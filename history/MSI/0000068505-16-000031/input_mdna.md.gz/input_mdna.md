# MSI MD&A — 0000068505-16-000031


## mdna

[0000068505-16-000031:mdna:1]
[same as prior period, unchanged from 0000068505-16-000026:mdna:1]

[0000068505-16-000031:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company,” “we,” “our,” or “us”) for the three and nine months ended October 1, 2016 and October 3, 2015, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2015.

[0000068505-16-000031:mdna:3]
[same as prior period, unchanged from 0000068505-16-000026:mdna:3]

[0000068505-16-000031:mdna:4]
[same as prior period, unchanged from 0000068505-16-000026:mdna:4]

[0000068505-16-000031:mdna:5]
[same as prior period, unchanged from 0000068505-16-000026:mdna:5]

[0000068505-16-000031:mdna:6]
During the three months ended October 1, 2016, we relocated our global headquarters from Schaumburg, IL to Chicago, IL. The move provides us with access to key talent and allows the Company to optimize the Schaumburg campus for current space requirements.

[0000068505-16-000031:mdna:7]
On September 23, 2016, we entered into a stock purchase agreement with Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions. The acquisition, which is expected to close in the fourth quarter of 2016, will expand our smart public safety portfolio and enables us to offer a full suite of command center solutions to a broader customer base.

[0000068505-16-000031:mdna:8]
[same as prior period, unchanged from 0000068505-16-000026:mdna:6]

[0000068505-16-000031:mdna:9]
[same as prior period, unchanged from 0000068505-16-000026:mdna:7]

[0000068505-16-000031:mdna:10]
[same as prior period, unchanged from 0000068505-16-000026:mdna:8]

[0000068505-16-000031:mdna:11]
Products: The Products segment is comprised of Devices and Systems. Devices includes two-way portable and vehicle mounted radios, accessories, and software features and upgrades. Systems includes the radio network core and central processing software, base stations, consoles, repeaters, and software applications and features. The primary customers of the Products segment are government, public safety and first-responder agencies, municipalities, and commercial and industrial customers who operate private communications networks and manage a mobile workforce. In the third quarter of 2016, the segment’s net sales were $920 million, representing 60% of our consolidated net sales.

[0000068505-16-000031:mdna:12]
Services: The Services segment provides a full set of service offerings for government, public safety, and commercial communication networks including: (i) Integration services, (ii) Managed & Support services, and (iii) iDEN services. Integration services includes the implementation, optimization, and integration of systems, devices, software, and applications. Managed & Support services includes a continuum of service offerings beginning with repair, technical support, and hardware maintenance. More advanced offerings include network monitoring, software maintenance, and cyber security services. Managed service offerings range from partial or full operation of customer owned networks to operation of Motorola Solutions owned networks. Services are provided across all radio network technologies, Command Center Consoles, and Smart Public Safety Solutions. iDEN services consists primarily of hardware and software maintenance services for our legacy iDEN customers. In the third quarter of 2016, the segment’s net sales were $612 million, representing 40% of our consolidated net sales.

[0000068505-16-000031:mdna:13]
[same as prior period, unchanged from 0000068505-16-000026:mdna:11]

[0000068505-16-000031:mdna:14]
Impact of Macroeconomic Conditions: The stronger U.S. dollar and weakening economic conditions have had a negative impact on sales, particularly in Latin America, parts of Europe, and China. Additionally, the strengthening dollar has reduced the purchasing power of our customers, and economic challenges have negatively impacted government budgets and funds available for the purchase of our products in these regions.

[0000068505-16-000031:mdna:15]
The impact of foreign exchange rate fluctuations on net earnings is partially mitigated by the following: (i) the majority of our revenues are derived from contracts within North America denominated in U.S. dollars, (ii) the cost of sales for the delivery of our Services offerings are predominately labor costs incurred within the same geographic region as the associated sales, resulting in minimal impact of foreign exchange rates on gross margin within the Services segment, and (iii) a significant portion

[0000068505-16-000031:mdna:16]
[same as prior period, unchanged from 0000068505-16-000026:mdna:28]

[0000068505-16-000031:mdna:17]
of our operating expenses are denominated in foreign currencies as a result of our offshore research and development ("R&D") and selling, general, and administrative ("SG&A") footprint.

[0000068505-16-000031:mdna:18]
Cost Savings Initiatives: We are committed to employing disciplined financial policies and driving continuous efficiencies and improvements in our cost structure. We expect to reduce SG&A and R&D expenses during 2016 by approximately $120 million in comparison to 2015, excluding incremental operating expenses from acquisitions in the second half of the year. In the first nine months of 2016, we realized $97 million of SG&A and R&D cost savings.

[0000068505-16-000031:mdna:19]
Growth of Our Services Portfolio: Our Services segment is expected to grow at a higher rate than our Products segment. Overall, the Services segment has a lower gross margin percentage than the Products segment, but we expect consolidated operating margins to continue to expand. During the three and nine months ended October 1, 2016, we grew our net sales within the Services segment by 23% and 18%, respectively, inclusive of the acquisition of GDCL, compared to the three and nine months ended October 3, 2015.

[0000068505-16-000031:mdna:20]
[same as prior period, unchanged from 0000068505-16-000026:mdna:18]

[0000068505-16-000031:mdna:21]
Third Quarter Summary

[0000068505-16-000031:mdna:22]
| • | Net sales were $1.5 billion in the third quarter of 2016, up $110 million, or 8%, from the third quarter of 2015. |

[0000068505-16-000031:mdna:23]
| • | We generated operating earnings of $341 million, or 22% of net sales, in the third quarter of 2016, compared to $231 million, or 16% of net sales, in the third quarter of 2015. Profitability increased primarily as a result of: (i) higher revenue and gross margin percentage in the Services segment and (ii) lower operating expenses as a result of cost savings initiatives. |

[0000068505-16-000031:mdna:24]
| • | We had earnings from continuing operations attributable to Motorola Solutions, Inc. of $192 million, or $1.13 per diluted common share, in the third quarter of 2016, compared to $126 million, or $0.63 per diluted common share, in the third quarter of 2015. |

[0000068505-16-000031:mdna:25]
| • | We generated net cash from operating activities of $652 million during the first nine months of 2016, compared to $607 million in the first nine months of 2015. |

[0000068505-16-000031:mdna:26]
| • | We returned $941 million in capital to shareholders through dividends and share repurchases during the first nine months of 2016. |

[0000068505-16-000031:mdna:27]
| • | We announced the acquisition of Spillman Technologies, a provider of comprehensive law enforcement and public safety software solutions. The acquisition, which is expected to close in the fourth quarter of 2016, will expand our smart public safety portfolio and will enable us to offer a full suite of command center solutions to a broader customer base. |

[0000068505-16-000031:mdna:28]
| • | We announced the increase of our quarterly dividend by 15 percent to $0.47 per share. |

[0000068505-16-000031:mdna:29]
[same as prior period, unchanged from 0000068505-16-000026:mdna:25]

[0000068505-16-000031:mdna:30]
| • | Products: Net sales were $920 million in the third quarter of 2016, a decrease of $5 million, or 1% compared to net sales of $925 million during the third quarter of 2015. On a geographic basis, net sales decreased in Europe, Middle East, and Africa ("EMEA"), Latin America, and Asia Pacific ("AP), and increased in North America, compared to the year-ago quarter. |

[0000068505-16-000031:mdna:31]
| • | Services: Net sales were $612 million in the third quarter of 2016, an increase of $115 million, or 23% compared to net sales of $497 million in the third quarter of 2015. On a geographic basis, net sales increased in EMEA, AP, and North America, and decreased in Latin America, compared to the year-ago quarter. |

[0000068505-16-000031:mdna:32]
27

[0000068505-16-000031:mdna:33]
[same as prior period, unchanged from 0000068505-16-000026:mdna:29]

[0000068505-16-000031:mdna:34]
|  | Three Months Ended |  | Nine Months Ended |
| (Dollars in millions, except per share amounts) | October 1, 2016 |  | % ofSales** |  | October 3, 2015 |  | % ofSales** |  | October 1, 2016 |  | % ofSales** |  | October 3, 2015 |  | % ofSales** |
| Net sales from products | $ | 920 |  |  |  |  | $ | 925 |  |  |  |  | $ | 2,423 |  |  |  |  | $ | 2,550 |  |  |  |
| Net sales from services | 612 |  |  |  |  | 497 |  |  |  |  | 1,732 |  |  |  |  | 1,463 |  |  |  |
| Net sales | 1,532 |  |  |  |  | 1,422 |  |  |  |  | 4,155 |  |  |  |  | 4,013 |  |  |  |
| Costs of product sales | 398 |  |  | 43.3 | % |  | 395 |  |  | 42.7 | % |  | 1,124 |  |  | 46.4 | % |  | 1,139 |  |  | 44.7 | % |
| Costs of services sales | 372 |  |  | 60.8 | % |  | 342 |  |  | 68.8 | % |  | 1,090 |  |  | 62.9 | % |  | 993 |  |  | 67.9 | % |
| Costs of sales | 770 |  |  |  |  | 737 |  |  |  |  | 2,214 |  |  |  |  | 2,132 |  |  |  |
| Gross margin | 762 |  |  | 49.7 | % |  | 685 |  |  | 48.2 | % |  | 1,941 |  |  | 46.7 | % |  | 1,881 |  |  | 46.9 | % |
| Selling, general and administrative expenses | 247 |  |  | 16.1 | % |  | 259 |  |  | 18.2 | % |  | 722 |  |  | 17.4 | % |  | 769 |  |  | 19.2 | % |
| Research and development expenditures | 137 |  |  | 8.9 | % |  | 153 |  |  | 10.8 | % |  | 411 |  |  | 9.9 | % |  | 468 |  |  | 11.7 | % |
| Other charges | 37 |  |  | 2.4 | % |  | 42 |  |  | 3.0 | % |  | 144 |  |  | 3.5 | % |  | 39 |  |  | 1.0 | % |
| Operating earnings | 341 |  |  | 22.3 | % |  | 231 |  |  | 16.2 | % |  | 664 |  |  | 16.0 | % |  | 605 |  |  | 15.1 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (54 | ) |  | (3.5 | )% |  | (43 | ) |  | (3.0 | )% |  | (157 | ) |  | (3.8 | )% |  | (122 | ) |  | (3.0 | )% |
| Gains (losses) on sales of investments and businesses, net | 7 |  |  | 0.5 | % |  | 10 |  |  | 0.7 | % |  | (13 | ) |  | (0.3 | )% |  | 60 |  |  | 1.5 | % |
| Other | (1 | ) |  | (0.1 | )% |  | (1 | ) |  | (0.1 | )% |  | (12 | ) |  | (0.3 | )% |  | (3 | ) |  | (0.1 | )% |
| Total other expense | (48 | ) |  | (3.1 | )% |  | (34 | ) |  | (2.4 | )% |  | (182 | ) |  | (4.4 | )% |  | (65 | ) |  | (1.6 | )% |
| Earnings from continuing operations before income taxes | 293 |  |  | 19.1 | % |  | 197 |  |  | 13.9 | % |  | 482 |  |  | 11.6 | % |  | 540 |  |  | 13.5 | % |
| Income tax expense | 100 |  |  | 6.5 | % |  | 71 |  |  | 5.0 | % |  | 164 |  |  | 3.9 | % |  | 175 |  |  | 4.4 | % |
| Earnings from continuing operations | 193 |  |  | 12.6 | % |  | 126 |  |  | 8.9 | % |  | 318 |  |  | 7.7 | % |  | 365 |  |  | 9.1 | % |
| Less: Earnings attributable to noncontrolling interests | 1 |  |  | 0.1 | % |  | — |  |  | — | % |  | 1 |  |  | — | % |  | 2 |  |  | — | % |
| Earnings from continuing operations* | 192 |  |  | 12.5 | % |  | 126 |  |  | 8.9 | % |  | 317 |  |  | 7.6 | % |  | 363 |  |  | 9.0 | % |
| Loss from discontinued operations, net of tax | — |  |  | — | % |  | (11 | ) |  | (0.8 | )% |  | — |  |  | — | % |  | (32 | ) |  | (0.8 | )% |
| Net earnings* | $ | 192 |  |  | 12.5 | % |  | $ | 115 |  |  | 8.1 | % |  | $ | 317 |  |  | 7.6 | % |  | $ | 331 |  |  | 8.2 | % |
| Earnings (loss) per diluted common share*: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Continuing operations | $ | 1.13 |  |  |  |  | $ | 0.63 |  |  |  |  | $ | 1.82 |  |  |  |  | $ | 1.74 |  |  |  |
| Discontinued operations | — |  |  |  |  | (0.06 | ) |  |  |  | — |  |  |  |  | (0.16 | ) |  |  |
| Earnings per diluted common share* | $ | 1.13 |  |  |  |  |  | $ | 0.57 |  |  |  |  |  | $ | 1.82 |  |  |  |  | $ | 1.58 |  |  |  |

[0000068505-16-000031:mdna:35]
[same as prior period, unchanged from 0000068505-16-000026:mdna:31]

[0000068505-16-000031:mdna:36]
[same as prior period, unchanged from 0000068505-16-000026:mdna:32]

[0000068505-16-000031:mdna:37]
Results of Operations—Three months ended October 1, 2016 compared to three months ended October 3, 2015

[0000068505-16-000031:mdna:38]
The results of operations for the third quarter of 2016 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-16-000031:mdna:39]
[same as prior period, unchanged from 0000068505-16-000026:mdna:35]

[0000068505-16-000031:mdna:40]
Net sales were $1.5 billion in the third quarter of 2016, a $110 million, or 8%, increase compared to the third quarter of 2015. The increase in net sales is reflective of growth in EMEA, North America, and AP, partially offset by a decrease in Latin America. The increase in EMEA was due to growth in Services sales, primarily due to the acquisition of GDCL which provided $131 million of net sales within the quarter, partially offset by lower Products sales. The increase in North America was due to higher sales in both the Products and Services segments. The increase in AP was due to growth in Services sales, partially offset by lower Products sales. The decrease in Latin America was the result of lower Products and Services sales primarily due to continued macroeconomic pressures.

[0000068505-16-000031:mdna:41]
[same as prior period, unchanged from 0000068505-16-000026:mdna:37]

[0000068505-16-000031:mdna:42]
Gross margin was $762 million, or 49.7% of net sales, in the third quarter of 2016, compared to $685 million, or 48.2% of net sales, in the third quarter of 2015. The increase in gross margin percentage was driven primarily by an increase in the margins within the Services segment while the Products segment decreased slightly. The increase in gross margin percentage in the Services segment was driven by the expansion of our Managed & Support services portfolio, primarily due to the acquisition of GDCL, which historically has had higher margins than our legacy portfolio.

[0000068505-16-000031:mdna:43]
[same as prior period, unchanged from 0000068505-16-000026:mdna:39]

[0000068505-16-000031:mdna:44]
SG&A expenses decreased 5% to $247 million, or 16.1% of net sales, in the third quarter of 2016, compared to $259 million, or 18.2% of net sales, in the third quarter of 2015. The decrease in SG&A expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000031:mdna:45]
[same as prior period, unchanged from 0000068505-16-000026:mdna:41]

[0000068505-16-000031:mdna:46]
R&D expenditures decreased 10% to $137 million, or 8.9% of net sales, in the third quarter of 2016, from $153 million, or 10.8% of net sales, in the third quarter of 2015. The decrease in R&D expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000031:mdna:47]
[same as prior period, unchanged from 0000068505-16-000026:mdna:43]

[0000068505-16-000031:mdna:48]
We recorded net charges of $37 million in the third quarter of 2016, compared to net charges of $42 million in the third quarter of 2015. The net Other charges in the third quarter of 2016 included: (i) $31 million of charges relating to the amortization of intangibles and (ii) $6 million of net reorganization of business charges. The net charges in the third quarter of 2015 of $42 million included: (i) $40 million of net reorganization of business charges, including a $26 million impairment of the corporate aircraft and a $6 million building impairment charge, and (ii) $2 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the “Reorganization of Businesses” section.

[0000068505-16-000031:mdna:49]
[same as prior period, unchanged from 0000068505-16-000026:mdna:45]

[0000068505-16-000031:mdna:50]
Net interest expense was $54 million in the third quarter of 2016 and $43 million in the third quarter of 2015. The increase in net interest expense in the third quarter of 2016 as compared to the third quarter of 2015 was a result of higher outstanding debt balances and lower cash balances.

[0000068505-16-000031:mdna:51]
[same as prior period, unchanged from 0000068505-16-000026:mdna:47]

[0000068505-16-000031:mdna:52]
Net gains on sales of investments and businesses were $7 million in the third quarter of 2016 compared to $10 million in the third quarter of 2015. The net gains in the third quarter of 2016 and the third quarter of 2015 were related to the sales of equity investments.

[0000068505-16-000031:mdna:53]
[same as prior period, unchanged from 0000068505-16-000026:mdna:49]

[0000068505-16-000031:mdna:54]
Net Other expense was $1 million in both the third quarter of 2016 and 2015. The net Other expense in the third quarter of 2016 was comprised of: (i) an $11 million loss on derivative investments and (ii) a $2 million investment impairment, partially offset by: (i) a $7 million foreign currency gain and (ii) $5 million of other non-operating gains. The net Other expense in the third quarter of 2015 was comprised of a $29 million foreign currency loss, partially offset by: (i) a $25 million gain on derivative instruments, (ii) a $2 million gain on equity method investments, and (iii) $1 million of other non-operating gains.

[0000068505-16-000031:mdna:55]
[same as prior period, unchanged from 0000068505-16-000026:mdna:51]

[0000068505-16-000031:mdna:56]
We recorded $100 million of net tax expense in the third quarter of 2016, resulting in an effective tax rate of 34%, compared to $71 million of net tax expense in the third quarter of 2015, resulting in an effective tax rate of 36%. Our effective tax rate in the third quarter of 2016 was lower than the U.S. statutory tax rate of 35% partly due to favorable discrete adjustments to deferred tax assets of foreign subsidiaries. Our effective tax rate in the third quarter of 2015 was higher than the U.S. statutory tax rate of 35% primarily due to higher income in the U.S. relative to foreign operations.

[0000068505-16-000031:mdna:57]
29

[0000068505-16-000031:mdna:58]
[same as prior period, unchanged from 0000068505-16-000026:mdna:53]

[0000068505-16-000031:mdna:59]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $192 million, or $1.13 per diluted share, in the third quarter of 2016, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $126 million, or $0.63 per diluted share, in the third quarter of 2015.

[0000068505-16-000031:mdna:60]
The increase in earnings from continuing operations in the third quarter of 2016, as compared to the third quarter of 2015, was primarily driven by: (i) a $77 million increase in Gross margin largely driven by our Managed & Support services in EMEA, primarily due to the acquisition of GDCL, (ii) a $16 million decrease in R&D expenses, and (iii) a $12 million decrease in SG&A spend. The increase in earnings from continuing operations per diluted share was driven by an increase in earnings from continuing operations and lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-16-000031:mdna:61]
[same as prior period, unchanged from 0000068505-16-000026:mdna:56]

[0000068505-16-000031:mdna:62]
In the third quarter of 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $11 million, or $0.06 per diluted share, in the third quarter of 2015.

[0000068505-16-000031:mdna:63]
Results of Operations—Nine months ended October 1, 2016 compared to nine months ended October 3, 2015

[0000068505-16-000031:mdna:64]
[same as prior period, unchanged from 0000068505-16-000026:mdna:59]

[0000068505-16-000031:mdna:65]
Net sales were $4.2 billion in the first nine months of 2016, a $142 million, or 4% increase from the first nine months of 2015. The increase in net sales is reflective of growth in EMEA and North America, partially offset by decreases in Latin America and AP. EMEA grew on Services sales, partially offset by lower Products sales. The increase in EMEA Services sales was due to an increase in Managed and Support services, primarily due to the acquisition of GDCL which provided $338 million of net sales during the first nine months of 2016. North America grew on both Services and Products sales. The decrease in Latin America was the result of lower Products and Services sales primarily due to macroeconomic pressures. The decrease in AP was due to lower Products sales, primarily in China, partially offset by growth in the Services segment.

[0000068505-16-000031:mdna:66]
[same as prior period, unchanged from 0000068505-16-000026:mdna:61]

[0000068505-16-000031:mdna:67]
Gross margin was $1.9 billion, or 46.7% of net sales, in the first nine months of 2016, compared to $1.9 billion, or 46.9% of net sales, in the first nine months of 2015. The decrease in gross margin percentage was driven by the Products segment while the gross margin percentage of the Services segment increased. The decrease in gross margin percentage in the Products segment was primarily driven by: (i) a decrease in volume and (ii) lower margins on global systems sales. The Services segment gross margin percentage improved with the expansion of our Managed & Support services portfolio, primarily due to the acquisition of GDCL, which historically has had higher margins than our legacy portfolio.

[0000068505-16-000031:mdna:68]
[same as prior period, unchanged from 0000068505-16-000026:mdna:63]

[0000068505-16-000031:mdna:69]
SG&A expenses decreased $47 million to $722 million, or 17.4% of net sales, in the first nine months of 2016, compared to $769 million, or 19.2% of net sales, in the first nine months of 2015. The decrease in SG&A expenditures is primarily due to: (i) cost savings initiatives, including headcount reductions, and (ii) lower pension expenses.

[0000068505-16-000031:mdna:70]
[same as prior period, unchanged from 0000068505-16-000026:mdna:65]

[0000068505-16-000031:mdna:71]
R&D expenditures decreased $57 million to $411 million, or 9.9% of net sales, in the first nine months of 2016, compared to $468 million, or 11.7% of net sales, in the first nine months of 2015. The decrease in R&D expenditures is primarily due to cost savings initiatives, including headcount reductions.

[0000068505-16-000031:mdna:72]
[same as prior period, unchanged from 0000068505-16-000026:mdna:67]

[0000068505-16-000031:mdna:73]
We recorded net charges of $144 million in Other charges in the first nine months of 2016, compared to net charges of $39 million in the first nine months of 2015. The net charges in the first nine months of 2016 included: (i) $83 million of charges relating to the amortization of intangibles, (ii) $48 million of net reorganization of business charges, including a $17 million building impairment and a $3 million impairment of the corporate aircraft, and (iii) $13 million of transaction fees on the acquisition of GDCL. The net Other charges in the first nine months of 2015 of $39 million included: (i) $65 million of net reorganization of business charges, including a $26 million impairment of the corporate aircraft and a $6 million building impairment charge, and (ii) $6 million of charges relating to the amortization of intangibles, partially offset by a $32 million gain related to the curtailment of a non-U.S. pension plan. The net reorganization of business charges are discussed in further detail in the “Reorganization of Business” section.

[0000068505-16-000031:mdna:74]
[same as prior period, unchanged from 0000068505-16-000026:mdna:69]

[0000068505-16-000031:mdna:75]
Net interest expense was $157 million in the first nine months of 2016 and $122 million in the first nine months of 2015. The increase in net interest expense in the first nine months of 2016 as compared to the first nine months of 2015 was a result of higher outstanding debt balances and lower cash balances.

[0000068505-16-000031:mdna:76]
[same as prior period, unchanged from 0000068505-16-000026:mdna:71]

[0000068505-16-000031:mdna:77]
Net losses on sales of investments and businesses were $13 million in the first nine months of 2016 compared to net gains on sales of investments and businesses of $60 million in the first nine months of 2015. The net losses in the first nine months of 2016 consisted of: (i) a $19 million loss on the sale of an investment in United Kingdom treasury securities and (ii) a $7 million loss from the sale of our Malaysia manufacturing operations, partially offset by $13 million of gains on the sales of equity investments. The net gain in the first nine months of 2015 consisted of gains on the sales of equity investments.

[0000068505-16-000031:mdna:78]
[same as prior period, unchanged from 0000068505-16-000026:mdna:73]

[0000068505-16-000031:mdna:79]
Net Other expense was $12 million in the first nine months of 2016, compared to net Other expense of $3 million in the first nine months of 2015. The net Other expense in the first nine months of 2016 was comprised of: (i) a $41 million loss on derivative instruments, (ii) a $10 million foreign currency loss on currency purchased and held in anticipation of the acquisition of GDCL, and (iii) a $2 million investment impairment, partially offset by: (i) a $34 million foreign currency gain, (ii) a $2 million gain on equity method investments, and (iii) $5 million of other non-operating gains. The net Other expense in the first nine months of 2015 was comprised of: (i) a $23 million foreign currency loss and (ii) a $3 million investment impairment, partially offset by: (i) a $13 million gain on derivative instruments, (ii) a $6 million gain on equity method investments, and (iii) $4 million of other non-operating gains.

[0000068505-16-000031:mdna:80]
[same as prior period, unchanged from 0000068505-16-000026:mdna:75]

[0000068505-16-000031:mdna:81]
We recorded $164 million of net tax expense in the first nine months of 2016, resulting in an effective tax rate of 34%, compared to $175 million of net tax expense, resulting in an effective tax rate of 32% in the first nine months of 2015. Our effective tax rate in 2016 was lower than the U.S. statutory tax rate of 35% partly due to the recognition of excess tax benefits on share-based compensation. Our effective tax rate in the first nine months of 2015 was lower than the U.S. statutory tax rate of 35% primarily due to the rate differential for foreign affiliates and the U.S. domestic production tax deduction.

[0000068505-16-000031:mdna:82]
[same as prior period, unchanged from 0000068505-16-000026:mdna:77]

[0000068505-16-000031:mdna:83]
After taxes, we had earnings from continuing operations attributable to Motorola Solutions, Inc. of $317 million, or $1.82 per diluted share, in the first nine months of 2016, compared to earnings from continuing operations attributable to Motorola Solutions, Inc. of $363 million, or $1.74 per diluted share, in the first nine months of 2015.

[0000068505-16-000031:mdna:84]
The decrease in earnings from continuing operations in the first nine months of 2016, as compared to the first nine months of 2015, was primarily driven by: (i) a $105 million increase in Other charges and (ii) a $73 million decrease in Gains (losses) on sales of investments and businesses, partially offset by: (i) a $60 million overall increase in Gross margin, (ii) a $57 million decrease in R&D expenses, and (iii) a $47 million decrease in SG&A spend. The increase in earnings from continuing operations per diluted share was driven by lower shares outstanding as a result of repurchases made through our ongoing share repurchase program.

[0000068505-16-000031:mdna:85]
[same as prior period, unchanged from 0000068505-16-000026:mdna:80]

[0000068505-16-000031:mdna:86]
In the first nine months of 2016, we reported no earnings from discontinued operations, compared to a loss from discontinued operations of $32 million, or $0.16 per diluted share, in the first nine months of 2015.

[0000068505-16-000031:mdna:87]
[same as prior period, unchanged from 0000068505-16-000026:mdna:82]

[0000068505-16-000031:mdna:88]
The following commentary should be read in conjunction with the financial results of each reporting segment for the three and nine months ended October 1, 2016 and October 3, 2015, as detailed in Note 12, “Segment Information,” of our condensed consolidated financial statements.

[0000068505-16-000031:mdna:89]
[same as prior period, unchanged from 0000068505-16-000026:mdna:84]

[0000068505-16-000031:mdna:90]
For the third quarter of 2016, the segment’s net sales represented 60% of our consolidated net sales, compared to 65% of our consolidated net sales for the third quarter of 2015. For the first nine months of 2016, the segment's net sales represented 58% of our consolidated net sales, compared to 64% of our consolidated net sales for the third quarter of 2015.

[0000068505-16-000031:mdna:91]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 1, 2016 |  | October 3, 2015 |  | % Change |  | October 1, 2016 |  | October 3, 2015 |  | % Change |
| Segment net sales | $ | 920 |  |  | $ | 925 |  |  | (1 | )% |  | $ | 2,423 |  |  | $ | 2,550 |  |  | (5 | )% |
| Operating earnings | 225 |  |  | 178 |  |  | 26 | % |  | 404 |  |  | 413 |  |  | (2 | )% |

[0000068505-16-000031:mdna:92]
Three months ended October 1, 2016 compared to three months ended October 3, 2015

[0000068505-16-000031:mdna:93]
The segment’s net sales decreased $5 million, or 1%, to $920 million in the third quarter of 2016, as compared to $925 million during the third quarter of 2015. The decrease in the segment's net sales was primarily driven by a decrease in devices sales in EMEA. On a geographic basis, net sales decreased in EMEA, Latin America, and AP, and increased in North America for the third quarter of 2016, compared to the third quarter of 2015.

[0000068505-16-000031:mdna:94]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 70% of the segment’s net sales in the third quarter of 2016, up from 66% of the segment’s net sales in the third quarter of 2015.

[0000068505-16-000031:mdna:95]
The segment had operating earnings of $225 million in the third quarter of 2016, compared to $178 million in the third quarter of 2015. The increase in operating earnings was primarily driven by: (i) a decrease in Other charges as a result of an $18 million impairment charge recorded in the third quarter of 2015 related to the corporate aircraft and (ii) lower SG&A and R&D expenditures as a result of cost savings initiatives, including headcount reductions.

[0000068505-16-000031:mdna:96]
Nine months ended October 1, 2016 compared to nine months ended October 3, 2015

[0000068505-16-000031:mdna:97]
The segment’s net sales decreased $127 million, or 5%, to $2.4 billion in the first nine months of 2016, as compared to $2.6 billion during the first nine months of 2015. The decrease in the segment's net sales was primarily driven by: (i) lower volume including decreased devices sales outside of North America and a decrease in global systems sales, (ii) decreases in both devices and systems sales in Latin America primarily due to macroeconomic conditions, and (iii) unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales decreased in EMEA, Latin America, and AP, and increased in North America for the first nine months of 2016, compared to the first nine months of 2015.

[0000068505-16-000031:mdna:98]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 70% of the segment’s net sales in the first nine months of 2016, up from 65% of the segment's net sales in the first nine months of 2015.

[0000068505-16-000031:mdna:99]
The segment had operating earnings of $404 million in the first nine months of 2016, compared to $413 million in the first nine months of 2015. The decrease in operating earnings in the first nine months of 2016 compared to the first nine months of 2015, was primarily driven by: (i) lower volume of devices and systems sales and (ii) an increase in Other charges, partially offset by: (i) lower SG&A expenditures as a result of cost savings initiatives, including headcount reductions, and lower pension expenses and (ii) lower R&D expenditures as a result of cost savings initiatives, including headcount reductions.

[0000068505-16-000031:mdna:100]
[same as prior period, unchanged from 0000068505-16-000026:mdna:97]

[0000068505-16-000031:mdna:101]
For the third quarter of 2016, the segment’s net sales represented 40% of our consolidated net sales, compared to 35% of our consolidated net sales for the third quarter of 2015. For the first nine months of 2016 and 2015, the segment’s net sales represented 42% of our consolidated net sales, compared to 36% of our consolidated net sales for the third quarter of 2015.

[0000068505-16-000031:mdna:102]
|  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  | October 1, 2016 |  | October 3, 2015 |  | % Change |  | October 1, 2016 |  | October 3, 2015 |  | % Change |
| Segment net sales | $ | 612 |  |  | $ | 497 |  |  | 23 | % |  | $ | 1,732 |  |  | $ | 1,463 |  |  | 18 | % |
| Operating earnings | 116 |  |  | 53 |  |  | 119 | % |  | 260 |  |  | 192 |  |  | 35 | % |

[0000068505-16-000031:mdna:103]
Three months ended October 1, 2016 compared to three months ended October 3, 2015

[0000068505-16-000031:mdna:104]
The segment’s net sales increased $115 million, or 23%, to $612 million in the third quarter of 2016, as compared to $497 million in the third quarter of 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the GDCL acquisition as well as organic growth. The acquisition of GDCL provided $131 million of net sales within EMEA during the quarter, while the organic Managed & Support services business grew in North America, AP, and Latin America. This sales growth was partially offset by: (i) a decrease in Integration services sales, primarily in EMEA related to the winding down of a large system implementation, and (ii) declining iDEN services sales in Latin America. On a geographic basis, net sales for the third quarter of 2016 increased in EMEA, AP, and North America, and decreased in Latin America, compared to the third quarter of 2015.

[0000068505-16-000031:mdna:105]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 52% of the segment’s net sales in the third quarter of 2016, compared to 63% of the segment’s net sales in the third quarter of 2015.

[0000068505-16-000031:mdna:106]
The segment had operating earnings of $116 million in the third quarter of 2016, compared to $53 million in the third quarter of 2015. The increase in operating earnings in the third quarter of 2016 compared to the third quarter of 2015 was primarily driven by increased sales volume generating higher gross margin on our Managed & Support services, primarily due to the GDCL acquisition, partially offset by an increase in Other charges, including $29 million of intangible amortization expense associated with the GDCL acquisition.

[0000068505-16-000031:mdna:107]
Nine months ended October 1, 2016 compared to nine months ended October 3, 2015

[0000068505-16-000031:mdna:108]
The segment’s net sales increased $269 million, or 18%, to $1.7 billion in the first nine months of 2016, as compared to net sales of $1.5 billion in the first nine months of 2015. The increase in the segment's net sales was primarily driven by higher Managed & Support services sales from both the acquisition of GDCL as well as organic growth. The acquisition of GDCL provided $338 million of net sales within EMEA during the first nine months of 2016, while the organic Managed & Support services business grew in North America and AP. This sales growth was partially offset by: (i) a decrease in Integration services sales, with a significant decrease in EMEA related to the winding down of a large system implementation, (ii) declining iDEN services sales in Latin America, and (iii) the effect of unfavorable foreign exchange rates with a strengthening U.S. dollar in EMEA, Latin America, and AP. On a geographic basis, net sales for the first nine months of 2016 increased in EMEA, AP, and North America, and decreased and Latin America, compared to the first nine months of 2015.

[0000068505-16-000031:mdna:109]
Net sales in North America continued to comprise a significant portion of the segment’s business, accounting for approximately 53% of the segment’s net sales in the first nine months of 2016, compared to 62% of the segment’s net sales in the first nine months of 2015.

[0000068505-16-000031:mdna:110]
The segment had operating earnings of $260 million in the first nine months of 2016, compared to operating earnings of $192 million in the first nine months of 2015. The increase in operating earnings in the first nine months of 2016 as compared to the first nine months of 2015 was driven by increased sales volume generating higher gross margin on our Managed & Support services, primarily in EMEA, partially offset by an increase in Other charges, including $77 million of intangible amortization expense associated with the GDCL acquisition.

[0000068505-16-000031:mdna:111]
[same as prior period, unchanged from 0000068505-16-000026:mdna:108]

[0000068505-16-000031:mdna:112]
During the third quarter of 2016, we recorded net reorganization of business charges of $7 million including $6 million of charges recorded within Other charges and $1 million in Cost of sales in our condensed consolidated statements of operations.  Included in the $7 million were charges of $8 million related to employee separation costs, partially offset by $1 million of reversals for accruals no longer needed.

[0000068505-16-000031:mdna:113]
During the first nine months of 2016, we implemented various productivity improvement plans aimed at continuing operating margin improvements by driving efficiencies and reducing operating costs. During the first nine months of 2016, we recorded net reorganization of business charges of $74 million including charges of $48 million recorded in Other charges and $26 million in Cost of sales in our condensed consolidated statements of operations. Included in the $74 million were charges of: (i) $54 million for employee separation costs, (ii) $20 million for impairments, including $17 million for a building impairment and $3 million for the impairment of the corporate aircraft, and (iii) $5 million for exit costs, partially offset by $5 million of reversals for accruals no longer needed.

[0000068505-16-000031:mdna:114]
During the third quarter of 2015, we recorded net reorganization of business charges of $41 million including charges of $40 million recorded in Other charges and $1 million in Cost of sales in our condensed consolidated statements of operations. Included in the $41 million were charges of: (i) $26 million for the impairment of corporate aircraft, (ii) $11 million of charges related to employee separation costs, and (iii) a $6 million building impairment charge, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-16-000031:mdna:115]
During the first nine months of 2015, we recorded net reorganization of business charges of $70 million including charges of $65 million recorded in Other charges and $5 million in Cost of sales in our condensed consolidated statements of operations. Included in the $70 million were charges of: (i) $36 million related to employee separation costs, (ii) $26 million for the impairment of the corporate aircraft, (iii) a $6 million building impairment charge, and (iv) $4 million for exit costs, partially offset by $2 million of reversals for accruals no longer needed.

[0000068505-16-000031:mdna:116]
[same as prior period, unchanged from 0000068505-16-000026:mdna:113]

[0000068505-16-000031:mdna:117]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Products | $ | 5 |  |  | $ | 29 |  |  | $ | 59 |  |  | $ | 51 |  |
| Services | 2 |  |  | 12 |  |  | 15 |  |  | 19 |  |
|  | $ | 7 |  |  | $ | 41 |  |  | $ | 74 |  |  | $ | 70 |  |

[0000068505-16-000031:mdna:118]
Cash payments for employee severance and exit costs in connection with the reorganization of business plans were $59 million in the first nine months of 2016 and $53 million in the first nine months of 2015. The reorganization of business accruals at October 1, 2016 were $55 million, of which $46 million relate to employee separation costs that are expected to be paid within one year and $9 million of accruals related primarily to lease termination obligations that are expected to be paid over a number of years.

[0000068505-16-000031:mdna:119]
[same as prior period, unchanged from 0000068505-16-000026:mdna:116]

[0000068505-16-000031:mdna:120]
We decreased the aggregate of our cash and cash equivalent balances by $293 million from $2.0 billion as of December 31, 2015 to $1.7 billion as of October 1, 2016. The decrease is primarily due to: (i) $1.0 billion paid in the acquisition of GDCL and (ii) $941 million of capital returned to shareholders through share repurchases and dividends paid, offset by (i) $673 million of net proceeds raised by the issuance of the Term Loan (net of $2 million of issuance costs paid), (ii) $382 million of proceeds received from the sale of United Kingdom treasury securities used to partially fund the acquisition of GDCL, and (iii) $652 million of cash generated by operating activities.

[0000068505-16-000031:mdna:121]
[same as prior period, unchanged from 0000068505-16-000026:mdna:118]

[0000068505-16-000031:mdna:122]
[same as prior period, unchanged from 0000068505-16-000026:mdna:119]

[0000068505-16-000031:mdna:123]
At October 1, 2016, $1.0 billion of the $1.7 billion cash and cash equivalents balance was held in the U.S. and approximately $680 million was held by the Company or its subsidiaries in other countries, with approximately $354 million held in the United Kingdom. Restricted cash was $63 million at both October 1, 2016 and December 31, 2015.

[0000068505-16-000031:mdna:124]
[same as prior period, unchanged from 0000068505-16-000026:mdna:121]

[0000068505-16-000031:mdna:125]
Net cash provided by operating activities in the first nine months of 2016 was $652 million, as compared to $607 million in the first nine months of 2015. Operating cash flows in the first nine months of 2016, as compared to the first nine months of 2015, were positively impacted by higher earnings from continuing operations (adjusted for net non-cash charges), offset by higher employee incentive payments.

[0000068505-16-000031:mdna:126]
[same as prior period, unchanged from 0000068505-16-000026:mdna:123]

[0000068505-16-000031:mdna:127]
Net cash used by investing activities was $721 million in the first nine months of 2016, compared to $129 million in the first nine months of 2015. The $721 million cash used in the first nine months of 2016 included: (i) $1.2 billion cash used for acquisitions and investments, including $1.0 billion paid for the acquisition of GDCL, and (ii) $211 million in capital expenditures, partially offset by: (i) $637 million of proceeds from sales of investments and businesses and (ii) $68 million of proceeds from the sale of property, plant and equipment. The cash usage of $129 million in the first nine months of 2015 consisted primarily of: (i) $150 million cash used for acquisitions and investments and (ii) $131 million in capital expenditures, partially offset by: (i) $150 million of proceeds from the sale of investments and businesses and (ii) $2 million of proceeds from the sale of property, plant, and equipment.

[0000068505-16-000031:mdna:128]
Acquisition and Investments:  We used net cash for acquisitions and investments of $1.2 billion during the first nine months of 2016 compared to $150 million in the first nine months of 2015. We paid cash of $1.0 billion during the first nine months of 2016 related to the acquisition of GDCL. The remainder of the cash was used for several debt and equity investments. The cash used during the first nine months of 2015 consisted of $49 million related to the acquisition of two public safety software solution providers and several debt and equity investments.

[0000068505-16-000031:mdna:129]
Sales of Investments and Businesses:  We had $637 million of proceeds related to the sales of investments and businesses in the first nine months of 2016 compared to $150 million in the first nine months of 2015. The proceeds in the first nine months of 2016 primarily consisted of: (i) $382 million from the sale of United Kingdom treasury securities used to finance the acquisition of GDCL, (ii) $209 million from the sales of various debt and equity securities, and (iii) $46 million from the sale of our Penang, Malaysia facility and manufacturing operations. The proceeds in the first nine months of 2015 were comprised of: (i) $54 million from the sale of an equity investment, (ii) $49 million reimbursement from Zebra Technologies for cash transferred with the sale of the Enterprise business in conjunction with legal entities sold through a stock sale, (iii) $15 million net cash received from Zebra Technologies for reimbursement of liabilities of the Enterprise business paid on Zebra's behalf, and (iv) proceeds from the sale of various debt and equity securities, partially offset by $27 million of net cash transferred in conjunction with the sale of our ownership interest in a majority owned subsidiary to the entity's noncontrolling interest.

[0000068505-16-000031:mdna:130]
Capital Expenditures:  Capital expenditures increased in the first nine months of 2016 to $211 million, compared to $131 million in the first nine months of 2015. The increase in capital expenditures was primarily related to revenue-generating network expenditures, information technology spend, and facility expenditures.

[0000068505-16-000031:mdna:131]
Sales of Property, Plant, and Equipment:  We had $68 million of proceeds related to the sale of property, plant, and equipment in the first nine months of 2016 compared to $2 million in the first nine months of 2015. The proceeds in the first nine months of 2016 were comprised of $49 million from the sale of buildings and land on the Schaumburg, IL headquarters campus and $19 million received from the sale of the corporate aircraft.

[0000068505-16-000031:mdna:132]
[same as prior period, unchanged from 0000068505-16-000026:mdna:130]

[0000068505-16-000031:mdna:133]
Net cash used for financing activities was $191 million in the first nine months of 2016, compared to $2.2 billion in the first nine months of 2015. Cash used for financing activities in the first nine months of 2016 was primarily comprised of: (i) $728 million used for purchases of our common stock under our share repurchase program and (ii) $213 million of cash used for the payment of dividends, partially offset by: (i) $673 million of net proceeds from the issuance of the Term Loan and (ii) $80 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan. Net cash used for financing activities in the first nine months of 2015 was primarily comprised of: (i) $3.0 billion used for purchases of our common stock under our share repurchase program and (ii) $218 million of cash used for the payment of dividends, partially offset by: (i) $976 million of net proceeds from the issuance of the Senior Convertible Notes (net of issuance costs paid) and (ii) $69 million of net proceeds from the issuance of common stock in connection with our employee stock option plans and employee stock purchase plan.

[0000068505-16-000031:mdna:134]
Long-Term Debt:  We had outstanding long-term debt of $5.0 billion and $4.3 billion, including the current portions of $5 million and $4 million at October 1, 2016 at December 31, 2015, respectively.

[0000068505-16-000031:mdna:135]
In connection with the completion of the acquisition of GDCL, we entered into a new term loan credit agreement (the “Term Loan Agreement”), under which we borrowed a Term Loan with an initial principal amount of $675 million. We received net proceeds of $673 million, net of $2 million of issuance costs. Interest on the Term Loan is variable and indexed to LIBOR. No additional borrowings are permitted under the Term Loan Agreement and amounts borrowed and repaid or prepaid may not be re-borrowed.

[0000068505-16-000031:mdna:136]
[same as prior period, unchanged from 0000068505-16-000026:mdna:134]

[0000068505-16-000031:mdna:137]
Share Repurchase Program: During the nine months ended October 1, 2016, the Company paid an aggregate of $728 million, including transaction costs, to repurchase approximately 10.5 million shares at an average price of $69.31 per share. As of October 1, 2016, the Company had used approximately $11.7 billion of the share repurchase authority, including transaction costs, to repurchase shares, leaving $2.3 billion of authority available for future repurchases.

[0000068505-16-000031:mdna:138]
Payment of Dividends: During the third quarter of 2016, we paid $70 million in cash dividends to holders of our common stock. During the first nine months of 2016, we paid $213 million in cash dividends to holders of our common stock. Subsequent to quarter end, we paid an additional $68 million in cash dividends to holders of our common stock.

[0000068505-16-000031:mdna:139]
[same as prior period, unchanged from 0000068505-16-000026:mdna:137]

[0000068505-16-000031:mdna:140]
As of October 1, 2016, we had a $2.1 billion unsecured syndicated revolving credit facility, which includes a $450 million letter of credit sub-limit, (the “2014 Motorola Solutions Credit Agreement”) scheduled to mature on May 29, 2019. We must comply with certain customary covenants, including maximum leverage ratio as defined in the 2014 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of October 1, 2016. We did not borrow or issue any letters of credit under the 2014 Motorola Solutions Credit Agreement during the first nine months of 2016.

[0000068505-16-000031:mdna:141]
[same as prior period, unchanged from 0000068505-16-000026:mdna:139]

[0000068505-16-000031:mdna:142]
Outstanding Commitments:  We had outstanding commitments to provide long-term financing to third parties totaling $214 million at October 1, 2016, compared to $112 million at December 31, 2015.

[0000068505-16-000031:mdna:143]
Outstanding Long-Term Receivables:  We had net non-current long-term receivables of $43 million at October 1, 2016, compared to $47 million at December 31, 2015.

[0000068505-16-000031:mdna:144]
[same as prior period, unchanged from 0000068505-16-000026:mdna:142]

[0000068505-16-000031:mdna:145]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and nine months ended October 1, 2016 and October 3, 2015:

[0000068505-16-000031:mdna:146]
|  | Three Months Ended |  | Nine Months Ended |
|  | October 1, 2016 |  | October 3, 2015 |  | October 1, 2016 |  | October 3, 2015 |
| Accounts receivable sales proceeds | $ | 8 |  |  | $ | 5 |  |  | $ | 15 |  |  | $ | 16 |  |
| Long-term receivables sales proceeds | 39 |  |  | 24 |  |  | 173 |  |  | 132 |  |
| Total proceeds from sales of accounts receivable | $ | 47 |  |  | $ | 29 |  |  | $ | 188 |  |  | $ | 148 |  |

[0000068505-16-000031:mdna:147]
At October 1, 2016, the Company had retained servicing obligations for $685 million of long-term receivables, compared to $668 million of long-term receivables at December 31, 2015. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables.

[0000068505-16-000031:mdna:148]
35

[0000068505-16-000031:mdna:149]
Other Contingencies

[0000068505-16-000031:mdna:150]
[same as prior period, unchanged from 0000068505-16-000026:mdna:147]

[0000068505-16-000031:mdna:151]
[same as prior period, unchanged from 0000068505-16-000026:mdna:148]

[0000068505-16-000031:mdna:152]
Some of these obligations arise as a result of divestitures of our assets or businesses and require us to indemnify the other party against losses arising from breaches of representations and warranties and covenants and, in some cases, the settlement of pending obligations. Our obligations under divestiture agreements for indemnification based on breaches of representations and warranties are generally limited in terms of duration, and for amounts for breaches of such representations and warranties in connection with prior divestitures not in excess of a percentage of the contract value. We had no accruals for any such obligations at October 1, 2016.

[0000068505-16-000031:mdna:153]
[same as prior period, unchanged from 0000068505-16-000026:mdna:150]

[0000068505-16-000031:mdna:154]
[same as prior period, unchanged from 0000068505-16-000026:mdna:151]

[0000068505-16-000031:mdna:155]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2014-09, "Revenue from Contracts with Customers." This new standard will replace most existing revenue recognition guidance in U.S. GAAP. The core principle of the ASU is that an entity should recognize revenue for the transfer of goods or services equal to the amount it expects to receive for those goods and services. The ASU requires additional disclosure about the nature, amount, timing and uncertainty of revenue and cash flows arising from customer contracts, including significant judgments and estimates and changes in those estimates. In August 2015, the FASB issued ASU 2015-14, "Revenue from Contracts with Customers: Deferral of the Effective Date" that delayed the effective date of ASU 2014-09 by one year to January 1, 2018, as the our annual reporting period begins after December 15, 2017. In March 2016, the FASB issued ASU 2016-08, “"Revenue from Contracts with Customers: Principal versus Agent Considerations (Reporting Revenue Gross versus Net)” which clarifies the implementation guidance on principal versus agent considerations and includes indicators to assist an entity in determining whether it controls a specified good or service before it is transferred to the customers. In April of 2016, the FASB issued ASU 2016-10, Revenue from Contracts with Customers (Topic 606) - Identifying Performance Obligations and Licensing,” which reduces the complexity when applying the guidance for identifying performance obligations and improves the operability and understandability of the license implementation guidance. In May 2016, the FASB issued ASU 2016-12 “Revenue from Contracts with Customers (Topic 606) - Narrow-Scope Improvements and Practical Expedients,” which amends the guidance on transition, collectability, non-cash consideration and the presentation of sales and other similar taxes. ASU 2016-12 clarifies that, for a contract to be considered completed at transition, all (or substantially all) of the revenue must have been recognized under legacy GAAP. In addition, ASU 2016-12 clarifies how an entity should evaluate the collectability threshold and when an entity can recognize nonrefundable consideration received as revenue if an arrangement does not meet the standard’s contract criteria. The standard allows for both retrospective and modified retrospective methods of adoption. We are in the process of determining the method of adoption we will elect and are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000031:mdna:156]
In February 2016, the FASB issued ASU No. 2016-02, "Leases," which amends existing guidance to require lessees to recognize assets and liabilities on the balance sheet for the rights and obligations created by long-term leases and to disclose additional quantitative and qualitative information about leasing arrangements. The ASU is effective for us January 1, 2019 and interim periods within that reporting period.  The ASU requires a modified retrospective method upon adoption. We are in the process of assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000031:mdna:157]
In August 2016, the FASB issued ASU 2016-15, “Statement of Cash Flows (Topic 230) - Classification of Certain Cash Receipts and Cash Payments,” which clarifies eight specific cash flow issues in an effort to reduce diversity in practice in how certain transactions are classified within the statement of cash flows. This ASU is effective for us January 1, 2018 with early adoption permitted. Upon adoption, the ASU requires a retrospective application unless it is determined that it is impractical to do so for which it must be retrospectively applied at the earliest date practical. Upon adoption, we do not anticipate significant changes to our existing accounting policies or presentation of the Statement of Cash Flows.

[0000068505-16-000031:mdna:158]
In October 2016, the FASB issued ASU 2016-16, “Accounting for Income Taxes: Intra-Entity Asset Transfers of Assets Other than Inventory,” as part of the Board’s simplification initiative aimed at reducing complexity in accounting standards. This

[0000068505-16-000031:mdna:159]
ASU eliminates the current application of deferring the income tax effect of intra-entity asset transfers, other than inventory, until the transferred asset is sold to a third party or otherwise recovered through use and will require entities to recognize tax expense when the transfer occurs. The guidance will be effective for us on January 1, 2018 and interim periods within that reporting period; early adoption permitted. The ASU requires a modified retrospective application with a cumulative-effect adjustment recorded in retained earnings as of the beginning of the period of adoption. We are currently assessing the impact of this ASU on our consolidated financial statements and footnote disclosures.

[0000068505-16-000031:mdna:160]
37
