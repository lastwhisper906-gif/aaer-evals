# MSI note change history — 0000068505-25-000024 → 0000068505-25-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-08-07):
[0000068505-25-000040:note_history:1]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for the Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor and awarded the Company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

- added (2025-08-07):
[0000068505-25-000040:note_history:2]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations.

- changed (2025-08-07):
[0000068505-25-000040:note_history:3]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation and injunction are currently briefed. The District Court is seeking to schedule a hearing on these issues for sometime later in 2025.
  (was, 2025-05-01, similarity 0.6241):
[0000068505-25-000024:note_history:3]
Following the February 14, 2020, verdict and judgment in the Company's favor, Hytera appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"), seeking review of the orders related to the jury's verdict as well as the District Court's royalty order. The Company filed its cross-appeal on August 5, 2022. The Court of Appeals heard oral arguments on December 5, 2023, and issued its decision on July 2, 2024. The Court of Appeals affirmed the District Court's award of $407.4 million in damages, including exemplary damages, under the Defend Trade Secrets Act. The Court of Appeals also directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. The issues of copyright recalculation and injunction are currently briefed and under consideration by the District Court.

- added (2025-08-07):
[0000068505-25-000040:note_history:4]
On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million, and an additional payment of approximately $10 million on April 25, 2025. Both payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. Subsequent to quarter end, the Company received additional payments of approximately $41 million. The Company continues to seek collection of the judgment through the ongoing legal process.

- changed (2025-08-07):
[0000068505-25-000040:note_history:5]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings in August 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.
  (was, 2025-05-01, similarity 0.61):
[0000068505-25-000024:note_history:5]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine, for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, to allow the Court of Appeals to review the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings from August 26-30, 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

- changed (2025-08-07):
[0000068505-25-000040:note_history:6]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 24th and 25th, 2025. Pursuant to the plea agreement, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.
  (was, 2025-05-01, similarity 0.8897):
[0000068505-25-000024:note_history:6]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 6, 2025. Pursuant to the plea agreement reached between Hytera and the government, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.

- removed (2025-08-07):
[0000068505-25-000024:note_history:7]
On March 14, 2017, the Company filed a complaint in the U.S. District Court for the Northern District of Illinois (the "District Court") against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), alleging trade secret theft and copyright infringement and seeking, among other things, injunctive relief, compensatory damages and punitive damages. On February 14, 2020, the Company announced that a jury decided in the Company's favor in its trade secret theft and copyright infringement case. In connection with this verdict, the jury awarded the Company $345.8 million in compensatory damages and $418.8 million in punitive damages, for a total of $764.6 million. In a series of post-trial rulings in 2021, the District Court subsequently reduced the judgment to $543.7 million, but also ordered Hytera to pay the Company $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees. The Company continues to seek collection of the judgment through the ongoing legal process.

- removed (2025-08-07):
[0000068505-25-000024:note_history:8]
On December 17, 2020, the District Court held that Hytera must pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, and on December 15, 2021, set royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. On July 5, 2022, the District Court ordered that Hytera pay into a third-party escrow on July 31, 2022, the royalties owed to the Company based on the sale of relevant products from July 1, 2019 to June 30, 2022. Hytera failed to make the required royalty payment on July 31, 2022. On August 1, 2022, Hytera filed a motion to modify or stay the District Court's previous July 5, 2022 royalty order, which the District Court denied on July 11, 2023. On August 3, 2022, the Company filed a motion seeking to hold Hytera in civil contempt for violating the royalty order by not making the required royalty payment on July 31, 2022. On August 26, 2023, the District Court granted the Company's contempt motion. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow. In addition to the September 1, 2023 payment of $56 million, Hytera made de minimis quarterly royalty payments into the third-party escrow from October 2022 through November 2024; after which such de minimis royalty payments have been paid directly to the Company. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other Charges (Income) within the Consolidated Statement of Operations. On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million and that payment was recorded as a gain within Other charges (Income) within the Consolidated Statement of Operations.

- removed (2025-08-07):
[0000068505-25-000024:note_history:9]
On January 2, 2025, Hytera filed a petition for Writ of certiorari with the Supreme Court of the United States. Hytera's petition was denied by the Supreme Court on February 24, 2025.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-08-07):
[0000068505-25-000040:note_history:10]
Basis of Presentation
The condensed consolidated financial statements as of June 28, 2025 and for the three and six months ended June 28, 2025 and June 29, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.
  (was, 2025-05-01, similarity 0.9451):
[0000068505-25-000024:note_history:10]
Basis of Presentation
The condensed consolidated financial statements as of March 29, 2025 and for the three months ended March 29, 2025 and March 30, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

- changed (2025-08-07):
[0000068505-25-000040:note_history:11]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and six months ended June 28, 2025 are not necessarily indicative of the operating results to be expected for the full year.
  (was, 2025-05-01, similarity 0.8167):
[0000068505-25-000024:note_history:11]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three months ended March 29, 2025 are not necessarily indicative of the operating results to be expected for the full year.

- added (2025-08-07):
[0000068505-25-000040:note_history:12]
Subsequent to the quarter end, with the acquisition of Silvus Technologies Holdings Inc. (“Silvus”), the Company will now report net sales from its principal product lines by combining the former LMR Communications and newly acquired Silvus under the new technology name Mission Critical Networks (MCN).

- added (2025-08-07):
[0000068505-25-000040:note_history:13]
On May 27, 2025, the Company entered into a purchase and sale agreement with Silvus Technologies Group LLC ("Seller") to acquire Silvus Technologies Holdings Inc. (“Silvus”), which subsequent to the quarter end closed on August 6, 2025, for $4.4 billion in upfront consideration, comprising $4.38 billion in cash, subject to customary adjustments for cash, net working capital, transaction expenses and indebtedness, and $20 million in restricted stock to certain employee equity holders. Additionally, under the terms of the transaction, the Seller will have the potential to earn earnout consideration following the achievement of certain financial targets of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn a catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be made in shares of common stock. Silvus designs and develops software-defined high-speed mobile ad-hoc network (MANET) technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. This business will be part of both the Products and Systems Integration segment and the Software and Services segment.

- changed (2025-08-07):
[0000068505-25-000040:note_history:14]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services segment.
  (was, 2025-05-01, similarity 0.6142):
[0000068505-25-000024:note_history:14]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio of enterprise technologies, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services Segment.

- changed (2025-08-07):
[0000068505-25-000040:note_history:15]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.
  (was, 2025-05-01, similarity 0.9924):
[0000068505-25-000024:note_history:15]
On October 29, 2024, the Company acquired 3tc Software ("3tc"), a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

- changed (2025-08-07):
[0000068505-25-000040:note_history:16]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.
  (was, 2025-05-01, similarity 0.9986):
[0000068505-25-000024:note_history:16]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date", which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-08-07):
[0000068505-25-000040:note_history:17]
Debt and Credit Facilities

- added (2025-08-07):
[0000068505-25-000040:note_history:18]
|  | June 28, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 596 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 893 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 7,732 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (70) |  |  | (322) |  |
| Long-term debt | $ | 7,661 |  |  | $ | 5,675 |  |

- added (2025-08-07):
[0000068505-25-000040:note_history:19]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030 (“2030 Notes”), $500 million of 5.2% senior notes due 2032 (“2032 Notes”) and $900 million of 5.55% senior notes due 2035 (“2035 Notes”). The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

- added (2025-08-07):
[0000068505-25-000040:note_history:20]
On May 27, 2025, the Company obtained financing commitments for $2.5 billion of senior unsecured delayed draw term loan facilities, comprised of a $1.75 billion 364-day facility and a $750 million three year facility. Upon issuance of 2030 Notes, 2032 Notes, and 2035 Notes, the financing commitments under the 364-day facility were reduced to $750 million. Subsequent to the quarter, on July 21, 2025 the Company entered into credit agreements for a $750 million 364-day delayed draw term loan and a $750 million three year delayed draw term loan, and on August 6, 2025 the Company borrowed $750 million under the 364-day delayed draw term loan and $750 million under the three year delayed draw term loan to fund a portion of the acquisition of Silvus.

- added (2025-08-07):
[0000068505-25-000040:note_history:21]
During the three months ended June 28, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% senior notes due 2025.

- changed (2025-08-07):
[0000068505-25-000040:note_history:22]
As of June 28, 2025, $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.
  (was, 2025-05-01, similarity 0.8014):
[0000068505-25-000024:note_history:22]
Debt and Credit Facilities
As of March 29, 2025, $252 million of 7.5% debentures due 2025, which mature in May 2025, and $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

- changed (2025-08-07):
[0000068505-25-000040:note_history:23]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 28, 2025.
  (was, 2025-05-01, similarity 0.8916):
[0000068505-25-000024:note_history:23]
Subsequent to the quarter end, on April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"). The 2025 Motorola Solutions Credit Agreement replaces the 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement.

- changed (2025-08-07):
[0000068505-25-000040:note_history:24]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 28, 2025 the Company had no outstanding debt under the commercial paper program. Subsequent to the quarter, the Company utilized its commercial paper program as a source of short-term liquidity to partially fund the acquisition of Silvus.
  (was, 2025-05-01, similarity 0.8903):
[0000068505-25-000024:note_history:24]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of March 29, 2025 the Company had no outstanding debt under the commercial paper program.

- removed (2025-08-07):
[0000068505-25-000024:note_history:25]
As of March 29, 2025, the Company had a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in March 2026 (the "2021 Motorola Solutions Credit Agreement"). The 2021 Motorola Solutions Credit Agreement includes a letter of credit sub-limit and fronting commitments of $450 million. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2021 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of March 29, 2025.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-08-07):
[0000068505-25-000040:note_history:26]
|  | June 28, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 596 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 893 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 7,732 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (70) |  |  | (322) |  |
| Long-term debt | $ | 7,661 |  |  | $ | 5,675 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-07):
[0000068505-25-000040:note_history:27]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 28, 2025 and June 29, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2025-05-01, similarity 0.9282):
[0000068505-25-000024:note_history:27]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 29, 2025 and March 30, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-08-07):
[0000068505-25-000040:note_history:28]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,030 |  |  | $ | 1,016 |  |  | 2,046 |  |  | $ | 1,000 |  |  | $ | 880 |  |  | $ | 1,880 |  |
| Indirect | 623 |  |  | 96 |  |  | 719 |  |  | 658 |  |  | 90 |  |  | 748 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
  (was, 2025-05-01, similarity 0.9832):
[0000068505-25-000024:note_history:28]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,016 |  |  | $ | 907 |  |  | 1,923 |  |  | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |
| Indirect | 530 |  |  | 75 |  |  | 605 |  |  | 630 |  |  | 77 |  |  | 707 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |

- added (2025-08-07):
[0000068505-25-000040:note_history:29]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,046 |  |  | $ | 1,923 |  |  | $ | 3,969 |  |  | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |
| Indirect | 1,153 |  |  | 171 |  |  | 1,324 |  |  | 1,288 |  |  | 167 |  |  | 1,455 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-08-07):
[0000068505-25-000040:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 28, 2025 and June 29, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:
  (was, 2025-05-01, similarity 0.9282):
[0000068505-25-000024:note_history:30]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three months ended March 29, 2025 and March 30, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

- changed (2025-08-07):
[0000068505-25-000040:note_history:31]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,030 |  |  | $ | 1,016 |  |  | 2,046 |  |  | $ | 1,000 |  |  | $ | 880 |  |  | $ | 1,880 |  |
| Indirect | 623 |  |  | 96 |  |  | 719 |  |  | 658 |  |  | 90 |  |  | 748 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
  (was, 2025-05-01, similarity 0.9832):
[0000068505-25-000024:note_history:31]
|  | Three Months Ended |
|  | March 29, 2025 |  | March 30, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,178 |  |  | $ | 674 |  |  | $ | 1,852 |  |  | $ | 1,082 |  |  | $ | 611 |  |  | $ | 1,693 |  |
| International | 368 |  |  | 308 |  |  | 676 |  |  | 408 |  |  | 288 |  |  | 696 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,315 |  |  | $ | 586 |  |  | $ | 1,901 |  |  | $ | 1,255 |  |  | $ | 567 |  |  | $ | 1,822 |  |
| Video | 231 |  |  | 210 |  |  | 441 |  |  | 235 |  |  | 163 |  |  | 398 |  |
| Command Center | — |  |  | 186 |  |  | 186 |  |  | — |  |  | 169 |  |  | 169 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,016 |  |  | $ | 907 |  |  | 1,923 |  |  | $ | 860 |  |  | $ | 822 |  |  | $ | 1,682 |  |
| Indirect | 530 |  |  | 75 |  |  | 605 |  |  | 630 |  |  | 77 |  |  | 707 |  |
|  | $ | 1,546 |  |  | $ | 982 |  |  | $ | 2,528 |  |  | $ | 1,490 |  |  | $ | 899 |  |  | $ | 2,389 |  |

- added (2025-08-07):
[0000068505-25-000040:note_history:32]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,046 |  |  | $ | 1,923 |  |  | $ | 3,969 |  |  | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |
| Indirect | 1,153 |  |  | 171 |  |  | 1,324 |  |  | 1,288 |  |  | 167 |  |  | 1,455 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |

- changed (2025-08-07):
[0000068505-25-000040:note_history:33]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of June 28, 2025 was $8.8 billion. A total of $3.4 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of June 28, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.4 billion was from Software and Services performance obligations that were not yet satisfied as of June 28, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.
  (was, 2025-05-01, similarity 0.9925):
[0000068505-25-000024:note_history:33]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of March 29, 2025 was $8.9 billion. A total of $3.6 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of March 29, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.3 billion was from Software and Services performance obligations that were not yet satisfied as of March 29, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

- changed (2025-08-07):
[0000068505-25-000040:note_history:34]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,852 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,380 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,016 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 616 |  |  | 496 |  |  |  |  |  |
  (was, 2025-05-01, similarity 0.6468):
[0000068505-25-000024:note_history:34]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 129 |  |  | 141 |  |  |  |  |  |

- added (2025-08-07):
[0000068505-25-000040:note_history:35]
Revenue recognized during the three months ended June 28, 2025 which was previously included in Contract liabilities as of March 29, 2025 was $663 million, compared to $553 million of revenue recognized during the three months ended June 29, 2024 which was previously included in Contract liabilities as of March 30, 2024. Revenue recognized during the six months ended June 28, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $886 million, compared to $908 million recognized during the six months ended June 29, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $5 million was recognized during the three months ended June 28, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $11 million of reversals for the three months ended June 29, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $6 million was reversed during the six months ended June 28, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $18 million of reversals for the six months ended June 29, 2024.

- changed (2025-08-07):
[0000068505-25-000040:note_history:36]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended June 28, 2025 and June 29, 2024.
  (was, 2025-05-01, similarity 0.9058):
[0000068505-25-000024:note_history:36]
There were no material expected credit losses recorded on contract assets during each of the three months ended March 29, 2025 and March 30, 2024.

- added (2025-08-07):
[0000068505-25-000040:note_history:37]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 130 |  |  | 141 |  |  |  |  |  |

- changed (2025-08-07):
[0000068505-25-000040:note_history:38]
Amortization of contract cost assets was $13 million and $26 million for the three and six months ended June 28, 2025, respectively, and $12 million and $25 million for the three and six months ended June 29, 2024, respectively.
  (was, 2025-05-01, similarity 0.6115):
[0000068505-25-000024:note_history:38]
Amortization of contract cost assets was $13 million for the three months ended March 29, 2025 and March 30, 2024.

- removed (2025-08-07):
[0000068505-25-000024:note_history:39]
| (In millions) | March 29, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,770 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,288 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 1,983 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 556 |  |  | 496 |  |  |  |  |  |

- removed (2025-08-07):
[0000068505-25-000024:note_history:40]
Revenue recognized during the three months ended March 29, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $537 million, compared to $508 million of revenue recognized during the three months ended March 30, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $9 million was reversed during the three months ended March 29, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $12 million of reversals for the three months ended March 30, 2024, primarily driven by changes in the estimates of progress on system contracts.
