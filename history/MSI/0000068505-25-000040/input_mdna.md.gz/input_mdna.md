# MSI MD&A — 0000068505-25-000040


## mdna

[0000068505-25-000040:mdna:1]
[same as prior period, unchanged from 0000068505-25-000024:mdna:1]

[0000068505-25-000040:mdna:2]
This commentary should be read in conjunction with the condensed consolidated financial statements and related notes thereto of Motorola Solutions, Inc. (“Motorola Solutions,” the “Company,” “we,” “our,” or “us”) for the three and six months ended June 28, 2025 and June 29, 2024, as well as our consolidated financial statements and related notes thereto and management’s discussion and analysis of financial condition and results of operations in our Annual Report on Form 10-K for the year ended December 31, 2024 (the "Form 10-K").

[0000068505-25-000040:mdna:3]
[same as prior period, unchanged from 0000068505-25-000024:mdna:3]

[0000068505-25-000040:mdna:4]
[same as prior period, unchanged from 0000068505-25-000024:mdna:4]

[0000068505-25-000040:mdna:5]
[same as prior period, unchanged from 0000068505-25-000024:mdna:5]

[0000068505-25-000040:mdna:6]
[same as prior period, unchanged from 0000068505-25-000024:mdna:6]

[0000068505-25-000040:mdna:7]
[same as prior period, unchanged from 0000068505-25-000024:mdna:7]

[0000068505-25-000040:mdna:8]
[same as prior period, unchanged from 0000068505-25-000024:mdna:8]

[0000068505-25-000040:mdna:9]
[same as prior period, unchanged from 0000068505-25-000024:mdna:9]

[0000068505-25-000040:mdna:10]
Subsequent to the quarter end, with the acquisition of Silvus Technologies Holdings Inc. (“Silvus”), we will now report net sales from our principal product lines by combining the former LMR Communications and newly acquired Silvus under the new technology name Mission Critical Networks (MCN).

[0000068505-25-000040:mdna:11]
Second Quarter Financial Results

[0000068505-25-000040:mdna:12]
•Net sales were $2.8 billion in the second quarter of 2025 compared to $2.6 billion in the second quarter of 2024.

[0000068505-25-000040:mdna:13]
•Operating earnings were $692 million in the second quarter of 2025 compared to $644 million in the second quarter of 2024.

[0000068505-25-000040:mdna:14]
•Net earnings attributable to Motorola Solutions, Inc. was $513 million, or $3.04 per diluted common share, in the second quarter of 2025, compared to $443 million, or $2.60 per diluted common share, in the second quarter of 2024.

[0000068505-25-000040:mdna:15]
•Operating cash flow increased $221 million to $783 million in the first half of 2025 compared to $562 million in the first half of 2024.

[0000068505-25-000040:mdna:16]
•We repurchased $543 million of common stock and paid $364 million in dividends in the first half of 2025.

[0000068505-25-000040:mdna:17]
[same as prior period, unchanged from 0000068505-25-000024:mdna:17]

[0000068505-25-000040:mdna:18]
[same as prior period, unchanged from 0000068505-25-000024:mdna:18]

[0000068505-25-000040:mdna:19]
The current global tariff environment is complex and evolving. In early 2025, the United States initiated a series of trade actions which imposed new tariffs and increased existing tariffs on goods imported from various countries, contributing to a global trade landscape subject to evolving tariffs, import/export regulations, trade barriers and trade disputes. As a result, we continue to observe elevated volatility and uncertainty around the global supply chain.

[0000068505-25-000040:mdna:20]
[same as prior period, unchanged from 0000068505-25-000024:mdna:20]

[0000068505-25-000040:mdna:21]
[same as prior period, unchanged from 0000068505-25-000024:mdna:25]

[0000068505-25-000040:mdna:22]
On May 27, 2025, we entered into a purchase and sale agreement with Silvus Technologies Group LLC ("Seller") to acquire Silvus Technologies Holdings Inc. (“Silvus”), which subsequent to the quarter end closed on August 6, 2025, for $4.4 billion in upfront consideration, comprising $4.38 billion in cash, subject to customary adjustments for cash, net working capital, transaction expenses and indebtedness, and $20 million in restricted stock to certain employee equity holders. Additionally, under the terms of the transaction, the Seller will have the potential to earn earnout consideration following the achievement of certain financial targets of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn a catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be made in shares of common stock. Silvus designs and develops software-defined high-speed mobile ad-hoc network (MANET) technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. This business will be part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-25-000040:mdna:23]
| Segment | Technology | Acquisition | Description | Purchase Price | Date of Acquisition |
| Software and Services | Command Center | Theatro | Creator of AI and voice-powered communication and digital workflow software for frontline workers. | $173 million and share-based compensation of $5 million | March 6, 2025 |
| Software and Services | Command Center | RapidDeploy | Provider of cloud-native 911 solutions. | $241 million and share-based compensation of $6 million | February 21, 2025 |
| Software and Services | Command Center | 3tc Software | Provider of control room software solutions. | $23 million and share-based compensation of $4 million | October 29, 2024 |
| Software and Services | Command Center | Noggin | Provider of cloud-based business continuity planning, operational resilience and critical event management software. | $92 million and share-based compensation of $19 million | July 1, 2024 |
| Software and Services | Video Security and Access Control | Unnamed vehicle location and management solutions business | Provider of vehicle location and management solutions. | $132 million and share-based compensation of $3 million | July 1, 2024 |
| Products and Systems Integration | Video Security and Access Control | Silent Sentinel | Provider of specialized, long-range cameras. | $37 million | February 13, 2024 |

[0000068505-25-000040:mdna:24]
[same as prior period, unchanged from 0000068505-25-000024:mdna:28]

[0000068505-25-000040:mdna:25]
|  | Three Months Ended |  | Six Months Ended |
| (Dollars in millions, except per share amounts) | June 28, 2025 |  | % ofSales* |  | June 29, 2024 |  | % ofSales* |  | June 28, 2025 |  | % ofSales* |  | June 29, 2024 |  | % ofSales* |
| Net sales from products | $ | 1,533 |  |  |  |  | $ | 1,563 |  |  |  |  | $ | 2,980 |  |  |  |  | $ | 2,968 |  |  |  |
| Net sales from services | 1,232 |  |  |  |  | 1,065 |  |  |  |  | 2,313 |  |  |  |  | 2,049 |  |  |  |
| Net sales | 2,765 |  |  |  |  | 2,628 |  |  |  |  | 5,293 |  |  |  |  | 5,017 |  |  |  |
| Costs of products sales | 646 |  |  | 42.1 | % |  | 653 |  |  | 41.8 | % |  | 1,220 |  |  | 40.9 | % |  | 1,252 |  |  | 42.2 | % |
| Costs of services sales | 706 |  |  | 57.3 | % |  | 636 |  |  | 59.7 | % |  | 1,360 |  |  | 58.8 | % |  | 1,234 |  |  | 60.2 | % |
| Costs of sales | 1,352 |  |  |  |  | 1,289 |  |  |  |  | 2,580 |  |  |  |  | 2,486 |  |  |  |
| Gross margin | 1,413 |  |  | 51.1 | % |  | 1,339 |  |  | 51.0 | % |  | 2,713 |  |  | 51.3 | % |  | 2,531 |  |  | 50.4 | % |
| Selling, general and administrative expenses | 450 |  |  | 16.3 | % |  | 430 |  |  | 16.4 | % |  | 886 |  |  | 16.7 | % |  | 827 |  |  | 16.5 | % |
| Research and development expenditures | 231 |  |  | 8.4 | % |  | 220 |  |  | 8.4 | % |  | 464 |  |  | 8.8 | % |  | 437 |  |  | 8.7 | % |
| Other charges | 40 |  |  | 1.4 | % |  | 45 |  |  | 1.7 | % |  | 89 |  |  | 1.7 | % |  | 104 |  |  | 2.1 | % |
| Operating earnings | 692 |  |  | 25.0 | % |  | 644 |  |  | 24.5 | % |  | 1,274 |  |  | 24.1 | % |  | 1,163 |  |  | 23.2 | % |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense, net | (55) |  |  | (2.0) | % |  | (69) |  |  | (2.6) | % |  | (106) |  |  | (2.0) | % |  | (113) |  |  | (2.3) | % |
| Other, net | 43 |  |  | 1.6 | % |  | 5 |  |  | 0.2 | % |  | 59 |  |  | 1.1 | % |  | (560) |  |  | (11.2) | % |
| Total other expense | (12) |  |  | (0.4) | % |  | (64) |  |  | (2.4) | % |  | (47) |  |  | (0.9) | % |  | (673) |  |  | (13.4) | % |
| Net earnings before income taxes | 680 |  |  | 24.6 | % |  | 580 |  |  | 22.1 | % |  | 1,227 |  |  | 23.2 | % |  | 490 |  |  | 9.8 | % |
| Income tax expense | 165 |  |  | 6.0 | % |  | 135 |  |  | 5.1 | % |  | 280 |  |  | 5.3 | % |  | 83 |  |  | 1.7 | % |
| Net earnings | 515 |  |  | 18.6 | % |  | 445 |  |  | 16.9 | % |  | 947 |  |  | 17.9 | % |  | 407 |  |  | 8.1 | % |
| Less: Earnings attributable to non-controlling interests | 2 |  |  | 0.1 | % |  | 2 |  |  | 0.1 | % |  | 4 |  |  | 0.1 | % |  | 3 |  |  | 0.1 | % |
| Net earnings attributable to Motorola Solutions, Inc. | $ | 513 |  |  | 18.6 | % |  | $ | 443 |  |  | 16.8 | % |  | $ | 943 |  |  | 17.8 | % |  | $ | 404 |  |  | 8.0 | % |
| Earnings per diluted common share | $ | 3.04 |  |  |  |  | $ | 2.60 |  |  |  |  | $ | 5.57 |  |  |  |  | $ | 2.37 |  |  |  |

[0000068505-25-000040:mdna:26]
[same as prior period, unchanged from 0000068505-25-000024:mdna:30]

[0000068505-25-000040:mdna:27]
30

[0000068505-25-000040:mdna:28]
Results of Operations—Three months ended June 28, 2025 compared to three months ended June 29, 2024

[0000068505-25-000040:mdna:29]
The results of operations for the second quarter of 2025 are not necessarily indicative of the operating results to be expected for the full year. Historically, we have experienced higher revenues in the fourth quarter as compared to the rest of the quarters of our fiscal year as a result of the purchasing patterns of our customers.

[0000068505-25-000040:mdna:30]
[same as prior period, unchanged from 0000068505-25-000024:mdna:34]

[0000068505-25-000040:mdna:31]
[same as prior period, unchanged from 0000068505-25-000024:mdna:35]

[0000068505-25-000040:mdna:32]
[same as prior period, unchanged from 0000068505-25-000024:mdna:36]

[0000068505-25-000040:mdna:33]
[same as prior period, unchanged from 0000068505-25-000024:mdna:37]

[0000068505-25-000040:mdna:34]
[same as prior period, unchanged from 0000068505-25-000024:mdna:38]

[0000068505-25-000040:mdna:35]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Operating earnings | $ | 363 |  |  | $ | 329 |  |  | $ | 692 |  |  | $ | 379 |  |  | $ | 265 |  |  | $ | 644 |  |
| Operating margins | 22.0 | % |  | 29.6 | % |  | 25.0 | % |  | 22.9 | % |  | 27.3 | % |  | 24.5 | % |

[0000068505-25-000040:mdna:36]
[same as prior period, unchanged from 0000068505-25-000024:mdna:40]

[0000068505-25-000040:mdna:37]
The Products and Systems Integration segment’s net sales represented 60% of our net sales in the second quarter of 2025 and 63% in the second quarter of 2024. The Software and Services segment’s net sales represented 40% of our net sales in the second quarter of 2025 and 37% in the second quarter of 2024.

[0000068505-25-000040:mdna:38]
Net sales increased $137 million, or 5%, in the second quarter of 2025 compared to the second quarter of 2024. The $142 million, or 15%, increase in net sales within the Software and Services segment was driven by an increase of 15% in the North America region and an increase of 13% in the International region. The $5 million decrease in net sales within the Products and Systems Integration segment was driven by a decrease of $11 million, or 3%, in the International region, partially offset by a $6 million increase in the North America region. Net sales includes:

[0000068505-25-000040:mdna:39]
•an increase in the Software and Services segment, inclusive of $39 million of revenue from acquisitions, driven by an increase in LMR services, Video and Command Center;

[0000068505-25-000040:mdna:40]
•the Products and Systems Integration segment was flat, driven by a decrease in LMR, partially offset by an increase in Video; and

[0000068505-25-000040:mdna:41]
•inclusive of $9 million from favorable currency rates.

[0000068505-25-000040:mdna:42]
[same as prior period, unchanged from 0000068505-25-000024:mdna:46]

[0000068505-25-000040:mdna:43]
•a 6% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in Video, LMR and Command Center; and

[0000068505-25-000040:mdna:44]
•a 4% increase in the International region, inclusive of revenue from acquisitions, driven by an increase in LMR.

[0000068505-25-000040:mdna:45]
31

[0000068505-25-000040:mdna:46]
[same as prior period, unchanged from 0000068505-25-000024:mdna:49]

[0000068505-25-000040:mdna:47]
The Products and Systems Integration segment was flat driven by the following:

[0000068505-25-000040:mdna:48]
•$7 million, or 1%, decrease in LMR, driven by both the the International and North America regions; partially offset by

[0000068505-25-000040:mdna:49]
•$2 million, or 1%, growth in Video, driven by the North America region, partially offset by the International region; and

[0000068505-25-000040:mdna:50]
•inclusive of $4 million from favorable currency rates.

[0000068505-25-000040:mdna:51]
[same as prior period, unchanged from 0000068505-25-000024:mdna:54]

[0000068505-25-000040:mdna:52]
The 15% increase in the Software and Services segment was driven by the following:

[0000068505-25-000040:mdna:53]
•$71 million, or 12%, growth in LMR services, driven by the North America and International regions;

[0000068505-25-000040:mdna:54]
•$45 million, or 25%, growth in Video, inclusive of revenue from acquisitions, driven by the North America and International regions;

[0000068505-25-000040:mdna:55]
•$26 million, or 12%, growth in Command Center, inclusive of revenue from acquisitions, driven by the North America region; and

[0000068505-25-000040:mdna:56]
•inclusive of $5 million from favorable currency rates.

[0000068505-25-000040:mdna:57]
[same as prior period, unchanged from 0000068505-25-000024:mdna:60]

[0000068505-25-000040:mdna:58]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 876 |  |  | $ | 874 |  |  | — | % |
| Gross margin from Software and Services | 537 |  |  | 465 |  |  | 15 | % |
| Gross margin | $ | 1,413 |  |  | $ | 1,339 |  |  | 6 | % |

[0000068505-25-000040:mdna:59]
Gross margin was 51.1% of net sales in the second quarter of 2025 compared to 51.0% in the second quarter of 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000040:mdna:60]
•a 0.4% increase in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, primarily driven by higher sales partially offset by acquisitions; and

[0000068505-25-000040:mdna:61]
•a 0.3% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, primarily driven by lower direct material costs, despite higher tariffs.

[0000068505-25-000040:mdna:62]
[same as prior period, unchanged from 0000068505-25-000024:mdna:65]

[0000068505-25-000040:mdna:63]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 355 |  |  | $ | 342 |  |  | 4 | % |
| SG&A expenses from Software and Services | 95 |  |  | 88 |  |  | 8 | % |
| SG&A expenses | $ | 450 |  |  | $ | 430 |  |  | 5 | % |

[0000068505-25-000040:mdna:64]
SG&A expenses increased 5% in the second quarter of 2025 compared to the second quarter of 2024 primarily driven by:

[0000068505-25-000040:mdna:65]
•a $13 million, or 4%, increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share based compensation and investments in video; and

[0000068505-25-000040:mdna:66]
•a $7 million, or 8%, increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses.

[0000068505-25-000040:mdna:67]
SG&A expenses were 16.3% of net sales in the second quarter of 2025 compared to 16.4% of net sales in the second quarter of 2024.

[0000068505-25-000040:mdna:68]
[same as prior period, unchanged from 0000068505-25-000024:mdna:88]

[0000068505-25-000040:mdna:69]
[same as prior period, unchanged from 0000068505-25-000024:mdna:71]

[0000068505-25-000040:mdna:70]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 143 |  |  | $ | 140 |  |  | 2 | % |
| R&D expenditures from Software and Services | 88 |  |  | 80 |  |  | 10 | % |
| R&D expenditures | $ | 231 |  |  | $ | 220 |  |  | 5 | % |

[0000068505-25-000040:mdna:71]
R&D expenditures increased $11 million, or 5%, in the second quarter of 2025 compared to the second quarter of 2024 primarily driven by higher employee incentive costs, including investments in video and share based compensation, and higher expenses associated with acquired businesses. R&D expenditures were 8.4% of net sales in both the second quarter of 2025 and in the second quarter of 2024.

[0000068505-25-000040:mdna:72]
[same as prior period, unchanged from 0000068505-25-000024:mdna:77]

[0000068505-25-000040:mdna:73]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Other charges from Products and Systems Integration | $ | 15 |  |  | $ | 13 |  |
| Other charges from Software and Services | 25 |  |  | 32 |  |
| Other charges | $ | 40 |  |  | $ | 45 |  |

[0000068505-25-000040:mdna:74]
Other charges decreased $5 million in the second quarter of 2025 compared to the second quarter of 2024. The decrease was primarily driven by:

[0000068505-25-000040:mdna:75]
•$10 million of gains on the Hytera litigation for the amounts recovered through legal proceedings due to theft of our trade secrets in the second quarter of 2025 that did not occur in the second quarter of 2024; and

[0000068505-25-000040:mdna:76]
•$2 million of acquisition related transaction fees in the second quarter of 2025 compared to $4 million of acquisition related transaction fees in the second quarter of 2024; partially offset by

[0000068505-25-000040:mdna:77]
•$39 million of intangible amortization expense in the second quarter of 2025 compared to $36 million of intangible amortization expense in the second quarter of 2024; and

[0000068505-25-000040:mdna:78]
•$8 million of reorganization of business expenses in the second quarter of 2025 compared to $4 million of reorganization of business expenses in the second quarter of 2024.

[0000068505-25-000040:mdna:79]
[same as prior period, unchanged from 0000068505-25-000024:mdna:83]

[0000068505-25-000040:mdna:80]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Operating earnings from Products and Systems Integration | $ | 363 |  |  | $ | 379 |  |
| Operating earnings from Software and Services | 329 |  |  | 265 |  |
| Operating earnings | $ | 692 |  |  | $ | 644 |  |

[0000068505-25-000040:mdna:81]
Operating earnings increased $48 million, or 7%, in the second quarter of 2025 compared to the second quarter of 2024. The increase in Operating earnings was due to:

[0000068505-25-000040:mdna:82]
•a $64 million increase in the Software and Services segment, primarily driven by higher sales and improved operating leverage, partially offset by higher expenses associated with acquired businesses and higher employee incentive costs, including investments in video and share based compensation; partially offset by

[0000068505-25-000040:mdna:83]
•a $16 million decrease in the Products and Systems Integration segment, primarily driven by decreased sales, higher employee incentive costs, including share based compensation and investments in video, and higher intangible amortization expenses, partially offset by lower direct material costs, despite higher tariffs, and a gain on the Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets.

[0000068505-25-000040:mdna:84]
[same as prior period, unchanged from 0000068505-25-000024:mdna:89]

[0000068505-25-000040:mdna:85]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Interest expense, net | $ | (55) |  |  | $ | (69) |  |

[0000068505-25-000040:mdna:86]
The $14 million decrease in Interest expense, net in the second quarter of 2025 compared to the second quarter of 2024 was primarily driven by interest accruals related to audits with tax authorities in foreign jurisdictions in 2024.

[0000068505-25-000040:mdna:87]
[same as prior period, unchanged from 0000068505-25-000024:mdna:92]

[0000068505-25-000040:mdna:88]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Other, net | $ | 43 |  |  | $ | 5 |  |

[0000068505-25-000040:mdna:89]
The $38 million increase in Other, net in the second quarter of 2025 compared to the second quarter of 2024 was primarily driven by:

[0000068505-25-000040:mdna:90]
•a $34 million gain on derivatives in the second quarter of 2025 compared to a $5 million loss on derivatives in the second quarter of 2024;

[0000068505-25-000040:mdna:91]
•an $18 million gain on fair value adjustments to equity investments in the second quarter of 2025 compared to a $11 million loss on fair value adjustments to equity investments in the second quarter of 2024; and

[0000068505-25-000040:mdna:92]
•an $11 million loss on assessments of uncertain tax positions in the second quarter of 2024 that did not occur in the second quarter of 2025; partially offset by

[0000068505-25-000040:mdna:93]
•a $42 million loss on foreign currency in the second quarter of 2025 compared to a $3 million gain on foreign currency in the second quarter of 2024.

[0000068505-25-000040:mdna:94]
[same as prior period, unchanged from 0000068505-25-000024:mdna:98]

[0000068505-25-000040:mdna:95]
|  | Three Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Income tax expense | $ | 165 |  |  | $ | 135 |  |

[0000068505-25-000040:mdna:96]
Income tax expense increased by $30 million in the second quarter of 2025 compared to the second quarter of 2024, resulting in an effective tax rate of 24%. Our effective tax rate for the three months ended June 28, 2025 of 24% was higher than the effective tax rate for the three months ended June 29, 2024 of 23%, primarily due to tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024 and lower excess tax benefits of share-based compensation in 2025.

[0000068505-25-000040:mdna:97]
Subsequent to quarter end, on July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law and included tax cut extensions and modifications to the international tax framework and corporate income tax deductions. We are currently evaluating the potential effects of these changes on our financial statements, inclusive of our income tax provision, income tax payable, and deferred tax asset balances. We will recognize the effects of this legislation in accordance with the enactment and effective dates of the applicable provisions.

[0000068505-25-000040:mdna:98]
Results of Operations—Six months ended June 28, 2025 compared to Six months ended June 29, 2024

[0000068505-25-000040:mdna:99]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales by region: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Net sales by major products and services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Operating earnings | $ | 715 |  |  | $ | 559 |  |  | $ | 1,274 |  |  | $ | 689 |  |  | $ | 474 |  |  | $ | 1,163 |  |
| Operating margins | 22.4 | % |  | 26.7 | % |  | 24.1 | % |  | 21.9 | % |  | 25.4 | % |  | 23.2 | % |

[0000068505-25-000040:mdna:100]
Net Sales

[0000068505-25-000040:mdna:101]
The Products and Systems Integration segment's net sales represented 60% of our net sales in the first half of 2025 and 63% in the first half of 2024. Net sales from the Software and Services segment represented 40% of our net sales in the first half of 2025 and 37% in the first half of 2024.

[0000068505-25-000040:mdna:102]
Net sales increased $276 million, or 6%, in the first half of 2025 compared to the first half of 2024. The $226 million, or 12%, increase in net sales within the Software and Services segment was driven by an increase of 13% in the North America region, and an increase of 10% in the International region. The $50 million, or 2%, increase in net sales within the Products and Systems Integration segment was driven by an increase of 4% in the North America region, partially offset by a decrease of 6% in the International region. Net sales includes:

[0000068505-25-000040:mdna:103]
•an increase in Software and Services, inclusive of $71 million of revenue from acquisitions, driven by an increase in Video, LMR services and Command Center;

[0000068505-25-000040:mdna:104]
•an increase in the Products and Systems Integration segment, driven by an increase in LMR; and

[0000068505-25-000040:mdna:105]
•inclusive of $17 million from unfavorable currency rates.

[0000068505-25-000040:mdna:106]
Regional results include:

[0000068505-25-000040:mdna:107]
•a 7% increase in the North America region, inclusive of revenue from acquisitions, driven by an increase in LMR, Video and Command Center; and

[0000068505-25-000040:mdna:108]
•the International region was flat, inclusive of revenue from acquisitions, driven by an increase in Command Center and Video, partially offset by LMR.

[0000068505-25-000040:mdna:109]
Products and Systems Integration

[0000068505-25-000040:mdna:110]
The 2% increase in the Products and Systems Integration segment was driven by the following:

[0000068505-25-000040:mdna:111]
•$51 million, or 2% growth in LMR, driven by the North America region, partially offset by the International region; partially offset by

[0000068505-25-000040:mdna:112]
•$1 million decrease in Video, driven by the International region, partially offset by North America region; and

[0000068505-25-000040:mdna:113]
•inclusive of $11 million from unfavorable currency rates.

[0000068505-25-000040:mdna:114]
Software and Services

[0000068505-25-000040:mdna:115]
The 12% increase in the Software and Services segment was driven by the following:

[0000068505-25-000040:mdna:116]
•$91 million, or 26% growth in Video, inclusive of revenue from acquisitions, driven by both the North America and International regions;

[0000068505-25-000040:mdna:117]
•$91 million, or 8% growth in LMR services, driven by both the North America and International regions;

[0000068505-25-000040:mdna:118]
•$44 million, or 12% growth in Command Center, inclusive of revenue from acquisitions, driven by both the North America and International regions; and

[0000068505-25-000040:mdna:119]
•inclusive of $6 million from unfavorable currency rates.

[0000068505-25-000040:mdna:120]
Gross Margin

[0000068505-25-000040:mdna:121]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| Gross margin from Products and Systems Integration | $ | 1,728 |  |  | $ | 1,649 |  |  | 5 | % |
| Gross margin from Software and Services | 985 |  |  | 882 |  |  | 12 | % |
| Gross margin | $ | 2,713 |  |  | $ | 2,531 |  |  | 7 | % |

[0000068505-25-000040:mdna:122]
Gross margin was 51.3% of net sales in the first half of 2025 compared to 50.4% in the first half of 2024. The primary drivers of this increase in gross margin as a percentage of net sales were:

[0000068505-25-000040:mdna:123]
•a 1.6% increase in gross margin as a percentage of net sales in the Products and Systems Integration segment, primarily driven by favorable mix and lower direct material costs, despite higher tariffs; partially offset by

[0000068505-25-000040:mdna:124]
•a 0.2% decrease in gross margin as a percentage of net sales in the Software and Services segment, inclusive of acquisitions, driven by higher expenses associated with acquired businesses.

[0000068505-25-000040:mdna:125]
Selling, General and Administrative ("SG&A") Expenses

[0000068505-25-000040:mdna:126]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| SG&A expenses from Products and Systems Integration | $ | 696 |  |  | $ | 654 |  |  | 6 | % |
| SG&A expenses from Software and Services | 190 |  |  | 173 |  |  | 10 | % |
| SG&A expenses | $ | 886 |  |  | $ | 827 |  |  | 7 | % |

[0000068505-25-000040:mdna:127]
SG&A expenses increased 7% in the first half of 2025 compared to the first half of 2024 primarily driven by:

[0000068505-25-000040:mdna:128]
•a $42 million, or 6%, increase in Products and Systems Integration SG&A expenses primarily due to higher employee incentive costs, including share based compensation and investments in video, and higher expenses related to legal matters, including Hytera related legal expenses; and

[0000068505-25-000040:mdna:129]
•a $17 million, or 10%, increase in Software and Services SG&A expenses primarily due to higher expenses associated with acquired businesses.

[0000068505-25-000040:mdna:130]
SG&A expenses were 16.7% of net sales in the first half of 2025 compared to 16.5% of net sales in the first half of 2024.

[0000068505-25-000040:mdna:131]
Research and Development ("R&D") Expenditures

[0000068505-25-000040:mdna:132]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |  | % Change |
| R&D expenditures from Products and Systems Integration | $ | 285 |  |  | $ | 276 |  |  | 3 | % |
| R&D expenditures from Software and Services | 179 |  |  | 161 |  |  | 11 | % |
| R&D expenditures | $ | 464 |  |  | $ | 437 |  |  | 6 | % |

[0000068505-25-000040:mdna:133]
R&D expenditures increased 6% in the first half of 2025 compared to the first half of 2024 primarily driven by:

[0000068505-25-000040:mdna:134]
•an $18 million, or 11%, increase in Software and Services R&D expenditures primarily due to higher employee incentive costs, including investments in video and share based compensation, and higher expenses associated with acquired businesses; and

[0000068505-25-000040:mdna:135]
•a $9 million, or 3%, increase in Products and Systems Integration R&D expenditures primarily due to higher employee incentive costs, including investments in video.

[0000068505-25-000040:mdna:136]
R&D expenditures were 8.8% of net sales in the first half of 2025 compared to 8.7% of net sales in the first half of 2024.

[0000068505-25-000040:mdna:137]
Other Charges

[0000068505-25-000040:mdna:138]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Other charges from Products and Systems Integration | $ | 32 |  |  | $ | 30 |  |
| Other charges from Software and Services | 57 |  |  | 74 |  |
| Other charges | $ | 89 |  |  | $ | 104 |  |

[0000068505-25-000040:mdna:139]
Other charges decreased by $15 million in the first half of 2025 compared to the first half of 2024. The decrease was driven primarily by:

[0000068505-25-000040:mdna:140]
•$20 million of gains on the Hytera litigation for the amounts recovered through legal proceedings due to theft of our trade secrets in the first half of 2025 that did not occur in the first half of 2024; and

[0000068505-25-000040:mdna:141]
•$4 million of operating lease asset impairments in the first half of 2024 that did not occur in the first half of 2025; partially offset by

[0000068505-25-000040:mdna:142]
•$20 million of reorganization of business expense in the first half of 2025 compared to $11 million in the first half of 2024.

[0000068505-25-000040:mdna:143]
Operating Earnings

[0000068505-25-000040:mdna:144]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Operating earnings from Products and Systems Integration | $ | 715 |  |  | $ | 689 |  |
| Operating earnings from Software and Services | 559 |  |  | 474 |  |
| Operating earnings | $ | 1,274 |  |  | $ | 1,163 |  |

[0000068505-25-000040:mdna:145]
Operating earnings increased $111 million, or 10%, in the first half of 2025 compared to the first half of 2024. The increase in Operating earnings was due to:

[0000068505-25-000040:mdna:146]
•an $85 million increase in the Software and Services segment, primarily driven by higher sales and a reduction of intangible amortization expenses, partially offset by higher expenses associated with acquired businesses, higher employee incentive costs, including investments in video and share based compensation, and increased reorganization expenses; and

[0000068505-25-000040:mdna:147]
•a $26 million increase in the Products and Systems Integration segment, primarily driven by higher sales, a gain on the Hytera litigation for amounts recovered through legal proceedings due to the theft of our trade secrets, favorable mix, and lower direct material costs, despite higher tariffs, partially offset by higher employee incentive costs, including share based compensation and investments in video, higher expenses related to legal matters, including Hytera related legal expenses, and increased intangible amortization expenses.

[0000068505-25-000040:mdna:148]
Interest Expense, net

[0000068505-25-000040:mdna:149]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Interest expense, net | $ | (106) |  |  | $ | (113) |  |

[0000068505-25-000040:mdna:150]
The $7 million decrease in Interest expense, net in the first half of 2025 compared to the first half of 2024 was primarily driven by interest accruals related to audits with tax authorities in foreign jurisdictions in 2024.

[0000068505-25-000040:mdna:151]
Other, net

[0000068505-25-000040:mdna:152]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Other, net | $ | 59 |  |  | $ | (560) |  |

[0000068505-25-000040:mdna:153]
The $619 million increase in Other, net in the first half of 2025 compared to the first half of 2024 was primarily driven by:

[0000068505-25-000040:mdna:154]
•a $585 million loss from the extinguishment of the $1.0 billion of 1.75% senior convertible notes issued to Silver Lake Partners and scheduled to mature in September 2024 (the "Silver Lake Convertible Debt") which was recognized in the first half of 2024;

[0000068505-25-000040:mdna:155]
•a $48 million gain on derivative instruments in the first half of 2025 compared to a $15 million loss on derivative instruments in the first half of 2024;

[0000068505-25-000040:mdna:156]
•a $13 million gain on fair value adjustments to equity investments in the first half of 2025 compared to a $13 million loss on fair value adjustments to equity investments in the first half of 2024; and

[0000068505-25-000040:mdna:157]
•an $11 million loss on assessments of uncertain tax positions in the first half of 2024 that did not occur in the first half of 2025; partially offset by

[0000068505-25-000040:mdna:158]
•a $62 million loss on foreign currency in the first half of 2025 compared to a $4 million gain on foreign currency in the first half of 2024.

[0000068505-25-000040:mdna:159]
Effective Tax Rate

[0000068505-25-000040:mdna:160]
|  | Six Months Ended |
| (In millions) | June 28, 2025 |  | June 29, 2024 |
| Income tax expense | $ | 280 |  |  | $ | 83 |  |

[0000068505-25-000040:mdna:161]
Income tax expense increased by $197 million in the first half of 2025 compared to the first half of 2024, resulting in an effective tax rate of 23%. Our effective tax rate of 23% for the six months ended June 28, 2025 was higher than the effective tax rate for the six months ended June 29, 2024 of 17%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.

[0000068505-25-000040:mdna:162]
Subsequent to quarter end, on July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law and included tax cut extensions and modifications to the international tax framework and corporate income tax deductions. We are currently evaluating the potential effects of these changes on our financial statements, inclusive of our income tax provision, income tax payable, and deferred tax asset balances. We will recognize the effects of this legislation in accordance with the enactment and effective dates of the applicable provisions.

[0000068505-25-000040:mdna:163]
[same as prior period, unchanged from 0000068505-25-000024:mdna:101]

[0000068505-25-000040:mdna:164]
During the second quarter of 2025, we recorded net reorganization of business charges of $14 million, consisting of $8 million of charges in Other charges and $6 million of charges in Cost of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $13 million related to employee separation costs and $1 million related to exit costs.

[0000068505-25-000040:mdna:165]
During the first half of 2025, we recorded net reorganization of business charges of $31 million, including $20 million of charges recorded within Other charges and $11 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $33 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000040:mdna:166]
During the second quarter of 2024, we recorded net reorganization of business charges of $4 million, including $4 million of charges recorded in Other charges in our Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $10 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals and $4 million of reversals for exit costs that are no longer needed.

[0000068505-25-000040:mdna:167]
During the first half of 2024, we recorded net reorganization of business charges of $14 million, including $11 million of charges recorded within Other charges and $3 million of charges in Costs of sales in our Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $22 million related to employee separation costs, partially offset by $4 million of reversals for exit accruals no longer needed and $4 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000040:mdna:168]
[same as prior period, unchanged from 0000068505-25-000024:mdna:104]

[0000068505-25-000040:mdna:169]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Products and Systems Integration | $ | 10 |  |  | $ | 6 |  |  | $ | 22 |  |  | $ | 14 |  |
| Software and Services | 4 |  |  | (2) |  |  | 9 |  |  | — |  |
|  | $ | 14 |  |  | $ | 4 |  |  | $ | 31 |  |  | $ | 14 |  |

[0000068505-25-000040:mdna:170]
Cash payments for employee severance in connection with the reorganization of business plans were $33 million in the first half of 2025 and $17 million in the first half of 2024. The reorganization of business accrual at June 28, 2025 was $24 million related to employee separation costs that are expected to be paid primarily within one year.

[0000068505-25-000040:mdna:171]
At January 1, 2025, we had an accrual of $1 million for exit costs related to our exit of the ESN contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in our Condensed Consolidated Balance Sheets at June 28, 2025, and are expected to be paid within one year.

[0000068505-25-000040:mdna:172]
[same as prior period, unchanged from 0000068505-25-000024:mdna:108]

[0000068505-25-000040:mdna:173]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| Cash flows provided by (used for): |  |  |  |
| Operating activities | $ | 783 |  |  | $ | 562 |  |
| Investing activities | (537) |  |  | (118) |  |
| Financing activities | 778 |  |  | (743) |  |
| Effect of exchange rates on cash and cash equivalents | 80 |  |  | (25) |  |
| Decrease in cash and cash equivalents | $ | 1,104 |  |  | $ | (324) |  |

[0000068505-25-000040:mdna:174]
[same as prior period, unchanged from 0000068505-25-000024:mdna:110]

[0000068505-25-000040:mdna:175]
At June 28, 2025, $2.8 billion of the $3.2 billion cash and cash equivalents balance was held in the U.S. and $367 million was held in other countries.

[0000068505-25-000040:mdna:176]
[same as prior period, unchanged from 0000068505-25-000024:mdna:112]

[0000068505-25-000040:mdna:177]
The increase in cash flows provided by operating activities from the first half of 2024 to the first half of 2025 was driven primarily by higher earnings, net of non-cash charges, and improved working capital.

[0000068505-25-000040:mdna:178]
[same as prior period, unchanged from 0000068505-25-000024:mdna:114]

[0000068505-25-000040:mdna:179]
The increase in cash flows used for investing activities in the first half of 2025 compared to the first half of 2024 was primarily due to an increase in cash used for acquisitions and investments.

[0000068505-25-000040:mdna:180]
[same as prior period, unchanged from 0000068505-25-000024:mdna:116]

[0000068505-25-000040:mdna:181]
The increase in cash flows provided by financing activities in the first half of 2025 compared to the cash flows used for financing activities in the first half of 2024 was primarily driven by (see also further discussion in the "Debt," "Share Repurchase Program" and "Dividends" sections below in this Part I, Item 2 of this Form 10-Q):

[0000068505-25-000040:mdna:182]
•$1.3 billion decrease in repayment of debt driven by the 7.5% senior notes repaid in the first half of 2025 compared to the repurchase of Silver Lake Convertible Debt in the first half of 2024; and

[0000068505-25-000040:mdna:183]
•$695 million increase in net proceeds from the issuance of debt in the first half of 2025 driven by the issuance of our 4.85% senior notes due 2030 ("2030 Notes"), 5.2% senior notes due 2032 ("2032 Notes") and our 5.55% senior notes due 2035 ("2035 Notes") compared to the the issuance of debt in the first half of 2024 driven by the issuance of our 5.0% senior notes due 2029 and 5.4% senior notes due 2034; partially offset by

[0000068505-25-000040:mdna:184]
•$433 million increase in share repurchases in the first half of 2025 compared to the first half of 2024;

[0000068505-25-000040:mdna:185]
•$38 million increase in the payment of dividends in the first half of 2025 compared to the first half of 2024; and

[0000068505-25-000040:mdna:186]
•$38 million increase in cash used for the issuance of common stock primarily driven by an increase in tax withholdings and a decrease in net proceeds from our employee stock option and employee stock purchase plans in the first half of 2025 compared to the first half of 2024.

[0000068505-25-000040:mdna:187]
[same as prior period, unchanged from 0000068505-25-000024:mdna:123]

[0000068505-25-000040:mdna:188]
The following table summarizes the proceeds received from sales of accounts receivable and long-term customer financing receivables for the three and six months ended June 28, 2025 and June 29, 2024:

[0000068505-25-000040:mdna:189]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Long-term receivables sales proceeds | $ | 89 |  |  | $ | 17 |  |  | 113 |  |  | 27 |  |

[0000068505-25-000040:mdna:190]
[same as prior period, unchanged from 0000068505-25-000024:mdna:126]

[0000068505-25-000040:mdna:191]
We had outstanding debt of $7.7 billion at June 28, 2025, of which $70 million was current. We had outstanding debt of $6.0 billion at December 31, 2024, of which $322 million was current.

[0000068505-25-000040:mdna:192]
On June 16, 2025, we issued $600 million of 4.85% senior notes due 2030 (“2030 Notes”), $500 million of 5.2% senior notes due 2032 (“2032 Notes”), $900 million of 5.55% senior notes due 2035 (“2035 Notes”). We recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-25-000040:mdna:193]
On May 27, 2025, we obtained financing commitments for $2.5 billion of senior unsecured delayed draw term loan facilities, comprised of $1.75 billion 364-day facility and a $750 million three year facility. Upon issuance of 2030 Notes, 2032 Notes, and 2035 Notes, the financing commitments under the 364-day facility were reduced to $750 million. Subsequent to the quarter, on July 21, 2025 we entered into credit agreements for a 750 million 364-day delayed draw term loan and a $750 million three year delayed draw term loan, and on August 6, 2025 we borrowed $750 million under the 364-day delayed draw term loan and $750 million under the three year delayed draw term loan to fund a portion of the acquisition of Silvus.

[0000068505-25-000040:mdna:194]
On April 25, 2025, we entered into a $2.25 billion syndicated, unsecured revolving credit facility scheduled to mature in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced our $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at our option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if our credit rating changes. We must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. We were in compliance with our financial covenants as of June 28, 2025.

[0000068505-25-000040:mdna:195]
We have an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which we may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. As of June 28, 2025 we had no outstanding debt under the commercial paper program. Subsequent to the quarter, we utilized our commercial paper program as a source of short-term liquidity to partially fund the acquisition of Silvus.

[0000068505-25-000040:mdna:196]
[same as prior period, unchanged from 0000068505-25-000024:mdna:132]

[0000068505-25-000040:mdna:197]
[same as prior period, unchanged from 0000068505-25-000024:mdna:133]

[0000068505-25-000040:mdna:198]
During the three and six months ended June 28, 2025, we repurchased approximately 0.6 million and 1.3 million shares at an average price of $414.42 and $427.74 per share for an aggregate amount of $218 million and $543 million, excluding transaction costs and excise tax. As of June 28, 2025, we had used approximately $16.3 billion of the share repurchase authority to repurchase shares, leaving $1.7 billion of authority available for future repurchases.

[0000068505-25-000040:mdna:199]
[same as prior period, unchanged from 0000068505-25-000024:mdna:135]

[0000068505-25-000040:mdna:200]
During the second quarter of 2025 we paid $182 million in cash dividends to holders of our common stock. Subsequent to the quarter, we paid an additional $182 million in cash dividends to holders of our common stock.

[0000068505-25-000040:mdna:201]
[same as prior period, unchanged from 0000068505-25-000024:mdna:137]

[0000068505-25-000040:mdna:202]
[same as prior period, unchanged from 0000068505-25-000024:mdna:138]

[0000068505-25-000040:mdna:203]
We do not anticipate a material decrease to net future cash flows generated from operations. We expect to use our available cash, investments, and debt facilities to support and invest in our business. This includes investing in our existing products and technologies, seeking new acquisition opportunities related to our strategic growth initiatives and returning cash to shareholders through common stock cash dividend payments (subject to the discretion of our Board of Directors) and share repurchases. Subsequent to the quarter, we used a portion of our cash and cash equivalents on hand to partially fund the acquisition of Silvus.

[0000068505-25-000040:mdna:204]
40

[0000068505-25-000040:mdna:205]
Subsequent to entering into a purchase and sale agreement with Silvus, our corporate credit ratings were reaffirmed by the major rating agencies. Fitch Ratings and S&P Global Ratings reaffirmed our BBB ratings, and Moody's Investors Service reaffirmed our Baa2 rating.

[0000068505-25-000040:mdna:206]
[same as prior period, unchanged from 0000068505-25-000024:mdna:140]

[0000068505-25-000040:mdna:207]
We had outstanding commitments to provide long-term financing to third parties totaling $171 million at June 28, 2025, compared to $105 million at December 31, 2024.

[0000068505-25-000040:mdna:208]
[same as prior period, unchanged from 0000068505-25-000024:mdna:142]

[0000068505-25-000040:mdna:209]
[same as prior period, unchanged from 0000068505-25-000024:mdna:143]
