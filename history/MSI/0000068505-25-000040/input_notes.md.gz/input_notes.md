# MSI notes — 0000068505-25-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000068505-25-000040:notes:1]
Basis of Presentation
The condensed consolidated financial statements as of June 28, 2025 and for the three and six months ended June 28, 2025 and June 29, 2024 include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to state fairly the Condensed Consolidated Balance Sheets, Statements of Operations, Statements of Comprehensive Income, Statements of Stockholders' Equity, and Statements of Cash Flows of Motorola Solutions, Inc. (“Motorola Solutions” or the “Company”) for all periods presented.

[0000068505-25-000040:notes:2]
[same as prior period, unchanged from 0000068505-25-000024:notes:2]

[0000068505-25-000040:notes:3]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with United States generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2024 (the "Form 10-K"). The results of operations for the three and six months ended June 28, 2025 are not necessarily indicative of the operating results to be expected for the full year.

[0000068505-25-000040:notes:4]
[same as prior period, unchanged from 0000068505-25-000024:notes:4]

[0000068505-25-000040:notes:5]
[same as prior period, unchanged from 0000068505-25-000024:notes:5]

[0000068505-25-000040:notes:6]
[same as prior period, unchanged from 0000068505-25-000024:notes:6]

[0000068505-25-000040:notes:7]
[same as prior period, unchanged from 0000068505-25-000024:notes:7]

[0000068505-25-000040:notes:8]
[same as prior period, unchanged from 0000068505-25-000024:notes:8]

[0000068505-25-000040:notes:9]
[same as prior period, unchanged from 0000068505-25-000024:notes:9]

[0000068505-25-000040:notes:10]
Subsequent to the quarter end, with the acquisition of Silvus Technologies Holdings Inc. (“Silvus”), the Company will now report net sales from its principal product lines by combining the former LMR Communications and newly acquired Silvus under the new technology name Mission Critical Networks (MCN).

[0000068505-25-000040:notes:11]
[same as prior period, unchanged from 0000068505-25-000024:notes:10]

[0000068505-25-000040:notes:12]
On May 27, 2025, the Company entered into a purchase and sale agreement with Silvus Technologies Group LLC ("Seller") to acquire Silvus Technologies Holdings Inc. (“Silvus”), which subsequent to the quarter end closed on August 6, 2025, for $4.4 billion in upfront consideration, comprising $4.38 billion in cash, subject to customary adjustments for cash, net working capital, transaction expenses and indebtedness, and $20 million in restricted stock to certain employee equity holders. Additionally, under the terms of the transaction, the Seller will have the potential to earn earnout consideration following the achievement of certain financial targets of up to $150 million for the annual period from July 5, 2026 through July 3, 2027 and up to $450 million for the annual period from July 4, 2027 through July 1, 2028 (with the potential to earn a catch-up earnout consideration based on performance in the annual period from July 4, 2027 through July 1, 2028 if the maximum earnout for the annual period from July 5, 2026 through July 3, 2027 is not earned). The earnout consideration, if any, will be made in shares of common stock. Silvus designs and develops software-defined high-speed mobile ad-hoc network (MANET) technology that enables highly secure data, video and voice communications without the need for fixed infrastructure. This acquisition brings mobile ad-hoc network expertise and new applications to the Company's public safety and enterprise portfolio. This business will be part of both the Products and Systems Integration segment and the Software and Services segment.

[0000068505-25-000040:notes:13]
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. This business is part of the Software and Services segment.

[0000068505-25-000040:notes:14]
[same as prior period, unchanged from 0000068505-25-000024:notes:12]

[0000068505-25-000040:notes:15]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing computer-aided dispatch ("CAD") for the U.K.'s public safety agencies. This business is part of the Software and Services segment.

[0000068505-25-000040:notes:16]
On July 1, 2024, the Company acquired Noggin, a global provider of critical event management ("CEM") software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The business is part of the Software and Services segment.

[0000068505-25-000040:notes:17]
[same as prior period, unchanged from 0000068505-25-000024:notes:15]

[0000068505-25-000040:notes:18]
[same as prior period, unchanged from 0000068505-25-000024:notes:16]

[0000068505-25-000040:notes:19]
[same as prior period, unchanged from 0000068505-25-000024:notes:17]

[0000068505-25-000040:notes:20]
In November 2024, the Financial Accounting Standards Board ("FASB") issued Accounting Standard Update ("ASU") No. 2024-03, "Disaggregation of Income Statement Expenses" (DISE), to enhance disclosures relating to key income statement expense topics. This was subsequently amended by ASU No. 2025-01, "Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date," which clarified the effective dates. The ASU is effective for fiscal years beginning after December 15, 2026 and interim periods within annual reporting periods beginning after December 15, 2027, with early adoption permitted. The Company is still evaluating the complete impact of the adoption of this ASU on its disclosures.

[0000068505-25-000040:notes:21]
In December 2023, the FASB issued ASU No. 2023-09, “Income Taxes (Topic 740): Improvements to Income Tax Disclosures,” which expands disclosures in an entity's income tax rate reconciliation table and disclosures regarding cash taxes paid both in the U.S. and foreign jurisdictions. This ASU is effective for fiscal years beginning after December 15, 2024, with early adoption permitted. The Company anticipates that it will have additional disclosures regarding cash taxes and the income tax rate reconciliation once it adopts this ASU.

[0000068505-25-000040:notes:22]
Recently Adopted Accounting Pronouncements
In November 2023, the FASB issued ASU No. 2023-07, “Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures,” to update reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses and information used to assess segment performance. The Company adopted ASU No. 2023-07 for the year ended December 31, 2024 and applied the required retrospective transition method. Refer to Note 13, "Segment Information" in this "Part 1 — Financial Information" of this Form 10-Q for the related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000068505-25-000040:notes:23]
[same as prior period, unchanged from 0000068505-25-000024:notes:21]

[0000068505-25-000040:notes:24]
The following table summarizes the disaggregation of the Company's revenue by segment, region, major products and services and customer type for the three and six months ended June 28, 2025 and June 29, 2024, consistent with the information reviewed by the Company's chief operating decision maker for evaluating the financial performance of the Company's reportable segments:

[0000068505-25-000040:notes:25]
|  | Three Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 1,251 |  |  | $ | 776 |  |  | $ | 2,027 |  |  | $ | 1,245 |  |  | $ | 672 |  |  | $ | 1,917 |  |
| International | 402 |  |  | 336 |  |  | 738 |  |  | 413 |  |  | 298 |  |  | 711 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 1,356 |  |  | $ | 649 |  |  | $ | 2,005 |  |  | $ | 1,363 |  |  | $ | 578 |  |  | $ | 1,941 |  |
| Video | 297 |  |  | 226 |  |  | 523 |  |  | 295 |  |  | 181 |  |  | 476 |  |
| Command Center | — |  |  | 237 |  |  | 237 |  |  | — |  |  | 211 |  |  | 211 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 1,030 |  |  | $ | 1,016 |  |  | 2,046 |  |  | $ | 1,000 |  |  | $ | 880 |  |  | $ | 1,880 |  |
| Indirect | 623 |  |  | 96 |  |  | 719 |  |  | 658 |  |  | 90 |  |  | 748 |  |
|  | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |

[0000068505-25-000040:notes:26]
|  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |
| (In millions) | Products and Systems Integration |  | Software and Services |  | Total |  | Products and Systems Integration |  | Software and Services |  | Total |
| Regions: |  |  |  |  |  |  |  |  |  |  |  |
| North America | $ | 2,429 |  |  | $ | 1,450 |  |  | $ | 3,879 |  |  | $ | 2,328 |  |  | $ | 1,282 |  |  | $ | 3,610 |  |
| International | 770 |  |  | 644 |  |  | 1,414 |  |  | 821 |  |  | 586 |  |  | 1,407 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Major Products and Services: |  |  |  |  |  |  |  |  |  |  |  |
| LMR Communications | $ | 2,671 |  |  | $ | 1,235 |  |  | $ | 3,906 |  |  | $ | 2,620 |  |  | $ | 1,144 |  |  | $ | 3,764 |  |
| Video | 528 |  |  | 436 |  |  | 964 |  |  | 529 |  |  | 345 |  |  | 874 |  |
| Command Center | — |  |  | 423 |  |  | 423 |  |  | — |  |  | 379 |  |  | 379 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Customer Types: |  |  |  |  |  |  |  |  |  |  |  |
| Direct | $ | 2,046 |  |  | $ | 1,923 |  |  | $ | 3,969 |  |  | $ | 1,861 |  |  | $ | 1,701 |  |  | $ | 3,562 |  |
| Indirect | 1,153 |  |  | 171 |  |  | 1,324 |  |  | 1,288 |  |  | 167 |  |  | 1,455 |  |
|  | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |

[0000068505-25-000040:notes:27]
[same as prior period, unchanged from 0000068505-25-000024:notes:24]

[0000068505-25-000040:notes:28]
Remaining performance obligations represent the revenue that is expected to be recognized in future periods related to performance obligations that are unsatisfied, or partially unsatisfied, as of the end of a period. The transaction value associated with remaining performance obligations which were not yet satisfied as of June 28, 2025 was $8.8 billion. A total of $3.4 billion was from Products and Systems Integration performance obligations that were not yet satisfied as of June 28, 2025, of which $1.9 billion is expected to be recognized in the next twelve months. The remaining amounts will generally be satisfied over time as systems are implemented. Remaining performance obligations from the Products and Systems Integration segment are equal to disclosed backlog for the segment. A total of $5.4 billion was from Software and Services performance obligations that were not yet satisfied as of June 28, 2025. The determination of Software and Services performance obligations that are not satisfied takes into account a contract term that may be limited by the customer’s ability to terminate for convenience. Where termination for convenience exists in the Company's service contracts, its disclosure of the remaining performance obligations that are unsatisfied assumes the contract term is limited until renewal. As a result, remaining performance obligations from the Software and Services segment may be less than disclosed backlog in the Software and Services segment due to multi-year service contracts with termination for convenience clauses. The Company expects to recognize $1.8 billion from unsatisfied Software and Services performance obligations over the next twelve months, with the remaining performance obligations generally to be recognized over time as services are performed and software is implemented.

[0000068505-25-000040:notes:29]
[same as prior period, unchanged from 0000068505-25-000024:notes:26]

[0000068505-25-000040:notes:30]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Accounts receivable, net | $ | 1,852 |  |  | $ | 1,952 |  |  |  |  |  |
| Contract assets | 1,380 |  |  | 1,230 |  |  |  |  |  |
| Contract liabilities | 2,016 |  |  | 2,072 |  |  |  |  |  |
| Non-current contract liabilities | 616 |  |  | 496 |  |  |  |  |  |

[0000068505-25-000040:notes:31]
[same as prior period, unchanged from 0000068505-25-000024:notes:28]

[0000068505-25-000040:notes:32]
Revenue recognized during the three months ended June 28, 2025 which was previously included in Contract liabilities as of March 29, 2025 was $663 million, compared to $553 million of revenue recognized during the three months ended June 29, 2024 which was previously included in Contract liabilities as of March 30, 2024. Revenue recognized during the six months ended June 28, 2025 which was previously included in Contract liabilities as of December 31, 2024 was $886 million, compared to $908 million recognized during the six months ended June 29, 2024 which was previously included in Contract liabilities as of December 31, 2023. Revenue of $5 million was recognized during the three months ended June 28, 2025 related to performance obligations satisfied, or partially satisfied, in previous periods, compared to $11 million of reversals for the three months ended June 29, 2024, primarily driven by changes in the estimates of progress on system contracts. Revenue of $6 million was reversed during the six months ended June 28, 2025 related to revenue recognized for performance obligations satisfied, or partially satisfied, in previous periods, primarily driven by changes in the estimates of progress on system contracts, compared to $18 million of reversals for the six months ended June 29, 2024.

[0000068505-25-000040:notes:33]
There were no material expected credit losses recorded on contract assets during each of the three and six months ended June 28, 2025 and June 29, 2024.

[0000068505-25-000040:notes:34]
[same as prior period, unchanged from 0000068505-25-000024:notes:31]

[0000068505-25-000040:notes:35]
| (In millions) | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Current contract cost assets | $ | 69 |  |  | $ | 70 |  |  |  |  |  |
| Non-current contract cost assets | 130 |  |  | 141 |  |  |  |  |  |

[0000068505-25-000040:notes:36]
Amortization of contract cost assets was $13 million and $26 million for the three and six months ended June 28, 2025, respectively, and $12 million and $25 million for the three and six months ended June 29, 2024, respectively.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000068505-25-000040:notes:37]
Leases
Components of Lease Expense

[0000068505-25-000040:notes:38]
|  | Three Months Ended |  | Six Months Ended |
| (in millions) | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Lease expense: |  |  |  |  |  |  |  |
| Operating lease cost | $ | 38 |  |  | $ | 34 |  |  | $ | 75 |  |  | $ | 69 |  |
| Variable cost | 16 |  |  | 11 |  |  | 28 |  |  | 22 |  |
| Sublease income | (2) |  |  | (1) |  |  | (3) |  |  | (3) |  |
| Net lease expense from operating leases | $ | 52 |  |  | $ | 44 |  |  | $ | 100 |  |  | $ | 88 |  |

[0000068505-25-000040:notes:39]
Lease Assets and Liabilities

[0000068505-25-000040:notes:40]
| (in millions) |  | Statement Line Classification |  | June 28, 2025 |  | December 31, 2024 |  |  |
| Right-of-use lease assets |  | Operating lease assets |  | $ | 590 |  |  | $ | 529 |  |  |  |
| Current lease liabilities |  | Accrued liabilities |  | 129 |  |  | 127 |  |  |  |
| Operating lease liabilities |  | Operating lease liabilities |  | 472 |  |  | 427 |  |  |  |

[0000068505-25-000040:notes:41]
Other Information Related to Leases

[0000068505-25-000040:notes:42]
|  | Six Months Ended |  |  |
| (in millions) | June 28, 2025 |  | June 29, 2024 |  |  |
| Supplemental cash flow information: |  |  |  |  |  |
| Net cash used for operating activities related to operating leases | $ | 88 |  |  | $ | 88 |  |  |  |
| Right-of-use assets obtained in exchange for lease liabilities | 58 |  |  | 91 |  |  |  |

[0000068505-25-000040:notes:43]
|  | June 28, 2025 |  | December 31, 2024 |
| Weighted average remaining lease terms (years) | 6 |  | 5 |
| Weighted average discount rate: | 4.14 | % |  | 3.97 | % |

[0000068505-25-000040:notes:44]
Future Lease Payments

[0000068505-25-000040:notes:45]
|  | June 28, 2025 |  |  |  |  |
| (in millions) | Operating Leases |  |  |  |  |
| Remainder of 2025 | $ | 58 |  |  |  |  |  |
| 2026 | 144 |  |  |  |  |  |
| 2027 | 142 |  |  |  |  |  |
| 2028 | 115 |  |  |  |  |  |
| 2029 | 85 |  |  |  |  |  |
| Thereafter | 135 |  |  |  |  |  |
| Total lease payments | 679 |  |  |  |  |  |
| Less: interest | 78 |  |  |  |  |  |
| Present value of lease liabilities | $ | 601 |  |  |  |  |  |


## us-gaap:LeaseCostTableTextBlock

[0000068505-25-000040:notes:46]
[same as prior period, unchanged from 0000068505-25-000024:notes:43]


## us-gaap:AdditionalFinancialInformationDisclosureTextBlock

[0000068505-25-000040:notes:47]
[same as prior period, unchanged from 0000068505-25-000024:notes:44]

[0000068505-25-000040:notes:48]
[same as prior period, unchanged from 0000068505-25-000024:notes:45]

[0000068505-25-000040:notes:49]
[same as prior period, unchanged from 0000068505-25-000024:notes:46]

[0000068505-25-000040:notes:50]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Other charges (income): |  |  |  |  |  |  |  |
| Intangibles amortization (Note 15) | $ | 39 |  |  | $ | 36 |  |  | $ | 76 |  |  | $ | 76 |  |
| Reorganization of business (Note 14) | 8 |  |  | 4 |  |  | 20 |  |  | 11 |  |
| Operating lease asset impairments | — |  |  | 1 |  |  | — |  |  | 4 |  |
| Acquisition-related transaction fees | 2 |  |  | 4 |  |  | 8 |  |  | 7 |  |
| Legal settlements | 1 |  |  | — |  |  | 5 |  |  | 6 |  |
| Gain on Hytera litigation | (10) |  |  | — |  |  | (20) |  |  | — |  |
|  | $ | 40 |  |  | $ | 45 |  |  | $ | 89 |  |  | $ | 104 |  |

[0000068505-25-000040:notes:51]
During the six months ended June 28, 2025, the Company recognized a gain on the Hytera litigation of $20 million for amounts recovered through legal proceedings due to theft of the Company's trade secrets. Refer to "Hytera Civil Litigation" within "Note 12: Commitments and Contingencies" in this "Part 1 — Financial Information" of this Form 10-Q.

[0000068505-25-000040:notes:52]
[same as prior period, unchanged from 0000068505-25-000024:notes:49]

[0000068505-25-000040:notes:53]
[same as prior period, unchanged from 0000068505-25-000024:notes:50]

[0000068505-25-000040:notes:54]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Interest, net: |  |  |  |  |  |  |  |
| Interest expense | $ | (71) |  |  | $ | (87) |  |  | $ | (140) |  |  | $ | (149) |  |
| Interest income | 16 |  |  | 18 |  |  | 34 |  |  | 36 |  |
|  | $ | (55) |  |  | $ | (69) |  |  | $ | (106) |  |  | $ | (113) |  |
| Other, net: |  |  |  |  |  |  |  |
| Net periodic pension and postretirement benefit (Note 8) | $ | 30 |  |  | $ | 31 |  |  | $ | 61 |  |  | $ | 63 |  |
| Loss from the extinguishment of Silver Lake Convertible Debt | — |  |  | — |  |  | — |  |  | (585) |  |
| Investment impairments | — |  |  | — |  |  | — |  |  | (3) |  |
| Foreign currency gain (loss) | (42) |  |  | 3 |  |  | (62) |  |  | 4 |  |
| Gain (loss) on derivative instruments (Note 6) | 34 |  |  | (5) |  |  | 48 |  |  | (15) |  |
| Fair value adjustments to equity investments | 18 |  |  | (11) |  |  | 13 |  |  | (13) |  |
| Assessments on uncertain tax positions | — |  |  | (11) |  |  | — |  |  | (11) |  |
| Other | 3 |  |  | (2) |  |  | (1) |  |  | — |  |
|  | $ | 43 |  |  | $ | 5 |  |  | $ | 59 |  |  | $ | (560) |  |

[0000068505-25-000040:notes:55]
Earnings Per Common Share

[0000068505-25-000040:notes:56]
Basic and diluted earnings per common share from net earnings attributable to Motorola Solutions, Inc. are computed as follows:

[0000068505-25-000040:notes:57]
|  | Amounts attributable to Motorola Solutions, Inc. common stockholders |
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Basic earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 513 |  |  | $ | 443 |  |  | $ | 943 |  |  | $ | 404 |  |
| Weighted average common shares outstanding | 166.8 |  |  | 166.9 |  |  | 166.8 |  |  | 166.5 |  |
| Per share amount | $ | 3.08 |  |  | $ | 2.65 |  |  | $ | 5.65 |  |  | $ | 2.43 |  |
| Diluted earnings per common share: |  |  |  |  |  |  |  |
| Earnings | $ | 513 |  |  | $ | 443 |  |  | $ | 943 |  |  | $ | 404 |  |
| Weighted average common shares outstanding | 166.8 |  |  | 166.9 |  |  | 166.8 |  |  | 166.5 |  |
| Add effect of dilutive securities: |  |  |  |  |  |  |  |
| Share-based awards | 2.0 |  |  | 3.4 |  |  | 2.6 |  |  | 3.8 |  |
| Diluted weighted average common shares outstanding | 168.8 |  |  | 170.3 |  |  | 169.4 |  |  | 170.3 |  |
| Per share amount | $ | 3.04 |  |  | $ | 2.60 |  |  | $ | 5.57 |  |  | $ | 2.37 |  |

[0000068505-25-000040:notes:58]
In the computation of diluted earnings per common share for the three months ended June 28, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000040:notes:59]
In the computation of diluted earnings per common share for the six months ended June 28, 2025, the assumed exercise of 0.1 million options and 0.1 million awards subject to performance conditions, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000040:notes:60]
In the computation of diluted earnings per common share for the three months ended June 29, 2024, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements, were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000040:notes:61]
In the computation of diluted earnings per common share for the six months ended June 29, 2024, a total of 0.5 million shares related to the 1.75% senior convertible notes issued to Silver Lake Partners ("Silver Lake Convertible Debt") were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive. In addition, the assumed exercise of 0.3 million options, inclusive of 0.2 million options subject to market based contingent option agreements were excluded from the computation of diluted earnings per common share because their inclusion would have been antidilutive.

[0000068505-25-000040:notes:62]
[same as prior period, unchanged from 0000068505-25-000024:notes:57]

[0000068505-25-000040:notes:63]
[same as prior period, unchanged from 0000068505-25-000024:notes:58]

[0000068505-25-000040:notes:64]
[same as prior period, unchanged from 0000068505-25-000024:notes:59]

[0000068505-25-000040:notes:65]
|  | June 28, 2025 |  | December 31, 2024 |
| Accounts receivable | $ | 1,927 |  |  | $ | 2,035 |  |
| Less allowance for credit losses | (75) |  |  | (83) |  |
|  | $ | 1,852 |  |  | $ | 1,952 |  |

[0000068505-25-000040:notes:66]
[same as prior period, unchanged from 0000068505-25-000024:notes:61]

[0000068505-25-000040:notes:67]
[same as prior period, unchanged from 0000068505-25-000024:notes:62]

[0000068505-25-000040:notes:68]
|  | June 28, 2025 |  | December 31, 2024 |
| Finished goods | $ | 442 |  |  | $ | 396 |  |
| Work-in-process and production materials | 544 |  |  | 498 |  |
|  | 986 |  |  | 894 |  |
| Less inventory reserves | (125) |  |  | (128) |  |
|  | $ | 861 |  |  | $ | 766 |  |

[0000068505-25-000040:notes:69]
[same as prior period, unchanged from 0000068505-25-000024:notes:64]

[0000068505-25-000040:notes:70]
[same as prior period, unchanged from 0000068505-25-000024:notes:65]

[0000068505-25-000040:notes:71]
|  | June 28, 2025 |  | December 31, 2024 |
| Current contract cost assets (Note 2) | $ | 69 |  |  | $ | 70 |  |
| Contractor receivables | 34 |  |  | 44 |  |
| Tax-related deposits | 38 |  |  | 54 |  |
| Other | 274 |  |  | 261 |  |
|  | $ | 415 |  |  | $ | 429 |  |

[0000068505-25-000040:notes:72]
[same as prior period, unchanged from 0000068505-25-000024:notes:67]

[0000068505-25-000040:notes:73]
[same as prior period, unchanged from 0000068505-25-000024:notes:68]

[0000068505-25-000040:notes:74]
|  | June 28, 2025 |  | December 31, 2024 |
| Land | $ | 5 |  |  | $ | 5 |  |
| Leasehold improvements | 458 |  |  | 441 |  |
| Machinery and equipment | 2,447 |  |  | 2,243 |  |
|  | 2,910 |  |  | 2,689 |  |
| Less accumulated depreciation | (1,840) |  |  | (1,667) |  |
|  | $ | 1,070 |  |  | $ | 1,022 |  |

[0000068505-25-000040:notes:75]
Depreciation expense was $47 million for both the three months ended June 28, 2025 and June 29, 2024. Depreciation expense for the six months ended June 28, 2025 and June 29, 2024 was $91 million and $90 million, respectively.

[0000068505-25-000040:notes:76]
[same as prior period, unchanged from 0000068505-25-000024:notes:71]

[0000068505-25-000040:notes:77]
[same as prior period, unchanged from 0000068505-25-000024:notes:72]

[0000068505-25-000040:notes:78]
|  | June 28, 2025 |  | December 31, 2024 |  |  |  |  |
| Common stock | $ | 36 |  |  | $ | 23 |  |  |  |  |  |
| Strategic investments | 57 |  |  | 26 |  |  |  |  |  |
| Company-owned life insurance policies | 77 |  |  | 75 |  |  |  |  |  |
| Equity method investments | 10 |  |  | 11 |  |  |  |  |  |
|  | $ | 180 |  |  | $ | 135 |  |  |  |  |  |

[0000068505-25-000040:notes:79]
[same as prior period, unchanged from 0000068505-25-000024:notes:74]

[0000068505-25-000040:notes:80]
[same as prior period, unchanged from 0000068505-25-000024:notes:75]

[0000068505-25-000040:notes:81]
|  | June 28, 2025 |  | December 31, 2024 |
| Defined benefit plan assets | $ | 201 |  |  | $ | 162 |  |
| Non-current contract cost assets (Note 2) | 130 |  |  | 141 |  |
| Other | 96 |  |  | 72 |  |
|  | $ | 427 |  |  | $ | 375 |  |

[0000068505-25-000040:notes:82]
[same as prior period, unchanged from 0000068505-25-000024:notes:77]

[0000068505-25-000040:notes:83]
[same as prior period, unchanged from 0000068505-25-000024:notes:78]

[0000068505-25-000040:notes:84]
The Company's outstanding amounts related to the suppliers participating in this program was $38 million as of both June 28, 2025 and December 31, 2024. Supplier finance program obligations are classified as Accounts payable within the Condensed Consolidated Balance Sheets.

[0000068505-25-000040:notes:85]
[same as prior period, unchanged from 0000068505-25-000024:notes:80]

[0000068505-25-000040:notes:86]
[same as prior period, unchanged from 0000068505-25-000024:notes:81]

[0000068505-25-000040:notes:87]
|  | June 28, 2025 |  | December 31, 2024 |
| Compensation | $ | 304 |  |  | $ | 406 |  |
| Tax liabilities | 161 |  |  | 217 |  |
| Dividend payable | 182 |  |  | 182 |  |
| Trade liabilities | 168 |  |  | 160 |  |
| Operating lease liabilities (Note 3) | 129 |  |  | 127 |  |
| Customer reserves | 90 |  |  | 97 |  |
| Other | 431 |  |  | 454 |  |
|  | $ | 1,465 |  |  | $ | 1,643 |  |

[0000068505-25-000040:notes:88]
[same as prior period, unchanged from 0000068505-25-000024:notes:83]

[0000068505-25-000040:notes:89]
[same as prior period, unchanged from 0000068505-25-000024:notes:84]

[0000068505-25-000040:notes:90]
|  | June 28, 2025 |  | December 31, 2024 |
| Defined benefit plans (Note 8) | $ | 739 |  |  | $ | 768 |  |
| Non-current contract liabilities (Note 2) | 616 |  |  | 496 |  |
| Unrecognized tax benefits (Note 7) | 38 |  |  | 39 |  |
| Deferred income taxes (Note 7) | 91 |  |  | 87 |  |
| Environmental reserve | 119 |  |  | 119 |  |
| Deferred compensation | 99 |  |  | 89 |  |
| Other | 129 |  |  | 121 |  |
|  | $ | 1,831 |  |  | $ | 1,719 |  |

[0000068505-25-000040:notes:91]
[same as prior period, unchanged from 0000068505-25-000024:notes:86]

[0000068505-25-000040:notes:92]
Share Repurchase Program: During the three and six months ended June 28, 2025, the Company repurchased approximately 0.6 million and 1.3 million shares at an average price of $414.42 and $427.74 per share for an aggregate amount of $218 million and $543 million, respectively.

[0000068505-25-000040:notes:93]
Payment of Dividends: During the three months ended June 28, 2025 and June 29, 2024, the Company paid $182 million and $163 million, respectively, in cash dividends to holders of its common stock. Subsequent to the quarter, the Company paid an additional $182 million in cash dividends to holders of its common stock. During the six months ended June 28, 2025 and June 29, 2024, the Company paid $364 million and $326 million, respectively, in cash dividends to holders of its common stock.

[0000068505-25-000040:notes:94]
[same as prior period, unchanged from 0000068505-25-000024:notes:89]

[0000068505-25-000040:notes:95]
The following table displays the changes in Accumulated other comprehensive loss, including amounts reclassified into income, and the affected line items in the Condensed Consolidated Statements of Operations during the three and six months ended June 28, 2025 and June 29, 2024:

[0000068505-25-000040:notes:96]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Foreign Currency Translation Adjustments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (505) |  |  | $ | (506) |  |  | $ | (546) |  |  | $ | (482) |  |
| Other comprehensive income (loss) before reclassification adjustment | 75 |  |  | (2) |  |  | 113 |  |  | (29) |  |
| Tax benefit (expense) | 2 |  |  | (1) |  |  | 5 |  |  | 2 |  |
| Other comprehensive income (loss), net of tax | 77 |  |  | (3) |  |  | 118 |  |  | (27) |  |
| Balance at end of period | $ | (428) |  |  | $ | (509) |  |  | $ | (428) |  |  | $ | (509) |  |
| Derivative Instruments: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (7) |  |  | $ | (8) |  |  | $ | (7) |  |  | $ | (12) |  |
| Other comprehensive income before reclassification adjustment | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income before reclassification adjustment, net of tax | — |  |  | — |  |  | — |  |  | 4 |  |
| Other comprehensive income, net of tax | — |  |  | — |  |  | $ | — |  |  | $ | 4 |  |
| Balance at end of period | $ | (7) |  |  | $ | (8) |  |  | $ | (7) |  |  | $ | (8) |  |
| Defined Benefit Plans: |  |  |  |  |  |  |  |
| Balance at beginning of period | $ | (1,988) |  |  | $ | (2,039) |  |  | $ | (1,986) |  |  | $ | (2,046) |  |
| Other comprehensive income (loss) before reclassification adjustment | 4 |  |  | — |  |  | (8) |  |  | — |  |
| Tax expense (benefit) | (1) |  |  | — |  |  | 2 |  |  | — |  |
| Other comprehensive income (loss) before reclassification adjustment, net of tax | 3 |  |  | — |  |  | (6) |  |  | — |  |
| Reclassification adjustment - Actuarial net losses into Other income (Note 8) | 9 |  |  | 8 |  |  | 18 |  |  | 17 |  |
| Reclassification adjustment - Prior service benefits into Other income (Note 8) | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Tax expense | (1) |  |  | (2) |  |  | (3) |  |  | (4) |  |
| Reclassification adjustments into Net earnings, net of tax | 8 |  |  | 7 |  |  | 15 |  |  | 14 |  |
| Other comprehensive income, net of tax | 11 |  |  | 7 |  |  | 9 |  |  | 14 |  |
| Balance at end of period | $ | (1,977) |  |  | $ | (2,032) |  |  | $ | (1,977) |  |  | $ | (2,032) |  |
| Total Accumulated other comprehensive loss | $ | (2,412) |  |  | $ | (2,549) |  |  | $ | (2,412) |  |  | $ | (2,549) |  |


## us-gaap:DebtDisclosureTextBlock

[0000068505-25-000040:notes:97]
Debt and Credit Facilities

[0000068505-25-000040:notes:98]
|  | June 28, 2025 |  | December 31, 2024 |
| 7.5% debentures due 2025 | $ | — |  |  | $ | 252 |  |
| 6.5% debentures due 2025 | 70 |  |  | 70 |  |
| 4.6% senior notes due 2028 | 697 |  |  | 696 |  |
| 6.5% debentures due 2028 | 24 |  |  | 24 |  |
| 5.0% senior notes due 2029 | 397 |  |  | 396 |  |
| 4.6% senior notes due 2029 | 802 |  |  | 802 |  |
| 2.3% senior notes due 2030 | 896 |  |  | 895 |  |
| 4.85% senior notes due 2030 | 595 |  |  | — |  |
| 2.75% senior notes due 2031 | 846 |  |  | 846 |  |
| 5.2% senior notes due 2032 | 496 |  |  | — |  |
| 5.6% senior notes due 2032 | 596 |  |  | 596 |  |
| 5.4% senior notes due 2034 | 893 |  |  | 893 |  |
| 5.55% senior notes due 2035 | 892 |  |  | — |  |
| 6.625% senior notes due 2037 | 38 |  |  | 38 |  |
| 5.5% senior notes due 2044 | 397 |  |  | 397 |  |
| 5.22% debentures due 2097 | 93 |  |  | 93 |  |
|  | 7,732 |  |  | 5,998 |  |
| Adjustments for unamortized gains on interest rate swap terminations | (1) |  |  | (1) |  |
| Less: current portion | (70) |  |  | (322) |  |
| Long-term debt | $ | 7,661 |  |  | $ | 5,675 |  |

[0000068505-25-000040:notes:99]
On June 16, 2025, the Company issued $600 million of 4.85% senior notes due 2030 (“2030 Notes”), $500 million of 5.2% senior notes due 2032 (“2032 Notes”) and $900 million of 5.55% senior notes due 2035 (“2035 Notes”). The Company recognized net proceeds of approximately $2.0 billion after debt issuance costs and discounts. The proceeds from these notes were used to fund a portion of the acquisition of Silvus.

[0000068505-25-000040:notes:100]
On May 27, 2025, the Company obtained financing commitments for $2.5 billion of senior unsecured delayed draw term loan facilities, comprised of a $1.75 billion 364-day facility and a $750 million three year facility. Upon issuance of 2030 Notes, 2032 Notes, and 2035 Notes, the financing commitments under the 364-day facility were reduced to $750 million. Subsequent to the quarter, on July 21, 2025 the Company entered into credit agreements for a $750 million 364-day delayed draw term loan and a $750 million three year delayed draw term loan, and on August 6, 2025 the Company borrowed $750 million under the 364-day delayed draw term loan and $750 million under the three year delayed draw term loan to fund a portion of the acquisition of Silvus.

[0000068505-25-000040:notes:101]
During the three months ended June 28, 2025, the Company repaid the $252 million aggregate principal amount of the 7.5% senior notes due 2025.

[0000068505-25-000040:notes:102]
As of June 28, 2025, $70 million of 6.5% debentures due 2025, which mature in September 2025, were presented as the Current portion of long-term debt within the Company's Condensed Consolidated Balance Sheets, as the debentures mature within the next twelve months.

[0000068505-25-000040:notes:103]
On April 25, 2025, the Company entered into a $2.25 billion syndicated, unsecured revolving credit facility maturing in April 2030 which can be used for general corporate purposes and letters of credit (the "2025 Motorola Solutions Credit Agreement"), which replaced the Company's $2.25 billion 2021 Motorola Solutions Credit Agreement scheduled to mature in March 2026. Borrowings under the facility bear interest at the prime rate plus the applicable margin, or at a spread above the Secured Overnight Financing Rate (SOFR), at the Company's option. An annual facility fee is payable on the undrawn amount of the credit line. The interest rate and facility fee are subject to adjustment if the Company's credit rating changes. The Company must comply with certain customary covenants including a maximum leverage ratio, as defined in the 2025 Motorola Solutions Credit Agreement. The Company was in compliance with its financial covenants as of June 28, 2025.

[0000068505-25-000040:notes:104]
The Company has an unsecured commercial paper program, backed by the 2025 Motorola Solutions Credit Agreement, under which the Company may issue unsecured commercial paper notes up to a maximum aggregate principal amount of $2.2 billion outstanding at any one time. Proceeds from the issuances of the notes are expected to be used for general corporate purposes. The notes are issued at a zero-coupon rate and are issued at a discount which reflects the interest component. At maturity, the notes are paid back in full including the interest component. The notes are not redeemable prior to maturity. As of June 28, 2025 the Company had no outstanding debt under the commercial paper program. Subsequent to the quarter, the Company utilized its commercial paper program as a source of short-term liquidity to partially fund the acquisition of Silvus.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000068505-25-000040:notes:105]
[same as prior period, unchanged from 0000068505-25-000024:notes:96]

[0000068505-25-000040:notes:106]
The Company had outstanding foreign exchange contracts with notional amounts totaling $1.3 billion and $1.0 billion for the periods ended June 28, 2025 and December 31, 2024, respectively. The Company does not believe these financial instruments should subject it to undue risk due to foreign exchange movements because gains and losses on these contracts should generally offset gains and losses on the underlying assets, liabilities and transactions.

[0000068505-25-000040:notes:107]
The following table shows the five largest net notional amounts of the positions to buy or sell foreign currency as of June 28, 2025, and the corresponding positions as of December 31, 2024:

[0000068505-25-000040:notes:108]
|  | Notional Amount |
| Net Buy (Sell) by Currency | June 28, 2025 |  | December 31, 2024 |
| British pound | $ | 212 |  |  | $ | 124 |  |
| Euro | 167 |  |  | 150 |  |
| Australian dollar | (145) |  |  | (136) |  |
| Canadian dollar | 93 |  |  | 70 |  |
| Chinese renminbi | (45) |  |  | (48) |  |

[0000068505-25-000040:notes:109]
[same as prior period, unchanged from 0000068505-25-000024:notes:100]

[0000068505-25-000040:notes:110]
The use of derivative financial instruments exposes the Company to counterparty credit risk in the event of non-performance by counterparties. However, the Company’s risk is limited to the fair value of the instruments when the derivative is in an asset position. The Company actively monitors its exposure to credit risk. As of June 28, 2025, all of the counterparties had investment grade credit ratings. As of June 28, 2025, the Company had $10 million of exposure to aggregate credit risk with all counterparties.

[0000068505-25-000040:notes:111]
[same as prior period, unchanged from 0000068505-25-000024:notes:102]

[0000068505-25-000040:notes:112]
The following tables summarize the fair values and locations in the Condensed Consolidated Balance Sheets of all derivative financial instruments held by the Company as of June 28, 2025 and December 31, 2024:

[0000068505-25-000040:notes:113]
|  | Fair Values of Derivative Instruments |
| June 28, 2025 | Other Current Assets |  | Accrued Liabilities |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | $ | — |  |  | $ | 20 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign exchange contracts | 9 |  |  | 1 |  |
| Equity swap contracts | 1 |  |  | — |  |
| Total derivatives | $ | 10 |  |  | $ | 21 |  |

[0000068505-25-000040:notes:114]
[same as prior period, unchanged from 0000068505-25-000024:notes:105]

[0000068505-25-000040:notes:115]
The following table summarizes the effect of derivatives on the Company's condensed consolidated financial statements for the three and six months ended June 28, 2025 and June 29, 2024:

[0000068505-25-000040:notes:116]
|  | Financial Statement Location | Three Months Ended |  | Six Months Ended |
| Derivatives | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Accumulated othercomprehensive income (loss) | $ | (17) |  |  | $ | 2 |  |  | $ | (23) |  |  | $ | 6 |  |
| Amortized hedge income | Other income (expense) | 2 |  |  | — |  |  | 3 |  |  | 1 |  |
| Treasury rate lock | Accumulated other comprehensive income (loss) | — |  |  | — |  |  | — |  |  | 4 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts | Other income (expense) | $ | 34 |  |  | $ | (5) |  |  | $ | 48 |  |  | $ | (15) |  |
| Equity swap contracts | Selling, general and administrative expenses | 2 |  |  | 1 |  |  | 1 |  |  | 2 |  |

[0000068505-25-000040:notes:117]
[same as prior period, unchanged from 0000068505-25-000024:notes:108]

[0000068505-25-000040:notes:118]
The Company uses foreign exchange forward and option contracts to hedge against the effect of the British pound and the Euro exchange rate fluctuations against the U.S. dollar on a portion of its net investments in certain European operations. The Company recognizes changes in the fair value of the net investment hedges as a component of Foreign currency translation adjustments within Other comprehensive income to offset a portion of the change in translated value of the net investments being hedged, until the investments are sold or liquidated. As of June 28, 2025, the Company had €160 million of net investment hedges in certain Euro functional subsidiaries and £50 million of net investment hedges in a British pound functional subsidiary.

[0000068505-25-000040:notes:119]
The Company excludes the difference between the spot rate and the forward rate of the forward contracts and initial time value of the options from its assessment of hedge effectiveness. The effect of the forward points recognized in forward contracts and the initial time value of the option contracts are amortized on a straight-line basis and recognized through interest expense within Other income (expense) in the Condensed Consolidated Statement of Operations.

[0000068505-25-000040:notes:120]
[same as prior period, unchanged from 0000068505-25-000024:notes:111]

[0000068505-25-000040:notes:121]
The Company uses equity swap contracts which serve as economic hedges against volatility within the equity markets, impacting the Company's deferred compensation plan obligations. These contracts are not designated as hedges for accounting purposes. Unrealized gains and losses on these contracts are included in Selling, general and administrative expenses in the Condensed Consolidated Statements of Operations. The notional amount of these contracts as of June 28, 2025 was $20 million.

[0000068505-25-000040:notes:122]
[same as prior period, unchanged from 0000068505-25-000024:notes:113]

[0000068505-25-000040:notes:123]
In 2023, the Company entered into treasury rate agreements which locked in the interest rate for $200 million in future debt issuances. The treasury rate lock agreements were designated and qualified as cash flow hedges. During the six months ended June 29, 2024, the Company issued $900 million of 5.4% senior notes due 2034 (the "2034 notes"). The treasury rate lock agreements were terminated upon the issuance of the 2034 notes for a net settlement loss of $8 million. The accumulated loss recorded in Accumulated other comprehensive income (loss) will be reclassified to interest expense on a straight-line basis over the ten year term of the 2034 notes.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000068505-25-000040:notes:124]
[same as prior period, unchanged from 0000068505-25-000024:notes:115]

[0000068505-25-000040:notes:125]
[same as prior period, unchanged from 0000068505-25-000024:notes:116]

[0000068505-25-000040:notes:126]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Net earnings before income taxes | $ | 680 |  |  | $ | 580 |  |  | $ | 1,227 |  |  | $ | 490 |  |
| Income tax expense | 165 |  |  | 135 |  |  | 280 |  |  | 83 |  |
| Effective tax rate | 24 | % |  | 23 | % |  | 23 | % |  | 17 | % |

[0000068505-25-000040:notes:127]
The effective tax rate for the three months ended June 28, 2025 of 24% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation. The effective tax rate for the six months ended June 28, 2025 of 23% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by excess tax benefits of share-based compensation.

[0000068505-25-000040:notes:128]
The effective tax rate for the three months ended June 29, 2024 of 23% was higher than the U.S. federal statutory tax rate of 21% primarily due to state tax expense, offset by the tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions and excess tax benefits of share-based compensation. The effective tax rate for the six months ended June 29, 2024 of 17% was lower than the U.S. federal statutory tax rate of 21% primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return, and excess tax benefits of share-based compensation, offset by the non-tax deductible loss on the extinguishment of the Silver Lake Convertible Debt in the first quarter of 2024 and state tax expense.

[0000068505-25-000040:notes:129]
The effective tax rate for the three months ended June 28, 2025 of 24% was higher than the effective tax rate for the three months ended June 29, 2024 of 23%, primarily due to tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024 and lower excess tax benefits of share-based compensation in 2025. The effective tax rate for the six months ended June 28, 2025 of 23% was higher than the effective tax rate for the six months ended June 29, 2024 of 17%, primarily due to the tax benefit recognized upon the Company's decision to implement a business initiative in 2024 which allowed for additional utilization of foreign tax credit carryforwards and a higher foreign derived intangible income deduction on its 2023 U.S. tax return and tax benefits recognized upon settlement of audits with taxing authorities in foreign jurisdictions in 2024, offset by the non-tax deductible loss on the extinguishment of Silver Lake Convertible Debt in 2024.

[0000068505-25-000040:notes:130]
Subsequent to quarter end, on July 4, 2025, the "One Big Beautiful Bill Act" was enacted into law, introducing a broad range of changes to the U.S. corporate income tax framework. The legislation includes business provisions that may impact the Company's tax position, including tax cut extensions and modifications to the international tax framework and corporate income tax deductions. The Company is currently evaluating the potential effects of these changes on its financial statements, inclusive of its income tax provision, income tax payable, and deferred tax asset balances. Due to the timing of the bill's enactment, the financial impact of this legislation is not reflected in this quarter's results. The Company will recognize the effects of this legislation in accordance with the enactment and effective dates of the applicable provisions.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000068505-25-000040:notes:131]
[same as prior period, unchanged from 0000068505-25-000024:notes:121]

[0000068505-25-000040:notes:132]
[same as prior period, unchanged from 0000068505-25-000024:notes:122]

[0000068505-25-000040:notes:133]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Three Months Ended | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Interest cost | $ | 50 |  |  | $ | 47 |  |  | $ | 14 |  |  | $ | 14 |  |  | $ | 2 |  |  | $ | 2 |  |
| Expected return on plan assets | (76) |  |  | (74) |  |  | (26) |  |  | (26) |  |  | (3) |  |  | (3) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 6 |  |  | 6 |  |  | 1 |  |  | 1 |  |  | 2 |  |  | 1 |  |
| Unrecognized prior service cost | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1 |  |
| Net periodic pension cost (benefits) | $ | (20) |  |  | $ | (21) |  |  | $ | (11) |  |  | $ | (11) |  |  | $ | 1 |  |  | $ | 1 |  |

[0000068505-25-000040:notes:134]
|  | U.S. Pension Benefit Plans |  | Non-U.S. Pension Benefit Plans |  | Postretirement Health Care Benefits Plan |
| Six Months Ended | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Interest cost | 100 |  |  | 94 |  |  | 28 |  |  | 28 |  |  | 3 |  |  | 3 |  |
| Expected return on plan assets | (152) |  |  | (149) |  |  | (52) |  |  | (51) |  |  | (6) |  |  | (6) |  |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized net loss | 12 |  |  | 12 |  |  | 3 |  |  | 3 |  |  | 3 |  |  | 2 |  |
| Unrecognized prior service cost (benefit) | — |  |  | — |  |  | (1) |  |  | (1) |  |  | 1 |  |  | 2 |  |
| Net periodic pension cost (benefits) | $ | (40) |  |  | $ | (43) |  |  | $ | (22) |  |  | $ | (21) |  |  | $ | 1 |  |  | $ | 1 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000068505-25-000040:notes:135]
[same as prior period, unchanged from 0000068505-25-000024:notes:124]

[0000068505-25-000040:notes:136]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
| Costs of sales | $ | 14 |  |  | $ | 12 |  |  | $ | 28 |  |  | $ | 24 |  |
| Selling, general and administrative expenses | 40 |  |  | 35 |  |  | 75 |  |  | 64 |  |
| Research and development expenditures | 20 |  |  | 16 |  |  | 37 |  |  | 31 |  |
| Share-based compensation expense included in Operating earnings | 74 |  |  | 63 |  |  | 140 |  |  | 119 |  |
| Tax benefit | (15) |  |  | (13) |  |  | (29) |  |  | (24) |  |
| Share-based compensation expense, net of tax | $ | 59 |  |  | $ | 50 |  |  | $ | 111 |  |  | $ | 95 |  |
| Decrease in basic earnings per share | $ | (0.35) |  |  | $ | (0.30) |  |  | $ | (0.67) |  |  | $ | (0.57) |  |
| Decrease in diluted earnings per share | $ | (0.35) |  |  | $ | (0.29) |  |  | $ | (0.66) |  |  | $ | (0.56) |  |

[0000068505-25-000040:notes:137]
During the six months ended June 28, 2025, the Company granted 0.5 million RSUs, 0.1 million performance stock units (PSUs) and 0.04 million market stock units (MSUs) with an aggregate grant-date fair value of $186 million, $24 million and $17 million, respectively, and 0.1 million stock options and 0.1 million performance options (POs) with an aggregate grant-date fair value of $8 million and $17 million, respectively. The share-based compensation expense will generally be recognized over the vesting period of three years.


## us-gaap:FairValueDisclosuresTextBlock

[0000068505-25-000040:notes:138]
Fair Value Measurements
The fair values of the Company’s financial assets and liabilities by level in the fair value hierarchy as of June 28, 2025 and December 31, 2024 were as follows:

[0000068505-25-000040:notes:139]
| June 28, 2025 | Level 1 |  | Level 2 |  |  |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 9 |  |  |  |  | $ | 9 |  |
| Equity swap contracts | 1 |  |  | — |  |  |  |  | 1 |  |
| Common stock | 36 |  |  | — |  |  |  |  | 36 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign exchange derivative contracts | $ | — |  |  | $ | 21 |  |  |  |  | $ | 21 |  |

[0000068505-25-000040:notes:140]
[same as prior period, unchanged from 0000068505-25-000024:notes:129]

[0000068505-25-000040:notes:141]
The Company had no foreign exchange derivative contracts, equity swap contracts or common stock investments in Level 3 holdings as of June 28, 2025 or December 31, 2024.

[0000068505-25-000040:notes:142]
At June 28, 2025 and December 31, 2024, the Company had $1.5 billion and $1.2 billion, respectively, of investments in money market government and U.S. treasury funds classified (Level 1) as Cash and cash equivalents in its Condensed Consolidated Balance Sheets. The money market funds had quoted market prices that are equivalent to par.

[0000068505-25-000040:notes:143]
Using quoted market prices and market interest rates, the fair value of the Company's long-term debt as of June 28, 2025 was $7.6 billion. The fair value of long-term debt at December 31, 2024 was $5.8 billion.

[0000068505-25-000040:notes:144]
[same as prior period, unchanged from 0000068505-25-000024:notes:133]


## us-gaap:TransfersAndServicingOfFinancialAssetsTextBlock

[0000068505-25-000040:notes:145]
[same as prior period, unchanged from 0000068505-25-000024:notes:134]

[0000068505-25-000040:notes:146]
The following table summarizes the proceeds received from sales of accounts receivable and long-term receivables for the three and six months ended June 28, 2025 and June 29, 2024:

[0000068505-25-000040:notes:147]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Long-term receivables sales proceeds | 89 |  |  | 17 |  |  | 113 |  |  | 27 |  |

[0000068505-25-000040:notes:148]
At June 28, 2025, the Company had retained servicing obligations for $845 million of long-term receivables, compared to $794 million at December 31, 2024. Servicing obligations are limited to collection activities related to the sales of accounts receivables and long-term receivables. The Company had outstanding commitments to provide long-term financing to third parties totaling $171 million at June 28, 2025, compared to $105 million at December 31, 2024.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000068505-25-000040:notes:149]
Commitments and Contingencies
Legal Matters

[0000068505-25-000040:notes:150]
Hytera Civil Litigation

[0000068505-25-000040:notes:151]
In 2017, the Company filed a complaint against Hytera Communications Corporation Limited of Shenzhen, China; Hytera America, Inc.; and Hytera Communications America (West), Inc. (collectively, "Hytera"), in the U.S. District Court for the Northern District of Illinois (the "District Court"), alleging trade secret theft and copyright infringement, and seeking injunctive relief. In 2020, a jury decided in the Company's favor and awarded the Company $543.7 million, plus $51.1 million in pre-judgment interest and $2.6 million in costs, as well as $34.2 million in attorneys' fees.

[0000068505-25-000040:notes:152]
Subsequently, the District Court ordered Hytera to pay the Company a forward-looking reasonable royalty on products that use the Company’s stolen trade secrets, setting royalty rates for Hytera's sale of relevant products from July 1, 2019 forward. The District Court then ordered Hytera to make royalty payments into a third-party escrow, while it reviewed Hytera's motion to modify the royalty order, which the District Court eventually denied. Hytera refused to make all of its royalty payments. The Company filed a motion to hold Hytera in civil contempt for failing to make every royalty payment, which the District Court granted in 2023. As a result, on September 1, 2023, Hytera made a payment of $56 million into the third-party escrow, in addition to subsequent de minimis quarterly royalty payments between October 2022 and November 2024. The aggregate amount paid into escrow of approximately $61 million was released to the Company on November 26, 2024 and was recorded as a gain within Other charges within the Consolidated Statement of Operations.

[0000068505-25-000040:notes:153]
Following the initial District Court judgment in the Company's favor, both parties appealed to the U.S. Court of Appeals for the Seventh Circuit (the "Court of Appeals"). On July 2, 2024, the Court of Appeals affirmed the District Court's award of $407.4 million in damages under the Defend Trade Secrets Act, directed the District Court to recalculate and reduce its award of $136.3 million in copyright infringement damages, and instructed the District Court to reconsider its denial of the Company's request for an injunction. In all other respects, the Court of Appeals affirmed the judgment of the District Court. On October 4, 2024, the Court of Appeals denied Hytera's motion for rehearing. The case was remanded to the District Court for further action per the Court of Appeals' decision. On January 2, 2025, Hytera filed a petition for writ of certiorari with the Supreme Court of the United States, which was subsequently denied on February 24, 2025. The issues of copyright recalculation and injunction are currently briefed. The District Court is seeking to schedule a hearing on these issues for sometime later in 2025.

[0000068505-25-000040:notes:154]
On March 4, 2025, Hytera made a partial payment toward the judgment of approximately $10 million, and an additional payment of approximately $10 million on April 25, 2025. Both payments were recorded as a gain within Other charges within the Consolidated Statement of Operations. Subsequent to quarter end, the Company received additional payments of approximately $41 million. The Company continues to seek collection of the judgment through the ongoing legal process.

[0000068505-25-000040:notes:155]
In 2024, the parties engaged in competing litigation in the District Court and a court in China related to the possible continued use by Hytera of the Company’s trade secrets in Hytera’s currently shipping products. On April 2, 2024, the District Court held Hytera in civil contempt, and issued a worldwide sales injunction of certain Hytera products and a daily fine for Hytera's failure to withdraw its competing litigation in China. On April 16, 2024, the Court of Appeals granted Hytera's motion for an emergency stay of the contempt sanctions, pending its review of the District Court's various orders related to the competing litigation and contempt sanctions. The District Court held hearings in August 2024, concerning whether Hytera's currently shipping products continue to misuse the Company's trade secrets and copyrighted source code. The issue is currently under consideration by the District Court.

[0000068505-25-000040:notes:156]
Hytera Criminal Litigation

[0000068505-25-000040:notes:157]
On January 13, 2025, Hytera pleaded guilty to one federal felony count of conspiracy to steal the Company's trade secrets in a criminal action brought by the U.S. Department of Justice against Hytera and several of its employees in the District Court. Hytera's sentencing has been scheduled for November 24th and 25th, 2025. Pursuant to the plea agreement, Hytera's sentence may include a fine to be paid to the government and restitution to be paid to the Company in the amount to be determined by the District Court.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000068505-25-000040:notes:158]
[same as prior period, unchanged from 0000068505-25-000024:notes:147]

[0000068505-25-000040:notes:159]
|  | Three Months Ended |
|  | June 28, 2025 |  |  |  |  |  | June 29, 2024 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net sales | $ | 1,653 |  |  | $ | 1,112 |  |  | $ | 2,765 |  |  |  |  |  |  | $ | 1,658 |  |  | $ | 970 |  |  | $ | 2,628 |  |
| Cost of sales | 777 |  | 575 |  | 1,352 |  |  |  |  |  | 784 |  | 505 |  | 1,289 |
| Gross margin | 876 |  | 537 |  | 1,413 |  |  |  |  |  | 874 |  | 465 |  | 1,339 |
| Selling, general and administrative expenses | 355 |  | 95 |  | 450 |  |  |  |  |  | 342 |  | 88 |  | 430 |
| Research and development expenditures | 143 |  | 88 |  | 231 |  |  |  |  |  | 140 |  | 80 |  | 220 |
| Other charges | 15 |  | 25 |  | 40 |  |  |  |  |  | 13 |  | 32 |  | 45 |
| Operating earnings | $ | 363 |  |  | $ | 329 |  |  | $ | 692 |  |  |  |  |  |  | $ | 379 |  |  | $ | 265 |  |  | $ | 644 |  |
| Total other expense |  |  |  |  | (12) |  |  |  |  |  |  |  |  |  | (64) |
| Earnings before income taxes |  |  |  |  | $ | 680 |  |  |  |  |  |  |  |  |  |  | $ | 580 |  |

[0000068505-25-000040:notes:160]
|  | Six Months Ended |
|  | June 28, 2025 |  |  |  |  |  | June 29, 2024 |
|  | Products and Systems Integration |  | Software and Services |  | Total |  |  |  |  |  | Products and Systems Integration |  | Software and Services |  | Total |
| Net Sales | $ | 3,199 |  |  | $ | 2,094 |  |  | $ | 5,293 |  |  |  |  |  |  | $ | 3,149 |  |  | $ | 1,868 |  |  | $ | 5,017 |  |
| Cost of Sales | 1,471 |  | 1,109 |  | 2,580 |  |  |  |  |  | 1,500 |  | 986 |  | 2,486 |
| Gross Margin | 1,728 |  | 985 |  | 2,713 |  |  |  |  |  | 1,649 |  | 882 |  | 2,531 |
| Selling, general and administrative expenses | 696 |  | 190 |  | 886 |  |  |  |  |  | 654 |  | 173 |  | 827 |
| Research and development expenditures | 285 |  | 179 |  | 464 |  |  |  |  |  | 276 |  | 161 |  | 437 |
| Other charges | 32 |  | 57 |  | 89 |  |  |  |  |  | 30 |  | 74 |  | 104 |
| Operating earnings | $ | 715 |  |  | $ | 559 |  |  | $ | 1,274 |  |  |  |  |  |  | $ | 689 |  |  | $ | 474 |  |  | $ | 1,163 |  |
| Total other expense |  |  |  |  | (47) |  |  |  |  |  |  |  |  |  | (673) |
| Earnings before income taxes |  |  |  |  | $ | 1,227 |  |  |  |  |  |  |  |  |  |  | $ | 490 |  |

[0000068505-25-000040:notes:161]
[same as prior period, unchanged from 0000068505-25-000024:notes:149]

[0000068505-25-000040:notes:162]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Products and Systems Integration | $ | 23 |  |  | $ | 23 |  |  | 38 |  | $ | 40 |  |
| Software and Services | 25 |  | 45 |  | 47 |  | 74 |
|  | $ | 48 |  |  | $ | 68 |  |  | 85 |  | $ | 114 |  |

[0000068505-25-000040:notes:163]
[same as prior period, unchanged from 0000068505-25-000024:notes:151]

[0000068505-25-000040:notes:164]
|  | Three Months Ended |  | Six Months Ended |
|  | June 28, 2025 |  | June 29, 2024 |  | June 28, 2025 |  | June 29, 2024 |
| Products and Systems Integration | $ | 23 |  |  | $ | 22 |  |  | $ | 44 |  |  | $ | 43 |  |
| Software and Services | 24 |  | 25 |  | 47 |  | 47 |
|  | $ | 47 |  |  | $ | 47 |  |  | $ | 91 |  |  | $ | 90 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000068505-25-000040:notes:165]
[same as prior period, unchanged from 0000068505-25-000024:notes:153]

[0000068505-25-000040:notes:166]
During the three months ended June 28, 2025, the Company recorded net reorganization of business charges of $14 million, including $8 million of charges in Other charges and $6 million of charges in Cost of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $13 million related to employee separation costs and $1 million related to exit costs.

[0000068505-25-000040:notes:167]
During the six months ended June 28, 2025, the Company recorded net reorganization of business charges of $31 million, including $20 million of charges in Other charges and $11 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $31 million were charges of $33 million related to employee separation costs and $1 million related to exit costs, partially offset by $3 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000040:notes:168]
[same as prior period, unchanged from 0000068505-25-000024:notes:155]

[0000068505-25-000040:notes:169]
| June 28, 2025 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 10 |  |  | $ | 22 |  |
| Software and Services | 4 |  |  | 9 |  |
|  | $ | 14 |  |  | $ | 31 |  |

[0000068505-25-000040:notes:170]
[same as prior period, unchanged from 0000068505-25-000024:notes:157]

[0000068505-25-000040:notes:171]
|  | January 1, 2025 |  | Additional Charges |  | Adjustments |  | Amount Used |  | June 28, 2025 |
| Employee separation costs | $ | 27 |  |  | $ | 33 |  |  | $ | (3) |  |  | $ | (33) |  |  | $ | 24 |  |
| Exit costs | 1 |  |  | 1 |  |  | — |  |  | (1) |  |  | 1 |  |
|  | $ | 28 |  |  | $ | 34 |  |  | $ | (3) |  |  | $ | (34) |  |  | $ | 25 |  |

[0000068505-25-000040:notes:172]
[same as prior period, unchanged from 0000068505-25-000024:notes:159]

[0000068505-25-000040:notes:173]
At January 1, 2025, the Company had an accrual of $1 million for exit costs, related to the Company's exit of the Emergency Service Network contract with the U.K. Home Office. The $1 million of exit costs are recorded in Accrued liabilities in the Company's Condensed Consolidated Balance Sheets at June 28, 2025, and are expected to be paid within one year.

[0000068505-25-000040:notes:174]
[same as prior period, unchanged from 0000068505-25-000024:notes:161]

[0000068505-25-000040:notes:175]
At January 1, 2025, the Company had an accrual of $27 million for employee separation costs. The 2025 additional charges of $33 million represent severance costs for approximately 470 employees. The adjustment of $3 million reflects reversals for accruals no longer needed. The $33 million used reflects cash payments to severed employees. The remaining accrual of $24 million, which is included in Accrued liabilities in the Company’s Condensed Consolidated Balance Sheets at June 28, 2025, is expected to be paid, primarily within one year, to approximately 670 employees, who have either been severed or have been notified of their severance and have begun or will begin receiving payments.

[0000068505-25-000040:notes:176]
[same as prior period, unchanged from 0000068505-25-000024:notes:163]

[0000068505-25-000040:notes:177]
During the three months ended June 29, 2024, the Company recorded net reorganization of business charges of $4 million, including $4 million of charges in Other charges in the Company's Condensed Consolidated Statements of Operations. Included in the $4 million were charges of $10 million related to employee separation costs, partially offset by $2 million of reversals for employee separation accruals and $4 million of reversals for exit cost accruals that are no longer needed.

[0000068505-25-000040:notes:178]
During the six months ended June 29, 2024, the Company recorded net reorganization of business charges of $14 million, including $11 million of charges in Other charges and $3 million of charges in Costs of sales in the Company's Condensed Consolidated Statements of Operations. Included in the $14 million were charges of $22 million related to employee separation costs, partially offset by $4 million of reversals for exit cost accruals no longer needed and $4 million of reversals for employee separation accruals no longer needed.

[0000068505-25-000040:notes:179]
| June 29, 2024 | Three Months Ended |  | Six Months Ended |
| Products and Systems Integration | $ | 6 |  |  | $ | 14 |  |
| Software and Services | (2) |  |  | — |  |
|  | $ | 4 |  |  | $ | 14 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000068505-25-000040:notes:180]
Intangible Assets and Goodwill
On March 6, 2025, the Company acquired Theatro, a maker of AI and voice-powered communication and digital workflow software for frontline workers for $173 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value price of $5 million to certain key employees that will be expensed over a service period of three years. The acquisition enhances the Company's portfolio of enterprise technologies by integrating Theatro's AI voice assistant in the Company's complementary workflows across our portfolio, including body cameras, fixed video, panic buttons and radios. The Company recognized $132 million of goodwill, $48 million of identifiable intangible assets and $7 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $15 million of customer relationships and $32 million of developed technology and will be amortized over a period of three, nineteen and eleven years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000040:notes:181]
On February 21, 2025, the Company acquired RapidDeploy, a provider of cloud-native 911 solutions for public safety for $241 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $6 million to certain key employees that will be expensed over a service period of two years. The acquisition complements the Company's Command Center portfolio of 911 solutions. The Company recognized $156 million of goodwill, $117 million of identifiable intangible assets, and $32 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $6 million of trade names, $36 million of customer relationships and $75 million of developed technology and will be amortized over a period of nine, nineteen and eighteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, intangible assets, net liabilities and goodwill may be subject to change.

[0000068505-25-000040:notes:182]
On October 29, 2024, the Company acquired 3tc Software, a provider of control room software solutions for $23 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $4 million to certain key employees that will be expensed over a service period of one year. The acquisition expands the Company's critical experience and innovation focused on advancing CAD for the U.K.'s public safety agencies. The Company recognized $15 million of goodwill, $11 million of identifiable intangible assets, and $3 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible asset was classified as $11 million of developed technology and will be amortized over a period of seven years. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-25-000040:notes:183]
On July 1, 2024, the Company acquired Noggin, a global provider of CEM software for $92 million, net of cash acquired. In addition, the Company issued restricted stock at a fair value of $19 million to certain key employees that will be expensed over a service period of three years. This acquisition enhances the Company's portfolio by adding operational resilience and CEM capabilities, which help enterprises and critical infrastructure anticipate, prepare for and efficiently respond to incidents. The Company recognized $50 million of goodwill, $53 million of identifiable intangible assets, and $11 million of net liabilities. The goodwill is not deductible for tax purposes. The identifiable intangible assets were classified as $1 million of trade names, $7 million of customer relationships and $45 million of developed technology and will be amortized over a period of three, fifteen and thirteen years, respectively. The business is part of the Software and Services segment. The purchase accounting is not yet complete and as such, the final allocation among income tax accounts, net liabilities and goodwill may be subject to change.

[0000068505-25-000040:notes:184]
[same as prior period, unchanged from 0000068505-25-000024:notes:170]

[0000068505-25-000040:notes:185]
[same as prior period, unchanged from 0000068505-25-000024:notes:171]

[0000068505-25-000040:notes:186]
[same as prior period, unchanged from 0000068505-25-000024:notes:172]

[0000068505-25-000040:notes:187]
[same as prior period, unchanged from 0000068505-25-000024:notes:173]

[0000068505-25-000040:notes:188]
|  | June 28, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Developed technology | $ | 1,351 |  |  | $ | 584 |  |  | $ | 1,226 |  |  | $ | 535 |  |
| Customer-related | 1,735 |  |  | 1,186 |  |  | 1,609 |  |  | 1,093 |  |
| Other intangibles | 128 |  |  | 83 |  |  | 118 |  |  | 76 |  |
|  | $ | 3,214 |  |  | $ | 1,853 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000040:notes:189]
Amortization expense on intangible assets was $39 million and $76 million for the three and six months ended June 28, 2025, respectively. Amortization expense on intangible assets was $36 million and $76 million for the three and six months ended June 29, 2024, respectively. As of June 28, 2025, annual amortization expense is estimated to be $154 million in 2025, $148 million in 2026, $138 million in 2027, $137 million in 2028, $125 million in 2029 and $122 million in 2030.

[0000068505-25-000040:notes:190]
[same as prior period, unchanged from 0000068505-25-000024:notes:176]

[0000068505-25-000040:notes:191]
|  | June 28, 2025 |  | December 31, 2024 |
|  | GrossCarryingAmount |  | AccumulatedAmortization |  | GrossCarryingAmount |  | AccumulatedAmortization |
| Products and Systems Integration | $ | 1,019 |  |  | $ | 446 |  |  | $ | 1,017 |  |  | $ | 409 |  |
| Software and Services | 2,195 |  |  | 1,407 |  |  | 1,936 |  |  | 1,295 |  |
|  | $ | 3,214 |  |  | $ | 1,853 |  |  | $ | 2,953 |  |  | $ | 1,704 |  |

[0000068505-25-000040:notes:192]
[same as prior period, unchanged from 0000068505-25-000024:notes:178]

[0000068505-25-000040:notes:193]
The Company performed its annual assessment of goodwill for impairment as of the last day of the third quarter. The following table displays a roll-forward of the carrying amount of goodwill by segment from January 1, 2025 to June 28, 2025:

[0000068505-25-000040:notes:194]
|  | Products and Systems Integration |  | Software and Services |  | Total |
| Balance as of January 1, 2025 | $ | 1,573 |  |  | $ | 1,953 |  |  | $ | 3,526 |  |
| Goodwill acquired | — |  |  | 288 |  |  | 288 |  |
| Purchase accounting adjustments | — |  |  | (3) |  |  | (3) |  |
| Foreign currency | 3 |  |  | 26 |  |  | 29 |  |
| Balance as of June 28, 2025 | $ | 1,576 |  |  | $ | 2,264 |  |  | $ | 3,840 |  |
