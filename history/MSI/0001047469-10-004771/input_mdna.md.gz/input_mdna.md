# MSI MD&A — 0001047469-10-004771


## mdna

[0001047469-10-004771:mdna:1]
Item 2. Management's Discussion and Analysis of Financial Condition and Results of Operations

[0001047469-10-004771:mdna:2]
This commentary should be read in conjunction with Motorola, Inc.'s (the "Company's") condensed consolidated
financial statements for the three months ended April 3, 2010 and April 4, 2009, as well as the Company's consolidated financial statements and related notes thereto and management's
discussion and analysis of financial condition and results of operations in the Company's Annual Report on Form 10-K for the year ended December 31, 2009.

[0001047469-10-004771:mdna:3]
Executive Overview

[0001047469-10-004771:mdna:4]
What businesses are we in?

[0001047469-10-004771:mdna:5]
The Company reports financial results for the following operating business segments:

[0001047469-10-004771:mdna:6]
•

[0001047469-10-004771:mdna:7]
The Mobile Devices segment designs, manufactures, sells and services
wireless handsets, including smartphones, with integrated software and accessory products, and licenses intellectual property. In the first quarter of 2010, the segment's net sales were
$1.6 billion, representing 33%* of the Company's consolidated net sales.

[0001047469-10-004771:mdna:8]
•

[0001047469-10-004771:mdna:9]
The Home segment designs, manufactures, sells, installs and services
digital video, Internet Protocol ("IP") video and broadcast network interactive set-tops ("digital entertainment devices"), end-to-end video distribution systems,
broadband access infrastructure platforms, and associated data and voice customer premise equipment ("broadband gateways") to cable television and telecom service providers. In the first quarter of
2010, the segment's net sales were $838 million, representing 17%* of the Company's consolidated net sales.

[0001047469-10-004771:mdna:10]
•

[0001047469-10-004771:mdna:11]
The Enterprise Mobility Solutions segment designs, manufactures, sells,
installs and services analog and digital two-way radios, wireless LAN and security products, voice and data communications products and systems for private networks, wireless broadband
systems and end-to-end enterprise mobility solutions to a wide range of customers, including government and public safety agencies (which, together with all sales to
distributors of two-way communication products, are referred to as the "government and public safety market"), as well as retail, energy and utilities, transportation, manufacturing,
healthcare and other commercial customers (which, collectively, are referred to as the "commercial enterprise market"). In the first quarter of 2010, the segment's net sales were $1.7 billion,
representing 34%* of the Company's consolidated net sales.

[0001047469-10-004771:mdna:12]
•

[0001047469-10-004771:mdna:13]
The Networks segment designs, manufactures, sells, installs and services
wireless network systems, including cellular infrastructure systems and wireless and cellular broadband systems, to wireless service providers. In the first quarter of 2010, the segment's net sales
were $896 million, representing 18%* of the Company's consolidated net sales.

[0001047469-10-004771:mdna:14]
First Quarter Summary

[0001047469-10-004771:mdna:15]
•

[0001047469-10-004771:mdna:16]
Net Sales were $5.0 Billion:  Our net sales were
$5.0 billion in the first quarter of 2010, down 6% compared to net sales of $5.4 billion in the first quarter of 2009. Compared to the year-ago quarter, net sales decreased
18% in the Home segment, decreased 9% in the Mobile Devices segment and decreased 7% in the Networks segment, partially offset by a 6% increase in net sales in the Enterprise Mobility Solutions
segment.

[0001047469-10-004771:mdna:17]
•

[0001047469-10-004771:mdna:18]
Operating Earnings were $76 Million:  We had
operating earnings of $76 million in the first quarter of 2010, compared to an operating loss of $449 million in the first quarter of 2009. Operating margin was 1.5% of net sales in the
first quarter of 2010, compared to (8.4)% of net sales in the first quarter of 2009.

[0001047469-10-004771:mdna:19]
*

[0001047469-10-004771:mdna:20]
When discussing the net sales of each of our four segments, we express the segment's net sales as a percentage of the
Company's consolidated net sales. However, certain of our segments sell products to other Motorola businesses and intracompany sales are eliminated as part of the consolidation process. Therefore, the
percentages of consolidated net sales for our business segments do not always sum to 100%.

[0001047469-10-004771:mdna:21]
| 30 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:22]
•

[0001047469-10-004771:mdna:23]
Earnings from Continuing Operations were $69 Million, or $0.03 per
Share: We had net earnings from continuing operations of $69 million, or $0.03 per diluted common share, in the first quarter of 2010, compared to a net loss from
continuing operations of $291 million, or $0.13 per diluted common share, in the first quarter of 2009.

[0001047469-10-004771:mdna:24]
•

[0001047469-10-004771:mdna:25]
Operating Cash Flow was $485 Million:  We generated
cash from operating activities of $485 million in the first quarter of 2010, compared to using $1.0 billion of cash for operating activities in the first quarter of 2009. The cash
generated from operating activities was primarily driven by: (i) a $411 million decrease in accounts receivable, (ii) income from continuing operations (adjusted for
non-cash items) of $262 million, and (iii) a $114 million decrease in other current assets, partially offset by a $388 million decrease in accounts payable and
accrued liabilities.

[0001047469-10-004771:mdna:26]
Highlights
for each of our business segments were as follows:

[0001047469-10-004771:mdna:27]
•

[0001047469-10-004771:mdna:28]
In Mobile Devices:  Net sales were $1.6 billion in
the first quarter of 2010, a decrease of 9% compared to net sales of $1.8 billion in the first quarter of 2009. The decrease in net sales was primarily driven by a 42% decrease in unit
shipments, partially offset by a 57% increase in average selling price ("ASP"). We shipped 8.5 million handsets in the first quarter of 2010, a 29% decrease sequentially compared to shipments
of 12.0 million handsets in the fourth quarter of 2009. We shipped 2.3 million Android-based smartphones in the first quarter of 2010, a 15% increase sequentially compared to shipments
of 2.0 million in the fourth quarter of 2009. On a geographic basis, net sales decreased in Latin America, Asia, and the Europe, Middle East and Africa region ("EMEA"), partially offset by
increased net sales in North America.

[0001047469-10-004771:mdna:29]
•

[0001047469-10-004771:mdna:30]
In Home:  Net sales were $838 million in the first
quarter of 2010, a decrease of 18% compared to net sales of $1.0 billion in the first quarter of 2009. The decrease in net sales in the Home segment was primarily driven by a 33% decrease in
net sales of digital entertainment devices, reflecting a 29% decrease in shipments of digital entertainment devices to 3.1 million units, partially offset by higher net sales of video and
access networks infrastructure equipment. On a geographic basis, net sales decreased in North America and Asia, partially offset by increased sales in Latin America and EMEA.

[0001047469-10-004771:mdna:31]
•

[0001047469-10-004771:mdna:32]
In Enterprise Mobility Solutions:  Net sales were
$1.7 billion in the first quarter of 2010, an increase of 6% compared to net sales of $1.6 billion in the first quarter of 2009. The increase in net sales reflects a 15% increase in net
sales to the commercial enterprise market and a 3% increase in net sales to the government and public safety market. On a geographic basis, net sales increased in all regions.

[0001047469-10-004771:mdna:33]
•

[0001047469-10-004771:mdna:34]
In Networks:  Net sales were $896 million in the
first quarter of 2010, a decrease of 7% compared to net sales of $966 million in the first quarter of 2009. The 7% decrease in net sales in the Networks segment was primarily driven by lower
net sales of GSM, CDMA and iDEN infrastructure equipment, partially offset by higher net sales of WiMAX products. On a geographic basis, net sales decreased substantially in EMEA, partially offset by
increased sales in Asia, North America and Latin America.

[0001047469-10-004771:mdna:35]
Looking Forward

[0001047469-10-004771:mdna:36]
In February 2010, the Company announced its updated plan for separating into two independent, publicly traded
companies. The Company is now targeting the completion of the planned
separation for the first quarter of 2011. After completing the separation, one company is expected to be comprised of the Mobile Devices and Home businesses and one company is expected to be comprised
of the Enterprise Mobility Solutions and Networks businesses. The Company intends to effect the separation through a tax-free stock dividend of shares in the new company to Motorola
shareholders. The Company expects that, post-separation, the Enterprise Mobility and Networks business will be capitalized in a manner that will achieve an investment grade
long-term debt rating and that it will be the entity responsible for Motorola's public market debt outstanding at the time of separation. Completion of the spin-off is subject
to a number of conditions, including, among others, confirmation of the tax-free nature of the transaction, as well as effectiveness of a Form 10 registration statement to be filed
with the U.S. Securities and Exchange Commission.

[0001047469-10-004771:mdna:37]
In
our Mobile Devices business, we expect the overall global handset market to remain intensely competitive. We expect an increase in total industry handset demand in 2010 compared to
2009, particularly in smartphones. Our strategy is focused on enhancing our smartphone portfolio and strengthening our position in priority markets. We plan to launch a significant number of new
smartphone devices with particular focus on: (i) differentiating our products using MOTOBLUR™, our proprietary applications and services suite,

[0001047469-10-004771:mdna:38]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 31 |

[0001047469-10-004771:mdna:39]
(ii) enhancing
the ecosystem using our MotoDEV application development program, and (iii) expanding our smartphone portfolio to include lower price tiers and address a wider set of
customers. Our initial market priorities are primarily North America and China. We will expand our priority markets to include Western Europe, other parts of Asia and Latin America in 2011. Our
mid to high-tier feature phone portfolio will be more limited than in the past as we shift resources to the smartphone segment of the market. Feature phone unit volumes, including iDEN, are expected
be lower in 2010 than in 2009. For lower-priced, voice-centric devices, we will partner with original device manufacturers (ODM) to deliver a portfolio to meet certain customer requirements and extend
our brand. With all of these actions, we expect to accelerate our speed to market, provide richer consumer experiences, build our brand and improve our financial performance.

[0001047469-10-004771:mdna:40]
In
our Home business, we continue to hold a market leading position in digital entertainment devices and video infrastructure solutions. In 2010, we expect demand for digital
entertainment devices to contract compared to 2009 due to market conditions, particularly in the U.S. Longer term, growth drivers for the business remain intact, as digital households are expected to
experience annual growth over the next several years, driven by demand for high definition TV, multi-room solutions, 3D TV and advanced interactive services. Analog to digital transitions
are still underway, particularly outside North America, and consumer demand is expected to drive infrastructure needs for more bandwidth, optimized networks and storage, and services. We will leverage
our position in digital entertainment devices and video delivery systems and prioritize our research and development efforts to ensure that we are well positioned for growth when demand levels
recover.

[0001047469-10-004771:mdna:41]
The
combination of the Mobile Devices and Home businesses will allow us to address opportunities resulting from the convergence of mobility, media, computing and the Internet. This
includes demand for innovative smartphone devices, uniform, multi-screen experiences, and interactive personalized user-driven services in the home and on mobile devices. The Mobile Devices and Home
businesses have core strengths in intellectual property, end-to-end solutions, design, operator relationships and a global brand which uniquely positions the combined entity to capitalize on these
opportunities.

[0001047469-10-004771:mdna:42]
In
our Enterprise Mobility Solutions business, we have market leading positions in both mission-critical and business-critical communications solutions for customers around the world.
Many government customers are facing challenging budget environments in 2010 and some may be required to curtail spending. However, we believe that these customers will continue to place a high
priority on mission-critical communications and homeland security products and solutions. Conditions in our commercial enterprise market continue to improve
as the economic recovery gains traction. Demand in this market is expected to grow in 2010 as many of our customers upgrade their technology to improve supply-chain efficiencies, increase productivity
of associates and improve end-customer buying experiences. We believe that our prioritized investments in next-generation products and solutions, our comprehensive portfolio, and market
leadership make our Enterprise Mobility Solutions business well positioned for profitable growth.

[0001047469-10-004771:mdna:43]
In
our Networks business, we expect the overall 2G and 3G wireless infrastructure market to decline in 2010 compared to 2009. However, growth in smartphones and data traffic is driving
continued demand for wireless network expansion and optimization. We will continue to optimize our 2G and 3G businesses while prioritizing investments in next-generation 4G technologies
commensurate with opportunities for profitable growth. In WiMAX, we are building upon a strong portfolio of customers and leveraging our market leadership. In LTE, we will continue to evolve our
competitive radio access network solution while focusing on leading wireless network customers around the world.

[0001047469-10-004771:mdna:44]
We
conduct our business in highly competitive markets, facing both new and established competitors. The markets for many of our products are characterized by rapidly changing
technologies, frequent new product introductions, changing consumer trends, short product life cycles and evolving industry standards. Market disruptions caused by new technologies, the entry of new
competitors, consolidations among our customers and competitors, and changes in regulatory requirements, among other matters, can introduce volatility into our businesses. We face challenging, but
stabilizing, global economic conditions with more limited visibility than historical norms. Meeting all of these challenges requires consistent operational planning and execution and investment in
technology, resulting in innovative products that meet the needs of our customers around the world. As we execute on meeting these objectives, we remain focused on taking the necessary action to
design and deliver differentiated and innovative products and services that will advance the way the world connects by simplifying and personalizing communications and enhancing mobility.

[0001047469-10-004771:mdna:45]
| 32 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:46]
Results of Operations

[0001047469-10-004771:mdna:47]
|  |  | Three Months Ended |  |
| (Dollars in millions, except per share amounts) |  |  | April 3, 2010 |  |  | % of Sales |  |  | April 4, 2009 |  |  | % of Sales |  |
| Net sales |  | $ | 5,044 |  |  |  |  | $ | 5,371 |  |  |  |  |
| Costs of sales |  |  | 3,258 |  |  | 64.6 | % |  | 3,875 |  |  | 72.1 | % |
| Gross margin |  |  | 1,786 |  |  | 35.4 | % |  | 1,496 |  |  | 27.9 | % |
| Selling, general and administrative expenses |  |  | 876 |  |  | 17.4 | % |  | 869 |  |  | 16.2 | % |
| Research and development expenditures |  |  | 757 |  |  | 15.0 | % |  | 847 |  |  | 15.8 | % |
| Other charges |  |  | 77 |  |  | 1.5 | % |  | 229 |  |  | 4.3 | % |
| Operating earnings (loss) |  |  | 76 |  |  | 1.5 | % |  | (449 | ) |  | (8.4 | )% |
| Other income (expense): |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Interest expense, net |  |  | (33 | ) |  | (0.7 | )% |  | (35 | ) |  | (0.6 | )% |
|  | Gains (losses) on sales of investments and businesses, net |  |  | 8 |  |  | 0.2 | % |  | (20 | ) |  | (0.4 | )% |
|  | Other |  |  | 12 |  |  | 0.2 | % |  | 70 |  |  | 1.3 | % |
|  | Total other income (expense) |  |  | (13 | ) |  | (0.3 | )% |  | 15 |  |  | 0.3 | % |
| Earnings (loss) from continuing operations before income taxes |  |  | 63 |  |  | 1.2 | % |  | (434 | ) |  | (8.1 | )% |
| Income tax benefit |  |  | (5 | ) |  | (0.1 | )% |  | (146 | ) |  | (2.7 | )% |
|  |  |  | 68 |  |  | 1.3 | % |  | (288 | ) |  | (5.4 | )% |
| Less: Earnings (loss) attributable to noncontrolling interests |  |  | (1 | ) |  | (0.0 | )% |  | 3 |  |  | 0.0 | % |
| Earnings (loss) from continuing operations* |  |  | 69 |  |  | 1.3 | % |  | (291 | ) |  | (5.4 | )% |
| Earnings from discontinued operations, net of tax |  |  | — |  |  | 0.0 | % |  | 60 |  |  | 1.1 | % |
| Net earnings (loss)* |  | $ | 69 |  |  | 1.3 | % | $ | (231 | ) |  | (4.3 | )% |
| Earnings (loss) per diluted common share: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Continuing operations |  | $ | 0.03 |  |  |  |  | $ | (0.13 | ) |  |  |  |
|  | Discontinued operations |  |  | — |  |  |  |  |  | 0.03 |  |  |  |  |
|  |  | $ | 0.03 |  |  |  |  | $ | (0.10 | ) |  |  |  |

[0001047469-10-004771:mdna:48]
*

[0001047469-10-004771:mdna:49]
Amounts
attributable to Motorola, Inc. common shareholders.

[0001047469-10-004771:mdna:50]
Results of Operations—Three months ended April 3, 2010 compared to three months ended April 4, 2009

[0001047469-10-004771:mdna:51]
Net Sales

[0001047469-10-004771:mdna:52]
Net sales were $5.0 billion in the first quarter of 2010, down 6% compared to net sales of $5.4 billion in the first
quarter of 2009. The decrease in net sales reflects: (i) a $187 million, or 18%, decrease in net sales in the Home segment, (ii) a $160 million, or 9%, decrease in net
sales in the Mobile Devices segment, and (iii) a $70 million, or 7%, decrease in net sales in the Networks segment, partially offset by a $95 million, or 6%, increase in net sales
in the Enterprise Mobility Solutions segment. The 18% decrease in net sales in the Home segment reflects a 33% decrease in net sales of digital entertainment devices, reflecting: (i) a 29%
decrease in shipments of digital entertainment devices to 3.1 million units, and (ii) a lower average selling price ("ASP") due to a product mix shift. The 9% decrease in net sales in
the Mobile Devices segment was primarily driven by a 42% decrease in unit shipments, partially offset by a 57% increase in ASP. The 7% decrease in net sales in the Networks segment was primarily
driven by lower net sales of GSM, CDMA and iDEN infrastructure equipment, partially offset by higher net sales of WiMAX products. The 6% increase in net sales in the Enterprise Mobility Solutions
segment reflects a 15% increase in net sales to the commercial enterprise market and a 3% increase in net sales to the government and public safety market.

[0001047469-10-004771:mdna:53]
Gross Margin

[0001047469-10-004771:mdna:54]
Gross margin was $1.8 billion, or 35.4% of net sales, in the first quarter of 2010, compared to $1.5 billion, or 27.9% of
net sales, in the first quarter of 2009. Gross margin increased in all segments and increased significantly in Mobile Devices. The increase in gross margin in the Mobile Devices segment was primarily
driven

[0001047469-10-004771:mdna:55]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 33 |

[0001047469-10-004771:mdna:56]
by:
(i) a favorable product mix, specifically due to increased volume of smartphone devices, and (ii) lower excess inventory and other related charges in 2010 than in 2009, partially
offset by the 9% decrease in net sales. The increase in gross margin in the Enterprise Mobility Solutions segment was primarily driven by the 6% increase in net sales and a favorable product mix. The
increase in gross margin in the Networks segment was primarily due to favorable product mix, partially offset by the 7% decrease in net sales. The increase in gross margin in the Home segment was
primarily due to a favorable product mix, partially offset by the 18% decrease in net sales.

[0001047469-10-004771:mdna:57]
The
increase in gross margin as a percentage of net sales in the first quarter of 2010 compared to the first quarter of 2009 reflects an increase in gross margin percentage in all
segments. The Company's overall gross margin as a percentage of net sales is impacted by the proportion of overall net sales generated by its various businesses.

[0001047469-10-004771:mdna:58]
Selling, General and Administrative Expenses

[0001047469-10-004771:mdna:59]
Selling, general and administrative ("SG&A") expenses increased 1% to $876 million, or 17.4% of net sales, in the first quarter
of 2010, compared to $869 million, or 16.2% of net sales, in the first quarter of 2009. The increase in SG&A expenses reflects: (i) higher SG&A expenses in the Enterprise Mobility
Solutions segment, and (ii) slightly higher SG&A expenses in the Home and the Networks segments, partially offset by lower SG&A expenses in the Mobile Devices segment. The increase in the
Enterprise Mobility Solutions segment was primarily due to increased selling and marketing expenses related to the increase in net sales. The decrease in the Mobile Devices segment was primarily
driven by savings from cost-reduction initiatives. SG&A expenses as a percentage of net sales increased in the Home, Networks and Mobile Devices segments and decreased in the Enterprise
Mobility Solutions segment.

[0001047469-10-004771:mdna:60]
Research and Development Expenditures

[0001047469-10-004771:mdna:61]
Research and development ("R&D") expenditures decreased 11% to $757 million, or 15.0% of net sales, in the first quarter of
2010, compared to $847 million, or 15.8% of net sales, in the first quarter of 2009. The decrease in R&D expenditures reflects lower R&D expenditures in all segments, primarily due to savings
from cost-reduction initiatives. R&D expenditures as a percentage of net sales decreased in the Mobile Devices, Enterprise Mobility Solutions and Networks segments and increased in the
Home segment. The Company participates in very competitive industries with constant changes in technology and, accordingly, the Company continues to believe that a strong commitment to R&D is required
to drive long-term growth.

[0001047469-10-004771:mdna:62]
Other Charges

[0001047469-10-004771:mdna:63]
The Company recorded net charges of $77 million in Other charges in the first quarter of 2010, compared to net charges of
$229 million in the first quarter of 2009. The charges in the first quarter of 2010 included: (i) $65 million of charges relating to the amortization of intangibles,
(ii) $25 million of separation-related transaction costs, and (iii) $16 million of net reorganization of business charges included in Other charges, partially offset by a
$29 million gain related to a legal settlement. The charges in the first quarter of 2009 include: (i) $158 million of net reorganization of business charges included in Other
charges, and (ii) $71 million of charges relating to the amortization of intangibles. The net reorganization of business charges are discussed in further detail in the "Reorganization of
Businesses" section.

[0001047469-10-004771:mdna:64]
Net Interest Expense

[0001047469-10-004771:mdna:65]
Net interest expense was $33 million in the first quarter of 2010, compared to net interest expense of $35 million in the
first quarter of 2009. Net interest expense in the first quarter of 2010 included interest expense of $61 million, partially offset by interest income of $28 million. Net interest
expense in the first quarter of 2009 included interest expense of $62 million, partially offset by interest income of $27 million. The decrease in net interest expense is primarily
attributable to reduced debt levels. Interest income was affected by a decrease in interest rate yields offset by interest received in connection with a tax refund.

[0001047469-10-004771:mdna:66]
Gains (Losses) on Sales of Investments and Businesses

[0001047469-10-004771:mdna:67]
Gains on sales of investments and businesses were $8 million in the first quarter of 2010, compared to a loss on sales of
investments and businesses of $20 million in the first quarter of 2009. In the first quarter of 2010, the net gain was primarily comprised of gains related to sales of certain of the Company's
equity investments. In the first quarter of 2009, the net loss primarily related to a loss on the sale of a business.

[0001047469-10-004771:mdna:68]
| 34 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:69]
[same as prior period, unchanged from 0000950123-09-057013:mdna:58]

[0001047469-10-004771:mdna:70]
Net Other income was $12 million in the first quarter of 2010, compared to net Other income of $70 million in the first
quarter of 2009. The net Other income in the first quarter of 2010 was primarily comprised of: (i) a $16 million gain from Sigma Fund investments, and (ii) $3 million of
foreign currency gains, partially offset by $9 million of investment impairments. Net Other income in the first quarter of 2009 was primarily comprised of: (i) a $67 million gain
related to the extinguishment of a portion of the Company's outstanding long-term debt, (ii) a $7 million gain from Sigma Fund investments, and (iii) $6 million
of foreign currency gains, partially offset by $7 million of investment impairments.

[0001047469-10-004771:mdna:71]
Effective Tax Rate

[0001047469-10-004771:mdna:72]
The Company recorded $5 million of net tax benefits in the first quarter of 2010, resulting in a negative effective tax rate of
(8)%, compared to $146 million of net tax benefits in the first quarter of 2009, resulting in an effective tax rate of 34%. The Company's effective tax rate in the first quarter of 2010 was
lower than the U.S. statutory tax rate of 35% primarily due to a reduction in unrecognized tax benefits for facts that now indicate the extent to which certain tax positions are
more-likely-than-not of being sustained, partially offset by: (i) a non-cash tax charge related to the Medicare Part D subsidy tax law
change enacted during the period, and (ii) certain separation-related transaction costs incurred for which the Company recorded no tax benefit.

[0001047469-10-004771:mdna:73]
The
Company's effective tax rate will change from period to period based on non-recurring events, such as the settlement of income tax audits, changes in valuation allowances
and the tax impact of significant unusual or extraordinary items, as well as recurring factors including changes in the geographic mix of income before taxes and effects of various global income tax
strategies.

[0001047469-10-004771:mdna:74]
Earnings (Loss) from Continuing Operations

[0001047469-10-004771:mdna:75]
The Company had net earnings from continuing operations before income taxes of $63 million in the first quarter of 2010,
compared with a net loss from continuing operations before income taxes of $434 million in the first quarter of 2009. After taxes, and excluding Earnings (loss) attributable to noncontrolling
interests, the Company had net earnings from continuing operations of $69 million, or $0.03 per diluted share, in the first quarter of 2010, compared to a net loss from continuing operations of
$291 million, or $0.13 per diluted share, in the first quarter of 2009.

[0001047469-10-004771:mdna:76]
The
improvement in the earnings (loss) from continuing operations before income taxes in the first quarter of 2010 compared to the first quarter of 2009 was primarily attributable to:
(i) a $290 million increase in gross margin, (ii) a $152 million decrease in Other charges, (iii) a $90 million decrease in R&D expenditures, and
(iv) a $28 million increase in gains on the sale of investments and businesses. These factors were partially offset by: (i) a $58 million decrease in net Other income, and
(ii) a $7 million increase in SG&A expenses.

[0001047469-10-004771:mdna:77]
Earnings from Discontinued Operations

[0001047469-10-004771:mdna:78]
During the first quarter of 2009, the Company completed the sales of: (i) Good Technology, and (ii) the Company's former
biometrics business unit, which included its Printrak trademark. After
taxes, the Company had earnings from discontinued operations of $60 million, or $0.03 per diluted share, in the first quarter of 2009.

[0001047469-10-004771:mdna:79]
Reorganization of Businesses

[0001047469-10-004771:mdna:80]
The Company maintains a formal Involuntary Severance Plan (the "Severance Plan"), which permits the Company to offer eligible employees
severance benefits based on years of service and employment grade level in the event that employment is involuntarily terminated as a result of a reduction-in-force or
restructuring. The Company recognizes termination benefits based on formulas per the Severance Plan at the point in time that future settlement is probable and can be reasonably estimated based on
estimates prepared at the time a restructuring plan is approved by management. Exit costs consist of future minimum lease payments on vacated facilities and other contractual terminations. At each
reporting date, the Company evaluates its accruals for employee separation and exit costs to ensure the accruals are still appropriate. In certain circumstances, accruals are no longer needed because
of efficiencies in carrying out the plans or because employees previously identified for separation resigned from the Company and did not receive severance or were redeployed due to circumstances not
foreseen when the original plans were initiated. In these cases, the Company reverses accruals through the consolidated statements of operations where the original charges were recorded when it is
determined they are no longer needed.

[0001047469-10-004771:mdna:81]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 35 |

[0001047469-10-004771:mdna:82]
The
Company expects to realize cost-saving benefits of approximately $36 million during the remaining nine months of 2010 from the plans that were initiated during the
first quarter of 2010, representing: (i) $19 million of savings in R&D expenditures, (ii) $10 million of savings in SG&A expenses, and (iii) $7 million of
savings in Costs of sales. Beyond 2010, the Company expects the reorganization plans initiated during the first quarter of 2010 to provide annualized cost savings of approximately $54 million,
representing: (i) $28 million of savings in R&D expenditures, (ii) $16 million of savings in SG&A expenses, and (iii) $10 million of savings in Cost of sales.

[0001047469-10-004771:mdna:83]
2010 Charges

[0001047469-10-004771:mdna:84]
During the first quarter of 2010, the Company continued to implement various productivity improvement plans aimed at achieving
long-term, sustainable profitability by driving efficiencies and reducing operating costs. All four of the Company's business segments are impacted by these plans, with the majority of the
impact in the Mobile Devices segment. The employees affected are located in all geographic regions.

[0001047469-10-004771:mdna:85]
During
the first quarter of 2010, the Company recorded net reorganization of business charges of $21 million, including $5 million of charges in Costs of sales and
$16 million of charges under Other charges in the Company's
consolidated statements of operations. Included in the aggregate $21 million are charges of $32 million for employee separation costs, partially offset by $11 million of reversals
for accruals no longer needed.

[0001047469-10-004771:mdna:86]
The
following table displays the net charges incurred by business segment:

[0001047469-10-004771:mdna:87]
| (Dollars in millions) |  |  | Three Months Ended April 3, 2010 |  |
| Mobile Devices |  | $ | 15 |  |
| Home |  |  | 5 |  |
| Enterprise Mobility Solutions |  |  | 2 |  |
| Networks |  |  | 1 |  |
|  |  |  | 23 |  |
| Corporate |  |  | (2 | ) |
|  |  | $ | 21 |  |

[0001047469-10-004771:mdna:88]
The
following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2010 to
April 3, 2010:

[0001047469-10-004771:mdna:89]
| (Dollars in millions) |  |  | Accruals at January 1, 2010 |  |  | Additional Charges |  |  | Adjustments |  |  | Amount Used |  |  | Accruals at April 3, 2010 |  |
| Exit costs |  | $ | 58 |  | $ | — |  | $ | (3 | ) | $ | (5 | ) | $ | 50 |  |
| Employee separation costs |  |  | 80 |  |  | 32 |  |  | (9 | ) |  | (46 | ) |  | 57 |  |
|  |  | $ | 138 |  | $ | 32 |  | $ | (12 | ) | $ | (51 | ) | $ | 107 |  |

[0001047469-10-004771:mdna:90]
Adjustments include translation adjustments.

[0001047469-10-004771:mdna:91]
Exit Costs

[0001047469-10-004771:mdna:92]
At January 1, 2010, the Company had an accrual of $58 million for exit costs attributable to lease terminations. The
additional 2010 charges were not material. The adjustments of $3 million primarily reflect reversals of accruals no longer needed. The $5 million used in 2010 reflects cash payments. The
remaining accrual of $50 million, which is included in Accrued liabilities in the Company's condensed consolidated balance sheets at April 3, 2010, represents future cash payments,
primarily for lease termination obligations.

[0001047469-10-004771:mdna:93]
Employee Separation Costs

[0001047469-10-004771:mdna:94]
At January 1, 2010, the Company had an accrual of $80 million for employee separation costs, representing the severance
costs for: (i) severed employees who began receiving payments in 2009, and (ii) approximately 1,200 employees who will begin receiving payments in 2010. The 2010 additional charges of
$32 million

[0001047469-10-004771:mdna:95]
| 36 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:96]
represent
severance costs for approximately an additional 700 employees, of which 100 are direct employees and 600 are indirect employees.

[0001047469-10-004771:mdna:97]
The
adjustments of $9 million reflect: (i) $8 million of reversals of accruals no longer needed, and (ii) $1 million of translation adjustments.

[0001047469-10-004771:mdna:98]
During
the first three months of 2010, approximately 500 employees, of which 100 were direct employees and 400 were indirect employees, were separated from the Company. The
$46 million used in 2010 reflects cash payments to separated employees. The remaining accrual of $57 million, which is included in Accrued liabilities in the Company's condensed
consolidated balance sheets at April 3, 2010, is expected to be paid to approximately 1,200 separated employees in 2010.

[0001047469-10-004771:mdna:99]
2009 Charges

[0001047469-10-004771:mdna:100]
During the first quarter of 2009, the Company committed to implement various productivity improvement plans aimed at achieving
long-term, sustainable profitability by driving efficiencies and reducing operating costs. All four of the Company's business segments, as well as corporate
functions, were impacted by these plans, with the majority of the impact in the Mobile Devices segment. The employees affected were located in all regions. During the first quarter of 2009, the
Company recorded net reorganization of business charges of $204 million, including $46 million of charges in Costs of sales and $158 million of charges under Other charges in the
Company's condensed consolidated statements of operations. Included in the aggregate $204 million were charges of $204 million for employee separation costs, $4 million for exit
costs and $17 million for fixed asset impairment charges, partially offset by $21 million of reversals for accruals no longer needed.

[0001047469-10-004771:mdna:101]
The
following table displays the net charges incurred by business segment:

[0001047469-10-004771:mdna:102]
| (Dollars in millions) |  |  | Three Months Ended April 4, 2009 |  |
| Mobile Devices |  | $ | 128 |  |
| Home |  |  | 10 |  |
| Enterprise Mobility Solutions |  |  | 30 |  |
| Networks |  |  | 11 |  |
|  |  |  | 179 |  |
| Corporate |  |  | 25 |  |
|  |  | $ | 204 |  |

[0001047469-10-004771:mdna:103]
The
following table displays a rollforward of the reorganization of businesses accruals established for exit costs and employee separation costs from January 1, 2009 to
April 4, 2009:

[0001047469-10-004771:mdna:104]
| (Dollars in millions) |  |  | Accruals at January 1, 2009 |  |  | Additional Charges |  |  | Adjustments |  |  | Amount Used |  |  | Accruals at April 4, 2009 |  |
| Exit costs |  | $ | 80 |  | $ | 4 |  | $ | (5 | ) | $ | (27 | ) | $ | 52 |  |
| Employee separation costs |  |  | 170 |  |  | 204 |  |  | (20 | ) |  | (148 | ) |  | 206 |  |
|  |  | $ | 250 |  | $ | 208 |  | $ | (25 | ) | $ | (175 | ) | $ | 258 |  |

[0001047469-10-004771:mdna:105]
Includes translation adjustments.

[0001047469-10-004771:mdna:106]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 37 |

[0001047469-10-004771:mdna:107]
Exit Costs

[0001047469-10-004771:mdna:108]
At January 1, 2009, the Company had an accrual of $80 million for exit costs attributable to lease terminations. The 2009
additional charges of $4 million primarily related to the exit of leased facilities and contractual termination costs, both within the Mobile Devices segment. The adjustments of
$5 million reflected: (i) $3 million of reversals of accruals no longer needed, and (ii) $2 million of translation adjustments. The $27 million used in 2009
reflected cash payments. The remaining accrual of $52 million, which is included in Accrued liabilities in the Company's condensed consolidated balance sheets at April 4, 2009,
represented future cash payments primarily for lease termination obligations.

[0001047469-10-004771:mdna:109]
Employee Separation Costs

[0001047469-10-004771:mdna:110]
At January 1, 2009, the Company had an accrual of $170 million for employee separation costs, representing the severance
costs for approximately 2,000 employees. The 2009 additional charges of $204 million represented severance costs for approximately an additional 5,600 employees, of which 2,000 were direct
employees and 3,600 were indirect employees.

[0001047469-10-004771:mdna:111]
The
adjustments of $20 million reflect: (i) $18 million of reversals of accruals no longer needed, and (ii) $2 million of translation adjustments.

[0001047469-10-004771:mdna:112]
During
the first quarter of 2009, approximately 5,100 employees, of which 2,100 were direct employees and 3,000 were indirect employees, were separated from the Company. The
$148 million used in 2009 reflected cash payments to separated employees. The remaining accrual of $206 million, was included in Accrued liabilities in the Company's condensed
consolidated balance sheets at April 4, 2009.

[0001047469-10-004771:mdna:113]
Liquidity and Capital Resources

[0001047469-10-004771:mdna:114]
As highlighted in the condensed consolidated statements of cash flows, the Company's liquidity and available capital
resources are impacted by four key components: (i) cash and cash equivalents, (ii) operating activities, (iii) investing activities, and (iv) financing activities.

[0001047469-10-004771:mdna:115]
Cash and Cash Equivalents

[0001047469-10-004771:mdna:116]
The Company's cash and cash equivalents (which are highly-liquid investments with an original maturity of three months or less) were
$3.2 billion at April 3, 2010, compared to $2.9 billion at December 31, 2009. At April 3, 2010, $596 million of this amount was held in the U.S. and
$2.6 billion was held by the Company or its subsidiaries in other countries. At April 3, 2010, restricted cash was $215 million (including $150 million held outside the
U.S.), compared to $206 million (including $143 million held outside the U.S.) at December 31, 2009.

[0001047469-10-004771:mdna:117]
The
Company continues to analyze and review various repatriation strategies to continue to efficiently repatriate funds. During the first three months of 2010, the Company repatriated
$221 million in funds to the U.S. from international jurisdictions with minimal cash tax cost. The Company has approximately $2.0 billion of earnings in foreign subsidiaries that are not
permanently reinvested and may be repatriated without additional U.S. federal income tax charges to the Company's condensed consolidated statements of operations, given the U.S. Federal tax provisions
previously accrued on undistributed earnings and the utilization of available foreign tax credits. On a cash basis, these repatriations from the Company's non-U.S. subsidiaries could
require the payment of additional foreign taxes. While the Company regularly repatriates funds and a portion of offshore funds can be repatriated with minimal adverse financial impact, repatriation of
some of these funds could be subject to delay for local country approvals and could have potential adverse tax consequences.

[0001047469-10-004771:mdna:118]
Operating Activities

[0001047469-10-004771:mdna:119]
In the first three months of 2010, the cash provided by operating activities was $485 million, compared to $1.0 billion
of cash used for operating activities in the first three months of 2009. The primary contributors to the cash provided in the first three months of 2010 were: (i) a $411 million decrease
in accounts receivable, (ii) income from continuing operations (adjusted for net non-cash charges) of $262 million, and (iii) a $114 million decrease in other
current assets, partially offset by a $388 million decrease in accounts payable and accrued liabilities.

[0001047469-10-004771:mdna:120]
| 38 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:121]
Accounts Receivable:     The Company's net accounts receivable were $3.1 billion at April 3, 2010, compared to
$3.5 billion at December 31, 2009, reflecting
the reduction in net sales during the first three months of 2010. Compared to December 31, 2009, net accounts receivable at April 3, 2010 were lower for all segments. The Company's
businesses sell their products in a variety of markets throughout the world and payment terms can vary by market type and geographic location. Accordingly, the Company's levels of net accounts
receivable can be impacted by the timing and level of sales that are made by its various businesses and by the geographic locations in which those sales are made.

[0001047469-10-004771:mdna:122]
As
further described below under "Sales of Receivables," the Company's levels of net accounts receivable can also be impacted by the timing and amount of accounts receivable sold to
third parties, which can vary by period and can be impacted by numerous factors. Total sales of receivables were $463 million during the first quarter of 2010, compared to $259 million
during the first quarter of 2009. Cash proceeds from sales of accounts receivable were $242 million during the quarter of 2010 compared to $259 million during the first quarter of 2009.
As of April 3, 2010, the Company is due $221 million from a third party under deferred payment provisions related to sold accounts receivable.

[0001047469-10-004771:mdna:123]
Total
cash proceeds from sales of accounts receivables were lower in the first quarter of 2010, than in the first quarter of 2009, primarily due to the Company's lower net sales and the
Company's decision to reduce accounts
receivable sales. Additionally, cash proceeds from sales of accounts receivable relative to the gross amount of receivables sold was lower in the first quarter of 2010 as compared to the first quarter
of 2009 due to the impact of new accounting guidance effective in the first quarter of 2010 governing the treatment of sales of receivables and the resulting changes required in the Company's
agreements for sales of receivables.

[0001047469-10-004771:mdna:124]
Inventory:     The Company's net inventory was $1.3 billion at both April 3, 2010, and December 31, 2009. The
slight decrease in the Company's net inventory
was driven by: (i) a substantial decrease in net inventory in the Mobile Devices segment, and (ii) a decrease in net inventory in the Home segment, partially offset by increased net
inventory in the Networks and Enterprise Mobility Solutions segments. The substantial decrease in net inventory in the Mobile Devices segment was due to supply-chain efficiencies and lower sales.
Inventory management continues to be an area of focus as the Company balances the need to maintain strategic inventory levels to ensure competitive delivery performance to its customers against the
risk of inventory excess and obsolescence due to rapidly changing technology and customer spending requirements.

[0001047469-10-004771:mdna:125]
Accounts Payable:     The Company's accounts payable were $2.1 billion at April 3, 2010, compared to $2.4 billion
at December 31, 2009. Accounts payable
decreased in all segments. The Company buys products in a variety of markets throughout the world and payment terms can vary by market type and geographic location. Accordingly, the Company's levels
of accounts payable can be impacted by the timing and level of purchases made by its various businesses and by the geographic locations in which those purchases are made.

[0001047469-10-004771:mdna:126]
Reorganization of Businesses:     The Company has implemented reorganization of businesses plans. Cash payments for employee
severance and exit costs in connection with a number of these plans
were $51 million in the first three months of 2010, as compared to $175 million in the first three months of 2009. Of the $107 million of reorganization of businesses accruals at
April 3, 2010, $57 million relate to employee separation costs and are expected to be paid in 2010. The remaining $50 million in accruals relate to lease termination obligations
that are expected to be paid over a number of years.

[0001047469-10-004771:mdna:127]
Benefit Plan Contributions:     During the first three months of 2010, the Company contributed $20 million to its non-U.S.
plans and made no contributions to its U.S. Regular
Pension Plan. The Company expects to make contributions of approximately $150 million to its U.S. Regular Pension Plan during the remainder of 2010. The Company expects to make additional cash
contributions of approximately $25 million to its non-U.S. plans and no cash contributions to its retiree health care plan during the remainder of 2010.

[0001047469-10-004771:mdna:128]
Investing Activities

[0001047469-10-004771:mdna:129]
Net cash used for investing activities was $163 million in the first three months of 2010, compared to net cash provided of
$1.6 billion in the first three months of 2009. This $1.7 billion decrease was primarily due to: (i) a $1.4 billion decrease in cash received from net sales of Sigma Fund
investments, (ii) a $210 million decrease in proceeds from sales of short-term investments, and (iii) a $115 million decrease in proceeds from sales of
investments and businesses, partially offset by a $25 million increase in proceeds from sales of property, plant and equipment.

[0001047469-10-004771:mdna:130]
Sigma Fund:     The Company and its wholly-owned subsidiaries invest most of their U.S. dollar-denominated cash in a fund (the
"Sigma Fund") that is designed to provide
investment returns similar to a money market fund. The Company purchased $116 million of Sigma Fund investments in the first quarter of 2010, compared to

[0001047469-10-004771:mdna:131]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 39 |

[0001047469-10-004771:mdna:132]
$1.3 billion
in net proceeds received from sales of the Sigma Fund investments in the first quarter of 2009. The aggregate fair value of Sigma Fund investments was $5.3 billion at
April 3, 2010 (including $2.4 billion held by the Company or its subsidiaries outside the U.S.), compared to $5.2 billion at December 31, 2009 (including
$2.3 billion held by the Company or its subsidiaries outside the U.S.).

[0001047469-10-004771:mdna:133]
The
Sigma Fund portfolio is managed by four independent investment management firms. The investment guidelines of the Sigma Fund require that purchased investments must be in
high-quality, investment grade (rated at least A/A-1 by Standard & Poor's or A2/P-1 by Moody's Investors Service), U.S. dollar-denominated debt obligations,
including certificates of deposit, commercial paper, government bonds, corporate bonds and asset- and mortgage-backed securities. Under the Sigma Fund's investment policies, except for debt
obligations of the U.S. government, agencies and government-sponsored enterprises, no more than 5% of the Sigma Fund portfolio is to consist of debt obligations of any one issuer. The Sigma Fund's
investment policies further require that floating rate investments must have a maturity at purchase date that does not exceed thirty-six months with an interest rate that is reset at least
annually. The average interest rate reset of the investments held by the funds must be 120 days or less. The actual average interest rate reset of the portfolio (excluding cash and defaulted
securities) was 16 days at April 3, 2010, compared to 15 days at December 31, 2009.

[0001047469-10-004771:mdna:134]
Investments
in the Sigma Fund are carried at fair value. The Company primarily relies on valuation pricing models and broker quotes to determine the fair value of investments in the
Sigma Fund. The valuation models are developed and maintained by third-party pricing services, and use a number of standard inputs, including benchmark yields, reported trades, broker/dealer quotes
where the counterparty is standing ready and able to transact, issuer spreads, benchmark securities, bids, offers and other reference data. For each asset class, quantifiable inputs related to
perceived market movements and sector news may be considered in addition to the standard inputs.

[0001047469-10-004771:mdna:135]
At
April 3, 2010, $5.2 billion of the Sigma Fund investments were classified as current in the Company's condensed consolidated balance sheets, compared to
$5.1 billion at December 31, 2009. The weighted average maturity of the Sigma Fund investments classified as current was 1 month (excluding cash of $106 million and
defaulted securities) at April 3, 2010, compared to 1 month (excluding cash of $202 million and defaulted securities) at December 31, 2009. At April 3, 2010,
approximately 93% of the Sigma Fund investments were invested in U.S. government, agency and government-sponsored enterprise obligations. This reflects a strategic decision by the Company to
prioritize capital preservation rather than returns.

[0001047469-10-004771:mdna:136]
During
the three months ended April 3, 2010, the Company recorded a gain from the Sigma Fund investments of $16 million in Other income (expense) in the condensed
consolidated statement of operations, compared to a gain from the Sigma Fund investments of $7 million during the three months ended April 4, 2009.

[0001047469-10-004771:mdna:137]
Securities
with a maturity greater than 12 months and defaulted securities have been classified as non-current in the Company's condensed consolidated balance sheets.
At April 3, 2010, $116 million of the Sigma Fund investments were classified as non-current, and the weighted average maturity of the Sigma Fund investments classified as
non-current (excluding defaulted securities) was 82 months. At December 31, 2009, $66 million of the Sigma Fund investments were classified as non-current.

[0001047469-10-004771:mdna:138]
The
Company continuously assesses its cash needs and continues to believe that the balance of cash and cash equivalents, short-term investments and investments in the Sigma
Fund classified as current are more than adequate to meet its current operating requirements over the next twelve months. Therefore, the Company believes it is prudent to hold the $116 million
of securities classified as non-current to maturity.

[0001047469-10-004771:mdna:139]
Strategic Acquisitions and Investments:     The Company used net cash for acquisitions and new investment activities of
$23 million in the first three months of 2010, compared to net cash used of
$15 million in the first three months of 2009. The cash used in the first three months of 2010 and 2009 were for small strategic investments across the Company.

[0001047469-10-004771:mdna:140]
Capital Expenditures:     Capital expenditures were $70 million in the first three months of 2010, compared to
$71 million in the first three months of 2009. The Company's
emphasis when making capital expenditure decisions is to focus on strategic investments driven by customer demand and new design capability.

[0001047469-10-004771:mdna:141]
Sales of Investments and Businesses:     The Company received $22 million in net proceeds from the sales of investments and
businesses in the first three months of 2010, compared to proceeds of
$137 million in the first three months of 2009. The $22 million in proceeds in the first three months of 2010 were primarily comprised of net proceeds related to sales of certain of the
Company's equity investments. The $137 million in proceeds in the first quarter of 2009 was primarily related to the sale of the biometrics business.

[0001047469-10-004771:mdna:142]
| 40 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:143]
Investments:     In addition to available cash and cash equivalents, the Sigma Fund balances (current and non-current) and
short-term investments, the
Company views its investments as an additional source of liquidity. The majority of these securities are available-for-sale and cost-method investments in
technology companies. The fair market values of these securities are subject to substantial price volatility. In addition, the realizable values of these securities are subject to market and other
conditions. At April 3, 2010, the Company's available-for-sale equity securities portfolio had an approximate fair market value of $124 million, which represented
a cost basis of $52 million and a net unrealized gain of $72 million. At December 31, 2009, the Company's available-for-sale equity securities portfolio
had an approximate fair market value of $147 million, comprised of a cost basis of $37 million and a net unrealized gain of $110 million.

[0001047469-10-004771:mdna:144]
Financing Activities

[0001047469-10-004771:mdna:145]
Net cash provided by financing activities was $49 million in the first quarter of 2010, compared to $218 million used in
the first three months of 2009. Cash provided by financing activities in the first quarter of 2010 was primarily comprised of $63 million of cash received from the issuance of common stock in
connection with the Company's employee stock option plans and employee stock purchase plan.

[0001047469-10-004771:mdna:146]
Cash
used for financing activities in the first quarter of 2009 was primarily: (i) $129 million of cash used for the repurchase of debt, (ii) $114 million of
cash used to pay dividends, and (iii) $31 million of net cash used for the repayment of short-term borrowings, partially offset by $56 million of net cash received
from the issuance of common stock in connection with the Company's employee stock option plans and employee stock purchase plan.

[0001047469-10-004771:mdna:147]
Short-Term Debt:     At April 3, 2010, the Company's outstanding notes payable and current portion of long-term debt was
$532 million, compared to
$536 million at December 31, 2009. Net cash used for the repayment of short-term borrowings was $4 million in the first quarter of 2010, compared to repayment of
$31 million of short-term borrowings in the first quarter of 2009.

[0001047469-10-004771:mdna:148]
Long-term Debt:     The Company had $3.4 billion of long-term debt outstanding at both April 3, 2010 and
December 31, 2009.

[0001047469-10-004771:mdna:149]
During
the first quarter of 2009, the Company repurchased $199 million of its outstanding long-term debt for an aggregate purchase price of $133 million,
including $4 million of accrued interest. The $199 million of long-term debt repurchased included principal amounts of: (i) $11 million of the
$358 million then outstanding of 7.50% Debentures due 2025 (the "2025 Debentures"), (ii) $20 million of the $399 million then outstanding of 6.50% Debentures due 2025,
(iii) $14 million of the $299 million then outstanding of 6.50% Debentures due 2028, and (iv) $154 million of the $600 million then outstanding of 6.625%
Senior Notes due 2037. The Company recognized a gain of approximately $67 million related to these open market purchases in Other within Other income (expense) in the consolidated statements of
operations.

[0001047469-10-004771:mdna:150]
The
Company believes that it will be able to maintain sufficient access to the capital markets, though there may be periods of time when access to the capital markets is limited for all
issuers. As a "split rated credit" (as defined below), the Company's ability to issue long-term debt may be limited. The market into which split rated debt is offered can be very volatile
and can be unavailable for periods of time. As a result, it may be more difficult for the Company to quickly access the long-term debt market and any debt issued may be more costly, which
may impact the Company's operating and financial flexibility.

[0001047469-10-004771:mdna:151]
The
Company may from time to time seek to retire certain of its outstanding debt through open market cash purchases, privately-negotiated transactions or otherwise. Such repurchases, if
any, will depend on prevailing market conditions, the Company's liquidity requirements, contractual restrictions and other factors.

[0001047469-10-004771:mdna:152]
Payment of Dividends:     During the first quarter of 2010, the Company did not pay cash dividends to holders of its common
stock. During the first quarter of 2009, the Company paid
$114 million in cash dividends to holders of its common stock, related to the payment of a dividend declared in November 2008. In February 2009, the Company announced that its Board of
Directors suspended the declaration of quarterly dividends on the Company's common stock.

[0001047469-10-004771:mdna:153]
Credit Ratings:     Three independent credit rating agencies, Fitch Ratings ("Fitch"), Moody's Investors Service ("Moody's") and
Standard & Poor's ("S&P"), assign ratings to
the Company's short-term and long-term debt.

[0001047469-10-004771:mdna:154]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 41 |

[0001047469-10-004771:mdna:155]
The
following chart reflects the current ratings assigned to the Company's senior unsecured non-credit enhanced long-term debt and the Company's commercial paper by each of
these agencies.

[0001047469-10-004771:mdna:156]
| Name of Rating Agency |  | Long-Term Debt Rating |  | Commercial Paper Rating |  | Date and Last Actions Taken |
| Fitch |  | BBB- |  | F-3 |  | February 3, 2009, downgraded long-term debt to BBB- (negative outlook) from BBB (negative outlook) and downgraded short-term debt to F-3 (negative outlook) from F-2 (negative outlook). |
| Moody's |  | Baa3 |  | P-3 |  | February 3, 2009, downgraded long-term debt to Baa3 (negative outlook) from Baa2 (review for downgrade) and downgraded short-term debt to P-3 (negative outlook) from P-2 (review for downgrade). |
| S&P |  | BB+ |  | — |  | December 5, 2008, downgraded long-term debt to BB+ (stable outlook) from BBB (credit watch negative) and withdrew the rating on commercial paper. |

[0001047469-10-004771:mdna:157]
Since the Company has investment grade ratings from Fitch and Moody's and a non-investment grade rating from S&P, it is referred to as
a "split rated credit".

[0001047469-10-004771:mdna:158]
Credit Facilities

[0001047469-10-004771:mdna:159]
The Company has a domestic syndicated revolving credit facility (as amended from time to time, the "Credit Facility") that is scheduled
to mature in December 2011. The size of the Credit Facility is the lesser of: (1) $1.5 billion, or (2) an amount determined based on eligible domestic accounts receivable and
inventory. If the Company elects to borrow under the Credit Facility, only then and not before, it would be required to pledge its domestic accounts receivables and, at its option, domestic inventory.
The Credit Facility does not require the Company to meet any financial covenants unless remaining availability under the Credit Facility is less than $225 million. In addition, until borrowings
are made under the Credit Facility, the Company is able to use its working capital assets in any capacity in conjunction with other capital market funding alternatives that may be available to the
Company. The Company has never borrowed under this Credit Facility or predecessor domestic syndicated revolving credit facilities.

[0001047469-10-004771:mdna:160]
Long-term Customer Financing Commitments

[0001047469-10-004771:mdna:161]
Outstanding Commitments:     Certain purchasers of the Company's infrastructure equipment may request
that the Company provide long-term financing (defined as financing with a
term of greater than one year) in connection with the sale of equipment. These requests may include all or a portion of the purchase price of the equipment. The Company's obligation to provide
long-term financing may be conditioned on the issuance of a letter of credit in favor of the Company by a reputable bank to support the purchaser's credit or a pre-existing
commitment from a reputable bank to purchase the long-term receivables from the Company. The Company had outstanding commitments to provide long-term financing to third parties
totaling $443 million at April 3, 2010, compared to $444 million at December 31, 2009. Of these amounts, $10 million was supported by letters of credit or by bank
commitments to purchase long-term receivables at April 3, 2010, compared to $13 million at December 31, 2009. The majority of the outstanding commitments at
April 3, 2010 are to a small number of network operators in the Middle East region. In response to the recent tightening in the credit markets, certain customers of the Company have requested
financing in connection with equipment purchases, and these types of requests have increased in volume and scope.

[0001047469-10-004771:mdna:162]
Guarantees of Third-Party Debt:     In addition to providing direct financing to certain equipment customers, the Company also
assists customers in obtaining financing directly from banks and other
sources to fund equipment purchases. The Company had committed to provide financial guarantees relating to customer financing totaling $30 million and $31 million at April 3, 2010
and December 31, 2009, respectively (including $26 million and $27 million at April 3, 2010 and December 31, 2009, respectively, relating to the sale of
short-term receivables). Customer financing guarantees outstanding were $3 million and $4 million at April 3, 2010 and December 31, 2009, respectively
(including $1 million and $2 million at April 3, 2010 and December 31, 2009, respectively, relating to the sale of short-term receivables).

[0001047469-10-004771:mdna:163]
Outstanding Long-Term Receivables:     The Company had net long-term receivables of $143 million (net of allowances for
losses of $9 million) at April 3, 2010, compared
to net long-term receivables of $145 million (net of allowances for losses of $9 million) at December 31, 2009. These long-term receivables are generally
interest bearing, with interest rates ranging from 4% to 11%.

[0001047469-10-004771:mdna:164]
| 42 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:165]
Sales of Receivables

[0001047469-10-004771:mdna:166]
From time to time, the Company sells accounts receivable and long-term receivables in transactions that qualify as
"true-sales." Certain of these
accounts receivable and long-term receivables are sold to third parties on a one-time, non-recourse basis, while others are sold to third parties under committed
facilities that involve contractual commitments from these parties to purchase qualifying receivables up to an outstanding monetary limit. Committed facilities may be revolving in nature and,
typically, must be renewed annually. The Company may or may not retain the obligation to service the sold accounts receivable and long-term receivables.

[0001047469-10-004771:mdna:167]
At
April 3, 2010, the Company had $200 million of committed revolving facilities for the sale of accounts receivable, of which $54 million was utilized. At
December 31, 2009, the Company had $200 million of committed revolving facilities for the sale of accounts receivable, of which $60 million was utilized.

[0001047469-10-004771:mdna:168]
Total
sales of accounts receivable and long-term receivables were $463 million during the first quarter of 2010, compared to $259 million during the first
quarter of 2009. At April 3, 2010, the Company retained servicing obligations for $380 million of sold accounts receivables and $265 million of long-term receivables
compared to $195 of accounts receivables and $297 million of long-term receivables at December 31, 2009. Cash proceeds from sales of accounts receivable were
$242 million during the first quarter of 2010, compared to $259 million during the first quarter of 2009. As of April 3, 2010, the Company is due $221 million from a third
party under deferred payment provisions related to sold accounts receivable.

[0001047469-10-004771:mdna:169]
Under
certain arrangements, the value of accounts receivable sold is covered by credit insurance purchased from third-party insurance companies, less deductibles or
self-insurance requirements under the insurance policies. The Company's total credit exposure, less insurance coverage, to outstanding accounts receivables that have been sold was
$26 million and $27 million at April 3, 2010 and December 31, 2009, respectively.

[0001047469-10-004771:mdna:170]
Other Contingencies

[0001047469-10-004771:mdna:171]
Potential Contractual Damage Claims in Excess of Underlying Contract Value:     In certain
circumstances, our businesses may enter into contracts with customers pursuant to which the damages that could be claimed by the other party for failed
performance might exceed the revenue the Company receives from the contract. Contracts with these types of uncapped damage provisions are fairly rare, but individual contracts could still represent
meaningful risk. There is a possibility that a damage claim by a counterparty to one of these contracts could result in expenses to the Company that are far in excess of the revenue received from the
counterparty in connection with the contract.

[0001047469-10-004771:mdna:172]
Indemnification Provisions:     In addition, the Company may provide indemnifications for losses that result from the breach of
general warranties contained in certain commercial, intellectual
property and divestiture agreements. Historically, the Company has not made significant payments under these agreements, nor have there been significant claims asserted against the Company. However,
there is an increasing risk in relation to intellectual property indemnities given the current legal climate. In indemnification cases, payment by the Company is conditioned on the other party making
a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. Further, the Company's obligations under
these agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, typically not more than 24 months, and for amounts not in
excess of the contract value, and in some instances the Company may have recourse against third parties for certain payments made by the Company.

[0001047469-10-004771:mdna:173]
Legal Matters:     The Company is a defendant in various lawsuits, claims and actions, which arise in the normal course of
business. In the opinion of management, the ultimate
disposition of these matters will not have a material adverse effect on the Company's consolidated financial position, liquidity or results of operations.

[0001047469-10-004771:mdna:174]
Segment Information

[0001047469-10-004771:mdna:175]
The following commentary should be read in conjunction with the financial results of each reporting segment for the
three months ended April 3, 2010 and April 4, 2009 as detailed in Note 12, "Segment Information," of the Company's condensed consolidated financial statements.

[0001047469-10-004771:mdna:176]
Change in Segment Presentation

[0001047469-10-004771:mdna:177]
On February 11, 2010, the Company announced that it is targeting the first quarter of 2011 for the completion of its planned
separation into two independent, publicly traded companies. The Company currently expects that, upon separation, one public company will be comprised of the Company's Mobile Devices and Home
businesses and the other public company will be comprised of the Company's Enterprise Mobility

[0001047469-10-004771:mdna:178]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 43 |

[0001047469-10-004771:mdna:179]
Solutions
and Networks businesses. As a result of this announcement, Motorola, Inc. has realigned its businesses as of the first quarter of 2010 and now reports financial results for the
following four operating business segments:

[0001047469-10-004771:mdna:180]
•

[0001047469-10-004771:mdna:181]
Mobile
Devices:  This segment designs, manufactures, sells and services wireless handsets, including smartphones, with integrated software and
accessory products, and licenses intellectual property.

[0001047469-10-004771:mdna:182]
•

[0001047469-10-004771:mdna:183]
Home:
  This segment designs, manufactures, sells, installs and services digital video, Internet Protocol video and broadcast network interactive set-tops,
end-to-end video distribution systems, broadband access infrastructure platforms, and associated data and voice customer premise equipment for cable television and telecom
service providers.

[0001047469-10-004771:mdna:184]
•

[0001047469-10-004771:mdna:185]
Enterprise Mobility
Solutions:  This segment designs, manufactures, sells, installs and services analog and digital two-way radios, wireless LAN
and security products, voice and data communications products and systems for private networks, wireless broadband systems and end-to-end enterprise mobility solutions.

[0001047469-10-004771:mdna:186]
•

[0001047469-10-004771:mdna:187]
Networks:  This segment designs, manufactures, sells, installs and services wireless
network systems, including cellular infrastructure systems and wireless and wireline cable and cellular broadband systems, for wireless service providers.

[0001047469-10-004771:mdna:188]
Additionally,
prior to the first quarter of 2010, certain costs, including some elements of share-based compensation, intangible assets amortization expense, business-related asset
impairments and other Corporate expenses, were recorded at Corporate and included in Other and Eliminations. In addition to the business realignment discussed above, effective as of the first quarter
of 2010, the Company now allocates the costs described above to the operating business segments.

[0001047469-10-004771:mdna:189]
Accordingly,
previously reported segment results for the quarterly period ended April 4, 2009, have been revised to reflect the new segment presentation and the allocation of
Corporate costs.

[0001047469-10-004771:mdna:190]
Mobile Devices Segment

[0001047469-10-004771:mdna:191]
|  |  | Three Months Ended |  |  |  |  |
| (Dollars in millions) |  |  | April 3, 2010 |  |  | April 4, 2009 |  |  | % Change |  |
| Segment net sales |  | $ | 1,641 |  | $ | 1,801 |  |  | (9 | )% |
| Operating loss |  |  | (192 | ) |  | (545 | ) |  | (65 | )% |

[0001047469-10-004771:mdna:192]
For
the first quarter of 2010, the segment's net sales represented 33% of the Company's consolidated net sales, compared to 34% in the first quarter of 2009.

[0001047469-10-004771:mdna:193]
Three months ended April 3, 2010 compared to three months ended April 4, 2009

[0001047469-10-004771:mdna:194]
In the first quarter of 2010, the segment's net sales were $1.6 billion, a decrease of 9% compared to net sales of
$1.8 billion in the first quarter of 2009. The 9% decrease in net sales was primarily driven by a 42% decrease in unit shipments, partially offset by a 57% increase in average selling price
("ASP"). The segment's net sales were negatively impacted by a decreased focus on the feature phone portfolio and limited product offerings in the very low-tier, partially offset by higher sales of
smartphones. On a product technology basis, net sales decreased substantially for GSM and iDEN technologies, partially offset by a substantial increase in net sales for 3G and CDMA technologies. On a
geographic basis, net sales decreased in Latin America, Asia, and the Europe, Middle East and Africa region ("EMEA"), partially offset by increased net sales in North America.

[0001047469-10-004771:mdna:195]
The
segment incurred an operating loss of $192 million in the first quarter of 2010, compared to an operating loss of $545 million in the first quarter of 2009. The
decrease in the operating loss was primarily due to an increase in gross margin driven by: (i) a favorable product mix, specifically due to increased sales volume of smartphone devices, and
(ii) lower excess inventory and other related charges in 2010 than in 2009, partially offset by the 9% decrease in net sales. Also contributing to the decrease in the operating loss were:
(i) a lower selling, general and administrative ("SG&A") and research and development ("R&D") expenditures, reflecting savings from cost-reduction initiatives, and (ii) lower
reorganization of business charges. As a percentage of net sales in the first quarter of 2010 as compared to the first quarter of 2009, gross margin and SG&A expenses increased and R&D expenditures
decreased.

[0001047469-10-004771:mdna:196]
Unit
shipments in the first quarter of 2010 were 8.5 million units, a 42% decrease compared to shipments of 14.7 million units in the first quarter of 2009 and a 29%
decrease sequentially compared to shipments of

[0001047469-10-004771:mdna:197]
| 44 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:198]
12.0 million
units in the fourth quarter of 2009. Android-based smartphone shipments in the first quarter of 2010 were 2.3 million, a 15% increase sequentially compared to shipments of
2.0 million in the fourth quarter of 2009.

[0001047469-10-004771:mdna:199]
In
the first quarter of 2010, ASP increased approximately 57% compared to the first quarter of 2009 and increased approximately 26% compared to the fourth quarter of 2009. The increase
in ASP in the first quarter of 2010 as compared to the fourth quarter of 2009 was driven by lower deferred revenue in the first quarter of 2010 and a more favorable product mix. ASP is impacted by
numerous factors, including product mix, market conditions and competitive product offerings, and ASP trends often vary over time.

[0001047469-10-004771:mdna:200]
The
segment's industry typically experiences short life cycles for new products. Therefore, it is vital to the segment's success that new, compelling products are continually introduced.
Accordingly, a strong commitment to R&D is required and, even amidst challenging global economic conditions, the segment will continue to make the appropriate investments to develop a differentiated
product portfolio and fuel long-term growth. In addition, the segment will continue to invest in the Motorola brand though advertising and promotion as we launch new products throughout
the year.

[0001047469-10-004771:mdna:201]
Home Segment

[0001047469-10-004771:mdna:202]
|  |  | Three Months Ended |  |  |  |  |
| (Dollars in millions) |  |  | April 3, 2010 |  |  | April 4, 2009 |  |  | % Change |  |
| Segment net sales |  | $ | 838 |  | $ | 1,025 |  |  | (18 | )% |
| Operating earnings |  |  | 20 |  |  | 3 |  |  | 567 | % |

[0001047469-10-004771:mdna:203]
For
the first quarter of 2010, the segment's net sales represented 17% of the Company's consolidated net sales, compared to 19% for the first quarter of 2009.

[0001047469-10-004771:mdna:204]
Three months ended April 3, 2010 compared to three months ended April 4, 2009

[0001047469-10-004771:mdna:205]
In the first quarter of 2010, the segment's net sales were $838 million, a decrease of 18% compared to net sales of
$1.0 billion in the first quarter of 2009. The 18% decrease in net sales in the Home segment is primarily attributable to (i) a 33% decrease in net sales of digital entertainment
devices, reflecting a 29% decrease in shipments of digital entertainment devices to 3.1 million units, and (ii) a lower ASP due to a product mix shift. The decrease in net sales of
digital entertainment devices was partially offset by higher net sales of video and access infrastructure equipment.

[0001047469-10-004771:mdna:206]
Sales
of standard definition ("SD") set-top units and high definition ("HD") set-top units decreased significantly, primarily due to lower shipments to large
telecommunication and cable operators in North America as a result of lower demand. The decrease in unit shipments of SD and HD set-tops was partially offset by an increase in HD/digital
video recording (together, "HD/DVR") unit shipments due to increased demand for DVR capabilities.

[0001047469-10-004771:mdna:207]
On
a geographic basis, net sales decreased in North America and Asia and increased in Latin America and EMEA. Net sales in North America continued to comprise a significant portion of
the segment's business, accounting for approximately 70% of the segment's net sales in the first quarter of 2010, compared to approximately 76% in the first quarter of 2009.

[0001047469-10-004771:mdna:208]
The
segment had operating earnings of $20 million in the first quarter of 2010, compared to operating earnings of $3 million in the first quarter of 2009. The increase in
operating earnings was primarily due to: (i) a slight increase in gross margin, driven by a favorable product mix, partially offset by the 18% decrease in net sales, and (ii) a decrease
in R&D expenditures, reflecting savings from cost-reduction initiatives. As a percentage of net sales in the first quarter of 2010 as compared the first quarter of 2009, gross margin, SG&A
expenses and R&D expenditures increased.

[0001047469-10-004771:mdna:209]
Enterprise Mobility Solutions Segment

[0001047469-10-004771:mdna:210]
|  |  | Three Months Ended |  |  |  |  |
| (Dollars in millions) |  |  | April 3, 2010 |  |  | April 4, 2009 |  |  | % Change |  |
| Segment net sales |  | $ | 1,694 |  | $ | 1,599 |  |  | 6 | % |
| Operating earnings |  |  | 141 |  |  | 66 |  |  | 114 | % |

[0001047469-10-004771:mdna:211]
For
the first quarter of 2010, the segment's net sales represented 34% of the Company's consolidated net sales, compared to 30% for the first quarter of 2009.

[0001047469-10-004771:mdna:212]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 45 |

[0001047469-10-004771:mdna:213]
Three months ended April 3, 2010 compared to three months ended April 4, 2009

[0001047469-10-004771:mdna:214]
In the first quarter of 2010, the segment's net sales were $1.7 billion, a 6% increase compared to net sales of
$1.6 billion in the first quarter of 2009. The 6% increase in net sales in the Enterprise Mobility Solutions segment reflects a 15% increase in net sales to the commercial enterprise market and
a 3% increase in net sales to the government and public safety market. The increase in net sales for the segment reflects higher net sales in all regions. Net sales in North America continued to
comprise a significant portion of the segment's business, accounting for approximately 57% of the segment's net sales in the first quarter of 2010, compared to approximately 58% in the first quarter
of 2009.

[0001047469-10-004771:mdna:215]
The
segment had operating earnings of $141 million in the first quarter of 2010, compared to operating earnings of $66 million in the first quarter of 2009. The increase in
operating earnings was primarily due to: (i) an increase in gross margin, driven by the 6% increase in net sales and a favorable product mix, and (ii) a decrease in R&D expenditures,
reflecting savings from cost-reduction initiatives. These factors were partially offset by increased SG&A expenses primarily due to increased selling and marketing expenses related to the
increase in net sales. As a percentage of net sales in the first quarter of 2010 as compared to the first quarter of 2009, gross margin increased and R&D expenditures and SG&A expenses decreased.

[0001047469-10-004771:mdna:216]
Networks Segment

[0001047469-10-004771:mdna:217]
|  |  | Three Months Ended |  |  |  |  |
| (Dollars in millions) |  |  | April 3, 2010 |  |  | April 4, 2009 |  |  | % Change |  |
| Segment net sales |  | $ | 896 |  | $ | 966 |  |  | (7 | )% |
| Operating earnings |  |  | 112 |  |  | 62 |  |  | 81 | % |

[0001047469-10-004771:mdna:218]
For
the first quarter of 2010 and the first quarter of 2009, the segment's net sales represented 18% of the Company's consolidated net sales.

[0001047469-10-004771:mdna:219]
Three months ended April 3, 2010 compared to three months ended April 4, 2009

[0001047469-10-004771:mdna:220]
In the first quarter of 2010, the segment's net sales were $896 million, a 7% decrease compared to net sales of
$966 million in the first quarter of 2009. The 7% decrease in net sales in the Networks segment was primarily driven by lower net sales of GSM, CDMA and iDEN infrastructure equipment, partially
offset by higher net sales of WiMAX products.

[0001047469-10-004771:mdna:221]
On
a geographic basis, net sales decreased substantially in EMEA, partially offset by increased net sales in Asia, North America and Latin America. The decrease in net sales in EMEA was
primarily due to lower net sales of GSM infrastructure equipment, partially offset by higher net sales of WiMAX products. The increases in net sales in Asia were both primarily driven by higher net
sales of GSM, UMTS and WiMAX infrastructure equipment, partially offset by lower net sales of CDMA infrastructure equipment. The increase in net sales in North America and Latin America was primarily
due to higher net sales of WiMAX products, partially offset by lower net sales of iDEN infrastructure equipment.

[0001047469-10-004771:mdna:222]
The
segment had operating earnings of $112 million in the first quarter of 2010, compared to operating earnings of $62 million in the first quarter of 2009. The increase in
operating earnings was primarily due to: (i) an increase in gross margin, driven by product mix as well as savings from cost-reduction initiatives, partially offset by the 7%
decrease in net sales, and (ii) a decrease in R&D expenditures, reflecting savings from cost-reduction initiatives. As a percentage of net sales in the first quarter of 2010 as
compared the first quarter of 2009, gross margin and SG&A expenses increased and R&D expenditures decreased.

[0001047469-10-004771:mdna:223]
Significant Accounting Policies

[0001047469-10-004771:mdna:224]
Management's Discussion and Analysis of Financial Condition and Results of Operations discusses the Company's condensed
consolidated financial statements, which have been prepared in accordance with U.S. generally accepted accounting principles. The preparation of these financial statements requires management to make
estimates and assumptions that affect the reported amounts of assets and liabilities and the disclosure of contingent assets and liabilities at the date of the financial statements, as well as the
reported amounts of revenues and expenses during the reporting period.

[0001047469-10-004771:mdna:225]
| 46 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:226]
Management
bases its estimates and judgments on historical experience, current economic and industry conditions and on various other factors that are believed to be reasonable under the
circumstances. This forms the basis for making judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these
estimates under different assumptions or conditions. Management believes the following significant accounting policies require significant judgment and estimates:

[0001047469-10-004771:mdna:227]
—

[0001047469-10-004771:mdna:228]
Revenue recognition

[0001047469-10-004771:mdna:229]
—

[0001047469-10-004771:mdna:230]
Inventory valuation

[0001047469-10-004771:mdna:231]
—

[0001047469-10-004771:mdna:232]
Income taxes

[0001047469-10-004771:mdna:233]
—

[0001047469-10-004771:mdna:234]
Valuation of the Sigma Fund and investment portfolios

[0001047469-10-004771:mdna:235]
—

[0001047469-10-004771:mdna:236]
Restructuring activities

[0001047469-10-004771:mdna:237]
—

[0001047469-10-004771:mdna:238]
Retirement-related benefits

[0001047469-10-004771:mdna:239]
—

[0001047469-10-004771:mdna:240]
Valuation and recoverability of goodwill and long-lived assets

[0001047469-10-004771:mdna:241]
The
following discussion addresses a change in the Company's revenue recognition accounting policy and a development requiring the testing of goodwill for impairment, both during the
first quarter of 2010.

[0001047469-10-004771:mdna:242]
Revenue Recognition

[0001047469-10-004771:mdna:243]
In October 2009, the Financial Accounting Standards Board ("FASB") issued new guidance which amended the accounting standards for
revenue arrangements with multiple deliverables. The new guidance changes the criteria required to separate deliverables into separate units of accounting when they are sold in a bundled arrangement
and requires an entity to allocate an arrangement's consideration using estimated selling prices ("ESP") of deliverables if a vendor does not have vendor-specific objective evidence of selling price
("VSOE") or third-party evidence of selling price ("TPE"). The new guidance also eliminates the use of the residual method to allocate an arrangement's consideration.

[0001047469-10-004771:mdna:244]
In
October 2009, the FASB also issued new guidance to remove from the scope of software revenue recognition guidance tangible products containing software components and
non-software components that function together to deliver the tangible product's essential functionality.

[0001047469-10-004771:mdna:245]
The
new accounting guidance is effective for revenue arrangements entered into or materially modified after June 15, 2010. The standards permit prospective or restrospective
adoption as well as early adoption. The Company elected to early adopt this guidance at the beginning of its first quarter of fiscal 2010 on a prospective basis for applicable transactions that were
entered into or materially modified after January 1, 2010.

[0001047469-10-004771:mdna:246]
The
Company's material revenue streams are the result of a wide range of activities, from the delivery of stand-alone equipment to custom design and installation over a period of time to
bundled sales of equipment, software and services. The Company enters into revenue arrangements that may consist of multiple deliverables of its product and service offerings due to the needs of its
customers. Additionally, many of the Company's products have both software and non-software components that function together to deliver the product's essential functionality. The Company
recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the sales price is fixed or determinable, and collectibility of the sales price is reasonably assured. In
addition to these general revenue recognition criteria, the following specific revenue recognition policies are followed:

[0001047469-10-004771:mdna:247]
Products and Equipment —For product and equipment sales, revenue recognition generally occurs when products or equipment have been shipped,
risk of loss has transferred to the customer,
objective evidence exists that customer acceptance provisions have been met, no significant obligations remain and allowances for discounts, price protection, returns and customer incentives can be
reliably estimated. Recorded revenues are reduced by these allowances. The Company bases its estimates of these allowances on historical experience taking into consideration the type of products sold,
the type of customer, and the specific type of transaction in each arrangement. Where customer incentives cannot be reliably estimated, the Company recognizes revenue at the time the product sells
through the distribution channel to the end customer.

[0001047469-10-004771:mdna:248]
Long-Term Contracts —For long-term contracts that involve customization of the Company's equipment or software, the Company generally
recognizes revenue using the
percentage of completion method based on the

[0001047469-10-004771:mdna:249]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 47 |

[0001047469-10-004771:mdna:250]
percentage
of costs incurred to date compared to the total estimated costs to complete the contract. In certain instances, when revenues or costs associated with long-term contracts cannot
be reliably estimated or the contract contains other inherent uncertainties, revenues and costs are deferred until the project is complete and customer acceptance is obtained. When current estimates
of total contract revenue and contract costs indicate a contract loss, the loss is recognized in the period it becomes evident.

[0001047469-10-004771:mdna:251]
Services —Revenue for services is generally recognized ratably over the contract term as services are performed.

[0001047469-10-004771:mdna:252]
Software and Licenses —Revenue from pre-paid perpetual licenses is recognized at the inception of the arrangement, presuming all other relevant
revenue recognition criteria
are met. Revenue from non-perpetual licenses or term licenses is recognized ratably over the period that the licensee uses the license. Revenue from software maintenance, technical support
and unspecified upgrades is generally recognized over the period that these services are delivered.

[0001047469-10-004771:mdna:253]
Multiple-Element Arrangements —Arrangements with customers may include multiple deliverables, including any combination of products, equipment,
services and software. These multiple element
arrangements could also include an element accounted for as a long-term contract coupled with other products, equipment, services and software. For the Company's multiple-element
arrangements where at least one of the deliverables is not subject to existing software revenue recognition guidance, deliverables are separated into more than one unit of accounting when
(i) the delivered element(s) have value to the customer on a stand-alone basis, and (ii) delivery of the undelivered element(s) is probable and substantially in the control of the
Company. Based on the new accounting guidance adopted January 1, 2010, revenue is then allocated to each unit of accounting based on the relative selling price of each unit of accounting based
first on VSOE if it exists, based next on TPE if VSOE does not exist, and, finally, if both VSOE and TPE do not exist, based on ESP.

[0001047469-10-004771:mdna:254]
•

[0001047469-10-004771:mdna:255]
VSOE—In many instances, products are sold separately in stand-alone arrangements as customers may support the
products themselves or purchase support on a time and materials basis. Additionally, advanced services such as general consulting, network management or advisory projects are often sold in stand-alone
engagements. Technical support services are also often sold separately through renewals of annual contracts. The Company determines VSOE based on its normal pricing and discounting practices for the
specific product or service when sold separately. In determining VSOE, the Company requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow
pricing range, generally evidenced by the pricing rates of approximately 80% of such historical stand-alone transactions falling within plus or minus 15% of the median rate. In addition, the Company
considers the geographies in which the products or services are sold, major product and service groups, customer classification, and other environmental or marketing variables in determining VSOE.

[0001047469-10-004771:mdna:256]
•

[0001047469-10-004771:mdna:257]
TPE—VSOE generally exists only when the Company sells the deliverable separately. When VSOE does not exist,
the Company attempts to determine TPE based on competitor prices for similar deliverables when sold separately. Generally, the Company's go-to-market strategy for many of its
products differs from that of its peers and its offerings contain a significant level of customization and differentiation such that the comparable pricing of products with similar functionality sold
by other companies cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products' selling prices are on a stand-alone basis. Therefore, the Company is
typically not able to determine TPE.

[0001047469-10-004771:mdna:258]
•

[0001047469-10-004771:mdna:259]
ESP—The objective of ESP is to determine the price at which the Company would transact a sale if the product
or service were sold on a stand-alone basis. When both VSOE and TPE do not exist, the Company determines ESP for the arrangement element by first collecting all reasonably available data points
including sales, cost and margin analysis of the product, and other inputs based on the Company's normal pricing practices. Second, the Company makes any reasonably required adjustments to the data
based on market and Company-specific factors. Third, the Company stratifies the data points, when appropriate, based on customer, magnitude of the transaction and sales volume.

[0001047469-10-004771:mdna:260]
Once
elements of an arrangement are separated into more than one unit of accounting, revenue is recognized for each separate unit of accounting based on the nature of the revenue as
described above.

[0001047469-10-004771:mdna:261]
The
Company's arrangements with multiple deliverables may also contain a stand-alone software deliverable that is subject to the existing software revenue recognition guidance. The
revenue for these multiple-element arrangements is allocated to the software deliverable and the non-software deliverable(s) based on the relative selling prices of all of the deliverables
in the arrangement using the hierarchy in the new revenue accounting

[0001047469-10-004771:mdna:262]
| 48 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:263]
guidance.
In circumstances where the Company cannot determine VSOE or TPE of the selling price for all of the deliverables in the arrangement, including the software deliverable, ESP is used for the
purpose of allocating the arrangement consideration.

[0001047469-10-004771:mdna:264]
The
Company's arrangements with multiple deliverables may be comprised entirely of deliverables that are all still subject to the existing software revenue recognition guidance. For
these arrangements, revenue is allocated to the
deliverables based on VSOE. Should VSOE not exist for the undelivered software element, revenue is deferred until either the undelivered element is delivered or VSOE is established for the element,
whichever occurs first. When the fair value of a delivered element has not been established, but fair value exists for the undelivered elements, the Company uses the residual method to recognize
revenue if the fair value of all undelivered elements is determinable. Under the residual method, the fair value of the undelivered elements is deferred and the remaining portion of the arrangement
consideration is allocated to the delivered elements and is recognized as revenue.

[0001047469-10-004771:mdna:265]
Based
on the Company's current sales strategies, the newly adopted accounting guidance for revenue recognition is not expected to have a significant effect on the timing and pattern of
revenue recognition for sales in periods after the initial adoption when applied to multiple-element arrangements, except for the continued impact on smartphone revenue recognition. However, the
Company expects that this new accounting guidance will facilitate the Company's efforts to optimize its product and service offerings due to better alignment of the economics of an arrangement and the
related accounting treatment. This may lead to the Company's engaging in new sales practices in the future. As these go-to-market strategies evolve, the Company may modify its
pricing practices in the future, which could result in changes in selling prices, including both VSOE and ESP. As a result, the Company's future revenue recognition for multiple-element arrangements
could differ materially from the results reported in the current period. The Company is currently unable to determine the impact that the newly adopted accounting guidance for revenue recognition
could have on its reported revenue as these go-to-market strategies evolve.

[0001047469-10-004771:mdna:266]
Changes
in costs estimates and the fair values of certain deliverables could negatively impact the Company's operating results. In addition, unforeseen conditions could arise over the
contract term that may have a significant impact on operating results.

[0001047469-10-004771:mdna:267]
Sales and Use Taxes —The Company records taxes imposed on revenue-producing transactions, including sales, use, value added and excise taxes,
on a net basis with such taxes excluded
from revenue.

[0001047469-10-004771:mdna:268]
Valuation and Recoverability of Goodwill and Long-Lived Assets

[0001047469-10-004771:mdna:269]
Goodwill:     The Company tests the recorded amount of goodwill for recovery on an annual basis in
the fourth quarter of each fiscal year. Goodwill is tested more frequently if
indicators of impairment exist. The Company continually assesses whether any indicators of impairment exist, which requires a significant amount of judgment. Such indicators may include: a sustained
significant decline in our share price and market capitalization; a decline in our expected future cash flows; a significant adverse change in legal factors or in the business climate; unanticipated
competition; the testing for recoverability of a significant asset group within a reporting unit; or slower growth rates, among others. Any adverse change in these factors could have a significant
impact on the recoverability of these assets and could have a material impact on our consolidated financial statements.

[0001047469-10-004771:mdna:270]
The
goodwill impairment test is performed at the reporting unit level. A reporting unit is an operating segment or one level below an operating segment (referred to as a "component"). A
component of an operating segment is a reporting unit if the component constitutes a business for which discrete financial information is available and segment management regularly reviews the
operating results of that component. When two or more components of an operating segment have similar economic characteristics, the components shall be aggregated and deemed a single reporting unit.
An operating segment shall be deemed to be a reporting unit if all of its components are similar, if none of its components is a reporting unit, or if the segment comprises only a single component.

[0001047469-10-004771:mdna:271]
During
the first quarter of 2010, the Company announced that it is targeting the first quarter of 2011 for the completion of its planned separation into two independent, publicly traded
companies. The Company currently expects that, upon separation, one public company will be comprised of the Company's Mobile Devices and Home businesses and the other public company will be comprised
of the Company's Enterprise Mobility Solutions and Networks businesses. As a result of this announcement, Motorola, Inc. has realigned its businesses as of the first quarter of 2010, into the
following four operating business segments: Mobile Devices, Home,

[0001047469-10-004771:mdna:272]
|  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  | 49 |

[0001047469-10-004771:mdna:273]
Enterprise
Mobility Solutions and Networks. Previously, the Home and Networks segments constituted a single segment, the Home and Networks Mobility segment. As a result of this business realignment,
the Company assessed whether there would be any changes to the previously determined reporting units for purposes of assessing goodwill impairment.

[0001047469-10-004771:mdna:274]
The
Company has determined that the new Home segment is comprised of two reporting units, the Broadband Home Solutions reporting unit and the Access Networks reporting unit, both of
which, based on the operational structure of the Home segment, are one level below the Home operating segment and, therefore, constitute a component or reporting unit of the Home segment. The Company
has also determined that the new Networks segment meets the requirements of a reporting unit.

[0001047469-10-004771:mdna:275]
As
a result of the revised determination of reporting units, the Company assessed whether there were any indicators of impairment at the new Broadband Home Solutions and Access Networks
reporting units. Due to differences in historical and forecasted financial performance at Access Networks as compared to Broadband Home Solutions, the Company determined there was a sufficient
indicator of impairment for the Access Networks reporting unit. As a result, a goodwill impairment test was performed for the Access Networks reporting unit during the first quarter of 2010. No
indicators of potential impairment were identified for the Broadband Home Solutions reporting unit or for the Company's other reporting units and, accordingly, the goodwill recorded at these other
reporting units was not tested for impairment.

[0001047469-10-004771:mdna:276]
The
goodwill impairment test is a two step analysis. In Step One, the fair value of each reporting unit is compared to its book value. Management must apply judgment in determining the
estimated fair value of these reporting units. Fair value is determined using a combination of present value techniques and quoted market prices of comparable businesses. If the fair value of the
reporting unit exceeds its book value, goodwill is not deemed to be impaired for that reporting unit, and no further testing would be necessary. If the fair value of the reporting unit is less than
its book value, the Company performs Step Two. Step Two uses the calculated fair value of the reporting unit to perform a hypothetical purchase price allocation to the fair value of the assets and
liabilities of the reporting unit. The difference between the fair value of the reporting unit calculated in Step One and the fair value of the underlying assets and liabilities of the reporting unit
is the implied fair value of the reporting unit's goodwill. A charge is recorded in the financial statements if the carrying value of the reporting unit's goodwill is greater than its implied fair
value.

[0001047469-10-004771:mdna:277]
The
following describes the valuation methodologies used to derive the fair value of the reporting units.

[0001047469-10-004771:mdna:278]
•

[0001047469-10-004771:mdna:279]
Income Approach:  To determine fair value, the Company
discounts the expected future cash flows of the reporting units. The discount rate used represents the estimated weighted average cost of capital, which reflects the overall level of inherent risk
involved in our operations and the rate of return a market participant would expect to earn. To estimate cash flows beyond the final year of our model, the Company uses a terminal value approach.
Under this approach, the Company uses estimated operating income before interest, taxes, depreciation and amortization in the final year of its model, adjusts it to estimate a normalized cash flow,
applies a perpetuity growth assumption and discounts it by a perpetuity discount factor to determine the terminal value. The Company incorporates the present value of the resulting terminal value into
its estimate of fair value.

[0001047469-10-004771:mdna:280]
•

[0001047469-10-004771:mdna:281]
Market-Based Approach:  To corroborate the results of the
income approach described above, the Company estimated the fair value of its reporting units using several market-based approaches, including the value that is derived based on the Company's
consolidated stock price as described above. The Company also uses the guideline company method, which focuses on comparing our risk profile and growth prospects to select reasonably similar/guideline
publicly traded companies.

[0001047469-10-004771:mdna:282]
The
determination of fair value of the reporting units and assets and liabilities within the reporting units requires the Company to make significant estimates and assumptions. These
estimates and assumptions primarily include, but are not limited to, the discount rate, terminal growth rates, earnings before depreciation and amortization, and capital expenditures forecasts. Due to
the inherent uncertainty involved in making these estimates, actual results could differ from those estimates. For the Access Networks reporting unit, the Company assigned a discount rate of 14.5% and
a terminal growth rate of 3%, both of which the Company believes to be reasonable based upon the risk profile and long-term growth prospects of this reporting unit in light of industry
market data.. The Company evaluated the merits of each significant assumption, both individually and in the aggregate, used to determine the fair value of the reporting units, as well as the fair
values of the corresponding assets and liabilities within the reporting units, and concluded they are reasonable.

[0001047469-10-004771:mdna:283]
| 50 |  | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |  |

[0001047469-10-004771:mdna:284]
The
Company has weighted the valuation of its reporting units at 75% based on the income approach and 25% based on the market-based approach, consistent with prior periods. The Company
believes that this weighting is appropriate since it is often difficult to find other appropriate companies that are similar to our reporting units and it is our view that future discounted cash flows
are more reflective of the value of the reporting units. If a heavier weighting was placed on the market-based approach, a higher fair value would have been determined for the Access Networks
reporting unit.

[0001047469-10-004771:mdna:285]
As
a result of the valuation work described above, the fair value of the Access Networks reporting unit exceeded its book value by a significant margin, indicating that there was no
impairment of goodwill.

[0001047469-10-004771:mdna:286]
Differences
in the Company's actual future cash flows, operating results, growth rates, capital expenditures, cost of capital and discount rates as compared to the estimates utilized for
the purpose of calculating the fair value of each reporting unit, as well as a decline in the Company's stock price and related market capitalization, could affect the results of our annual goodwill
assessment and, accordingly, potentially lead to future goodwill impairment charges.

[0001047469-10-004771:mdna:287]
New Accounting Pronouncements

[0001047469-10-004771:mdna:288]
In June 2009, the FASB issued new authoritative guidance amending the accounting for transfers of financial assets. Key provisions of
this amended guidance include (i) the removal of the concept of qualifying special purpose entities, (ii) the introduction of the concept of a participating interest, in circumstances in
which a portion of a financial asset has been transferred, and (iii) the requirement that to qualify for sale accounting the transferor must evaluate whether it maintains effective control over
transferred financial assets either directly or indirectly. Additionally, this guidance requires enhanced disclosures about transfers of financial assets and a transferor's continuing involvement. The
Company has adopted this guidance effective January 1, 2010. This adoption did not have a material impact on the Company's consolidated financial statements.

[0001047469-10-004771:mdna:289]
In
June 2009, the FASB issued authoritative guidance to amend the manner in which entities evaluate whether consolidation is required for variable interest entities (VIEs). The model for
determining whether an enterprise has a controlling financial interest and is the primary beneficiary of a VIE has changed significantly under the new guidance. Previously, variable interest holders
had to determine whether they had a controlling financial interest in a VIE based on a quantitative analysis of the expected gains and/or losses of the entity. In contrast, the new guidance requires
an enterprise with a variable interest in a VIE to qualitatively assess whether it has a controlling financial interest in the entity and, if so, whether it is the primary beneficiary. Furthermore,
this guidance requires that companies continually evaluate VIEs for consolidation, rather than assessing VIEs based only upon the occurrence of triggering events. This guidance also requires enhanced
disclosures about how a company's involvement with a VIE affects its financial statements and exposure to risks. The Company has adopted this guidance effective January 1, 2010. This adoption
did not have a material impact on the Company's consolidated financial statements.

[0001047469-10-004771:mdna:290]
In
May 2009, the FASB issued guidance establishing general standards for accounting for and disclosure of events that occur after the balance sheet date but before financial statements
are issued or are available to be issued. This guidance, among other things, sets forth the period after the balance sheet date during which management should evaluate events or transactions that may
occur for potential recognition or disclosure in the financial statements, the circumstances under which an entity should recognize events or transactions occurring after the
balance sheet date in its financial statements, and the disclosures an entity should make about events or transactions that occurred after the balance sheet date. In February 2010, new guidance was
issued which removes the requirement for public to disclose the date through which subsequent events were reviewed. This guidance was effective upon issuance and has been adopted by the Company.

[0001047469-10-004771:mdna:291]
In
January 2010, FASB issued guidance related to fair value disclosure requirements. Under this guidance, companies will be required to make additional disclosures concerning significant
transfers of amounts between the Level 1 and Level 2 fair value disclosures, as well as further disaggregation of the types of activity that were previously disclosed in the rollforward
of Level 3 fair value disclosures. Further, the guidance clarifies the level of aggregation of assets and liabilities within the fair value hierarchy that may be presented. This guidance is
effective for interim periods beginning after December 15, 2009. The Company has adopted this guidance effective January 1, 2010. The disclosures required by this adoption are included
in Note 9, "Fair Value Measurements."

[0001047469-10-004771:mdna:292]
|  |  |  | 51 |
