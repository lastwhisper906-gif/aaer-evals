# MSI notes — 0001047469-10-004771


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001047469-10-004771:notes:1]
| Three Months Ended April 3, 2010 |  | As Reported |  | Pro Forma Basis |  |
| Net sales |  | $ | 5,044 |  | $ | 4,604 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001047469-10-004771:notes:2]
| 11. Commitments and Contingencies Legal The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's consolidated financial position, liquidity or results of operations. Other The Company is also a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to hold the other party harmless against losses arising from the settlement of these pending obligations. The total amount of indemnification under these types of provisions is $143 million, of which the Company accrued $51 million at April 3, 2010 for potential claims under these provisions. In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property. Historically, the Company has not made significant payments under these agreements. However, there is an increasing risk in relation to patent indemnities given the current legal climate. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. Further, the Company's obligations under these agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, and for amounts not in excess of the contract value, and, in some instances, the Company may have recourse against third parties for certain payments made by the Company. |


## us-gaap:DebtDisclosureTextBlock

[0001047469-10-004771:notes:3]
| 4. Debt and Credit Facilities Long-Term Debt During the three months ended April 4, 2009, the Company repurchased $199 million of its outstanding long-term debt for an aggregate purchase price of $133 million, including $4 million of accrued interest. The $199 million of long-term debt repurchased included principal amounts of: (i) $11 million of the $358 million then outstanding of the 7.50% Debentures due 2025, (ii) $20 million of the $399 million then outstanding of the 6.50% Debentures due 2025, (iii) $14 million of the $299 million then outstanding of the 6.50% Debentures due 2028, and (iv) $154 million of the $600 million then outstanding of the 6.625% Senior Notes due 2037. The Company recognized a gain of approximately $67 million related to these open market purchases in Other within Other income (expense) in the consolidated statements of operations. |


## us-gaap:DisposalGroupsIncludingDiscontinuedOperationsDisclosureTextBlock

[0001047469-10-004771:notes:4]
| Three Months Ended |  | April 4, 2009 |  |
| Net sales |  | $ | 19 |  |
| Operating loss |  |  | (11 | ) |
| Gains on sales of investments and businesses, net |  |  | 175 |  |
| Earnings before income taxes |  |  | 162 |  |
| Income tax expense |  |  | 102 |  |
| Earnings from discontinued operations, net of tax |  |  | 60 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001047469-10-004771:notes:5]
| April 3, 2010 |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Sigma Fund securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | U.S. government, agency and government-sponsored enterprise obligations |  | $ | — |  | $ | 4,894 |  | $ | — |  | $ | 4,894 |  |
|  |  | Corporate bonds |  |  | — |  |  | 173 |  |  | 22 |  |  | 195 |  |
|  |  | Asset-backed securities |  |  | — |  |  | 45 |  |  | — |  |  | 45 |  |
|  |  | Mortgage-backed securities |  |  | — |  |  | 50 |  |  | — |  |  | 50 |  |
|  | Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | U.S. government, agency and government-sponsored enterprise obligations |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
|  |  | Corporate bonds |  |  | — |  |  | 11 |  |  | — |  |  | 11 |  |
|  |  | Mortgage-backed securities |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
|  |  | Common stock and equivalents |  |  | 114 |  |  | 10 |  |  | — |  |  | 124 |  |
|  | Foreign exchange derivative contracts |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Foreign exchange derivative contracts |  |  | — |  |  | 8 |  |  | — |  |  | 8 |  |
|  | Interest agreement derivative contracts |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |
| December 31, 2009 |  |  | Level 1 |  |  | Level 2 |  |  | Level 3 |  |  | Total |  |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Sigma Fund securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | U.S. government, agency and government-sponsored enterprise obligations |  | $ | — |  | $ | 4,408 |  | $ | — |  | $ | 4,408 |  |
|  |  | Corporate bonds |  |  | — |  |  | 411 |  |  | 19 |  |  | 430 |  |
|  |  | Asset-backed securities |  |  | — |  |  | 66 |  |  | — |  |  | 66 |  |
|  |  | Mortgage-backed securities |  |  | — |  |  | 52 |  |  | — |  |  | 52 |  |
|  | Available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  |  | U.S. government, agency and government-sponsored enterprise obligations |  |  | — |  |  | 23 |  |  | — |  |  | 23 |  |
|  |  | Corporate bonds |  |  | — |  |  | 10 |  |  | — |  |  | 10 |  |
|  |  | Mortgage-backed securities |  |  | — |  |  | 3 |  |  | — |  |  | 3 |  |
|  |  | Common stock and equivalents |  |  | 136 |  |  | 11 |  |  | — |  |  | 147 |  |
|  | Foreign exchange derivative contracts |  |  | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Foreign exchange derivative contracts |  |  | — |  |  | 17 |  |  | — |  |  | 17 |  |
|  | Interest agreement derivative contracts |  |  | — |  |  | 4 |  |  | — |  |  | 4 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001047469-10-004771:notes:6]
| 6. Income Taxes At April 3, 2010 and December 31, 2009, the Company had valuation allowances of $2.9 billion, including $403 million and $422 million, respectively, relating to deferred tax assets for non-U.S. subsidiaries. During the three months ended April 3, 2010, there was no adjustment to the U.S. valuation allowance. The valuation allowance relating to deferred tax assets of non-U.S. subsidiaries was adjusted primarily for exchange rate variances. In March 2008, the Company announced a strategy to separate into two publicly-traded companies. In February 2010, the Company announced that it is targeting the first quarter of 2011 for the completion of this separation. When evaluating the Company's valuation allowances the Company is precluded from taking into consideration events dependent on future market conditions, such as the announced separation transaction. The Company will reassess its valuation allowance needs based on two separate publicly traded companies in the period the separation transaction occurs or when the transaction is imminent. The valuation allowances determined for two separate publicly traded companies may differ from the Company's current valuation allowance balances. In the first quarter of 2010, the Patient Protection and Affordable Care Act and the Health Care and Education Reconciliation Act of 2010 were signed into law, which eliminated the favorable income tax treatment of Medicare Part D Subsidy receipts effective for tax years starting in 2013. As a result of the tax law change, the Company recorded an $18 million non-cash tax charge to reduce its deferred tax asset associated with Medicare Part D subsidies currently estimated to be received after 2012. The Company had unrecognized tax benefits of $401 million and $466 million, at April 3, 2010 and December 31, 2009, respectively, of which approximately $80 million and $100 million, respectively, if recognized, would affect the effective tax rate, net of resulting changes to valuation allowances. During the three months ended April 3, 2010, the Company recorded a $53 million tax benefit representing a reduction in unrecognized tax benefits relating to facts that now indicate the extent to which certain tax positions are more-likely-than-not of being sustained. Based on the potential outcome of the Company's global tax examinations, the expiration of the statute of limitations for specific jurisdictions, or the continued ability to satisfy tax incentive obligations, it is reasonably possible that the unrecognized tax benefits will change within the next 12 months. The associated net tax impact on the effective tax rate, exclusive of valuation allowance changes, is estimated to be in the range of a $75 million tax charge to a $175 million tax benefit, with cash payments in the range of $0 to $150 million. During the first quarter of 2010, the Internal Revenue Service ("IRS") concluded its audit of Symbol's 2004 through January 9, 2007 pre-acquisition tax years. The Company has audits pending in several tax jurisdictions. Although the final resolution of the Company's global tax disputes is uncertain, based on current information, in the opinion of the Company's management, the ultimate disposition of these matters will not have a material adverse effect on the Company's consolidated financial position, liquidity or results of operations. However, an unfavorable resolution of the Company's global tax disputes could have a material adverse effect on the Company's consolidated financial position, liquidity or results of operations in the periods in which the matters are ultimately resolved. |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001047469-10-004771:notes:7]
|  |  | April 3, 2010 |  | December 31, 2009 |  |
|  |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |
| Completed technology |  | $ | 1,126 |  | $ | 850 |  | $ | 1,123 |  | $ | 792 |  |
| Patents |  |  | 288 |  |  | 179 |  |  | 288 |  |  | 179 |  |
| Customer-related |  |  | 279 |  |  | 151 |  |  | 278 |  |  | 145 |  |
| Licensed technology |  |  | 130 |  |  | 122 |  |  | 130 |  |  | 122 |  |
| Other intangibles |  |  | 152 |  |  | 138 |  |  | 149 |  |  | 137 |  |
|  |  | $ | 1,975 |  | $ | 1,440 |  | $ | 1,968 |  | $ | 1,375 |  |


## mot:LongTermCustomerFinancingAndSalesOfReceivablesTextBlock

[0001047469-10-004771:notes:8]
|  |  |  | April 3, 2010 |  |  | December 31, 2009 |  |
| Long-term receivables |  | $ | 152 |  | $ | 154 |  |
| Less allowance for losses |  |  | (9 | ) |  | (9 | ) |
|  |  |  | 143 |  |  | 145 |  |
| Less current portion |  |  | (20 | ) |  | (28 | ) |
| Non-current long-term receivables, net |  | $ | 123 |  | $ | 117 |  |


## mot:OtherFinancialDataTextBlock

[0001047469-10-004771:notes:9]
| Three Months Ended |  |  | April 3, 2010 |  |  | April 4, 2009 |  |
| Other charges: |  |  |  |  |  |  |  |
|  | Amortization of intangible assets |  | $ | 65 |  | $ | 71 |  |
|  | Separation-related transaction costs |  |  | 25 |  |  | — |  |
|  | Reorganization of businesses |  |  | 16 |  |  | 158 |  |
|  | Legal settlement |  |  | (29 | ) |  | — |  |
|  |  | $ | 77 |  | $ | 229 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001047469-10-004771:notes:10]
| Three Months Ended |  |  | April 3, 2010 |  |
| Mobile Devices |  | $ | 15 |  |
| Home |  |  | 5 |  |
| Enterprise Mobility Solutions |  |  | 2 |  |
| Networks |  |  | 1 |  |
|  |  |  | 23 |  |
| Corporate |  |  | (2 | ) |
|  |  | $ | 21 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001047469-10-004771:notes:11]
|  |  | April 3, 2010 |  | April 4, 2009 |  |
| Three Months Ended |  |  | Regular Pension |  |  | Officers' and MSPP |  |  | Non U.S. |  |  | Regular Pension |  |  | Officers' and MSPP |  |  | Non U.S. |  |
| Service cost |  | $ | — |  | $ | — |  | $ | 7 |  | $ | 4 |  | $ | — |  | $ | 6 |  |
| Interest cost |  |  | 86 |  |  | 1 |  |  | 28 |  |  | 85 |  |  | 2 |  |  | 16 |  |
| Expected return on plan assets |  |  | (95 | ) |  | — |  |  | (28 | ) |  | (95 | ) |  | — |  |  | (14 | ) |
| Amortization of: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
|  | Unrecognized net loss |  |  | 38 |  |  | 1 |  |  | 6 |  |  | 20 |  |  | — |  |  | 1 |  |
|  | Unrecognized prior service cost |  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | — |  |  | — |  |
| Settlement/curtailment loss |  |  | — |  |  | 1 |  |  | — |  |  | — |  |  | 2 |  |  | — |  |
| Net periodic pension cost |  | $ | 29 |  | $ | 3 |  | $ | 12 |  | $ | 14 |  | $ | 4 |  | $ | 9 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001047469-10-004771:notes:12]
|  |  | Notional Amount |  |
| Net Buy (Sell) by Currency |  |  | April 3, 2010 |  |  | December 31, 2009 |  |
| Chinese Renminbi |  | $ | (386 | ) | $ | (297 | ) |
| Brazilian Real |  |  | (318 | ) |  | (342 | ) |
| Euro |  |  | (284 | ) |  | (377 | ) |
| Japanese Yen |  |  | (129 | ) |  | (236 | ) |
| British Pound |  |  | 117 |  |  | 143 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001047469-10-004771:notes:13]
|  |  | Net Sales |  | Operating Earnings (Loss) |  |
| Three Months Ended |  |  | April 3, 2010 |  |  | April 4, 2009 |  |  | April 3, 2010 |  |  | April 4, 2009 |  |
| Mobile Devices |  | $ | 1,641 |  | $ | 1,801 |  | $ | (192 | ) | $ | (545 | ) |
| Home |  |  | 838 |  |  | 1,025 |  |  | 20 |  |  | 3 |  |
| Enterprise Mobility Solutions |  |  | 1,694 |  |  | 1,599 |  |  | 141 |  |  | 66 |  |
| Networks |  |  | 896 |  |  | 966 |  |  | 112 |  |  | 62 |  |
|  |  |  | 5,069 |  |  | 5,391 |  |  | 81 |  |  | (414 | ) |
| Other and Eliminations |  |  | (25 | ) |  | (20 | ) |  | (5 | ) |  | (35 | ) |
|  |  | $ | 5,044 |  | $ | 5,371 |  |  |  |  |  |  |  |
| Operating earnings (loss) |  |  |  |  |  |  |  |  | 76 |  |  | (449 | ) |
| Total other income (expense) |  |  |  |  |  |  |  |  | (13 | ) |  | 15 |  |
| Earnings (loss) from continuing operations before income taxes |  |  |  |  |  |  |  | $ | 63 |  | $ | (434 | ) |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001047469-10-004771:notes:14]
| Three Months Ended |  |  | April 3, 2010 |  |  | April 4, 2009 |  |
| Share-based compensation expense included in: |  |  |  |  |  |  |  |
|  | Costs of sales |  | $ | 8 |  | $ | 9 |  |
|  | Selling, general and administrative expenses |  |  | 42 |  |  | 41 |  |
|  | Research and development expenditures |  |  | 22 |  |  | 26 |  |
| Share-based compensation expense included in Operating earnings (loss) |  |  | 72 |  |  | 76 |  |
| Tax benefit |  |  | 24 |  |  | 24 |  |
| Share-based compensation expense, net of tax |  | $ | 48 |  | $ | 52 |  |
| Decrease in basic earnings per share |  | $ | (0.02 | ) | $ | (0.02 | ) |
| Decrease in diluted earning per share |  | $ | (0.02 | ) | $ | (0.02 | ) |
