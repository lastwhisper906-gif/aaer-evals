# MSI note change history — 0000950123-09-057013 → 0001047469-10-004771


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2010-05-04):
[0001047469-10-004771:note_history:1]
| 11. Commitments and Contingencies Legal The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company's consolidated financial position, liquidity or results of operations. Other The Company is also a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. Some of these obligations arise as a result of divestitures of the Company's assets or businesses and require the Company to hold the other party harmless against losses arising from the settlement of these pending obligations. The total amount of indemnification under these types of provisions is $143 million, of which the Company accrued $51 million at April 3, 2010 for potential claims under these provisions. In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property. Historically, the Company has not made significant payments under these agreements. However, there is an increasing risk in relation to patent indemnities given the current legal climate. In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party's claims. Further, the Company's obligations under these agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, and for amounts not in excess of the contract value, and, in some instances, the Company may have recourse against third parties for certain payments made by the Company. |

- removed (2010-05-04):
[0000950123-09-057013:note_history:2]
11. Commitments and Contingencies

- removed (2010-05-04):
[0000950123-09-057013:note_history:3]
Legal

- removed (2010-05-04):
[0000950123-09-057013:note_history:4]
The Company is a defendant in various suits, claims and investigations that arise in the normal course of business. In the opinion of management, the ultimate disposition of these matters will not have a material adverse effect on the Company’s consolidated financial position, liquidity or results of operations.

- removed (2010-05-04):
[0000950123-09-057013:note_history:5]
Other

- removed (2010-05-04):
[0000950123-09-057013:note_history:6]
The Company is also a party to a variety of agreements pursuant to which it is obligated to indemnify the other party with respect to certain matters. Some of these obligations arise as a result of divestitures of the Company’s assets or businesses and require the Company to hold the other party harmless against losses arising from the settlement of these pending obligations. The total amount of indemnification under these types of provisions is $156 million, of which the Company accrued $55 million at October 3, 2009 for potential claims under these provisions.

- removed (2010-05-04):
[0000950123-09-057013:note_history:7]
In addition, the Company may provide indemnifications for losses that result from the breach of general warranties contained in certain commercial and intellectual property. Historically, the Company has not made significant payments under these agreements. However, there is an increasing risk in relation to patent indemnities given the current legal climate.

- removed (2010-05-04):
[0000950123-09-057013:note_history:8]
In indemnification cases, payment by the Company is conditioned on the other party making a claim pursuant to the procedures specified in the particular contract, which procedures typically allow the Company to challenge the other party’s claims. Further, the Company’s obligations under these agreements for indemnification based on breach of representations and warranties are generally limited in terms of duration, and for amounts not in excess of the contract value, and, in some instances, the Company may have recourse against third parties for certain payments made by the Company.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2010-05-04):
[0001047469-10-004771:note_history:9]
| Three Months Ended April 3, 2010 |  | As Reported |  | Pro Forma Basis |  |
| Net sales |  | $ | 5,044 |  | $ | 4,604 |  |

- removed (2010-05-04):
[0000950123-09-057013:note_history:10]
1. Basis of Presentation

- removed (2010-05-04):
[0000950123-09-057013:note_history:11]
The condensed consolidated financial statements as of October 3, 2009 and for the three and nine months ended October 3, 2009 and September 27, 2008, include, in the opinion of management, all adjustments (consisting of normal recurring adjustments and reclassifications) necessary to present fairly the Company’s consolidated financial position, results of operations and cash flows for all periods presented.

- removed (2010-05-04):
[0000950123-09-057013:note_history:12]
Certain information and footnote disclosures normally included in financial statements prepared in accordance with U.S. generally accepted accounting principles (“U.S. GAAP”) have been condensed or omitted. These condensed consolidated financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in the Company’s Form 10-K for the year ended December 31, 2008. The results of operations for the three and nine months ended October 3, 2009 are not necessarily indicative of the operating results to be expected for the full year. Certain amounts in prior period financial statements and related notes have been reclassified to conform to the 2009 presentation.

- removed (2010-05-04):
[0000950123-09-057013:note_history:13]
The preparation of financial statements in conformity with U.S. GAAP requires management to make certain estimates and assumptions that affect the reported amounts of assets and liabilities and disclosure of contingent assets and liabilities at the date of the financial statements and the reported amounts of revenues and expenses during the reporting periods. Actual results could differ from those estimates. The Company has evaluated subsequent events after October 3, 2009, through the date and time the financial statements were issued on November 3, 2009.

- removed (2010-05-04):
[0000950123-09-057013:note_history:14]
In October 2009, the Financial Accounting Standards Board (“FASB”) issued new authoritative guidance related to the recognition of revenue for certain multiple deliverable arrangements. Under the new guidance, revenue will be allocated to the different elements in an arrangement based on relative sales price. The new guidance, which is expected to result in more multiple-deliverable arrangements being separable than under current guidance, will be effective for the Company prospectively for revenue arrangements entered into or materially modified on or after January 1, 2011. In October 2009, the FASB issued new authoritative guidance which alters the scope of revenue recognition guidance for software deliverables to exclude items sold that include hardware with software that is essential to its functionality. The new guidance will be effective for the Company prospectively for revenue arrangements entered into or materially modified on or after January 1, 2011. Early adoption of both standards is permitted. The Company is still assessing the potential impact of adopting this new guidance.

- removed (2010-05-04):
[0000950123-09-057013:note_history:15]
In June 2009, the FASB issued authoritative guidance amending the accounting for transfers of financial assets. Key provisions of this amended guidance include (i) the removal of the concept of qualifying special purpose entities, (ii) the introduction of the concept of a participating interest, in circumstances in which a portion of a financial asset has been transferred, and (iii) the requirement that to qualify for sale accounting the transferor must evaluate whether it maintains effective control over transferred financial assets either directly or indirectly. Additionally, this guidance requires enhanced disclosures about transfers of financial assets and a transferor’s continuing involvement. This new guidance will be effective for the Company beginning January 1, 2010. The Company is still assessing the potential impact of adopting this new guidance.

- removed (2010-05-04):
[0000950123-09-057013:note_history:16]
In June 2009, the FASB issued authoritative guidance to amend the manner in which entities evaluate whether consolidation is required for variable interest entities (VIEs). The model for determining which enterprise has a controlling financial interest and is the primary beneficiary of a VIE has changed significantly under the new guidance. Previously, variable interest holders had to determine whether they had a controlling financial interest in a VIE based on a quantitative analysis of the expected gains and/or losses of the entity. In contrast, the new guidance requires an enterprise with a variable interest in a VIE to qualitatively assess whether it has a controlling financial interest in the entity and, if so, whether it is the primary beneficiary. Furthermore, this guidance requires that companies continually evaluate VIEs for consolidation, rather than assessing VIEs based only upon the occurrence of triggering events. This revised guidance also requires enhanced disclosures about how a company’s involvement with a VIE affects its financial statements and exposure to risks. This new guidance will be effective for the Company beginning January 1, 2010. The Company is still assessing the potential impact of adopting this new guidance.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2010-05-04):
[0001047469-10-004771:note_history:17]
| 4. Debt and Credit Facilities Long-Term Debt During the three months ended April 4, 2009, the Company repurchased $199 million of its outstanding long-term debt for an aggregate purchase price of $133 million, including $4 million of accrued interest. The $199 million of long-term debt repurchased included principal amounts of: (i) $11 million of the $358 million then outstanding of the 7.50% Debentures due 2025, (ii) $20 million of the $399 million then outstanding of the 6.50% Debentures due 2025, (iii) $14 million of the $299 million then outstanding of the 6.50% Debentures due 2028, and (iv) $154 million of the $600 million then outstanding of the 6.625% Senior Notes due 2037. The Company recognized a gain of approximately $67 million related to these open market purchases in Other within Other income (expense) in the consolidated statements of operations. |

- removed (2010-05-04):
[0000950123-09-057013:note_history:18]
4. Debt and Credit Facilities

- removed (2010-05-04):
[0000950123-09-057013:note_history:19]
Long-Term Debt

- removed (2010-05-04):
[0000950123-09-057013:note_history:20]
During the nine months ended October 3, 2009, the Company completed the open market purchase of $199 million of its outstanding long-term debt for an aggregate purchase price of $133 million, including $4 million of accrued interest, all of which occurred during the three months ended April 4, 2009. The $199 million of long-term debt repurchased included principal amounts of: (i) $11 million of the $400 million outstanding of the 7.50% Debentures due 2025, (ii) $20 million of the $309 million outstanding of the 6.50% Debentures due 2025, (iii) $14 million of the $299 million outstanding of the 6.50% Debentures due 2028, and (iv) $154 million of the $600 million outstanding of the 6.625% Senior Notes due 2037. The Company recognized a gain of approximately $67 million related to these open market purchases in Other within Other income (expense) in the condensed consolidated statements of operations.

- removed (2010-05-04):
[0000950123-09-057013:note_history:21]
Credit Facilities

- removed (2010-05-04):
[0000950123-09-057013:note_history:22]
In June 2009, the Company elected to amend its domestic syndicated revolving credit facility (as amended from time to time, the “Credit Facility”) that is scheduled to mature in December 2011. As part of the amendment, the Company reduced the size of the Credit Facility to the lesser of: (1) $1.5 billion, or (2) an amount determined based on eligible domestic accounts receivable and inventory. If the Company elects to borrow under the Credit Facility, it would be required to pledge its domestic accounts receivables and, at its option, domestic inventory. As amended, the Credit Facility does not require the Company to meet any financial covenants unless remaining availability under the Credit Facility is less than $225 million. In addition, until borrowings are made under the Credit Facility, the Company is able to use its working capital assets in any capacity in conjunction with other capital market funding alternatives that may be available to the Company. As of and during the nine months ended October 3, 2009, there were no outstanding borrowings under this Credit Facility.
