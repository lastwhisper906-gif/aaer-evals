# MSI 8-K — 0001104659-10-022730 filed 2010-04-29

## item codes, every 8-K on or before 2010-05-04

- 2010-04-29 0001104659-10-022730 — 2.02, 9.01
- 2010-04-05 0001104659-10-018302 — 2.02, 9.01
- 2010-02-22 0001104659-10-008480 — 5.02, 9.01
- 2010-02-16 0001104659-10-007219 — 5.02, 8.01, 9.01
- 2010-01-28 0001104659-10-003418 — 2.02, 9.01
- 2009-11-16 0000950123-09-062915 — 5.03, 9.01
- 2009-11-13 0000950123-09-062285 — 5.02
- 2009-10-29 0000950123-09-054483 — 2.02, 9.01
- 2009-10-14 0000950123-09-050206 — 5.02
- 2009-07-30 0000950123-09-027325 — 2.02, 9.01
- 2009-05-22 0000950137-09-004049 — 5.02
- 2009-04-30 0000950137-09-003388 — 2.02, 9.01
- 2009-04-06 0000950137-09-002635 — 2.05
- 2009-04-01 0000950137-09-002505 — 5.02 — amendment of 0000950137-09-002115
- 2009-03-23 0000950137-09-002115 — 5.02, 8.01, 9.01
- 2009-02-03 0000950152-09-000904 — 2.02, 5.02, 8.01, 9.01
- 2009-01-21 0000950137-09-000352 — 2.02, 2.05, 5.02, 9.01
- 2008-12-30 0000950137-08-014637 — 2.05
- 2008-12-18 0000950123-08-017856 — 5.02
- 2008-12-17 0000950137-08-014456 — 5.02, 8.01, 9.01
- 2008-10-30 0000950152-08-008371 — 2.02, 9.01
- 2008-08-29 0000950137-08-011276 — 5.02, 9.01
- 2008-08-04 0000898822-08-000839 — 5.02, 5.03, 8.01, 9.01
- 2008-07-31 0000950137-08-009960 — 5.02
- 2008-07-31 0000950134-08-013761 — 2.02, 9.01
- 2008-04-25 0000950137-08-006039 — 5.02
- 2008-04-24 0000950134-08-007259 — 2.02, 9.01
- 2008-04-08 0000898822-08-000394 — 5.02, 8.01, 9.01
- 2008-04-03 0000950137-08-005055 — 2.05
- 2008-04-02 0000950137-08-004996 — 5.02, 9.01
- 2008-03-26 0000898822-08-000323 — 8.01, 9.01
- 2008-03-20 0000950137-08-003967 — 5.02
- 2008-03-11 0000950137-08-003512 — 5.02, 9.01
- 2008-02-27 0000950137-08-002814 — 5.02, 9.01
- 2008-02-05 0000950137-08-001640 — 5.02
- 2008-02-04 0000950137-08-001572 — 8.01, 9.01
- 2008-01-23 0000950134-08-000935 — 2.02, 9.01
- 2008-01-04 0000950137-08-000104 — 2.05
- 2007-11-30 0000898822-07-001404 — 5.02, 9.01
- 2007-10-31 0000950137-07-016286 — 9.01
- 2007-10-25 0000950124-07-005297 — 2.02, 9.01
- 2007-10-04 0000950137-07-015106 — 5.02, 9.01
- 2007-10-03 0000950137-07-015031 — 2.05
- 2007-09-19 0000950137-07-014349 — 5.02, 9.01
- 2007-08-03 0000950137-07-011210 — 8.01, 9.01
- 2007-07-30 0000950137-07-010759 — 5.02, 9.01
- 2007-07-19 0000950134-07-015424 — 2.02, 9.01
- 2007-07-17 0000950137-07-010074 — 2.02, 9.01
- 2007-07-12 0000950137-07-009943 — 2.02, 9.01
- 2007-07-10 0000950137-07-009817 — 5.02
- 2007-07-05 0000950137-07-009733 — 2.05
- 2007-06-06 0000950137-07-008512 — 5.02
- 2007-05-14 0000950137-07-007421 — 5.02, 9.01
- 2007-04-18 0000950124-07-002224 — 2.02, 9.01
- 2007-04-10 0000950137-07-005362 — 5.02
- 2007-03-27 0000950137-07-004530 — 5.02, 9.01 — amendment of 0000950137-07-004160
- 2007-03-21 0000950137-07-004160 — 5.02, 7.01, 8.01, 9.01
- 2007-02-28 0000950137-07-002962 — 5.02
- 2007-02-20 0000950137-07-002451 — 5.02
- 2007-02-15 0000950137-07-002342 — 5.02, 9.01
- 2007-01-19 0000950124-07-000344 — 2.02, 9.01
- 2007-01-10 0000950137-07-000214 — 2.01, 9.01
- 2007-01-05 0000950137-07-000112 — 2.02, 9.01
- 2006-10-17 0000950137-06-011096 — 2.02, 9.01
- 2006-09-25 0000950137-06-010337 — 1.01, 9.01
- 2006-09-19 0000950137-06-010161 — 8.01, 9.01
- 2006-07-27 0000950137-06-008197 — 3.03, 5.03, 9.01
- 2006-07-24 0000950137-06-008023 — 1.01, 8.01, 9.01
- 2006-07-19 0000950137-06-007904 — 2.02, 9.01
- 2006-07-10 0000950137-06-007690 — 5.02, 9.01
- 2006-07-06 0000950137-06-007601 — 2.02, 9.01
- 2006-04-18 0000950137-06-004651 — 2.02, 9.01
- 2006-04-03 0000950137-06-004098 — 1.01, 9.01
- 2006-03-01 0000950137-06-002434 — 5.03, 8.01, 9.01
- 2006-02-16 0000950137-06-001960 — 1.01, 9.01
- 2006-01-19 0000950137-06-000599 — 2.02, 9.01
- 2005-11-18 0000950137-05-013977 — 1.01, 9.01
- 2005-10-18 0000950137-05-012538 — 2.02, 9.01
- 2005-10-04 0000950137-05-012037 — 2.05
- 2005-08-19 0000950137-05-010470 — 8.01
- 2005-08-01 0000950137-05-009368 — 5.02, 9.01
- 2005-07-29 0000950137-05-009298 — 1.01
- 2005-07-19 0000950137-05-008843 — 2.02, 9.01
- 2005-05-19 0000950137-05-006229 — 8.01, 9.01
- 2005-05-06 0000950137-05-005524 — 1.01, 9.01
- 2005-04-20 0000950137-05-004668 — 2.02, 9.01
- 2005-04-19 0000950137-05-004590 — 1.01, 9.01
- 2005-04-06 0000950137-05-004176 — 2.02, 9.01
- 2005-02-22 0000950137-05-002079 — 2.02, 9.01
- 2005-02-18 0000950137-05-002010 — 1.01, 1.02, 5.03, 9.01
- 2005-02-16 0000950137-05-001881 — 5.02, 9.01
- 2005-02-08 0000950137-05-001331 — 7.01, 9.01
- 2005-02-02 0001193125-05-017220 — 5.02, 9.01
- 2005-01-18 0001193125-05-007688 — 2.02, 9.01
- 2005-01-14 0001193125-05-006059 — 5.02, 9.01
- 2004-12-20 0001193125-04-216662 — 8.01, 9.01
- 2004-12-08 0000950137-04-010855 — 2.01, 9.01
- 2004-11-29 0001299933-04-002005 — 8.01, 9.01
- 2004-11-12 0001299933-04-001770 — 8.01, 9.01
- 2004-11-12 0001299933-04-001741 — 8.01, 9.01
- 2004-10-19 0001193125-04-173798 — 2.02, 2.05
- 2004-10-04 0001193125-04-166322 — 5.05, 9.01
- 2004-09-28 0001193125-04-162709 — 2.05, 8.01
- 2004-08-11 0000950137-04-006585 — 7
- 2004-07-20 0001193125-04-121036 — 2
- 2004-07-19 0001193125-04-120172 — 5, 7
- 2004-06-24 0001193125-04-108090 — 5
- 2004-06-21 0001193125-04-105400 — 9
- 2004-04-20 0001193125-04-065576 — 12
- 2004-04-14 0001193125-04-062374 — 12
- 2004-01-20 0001193125-04-006217 — 12
- 2003-12-18 0001193125-03-096572 — 5
- 2003-12-16 0001047469-03-041112 — 5
- 2003-10-14 0001047469-03-033212 — 12
- 2003-10-08 0001047469-03-032904 — 5
- 2003-09-22 0001047469-03-031284 — 5
- 2003-07-15 0001047469-03-024190 — 9
- 2003-04-15 0001047469-03-013457 — 9
- 2003-04-08 0001047469-03-012294 — 9
- 2003-04-03 0001047469-03-011829 — 5
- 2002-12-18 0001047469-02-007510 — 5
- 2002-10-15 0000912057-02-038694 — 7 — amendment of 0000912057-02-014300
- 2002-06-27 0000912057-02-025589 — 5
- 2002-04-09 0000912057-02-014300 — 7
- 2002-01-15 0000912057-02-001307 — 7, 9
- 2001-11-02 0000950131-01-503968 — 5
- 2001-10-22 0000950131-01-503828 — 5
- 2001-04-03 0000950137-01-500595 — 7
- 2000-11-07 0000927356-00-002002 — 7 — amendment of 0000950131-00-001931
- 2000-06-02 0000950131-00-003731 — 5 — amendment of 0000950131-00-001931
- 2000-03-24 0000950131-00-001960 — 5 — amendment of 0000950131-00-001931
- 2000-03-23 0000950131-00-001931 — 5
- 2000-03-17 0000068505-00-000007 — 7 — amendment of 0000898822-00-000009
- 2000-01-06 0000898822-00-000009 — 2, 7
- 1999-09-16 0000068505-99-000031 — 5, 7
- 1998-11-05 0000068505-98-000032 — 5, 7
- 1998-06-05 0000068505-98-000013 — 5, 7
- 1996-01-10 0000068505-96-000001 — 5, 7
- 1995-08-30 0000068505-95-000009 — 5, 7 — amendment of 0000068505-95-000008
- 1995-08-29 0000068505-95-000008 — 5, 7
- 1995-05-18 0000068505-95-000006 — 5, 7
- 1994-08-18 0000898822-94-000070 — 5, 7

## late-filing notifications on or before 2010-05-04

- none on or before 2010-05-04

## item 2.02 — earnings release, exhibit 99.1

[0001104659-10-022730:8k_2_02:1]
EX-99.1
2
a10-8892_1ex99d1.htm
EX-99.1

[0001104659-10-022730:8k_2_02:2]
Exhibit 99.1

[0001104659-10-022730:8k_2_02:3]
Motorola Announces First-Quarter 2010 Financial Results

[0001104659-10-022730:8k_2_02:4]
Financial Highlights

[0001104659-10-022730:8k_2_02:5]
·                  First-quarter sales of $5.0
billion

[0001104659-10-022730:8k_2_02:6]
·                  First-quarter GAAP earnings
of $0.03 per share, compared to a loss from continuing operations of $0.13 per
share in first quarter 2009; first-quarter 2010 GAAP earnings include income of
$0.01 per share from highlighted items

[0001104659-10-022730:8k_2_02:7]
·                  Total cash* of $8.5 billion,
a sequential increase of $455 million

[0001104659-10-022730:8k_2_02:8]
·                  Enterprise Mobility
Solutions sales of $1.7 billion; operating earnings of $141 million

[0001104659-10-022730:8k_2_02:9]
·                  Mobile Devices sales of $1.6
billion; shipped 8.5 million handsets, including 2.3 million smartphones;
operating loss of $192 million

[0001104659-10-022730:8k_2_02:10]
·                  Networks sales of $896
million; operating earnings of $112 million

[0001104659-10-022730:8k_2_02:11]
·                  Home sales of $838 million;
operating earnings of $20 million

[0001104659-10-022730:8k_2_02:12]
SCHAUMBURG, Ill. — April 29, 2010 — Motorola, Inc.
(NYSE: MOT) today reported sales of $5.0 billion in the first quarter
of 2010. The GAAP earnings in the first quarter of 2010 were $69 million, or
$0.03 per share, which compares to a GAAP loss from continuing operations of
$291 million, or $0.13 per share, in the first quarter of 2009.

[0001104659-10-022730:8k_2_02:13]
First-quarter 2010 GAAP earnings include net income of $0.01 per share
from highlighted items, which are described at the end of the press release.
GAAP earnings per share also include non-cash expenses for stock-based
compensation and amortization of intangibles totaling $0.04 per share in the
first quarter of 2010. Further details are outlined at the end of this press
release.

[0001104659-10-022730:8k_2_02:14]
During
the quarter, the Company generated positive operating cash flow of $485 million
and ended the quarter with a total cash* position of $8.5 billion.

[0001104659-10-022730:8k_2_02:15]
“We
continue to execute on our business strategy, build momentum in smartphones and
improve our operating performance. During the quarter, we increased smartphone
shipments sequentially and introduced six new devices,” said Sanjay Jha,
Motorola co-chief executive officer and CEO of Mobile Devices and Home. “We are
in a strong position to improve our share in the rapidly growing smartphone
market, particularly in light of our competitive portfolio, strengthened brand
and improved carrier relationships.”

[0001104659-10-022730:8k_2_02:16]
Jha
added, “The Mobile Devices and Home businesses are uniquely positioned to
capitalize on the convergence of mobile experiences and home entertainment. We
remain focused on developing next-generation products to capitalize on the
opportunities of this dynamic market.”

[0001104659-10-022730:8k_2_02:17]
“Our Enterprise Mobility Solutions and Networks businesses performed
very well during the quarter, delivering strong operating earnings and
excellent cash generation,” said Greg Brown,
Motorola co-chief executive officer and CEO of Motorola Solutions. “These businesses continue to deliver best-in-class market leadership and financial
returns.”

[0001104659-10-022730:8k_2_02:18]
Operating Results

[0001104659-10-022730:8k_2_02:19]
Mobile Devices segment sales were $1.6 billion, down 9
percent compared with the year-ago quarter. The GAAP operating loss was $192
million, a significant improvement compared to the operating loss of $545
million in the year-ago quarter.

[0001104659-10-022730:8k_2_02:20]
Mobile
Devices highlights:

[0001104659-10-022730:8k_2_02:21]
·                  Shipped 8.5 million units,
including 2.3 million smartphones; continued to strengthen North America
position and shipped smartphones to carrier, distributor and retail customers
globally

[0001104659-10-022730:8k_2_02:22]
·                  Introduced six new Android-powered
smartphones: BACKFLIP™, QUENCH™/CLIQ XT™, DEVOUR™, as well as three products
designed for the Asia market, the MOTO XT701, MT710 and XT800, bringing our
smartphone portfolio to eight

[0001104659-10-022730:8k_2_02:23]
·                  Introduced SHOP4APPS, an application store,
currently available for our consumers in China to enhance their Motorola
Android experience

[0001104659-10-022730:8k_2_02:24]
Home segment sales were $838 million, down 18 percent
compared with the year-ago quarter. GAAP operating earnings were $20 million,
compared to $3 million in the year-ago quarter.

[0001104659-10-022730:8k_2_02:25]
Home
highlights:

[0001104659-10-022730:8k_2_02:26]
·                  Shipped 3.1 million digital entertainment
devices

[0001104659-10-022730:8k_2_02:27]
·                  Announced QIP eco-friendly set-top boxes for
Verizon FiOS™ customers

[0001104659-10-022730:8k_2_02:28]
·                  Introduced innovative 3DTV set-tops for
cable, significantly enhancing 3D experience for consumers

[0001104659-10-022730:8k_2_02:29]
·                  Strengthened North America position and
secured wins with four customers to support the delivery of ultra-broadband
triple play services

[0001104659-10-022730:8k_2_02:30]
Enterprise
Mobility Solutions segment sales were $1.7 billion, up 6 percent
compared with the year-ago quarter. GAAP operating earnings were $141 million,
compared with operating earnings of $66 million in the year-ago quarter.

[0001104659-10-022730:8k_2_02:31]
Enterprise
Mobility Solutions highlights:

[0001104659-10-022730:8k_2_02:32]
·                  Secured one of the single largest TETRA
terminal contracts ever awarded in Europe, including more than 50,000
terminals, from the German Federal Ministry of Interior

[0001104659-10-022730:8k_2_02:33]
·                  Received several North America contracts,
including a number of multi-million dollar awards from cities, and three
statewide expansion wins, including Michigan and Wyoming

[0001104659-10-022730:8k_2_02:34]
·                  Announced a series of rugged digital bar code
scanners for harsh industrial environments, and launched the first cordless
digital imager designed for healthcare

[0001104659-10-022730:8k_2_02:35]
·                  Continued momentum in retail and in
transportation and logistics, including a win with Con-Way, a leader in freight
transportation and logistics, for the selection of the MC75 mobile computers

[0001104659-10-022730:8k_2_02:36]
Networks segment sales were $896 million, down 7 percent
compared with the year-ago quarter. GAAP operating earnings were $112 million,
compared to $62 million in the year-ago quarter.

[0001104659-10-022730:8k_2_02:37]
Networks
highlights:

[0001104659-10-022730:8k_2_02:38]
·                  Announced contract with Zain for the first
LTE network deployment in Saudi Arabia

[0001104659-10-022730:8k_2_02:39]
·                  Achieved first over-the-air TD-LTE data
sessions at the Expo Center for World Expo 2010 in Shanghai; selected by China
Mobile Communications Corporation to provide indoor TD-LTE coverage at the
World Expo

[0001104659-10-022730:8k_2_02:40]
·                  Shipped 2 millionth WiMAX CPE and dongles,
doubling cumulative shipments in just five months

[0001104659-10-022730:8k_2_02:41]
Second-Quarter 2010 Outlook

[0001104659-10-022730:8k_2_02:42]
The
Company’s outlook for the second quarter of 2010 is for earnings of $0.07 to
$0.09 per share. This outlook now excludes stock-based compensation and
amortization of intangibles expenses of approximately $0.04 per share, as well
as charges associated with items of the variety typically highlighted by the
Company in its quarterly earnings releases.

[0001104659-10-022730:8k_2_02:43]
Consolidated GAAP Results

[0001104659-10-022730:8k_2_02:44]
A
comparison of results from operations is as follows:

[0001104659-10-022730:8k_2_02:45]
|  |  | First Quarter |  |
| (In millions, except per share amounts) |  | 2010 |  | 2009 |  |
| Net sales |  | $ | 5,044 |  | $ | 5,371 |  |
| Gross margin |  | 1,786 |  | 1,496 |  |
| Operating earnings (loss) |  | 76 |  | (449 | ) |
| Earnings (loss) from continuing operations ** |  | 69 |  | (291 | ) |
| Net earnings (loss) ** |  | 69 |  | (231 | ) |
| Diluted earnings (loss) per common share: ** |  |  |  |  |  |
| Continuing operations |  | 0.03 |  | (0.13 | ) |
| Discontinued operations |  | — |  | 0.03 |  |
|  |  | 0.03 |  | (0.10 | ) |
| Weighted average diluted common shares outstanding |  | 2,341.3 |  | 2,280.5 |  |

[0001104659-10-022730:8k_2_02:46]
Highlighted Items, Stock-Based Compensation Expense
and Intangibles Amortization Expense

[0001104659-10-022730:8k_2_02:47]
The
table below includes highlighted items, stock-based compensation expense and
intangibles amortization expense for the first quarter of 2010.

[0001104659-10-022730:8k_2_02:48]
|  |  | EPS Impact Exp/(Inc)*** |  |
| Tax-related benefit |  | $ | (0.02 | ) |
| Legal settlement |  | (0.01 | ) |
| Separation-related transaction costs |  | 0.01 |  |
| Reorganization of business charges |  | 0.01 |  |
| Impact of Medicare Part D Subsidy tax law change |  | 0.01 |  |
| Total Highlighted Items |  | (0.01 | ) |
| Stock-based compensation expense |  | 0.02 |  |
| Intangibles amortization expense |  | 0.02 |  |
| Total |  | $ | 0.03 |  |

[0001104659-10-022730:8k_2_02:49]
Conference Call and Webcast

[0001104659-10-022730:8k_2_02:50]
Motorola
will host its quarterly conference call beginning at 8 a.m. (U.S. Eastern
Time) on Thursday, April 29. The conference call will be webcast live with
audio and slides at www.motorola.com/investor.

[0001104659-10-022730:8k_2_02:51]
Business
Risks

[0001104659-10-022730:8k_2_02:52]
This
press release contains “forward-looking statements” as that term is defined in
the Private Securities Litigation Reform Act of 1995. Such forward-looking
statements include, but are not limited to, statements about the timing and
financial impact of the launch of new products and Motorola’s financial outlook
for the second quarter of 2010. Motorola cautions the reader that the risk
factors

[0001104659-10-022730:8k_2_02:53]
below,
as well as those on pages 17 through 29 in Item 1A of Motorola’s 2009
Annual Report on Form 10-K and in its other SEC filings, could cause
Motorola’s actual results to differ materially from those estimated or
predicted in the forward-looking statements. Factors that may impact
forward-looking statements include, but are not limited to: (1) possible
negative effects on the Company’s business operations, financial performance or
assets as a result of its plan to create two independent, publicly traded
companies; (2) the economic outlook for the telecommunications and
broadband industries; (3) the Company’s ability to improve financial
performance in its Mobile Devices business, including the success of its
smartphone strategy; (4) Mobile Device’s dependency on third-party
operating systems and software, including Google’s Android operating system; (5) the
level of demand for the Company’s products, particularly if consumers,
businesses and governments defer purchases in response to tighter credit; (6) the
Company’s ability to introduce new products and technologies in a timely
manner; (7) unexpected negative consequences from the Company’s
restructuring and cost reduction activities, including as a result of
significant restructuring at the Mobile Devices business; (8) negative
impact on the Company’s business from global economic conditions, which may
include: (i) the inability of customers to obtain financing for purchases
of the Company’s products; (ii) the viability of the Company’s suppliers
that may no longer have access to necessary financing; (iii) changes in
the value of investments held by the Company’s pension plan and other defined
benefit plans; (iv) fair and/or actual value of the Company’s debt and
equity investments differing significantly from the fair values currently
assigned to them; (v) counterparty failures negatively impacting the
Company’s financial position; (vi) difficulties or increased costs for the
Company in obtaining financing; and (vii) the inability of the Company to
sell accounts receivable and long-term receivables in volumes and on terms
comparable to historical practices; (9) the Company’s ability to purchase
sufficient materials, parts and components to meet customer demand,
particularly in light of global economic conditions; (10) risks related to
dependence on certain key suppliers; (11) the impact on the Company’s
performance and financial results from strategic acquisitions or divestitures,
including those that may occur in the future; (12) risks related to the Company’s
high volume of manufacturing in Asia; (13) the creditworthiness of the Company’s
customers and distributors, particularly purchasers of large infrastructure
systems; (14) variability in income received from licensing the Company’s
intellectual property to others, as well as expenses incurred when the Company
licenses intellectual property from others; (15) unexpected liabilities or expenses,
including unfavorable outcomes to any pending or future litigation or
regulatory or similar proceedings; (16) the impact of foreign currency
fluctuations, including the negative impact of a strengthening U.S. dollar on
the Company when competing for business in foreign markets; (17) the impact on
the Company from continuing hostilities in countries where the Company does
business; (18) the impact on the Company from ongoing consolidation in the
telecommunications and broadband industries; (19) the impact of changes in
governmental policies, laws or regulations; (20) the outcome of currently
ongoing and future tax matters; and

[0001104659-10-022730:8k_2_02:54]
(21)
negative consequences from the Company’s outsourcing of various activities,
including certain manufacturing, information technology and administrative
functions. Motorola undertakes no obligation to publicly update any
forward-looking statement or risk factor, whether as a result of new
information, future events or otherwise.

[0001104659-10-022730:8k_2_02:55]
Definitions

[0001104659-10-022730:8k_2_02:56]
*
Total cash equals Cash and cash equivalents plus Sigma Fund (current and non-current) plus Short-term investments.

[0001104659-10-022730:8k_2_02:57]
**
Amounts attributable to Motorola, Inc. common shareholders

[0001104659-10-022730:8k_2_02:58]
***
Due to rounding, EPS impact may not be equal to the sum of individual items.

[0001104659-10-022730:8k_2_02:59]
About
Motorola

[0001104659-10-022730:8k_2_02:60]
Motorola is known around the
world for innovation in communications and is focused on advancing the way the
world connects. From broadband communications infrastructure, enterprise
mobility and public safety solutions to high-definition video and mobile devices,
Motorola is leading the next wave of innovations that enable people,
enterprises and governments to be more connected and more mobile. Motorola
(NYSE: MOT) had sales of US $22 billion in 2009. For more information, please
visit www.motorola.com.

[0001104659-10-022730:8k_2_02:61]
# #
#

[0001104659-10-022730:8k_2_02:62]
Media contact:

[0001104659-10-022730:8k_2_02:63]
Jennifer
Erickson

[0001104659-10-022730:8k_2_02:64]
Motorola, Inc.

[0001104659-10-022730:8k_2_02:65]
+1
847-435-5320

[0001104659-10-022730:8k_2_02:66]
jennifer.erickson@motorola.com

[0001104659-10-022730:8k_2_02:67]
Investor contact:

[0001104659-10-022730:8k_2_02:68]
Dean
Lindroth

[0001104659-10-022730:8k_2_02:69]
Motorola, Inc.

[0001104659-10-022730:8k_2_02:70]
+1 847-576-6899

[0001104659-10-022730:8k_2_02:71]
dean.lindroth@motorola.com

[0001104659-10-022730:8k_2_02:72]
MOTOROLA and the Stylized M Logo are registered in
the US Patent & Trademark Office. All other product or service names
are the property of their respective owners. © Motorola, Inc. 2010. All
rights reserved.

[0001104659-10-022730:8k_2_02:73]
Motorola, Inc. and Subsidiaries

[0001104659-10-022730:8k_2_02:74]
Condensed Consolidated Statements of Operations

[0001104659-10-022730:8k_2_02:75]
(In millions, except per share amounts)

[0001104659-10-022730:8k_2_02:76]
|  |  | Three Months Ended |  |
|  |  | April 3, 2010 |  | December 31, 2009 |  | April 4, 2009 |  |
| Net sales |  | $ | 5,044 |  | $ | 5,723 |  | $ | 5,371 |  |
| Costs of sales |  | 3,258 |  | 3,680 |  | 3,875 |  |
| Gross margin |  | 1,786 |  | 2,043 |  | 1,496 |  |
| Selling, general and administrative expenses |  | 876 |  | 890 |  | 869 |  |
| Research and development expenditures |  | 757 |  | 793 |  | 847 |  |
| Separation-related transaction costs |  | 25 |  | 23 |  | — |  |
| Other charges (income) |  | (13 | ) | 106 |  | 158 |  |
| Intangibles amortization |  | 65 |  | 68 |  | 71 |  |
| Operating earnings (loss) |  | 76 |  | 163 |  | (449 | ) |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest expense, net |  | (33 | ) | (18 | ) | (35 | ) |
| Gain (loss) on sales of investments and businesses, net |  | 8 |  | 57 |  | (20 | ) |
| Other |  | 12 |  | (2 | ) | 70 |  |
| Total other income (expense) |  | (13 | ) | 37 |  | 15 |  |
| Earnings (loss) from continuing operations before income taxes |  | 63 |  | 200 |  | (434 | ) |
| Income tax expense (benefit) |  | (5 | ) | 57 |  | (146 | ) |
| Earnings (loss) from continuing operations |  | 68 |  | 143 |  | (288 | ) |
| Earnings from discontinued operations, net of tax |  | — |  | — |  | 60 |  |
| Net earnings (loss) |  | 68 |  | 143 |  | (228 | ) |
| Less: Earnings (loss) attributable to noncontrolling interests |  | (1 | ) | 1 |  | 3 |  |
| Net earnings (loss) attributable to Motorola, Inc. |  | $ | 69 |  | $ | 142 |  | $ | (231 | ) |
| Amounts attributable to Motorola, Inc. common shareholders |  |  |  |  |  |  |  |
| Earnings (loss) from continuing operations, net of tax |  | $ | 69 |  | $ | 142 |  | $ | (291 | ) |
| Earnings from discontinued operations, net of tax |  | — |  | — |  | 60 |  |
| Net earnings (loss) |  | $ | 69 |  | $ | 142 |  | $ | (231 | ) |
| Earnings (loss) per common share |  |  |  |  |  |  |  |
| Basic: |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.03 |  | $ | 0.06 |  | $ | (0.13 | ) |
| Discontinued operations |  | — |  | — |  | 0.03 |  |
|  |  | $ | 0.03 |  | $ | 0.06 |  | $ | (0.10 | ) |
| Diluted: |  |  |  |  |  |  |  |
| Continuing operations |  | $ | 0.03 |  | $ | 0.06 |  | $ | (0.13 | ) |
| Discontinued operations |  | — |  | — |  | 0.03 |  |
|  |  | $ | 0.03 |  | $ | 0.06 |  | $ | (0.10 | ) |
| Weighted average common shares outstanding |  |  |  |  |  |  |  |
| Basic |  | 2,315.7 |  | 2,311.4 |  | 2,280.5 |  |
| Diluted |  | 2,341.3 |  | 2,330.0 |  | 2,280.5 |  |
| Dividends paid per share |  | $ | — |  | $ | — |  | $ | 0.05 |  |

[0001104659-10-022730:8k_2_02:77]
|  |  | Percentage of Net Sales* |  |
| Net sales |  | 100 | % | 100 | % | 100 | % |
| Costs of sales |  | 64.6 | % | 64.3 | % | 72.1 | % |
| Gross margin |  | 35.4 | % | 35.7 | % | 27.9 | % |
| Selling, general and administrative expenses |  | 17.4 | % | 15.6 | % | 16.2 | % |
| Research and development expenditures |  | 15.0 | % | 13.9 | % | 15.8 | % |
| Separation-related transaction costs |  | 0.5 | % | 0.4 | % | 0.0 | % |
| Other charges (income) |  | -0.3 | % | 1.9 | % | 2.9 | % |
| Intangibles amortization |  | 1.3 | % | 1.2 | % | 1.3 | % |
| Operating earnings (loss) |  | 1.5 | % | 2.8 | % | -8.4 | % |
| Other income (expense): |  |  |  |  |  |  |  |
| Interest exense, net |  | -0.7 | % | -0.3 | % | -0.7 | % |
| Gain (loss) on sales of investments and businesses, net |  | 0.2 | % | 1.0 | % | -0.4 | % |
| Other |  | 0.2 | % | 0.0 | % | 1.3 | % |
| Total other income (expense) |  | -0.3 | % | 0.6 | % | 0.3 | % |
| Earnings (loss) from continuing operations before income taxes |  | 1.2 | % | 3.5 | % | -8.1 | % |
| Income tax expense (benefit) |  | -0.1 | % | 1.0 | % | -2.7 | % |
| Earnings (loss) from continuing operations |  | 1.3 | % | 2.5 | % | -5.4 | % |
| Earnings from discontinued operations, net of tax |  | 0.0 | % | 0.0 | % | 1.1 | % |
| Net earnings (loss) |  | 1.3 | % | 2.5 | % | -4.2 | % |
| Less: Earnings (loss) attributable to noncontrolling interests |  | 0.0 | % | 0.0 | % | 0.1 | % |
| Net earnings (loss) attributable to Motorola, Inc. |  | 1.4 | % | 2.5 | % | -4.3 | % |

[0001104659-10-022730:8k_2_02:78]
*
Percentages may not add up due to rounding

[0001104659-10-022730:8k_2_02:79]
Motorola, Inc. and Subsidiaries

[0001104659-10-022730:8k_2_02:80]
Condensed Consolidated Balance Sheets

[0001104659-10-022730:8k_2_02:81]
(In millions)

[0001104659-10-022730:8k_2_02:82]
|  |  | April 3, |  | December 31, |  | April 4, |  |
|  |  | 2010 |  | 2009 |  | 2009 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 3,188 |  | $ | 2,869 |  | $ | 3,265 |  |
| Sigma Fund |  | 5,174 |  | 5,092 |  | 2,587 |  |
| Short-term investments |  | 6 |  | 2 |  | 19 |  |
| Accounts receivable, net |  | 3,086 |  | 3,495 |  | 3,689 |  |
| Inventories, net |  | 1,251 |  | 1,308 |  | 2,071 |  |
| Deferred income taxes |  | 1,125 |  | 1,082 |  | 1,161 |  |
| Other current assets |  | 2,066 |  | 2,184 |  | 2,919 |  |
| Total current assets |  | 15,896 |  | 16,032 |  | 15,711 |  |
| Property, plant and equipment, net |  | 2,088 |  | 2,154 |  | 2,322 |  |
| Sigma Fund |  | 116 |  | 66 |  | 257 |  |
| Investments |  | 408 |  | 459 |  | 498 |  |
| Deferred income taxes |  | 2,253 |  | 2,284 |  | 2,445 |  |
| Goodwill |  | 2,830 |  | 2,823 |  | 2,822 |  |
| Other assets |  | 1,669 |  | 1,785 |  | 1,708 |  |
| Total assets |  | $ | 25,260 |  | $ | 25,603 |  | $ | 25,763 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |
| Notes payable and current portion of long-term debt |  | $ | 532 |  | $ | 536 |  | $ | 63 |  |
| Accounts payable |  | 2,147 |  | 2,429 |  | 2,265 |  |
| Accrued liabilities |  | 5,194 |  | 5,296 |  | 6,728 |  |
| Total current liabilities |  | 7,873 |  | 8,261 |  | 9,056 |  |
| Long-term debt |  | 3,372 |  | 3,365 |  | 3,878 |  |
| Other liabilities |  | 3,970 |  | 4,094 |  | 3,463 |  |
| Total Motorola, Inc. stockholders’ equity |  | 9,944 |  | 9,775 |  | 9,275 |  |
| Noncontrolling interests |  | 101 |  | 108 |  | 91 |  |
| Total liabilities and stockholders’ equity |  | $ | 25,260 |  | $ | 25,603 |  | $ | 25,763 |  |
| Financial Ratios: |  |  |  |  |  |  |  |
| Total cash* |  | $ | 8,484 |  | $ | 8,029 |  | $ | 6,128 |  |

[0001104659-10-022730:8k_2_02:83]
*Total
cash = Cash and cash equivalents + Sigma Fund (current and non-current) +
Short-term investments

[0001104659-10-022730:8k_2_02:84]
Motorola, Inc.
and Subsidiaries

[0001104659-10-022730:8k_2_02:85]
Condensed
Consolidated Statements of Cash Flows

[0001104659-10-022730:8k_2_02:86]
(In
millions)

[0001104659-10-022730:8k_2_02:87]
|  |  | Three Months Ended |  |
|  |  | April 3, 2010 |  | December 31, 2009 |  | April 4, 2009 |  |
| Operating |  |  |  |  |  |  |  |
| Net earnings (loss) attributable to Motorola, Inc. |  | $ | 69 |  | $ | 142 |  | $ | (231 | ) |
| Earnings (loss) attributable to the noncontrolling interest |  | (1 | ) | 1 |  | 3 |  |
| Net earnings (loss) |  | 68 |  | 143 |  | (228 | ) |
| Earnings from discontinued operations, net of tax |  | — |  | — |  | 60 |  |
| Earnings (loss) from continuing operations |  | 68 |  | 143 |  | (288 | ) |
| Adjustments to reconcile earnings (loss) from continuing operations to net cash provided by (used for) operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  | 173 |  | 180 |  | 190 |  |
| Non-cash other charges |  | (21 | ) | (5 | ) | (63 | ) |
| Share-based compensation expense |  | 72 |  | 71 |  | 76 |  |
| Loss (gain) on sales of investments and businesses, net |  | (8 | ) | (58 | ) | 20 |  |
| Deferred income taxes, including change in valuation allowance |  | (22 | ) | 164 |  | (197 | ) |
| Changes in assets and liabilities, net of effects of acquisitions and dispositions: |  |  |  |  |  |  |  |
| Accounts receivable |  | 411 |  | (94 | ) | (204 | ) |
| Inventories |  | 58 |  | 223 |  | 582 |  |
| Other current assets |  | 114 |  | — |  | 217 |  |
| Accounts payable and accrued liabilities |  | (388 | ) | 164 |  | (1,355 | ) |
| Other assets and liabilities |  | 28 |  | 89 |  | 8 |  |
| Net cash provided by (used for) operating activities |  | 485 |  | 877 |  | (1,014 | ) |
| Investing |  |  |  |  |  |  |  |
| Acquisitions and investments, net |  | (23 | ) | (20 | ) | (15 | ) |
| Proceeds from sales of investments and businesses, net |  | 22 |  | 35 |  | 137 |  |
| Capital expenditures |  | (70 | ) | (86 | ) | (71 | ) |
| Proceeds from sales of property, plant and equipment |  | 28 |  | 14 |  | 3 |  |
| Proceeds from sales (purchases) of Sigma Fund investments, net |  | (116 | ) | (1,020 | ) | 1,319 |  |
| Proceeds from sales (purchases) of short-term investments, net |  | (4 | ) | 14 |  | 206 |  |
| Net cash provided by (used for) investing activities |  | (163 | ) | (1,063 | ) | 1,579 |  |
| Financing |  |  |  |  |  |  |  |
| Repayment of short-term borrowings, net |  | (4 | ) | (15 | ) | (31 | ) |
| Repayment of debt |  | (2 | ) | (2 | ) | (129 | ) |
| Issuance of common stock |  | 63 |  | 6 |  | 56 |  |
| Payment of dividends |  | — |  | — |  | (114 | ) |
| Other, net |  | (8 | ) | (1 | ) | — |  |
| Net cash provided by (used for) financing activities |  | 49 |  | (12 | ) | (218 | ) |
| Effect of exchange rate changes on cash and cash equivalents |  | (52 | ) | 17 |  | (146 | ) |
| Net increase (decrease) in cash and cash equivalents |  | 319 |  | (181 | ) | 201 |  |
| Cash and cash equivalents, beginning of period |  | 2,869 |  | 3,050 |  | 3,064 |  |
| Cash and cash equivalents, end of period |  | $ | 3,188 |  | $ | 2,869 |  | $ | 3,265 |  |

[0001104659-10-022730:8k_2_02:88]
Motorola, Inc.
and Subsidiaries

[0001104659-10-022730:8k_2_02:89]
Segment
Information

[0001104659-10-022730:8k_2_02:90]
(In
millions)

[0001104659-10-022730:8k_2_02:91]
Summarized below are the
Company’s Net sales and Operating earnings (loss) by reportable segment for the
three months ended April 3, 2010 and April 4, 2009.

[0001104659-10-022730:8k_2_02:92]
|  |  | Net Sales |  |
|  |  | Three Months Ended April 3, 2010 |  | Three Months Ended April 4, 2009 |  | % Change from 2009 |  |
| Mobile Devices |  | $ | 1,641 |  | $ | 1,801 |  | -9 | % |
| Home |  | 838 |  | 1,025 |  | -18 | % |
| Enterprise Mobility Solutions |  | 1,694 |  | 1,599 |  | 6 | % |
| Networks |  | 896 |  | 966 |  | -7 | % |
| Segment Totals |  | 5,069 |  | 5,391 |  | -6 | % |
| Other and Eliminations |  | (25 | ) | (20 | ) | 25 | % |
| Company Totals |  | $ | 5,044 |  | $ | 5,371 |  | -6 | % |

[0001104659-10-022730:8k_2_02:93]
|  |  | Operating Earnings (Loss) |  |
|  |  | Three Months Ended April 3, 2010 |  | Three Months Ended April 4, 2009 |  | % Change from 2009 |  |
| Mobile Devices |  | $ | (192 | ) | $ | (545 | ) | -65 | % |
| Home |  | 20 |  | 3 |  | 567 | % |
| Enterprise Mobility Solutions |  | 141 |  | 66 |  | 114 | % |
| Networks |  | 112 |  | 62 |  | 81 | % |
| Segment Totals |  | 81 |  | (414 | ) | *** |  |
| Other and Eliminations |  | (5 | ) | (35 | ) | -86 | % |
| Company Totals |  | $ | 76 |  | $ | (449 | ) | *** |  |

[0001104659-10-022730:8k_2_02:94]
***
Percentage change is not meaningful.
