# MSI 10-Q controls and the auditor's report


## item_4_controls

[0001047469-10-004771:item_4_controls:1]
Item 4. Controls and Procedures

[0001047469-10-004771:item_4_controls:2]
(a)    Evaluation of disclosure controls and procedures.    Under the supervision and with the participation of our
senior management, including our chief executive officers and chief financial officer, we conducted an evaluation of the effectiveness of the design and operation of our disclosure controls and
procedures, as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended (the "Exchange Act"), as of the end of the period covered
by this quarterly report (the "Evaluation Date"). Based on this evaluation, our chief executive officers and chief financial officer concluded as of the Evaluation Date that our disclosure controls
and procedures were effective such that the information relating to Motorola, including our consolidated subsidiaries, required to be disclosed in our Securities and Exchange Commission ("SEC")
reports (i) is recorded, processed, summarized and reported within the time periods specified in SEC rules and forms, and (ii) is accumulated and communicated to Motorola's management,
including our chief executive officers and chief financial officer, as appropriate to allow timely decisions regarding required disclosure.

[0001047469-10-004771:item_4_controls:3]
(b)    Changes in internal control over financial reporting.    There have been no changes in our internal control
over financial reporting that occurred during the quarter ended April 3, 2010, that have materially affected or are reasonably likely to materially affect our internal control over financial
reporting.

[0001047469-10-004771:item_4_controls:4]
|  |  |  | 53 |
