# CIEN 8-K — 0000936395-18-000009 filed 2018-03-06

## item codes, every 8-K on or before 2018-03-07

- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2018-03-07

- none on or before 2018-03-07

## item 2.02 — earnings release, exhibit 99.1

[0000936395-18-000009:8k_2_02:1]
EX-99.1
2
exhibit991-2018q1earningsp.htm
EXHIBIT 99.1

[0000936395-18-000009:8k_2_02:2]
Exhibit

[0000936395-18-000009:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-18-000009:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2018 Financial Results

[0000936395-18-000009:8k_2_02:5]
HANOVER, Md. - March 6, 2018 - Ciena® Corporation (NYSE:  CIEN)

[0000936395-18-000009:8k_2_02:6]
| • | Q1 Revenue: $646.1 million, increasing 4% year over year |

[0000936395-18-000009:8k_2_02:7]
| • | Q1 Net Income (Loss) per Share: $(3.29) GAAP; $0.15 adjusted (non-GAAP) |

[0000936395-18-000009:8k_2_02:8]
| ◦ | GAAP loss primarily due to significant non-cash charges related to the Tax Cuts and Jobs Act, which resulted in an estimated $476.9 million of additional tax expense |

[0000936395-18-000009:8k_2_02:9]
| • | Share Repurchase: Commenced repurchase activity on three-year, $300 million repurchase program during Q1 |

[0000936395-18-000009:8k_2_02:10]
Ciena, a network strategy and technology company, today announced unaudited financial results for its fiscal first quarter ended January 31, 2018.

[0000936395-18-000009:8k_2_02:11]
“We demonstrated a strong start toward achieving our long-term financial goals with our fiscal first quarter results, including year-over-year top-line growth, continued cash generation and a strengthening balance sheet,” said Gary B. Smith, president and CEO, Ciena. “We also are confident in our ability to continue driving market share gains across key geographies and customer segments by intersecting the industry’s demand drivers with leading innovation.”

[0000936395-18-000009:8k_2_02:12]
For the fiscal first quarter 2018, Ciena reported revenue of $646.1 million as compared to $621.5 million for the fiscal first quarter 2017.

[0000936395-18-000009:8k_2_02:13]
Ciena's fiscal first quarter 2018 GAAP results include a non-cash $476.9 million charge related to the enactment of the Tax Cuts and Jobs Act. As a result, Ciena's GAAP net loss for the fiscal first quarter 2018 was $(473.4) million, or $(3.29) per diluted common share, which compares to a GAAP net income of $3.9 million, or $0.03 per diluted common share, for the fiscal first quarter 2017.

[0000936395-18-000009:8k_2_02:14]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2018 was $21.9 million, or $0.15 per diluted common share, which compares to an adjusted (non-GAAP) net income of $24.6 million, or $0.17 per diluted common share, for the fiscal first quarter 2017.

[0000936395-18-000009:8k_2_02:15]
Share Repurchase Program

[0000936395-18-000009:8k_2_02:16]
On December 7, 2017, Ciena announced that its Board of Directors had authorized a program to repurchase up to $300 million of the Company’s common stock through the end of fiscal 2020. The Company commenced repurchases late in the fiscal first quarter 2018, and through March 5, 2018, has repurchased approximately 874,000

[0000936395-18-000009:8k_2_02:17]
shares of its common stock, for an aggregate purchase price of $19.5 million at an average price of $22.34 per share.

[0000936395-18-000009:8k_2_02:18]
Fiscal First Quarter 2018 Performance Summary

[0000936395-18-000009:8k_2_02:19]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendix A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-18-000009:8k_2_02:20]
|  |  | GAAP Results |
|  |  | Q1 |  | Q1 |  | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 646.1 |  |  | $ | 621.5 |  |  | 4.0 | % |
| Gross margin |  | 42.1 | % |  | 44.1 | % |  | (2.0 | )% |
| Operating expense |  | $ | 255.0 |  |  | $ | 254.7 |  |  | 0.1 | % |
| Operating margin |  | 2.6 | % |  | 3.1 | % |  | (0.5 | )% |

[0000936395-18-000009:8k_2_02:21]
|  |  | Non-GAAP Results |
|  |  | Q1 |  | Q1 |  | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 646.1 |  |  | $ | 621.5 |  |  | 4.0 | % |
| Adj. gross margin |  | 42.6 | % |  | 44.9 | % |  | (2.3 | )% |
| Adj. operating expense |  | $ | 234.4 |  |  | $ | 226.2 |  |  | 3.6 | % |
| Adj. operating margin |  | 6.3 | % |  | 8.5 | % |  | (2.2 | )% |
| Adj. EBITDA |  | $ | 61.8 |  |  | $ | 69.9 |  |  | (11.6 | )% |

[0000936395-18-000009:8k_2_02:22]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-18-000009:8k_2_02:23]
|  |  | Revenue by Segment |
|  |  | Q1 FY 2018 |  | Q1 FY 2017 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical 1 |  | $ | 427.4 |  |  | 66.1 |  | $ | 417.8 |  |  | 67.2 |
| Packet Networking |  | 68.6 |  |  | 10.6 |  | 72.2 |  |  | 11.6 |
| Total Networking Platforms |  | 496.0 |  |  | 76.7 |  | 490.0 |  |  | 78.8 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |
| Software Platforms |  | 29.6 |  |  | 4.6 |  | 17.0 |  |  | 2.7 |
| Software-Related Services |  | 23.9 |  |  | 3.7 |  | 22.3 |  |  | 3.6 |
| Total Software and Software-Related Services |  | 53.5 |  |  | 8.3 |  | 39.3 |  |  | 6.3 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 56.0 |  |  | 8.7 |  | 55.0 |  |  | 8.9 |
| Installation and Deployment |  | 30.0 |  |  | 4.7 |  | 27.9 |  |  | 4.5 |
| Consulting and Network Design |  | 10.6 |  |  | 1.6 |  | 9.3 |  |  | 1.5 |
| Total Global Services |  | 96.6 |  |  | 15.0 |  | 92.2 |  |  | 14.9 |
| Total |  | $ | 646.1 |  |  | 100.0 |  | $ | 621.5 |  |  | 100.0 |

[0000936395-18-000009:8k_2_02:24]
1. As of the first fiscal quarter of 2018, sales of Optical Transport products are reflected within the Converged Packet Optical product line for all periods presented.

[0000936395-18-000009:8k_2_02:25]
Additional Performance Metrics for Fiscal First Quarter 2018

[0000936395-18-000009:8k_2_02:26]
|  |  | Revenue by Geographic Region |
|  |  | Q1 FY 2018 |  | Q1 FY 2017 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 402.9 |  |  | 62.4 |  | $ | 405.9 |  |  | 65.3 |
| Europe, Middle East and Africa |  | 97.8 |  |  | 15.1 |  | 91.5 |  |  | 14.7 |
| Caribbean and Latin America |  | 34.6 |  |  | 5.4 |  | 35.2 |  |  | 5.7 |
| Asia Pacific |  | 110.8 |  |  | 17.1 |  | 88.9 |  |  | 14.3 |
| Total |  | $ | 646.1 |  |  | 100.0 |  | $ | 621.5 |  |  | 100.0 |

[0000936395-18-000009:8k_2_02:27]
**  Denotes %  of total revenue

[0000936395-18-000009:8k_2_02:28]
| • | U.S. customers contributed 59.3% of total revenue |

[0000936395-18-000009:8k_2_02:29]
| • | Two customers each accounted for greater than 10% of revenue and in aggregate represented 25% of total revenue |

[0000936395-18-000009:8k_2_02:30]
| • | Cash and investments totaled $986.8 million |

[0000936395-18-000009:8k_2_02:31]
| • | Cash flow from operations totaled $35.7 million |

[0000936395-18-000009:8k_2_02:32]
| • | Free cash flow totaled $10.0 million |

[0000936395-18-000009:8k_2_02:33]
| • | Average days' sales outstanding (DSOs) were 77 |

[0000936395-18-000009:8k_2_02:34]
| • | Accounts receivable balance was $553.7 million |

[0000936395-18-000009:8k_2_02:35]
| • | Inventories totaled $255.3 million, including: |

[0000936395-18-000009:8k_2_02:36]
| ◦ | Raw materials: $47.7 million |

[0000936395-18-000009:8k_2_02:37]
| ◦ | Work in process: $16.5 million |

[0000936395-18-000009:8k_2_02:38]
| ◦ | Finished goods: $176.5 million |

[0000936395-18-000009:8k_2_02:39]
| ◦ | Deferred cost of sales: $64.4 million |

[0000936395-18-000009:8k_2_02:40]
| ◦ | Reserve for excess and obsolescence: $(49.8) million |

[0000936395-18-000009:8k_2_02:41]
| • | Product inventory turns were 4.9 |

[0000936395-18-000009:8k_2_02:42]
| • | Headcount totaled 5,712 |

[0000936395-18-000009:8k_2_02:43]
Impact of the Tax Cuts and Jobs Act

[0000936395-18-000009:8k_2_02:44]
The first fiscal quarter 2018 provision for income taxes includes the following significant non-cash charges related to the enactment of the Tax Cuts and Jobs Act:

[0000936395-18-000009:8k_2_02:45]
| • | $431.3 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Cuts and Jobs Act; and |

[0000936395-18-000009:8k_2_02:46]
| • | $45.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S. |

[0000936395-18-000009:8k_2_02:47]
Ciena continues to evaluate the impact of the Tax Cuts and Jobs Act. At this time, Ciena does not expect to pay substantial cash taxes for U.S. federal income tax for the foreseeable future primarily due to its deferred tax asset balance. As of January 31, 2018, Ciena has net deferred tax assets of approximately $739.4 million, and consequently, over the near term, Ciena's cash taxes will continue to be primarily related to the state taxes and tax expense of Ciena's foreign subsidiaries, which amounts have not historically been significant. Ciena's foreign and domestic income tax expense for the first quarter of fiscal 2018 and 2017 expected to be paid using cash was $1.0 million and $0.4 million, respectively.

[0000936395-18-000009:8k_2_02:48]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal First Quarter 2018 Results

[0000936395-18-000009:8k_2_02:49]
Today, Tuesday, March 6, 2018, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website supporting materials for its unaudited fiscal first quarter 2018 results, including prepared remarks from management and a related investor presentation.

[0000936395-18-000009:8k_2_02:50]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's fiscal second quarter outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-18-000009:8k_2_02:51]
Notes to Investors

[0000936395-18-000009:8k_2_02:52]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We demonstrated a strong start toward achieving our long-term financial goals with our fiscal first quarter results, including year-over-year top-line

[0000936395-18-000009:8k_2_02:53]
growth, continued cash generation and a strengthening balance sheet"; "We also are confident in our ability to continue driving market share gains across key geographies and customer segments by intersecting the industry’s demand drivers with leading innovation".

[0000936395-18-000009:8k_2_02:54]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act, changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's Report on Form 10-K, which Ciena filed with the Securities and Exchange Commission on December 22, 2017. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-18-000009:8k_2_02:55]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-18-000009:8k_2_02:56]
About Ciena.  Ciena (NYSE: CIEN) is a network strategy and technology company. We translate best-in-class technology into value through a high-touch, consultative business model - with a relentless drive to create exceptional experiences measured by outcomes. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-18-000009:8k_2_02:57]
CIENA CORPORATION

[0000936395-18-000009:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-18-000009:8k_2_02:59]
(in thousands, except per share data)

[0000936395-18-000009:8k_2_02:60]
(unaudited)

[0000936395-18-000009:8k_2_02:61]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Revenue: |  |  |  |
| Products | $ | 525,609 |  |  | $ | 506,993 |  |
| Services | 120,526 |  |  | 114,504 |  |
| Total revenue | 646,135 |  |  | 621,497 |  |
| Cost of goods sold: |  |  |  |
| Products | 313,120 |  |  | 286,811 |  |
| Services | 61,250 |  |  | 60,901 |  |
| Total cost of goods sold | 374,370 |  |  | 347,712 |  |
| Gross profit | 271,765 |  |  | 273,785 |  |
| Operating expenses: |  |  |  |
| Research and development | 118,524 |  |  | 116,869 |  |
| Selling and marketing | 88,515 |  |  | 85,002 |  |
| General and administrative | 38,406 |  |  | 35,864 |  |
| Amortization of intangible assets | 3,623 |  |  | 14,551 |  |
| Significant asset impairments and restructuring costs | 5,961 |  |  | 2,395 |  |
| Total operating expenses | 255,029 |  |  | 254,681 |  |
| Income from operations | 16,736 |  |  | 19,104 |  |
| Interest and other income (loss), net | 1,575 |  |  | 370 |  |
| Interest expense | (13,734 | ) |  | (15,203 | ) |
| Income before income taxes | 4,577 |  |  | 4,271 |  |
| Provision for income taxes 1 | 477,940 |  |  | 410 |  |
| Net income (loss) | $ | (473,363 | ) |  | $ | 3,861 |  |
| Net Income (Loss) per Common Share |  |  |  |
| Basic net income (loss) per common share | $ | (3.29 | ) |  | $ | 0.03 |  |
| Diluted net income (loss) per potential common share | $ | (3.29 | ) |  | $ | 0.03 |  |
| Weighted average basic common shares outstanding | 143,922 |  |  | 140,682 |  |
| Weighted average dilutive potential common shares outstanding 2 | 143,922 |  |  | 142,184 |  |

[0000936395-18-000009:8k_2_02:62]
1.  The provision for income taxes for the first quarter of fiscal 2018 is primarily related to the enactment of the Tax Cuts and Jobs Act. These amounts are provisional and reflect management’s current estimates and current interpretations of the Tax Cuts and Jobs Act. These amounts may require adjustment in future periods as additional guidance under the Tax Cuts and Jobs Act becomes available and analysis of its provisions is completed.

[0000936395-18-000009:8k_2_02:63]
2. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first quarter of fiscal 2017 includes 1.5 million shares underlying certain stock options and restricted stock units.

[0000936395-18-000009:8k_2_02:64]
CIENA CORPORATION

[0000936395-18-000009:8k_2_02:65]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-18-000009:8k_2_02:66]
(in thousands, except share data)

[0000936395-18-000009:8k_2_02:67]
(unaudited)

[0000936395-18-000009:8k_2_02:68]
|  | January 31, 2018 |  | October 31, 2017 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 648,867 |  |  | $ | 640,513 |  |
| Short-term investments | 278,743 |  |  | 279,133 |  |
| Accounts receivable, net | 553,724 |  |  | 622,183 |  |
| Inventories | 255,251 |  |  | 267,143 |  |
| Prepaid expenses and other | 186,837 |  |  | 197,339 |  |
| Total current assets | 1,923,422 |  |  | 2,006,311 |  |
| Long-term investments | 59,151 |  |  | 49,783 |  |
| Equipment, building, furniture and fixtures, net | 318,835 |  |  | 308,465 |  |
| Goodwill | 267,899 |  |  | 267,458 |  |
| Other intangible assets, net | 96,485 |  |  | 100,997 |  |
| Deferred tax asset, net | 739,446 |  |  | 1,155,104 |  |
| Other long-term assets | 64,146 |  |  | 63,593 |  |
| Total assets | $ | 3,469,384 |  |  | $ | 3,951,711 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 209,243 |  |  | $ | 260,098 |  |
| Accrued liabilities and other short-term obligations | 268,164 |  |  | 322,934 |  |
| Deferred revenue | 103,216 |  |  | 102,418 |  |
| Current portion of long-term debt | 352,753 |  |  | 352,293 |  |
| Total current liabilities | 933,376 |  |  | 1,037,743 |  |
| Long-term deferred revenue | 79,297 |  |  | 82,589 |  |
| Other long-term obligations | 115,970 |  |  | 111,349 |  |
| Long-term debt, net | 584,601 |  |  | 583,688 |  |
| Total liabilities | $ | 1,713,244 |  |  | $ | 1,815,369 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 144,180,782 and 143,043,227 shares issued and outstanding | 1,442 |  |  | 1,430 |  |
| Additional paid-in capital | 6,828,648 |  |  | 6,810,182 |  |
| Accumulated other comprehensive income (loss) | 2,375 |  |  | (11,017 | ) |
| Accumulated deficit | (5,076,325 | ) |  | (4,664,253 | ) |
| Total stockholders’ equity | 1,756,140 |  |  | 2,136,342 |  |
| Total liabilities and stockholders’ equity | $ | 3,469,384 |  |  | $ | 3,951,711 |  |

[0000936395-18-000009:8k_2_02:69]
CIENA CORPORATION

[0000936395-18-000009:8k_2_02:70]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-18-000009:8k_2_02:71]
(in thousands)

[0000936395-18-000009:8k_2_02:72]
(unaudited)

[0000936395-18-000009:8k_2_02:73]
|  | Three Months Ended January 31, |
|  | 2018 |  | 2017 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income (loss) | $ | (473,363 | ) |  | $ | 3,861 |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 20,833 |  |  | 16,699 |  |
| Share-based compensation costs | 12,393 |  |  | 12,825 |  |
| Amortization of intangible assets | 5,912 |  |  | 18,864 |  |
| Deferred taxes | 476,897 |  |  | — |  |
| Provision for inventory excess and obsolescence | 6,804 |  |  | 5,431 |  |
| Provision for warranty | 4,657 |  |  | 553 |  |
| Other | 2,269 |  |  | 4,452 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 72,439 |  |  | (21,956 | ) |
| Inventories | 5,199 |  |  | (78,749 | ) |
| Prepaid expenses and other | 16,120 |  |  | (1,004 | ) |
| Accounts payable, accruals and other obligations | (111,476 | ) |  | 4,037 |  |
| Deferred revenue | (2,981 | ) |  | 8,737 |  |
| Net cash provided by (used in) operating activities | 35,703 |  |  | (26,250 | ) |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (25,662 | ) |  | (25,706 | ) |
| Purchase of available for sale securities | (118,877 | ) |  | (89,897 | ) |
| Proceeds from maturities of available for sale securities | 110,000 |  |  | 95,000 |  |
| Settlement of foreign currency forward contracts, net | 1,061 |  |  | 440 |  |
| Net cash used in investing activities | (33,478 | ) |  | (20,163 | ) |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Payment of long term debt | (1,000 | ) |  | (46,296 | ) |
| Payment of capital lease obligations | (914 | ) |  | (605 | ) |
| Repurchases of common stock-repurchase program | (4,103 | ) |  | — |  |
| Proceeds from issuance of common stock | 11,008 |  |  | 9,708 |  |
| Net cash provided by (used in) financing activities | 4,991 |  |  | (37,193 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 1,138 |  |  | (156 | ) |
| Net increase (decrease) in cash and cash equivalents | 8,354 |  |  | (83,762 | ) |
| Cash and cash equivalents at beginning of period | 640,513 |  |  | 777,615 |  |
| Cash and cash equivalents at end of period | $ | 648,867 |  |  | $ | 693,853 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 10,020 |  |  | $ | 11,831 |  |
| Cash paid during the period for income taxes, net | $ | 3,498 |  |  | $ | 5,521 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 2,014 |  |  | $ | 5,293 |  |
| Non-cash financing activities |  |  |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 1,652 |  |  | $ | — |  |

[0000936395-18-000009:8k_2_02:74]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |
|  |  | Quarter Ended January 31, |
|  |  | 2018 |  | 2017 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 271,765 |  |  | $ | 273,785 |  |
| Share-based compensation-products |  | 672 |  |  | 561 |  |
| Share-based compensation-services |  | 625 |  |  | 628 |  |
| Amortization of intangible assets |  | 2,289 |  |  | 4,313 |  |
| Total adjustments related to gross profit |  | 3,586 |  |  | 5,502 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 275,351 |  |  | $ | 279,287 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 42.6 | % |  | 44.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 255,029 |  |  | $ | 254,681 |  |
| Share-based compensation-research and development |  | 3,255 |  |  | 3,209 |  |
| Share-based compensation-sales and marketing |  | 3,328 |  |  | 2,873 |  |
| Share-based compensation-general and administrative |  | 4,474 |  |  | 5,453 |  |
| Amortization of intangible assets |  | 3,623 |  |  | 14,551 |  |
| Significant asset impairments and restructuring costs |  | 5,961 |  |  | 2,395 |  |
| Total adjustments related to operating expense |  | 20,641 |  |  | 28,481 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 234,388 |  |  | $ | 226,200 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 16,736 |  |  | $ | 19,104 |  |
| Total adjustments related to gross profit |  | 3,586 |  |  | 5,502 |  |
| Total adjustments related to operating expense |  | 20,641 |  |  | 28,481 |  |
| Total adjustments related to income from operations |  | 24,227 |  |  | 33,983 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 40,963 |  |  | $ | 53,087 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 6.3 | % |  | 8.5 | % |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income (loss) |  | $ | (473,363 | ) |  | $ | 3,861 |  |
| Exclude GAAP provision for income taxes |  | 477,940 |  |  | 410 |  |
| Income before income taxes |  | $ | 4,577 |  |  | $ | 4,271 |  |
| Total adjustments related to income from operations |  | 24,227 |  |  | 33,983 |  |
| Loss on extinguishment of debt |  | — |  |  | 41 |  |
| Non-cash interest expense |  | 749 |  |  | 513 |  |
| Adjusted income before income taxes |  | $ | 29,553 |  |  | $ | 38,808 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 7,645 |  |  | 14,165 |  |
| Adjusted (non-GAAP) net income |  | $ | 21,908 |  |  | $ | 24,643 |  |
| Weighted average basic common shares outstanding |  | 143,922 |  |  | 140,682 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 145,558 |  |  | 165,104 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | (3.29 | ) |  | $ | 0.03 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.15 |  |  | $ | 0.17 |  |

[0000936395-18-000009:8k_2_02:75]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2018 includes 0.9 million shares underlying certain stock options and restricted stock units and 0.7 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018. |

[0000936395-18-000009:8k_2_02:76]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2017 includes 1.5 million shares underlying certain stock options and restricted stock units, 5.6 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 and 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018.

[0000936395-18-000009:8k_2_02:77]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2017 requires adding back interest expense of approximately $0.4 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 and approximately $2.3 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-18-000009:8k_2_02:78]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |
|  |  | Quarter Ended January 31, |
|  |  | 2018 |  | 2017 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (loss) (GAAP) |  | $ | (473,363 | ) |  | $ | 3,861 |  |
| Add: Interest expense |  | 13,734 |  |  | 15,203 |  |
| Less: Interest and other income (loss), net |  | 1,575 |  |  | 370 |  |
| Add: Provision for income taxes |  | 477,940 |  |  | 410 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 20,833 |  |  | 16,699 |  |
| Add: Amortization of intangible assets |  | 5,912 |  |  | 18,864 |  |
| EBITDA |  | $ | 43,481 |  |  | $ | 54,667 |  |
| Add: Shared-based compensation cost |  | 12,393 |  |  | 12,825 |  |
| Add: Significant asset impairments and restructuring costs |  | 5,961 |  |  | 2,395 |  |
| Adjusted EBITDA |  | $ | 61,835 |  |  | $ | 69,887 |  |

[0000936395-18-000009:8k_2_02:79]
* * *

[0000936395-18-000009:8k_2_02:80]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-18-000009:8k_2_02:81]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-18-000009:8k_2_02:82]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-18-000009:8k_2_02:83]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-18-000009:8k_2_02:84]
| • | Non-cash loss on extinguishment of debt - related to certain private repurchases conducted with several holders of Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017. |

[0000936395-18-000009:8k_2_02:85]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-18-000009:8k_2_02:86]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 25.87% for the first fiscal quarter of 2018, and 36.5% for the first fiscal quarter of 2017. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. In calculating, the Non-GAAP tax provision for the first fiscal quarter of 2018, Ciena excluded certain significant non-cash |

[0000936395-18-000009:8k_2_02:87]
charges resulting from the enactment of Tax Cuts and Jobs Act. Specifically, during the first quarter of fiscal 2018, Ciena recorded a provisional, non-cash charge of $476.9 million, consisting of a $431.3 million charge related to the re-measurement of net deferred tax assets at the lower statutory rate, and a $45.6 million charge related to the U.S. transition tax described above. These amounts are provisional in nature based on Securities and Exchange Commission Staff Accounting Bulletin No. 118 and therefore subject to adjustment in future periods, including as a result of the availability of additional guidance and further analysis by Ciena under the Tax Cuts and Jobs Act.
