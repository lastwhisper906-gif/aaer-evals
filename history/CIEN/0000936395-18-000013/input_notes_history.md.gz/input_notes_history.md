# CIEN note change history — 0000936395-17-000051 → 0000936395-18-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:1]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.
  (was, 2017-09-07, similarity 0.9921):
[0000936395-17-000051:note_history:1]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

- changed (2018-03-07):
[0000936395-18-000013:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Oral argument was heard by the Supreme Court on this matter on November 28, 2017. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2017-09-07, similarity 0.852):
[0000936395-17-000051:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, which petition was granted on June 27, 2017. The matter is expected to be heard during the Supreme Court’s October 2017 Term. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- added (2018-03-07):
[0000936395-18-000013:note_history:3]
Internal Investigations

- added (2018-03-07):
[0000936395-18-000013:note_history:4]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena's Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

- added (2018-03-07):
[0000936395-18-000013:note_history:5]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

- added (2018-03-07):
[0000936395-18-000013:note_history:6]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

- removed (2018-03-07):
[0000936395-17-000051:note_history:7]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 15, 2016, the plaintiffs filed a third amended complaint against the members of Cyan's board of directors, which generally alleged that they breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.

- removed (2018-03-07):
[0000936395-17-000051:note_history:8]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

- removed (2018-03-07):
[0000936395-17-000051:note_history:9]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2018-03-07):
[0000936395-17-000051:note_history:10]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-03-07):
[0000936395-18-000013:note_history:11]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2018 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2017 was a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.

- removed (2018-03-07):
[0000936395-17-000051:note_history:12]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2017 and 2016 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:13]
RECENT ACCOUNTING PRONOUNCEMENTS
  (was, 2017-09-07, similarity 0.6349):
[0000936395-17-000051:note_history:13]
SIGNIFICANT ACCOUNTING POLICIES

- added (2018-03-07):
[0000936395-18-000013:note_history:14]
Except for the changes in certain policies related to adoption of the accounting standards described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.

- changed (2018-03-07):
[0000936395-18-000013:note_history:15]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.
  (was, 2017-09-07, similarity 0.7998):
[0000936395-17-000051:note_history:15]
In January 2017, the FASB issued ASU No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.

- changed (2018-03-07):
[0000936395-18-000013:note_history:16]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.
  (was, 2017-09-07, similarity 0.6875):
[0000936395-17-000051:note_history:16]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. ASU 2017-12 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is evaluating the effect of the update on its Consolidated Financial Statements and disclosures.

- added (2018-03-07):
[0000936395-18-000013:note_history:17]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

- added (2018-03-07):
[0000936395-18-000013:note_history:18]
In May 2014, the FASB issued ASU No. 2014-09 ("ASU 2014-09"), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

- added (2018-03-07):
[0000936395-18-000013:note_history:19]
For multiple element software arrangements where vendor-specific objective evidence ("VSOE") of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of ASU 2014-09 will require that it determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

- changed (2018-03-07):
[0000936395-18-000013:note_history:20]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.
  (was, 2017-09-07, similarity 0.9942):
[0000936395-17-000051:note_history:20]
Ciena also expects certain installation and deployment and consulting and network design services will be recognized over a period of time rather than at a point in time.

- changed (2018-03-07):
[0000936395-18-000013:note_history:21]
Ciena has considered the impact of the guidance in Accounting Standards Codification ("ASC") 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.
  (was, 2017-09-07, similarity 0.9672):
[0000936395-17-000051:note_history:21]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less and amortized over the period of performance if the period of the asset recognition is greater than one year.

- changed (2018-03-07):
[0000936395-18-000013:note_history:22]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2017-09-07, similarity 0.9884):
[0000936395-17-000051:note_history:22]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- changed (2018-03-07):
[0000936395-18-000013:note_history:23]
In February 2016, the FASB issued ASU No. 2016-02 ("ASU 2016-02"), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.
  (was, 2017-09-07, similarity 0.9797):
[0000936395-17-000051:note_history:23]
In February 2016, the FASB issued ASU No. 2016-02, Leases ("ASU 2016-02"), which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- removed (2018-03-07):
[0000936395-17-000051:note_history:24]
Business Combinations

- removed (2018-03-07):
[0000936395-17-000051:note_history:25]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

- removed (2018-03-07):
[0000936395-17-000051:note_history:26]
Use of Estimates

- removed (2018-03-07):
[0000936395-17-000051:note_history:27]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- removed (2018-03-07):
[0000936395-17-000051:note_history:28]
Cash and Cash Equivalents

- removed (2018-03-07):
[0000936395-17-000051:note_history:29]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included either in other current assets or in other long-term assets depending upon the duration of the restriction.

- removed (2018-03-07):
[0000936395-17-000051:note_history:30]
Investments

- removed (2018-03-07):
[0000936395-17-000051:note_history:31]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that a decline in the fair value of any investment below its cost basis is other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

- removed (2018-03-07):
[0000936395-17-000051:note_history:32]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.

- removed (2018-03-07):
[0000936395-17-000051:note_history:33]
Inventories

- removed (2018-03-07):
[0000936395-17-000051:note_history:34]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

- removed (2018-03-07):
[0000936395-17-000051:note_history:35]
Segment Reporting

- removed (2018-03-07):
[0000936395-17-000051:note_history:36]
Ciena's chief operating decision maker, its chief executive officer, evaluates the Company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:37]
Goodwill

- removed (2018-03-07):
[0000936395-17-000051:note_history:38]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

- removed (2018-03-07):
[0000936395-17-000051:note_history:39]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by Financial Accounting Standards Board ("FASB") Accounting Standards Update ("ASU") No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

- removed (2018-03-07):
[0000936395-17-000051:note_history:40]
Long-lived Assets

- removed (2018-03-07):
[0000936395-17-000051:note_history:41]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

- removed (2018-03-07):
[0000936395-17-000051:note_history:42]
Equipment, Building, Furniture and Fixtures and Internal Use Software

- removed (2018-03-07):
[0000936395-17-000051:note_history:43]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

- removed (2018-03-07):
[0000936395-17-000051:note_history:44]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 13 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:45]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two to five years.

- removed (2018-03-07):
[0000936395-17-000051:note_history:46]
Intangible Assets

- removed (2018-03-07):
[0000936395-17-000051:note_history:47]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

- removed (2018-03-07):
[0000936395-17-000051:note_history:48]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, and the asset developed has no alternative use, the full value of the asset will be charged to expense.

- removed (2018-03-07):
[0000936395-17-000051:note_history:49]
Maintenance Spares

- removed (2018-03-07):
[0000936395-17-000051:note_history:50]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.

- removed (2018-03-07):
[0000936395-17-000051:note_history:51]
Concentrations

- removed (2018-03-07):
[0000936395-17-000051:note_history:52]
Substantially all of Ciena's cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena's cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

- removed (2018-03-07):
[0000936395-17-000051:note_history:53]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 20 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:54]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.

- removed (2018-03-07):
[0000936395-17-000051:note_history:55]
Revenue Recognition

- removed (2018-03-07):
[0000936395-17-000051:note_history:56]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

- removed (2018-03-07):
[0000936395-17-000051:note_history:57]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

- removed (2018-03-07):
[0000936395-17-000051:note_history:58]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

- removed (2018-03-07):
[0000936395-17-000051:note_history:59]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

- removed (2018-03-07):
[0000936395-17-000051:note_history:60]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

- removed (2018-03-07):
[0000936395-17-000051:note_history:61]
Warranty Accruals

- removed (2018-03-07):
[0000936395-17-000051:note_history:62]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based upon actual warranty cost experience, estimates of component failure rates and management's industry experience. Ciena's sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

- removed (2018-03-07):
[0000936395-17-000051:note_history:63]
Accounts Receivable, Net

- removed (2018-03-07):
[0000936395-17-000051:note_history:64]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.

- removed (2018-03-07):
[0000936395-17-000051:note_history:65]
Research and Development

- removed (2018-03-07):
[0000936395-17-000051:note_history:66]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

- removed (2018-03-07):
[0000936395-17-000051:note_history:67]
Advertising Costs

- removed (2018-03-07):
[0000936395-17-000051:note_history:68]
Ciena expenses all advertising costs as incurred.

- removed (2018-03-07):
[0000936395-17-000051:note_history:69]
Legal Costs

- removed (2018-03-07):
[0000936395-17-000051:note_history:70]
Ciena expenses legal costs associated with litigation as incurred.

- removed (2018-03-07):
[0000936395-17-000051:note_history:71]
Share-Based Compensation Expense

- removed (2018-03-07):
[0000936395-17-000051:note_history:72]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 19 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:73]
Income Taxes

- removed (2018-03-07):
[0000936395-17-000051:note_history:74]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

- removed (2018-03-07):
[0000936395-17-000051:note_history:75]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2014), United Kingdom (2014), Canada (2011), India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

- removed (2018-03-07):
[0000936395-17-000051:note_history:76]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.

- removed (2018-03-07):
[0000936395-17-000051:note_history:77]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena’s net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena’s net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

- removed (2018-03-07):
[0000936395-17-000051:note_history:78]
Loss Contingencies

- removed (2018-03-07):
[0000936395-17-000051:note_history:79]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

- removed (2018-03-07):
[0000936395-17-000051:note_history:80]
Fair Value of Financial Instruments

- removed (2018-03-07):
[0000936395-17-000051:note_history:81]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loans, see Note 16 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:82]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

- removed (2018-03-07):
[0000936395-17-000051:note_history:83]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

- removed (2018-03-07):
[0000936395-17-000051:note_history:84]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

- removed (2018-03-07):
[0000936395-17-000051:note_history:85]
| • | Level 3 inputs are unobservable inputs based on Ciena's assumptions used to measure assets and liabilities at fair value. |

- removed (2018-03-07):
[0000936395-17-000051:note_history:86]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

- removed (2018-03-07):
[0000936395-17-000051:note_history:87]
Restructuring

- removed (2018-03-07):
[0000936395-17-000051:note_history:88]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:89]
Foreign Currency

- removed (2018-03-07):
[0000936395-17-000051:note_history:90]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:91]
Derivatives

- removed (2018-03-07):
[0000936395-17-000051:note_history:92]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. Ciena also has interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

- removed (2018-03-07):
[0000936395-17-000051:note_history:93]
Ciena records derivative instruments in the Condensed Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

- removed (2018-03-07):
[0000936395-17-000051:note_history:94]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.

- removed (2018-03-07):
[0000936395-17-000051:note_history:95]
See Notes 6 and 14 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:96]
Computation of Net Income (Loss) per Share

- removed (2018-03-07):
[0000936395-17-000051:note_history:97]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 18 below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:98]
Software Development Costs

- removed (2018-03-07):
[0000936395-17-000051:note_history:99]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development cost qualifying for capitalization has been insignificant. Accordingly, Ciena has not capitalized any software development costs.

- removed (2018-03-07):
[0000936395-17-000051:note_history:100]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $5.8 million at July 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and to continue to present such capitalized costs in other assets.

- removed (2018-03-07):
[0000936395-17-000051:note_history:101]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

- removed (2018-03-07):
[0000936395-17-000051:note_history:102]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) ("ASU 2014-09"), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

- removed (2018-03-07):
[0000936395-17-000051:note_history:103]
For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require that it determine the stand alone selling price for each of the elements at the contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

- removed (2018-03-07):
[0000936395-17-000051:note_history:104]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any related valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, with the prior periods adjusted accordingly, as a result of the adoption. Finally, Ciena will elect to continue to estimate expected forfeitures rather than account for forfeitures as they occur.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:105]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-09-07, similarity 0.8561):
[0000936395-17-000051:note_history:105]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-03-07):
[0000936395-18-000013:note_history:106]
|  |  | January 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 392,972 |  |
  (was, 2017-09-07, similarity 0.7945):
[0000936395-17-000051:note_history:106]
|  |  | July 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 393,674 |  |  | $ | 401,993 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:107]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.9 million at January 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2018. There was no recorded amortization of deferred debt issuance costs for the 2022 Term Loan included in interest expense during the first three months of fiscal 2017. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.
  (was, 2017-09-07, similarity 0.6201):
[0000936395-17-000051:note_history:107]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.3 million at July 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.7 million and $0.8 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.

- changed (2018-03-07):
[0000936395-18-000013:note_history:108]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of January 31, 2018 (in thousands):
  (was, 2017-09-07, similarity 0.9875):
[0000936395-17-000051:note_history:108]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of July 31, 2017 (in thousands):

- changed (2018-03-07):
[0000936395-18-000013:note_history:109]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 397,000 |  |  | $ | (1,808 | ) |  | $ | (2,923 | ) |  | $392,269 |
  (was, 2017-09-07, similarity 0.9869):
[0000936395-17-000051:note_history:109]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,038 | ) |  | $ | (3,288 | ) |  | $393,674 |

- added (2018-03-07):
[0000936395-18-000013:note_history:110]
|  |  | January 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 397,993 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:111]
|  |  | January 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,627 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 194,717 |  |
|  |  | $ | 545,085 |  |  | $ | 543,009 |  |
  (was, 2017-09-07, similarity 0.8831):
[0000936395-17-000051:note_history:111]
|  |  | July 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 188,509 |  |
|  |  | $ | 541,628 |  |  | $ | 767,379 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:112]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.7 million at January 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.4 million and $0.5 million during the first three months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.
  (was, 2017-09-07, similarity 0.9081):
[0000936395-17-000051:note_history:112]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.5 million at July 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.4 million and $2.1 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

- changed (2018-03-07):
[0000936395-18-000013:note_history:113]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of January 31, 2018 (in thousands):
  (was, 2017-09-07, similarity 0.9854):
[0000936395-17-000051:note_history:113]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of July 31, 2017 (in thousands):

- added (2018-03-07):
[0000936395-18-000013:note_history:114]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (145 | ) |  | $ | 61,125 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (423 | ) |  | $ | (680 | ) |  | $ | 287,627 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 205,906 |  |  | $ | (8,692 | ) |  | $ | (881 | ) |  | $ | 196,333 |  |  | $ | 43,131 |  |

- added (2018-03-07):
[0000936395-18-000013:note_history:115]
| (1) | Includes accretion of principal at a rate of 1.85% per year |

- changed (2018-03-07):
[0000936395-18-000013:note_history:116]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2018:
  (was, 2017-09-07, similarity 0.9849):
[0000936395-17-000051:note_history:116]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2017:

- added (2018-03-07):
[0000936395-18-000013:note_history:117]
|  |  | January 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 71,778 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 287,627 |  |  | 338,247 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 246,281 |  |
|  |  | $ | 545,085 |  |  | $ | 656,306 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:118]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |
  (was, 2017-09-07, similarity 0.9874):
[0000936395-17-000051:note_history:118]
| (2) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2018-03-07):
[0000936395-17-000051:note_history:119]
|  |  | July 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,674 |  |  | — |  |
|  |  | $ | 393,674 |  |  | $ | 486,303 |  |

- removed (2018-03-07):
[0000936395-17-000051:note_history:120]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1.0 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed. The aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.

- removed (2018-03-07):
[0000936395-17-000051:note_history:121]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2022 Term Loan will, among other things:

- removed (2018-03-07):
[0000936395-17-000051:note_history:122]
| • | be subject to mandatory prepayment on the same basis as under the Term Loan Credit Agreement; |

- removed (2018-03-07):
[0000936395-17-000051:note_history:123]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

- removed (2018-03-07):
[0000936395-17-000051:note_history:124]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

- removed (2018-03-07):
[0000936395-17-000051:note_history:125]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

- removed (2018-03-07):
[0000936395-17-000051:note_history:126]
| (1) | Includes unamortized debt discount and debt issuance costs. |

- removed (2018-03-07):
[0000936395-17-000051:note_history:127]
Prior Term Loans

- removed (2018-03-07):
[0000936395-17-000051:note_history:128]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

- removed (2018-03-07):
[0000936395-17-000051:note_history:129]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

- removed (2018-03-07):
[0000936395-17-000051:note_history:130]
Maturity of 2017 Convertible Notes

- removed (2018-03-07):
[0000936395-17-000051:note_history:131]
On June 15, 2017, the outstanding 0.875% Convertible Senior Notes matured and Ciena repaid the approximately $185.3 million in aggregate principal amount outstanding, together with approximately $0.8 million in accrued interest through the date of maturity.

- removed (2018-03-07):
[0000936395-17-000051:note_history:132]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,443 | ) |  | $ | 348,557 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,996 |  |  | $ | (9,893 | ) |  | $ | (1,032 | ) |  | $ | 193,071 |  |  | $ | 43,131 |  |

- removed (2018-03-07):
[0000936395-17-000051:note_history:133]
|  |  | July 31, 2017 |
|  |  | Net Carrying Value (1) |  | Fair Value(2) |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 482,825 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 269,719 |  |
|  |  | $ | 541,628 |  |  | $ | 752,544 |  |

- removed (2018-03-07):
[0000936395-17-000051:note_history:134]
| (1) | Includes unamortized debt discount, accretion of principal and deferred debt issuance costs. |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:135]
|  | January 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,404 |  |  | $ | — |  |  | (530 | ) |  | $ | 238,874 |  |
| Included in long-term investments | 59,313 |  |  | — |  |  | (162 | ) |  | 59,151 |  |
|  | $ | 298,717 |  |  | $ | — |  |  | $ | (692 | ) |  | $ | 298,025 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 39,868 |  |  | 1 |  |  | — |  |  | $ | 39,869 |  |
|  | $ | 39,868 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 39,869 |  |
  (was, 2017-09-07, similarity 0.852):
[0000936395-17-000051:note_history:135]
|  | July 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 225,032 |  |  | $ | — |  |  | (272 | ) |  | $ | 224,760 |  |
| Included in long-term investments | 59,976 |  |  | — |  |  | (102 | ) |  | 59,874 |  |
|  | $ | 285,008 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 284,634 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,983 |  |  | — |  |  | — |  |  | $ | 9,983 |  |
|  | $ | 9,983 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,983 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:136]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |
  (was, 2017-09-07, similarity 0.648):
[0000936395-17-000051:note_history:136]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | — |  |  | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:137]
The following table summarizes the final legal maturities of debt investments at January 31, 2018 (in thousands):
  (was, 2017-09-07, similarity 0.9765):
[0000936395-17-000051:note_history:137]
The following table summarizes the final legal maturities of debt investments at July 31, 2017 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:138]
|  |  | January 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,627 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 194,717 |  |
|  |  | $ | 545,085 |  |  | $ | 543,009 |  |
  (was, 2017-09-07, similarity 0.8831):
[0000936395-17-000051:note_history:138]
|  |  | July 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 188,509 |  |
|  |  | $ | 541,628 |  |  | $ | 767,379 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:139]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-09-07, similarity 0.8561):
[0000936395-17-000051:note_history:139]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-03-07):
[0000936395-18-000013:note_history:140]
|  |  | January 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 392,972 |  |
  (was, 2017-09-07, similarity 0.7945):
[0000936395-17-000051:note_history:140]
|  |  | July 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 393,674 |  |  | $ | 401,993 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:141]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2018:
  (was, 2017-09-07, similarity 0.9849):
[0000936395-17-000051:note_history:141]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2017:

- added (2018-03-07):
[0000936395-18-000013:note_history:142]
|  |  | January 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 71,778 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 287,627 |  |  | 338,247 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 246,281 |  |
|  |  | $ | 545,085 |  |  | $ | 656,306 |  |

- changed (2018-03-07):
[0000936395-18-000013:note_history:143]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |
  (was, 2017-09-07, similarity 0.9874):
[0000936395-17-000051:note_history:143]
| (2) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2018-03-07):
[0000936395-18-000013:note_history:144]
|  |  | January 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 397,993 |  |

- added (2018-03-07):
[0000936395-18-000013:note_history:145]
| (1) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2018-03-07):
[0000936395-17-000051:note_history:146]
|  |  | July 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,674 |  |  | — |  |
|  |  | $ | 393,674 |  |  | $ | 486,303 |  |

- removed (2018-03-07):
[0000936395-17-000051:note_history:147]
|  |  | July 31, 2017 |
|  |  | Net Carrying Value (1) |  | Fair Value(2) |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 482,825 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 269,719 |  |
|  |  | $ | 541,628 |  |  | $ | 752,544 |  |

- removed (2018-03-07):
[0000936395-17-000051:note_history:148]
| (1) | Includes unamortized debt discount, accretion of principal and deferred debt issuance costs. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-03-07):
[0000936395-18-000013:note_history:149]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of January 31, 2018 (in thousands):
  (was, 2017-09-07, similarity 0.9854):
[0000936395-17-000051:note_history:149]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of July 31, 2017 (in thousands):

- added (2018-03-07):
[0000936395-18-000013:note_history:150]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (145 | ) |  | $ | 61,125 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (423 | ) |  | $ | (680 | ) |  | $ | 287,627 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 205,906 |  |  | $ | (8,692 | ) |  | $ | (881 | ) |  | $ | 196,333 |  |  | $ | 43,131 |  |

- added (2018-03-07):
[0000936395-18-000013:note_history:151]
| (1) | Includes accretion of principal at a rate of 1.85% per year |

- changed (2018-03-07):
[0000936395-18-000013:note_history:152]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of January 31, 2018 (in thousands):
  (was, 2017-09-07, similarity 0.9875):
[0000936395-17-000051:note_history:152]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of July 31, 2017 (in thousands):

- changed (2018-03-07):
[0000936395-18-000013:note_history:153]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 397,000 |  |  | $ | (1,808 | ) |  | $ | (2,923 | ) |  | $392,269 |
  (was, 2017-09-07, similarity 0.9869):
[0000936395-17-000051:note_history:153]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,038 | ) |  | $ | (3,288 | ) |  | $393,674 |

- removed (2018-03-07):
[0000936395-17-000051:note_history:154]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,443 | ) |  | $ | 348,557 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,996 |  |  | $ | (9,893 | ) |  | $ | (1,032 | ) |  | $ | 193,071 |  |  | $ | 43,131 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: no_current_note, score: 0.0

- removed (2018-03-07):
[0000936395-17-000051:note_history:155]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

- removed (2018-03-07):
[0000936395-17-000051:note_history:156]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

- removed (2018-03-07):
[0000936395-17-000051:note_history:157]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

- removed (2018-03-07):
[0000936395-17-000051:note_history:158]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

- removed (2018-03-07):
[0000936395-17-000051:note_history:159]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-03-07):
[0000936395-18-000013:note_history:160]
Stock Repurchase Program

- added (2018-03-07):
[0000936395-18-000013:note_history:161]
From the end of the first quarter of fiscal 2018 through March 5, 2018, Ciena repurchased an additional 611,514 shares of its common stock, for an aggregate purchase price of  $13.8 million at an average price of $22.52 per share, including of repurchases pending settlement. As of March 5, 2018, Ciena has an aggregate of $280.5 million of authorized funds remaining under its Stock Repurchase Program.

- removed (2018-03-07):
[0000936395-17-000051:note_history:162]
On August 2, 2017, Ciena completed its offer to exchange its outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount. The New Notes give Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares. Through these cash settlement options, Ciena believes that it will gain additional flexibility to better manage its long-term capital structure and reduce the dilutive impact of its convertible notes upon stockholders. It is Ciena’s current intent that upon any conversion of the New Notes, Ciena will settle the principal amount thereof in cash. Accordingly, beginning in the fourth quarter of fiscal 2017, Ciena intends to use the treasury stock method for the New Notes in its diluted earnings per share calculation. Following settlement of the exchange, $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding.
