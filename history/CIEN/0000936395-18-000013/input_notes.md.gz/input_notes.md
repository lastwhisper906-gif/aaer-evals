# CIEN notes — 0000936395-18-000013


## cien:ScheduleOfStockRepurchaseProgramTableTextBlock

[0000936395-18-000013:notes:1]
A summary of the stock repurchase program, reported based on trade date, is summarized as follows:

[0000936395-18-000013:notes:2]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2017 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 262,487 |  |  | 21.92 |  |  | 5,755 |  |
| Cumulative balance at January 31, 2018 | 262,487 |  |  | $ | 21.92 |  |  | $ | 5,755 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-18-000013:notes:3]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-18-000013:notes:4]
Outstanding Term Loan Payable

[0000936395-18-000013:notes:5]
2022 Term Loan

[0000936395-18-000013:notes:6]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000013:notes:7]
|  |  | January 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 392,972 |  |

[0000936395-18-000013:notes:8]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.9 million at January 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2018. There was no recorded amortization of deferred debt issuance costs for the 2022 Term Loan included in interest expense during the first three months of fiscal 2017. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.

[0000936395-18-000013:notes:9]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of January 31, 2018 (in thousands):

[0000936395-18-000013:notes:10]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 397,000 |  |  | $ | (1,808 | ) |  | $ | (2,923 | ) |  | $392,269 |

[0000936395-18-000013:notes:11]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

[0000936395-18-000013:notes:12]
|  |  | January 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 397,993 |  |

[0000936395-18-000013:notes:13]
| (1) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-18-000013:notes:14]
Outstanding Convertible Notes Payable

[0000936395-18-000013:notes:15]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000013:notes:16]
|  |  | January 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,627 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 194,717 |  |
|  |  | $ | 545,085 |  |  | $ | 543,009 |  |

[0000936395-18-000013:notes:17]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.7 million at January 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.4 million and $0.5 million during the first three months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

[0000936395-18-000013:notes:18]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of January 31, 2018 (in thousands):

[0000936395-18-000013:notes:19]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (145 | ) |  | $ | 61,125 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (423 | ) |  | $ | (680 | ) |  | $ | 287,627 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 205,906 |  |  | $ | (8,692 | ) |  | $ | (881 | ) |  | $ | 196,333 |  |  | $ | 43,131 |  |

[0000936395-18-000013:notes:20]
| (1) | Includes accretion of principal at a rate of 1.85% per year |

[0000936395-18-000013:notes:21]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2018:

[0000936395-18-000013:notes:22]
|  |  | January 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 71,778 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 287,627 |  |  | 338,247 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 246,281 |  |
|  |  | $ | 545,085 |  |  | $ | 656,306 |  |

[0000936395-18-000013:notes:23]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-18-000013:notes:24]
COMMITMENTS AND CONTINGENCIES

[0000936395-18-000013:notes:25]
Foreign Tax Contingencies

[0000936395-18-000013:notes:26]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-18-000013:notes:27]
Litigation

[0000936395-18-000013:notes:28]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Oral argument was heard by the Supreme Court on this matter on November 28, 2017. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-18-000013:notes:29]
Internal Investigations

[0000936395-18-000013:notes:30]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena's Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

[0000936395-18-000013:notes:31]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-18-000013:notes:32]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-18-000013:notes:33]
[same as prior period, unchanged from 0000936395-17-000051:notes:56]

[0000936395-18-000013:notes:34]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the three months ended January 31, 2018:

[0000936395-18-000013:notes:35]
|  | Unrealized Loss on |  | Unrealized Gain/(Loss) on |  | Unrealized Gain on Forward |  | Cumulative Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (261 | ) |  | 1,624 |  |  | 3,479 |  |  | 8,202 |  |  | 13,044 |  |
| Amounts reclassified from AOCI | — |  |  | (71 | ) |  | 419 |  |  | — |  |  | 348 |  |
| Balance at January 31, 2018 | $ | (712 | ) |  | $ | 167 |  |  | $ | 4,116 |  |  | $ | (1,196 | ) |  | $ | 2,375 |  |

[0000936395-18-000013:notes:36]
The following table summarizes the changes in AOCI for the three months ended January 31, 2017:

[0000936395-18-000013:notes:37]
|  | Unrealized Gain/(Loss) on |  | Unrealized Gain/(Loss) on |  | Unrealized Gain/(Loss) on Forward |  | Cumulative Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (249 | ) |  | 1,031 |  |  | 4,044 |  |  | 490 |  |  | 5,316 |  |
| Amounts reclassified from AOCI | — |  |  | 394 |  |  | 448 |  |  | — |  |  | 842 |  |
| Balance at January 31, 2017 | $ | (110 | ) |  | $ | 334 |  |  | $ | (1,475 | ) |  | $ | (16,920 | ) |  | $ | (18,171 | ) |

[0000936395-18-000013:notes:38]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue or research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-18-000013:notes:39]
[same as prior period, unchanged from 0000936395-17-000051:notes:65]

[0000936395-18-000013:notes:40]
[same as prior period, unchanged from 0000936395-17-000051:notes:66]

[0000936395-18-000013:notes:41]
As of January 31, 2018 and October 31, 2017, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, and its Euro denominated revenue. The notional amount of these contracts was approximately $187.3 million and $86.1 million as of January 31, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-18-000013:notes:42]
During the first three months of fiscal 2018 and fiscal 2017, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $82.7 million and $83.4 million as of January 31, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-18-000013:notes:43]
[same as prior period, unchanged from 0000936395-17-000051:notes:69]

[0000936395-18-000013:notes:44]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 12 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). The interest rate swaps fix 98%, 82%, and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020, and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25%, 4.25% ,and 4.75%, respectively. The total notional amount of these interest rate swaps in effect as of January 31, 2018 was $388.6 million. The total notional amount of these interest rate swaps in effect as of October 31, 2017 was $389.6 million.

[0000936395-18-000013:notes:45]
[same as prior period, unchanged from 0000936395-17-000051:notes:72]

[0000936395-18-000013:notes:46]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 4 and Note 7 above.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-18-000013:notes:47]
[same as prior period, unchanged from 0000936395-17-000051:notes:77]

[0000936395-18-000013:notes:48]
[same as prior period, unchanged from 0000936395-17-000051:notes:103]

[0000936395-18-000013:notes:49]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Product costs | $ | 672 |  |  | $ | 561 |  |
| Service costs | 625 |  |  | 628 |  |
| Share-based compensation expense included in cost of sales | 1,297 |  |  | 1,189 |  |
| Research and development | 3,255 |  |  | 3,209 |  |
| Sales and marketing | 3,328 |  |  | 2,873 |  |
| General and administrative | 4,474 |  |  | 5,453 |  |
| Share-based compensation expense included in operating expense | 11,057 |  |  | 11,535 |  |
| Share-based compensation expense capitalized in inventory, net | 39 |  |  | 101 |  |
| Total share-based compensation | $ | 12,393 |  |  | $ | 12,825 |  |

[0000936395-18-000013:notes:50]
As of January 31, 2018, total unrecognized share-based compensation expense was approximately $100.1 million, consisting of: (i) $0.1 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 0.8 years; and (ii) $100.0 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.7 years.


## us-gaap:EarningsPerShareTextBlock

[0000936395-18-000013:notes:51]
[same as prior period, unchanged from 0000936395-17-000051:notes:107]

[0000936395-18-000013:notes:52]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of restricted stock units; (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method; (iv) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the treasury stock method (the New Notes); and (v) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the if-converted method.

[0000936395-18-000013:notes:53]
|  | Quarter Ended January 31, |
| Numerator | 2018 |  | 2017 |
| Net income (loss) | $ | (473,363 | ) |  | $ | 3,861 |  |

[0000936395-18-000013:notes:54]
|  | Quarter Ended January 31, |
| Denominator | 2018 |  | 2017 |
| Basic weighted average shares outstanding | 143,922 |  |  | 140,682 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | — |  |  | 1,502 |  |
| Dilutive weighted average shares outstanding | 143,922 |  |  | 142,184 |  |

[0000936395-18-000013:notes:55]
|  | Quarter Ended January 31, |
| EPS | 2018 |  | 2017 |
| Basic EPS | $ | (3.29 | ) |  | $ | 0.03 |  |
| Diluted EPS | $ | (3.29 | ) |  | $ | 0.03 |  |

[0000936395-18-000013:notes:56]
[same as prior period, unchanged from 0000936395-17-000051:notes:112]

[0000936395-18-000013:notes:57]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Shares underlying stock options and restricted stock units | 3,414 |  |  | 1,556 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | 5,564 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) | 3,038 |  |  | 17,355 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) (1) | 691 |  |  | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 16,341 |  |  | 33,673 |  |

[0000936395-18-000013:notes:58]
| (1) | Since Ciena intends, upon any conversion of the outstanding 3.75% Convertible Senior Notes due 2018 (New Notes), to settle the principal amount thereof in cash, Ciena uses the treasury stock method for calculating any potential dilutive effect of the conversion spread on diluted net income per share, if applicable. The 14.3 million shares underlying the New Notes will have a dilutive impact on diluted net income per share of common stock when the average market price of Ciena common stock for a given period exceeds the conversion price of $20.17 per share for the New Notes. During the first quarter of fiscal 2018, the average market price of Ciena common stock was $21.19 and, as such, the New Notes are dilutive by the conversion spread, or 0.7 million shares. |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-18-000013:notes:59]
[same as prior period, unchanged from 0000936395-17-000051:notes:114]

[0000936395-18-000013:notes:60]
|  | January 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 521,698 |  |  | $ | — |  |  | $ | — |  |  | $ | 521,698 |  |
| U.S. government obligations | — |  |  | 298,025 |  |  | — |  |  | 298,025 |  |
| Commercial paper | — |  |  | 69,810 |  |  | — |  |  | 69,810 |  |
| Foreign currency forward contracts | — |  |  | 3,730 |  |  | — |  |  | 3,730 |  |
| Forward starting interest rate swaps | — |  |  | 4,117 |  |  | — |  |  | 4,117 |  |
| Total assets measured at fair value | $ | 521,698 |  |  | $ | 375,682 |  |  | $ | — |  |  | $ | 897,380 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,415 |  |  | $ | — |  |  | $ | 2,415 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,415 |  |  | $ | — |  |  | $ | 2,415 |  |

[0000936395-18-000013:notes:61]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 511,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 511,355 |  |
| U.S. government obligations | — |  |  | 298,976 |  |  | — |  |  | 298,976 |  |
| Commercial paper | — |  |  | 89,865 |  |  | — |  |  | 89,865 |  |
| Foreign currency forward contracts | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Forward starting interest rate swaps | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-18-000013:notes:62]
[same as prior period, unchanged from 0000936395-17-000051:notes:117]

[0000936395-18-000013:notes:63]
|  | January 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 521,698 |  |  | $ | 29,941 |  |  | $ | — |  |  | $ | 551,639 |  |
| Short-term investments | — |  |  | 278,743 |  |  | — |  |  | 278,743 |  |
| Prepaid expenses and other | — |  |  | 3,730 |  |  | — |  |  | 3,730 |  |
| Long-term investments | — |  |  | 59,151 |  |  | — |  |  | 59,151 |  |
| Other long-term assets | — |  |  | 4,117 |  |  | — |  |  | 4,117 |  |
| Total assets measured at fair value | $ | 521,698 |  |  | $ | 375,682 |  |  | $ | — |  |  | $ | 897,380 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,415 |  |  | $ | — |  |  | $ | 2,415 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,415 |  |  | $ | — |  |  | $ | 2,415 |  |

[0000936395-18-000013:notes:64]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 511,355 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 571,280 |  |
| Short-term investments | — |  |  | 279,133 |  |  | — |  |  | 279,133 |  |
| Prepaid expenses and other | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments | — |  |  | 49,783 |  |  | — |  |  | 49,783 |  |
| Other long-term assets | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-18-000013:notes:65]
[same as prior period, unchanged from 0000936395-17-000051:notes:120]

[0000936395-18-000013:notes:66]
[same as prior period, unchanged from 0000936395-17-000051:notes:121]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-18-000013:notes:67]
INCOME TAXES

[0000936395-18-000013:notes:68]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries that were previously tax deferred. As a fiscal-year taxpayer, certain provisions of the Tax Act impact Ciena in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system, other changes to how foreign earnings are subject to U.S. tax, and adoption of an alternative tax system.

[0000936395-18-000013:notes:69]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena has computed its income tax expense for the October 31, 2018 fiscal year using a blended federal tax rate of 23.4%. The 21% federal tax rate will apply to Ciena’s fiscal year ending October 31, 2019 and each year thereafter. Ciena remeasured its deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-18-000013:notes:70]
During the three months ended January 31, 2018, Ciena recorded a provisional tax expense of $477.9 million, primarily related to the Tax Act and comprised of $431.3 million remeasurement of net DTA and $45.6 million of U.S. transition tax.

[0000936395-18-000013:notes:71]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional amounts due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. Ciena has determined that the $45.6 million of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries and the $431.3 million of tax expense for DTA remeasurement were each provisional amounts and reasonable estimates as of January 31, 2018. Estimates used in the provisional amounts include the anticipated reversal pattern of the gross DTAs plus the earnings and profits, cash position at the end of fiscal year 2018, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000936395-18-000013:notes:72]
Ciena currently intends to reinvest indefinitely its foreign earnings outside the U.S. However, Ciena intends to further study changes enacted by the Tax Act, costs of repatriation and the current and future cash needs of foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If Ciena determines to repatriate these earnings, the provisional amount of unrecognized deferred income tax liability related to these foreign withholding taxes would be approximately $22.0 million. There are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-18-000013:notes:73]
The significant components of DTA are as follows (in thousands):

[0000936395-18-000013:notes:74]
|  | January 31, |  | October 31, |
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 36,706 |  |  | $ | 56,597 |  |
| Depreciation and amortization | 274,974 |  |  | 451,385 |  |
| NOL and credit carry forward | 560,603 |  |  | 803,622 |  |
| Other | 18,224 |  |  | 29,398 |  |
| Gross deferred tax assets | 890,507 |  |  | 1,341,002 |  |
| Valuation allowance | (151,061 | ) |  | (185,898 | ) |
| Deferred tax asset, net of valuation allowance | $ | 739,446 |  |  | $ | 1,155,104 |  |

[0000936395-18-000013:notes:75]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. See Note 2 above and Note 14 below. As of January 31, 2018, Ciena continues to maintain a valuation allowance of $151.1 million. This valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-18-000013:notes:76]
[same as prior period, unchanged from 0000936395-17-000051:notes:139]

[0000936395-18-000013:notes:77]
[same as prior period, unchanged from 0000936395-17-000051:notes:140]

[0000936395-18-000013:notes:78]
|  | January 31, 2018 |  | October 31, 2017 |
| Raw materials | $ | 47,710 |  |  | $ | 52,898 |  |
| Work-in-process | 16,444 |  |  | 18,623 |  |
| Finished goods | 176,426 |  |  | 185,488 |  |
| Deferred cost of goods sold | 64,445 |  |  | 61,340 |  |
|  | 305,025 |  |  | 318,349 |  |
| Provision for excess and obsolescence | (49,774 | ) |  | (51,206 | ) |
|  | $ | 255,251 |  |  | $ | 267,143 |  |

[0000936395-18-000013:notes:79]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first three months of fiscal 2018, Ciena recorded a provision for excess and obsolescence of $6.8 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-18-000013:notes:80]
The following table summarizes the final legal maturities of debt investments at January 31, 2018 (in thousands):

[0000936395-18-000013:notes:81]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 279,272 |  |  | $ | 278,743 |  |
| Due in 1-2 years | 59,313 |  |  | 59,151 |  |
|  | $ | 338,585 |  |  | $ | 337,894 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-18-000013:notes:82]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-18-000013:notes:83]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-18-000013:notes:84]
|  | January 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,404 |  |  | $ | — |  |  | (530 | ) |  | $ | 238,874 |  |
| Included in long-term investments | 59,313 |  |  | — |  |  | (162 | ) |  | 59,151 |  |
|  | $ | 298,717 |  |  | $ | — |  |  | $ | (692 | ) |  | $ | 298,025 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 39,868 |  |  | 1 |  |  | — |  |  | $ | 39,869 |  |
|  | $ | 39,868 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 39,869 |  |

[0000936395-18-000013:notes:85]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-18-000013:notes:86]
Newly Issued Accounting Standards - Effective

[0000936395-18-000013:notes:87]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

[0000936395-18-000013:notes:88]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

[0000936395-18-000013:notes:89]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

[0000936395-18-000013:notes:90]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-18-000013:notes:91]
In May 2014, the FASB issued ASU No. 2014-09 ("ASU 2014-09"), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

[0000936395-18-000013:notes:92]
For multiple element software arrangements where vendor-specific objective evidence ("VSOE") of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of ASU 2014-09 will require that it determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-18-000013:notes:93]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-18-000013:notes:94]
Ciena has considered the impact of the guidance in Accounting Standards Codification ("ASC") 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-18-000013:notes:95]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-18-000013:notes:96]
In February 2016, the FASB issued ASU No. 2016-02 ("ASU 2016-02"), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-18-000013:notes:97]
[same as prior period, unchanged from 0000936395-17-000051:notes:167]

[0000936395-18-000013:notes:98]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the "SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2017 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000013:notes:99]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2018 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2017 was a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-18-000013:notes:100]
[same as prior period, unchanged from 0000936395-17-000051:notes:172]

[0000936395-18-000013:notes:101]
[same as prior period, unchanged from 0000936395-17-000051:notes:173]

[0000936395-18-000013:notes:102]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Interest income | $ | 2,444 |  |  | $ | 1,282 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (699 | ) |  | 1,024 |  |
| Foreign currency exchange gain (loss) | 13 |  |  | (2,417 | ) |
| Other | (183 | ) |  | 481 |  |
| Interest and other income (loss), net | $ | 1,575 |  |  | $ | 370 |  |

[0000936395-18-000013:notes:103]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. During the first three months of fiscal 2017, Ciena recorded $2.4 million in foreign currency exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the remeasurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2018, Ciena recorded losses of $0.7 million from non-hedge designated foreign currency forward contracts. During the first three months of fiscal 2017, Ciena recorded gains of $1.0 million from non-hedge designated foreign currency forward contracts.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-18-000013:notes:104]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-18-000013:notes:105]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Segment profit: |  |  |  |
| Networking Platforms | $ | 88,569 |  |  | $ | 113,747 |  |
| Software and Software-Related Services | 23,635 |  |  | 7,700 |  |
| Global Services | 41,037 |  |  | 35,469 |  |
| Total segment profit | 153,241 |  |  | 156,916 |  |
| Less: Non-performance operating expenses |  |  |  |
| Selling and marketing | 88,515 |  |  | 85,002 |  |
| General and administrative | 38,406 |  |  | 35,864 |  |
| Amortization of intangible assets | 3,623 |  |  | 14,551 |  |
| Significant asset impairments and restructuring costs | 5,961 |  |  | 2,395 |  |
| Add: Other non-performance financial items |  |  |  |
| Interest expense and other income (loss), net | (12,159 | ) |  | (14,833 | ) |
| Less: Provision for income taxes | 477,940 |  |  | 410 |  |
| Consolidated net income (loss) | $ | (473,363 | ) |  | $ | 3,861 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-18-000013:notes:106]
[same as prior period, unchanged from 0000936395-17-000051:notes:186]

[0000936395-18-000013:notes:107]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| Revenue: |  |  |  |
| Networking Platforms |  |  |  |
| Converged Packet Optical | $ | 427,401 |  |  | $ | 417,750 |  |
| Packet Networking | 68,632 |  |  | 72,194 |  |
| Total Networking Platforms | 496,033 |  |  | 489,944 |  |
| Software and Software-Related Services |  |  |  |
| Software Platforms | 29,576 |  |  | 17,049 |  |
| Software-Related Services | 23,911 |  |  | 22,331 |  |
| Total Software and Software-Related Services | 53,487 |  |  | 39,380 |  |
| Global Services |  |  |  |
| Maintenance Support and Training | 55,958 |  |  | 54,990 |  |
| Installation and Deployment | 30,016 |  |  | 27,919 |  |
| Consulting and Network Design | 10,641 |  |  | 9,264 |  |
| Total Global Services | 96,615 |  |  | 92,173 |  |
| Consolidated revenue | $ | 646,135 |  |  | $ | 621,497 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-18-000013:notes:108]
[same as prior period, unchanged from 0000936395-17-000051:notes:189]

[0000936395-18-000013:notes:109]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2018 (in thousands):

[0000936395-18-000013:notes:110]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 4,413 |  | (1) | 1,548 |  | (2) | 5,961 |  |
| Cash payments | (4,459 | ) |  | (1,282 | ) |  | (5,741 | ) |
| Balance at January 31, 2018 | $ | 1,245 |  |  | $ | 1,914 |  |  | $ | 3,159 |  |
| Current restructuring liabilities | $ | 1,245 |  |  | $ | 590 |  |  | $ | 1,835 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,324 |  |  | $ | 1,324 |  |

[0000936395-18-000013:notes:111]
| (1) | Reflects a global workforce reduction of approximately 100 employees during the first quarter of fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-18-000013:notes:112]
| (2) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California. |

[0000936395-18-000013:notes:113]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2017 (in thousands):

[0000936395-18-000013:notes:114]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 2,008 |  |  | 387 |  |  | 2,395 |  |
| Cash payments | (2,512 | ) |  | (652 | ) |  | (3,164 | ) |
| Balance at January 31, 2017 | $ | 364 |  |  | $ | 1,705 |  |  | $ | 2,069 |  |
| Current restructuring liabilities | $ | 364 |  |  | $ | 1,269 |  |  | $ | 1,633 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 436 |  |  | $ | 436 |  |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-18-000013:notes:115]
[same as prior period, unchanged from 0000936395-17-000051:notes:201]

[0000936395-18-000013:notes:116]
|  | January 31, 2018 |  | October 31, 2017 |
| Compensation, payroll related tax and benefits(1) | $ | 68,526 |  |  | $ | 113,272 |  |
| Warranty | 42,526 |  |  | 42,456 |  |
| Vacation | 39,628 |  |  | 39,778 |  |
| Capital lease obligations | 3,934 |  |  | 3,772 |  |
| Interest payable | 4,867 |  |  | 3,612 |  |
| Other | 108,683 |  |  | 120,044 |  |
|  | $ | 268,164 |  |  | $ | 322,934 |  |

[0000936395-18-000013:notes:117]
(1) Reduction is primarily due to the timing of bonus payments to employees under Ciena's annual cash incentive compensation plan.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-18-000013:notes:118]
[same as prior period, unchanged from 0000936395-17-000051:notes:208]

[0000936395-18-000013:notes:119]
| Three Months Ended January 31, |  | Beginning Balance |  | Current Period Provisions (1) |  | Settlements |  | Ending Balance |
| 2017 |  | $ | 52,324 |  |  | 553 |  |  | (4,225 | ) |  | $ | 48,652 |  |
| 2018 |  | $ | 42,456 |  |  | 4,657 |  |  | (4,587 | ) |  | $ | 42,526 |  |

[0000936395-18-000013:notes:120]
(1) As a result of lower than expected actual failure rates, Ciena adjusted its fiscal 2017 provision for warranty. These adjustments for previous years provisions had the effect of reducing warranty provision by $3.6 million for the three months ended January 31, 2017.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-18-000013:notes:121]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-18-000013:notes:122]
|  | Quarter Ended January 31, |
|  | 2018 |  | 2017 |
| AT&T | $ | 90,645 |  |  | $ | 96,437 |  |
| Verizon | 68,445 |  |  | 73,089 |  |
| Total | $ | 159,090 |  |  | $ | 169,526 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-18-000013:notes:123]
[same as prior period, unchanged from 0000936395-17-000051:notes:213]

[0000936395-18-000013:notes:124]
|  | January 31, 2018 |  | October 31, 2017 |
| Canada | $ | 212,142 |  |  | $ | 203,491 |  |
| United States | 86,836 |  |  | 90,482 |  |
| Other International | 19,857 |  |  | 14,492 |  |
| Total | $ | 318,835 |  |  | $ | 308,465 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-18-000013:notes:125]
SEGMENTS AND ENTITY-WIDE DISCLOSURES

[0000936395-18-000013:notes:126]
[same as prior period, unchanged from 0000936395-17-000051:notes:218]

[0000936395-18-000013:notes:127]
[same as prior period, unchanged from 0000936395-17-000051:notes:219]

[0000936395-18-000013:notes:128]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

[0000936395-18-000013:notes:129]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. In addition, as of the first quarter of fiscal 2018, sales of Optical Transport products are reflected within the Converged Packet Optical product line for all periods presented. |

[0000936395-18-000013:notes:130]
[same as prior period, unchanged from 0000936395-17-000051:notes:222]

[0000936395-18-000013:notes:131]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations.

[0000936395-18-000013:notes:132]
[same as prior period, unchanged from 0000936395-17-000051:notes:225]

[0000936395-18-000013:notes:133]
[same as prior period, unchanged from 0000936395-17-000051:notes:227]

[0000936395-18-000013:notes:134]
[same as prior period, unchanged from 0000936395-17-000051:notes:226]

[0000936395-18-000013:notes:135]
Revenue from the software platforms portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from software-related services is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-18-000013:notes:136]
| • | Global Services reflects sales of a broad range of Ciena’s services for consulting and network design, installation and deployment, maintenance support and training activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

[0000936395-18-000013:notes:137]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2018, equipment, building, furniture and fixtures, net totaled $318.8 million primarily supporting asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supporting Ciena's unallocated selling and general and administrative activities. As of January 31, 2018, $36.9 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Networking Platforms segment and $59.6 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of January 31, 2018, all of the maintenance spares, net, totaling $43.7 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-18-000013:notes:138]
[same as prior period, unchanged from 0000936395-17-000051:notes:231]

[0000936395-18-000013:notes:139]
Segment Profit

[0000936395-18-000013:notes:140]
Segment profit is determined based on internal performance measures used by Ciena's chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs; interest and other income (loss), net; interest expense; and provisions for income taxes.

[0000936395-18-000013:notes:141]
Entity-Wide Reporting

[0000936395-18-000013:notes:142]
Ciena's revenue includes $383.4 million and $379.7 million of U.S. revenue for the first quarter of fiscal 2018 and 2017, respectively. There were no other countries that accounted for more than 10% of Ciena's revenue in the first quarter of fiscal 2018 and 2017.

[0000936395-18-000013:notes:143]
The following table reflects Ciena's geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-18-000013:notes:144]
[same as prior period, unchanged from 0000936395-17-000051:notes:238]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-18-000013:notes:145]
RECENT ACCOUNTING PRONOUNCEMENTS

[0000936395-18-000013:notes:146]
Except for the changes in certain policies related to adoption of the accounting standards described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-18-000013:notes:147]
STOCKHOLDERS' EQUITY

[0000936395-18-000013:notes:148]
Adoption of ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting

[0000936395-18-000013:notes:149]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Ciena also elected to recognize forfeitures of stock awards when they occur, rather than estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the period of adoption.

[0000936395-18-000013:notes:150]
Stock Repurchase Program

[0000936395-18-000013:notes:151]
On December 7, 2017, Ciena announced that its Board of Directors authorized a program to repurchase up to $300 million of Ciena’s common stock through the end of fiscal 2020. Ciena may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-18-000013:notes:152]
The purchase price for the shares of Ciena's stock repurchased is reflected as a reduction to stockholders' equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:SubsequentEventsTextBlock

[0000936395-18-000013:notes:153]
SUBSEQUENT EVENT

[0000936395-18-000013:notes:154]
From the end of the first quarter of fiscal 2018 through March 5, 2018, Ciena repurchased an additional 611,514 shares of its common stock, for an aggregate purchase price of  $13.8 million at an average price of $22.52 per share, including of repurchases pending settlement. As of March 5, 2018, Ciena has an aggregate of $280.5 million of authorized funds remaining under its Stock Repurchase Program.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-18-000013:notes:155]
ACCRUED LIABILITIES AND OTHER SHORT-TERM OBLIGATIONS
