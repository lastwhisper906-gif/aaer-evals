# CIEN MD&A — 0000936395-18-000013


## mdna

[0000936395-18-000013:mdna:1]
[same as prior period, unchanged from 0000936395-17-000051:mdna:1]

[0000936395-18-000013:mdna:2]
Cautionary Note Regarding Forward-Looking Statements

[0000936395-18-000013:mdna:3]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” "projects," "targets," or  “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and control of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including IT transitions or initiatives; the impact of the Tax Cuts and Jobs Act and provisional estimates with respect thereto; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-18-000013:mdna:4]
[same as prior period, unchanged from 0000936395-17-000051:mdna:3]

[0000936395-18-000013:mdna:5]
| • | fluctuations in our revenue, gross margin and operating results and our financial results generally; |

[0000936395-18-000013:mdna:6]
[same as prior period, unchanged from 0000936395-17-000051:mdna:5]

[0000936395-18-000013:mdna:7]
[same as prior period, unchanged from 0000936395-17-000051:mdna:6]

[0000936395-18-000013:mdna:8]
[same as prior period, unchanged from 0000936395-17-000051:mdna:7]

[0000936395-18-000013:mdna:9]
[same as prior period, unchanged from 0000936395-17-000051:mdna:8]

[0000936395-18-000013:mdna:10]
| • | product performance or security problems and undetected errors; |

[0000936395-18-000013:mdna:11]
| • | our ability to diversify our customer base beyond our traditional customers and to broaden the application for our solutions in communications networks; |

[0000936395-18-000013:mdna:12]
[same as prior period, unchanged from 0000936395-17-000051:mdna:11]

[0000936395-18-000013:mdna:13]
[same as prior period, unchanged from 0000936395-17-000051:mdna:12]

[0000936395-18-000013:mdna:14]
[same as prior period, unchanged from 0000936395-17-000051:mdna:13]

[0000936395-18-000013:mdna:15]
[same as prior period, unchanged from 0000936395-17-000051:mdna:14]

[0000936395-18-000013:mdna:16]
[same as prior period, unchanged from 0000936395-17-000051:mdna:15]

[0000936395-18-000013:mdna:17]
| • | the continued availability, on commercially reasonable terms, of software and other technology under third-party licenses; |

[0000936395-18-000013:mdna:18]
| • | the potential failure to maintain the security of confidential, proprietary or otherwise sensitive business information or systems or to protect against cyber attacks; |

[0000936395-18-000013:mdna:19]
| • | the performance of our third-party contract manufacturers; |

[0000936395-18-000013:mdna:20]
[same as prior period, unchanged from 0000936395-17-000051:mdna:19]

[0000936395-18-000013:mdna:21]
| • | our ability to manage effectively our relationships with third-party service partners and distributors; |

[0000936395-18-000013:mdna:22]
[same as prior period, unchanged from 0000936395-17-000051:mdna:21]

[0000936395-18-000013:mdna:23]
| • | our ability to grow and maintain our new distribution relationships under which we will make available certain technology as a component; |

[0000936395-18-000013:mdna:24]
[same as prior period, unchanged from 0000936395-17-000051:mdna:23]

[0000936395-18-000013:mdna:25]
[same as prior period, unchanged from 0000936395-17-000051:mdna:24]

[0000936395-18-000013:mdna:26]
[same as prior period, unchanged from 0000936395-17-000051:mdna:25]

[0000936395-18-000013:mdna:27]
[same as prior period, unchanged from 0000936395-17-000051:mdna:26]

[0000936395-18-000013:mdna:28]
[same as prior period, unchanged from 0000936395-17-000051:mdna:27]

[0000936395-18-000013:mdna:29]
| • | our ability to attract and retain experienced and qualified personnel; |

[0000936395-18-000013:mdna:30]
[same as prior period, unchanged from 0000936395-17-000051:mdna:29]

[0000936395-18-000013:mdna:31]
[same as prior period, unchanged from 0000936395-17-000051:mdna:30]

[0000936395-18-000013:mdna:32]
| • | changes in, and the impact of, government regulations, including with respect to: the communications industry generally; the business of our customers; the use, import or export of products; and the environment, potential climate change, and other social initiatives; |

[0000936395-18-000013:mdna:33]
| • | the impact of the Tax Cuts & Jobs Act and any adjustments to provisional estimates relating thereto; |

[0000936395-18-000013:mdna:34]
[same as prior period, unchanged from 0000936395-17-000051:mdna:32]

[0000936395-18-000013:mdna:35]
| • | the write-down of goodwill, long-lived assets, or our deferred tax assets; |

[0000936395-18-000013:mdna:36]
[same as prior period, unchanged from 0000936395-17-000051:mdna:34]

[0000936395-18-000013:mdna:37]
| • | adverse results in litigation matters. |

[0000936395-18-000013:mdna:38]
[same as prior period, unchanged from 0000936395-17-000051:mdna:36]

[0000936395-18-000013:mdna:39]
We are a network strategy and technology company, providing solutions that enable a wide range of network operators to deploy and manage next-generation communication architectures that deliver a broad array of services. We provide network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data, and voice traffic on communications networks. Our high-capacity hardware and network management and control software solutions enable open, programmable networks that enhance automation, reduce network complexity, and support changing service requirements. Our solutions create business and operational value for our customers by enabling them to introduce new revenue-generating services and reduce network costs.

[0000936395-18-000013:mdna:40]
Our solutions include a diverse set of Networking Platforms products, which are used by a broad range of network operator customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which can be applied from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware systems and components, we offer network management and domain control software platforms, along with advanced applications software, designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of services that help our customers design, optimize, integrate, deploy, manage, and maintain their networks.

[0000936395-18-000013:mdna:41]
26

[0000936395-18-000013:mdna:42]
Stock Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. For additional information, including our repurchase activities under the program, see Note 14 and Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-18-000013:mdna:43]
Impact of Tax Cuts and Jobs Act. Our results of operations for the first quarter of fiscal 2018 were impacted by enactment of the Tax Cuts and Jobs Act (the "Tax Act") on December 22, 2017. Accordingly, our results for the first quarter of fiscal 2018 include a provisional $476.9 million tax charge consisting of the following:

[0000936395-18-000013:mdna:44]
| • | $431.3 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Act; and |

[0000936395-18-000013:mdna:45]
| • | $45.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S. |

[0000936395-18-000013:mdna:46]
These amounts are provisional and reflect management’s current estimates and current interpretations of the Tax Act. These amounts may require adjustment in future periods as additional guidance under the Tax Act becomes available and analysis of its provisions is completed. See Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information related to the impact of the Tax Act.

[0000936395-18-000013:mdna:47]
Available Information. Our quarterly reports on Form 10-Q, annual reports on Form 10-K, current reports on Form 8-K, and any amendments thereto filed or furnished with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file or furnish these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-18-000013:mdna:48]
For additional information on our business, industry, market opportunity, competitive landscape, and strategy, see our annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000013:mdna:49]
[same as prior period, unchanged from 0000936395-17-000051:mdna:77]

[0000936395-18-000013:mdna:50]
[same as prior period, unchanged from 0000936395-17-000051:mdna:78]

[0000936395-18-000013:mdna:51]
We have the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Software and Software-Related Services; and (iii) Global Services. As of the first quarter of fiscal 2018, sales of our Optical Transport products are reflected within the Converged Packet Optical product line of our Networking Platforms segment for all periods presented. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000013:mdna:52]
Quarter ended January 31, 2018 compared to the quarter ended January 31, 2017

[0000936395-18-000013:mdna:53]
[same as prior period, unchanged from 0000936395-17-000051:mdna:81]

[0000936395-18-000013:mdna:54]
During the first quarter of fiscal 2018, approximately 19.0% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, Argentina Pesos, British Pounds, Mexican Pesos and Indian Rupees. During the first quarter of fiscal 2018, as compared to the first quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $4.2 million, or 0.7%, as compared to the first quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000013:mdna:55]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 427,401 |  |  | 66.1 |  | $ | 417,750 |  |  | 67.2 |  | $ | 9,651 |  |  | 2.3 |  |
| Packet Networking | 68,632 |  |  | 10.6 |  | 72,194 |  |  | 11.6 |  | (3,562 | ) |  | (4.9 | ) |
| Total Networking Platforms | 496,033 |  |  | 76.7 |  | 489,944 |  |  | 78.8 |  | 6,089 |  |  | 1.2 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 29,576 |  |  | 4.6 |  | 17,049 |  |  | 2.7 |  | 12,527 |  |  | 73.5 |  |
| Software-Related Services | 23,911 |  |  | 3.7 |  | 22,331 |  |  | 3.6 |  | 1,580 |  |  | 7.1 |  |
| Total Software and Software-Related Services | 53,487 |  |  | 8.3 |  | 39,380 |  |  | 6.3 |  | 14,107 |  |  | 35.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 55,958 |  |  | 8.7 |  | 54,990 |  |  | 8.9 |  | 968 |  |  | 1.8 |  |
| Installation and Deployment | 30,016 |  |  | 4.7 |  | 27,919 |  |  | 4.5 |  | 2,097 |  |  | 7.5 |  |
| Consulting and Network Design | 10,641 |  |  | 1.6 |  | 9,264 |  |  | 1.5 |  | 1,377 |  |  | 14.9 |  |
| Total Global Services | 96,615 |  |  | 15.0 |  | 92,173 |  |  | 14.9 |  | 4,442 |  |  | 4.8 |  |
| Consolidated revenue | $ | 646,135 |  |  | 100.0 |  | $ | 621,497 |  |  | 100.0 |  | $ | 24,638 |  |  | 4.0 |  |

[0000936395-18-000013:mdna:56]
[same as prior period, unchanged from 0000936395-17-000051:mdna:84]

[0000936395-18-000013:mdna:57]
[same as prior period, unchanged from 0000936395-17-000051:mdna:85]

[0000936395-18-000013:mdna:58]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:59]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $9.7 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $3.6 million of our Packet Networking products. |

[0000936395-18-000013:mdna:60]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $50.4 million of our Waveserver stackable interconnect system, primarily due to increased sales to Web-scale providers, which, as we continue to diversify, represent a growing portion of our business, and $25.2 million of our Optical Transport Network (OTN) configuration for the 5410 Reconfigurable Switching System, primarily due to increased sales to communications service providers in the Asia Pacific (“APAC”) region. These increases were partially offset |

[0000936395-18-000013:mdna:61]
by sales decreases of $33.4 million of our 6500 Packet-Optical Platform, $16.4 million of our 5430 Reconfigurable Switching System and $11.9 million of our Z-Series Packet-Optical Platform. The decreases in sales of our 6500 Packet-Optical Platform are primarily due to decreased sales to certain communications service providers, government customers and certain submarine network operators.

[0000936395-18-000013:mdna:62]
| ◦ | Packet Networking sales primarily reflects a sales decrease of $5.4 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to AT&T, partially offset by increased sales to other communications service providers. |

[0000936395-18-000013:mdna:63]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $12.5 million in our software platforms and $1.6 million in software-related services. The increase in software platform sales primarily reflects an increase of $13.4 million in sales of our Blue Planet software platform to AT&T and other communications service providers. |

[0000936395-18-000013:mdna:64]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $2.1 million of our installation and deployment services, $1.4 million of our network transformation services and $1.0 million of our maintenance support and training services. |

[0000936395-18-000013:mdna:65]
Our operating segments each engage in business and operations across four geographic regions: North America; Europe, Middle East and Africa ("EMEA"); Caribbean and Latin America (“CALA”); and APAC. Results for North America include only activities in the U.S. and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as the APAC region. We believe that this is an important part of our strategy, and that it is required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The increase in our APAC region for the fiscal quarter ended January 31, 2018 was primarily driven by increased sales in Japan and continued execution of our strategy to capture new market share with communications service providers in the region. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000013:mdna:66]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| North America | $ | 402,909 |  |  | 62.4 |  | $ | 405,928 |  |  | 65.3 |  | $ | (3,019 | ) |  | (0.7 | ) |
| EMEA | 97,834 |  |  | 15.1 |  | 91,543 |  |  | 14.7 |  | 6,291 |  |  | 6.9 |  |
| CALA | 34,563 |  |  | 5.3 |  | 35,146 |  |  | 5.7 |  | (583 | ) |  | (1.7 | ) |
| APAC | 110,829 |  |  | 17.2 |  | 88,880 |  |  | 14.3 |  | 21,949 |  |  | 24.7 |  |
| Total | $ | 646,135 |  |  | 100.0 |  | $ | 621,497 |  |  | 100.0 |  | $ | 24,638 |  |  | 4.0 |  |

[0000936395-18-000013:mdna:67]
[same as prior period, unchanged from 0000936395-17-000051:mdna:95]

[0000936395-18-000013:mdna:68]
[same as prior period, unchanged from 0000936395-17-000051:mdna:96]

[0000936395-18-000013:mdna:69]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:70]
[same as prior period, unchanged from 0000936395-17-000051:mdna:103]

[0000936395-18-000013:mdna:71]
[same as prior period, unchanged from 0000936395-17-000051:mdna:104]

[0000936395-18-000013:mdna:72]
[same as prior period, unchanged from 0000936395-17-000051:mdna:105]

[0000936395-18-000013:mdna:73]
Our gross profit as a percentage of revenue, or “gross margin,” has remained relatively consistent in recent fiscal years. However, gross margin, particularly when viewed on a quarterly basis, can fluctuate due to a number of factors. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we

[0000936395-18-000013:mdna:74]
regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Our success in taking share and winning new business can result in additional costs associated with the early stages of network deployments, including an increased concentration of lower margin “common” equipment sales and installation services, as compared to higher margin products including channel cards, software services, and maintenance services. Gross margin can be impacted by technology-based price compression and the introduction  or substitution of new platforms for existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations and our revenue concentration within a particular segment, product line, geography, or customer.

[0000936395-18-000013:mdna:75]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix, and the timing and extent of any investments in internal resources to support this business.

[0000936395-18-000013:mdna:76]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold, and gross profit for the periods indicated:

[0000936395-18-000013:mdna:77]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 646,135 |  |  | 100.0 |  | $ | 621,497 |  |  | 100.0 |  | $ | 24,638 |  |  | 4.0 |  |
| Total cost of goods sold | 374,370 |  |  | 57.9 |  | 347,712 |  |  | 55.9 |  | 26,658 |  |  | 7.7 |  |
| Gross profit | $ | 271,765 |  |  | 42.1 |  | $ | 273,785 |  |  | 44.1 |  | $ | (2,020 | ) |  | (0.7 | ) |

[0000936395-18-000013:mdna:78]
[same as prior period, unchanged from 0000936395-17-000051:mdna:110]

[0000936395-18-000013:mdna:79]
[same as prior period, unchanged from 0000936395-17-000051:mdna:111]

[0000936395-18-000013:mdna:80]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:81]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 525,609 |  |  | 100.0 |  | $ | 506,993 |  |  | 100.0 |  | $ | 18,616 |  |  | 3.7 |  |
| Product cost of goods sold | 313,120 |  |  | 59.6 |  | 286,811 |  |  | 56.6 |  | 26,309 |  |  | 9.2 |  |
| Product gross profit | $ | 212,489 |  |  | 40.4 |  | $ | 220,182 |  |  | 43.4 |  | $ | (7,693 | ) |  | (3.5 | ) |

[0000936395-18-000013:mdna:82]
[same as prior period, unchanged from 0000936395-17-000051:mdna:114]

[0000936395-18-000013:mdna:83]
[same as prior period, unchanged from 0000936395-17-000051:mdna:115]

[0000936395-18-000013:mdna:84]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:85]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 120,526 |  |  | 100.0 |  | $ | 114,504 |  |  | 100.0 |  | $ | 6,022 |  |  | 5.3 |
| Service cost of goods sold | 61,250 |  |  | 50.8 |  | 60,901 |  |  | 53.2 |  | 349 |  |  | 0.6 |
| Service gross profit | $ | 59,276 |  |  | 49.2 |  | $ | 53,603 |  |  | 46.8 |  | $ | 5,673 |  |  | 10.6 |

[0000936395-18-000013:mdna:86]
[same as prior period, unchanged from 0000936395-17-000051:mdna:118]

[0000936395-18-000013:mdna:87]
[same as prior period, unchanged from 0000936395-17-000051:mdna:119]

[0000936395-18-000013:mdna:88]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:89]
| • | Gross profit as a percentage of revenue reflects reduced product gross profit, partially offset by improved services gross profit. We may encounter fluctuations or reductions in quarterly gross margin during fiscal 2018 as a result of our strategy to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. |

[0000936395-18-000013:mdna:90]
| • | Gross profit on products as a percentage of product revenue decreased primarily as a result of market-based price erosion, the impact of early stages of international network deployments, including an increased concentration of lower margin “common” equipment sales, partially offset by product cost reductions and increased software platform |

[0000936395-18-000013:mdna:91]
sales. Part of our strategy for fiscal 2018 is to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Accordingly, we may encounter fluctuations or reductions in quarterly gross margin during this period.

[0000936395-18-000013:mdna:92]
| • | Gross profit on services as a percentage of services revenue increased primarily due to improved margin on deployment sales and increased sales of higher margin software subscription services and maintenance support services. |

[0000936395-18-000013:mdna:93]
[same as prior period, unchanged from 0000936395-17-000051:mdna:124]

[0000936395-18-000013:mdna:94]
We expect operating expense to increase in fiscal 2018 from the level reported for fiscal 2017 in order to fund our research and development initiatives.

[0000936395-18-000013:mdna:95]
[same as prior period, unchanged from 0000936395-17-000051:mdna:126]

[0000936395-18-000013:mdna:96]
| • | Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, testing of our products, depreciation expense, and third-party consulting costs. |

[0000936395-18-000013:mdna:97]
| • | Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense), and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs. |

[0000936395-18-000013:mdna:98]
| • | General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense), and costs for third-party consulting and other services. |

[0000936395-18-000013:mdna:99]
| • | Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions. |

[0000936395-18-000013:mdna:100]
| • | Significant asset impairments and restructuring costs primarily reflect actions we have taken to better align our workforce, facilities, and operating costs with perceived market opportunities, business strategies and changes in market and business conditions and significant impairments of assets. |

[0000936395-18-000013:mdna:101]
During the first quarter of fiscal 2018, approximately 53.4% of our operating expense was non-U.S. Dollar denominated,  including expenses in Canadian Dollars, British Pounds, Indian Rupees, Euros, and Brazilian Reais. During the first quarter of fiscal 2018 as compared to the first quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $6.2 million, or 2.4%, as compared to the first quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000013:mdna:102]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 118,524 |  |  | 18.3 |  | $ | 116,869 |  |  | 18.8 |  | $ | 1,655 |  |  | 1.4 |  |
| Selling and marketing | 88,515 |  |  | 13.7 |  | 85,002 |  |  | 13.7 |  | 3,513 |  |  | 4.1 |  |
| General and administrative | 38,406 |  |  | 6.0 |  | 35,864 |  |  | 5.8 |  | 2,542 |  |  | 7.1 |  |
| Amortization of intangible assets | 3,623 |  |  | 0.6 |  | 14,551 |  |  | 2.3 |  | (10,928 | ) |  | (75.1 | ) |
| Significant asset impairments and restructuring costs | 5,961 |  |  | 0.9 |  | 2,395 |  |  | 0.4 |  | 3,566 |  |  | 148.9 |  |
| Total operating expenses | $ | 255,029 |  |  | 39.5 |  | $ | 254,681 |  |  | 41.0 |  | $ | 348 |  |  | 0.1 |  |

[0000936395-18-000013:mdna:103]
[same as prior period, unchanged from 0000936395-17-000051:mdna:135]

[0000936395-18-000013:mdna:104]
[same as prior period, unchanged from 0000936395-17-000051:mdna:136]

[0000936395-18-000013:mdna:105]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:106]
| • | Research and development expense was adversely affected by $3.3 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $1.7 million. This change primarily reflects increased employee and compensation costs and depreciation costs, partially offset by lower facility and information systems expense and professional services. |

[0000936395-18-000013:mdna:107]
| • | Selling and marketing expense was adversely affected by $2.4 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, selling and marketing expenses increased by $3.5 million, primarily reflecting increased employee and compensation costs. |

[0000936395-18-000013:mdna:108]
| • | General and administrative expense increased by $2.5 million, primarily reflecting increased professional services and legal fees. |

[0000936395-18-000013:mdna:109]
[same as prior period, unchanged from 0000936395-17-000051:mdna:141]

[0000936395-18-000013:mdna:110]
| • | Significant asset impairments and restructuring costs increased reflecting a global workforce reduction of approximately 100 employees during the first quarter of fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. The increase also reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California. |

[0000936395-18-000013:mdna:111]
[same as prior period, unchanged from 0000936395-17-000051:mdna:144]

[0000936395-18-000013:mdna:112]
[same as prior period, unchanged from 0000936395-17-000051:mdna:145]

[0000936395-18-000013:mdna:113]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 1,575 |  |  | 0.2 |  | $ | 370 |  |  | 0.1 |  | $ | 1,205 |  |  | 325.7 |  |
| Interest expense | $ | 13,734 |  |  | 2.1 |  | $ | 15,203 |  |  | 2.4 |  | $ | (1,469 | ) |  | (9.7 | ) |
| Provision for income taxes | $ | 477,940 |  |  | 74.0 |  | $ | 410 |  |  | 0.1 |  | $ | 477,530 |  |  | n/a |  |

[0000936395-18-000013:mdna:114]
[same as prior period, unchanged from 0000936395-17-000051:mdna:147]

[0000936395-18-000013:mdna:115]
[same as prior period, unchanged from 0000936395-17-000051:mdna:148]

[0000936395-18-000013:mdna:116]
**    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:117]
n/a    Not meaningful

[0000936395-18-000013:mdna:118]
| • | Interest and other income (loss), net primarily reflects a $1.1 million gain in interest income. |

[0000936395-18-000013:mdna:119]
| • | Interest expense decreased primarily due to a reduction in our aggregate outstanding debt due to the refinancing of our term loans during the second quarter of fiscal 2017 and the maturity of our outstanding 0.875% Convertible Senior Notes during the third quarter of fiscal 2017. |

[0000936395-18-000013:mdna:120]
| • | Provision for income taxes increased primarily due to the impact of significant additional tax expense resulting from the enactment of the Tax Act and reflects $431.3 million for the remeasurement of our net deferred tax assets and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. For additional information, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-18-000013:mdna:121]
Segment Profit

[0000936395-18-000013:mdna:122]
[same as prior period, unchanged from 0000936395-17-000051:mdna:216]

[0000936395-18-000013:mdna:123]
|  | Quarter Ended January 31, |  |  |  |
|  | 2018 |  | 2017 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 88,569 |  |  | $ | 113,747 |  |  | $ | (25,178 | ) |  | (22.1 | ) |
| Software and Software-Related Services | $ | 23,635 |  |  | $ | 7,700 |  |  | $ | 15,935 |  |  | 206.9 |  |
| Global Services | $ | 41,037 |  |  | $ | 35,469 |  |  | $ | 5,568 |  |  | 15.7 |  |

[0000936395-18-000013:mdna:124]
[same as prior period, unchanged from 0000936395-17-000051:mdna:168]

[0000936395-18-000013:mdna:125]
*    Denotes % change from 2017 to 2018

[0000936395-18-000013:mdna:126]
| • | Networking Platforms segment profit decreased, primarily due to reduced gross margin as described above, and increased research and development costs, partially offset by higher sales volume. |

[0000936395-18-000013:mdna:127]
| • | Software and Software-Related Services segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, and slightly lower research and development costs. |

[0000936395-18-000013:mdna:128]
| • | Global Services segment profit increased, primarily due to improved gross margin on deployment sales and increased sales of higher margin maintenance support services. |

[0000936395-18-000013:mdna:129]
[same as prior period, unchanged from 0000936395-17-000051:mdna:231]

[0000936395-18-000013:mdna:130]
For the three months ended January 31, 2018, we generated $35.7 million in cash to fund our operating needs, as our net loss (adjusted for non-cash charges) of $56.4 million exceeded our working capital requirements of $20.7 million. Our net loss (adjusted for non-cash charges) reflects a non-cash tax provision of $476.9 million primarily related to the enactment of the Tax Act. For additional information on the non-cash tax provision, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. For additional details on our cash from operations, see the discussion below entitled “Cash from Operations.”

[0000936395-18-000013:mdna:131]
Cash, cash equivalents and investments increased by $17.3 million during the first three months of fiscal 2018. In addition to the cash from operations mentioned above, proceeds from issuance of equity under our employee stock purchase plans provided $11.0 million in cash during the period. These provisions were sufficient to fund our investing activities for capital expenditures totaling $25.7 million, our settlement of certain foreign currency forward contracts of $1.1 million and our other financing activities, including our new stock repurchase program described below and in Note 14 and Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, which totaled $4.1 million in the period.

[0000936395-18-000013:mdna:132]
|  | January 31, 2018 |  | October 31, 2017 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 648,867 |  |  | $ | 640,513 |  |  | $ | 8,354 |  |
| Short-term investments in marketable debt securities | 278,743 |  |  | 279,133 |  |  | (390 | ) |
| Long-term investments in marketable debt securities | 59,151 |  |  | 49,783 |  |  | 9,368 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 986,761 |  |  | $ | 969,429 |  |  | $ | 17,332 |  |

[0000936395-18-000013:mdna:133]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of January 31, 2018 totaled $986.8 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the "ABL Credit Facility"). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 31, 2018, letters of credit totaling $70.0 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2018.

[0000936395-18-000013:mdna:134]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $60.7 million as of January 31, 2018. Our accumulated historical foreign earnings are generally held in either cash or short-term intercompany receivables, or have been used to fund investments in equipment, building, furniture and fixtures, or other assets and liabilities of our foreign operations. We currently intend to reinvest indefinitely our foreign earnings, however, we intend to study further the changes resulting from the enactment of the Tax Act, the costs of repatriation of such foreign earnings, and the current and future cash needs of our foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If we determine to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $22.0 million. See Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000013:mdna:135]
Intent to Cash Settle New 2018 Convertible Notes. As more fully described in Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, following the settlement of an exchange offer on August 2, 2017, approximately $288.7 million in aggregate principal amount at maturity of Original Notes were exchanged for New Notes, which provide us with the option, at our election, to settle conversions for cash, shares of our common stock, or a combination of cash and shares. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash.

[0000936395-18-000013:mdna:136]
Stock Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. As of March 5, 2018, an aggregate

[0000936395-18-000013:mdna:137]
of $280.5 million of authorized funds remained under this repurchase program. For additional information, including our repurchase activities under the program, see Note 14 and Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-18-000013:mdna:138]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-18-000013:mdna:139]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations, including the settlement of the principal amount of the New Notes in cash upon any conversions prior to maturity, through at least the next 12 months.

[0000936395-18-000013:mdna:140]
[same as prior period, unchanged from 0000936395-17-000051:mdna:240]

[0000936395-18-000013:mdna:141]
The following sections set forth the components of our $35.7 million of cash generated from operating activities during the first three months of fiscal 2018:

[0000936395-18-000013:mdna:142]
Net loss (adjusted for non-cash charges)

[0000936395-18-000013:mdna:143]
The following table sets forth our net loss (adjusted for non-cash charges) during the period (in thousands):

[0000936395-18-000013:mdna:144]
|  | Three months ended |
|  | January 31, 2018 |
| Net loss | $ | (473,363 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 20,833 |  |
| Share-based compensation costs | 12,393 |  |
| Amortization of intangible assets | 5,912 |  |
| Deferred tax provision | 476,897 |  |
| Provision for inventory excess and obsolescence | 6,804 |  |
| Provision for warranty | 4,657 |  |
| Other | 2,269 |  |
| Net loss (adjusted for non-cash charges) | $ | 56,402 |  |

[0000936395-18-000013:mdna:145]
[same as prior period, unchanged from 0000936395-17-000051:mdna:245]

[0000936395-18-000013:mdna:146]
We used $20.7 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-18-000013:mdna:147]
|  | Three months ended |
|  | January 31, 2018 |
| Cash provided by accounts receivable | $ | 72,439 |  |
| Cash provided by inventories | 5,199 |  |
| Cash provided by prepaid expenses and other | 16,120 |  |
| Cash used in accounts payable, accruals and other obligations | (111,476 | ) |
| Cash used in deferred revenue | (2,981 | ) |
| Total cash used for working capital | $ | (20,699 | ) |

[0000936395-18-000013:mdna:148]
As compared to the end of fiscal 2017:

[0000936395-18-000013:mdna:149]
| • | The $72.4 million of cash provided by accounts receivable during the first three months of fiscal 2018 reflects increased customer collections; |

[0000936395-18-000013:mdna:150]
| • | The $5.2 million of cash provided by inventory during the first three months of fiscal 2018 primarily reflects improved manufacturing efficiencies to meet customer delivery schedules, partially offset by higher deferred costs of sales awaiting customer acceptance; |

[0000936395-18-000013:mdna:151]
| • | The $16.1 million of cash provided by prepaid expense and other during the first three months of fiscal 2018 primarily reflects lower prepaid value added taxes; |

[0000936395-18-000013:mdna:152]
| • | The $111.5 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2018 primarily reflects the timing of bonus payments to employees under our annual cash incentive compensation plan and payments to suppliers; and |

[0000936395-18-000013:mdna:153]
| • | The $3.0 million of cash used in deferred revenue during the first three months of fiscal 2018 represents a decrease in advanced payments received from customers prior to revenue recognition. |

[0000936395-18-000013:mdna:154]
Our days sales outstanding (DSOs) for the first three months of fiscal 2018 were 77 days, and our inventory turns for the first three months of fiscal 2018 were 4.9.

[0000936395-18-000013:mdna:155]
[same as prior period, unchanged from 0000936395-17-000051:mdna:255]

[0000936395-18-000013:mdna:156]
[same as prior period, unchanged from 0000936395-17-000051:mdna:256]

[0000936395-18-000013:mdna:157]
|  | Three months ended |
|  | January 31, 2018 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original)(1) | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New)(1) | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020(2) | 3,750 |  |
| Term Loan due January 30, 2022 (3) | 3,986 |  |
| Interest rate swaps(4) | 419 |  |
| ABL Credit Facility(5) | 404 |  |
| Capital leases | 1,461 |  |
| Cash paid during period | $ | 10,020 |  |

[0000936395-18-000013:mdna:158]
| (1) | Interest on our outstanding 3.75% Convertible Senior Notes due October 15, 2018 (Original) and our outstanding 3.75% Convertible Senior Notes due October 15, 2018 (New) is payable on April 15 and October 15 of each year. |

[0000936395-18-000013:mdna:159]
| (2) | Interest on our outstanding 4.0% Convertible Senior Notes due December 15, 2020 is payable on June 15 and December 15 of each year. |

[0000936395-18-000013:mdna:160]
| (3) | Interest on the Term Loan due January 30, 2022 (the "2022 Term Loan") is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of the first quarter of fiscal 2018, the interest rate on the 2022 Term Loan was 4.06%. |

[0000936395-18-000013:mdna:161]
| (4) | Our interest rate swaps fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during the periods described above will be 4.25%, 4.25% and 4.75%, respectively. |

[0000936395-18-000013:mdna:162]
| (5) | During the first three months of fiscal 2018, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.4 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-18-000013:mdna:163]
[same as prior period, unchanged from 0000936395-17-000051:mdna:269]

[0000936395-18-000013:mdna:164]
There have been no material changes to our contractual obligations since October 31, 2017. For a summary of our contractual obligations, see Item 7 of Part II of our annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000013:mdna:165]
[same as prior period, unchanged from 0000936395-17-000051:mdna:281]

[0000936395-18-000013:mdna:166]
[same as prior period, unchanged from 0000936395-17-000051:mdna:282]

[0000936395-18-000013:mdna:167]
[same as prior period, unchanged from 0000936395-17-000051:mdna:283]

[0000936395-18-000013:mdna:168]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our

[0000936395-18-000013:mdna:169]
estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-18-000013:mdna:170]
Our critical accounting policies and estimates have not changed materially since October 31, 2017, except for items listed below. For a discussion of our critical accounting policies and estimates, see Item 7 of Part II of our annual report on Form 10-K for the fiscal year ended October 31, 2017 (Management's Discussion and Analysis of Financial Condition and Results of Operations).

[0000936395-18-000013:mdna:171]
Deferred Tax Assets

[0000936395-18-000013:mdna:172]
Pursuant to Accounting Standards Codification (“ASC”) Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-18-000013:mdna:173]
The valuation allowance balance at January 31, 2018 was $151.1 million and the corresponding net deferred tax asset was $739.4 million. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending upon our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For example, the recently enacted Tax Act required us to write down our net deferred tax asset by approximately $431.3 million. As this is a provisional estimate, it may be subject to change based upon availability of additional guidance and our continued assessment of the impact of the Tax Act on our business. As these amounts are finalized throughout fiscal 2018, our operating results may be materially adversely affected by a non-cash charge to reflect the change in value of these assets. For further discussion, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000013:mdna:174]
Effects of Recent Accounting Pronouncements

[0000936395-18-000013:mdna:175]
See Note 2 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information relating to our discussion of the effects of recent accounting pronouncements.
