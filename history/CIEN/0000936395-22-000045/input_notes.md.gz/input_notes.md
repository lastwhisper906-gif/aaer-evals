# CIEN notes — 0000936395-22-000045


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-22-000045:notes:1]
[same as prior period, unchanged from 0000936395-22-000029:notes:1]

[0000936395-22-000045:notes:2]
[same as prior period, unchanged from 0000936395-22-000029:notes:2]

[0000936395-22-000045:notes:3]
[same as prior period, unchanged from 0000936395-22-000029:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-22-000045:notes:4]
[same as prior period, unchanged from 0000936395-22-000029:notes:4]

[0000936395-22-000045:notes:5]
[same as prior period, unchanged from 0000936395-22-000029:notes:5]

[0000936395-22-000045:notes:6]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000045:notes:7]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

[0000936395-22-000045:notes:8]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London

[0000936395-22-000045:notes:9]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000045:notes:10]
[same as prior period, unchanged from 0000936395-22-000029:notes:10]

[0000936395-22-000045:notes:11]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-22-000045:notes:12]
[same as prior period, unchanged from 0000936395-22-000029:notes:12]

[0000936395-22-000045:notes:13]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.

[0000936395-22-000045:notes:14]
[same as prior period, unchanged from 0000936395-22-000029:notes:14]

[0000936395-22-000045:notes:15]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | 773,728 |  |
| Services transferred over time | — |  |  | $ | 47,414 |  |  | $ | 12,845 |  |  | $ | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

[0000936395-22-000045:notes:16]
|  | Quarter Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

[0000936395-22-000045:notes:17]
|  | Six Months Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

[0000936395-22-000045:notes:18]
|  | Six Months Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

[0000936395-22-000045:notes:19]
[same as prior period, unchanged from 0000936395-22-000029:notes:17]

[0000936395-22-000045:notes:20]
[same as prior period, unchanged from 0000936395-22-000029:notes:18]

[0000936395-22-000045:notes:21]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 700,840 |  |  | $ | 587,475 |  |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |
| EMEA |  | 145,106 |  |  | 155,054 |  |  | 295,891 |  |  | 310,472 |  |
| APAC |  | 103,281 |  |  | 91,398 |  |  | 201,795 |  |  | 196,499 |  |
| Total revenue by geographic distribution |  | $ | 949,227 |  |  | $ | 833,927 |  |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |

[0000936395-22-000045:notes:22]
Ciena’s revenue includes $642.2 million and $518.6 million of United States revenue for the second quarter of fiscal 2022 and 2021, respectively. For the six months ended April 30, 2022 and May 1, 2021, United States revenue was $1.2 billion and $1.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-22-000045:notes:23]
[same as prior period, unchanged from 0000936395-22-000029:notes:21]

[0000936395-22-000045:notes:24]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| AT&T | $ | 103,189 |  |  | 125,138 |  |  | 214,065 |  |  | 193,941 |  |

[0000936395-22-000045:notes:25]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-22-000045:notes:26]
[same as prior period, unchanged from 0000936395-22-000029:notes:25]

[0000936395-22-000045:notes:27]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.

[0000936395-22-000045:notes:28]
•Routing and Switching - includes the 3900 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta (as defined in Note 4 below) virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

[0000936395-22-000045:notes:29]
[same as prior period, unchanged from 0000936395-22-000029:notes:28]

[0000936395-22-000045:notes:30]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines described above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-22-000045:notes:31]
[same as prior period, unchanged from 0000936395-22-000029:notes:30]

[0000936395-22-000045:notes:32]
[same as prior period, unchanged from 0000936395-22-000029:notes:31]

[0000936395-22-000045:notes:33]
[same as prior period, unchanged from 0000936395-22-000029:notes:32]

[0000936395-22-000045:notes:34]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-22-000045:notes:35]
[same as prior period, unchanged from 0000936395-22-000029:notes:34]

[0000936395-22-000045:notes:36]
[same as prior period, unchanged from 0000936395-22-000029:notes:35]

[0000936395-22-000045:notes:37]
|  |  | Balance at April 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 774,896 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 144,344 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 218,769 |  |  | $ | 175,464 |  |

[0000936395-22-000045:notes:38]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 12 below.

[0000936395-22-000045:notes:39]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $82.0 million and $78.0 million of revenue during the first six months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 30, 2022 and May 1, 2021.

[0000936395-22-000045:notes:40]
[same as prior period, unchanged from 0000936395-22-000029:notes:39]

[0000936395-22-000045:notes:41]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $32.5 million and $27.6 million as of April 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $14.1 million and $10.7 million during the first six months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

[0000936395-22-000045:notes:42]
[same as prior period, unchanged from 0000936395-22-000029:notes:41]

[0000936395-22-000045:notes:43]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2022, the aggregate amount of RPO was $2.7 billion. As of April 30, 2022, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-22-000045:notes:44]
[same as prior period, unchanged from 0000936395-22-000029:notes:43]

[0000936395-22-000045:notes:45]
|  | April 30,2022 |  | October 30,2021 |
| Products | $ | 19,911 |  |  | $ | 12,859 |  |
| Services | 198,858 |  |  | 162,605 |  |
| Total deferred revenue | 218,769 |  |  | 175,464 |  |
| Less current portion | (156,400) |  |  | (118,007) |  |
| Long-term deferred revenue | $ | 62,369 |  |  | $ | 57,457 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-22-000045:notes:46]
BUSINESS COMBINATIONS
Vyatta and Xelic Acquisitions

[0000936395-22-000045:notes:47]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology. AT&T is a customer of Ciena, see Note 3 above. On March 9, 2022, Ciena acquired Xelic, Inc. (“Xelic”), a provider and developer of field programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores. These businesses were acquired for an aggregate of approximately $64.3 million, of which $63.5 million was paid in cash and $0.8 million represents a future payable arrangement. These transactions have each been accounted for as the acquisition of a business.

[0000936395-22-000045:notes:48]
Ciena incurred approximately $1.7 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal and accounting advisors. These costs were recorded in acquisition and integration costs in the Condensed Consolidated Statement of Operations.

[0000936395-22-000045:notes:49]
The following table summarizes the final purchase price allocation related to the acquisitions based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-22-000045:notes:50]
|  | Amount |
| Cash and cash equivalents | $ | 201 |  |
| Prepaid expenses and other | 1,614 |  |
| Equipment, furniture and fixtures | 694 |  |
| Customer relationships and contracts | 15,800 |  |
| Developed technology | 32,491 |  |
| Goodwill | 17,982 |  |
| Accrued liabilities | (4,434) |  |
| Total purchase consideration | $ | 64,348 |  |

[0000936395-22-000045:notes:51]
[same as prior period, unchanged from 0000936395-22-000029:notes:50]

[0000936395-22-000045:notes:52]
Developed technology represents purchased technology that has reached technological feasibility and for which the acquired companies had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-22-000045:notes:53]
The goodwill generated from these acquisitions are primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-22-000045:notes:54]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included in the Condensed Consolidated Statement of Operations for the reporting period are immaterial.


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-22-000045:notes:55]
CANADIAN EMERGENCY WAGE SUBSIDY
In April 2020, the Canadian government introduced the Canada Emergency Wage Subsidy (“CEWS”) to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. The CEWS program expired in October 2021. The subsidy covered employers of all sizes and across all sectors.

[0000936395-22-000045:notes:56]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. During the second quarter and six months ended May 1, 2021, Ciena recorded a CAD$51.1 million ($40.4 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($34.7 million) related to employee wages during fiscal 2020.

[0000936395-22-000045:notes:57]
The following table summarizes CEWS for the periods indicated (in thousands, USD):

[0000936395-22-000045:notes:58]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product | $ | — |  |  | $ | 4,189 |  |  | $ | — |  |  | $ | 4,189 |  |
| Service | — |  |  | 2,620 |  |  | — |  |  | 2,620 |  |
| CEWS benefit in cost of goods sold | — |  |  | 6,809 |  |  | — |  |  | 6,809 |  |
| Research and development | — |  |  | 28,923 |  |  | — |  |  | 28,923 |  |
| Sales and marketing | — |  |  | 2,551 |  |  | — |  |  | 2,551 |  |
| General and administrative | — |  |  | 2,161 |  |  | — |  |  | 2,161 |  |
| CEWS benefit in operating expense | — |  |  | 33,635 |  |  | — |  |  | 33,635 |  |
| Total CEWS benefit | $ | — |  |  | $ | 40,444 |  |  | $ | — |  |  | $ | 40,444 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-22-000045:notes:59]
SIGNIFICANT ASSET IMPAIRMENT AND RESTRUCTURING COSTS
Restructuring Costs

[0000936395-22-000045:notes:60]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the six months ended April 30, 2022 (in thousands):

[0000936395-22-000045:notes:61]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 1,413 |  | (1) | 7,018 |  | (2) | 8,431 |  |
| Cash payments | (1,388) |  |  | (7,018) |  |  | (8,406) |  |
| Balance at April 30, 2022 | $ | 806 |  |  | $ | — |  |  | $ | 806 |  |
| Current restructuring liabilities | $ | 806 |  |  | $ | — |  |  | $ | 806 |  |

[0000936395-22-000045:notes:62]
(1) Reflects employee costs associated with workforce reductions during the six months ended April 30, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000045:notes:63]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.

[0000936395-22-000045:notes:64]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the six months ended May 1, 2021 (in thousands):

[0000936395-22-000045:notes:65]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2020 | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 2,617 |  | (1) | 11,459 |  | (2) | 14,076 |  |
| Cash payments | (4,696) |  |  | (11,459) |  |  | (16,155) |  |
| Balance at May 1, 2021 | $ | 836 |  |  | $ | — |  |  | $ | 836 |  |
| Current restructuring liabilities | $ | 836 |  |  | $ | — |  |  | $ | 836 |  |

[0000936395-22-000045:notes:66]
(1) Reflects employee costs associated with workforce reductions during the six months ended May 1, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000045:notes:67]
Significant Asset Impairments

[0000936395-22-000045:notes:68]
In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions. On March 7, 2022, Ciena announced its decision to immediately suspend its business operations in Russia. As a result, Ciena recorded impairment charges of $4.1 million of which $2.0 million was a provision for credit losses.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-22-000045:notes:69]
INTEREST AND OTHER INCOME (LOSS), NETThe components of interest and other income (loss), net, are as follows for the periods indicated (in thousands):

[0000936395-22-000045:notes:70]
|  | Quarter Ended | Six Months Ended |  |
|  | April 30, |  | May 1, | April 30, |  | May 1, |  |
|  | 2022 |  | 2021 | 2022 |  | 2021 |  |
| Interest income | $ | 1,434 |  |  | $ | 554 |  | $ | 2,188 |  |  | $ | 1,088 |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 2,334 |  |  | 5,180 |  | (1,926) |  |  | 9,709 |  |  |
| Foreign currency exchange gains (losses) | (1,267) |  |  | (6,575) |  | 3,499 |  |  | (13,493) |  |  |
| Unrealized gain on cost method equity investment | — |  |  | — |  | 4,120 |  |  | — |  |  |
| Other | (1,693) |  |  | (433) |  | (3,387) |  |  | 301 |  |  |
| Interest and other income (loss), net | $ | 808 |  |  | $ | (1,274) |  | $ | 4,494 |  |  | $ | (2,395) |  |  |

[0000936395-22-000045:notes:71]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $3.5 million in foreign currency exchange rate gains for the first six months of fiscal 2022 and during the first six months of fiscal 2021, Ciena recorded $13.5 million in foreign currency exchange rate losses, both as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2022, Ciena recorded losses of $1.9 million and during the first six months of fiscal 2021, Ciena recorded gains of $9.7 million from non-hedge designated foreign currency forward contracts. During the first six months of fiscal 2022, Ciena recorded an unrealized gain of $4.1 million on its cost method equity investment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-22-000045:notes:72]
INCOME TAXES
The effective tax rate for the quarter ended April 30, 2022 was higher than the effective tax rate for the quarter ended May 1, 2021, primarily due to a higher foreign tax rate.

[0000936395-22-000045:notes:73]
The effective tax rate for the six months ended April 30, 2022 was lower than the effective tax rate for the six months ended May 1, 2021, primarily due to a lower foreign tax rate in the six months ended April 30, 2022.

[0000936395-22-000045:notes:74]
Ciena’s future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations. Ciena continues to monitor these items and will adopt strategies to address their impact as appropriate. In certain jurisdictions, Ciena provides a valuation allowance for its deferred tax assets in excess of deferred tax liabilities because Ciena has concluded that it is more likely than not that such deferred tax assets will ultimately not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. Ciena assesses available positive and negative evidence regarding its ability to realize deferred tax assets and record a valuation allowance when it is more likely than not that deferred tax assets will not be realized. To form a conclusion, management considers its recent financial results and trends and makes judgments and estimates related to projections of profitability, the timing and extent of the use of net operating loss carryforwards, and tax planning strategies.

[0000936395-22-000045:notes:75]
Ciena will continue to evaluate future financial performance to determine whether such profitability is both sustainable and significant enough to provide sufficient evidence to support reversal of all or a portion of the valuation allowance. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-22-000045:notes:76]
SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-22-000045:notes:77]
|  | April 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 530,051 |  |  | $ | 1 |  |  | $ | (500) |  |  | $ | 529,552 |  |
| Included in long-term investments | 89,593 |  |  | — |  |  | (2,451) |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 1 |  |  | $ | (2,951) |  |  | $ | 616,694 |  |

[0000936395-22-000045:notes:78]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,488 |  |  | $ | 5 |  |  | $ | (10) |  |  | $ | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |

[0000936395-22-000045:notes:79]
The following table summarizes the final legal maturities of debt investments as of April 30, 2022 (in thousands):

[0000936395-22-000045:notes:80]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 530,051 |  |  | $ | 529,552 |  |
| Due in 1-2 years | 89,593 |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 616,694 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-22-000045:notes:81]
[same as prior period, unchanged from 0000936395-22-000029:notes:72]

[0000936395-22-000045:notes:82]
|  | April 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 607,553 |  |  | $ | — |  |  | $ | — |  |  | $ | 607,553 |  |
| Bond mutual fund | 100,428 |  |  | — |  |  | — |  |  | 100,428 |  |
| Time deposits | 133,544 |  |  | — |  |  | — |  |  | 133,544 |  |
| Deferred compensation plan assets | 13,274 |  |  | — |  |  | — |  |  | 13,274 |  |
| U.S. government obligations | — |  |  | 616,694 |  |  | — |  |  | 616,694 |  |
| Foreign currency forward contracts | — |  |  | 5,867 |  |  | — |  |  | 5,867 |  |
| Total assets measured at fair value | $ | 854,799 |  |  | $ | 622,561 |  |  | $ | — |  |  | $ | 1,477,360 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 5,281 |  |  | $ | — |  |  | $ | 5,281 |  |
| Forward starting interest rate swaps | — |  |  | 1,465 |  |  | — |  |  | 1,465 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,746 |  |  | $ | — |  |  | $ | 6,746 |  |

[0000936395-22-000045:notes:83]
[same as prior period, unchanged from 0000936395-22-000029:notes:74]

[0000936395-22-000045:notes:84]
[same as prior period, unchanged from 0000936395-22-000029:notes:75]

[0000936395-22-000045:notes:85]
|  | April 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 841,525 |  |  | $ | — |  |  | $ | — |  |  | $ | 841,525 |  |
| Short-term investments | — |  |  | 529,552 |  |  | — |  |  | 529,552 |  |
| Prepaid expenses and other | — |  |  | 5,867 |  |  | — |  |  | 5,867 |  |
| Long-term investments | — |  |  | 87,142 |  |  | — |  |  | 87,142 |  |
| Other long-term assets | 13,274 |  |  | — |  |  | — |  |  | 13,274 |  |
| Total assets measured at fair value | $ | 854,799 |  |  | $ | 622,561 |  |  | $ | — |  |  | $ | 1,477,360 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 5,281 |  |  | $ | — |  |  | $ | 5,281 |  |
| Other long-term obligations | — |  |  | 1,465 |  |  | — |  |  | 1,465 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,746 |  |  | $ | — |  |  | $ | 6,746 |  |

[0000936395-22-000045:notes:86]
[same as prior period, unchanged from 0000936395-22-000029:notes:77]

[0000936395-22-000045:notes:87]
[same as prior period, unchanged from 0000936395-22-000029:notes:78]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-22-000045:notes:88]
[same as prior period, unchanged from 0000936395-22-000029:notes:79]

[0000936395-22-000045:notes:89]
|  | April 30,2022 |  | October 30,2021 |
| Raw materials | $ | 373,517 |  |  | $ | 175,399 |  |
| Work-in-process | 12,268 |  |  | 10,260 |  |
| Finished goods | 157,919 |  |  | 180,800 |  |
| Deferred cost of goods sold | 28,921 |  |  | 44,765 |  |
| Gross inventories | 572,625 |  |  | 411,224 |  |
| Reserve for inventory excess and obsolescence | (35,747) |  |  | (36,959) |  |
| Inventories, net | $ | 536,878 |  |  | $ | 374,265 |  |

[0000936395-22-000045:notes:90]
The increase in raw materials inventory is related to the steps Ciena is taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first six months of fiscal 2022, Ciena recorded a provision for inventory excess and obsolescence of $8.5 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-22-000045:notes:91]
[same as prior period, unchanged from 0000936395-22-000029:notes:82]

[0000936395-22-000045:notes:92]
|  | April 30,2022 |  | October 30,2021 |
| Contract assets for unbilled accounts receivable, net | $ | 144,344 |  |  | $ | 101,355 |  |
| Prepaid VAT and other taxes | 71,658 |  |  | 77,388 |  |
| Prepaid expenses | 68,879 |  |  | 62,189 |  |
| Product demonstration equipment, net | 35,139 |  |  | 29,362 |  |
| Capitalized contract acquisition costs | 26,531 |  |  | 21,753 |  |
| Other non-trade receivables | 14,637 |  |  | 18,408 |  |
| Derivative assets | 5,867 |  |  | 14,935 |  |
| Deferred deployment expense | 289 |  |  | 264 |  |
|  | $ | 367,344 |  |  | $ | 325,654 |  |

[0000936395-22-000045:notes:93]
Depreciation of product demonstration equipment was $4.8 million during the first six months of fiscal 2022 and $5.1 million during the first six months of fiscal 2021.

[0000936395-22-000045:notes:94]
[same as prior period, unchanged from 0000936395-22-000029:notes:85]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-22-000045:notes:95]
[same as prior period, unchanged from 0000936395-22-000029:notes:86]

[0000936395-22-000045:notes:96]
|  | April 30, 2022 |  | October 30, 2021 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 428,218 |  |  | $ | (374,782) |  |  | $ | 53,436 |  |  | $ | 395,726 |  |  | $ | (359,828) |  |  | $ | 35,898 |  |
| Patents and licenses | 7,815 |  |  | (3,767) |  |  | 4,048 |  |  | 7,815 |  |  | (3,321) |  |  | 4,494 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 390,777 |  |  | (359,305) |  |  | 31,472 |  |  | 375,329 |  |  | (350,407) |  |  | 24,922 |  |
| Total intangible assets | $ | 826,810 |  |  | $ | (737,854) |  |  | $ | 88,956 |  |  | $ | 778,870 |  |  | $ | (713,556) |  |  | $ | 65,314 |  |

[0000936395-22-000045:notes:97]
The aggregate amortization expense of intangible assets was $24.5 million during the first six months of fiscal 2022 and $18.5 million during the first six months of fiscal 2021. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-22-000045:notes:98]
| Fiscal Year | Amount |  |
| 2022 | $ | 19,814 |  |  |
| 2023 | 28,815 |  |  |
| 2024 | 19,180 |  |  |
| 2025 | 13,317 |  |  |
| 2026 | 7,105 |  |  |
| Thereafter | 725 |  |  |
|  | $ | 88,956 |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-22-000045:notes:99]
[same as prior period, unchanged from 0000936395-22-000029:notes:90]

[0000936395-22-000045:notes:100]
|  | April 30,2022 |  | October 30,2021 |
| Compensation, payroll related tax and benefits (1) | $ | 122,590 |  |  | $ | 201,119 |  |
| Warranty | 45,684 |  |  | 48,019 |  |
| Vacation | 31,658 |  |  | 31,200 |  |
| Income taxes payable | 9,535 |  |  | 13,577 |  |
| Foreign currency forward contracts | 5,281 |  |  | 716 |  |
| Interest payable | 5,202 |  |  | 598 |  |
| Finance lease liabilities | 3,834 |  |  | 3,620 |  |
| Other | 109,366 |  |  | 110,436 |  |
|  | $ | 333,150 |  |  | $ | 409,285 |  |

[0000936395-22-000045:notes:101]
[same as prior period, unchanged from 0000936395-22-000029:notes:92]

[0000936395-22-000045:notes:102]
[same as prior period, unchanged from 0000936395-22-000029:notes:93]

[0000936395-22-000045:notes:103]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Six Months Ended May 1, 2021 |  | $ | 49,868 |  |  |  |  | 7,937 |  |  | (9,682) |  |  | $ | 48,123 |  |
| Six Months Ended April 30, 2022 |  | $ | 48,019 |  |  |  |  | 7,228 |  |  | (9,563) |  |  | $ | 45,684 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-22-000045:notes:104]
[same as prior period, unchanged from 0000936395-22-000029:notes:95]

[0000936395-22-000045:notes:105]
[same as prior period, unchanged from 0000936395-22-000029:notes:96]

[0000936395-22-000045:notes:106]
As of April 30, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability that is principally related to research and development activities. The notional amount of these contracts was approximately $251.5 million and $288.6 million as of April 30, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-22-000045:notes:107]
As of April 30, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $93.1 million and $296.1 million as of April 30, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-22-000045:notes:108]
[same as prior period, unchanged from 0000936395-22-000029:notes:99]

[0000936395-22-000045:notes:109]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of April 30, 2022 and October 30, 2021.

[0000936395-22-000045:notes:110]
In April 2022, Ciena entered into floating to fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the Secured Overnight Funding Rate (“SOFR”) for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350 million as of April 30, 2022. Ciena entered into the forward starting swaps to hedge its anticipated SOFR rate risk from the 2025 Term Loan because the LIBOR rate is expected to be discontinued in 2023.

[0000936395-22-000045:notes:111]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps and forward starting swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the 2025 Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-22-000045:notes:112]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 7 and Note 10 above.


## us-gaap:DebtDisclosureTextBlock

[0000936395-22-000045:notes:113]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-22-000045:notes:114]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-22-000045:notes:115]
The net carrying value of the 2025 Term Loan was comprised of the following for the periods indicated (in thousands):

[0000936395-22-000045:notes:116]
|  |  | April 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,089) |  |  | $ | (2,037) |  |  | $ | 674,281 |  |  | $ | 677,285 |  |

[0000936395-22-000045:notes:117]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.0 million as of April 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-22-000045:notes:118]
As of April 30, 2022, the estimated fair value of the 2025 Term Loan was $677.5 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-22-000045:notes:119]
2030 Notes

[0000936395-22-000045:notes:120]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-22-000045:notes:121]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”).

[0000936395-22-000045:notes:122]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. Ciena intends to use the net proceeds from the Offering for general corporate purposes.

[0000936395-22-000045:notes:123]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

[0000936395-22-000045:notes:124]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

[0000936395-22-000045:notes:125]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

[0000936395-22-000045:notes:126]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

[0000936395-22-000045:notes:127]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as

[0000936395-22-000045:notes:128]
described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

[0000936395-22-000045:notes:129]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0000936395-22-000045:notes:130]
|  |  | April 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,169) |  |  | $ | 394,831 |  |  |  |

[0000936395-22-000045:notes:131]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.2 million as of April 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first six months of fiscal 2022.

[0000936395-22-000045:notes:132]
As of April 30, 2022, the estimated fair value of the 2030 Notes was $363.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-22-000045:notes:133]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended April 30, 2022 (in thousands):

[0000936395-22-000045:notes:134]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (2,105) |  |  | (5,083) |  |  | 6,098 |  |  | (18,746) |  |  | (19,836) |  |
| Amounts reclassified from AOCI | — |  |  | (1,602) |  |  | 4,940 |  |  | — |  |  | 3,338 |  |
| Balance at April 30, 2022 | $ | (2,269) |  |  | $ | (469) |  |  | $ | (1,141) |  |  | $ | (12,180) |  |  | $ | (16,059) |  |

[0000936395-22-000045:notes:135]
The following table summarizes the changes in AOCI, net of tax, for the six months ended May 1, 2021 (in thousands):

[0000936395-22-000045:notes:136]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications | (7) |  |  | 14,690 |  |  | (494) |  |  | 26,261 |  |  | 40,450 |  |
| Amounts reclassified from AOCI | — |  |  | (4,256) |  |  | 4,525 |  |  | — |  |  | 269 |  |
| Balance at May 1, 2021 | $ | 38 |  |  | $ | 10,215 |  |  | $ | (17,504) |  |  | $ | 12,612 |  |  | $ | 5,361 |  |

[0000936395-22-000045:notes:137]
[same as prior period, unchanged from 0000936395-22-000029:notes:126]


## us-gaap:EarningsPerShareTextBlock

[0000936395-22-000045:notes:138]
EARNINGS PER SHARE CALCULATIONBasic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number 
of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-22-000045:notes:139]
The following table presents the calculation of Basic and Diluted EPS (in thousands, except per share amounts):

[0000936395-22-000045:notes:140]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income | $ | 38,922 |  |  | $ | 103,117 |  |  | $ | 84,745 |  |  | $ | 158,465 |  |
| Basic weighted average shares outstanding | 152,197 |  |  | 155,331 |  |  | 153,179 |  |  | 155,257 |  |
| Effect of dilutive potential common shares | 1,147 |  |  | 1,545 |  |  | 1,401 |  |  | 1,477 |  |
| Diluted weighted average shares | 153,344 |  |  | 156,876 |  |  | 154,580 |  |  | 156,734 |  |
| Basic EPS | $ | 0.26 |  |  | $ | 0.66 |  |  | $ | 0.55 |  |  | $ | 1.02 |  |
| Diluted EPS | $ | 0.25 |  |  | $ | 0.66 |  |  | $ | 0.55 |  |  | $ | 1.01 |  |
| Antidilutive employee share-based awards, excluded | 1,392 |  |  | 30 |  |  | 1,077 |  |  | 82 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-22-000045:notes:141]
[same as prior period, unchanged from 0000936395-22-000029:notes:130]

[0000936395-22-000045:notes:142]
On December 9, 2021, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received approximately 3.6 million shares of its common stock from Goldman, calculated based on the average of the volume-weighted average prices of Ciena’s common stock of $69.78 for the period from December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt.

[0000936395-22-000045:notes:143]
During the second quarter of fiscal 2022, Ciena repurchased an additional 1.5 million shares of its common stock, for an aggregate purchase price of $87.0 million at an average price of $57.92 per share. As of April 30, 2022, Ciena has repurchased an aggregate of 5.1 million shares for an aggregate purchase price of $337.0 million at an average price of $66.28 per share and has an aggregate of $663.0 million of authorized funds remaining under its stock repurchase program. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-22-000045:notes:144]
[same as prior period, unchanged from 0000936395-22-000029:notes:132]

[0000936395-22-000045:notes:145]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $35.0 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2022 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-22-000045:notes:146]
SHARE-BASED COMPENSATION EXPENSEThe following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-22-000045:notes:147]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Products | $ | 1,058 |  |  | $ | 498 |  |  | $ | 1,958 |  |  | $ | 1,451 |  |
| Services | 1,943 |  |  | 1,421 |  |  | 3,527 |  |  | 2,626 |  |
| Share-based compensation expense included in cost of goods sold | 3,001 |  |  | 1,919 |  |  | 5,485 |  |  | 4,077 |  |
| Research and development | 8,309 |  |  | 5,844 |  |  | 15,140 |  |  | 10,638 |  |
| Selling and marketing | 8,061 |  |  | 6,610 |  |  | 15,121 |  |  | 12,426 |  |
| General and administrative | 7,334 |  |  | 6,743 |  |  | 15,246 |  |  | 13,101 |  |
| Share-based compensation expense included in operating expense | 23,704 |  |  | 19,197 |  |  | 45,507 |  |  | 36,165 |  |
| Share-based compensation expense capitalized in inventory, net | (32) |  |  | 419 |  |  | (22) |  |  | 257 |  |
| Total share-based compensation expense | $ | 26,673 |  |  | $ | 21,535 |  |  | $ | 50,970 |  |  | $ | 40,499 |  |

[0000936395-22-000045:notes:148]
As of April 30, 2022, total unrecognized share-based compensation expense was approximately $218.8 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.64 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-22-000045:notes:149]
[same as prior period, unchanged from 0000936395-22-000029:notes:137]

[0000936395-22-000045:notes:150]
[same as prior period, unchanged from 0000936395-22-000029:notes:138]

[0000936395-22-000045:notes:151]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2022, equipment, building, furniture and fixtures, net, totaled $278.5 million, and operating ROU assets totaled $45.7 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of April 30, 2022, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-22-000045:notes:152]
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 46,386 |  |  | $ | — |  |  | $ | 42,570 |  |  | $ | — |  |  | $ | 88,956 |  |
| Goodwill | $ | 83,684 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 328,924 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 50,196 |  |  | $ | 50,196 |  |

[0000936395-22-000045:notes:153]
[same as prior period, unchanged from 0000936395-22-000029:notes:141]

[0000936395-22-000045:notes:154]
[same as prior period, unchanged from 0000936395-22-000029:notes:142]

[0000936395-22-000045:notes:155]
[same as prior period, unchanged from 0000936395-22-000029:notes:143]

[0000936395-22-000045:notes:156]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 152,769 |  |  | $ | 211,412 |  |  | $ | 286,894 |  |  | $ | 367,843 |  |
| Platform Software and Services | 43,556 |  |  | 36,506 |  |  | 93,052 |  |  | 64,166 |  |
| Blue Planet Automation Software and Services | (6,520) |  |  | 5,688 |  |  | (7,554) |  |  | 3,254 |  |
| Global Services | 52,652 |  |  | 48,567 |  |  | 105,843 |  |  | 92,060 |  |
| Total segment profit | 242,457 |  |  | 302,173 |  |  | 478,235 |  |  | 527,323 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 119,939 |  |  | 110,387 |  |  | 238,820 |  |  | 207,665 |  |
| General and administrative | 45,572 |  |  | 43,635 |  |  | 90,070 |  |  | 83,628 |  |
| Significant asset impairments and restructuring costs | 9,102 |  |  | 8,209 |  |  | 12,511 |  |  | 14,076 |  |
| Amortization of intangible assets | 8,920 |  |  | 6,019 |  |  | 17,838 |  |  | 11,929 |  |
| Acquisition and integration costs | 495 |  |  | 294 |  |  | 563 |  |  | 601 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (11,177) |  |  | (9,059) |  |  | (16,139) |  |  | (17,540) |  |
| Less: Provision for income taxes | 8,330 |  |  | 21,453 |  |  | 17,549 |  |  | 33,419 |  |
| Net income | $ | 38,922 |  |  | $ | 103,117 |  |  | $ | 84,745 |  |  | $ | 158,465 |  |

[0000936395-22-000045:notes:157]
[same as prior period, unchanged from 0000936395-22-000029:notes:145]

[0000936395-22-000045:notes:158]
[same as prior period, unchanged from 0000936395-22-000029:notes:146]

[0000936395-22-000045:notes:159]
|  | April 30,2022 |  | October 30,2021 |
| Canada | $ | 237,106 |  |  | $ | 240,968 |  |
| United States | 46,506 |  |  | 50,744 |  |
| Other International | 40,603 |  |  | 37,541 |  |
| Total | $ | 324,215 |  |  | $ | 329,253 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-22-000045:notes:160]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

[0000936395-22-000045:notes:161]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena could have received up to an aggregate CAD$57.6 million (approximately $44.8 million) in reimbursement from the three Canadian government entities for eligible costs over the period from February 20, 2017 through March 31, 2022. Amounts received under the agreements were subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of April 30, 2022, Ciena has recorded CAD$57.6 million (approximately $44.8 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.6 million ($5.2 million) was recorded in the first six months of fiscal 2022. As of April 30, 2022, amounts receivable from this grant were CAD$3.3 million ($2.6 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

[0000936395-22-000045:notes:162]
Tax Contingencies

[0000936395-22-000045:notes:163]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-22-000045:notes:164]
Litigation

[0000936395-22-000045:notes:165]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-22-000045:notes:166]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-22-000045:notes:167]
From the end of the second quarter of fiscal 2022 through June 3, 2022, Ciena repurchased an additional 1,161,320 shares of its common stock, for an aggregate purchase price of $60.0 million at an average price of $51.67 per share, inclusive of repurchases pending settlement. As of June 3, 2022, Ciena has repurchased an aggregate of 6,246,078 shares and has $603.0 million of authorized funds remaining under its stock repurchase program.
