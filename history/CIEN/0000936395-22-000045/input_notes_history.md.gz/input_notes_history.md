# CIEN note change history — 0000936395-22-000029 → 0000936395-22-000045


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena could have received up to an aggregate CAD$57.6 million (approximately $44.8 million) in reimbursement from the three Canadian government entities for eligible costs over the period from February 20, 2017 through March 31, 2022. Amounts received under the agreements were subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of April 30, 2022, Ciena has recorded CAD$57.6 million (approximately $44.8 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.6 million ($5.2 million) was recorded in the first six months of fiscal 2022. As of April 30, 2022, amounts receivable from this grant were CAD$3.3 million ($2.6 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.
  (was, 2022-03-09, similarity 0.8992):
[0000936395-22-000029:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of January 29, 2022, Ciena has recorded CAD$54.8 million (approximately $42.9 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.9 million ($3.0 million) was recorded in the first three months of fiscal 2022. As of January 29, 2022, amounts receivable from this grant were CAD$2.9 million ($2.2 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:2]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.
  (was, 2022-03-09, similarity 0.8427):
[0000936395-22-000029:note_history:2]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- added (2022-06-08):
[0000936395-22-000045:note_history:3]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

- added (2022-06-08):
[0000936395-22-000045:note_history:4]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- changed (2022-06-08):
[0000936395-22-000045:note_history:5]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.
  (was, 2022-03-09, similarity 0.98):
[0000936395-22-000029:note_history:5]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its condensed consolidated financial statements and related disclosures.

- removed (2022-06-08):
[0000936395-22-000029:note_history:6]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. Ciena elected to adopt ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

- removed (2022-06-08):
[0000936395-22-000029:note_history:7]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:8]
The net carrying value of the 2025 Term Loan was comprised of the following for the periods indicated (in thousands):
  (was, 2022-03-09, similarity 0.9655):
[0000936395-22-000029:note_history:8]
The net carrying value of Ciena’s 2025 Term Loan was comprised of the following for the periods indicated (in thousands):

- changed (2022-06-08):
[0000936395-22-000045:note_history:9]
|  |  | April 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,089) |  |  | $ | (2,037) |  |  | $ | 674,281 |  |  | $ | 677,285 |  |
  (was, 2022-03-09, similarity 0.7354):
[0000936395-22-000029:note_history:9]
|  |  | January 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,322) |  |  | $ | 394,678 |  |  |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.0 million as of April 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2022-03-09, similarity 0.9838):
[0000936395-22-000029:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.2 million as of January 29, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2022-06-08):
[0000936395-22-000045:note_history:11]
As of April 30, 2022, the estimated fair value of the 2025 Term Loan was $677.5 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-03-09, similarity 0.9814):
[0000936395-22-000029:note_history:11]
As of January 29, 2022, the estimated fair value of the 2025 Term Loan was $681.7 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2022-06-08):
[0000936395-22-000045:note_history:12]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as
  (was, 2022-03-09, similarity 0.7447):
[0000936395-22-000029:note_history:12]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

- added (2022-06-08):
[0000936395-22-000045:note_history:13]
described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

- changed (2022-06-08):
[0000936395-22-000045:note_history:14]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):
  (was, 2022-03-09, similarity 0.9954):
[0000936395-22-000029:note_history:14]
The net carrying value of the 2030 Notes was comprised of the following for the periods indicated (in thousands):

- added (2022-06-08):
[0000936395-22-000045:note_history:15]
|  |  | April 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,169) |  |  | $ | 394,831 |  |  |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:16]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.2 million as of April 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first six months of fiscal 2022.
  (was, 2022-03-09, similarity 0.9163):
[0000936395-22-000029:note_history:16]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Notes totaled $5.3 million as of January 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was minimal during the first three months of fiscal 2022.

- changed (2022-06-08):
[0000936395-22-000045:note_history:17]
As of April 30, 2022, the estimated fair value of the 2030 Notes was $363.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-03-09, similarity 0.9644):
[0000936395-22-000029:note_history:17]
As of January 29, 2022, the estimated fair value of the 2030 Notes was $395.5 million. Ciena’s 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2022-06-08):
[0000936395-22-000029:note_history:18]
|  |  | January 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 680,873 |  |  | $ | (1,170) |  |  | $ | (2,188) |  |  | $ | 677,515 |  |  | $ | 677,285 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:19]
|  | April 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 530,051 |  |  | $ | 1 |  |  | $ | (500) |  |  | $ | 529,552 |  |
| Included in long-term investments | 89,593 |  |  | — |  |  | (2,451) |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 1 |  |  | $ | (2,951) |  |  | $ | 616,694 |  |
  (was, 2022-03-09, similarity 0.9784):
[0000936395-22-000029:note_history:19]
|  | January 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 460,683 |  |  | $ | — |  |  | $ | (315) |  |  | $ | 460,368 |  |
| Included in long-term investments | 89,527 |  |  | — |  |  | (887) |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | — |  |  | $ | (1,202) |  |  | $ | 549,008 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:20]
SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2022-03-09, similarity 0.9959):
[0000936395-22-000029:note_history:20]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

- changed (2022-06-08):
[0000936395-22-000045:note_history:21]
|  | April 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 530,051 |  |  | $ | 1 |  |  | $ | (500) |  |  | $ | 529,552 |  |
| Included in long-term investments | 89,593 |  |  | — |  |  | (2,451) |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 1 |  |  | $ | (2,951) |  |  | $ | 616,694 |  |
  (was, 2022-03-09, similarity 0.9784):
[0000936395-22-000029:note_history:21]
|  | January 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 460,683 |  |  | $ | — |  |  | $ | (315) |  |  | $ | 460,368 |  |
| Included in long-term investments | 89,527 |  |  | — |  |  | (887) |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | — |  |  | $ | (1,202) |  |  | $ | 549,008 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:22]
The following table summarizes the final legal maturities of debt investments as of April 30, 2022 (in thousands):
  (was, 2022-03-09, similarity 0.9401):
[0000936395-22-000029:note_history:22]
The following table summarizes the final legal maturities of debt investments at January 29, 2022 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:23]
The net carrying value of the 2025 Term Loan was comprised of the following for the periods indicated (in thousands):
  (was, 2022-03-09, similarity 0.9655):
[0000936395-22-000029:note_history:23]
The net carrying value of Ciena’s 2025 Term Loan was comprised of the following for the periods indicated (in thousands):

- added (2022-06-08):
[0000936395-22-000045:note_history:24]
|  |  | April 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,089) |  |  | $ | (2,037) |  |  | $ | 674,281 |  |  | $ | 677,285 |  |

- removed (2022-06-08):
[0000936395-22-000029:note_history:25]
|  |  | January 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 680,873 |  |  | $ | (1,170) |  |  | $ | (2,188) |  |  | $ | 677,515 |  |  | $ | 677,285 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:26]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):
  (was, 2022-03-09, similarity 0.9954):
[0000936395-22-000029:note_history:26]
The net carrying value of the 2030 Notes was comprised of the following for the periods indicated (in thousands):

- changed (2022-06-08):
[0000936395-22-000045:note_history:27]
|  |  | April 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,169) |  |  | $ | 394,831 |  |  |  |
  (was, 2022-03-09, similarity 0.9781):
[0000936395-22-000029:note_history:27]
|  |  | January 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,322) |  |  | $ | 394,678 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-06-08):
[0000936395-22-000045:note_history:28]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | 773,728 |  |
| Services transferred over time | — |  |  | $ | 47,414 |  |  | $ | 12,845 |  |  | $ | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
  (was, 2022-03-09, similarity 0.9786):
[0000936395-22-000029:note_history:28]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:29]
|  | Quarter Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
  (was, 2022-03-09, similarity 0.9966):
[0000936395-22-000029:note_history:29]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

- added (2022-06-08):
[0000936395-22-000045:note_history:30]
|  | Six Months Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- added (2022-06-08):
[0000936395-22-000045:note_history:31]
|  | Six Months Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:32]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 700,840 |  |  | $ | 587,475 |  |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |
| EMEA |  | 145,106 |  |  | 155,054 |  |  | 295,891 |  |  | 310,472 |  |
| APAC |  | 103,281 |  |  | 91,398 |  |  | 201,795 |  |  | 196,499 |  |
| Total revenue by geographic distribution |  | $ | 949,227 |  |  | $ | 833,927 |  |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |
  (was, 2022-03-09, similarity 0.7517):
[0000936395-22-000029:note_history:32]
|  |  | Quarter Ended |  |  |
|  |  | January 29, |  | January 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  |  |
| EMEA |  | 150,785 |  |  | 155,418 |  |  |  |  |  |
| APAC |  | 98,514 |  |  | 105,101 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:33]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| AT&T | $ | 103,189 |  |  | 125,138 |  |  | 214,065 |  |  | 193,941 |  |
  (was, 2022-03-09, similarity 0.7619):
[0000936395-22-000029:note_history:33]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| AT&T | $ | 110,876 |  |  | n/a |  |  |  |  |

- removed (2022-06-08):
[0000936395-22-000029:note_history:34]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2022-06-08):
[0000936395-22-000045:note_history:35]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.

- changed (2022-06-08):
[0000936395-22-000045:note_history:36]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | 773,728 |  |
| Services transferred over time | — |  |  | $ | 47,414 |  |  | $ | 12,845 |  |  | $ | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
  (was, 2022-03-09, similarity 0.9786):
[0000936395-22-000029:note_history:36]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:37]
|  | Quarter Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
  (was, 2022-03-09, similarity 0.9966):
[0000936395-22-000029:note_history:37]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

- added (2022-06-08):
[0000936395-22-000045:note_history:38]
|  | Six Months Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- added (2022-06-08):
[0000936395-22-000045:note_history:39]
|  | Six Months Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:40]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 700,840 |  |  | $ | 587,475 |  |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |
| EMEA |  | 145,106 |  |  | 155,054 |  |  | 295,891 |  |  | 310,472 |  |
| APAC |  | 103,281 |  |  | 91,398 |  |  | 201,795 |  |  | 196,499 |  |
| Total revenue by geographic distribution |  | $ | 949,227 |  |  | $ | 833,927 |  |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |
  (was, 2022-03-09, similarity 0.7517):
[0000936395-22-000029:note_history:40]
|  |  | Quarter Ended |  |  |
|  |  | January 29, |  | January 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  |  |
| EMEA |  | 150,785 |  |  | 155,418 |  |  |  |  |  |
| APAC |  | 98,514 |  |  | 105,101 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  |  |

- added (2022-06-08):
[0000936395-22-000045:note_history:41]
Ciena’s revenue includes $642.2 million and $518.6 million of United States revenue for the second quarter of fiscal 2022 and 2021, respectively. For the six months ended April 30, 2022 and May 1, 2021, United States revenue was $1.2 billion and $1.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- changed (2022-06-08):
[0000936395-22-000045:note_history:42]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| AT&T | $ | 103,189 |  |  | 125,138 |  |  | 214,065 |  |  | 193,941 |  |
  (was, 2022-03-09, similarity 0.7619):
[0000936395-22-000029:note_history:42]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| AT&T | $ | 110,876 |  |  | n/a |  |  |  |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:43]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.
  (was, 2022-03-09, similarity 0.6154):
[0000936395-22-000029:note_history:43]
The customer identified above for the first quarter of fiscal 2022 purchased products and services from each of Ciena’s operating segments.

- changed (2022-06-08):
[0000936395-22-000045:note_history:44]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.
  (was, 2022-03-09, similarity 0.9353):
[0000936395-22-000029:note_history:44]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes sales of the Z-Series Packet-Optical Platform.

- changed (2022-06-08):
[0000936395-22-000045:note_history:45]
•Routing and Switching - includes the 3900 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta (as defined in Note 4 below) virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.
  (was, 2022-03-09, similarity 0.9704):
[0000936395-22-000029:note_history:45]
•Routing and Switching - includes the 3900 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

- changed (2022-06-08):
[0000936395-22-000045:note_history:46]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines described above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2022-03-09, similarity 0.994):
[0000936395-22-000029:note_history:46]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2022-06-08):
[0000936395-22-000045:note_history:47]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2022-03-09, similarity 0.9868):
[0000936395-22-000029:note_history:47]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2022-06-08):
[0000936395-22-000045:note_history:48]
|  |  | Balance at April 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 774,896 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 144,344 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 218,769 |  |  | $ | 175,464 |  |
  (was, 2022-03-09, similarity 0.9746):
[0000936395-22-000029:note_history:48]
|  |  | Balance at January 29, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 795,247 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 117,003 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 185,626 |  |  | $ | 175,464 |  |

- changed (2022-06-08):
[0000936395-22-000045:note_history:49]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $82.0 million and $78.0 million of revenue during the first six months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 30, 2022 and May 1, 2021.
  (was, 2022-03-09, similarity 0.9222):
[0000936395-22-000029:note_history:49]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $56.8 million and $46.4 million of revenue during the first three months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 29, 2022 and January 30, 2021.

- changed (2022-06-08):
[0000936395-22-000045:note_history:50]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $32.5 million and $27.6 million as of April 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $14.1 million and $10.7 million during the first six months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.
  (was, 2022-03-09, similarity 0.9723):
[0000936395-22-000029:note_history:50]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $29.6 million and $27.6 million as of January 29, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $7.0 million and $5.5 million during the first three months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

- changed (2022-06-08):
[0000936395-22-000045:note_history:51]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2022, the aggregate amount of RPO was $2.7 billion. As of April 30, 2022, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2022-03-09, similarity 0.9698):
[0000936395-22-000029:note_history:51]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 29, 2022, the aggregate amount of RPO was $2.4 billion. As of January 29, 2022, Ciena expects approximately 89% of the RPO to be recognized as revenue within the next 12 months.

- removed (2022-06-08):
[0000936395-22-000029:note_history:52]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line.

- removed (2022-06-08):
[0000936395-22-000029:note_history:53]
Ciena’s revenue includes $543.5 million and $439.4 million of United States revenue for the first quarter of fiscal 2022 and 2021, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- removed (2022-06-08):
[0000936395-22-000029:note_history:54]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-06-08):
[0000936395-22-000045:note_history:55]
SUBSEQUENT EVENTS
Stock Repurchase Program

- added (2022-06-08):
[0000936395-22-000045:note_history:56]
From the end of the second quarter of fiscal 2022 through June 3, 2022, Ciena repurchased an additional 1,161,320 shares of its common stock, for an aggregate purchase price of $60.0 million at an average price of $51.67 per share, inclusive of repurchases pending settlement. As of June 3, 2022, Ciena has repurchased an aggregate of 6,246,078 shares and has $603.0 million of authorized funds remaining under its stock repurchase program.

- removed (2022-06-08):
[0000936395-22-000029:note_history:57]
SUBSEQUENT EVENTSStock Repurchase Program and Accelerated Share Repurchase AgreementOn February 15, 2022, Ciena received delivery of the remaining 884,531 shares of common stock repurchased under the ASR Agreement, for a total delivery of approximately 3.6 million shares, calculated based on the average of the daily volume-weighted average prices of Ciena’s common stock of $69.78 for the period December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement.
