# CIEN MD&A — 0000936395-22-000045


## mdna

[0000936395-22-000045:mdna:1]
[same as prior period, unchanged from 0000936395-22-000029:mdna:1]

[0000936395-22-000045:mdna:2]
[same as prior period, unchanged from 0000936395-22-000029:mdna:2]

[0000936395-22-000045:mdna:3]
[same as prior period, unchanged from 0000936395-22-000029:mdna:3]

[0000936395-22-000045:mdna:4]
[same as prior period, unchanged from 0000936395-22-000029:mdna:4]

[0000936395-22-000045:mdna:5]
[same as prior period, unchanged from 0000936395-22-000029:mdna:5]

[0000936395-22-000045:mdna:6]
[same as prior period, unchanged from 0000936395-22-000029:mdna:6]

[0000936395-22-000045:mdna:7]
[same as prior period, unchanged from 0000936395-22-000029:mdna:12]

[0000936395-22-000045:mdna:8]
Since the second quarter of fiscal 2021, we have experienced unprecedented demand for our products and services. Our quarterly order volumes during this period have significantly exceeded our quarterly revenue and historical order volumes, with some concentration of orders among certain existing Webscale and North America-based service provider customers. As a result of order volume growth in recent periods, our backlog has grown from $2.2 billion at the end of fiscal 2021 to $4.1 billion at the end of the second quarter of fiscal 2022. We believe that we are benefiting from certain shifts in business and consumer behaviors, in part accelerated by the COVID-19 pandemic, which represent positive, long-term trends for our business. These include enterprise and consumer cloud network adoption, increasing demands on the network edge, and network operator focus on resilience and automation. We believe that some portion of our increased order volumes in recent periods also reflects customer acceleration of future orders due to the implementation of security of supply strategies, or spending that was delayed or deferred in prior years due to COVID-19 related impacts. We believe that many of the drivers of the recent increase in network operator demand are durable and represent long-term opportunities for our business. However, we do not expect the rate of orders growth experienced in recent periods to be sustainable in the long term and expect it to moderate over time, and backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to the demand environment.

[0000936395-22-000045:mdna:9]
[same as prior period, unchanged from 0000936395-22-000029:mdna:7]

[0000936395-22-000045:mdna:10]
In the face of extraordinary demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits and other electronic components used in most of our products, has experienced substantial constraint and disruption in recent periods. As a result, we have experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components. These conditions worsened for our business during the second quarter of fiscal 2022, in particular in relation to unexpected cancellation or delay of previously committed supply in two primary areas. First, several key optical suppliers were unable to meet their previous supply commitments due to constrained access to semiconductors. Second, several integrated circuit providers experienced a lack of supply for certain lower value, commodity parts, which we believe was exacerbated by government-mandated lockdowns in several cities in China in response to COVID-19.

[0000936395-22-000045:mdna:11]
These supply constraints are impacting our ability to meet customer demand and our anticipated level of revenue and growth in fiscal 2022. At the same time, increased costs associated with procuring and transporting our equipment, including supply premiums, expediting fees and freight and logistics have impacted our gross margin and profitability. We expect these constrained supply conditions to increase our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. We believe these supply chain challenges and their adverse impact on our business and financial results will persist for the foreseeable future, and specifically, we expect these conditions to adversely impact both our revenue and our profitability during the remainder of fiscal 2022.

[0000936395-22-000045:mdna:12]
In response to these supply constraints, we have implemented mitigation strategies and increased our inventory purchases. In some cases, we have incurred higher costs to secure available component inventory, have extended the duration of our purchase commitments, or placed non-cancellable, advanced orders with or through suppliers, particularly for long lead time components. Beginning in the second half of fiscal 2021, we started placing significant, advanced orders for supply of certain long lead time components to address our expected strong customer demand for fiscal 2022 and the then emerging supply chain

[0000936395-22-000045:mdna:13]
challenges. As of April 30, 2022 we had $1.8 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory, including approximately $1.2 billion in advance orders made to address supply shortages. We have also been expanding our manufacturing capacity and have been accumulating raw materials inventory of components that are not as scarce, so we are prepared to produce finished goods more quickly when supply constraints ease.  These mitigation steps introduce additional costs and risk. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain.

[0000936395-22-000045:mdna:14]
Impact of Global Events on our Business and Operations

[0000936395-22-000045:mdna:15]
COVID-19 Pandemic. The impact of the COVID-19 pandemic and countermeasures taken to contain its spread remain dynamic. We continue to monitor the situation and actively assess further implications for our business, supply chain, fulfillment operations and customer demand. For example, we have reopened a significant number of our offices globally as of the end of the second quarter of fiscal 2022. We continue to take meaningful precautions in accordance with relevant guidelines to protect the health and safety of our employees. Variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. If the COVID-19 pandemic or its adverse effects, including the effects of recent government-mandated lockdowns in several cities in China, become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected. For additional information on the impact of COVID-19 upon our business, operations and financial results, and the steps that we have taken in response, see our 2021 Annual Report.

[0000936395-22-000045:mdna:16]
Russia and Ukraine Conflict. In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions, which could damage or disrupt international commerce and the global economy. We are complying with a broad range of United States and international sanctions and export control requirements imposed on Russia and, on March 7, 2022, we announced our decision to immediately suspend our business operations in Russia. Due to the limited amount of business that we have conducted in Russia historically, this decision has not materially impacted our results of operations for the second quarter of fiscal 2022 and we do not expect it to materially impact our results of operations going forward. See Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on the impact of suspending our business operations in Russia.

[0000936395-22-000045:mdna:17]
[same as prior period, unchanged from 0000936395-22-000029:mdna:16]

[0000936395-22-000045:mdna:18]
Xelic Acquisition. On March 9, 2022, we acquired Xelic, Inc. (“Xelic”), a provider and developer of field-programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores, to enhance development of our WaveLogic® coherent modem technology. See Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on this acquisition and the related accounting.

[0000936395-22-000045:mdna:19]
Stock Repurchase Program and Accelerated Share Repurchase Agreement. On December 9, 2021, we announced that our Board of Directors had authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety our previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement (the “ASR Agreement”) for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During the second quarter of fiscal 2022, we repurchased $87.0 million of our common stock under the stock repurchase program, and we had $663.0 million remaining under the current repurchase authorization as of April 30, 2022. The amount and timing of any further repurchases under our stock purchase program are subject to a variety of factors, including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 19 and 23 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on our stock repurchase program.

[0000936395-22-000045:mdna:20]
[same as prior period, unchanged from 0000936395-22-000029:mdna:21]

[0000936395-22-000045:mdna:21]
[same as prior period, unchanged from 0000936395-22-000029:mdna:22]

[0000936395-22-000045:mdna:22]
[same as prior period, unchanged from 0000936395-22-000029:mdna:23]

[0000936395-22-000045:mdna:23]
[same as prior period, unchanged from 0000936395-22-000029:mdna:24]

[0000936395-22-000045:mdna:24]
[same as prior period, unchanged from 0000936395-22-000029:mdna:25]

[0000936395-22-000045:mdna:25]
[same as prior period, unchanged from 0000936395-22-000029:mdna:26]

[0000936395-22-000045:mdna:26]
Approximately 14.0% of our revenue was non-U.S. Dollar-denominated during both the second quarter and first six months of fiscal 2022, primarily including sales in Euros, Canadian Dollars and British Pounds. During the second quarter of fiscal 2022, as compared to the second quarter of fiscal 2021, and during the first six months of fiscal 2022, as compared to the first six months of fiscal 2021, the U.S. Dollar primarily strengthened against these currencies. Consequently, our revenue for the second quarter and first six months of fiscal 2022 reported in U.S. Dollars was adversely impacted by approximately $5.0 million, or 0.5%, and $8.2 million, or 0.5%, respectively.

[0000936395-22-000045:mdna:27]
[same as prior period, unchanged from 0000936395-22-000029:mdna:28]

[0000936395-22-000045:mdna:28]
[same as prior period, unchanged from 0000936395-22-000029:mdna:29]

[0000936395-22-000045:mdna:29]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | 573,657 |  |  |  |  | 9.0 | % |  | $ | 1,166,230 |  |  | $ | 1,085,981 |  |  |  |  | 7.4 | % |
| %** | 65.8 | % |  | 68.8 | % |  |  |  |  |  | 65.0 | % |  | 68.2 | % |  |  |  |  |
| Routing and Switching | 109,186 |  |  | 63,628 |  |  |  |  | 71.6 | % |  | 194,896 |  |  | 127,934 |  |  |  |  | 52.3 | % |
| %** | 11.5 | % |  | 7.6 | % |  |  |  |  |  | 10.9 | % |  | 8.0 | % |  |  |  |  |
| Total Networking Platforms | 734,480 |  |  | 637,285 |  |  |  |  | 15.3 | % |  | 1,361,126 |  |  | 1,213,915 |  |  |  |  | 12.1 | % |
| %** | 77.3 | % |  | 76.4 | % |  |  |  |  |  | 75.9 | % |  | 76.2 | % |  |  |  |  |
| Platform Software and Services | 69,157 |  |  | 56,688 |  |  |  |  | 22.0 | % |  | 142,074 |  |  | 106,527 |  |  |  |  | 33.4 | % |
| %** | 7.3 | % |  | 6.8 | % |  |  |  |  |  | 7.9 | % |  | 6.7 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 16,881 |  |  | 23,958 |  |  |  |  | (29.5) | % |  | 37,992 |  |  | 40,892 |  |  |  |  | (7.1) | % |
| %** | 1.8 | % |  | 2.9 | % |  |  |  |  |  | 2.1 | % |  | 2.6 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 74,019 |  |  | 70,418 |  |  |  |  | 5.1 | % |  | 146,509 |  |  | 138,049 |  |  |  |  | 6.1 | % |
| %** | 7.8 | % |  | 8.4 | % |  |  |  |  |  | 8.2 | % |  | 8.7 | % |  |  |  |  |
| Installation and Deployment | 41,430 |  |  | 37,999 |  |  |  |  | 9.0 | % |  | 81,800 |  |  | 77,610 |  |  |  |  | 5.4 | % |
| %** | 4.4 | % |  | 4.6 | % |  |  |  |  |  | 4.6 | % |  | 4.9 | % |  |  |  |  |
| Consulting and Network Design | 13,260 |  |  | 7,579 |  |  |  |  | 75.0 | % |  | 24,169 |  |  | 14,064 |  |  |  |  | 71.9 | % |
| %** | 1.4 | % |  | 0.9 | % |  |  |  |  |  | 1.3 | % |  | 0.9 | % |  |  |  |  |
| Total Global Services | 128,709 |  |  | 115,996 |  |  |  |  | 11.0 | % |  | 252,478 |  |  | 229,723 |  |  |  |  | 9.9 | % |
| %** | 13.6 | % |  | 13.9 | % |  |  |  |  |  | 14.1 | % |  | 14.5 | % |  |  |  |  |
| Total revenue | $ | 949,227 |  |  | $ | 833,927 |  |  |  |  | 13.8 | % |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |  |  |  | 12.7 | % |

[0000936395-22-000045:mdna:30]
[same as prior period, unchanged from 0000936395-22-000029:mdna:31]

[0000936395-22-000045:mdna:31]
[same as prior period, unchanged from 0000936395-22-000029:mdna:32]

[0000936395-22-000045:mdna:32]
[same as prior period, unchanged from 0000936395-22-000029:mdna:33]

[0000936395-22-000045:mdna:33]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:34]
•Networking Platforms segment revenue increased by $97.2 million, reflecting product line sales increases of $51.6 million of our Converged Packet Optical products and $45.6 million of our Routing and Switching products.

[0000936395-22-000045:mdna:35]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $44.4 million of our Waveserver® products to communication service providers and $23.2 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers. These sales increases were partially offset primarily by a sales decrease of $8.8 million of our 6500 Packet-Optical Platform, primarily to cable and multiservice operators and communication service providers.

[0000936395-22-000045:mdna:36]
◦Routing and Switching sales increased, primarily reflecting a sales increase of $22.6 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. Sales also include $25.4 million of our Virtualization Edge software, which was acquired in the acquisition of the Vyatta Software Technology (“Vyatta”) and its virtual routing and switching technology in the first quarter of fiscal 2022. These sales increases were partially offset by a sales decrease of $7.0 million of our 8700 Packetwave Platform, primarily to communication service providers.

[0000936395-22-000045:mdna:37]
•Platform Software and Services segment revenue increased by $12.5 million, reflecting sales increases of $11.2 million in software services, primarily to communication service providers, and $1.3 million in sales of software platforms.

[0000936395-22-000045:mdna:38]
•Blue Planet Automation Software and Services segment revenue decreased by $7.1 million, primarily reflecting a sales decrease of $8.6 million of our automation software platforms due to extended project completion timeframes, partially offset by a sales increase of $1.5 million in software-related services.

[0000936395-22-000045:mdna:39]
•Global Services segment revenue increased by $12.7 million, primarily reflecting sales increases of $5.7 million of our consulting and network design services, $3.6 million of our maintenance support and training services and $3.4 million of our installation and deployment services.

[0000936395-22-000045:mdna:40]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:41]
•Networking Platforms segment revenue increased by $147.2 million, reflecting product line sales increases of $80.2 million of our Converged Packet Optical products and $67.0 million of our Routing and Switching products.

[0000936395-22-000045:mdna:42]
◦Converged Packet Optical sales increased, primarily reflecting increases of $56.5 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-scale providers, and $41.3 million of our 6500 RLS products, primarily to Web-scale providers. These sales increases were partially offset by sales decreases of $9.0 million of our 5430 Reconfigurable Switching Systems and $8.8 million of our Z-Series Packet-Optical Platform, each primarily to communications service providers.

[0000936395-22-000045:mdna:43]
◦Routing and Switching sales increased, primarily reflecting a sales increase of $36.6 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. Sales also include $37.6 million of our Virtualization Edge software, which was acquired in the acquisition of Vyatta’s virtual routing and switching technology in the first quarter of fiscal 2022. These sales increases were partially offset by a sales decrease of $8.9 million of our 8700 Packetwave Platform primarily to communication service providers.

[0000936395-22-000045:mdna:44]
•Platform Software and Services segment revenue increased by $35.5 million, reflecting increases of $20.4 million in software services and $15.1 million in sales of software platforms.

[0000936395-22-000045:mdna:45]
•Blue Planet Automation Software and Services segment revenue decreased by $2.9 million, reflecting a decrease of $4.7 million in sales of automation software platforms due to extended project completion timeframes, offset by a sales increase of $1.8 million in software-related services.

[0000936395-22-000045:mdna:46]
•Global Services segment revenue increased by $22.8 million, primarily reflecting sales increases of $10.1 million of our consulting and network design services, $8.5 million of our maintenance support and training and $4.2 million of our installation and deployment services.

[0000936395-22-000045:mdna:47]
[same as prior period, unchanged from 0000936395-22-000029:mdna:41]

[0000936395-22-000045:mdna:48]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for the quarter and six months ended April 30, 2022 was primarily driven by increased sales in the United States. The increase in our APAC region revenue for the quarter and six months ended April 30, 2022 was primarily driven by

[0000936395-22-000045:mdna:49]
increased sales in Australia and New Zealand, partially offset by decreased sales in India. The decrease in our EMEA region revenue for the quarter ended April 30, 2022 was primarily driven by decreased sales in the United Kingdom and Russia, partially offset by increased sales in the Netherlands. The decrease in our EMEA region revenue for the six months ended April 30, 2022 was primarily driven by decreased sales in the Netherlands and Russia. Our Russia operations were suspended in March 2022.

[0000936395-22-000045:mdna:50]
[same as prior period, unchanged from 0000936395-22-000029:mdna:43]

[0000936395-22-000045:mdna:51]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Americas | $ | 700,840 |  |  | $ | 587,475 |  |  |  |  | 19.3 | % |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |  |  |  | 19.5 | % |
| %** | 73.8 | % |  | 70.4 | % |  |  |  |  |  | 72.3 | % |  | 68.1 | % |  |  |  |  |
| EMEA | 145,106 |  |  | 155,054 |  |  |  |  | (6.4) | % |  | 295,891 |  |  | 310,472 |  |  |  |  | (4.7) | % |
| %** | 15.3 | % |  | 18.6 | % |  |  |  |  |  | 16.5 | % |  | 19.5 | % |  |  |  |  |
| APAC | 103,281 |  |  | 91,398 |  |  |  |  | 13.0 | % |  | 201,795 |  |  | 196,499 |  |  |  |  | 2.7 | % |
| %** | 10.9 | % |  | 11.0 | % |  |  |  |  |  | 11.2 | % |  | 12.4 | % |  |  |  |  |
| Total | $ | 949,227 |  |  | $ | 833,927 |  |  |  |  | 13.8 | % |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |  |  |  | 12.7 | % |

[0000936395-22-000045:mdna:52]
[same as prior period, unchanged from 0000936395-22-000029:mdna:45]

[0000936395-22-000045:mdna:53]
[same as prior period, unchanged from 0000936395-22-000029:mdna:46]

[0000936395-22-000045:mdna:54]
[same as prior period, unchanged from 0000936395-22-000029:mdna:47]

[0000936395-22-000045:mdna:55]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:56]
•Americas revenue increased by $113.4 million, reflecting sales increases of $94.2 million within our Networking Platforms segment, $12.3 million within our Global Services segment, and $8.9 million within our Platform Software and Services segment. These sale increases were offset by a sales decrease of $1.9 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects product line sales increases of $48.4 million of our Routing and Switching products and $45.8 million of our Converged Packet Optical products. The increase within our Routing and Switching product line primarily reflects a sales increase of $24.5 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communication service providers. Also included in the Routing and Switching product line were sales of $25.4 million of our Virtualization Edge software, which was acquired in the acquisition of Vyatta’s virtual routing and switching technology in the first quarter of fiscal 2022. The increase within our Converged Packet Optical product line was primarily related to a sales increase of $51.3 million of our Waveserver® products primarily to communication service providers.

[0000936395-22-000045:mdna:57]
•EMEA revenue decreased by $9.9 million, reflecting sales decreases of $5.4 million within our Networking Platforms segment, $4.9 million within our Blue Planet Automation Software and Services segment, and $1.6 million within our Global Services segment. These sales decreases were offset by a sales increase of $2.0 million within our Platform Software and Services segment. Sales decreased by $4.0 million from customers in Russia.

[0000936395-22-000045:mdna:58]
•APAC revenue increased by $11.9 million, primarily reflecting sales increases of $8.5 million within our Networking Platforms segment, $2.0 million within our Global Services segment and $1.7 million within our Platform Software and Services segment.

[0000936395-22-000045:mdna:59]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:60]
•Americas revenue increased by $211.9 million, reflecting sales increases of $160.8 million within our Networking Platforms segment, $26.7 million within our Platform Software and Services segment, $21.4 million within our Global Services segment, and $3.0 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $90.0 million of Converged Packet Optical products and $70.8 million of Routing and Switching products. Our Converged Packet Optical revenue increase primarily reflects sales increases of $52.0 million of our 6500 Packet-Optical Platform, $30.7 million of our Waveserver® products, and $23.6 million of our 6500 Reconfigurable Line System (RLS) products, partially offset by a sales decrease of $10.6 million of our 5430 Reconfigurable Switching Systems. Included in the Routing and Switching product line were sales of $37.6 million of our Virtualization Edge software, which was acquired in the

[0000936395-22-000045:mdna:61]
acquisition of Vyatta’s virtual routing and switching technology in the first quarter of fiscal 2022, and a sales increase of $38.1 million of our 3000 and 5000 families of service delivery and aggregation switches.

[0000936395-22-000045:mdna:62]
•EMEA revenue decreased by $14.6 million, reflecting decreases of $13.6 million within our Networking Platforms segment, $4.1 million within our Blue Planet Automation Software and Services segment and $3.0 million within our Global Services segment. These sales decreases were offset by a sales increase of $6.1 million within our Platform Software and Services segment. Sales decreased by $6.8 million from customers in Russia.

[0000936395-22-000045:mdna:63]
•APAC revenue increased by $5.3 million, primarily reflecting increases of $4.3 million within our Global Services segment, and $2.8 million within our Platform Software and Services segment. These sales increases were offset by a sales decrease of $1.8 million within our Blue Planet Automation Software and Services segment. Sales within our Networking Platforms segment remained relatively unchanged.

[0000936395-22-000045:mdna:64]
[same as prior period, unchanged from 0000936395-22-000029:mdna:52]

[0000936395-22-000045:mdna:65]
There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. The component elements that comprise our product cost of goods sold and services costs of goods sold, and certain factors that can cause gross margin to fluctuate, are described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2021 Annual Report.

[0000936395-22-000045:mdna:66]
Canada Emergency Wage Subsidy (“CEWS”) benefits, recorded in the particular line item within cost of goods sold in our Condensed Consolidated Statement of Operations to which the grant activity relates, were $6.8 million in the first six months of fiscal 2021, net of certain fees. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-22-000045:mdna:67]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Total revenue | $ | 949,227 |  |  | $ | 833,927 |  |  |  |  | 13.8 | % |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |  |  |  | 12.7 | % |
| Total cost of goods sold | 547,446 |  |  | 421,508 |  |  |  |  | 29.9 | % |  | 1,007,702 |  |  | 820,747 |  |  |  |  | 22.8 | % |
| Gross profit | $ | 401,781 |  |  | $ | 412,419 |  |  |  |  | (2.6) | % |  | $ | 785,968 |  |  | $ | 770,310 |  |  |  |  | 2.0 | % |
| %** | 42.3 | % |  | 49.5 | % |  |  |  |  |  | 43.8 | % |  | 48.4 | % |  |  |  |  |

[0000936395-22-000045:mdna:68]
[same as prior period, unchanged from 0000936395-22-000029:mdna:56]

[0000936395-22-000045:mdna:69]
[same as prior period, unchanged from 0000936395-22-000029:mdna:57]

[0000936395-22-000045:mdna:70]
**     Denotes % of total revenue

[0000936395-22-000045:mdna:71]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Product revenue | $ | 759,948 |  |  | $ | 670,043 |  |  |  |  | 13.4 | % |  | $ | 1,424,955 |  |  | $ | 1,267,263 |  |  |  |  | 12.4 | % |
| Product cost of goods sold | 452,057 |  |  | 339,601 |  |  |  |  | 33.1 | % |  | 824,622 |  |  | 654,699 |  |  |  |  | 26.0 | % |
| Product gross profit | $ | 307,891 |  |  | $ | 330,442 |  |  |  |  | (6.8) | % |  | $ | 600,333 |  |  | $ | 612,564 |  |  |  |  | (2.0) | % |
| %** | 40.5 | % |  | 49.3 | % |  |  |  |  |  | 42.1 | % |  | 48.3 | % |  |  |  |  |

[0000936395-22-000045:mdna:72]
[same as prior period, unchanged from 0000936395-22-000029:mdna:60]

[0000936395-22-000045:mdna:73]
[same as prior period, unchanged from 0000936395-22-000029:mdna:61]

[0000936395-22-000045:mdna:74]
**     Denotes % of product revenue

[0000936395-22-000045:mdna:75]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Services revenue | $ | 189,279 |  |  | $ | 163,884 |  |  |  |  | 15.5 | % |  | $ | 368,715 |  |  | $ | 323,794 |  |  |  |  | 13.9 | % |
| Services cost of goods sold | 95,389 |  |  | 81,907 |  |  |  |  | 16.5 | % |  | 183,080 |  |  | 166,048 |  |  |  |  | 10.3 | % |
| Services gross profit | $ | 93,890 |  |  | $ | 81,977 |  |  |  |  | 14.5 | % |  | $ | 185,635 |  |  | $ | 157,746 |  |  |  |  | 17.7 | % |
| % ** | 49.6 | % |  | 50.0 | % |  |  |  |  |  | 50.3 | % |  | 48.7 | % |  |  |  |  |

[0000936395-22-000045:mdna:76]
[same as prior period, unchanged from 0000936395-22-000029:mdna:64]

[0000936395-22-000045:mdna:77]
[same as prior period, unchanged from 0000936395-22-000029:mdna:65]

[0000936395-22-000045:mdna:78]
**     Denotes % of services revenue

[0000936395-22-000045:mdna:79]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:80]
•Gross profit decreased by $10.6 million. Gross margin decreased by 720 basis points, primarily due to increased costs of components resulting from global supply chain shortages and market-based price compression. The decrease also reflects the effect of a $6.8 million benefit received in the second quarter of fiscal 2021 from the now-expired CEWS program. As described in “Overview” above, we expect the current constrained supply environment, including increased component and logistics costs, to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2022. We believe that these supply chain challenges and their adverse impact on our business and financial results will persist for the foreseeable future and at least through the remainder of fiscal 2022.

[0000936395-22-000045:mdna:81]
•Gross profit on products decreased by $22.6 million. Product gross margin decreased by 880 basis points, primarily due to the increased costs of components resulting from global supply chain shortages and market-based price compression. The decrease also reflects the effect of a $4.2 million benefit received in the second quarter of fiscal 2021 from the now-expired CEWS program.

[0000936395-22-000045:mdna:82]
•Gross profit on services increased by $11.9 million. Services gross margin decreased by 40 basis points, reflecting the effect of a $2.6 million benefit recorded in the second quarter of fiscal 2021 from the now-expired CEWS program. Excluding the effect of the CEWS program, services margin improved due to higher margin on consulting and professional services and installation and deployment services.

[0000936395-22-000045:mdna:83]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:84]
•Gross profit increased by $15.7 million. Gross margin decreased by 460 basis points, primarily due to increased costs of components resulting from global supply chain shortages and market-based price compression. The decrease also reflects the effect of a $6.8 million benefit received in the second quarter of fiscal 2021 from the now-expired CEWS program. As described in “Overview” above, we expect the current market shortage for semiconductor components and constrained supply environment to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2022. We believe that these supply chain challenges and their adverse impact on our business and financial results will persist for the foreseeable future and at least through the remainder of fiscal 2022.

[0000936395-22-000045:mdna:85]
•Gross profit on products decreased by $12.2 million. Product gross margin decreased by 620 basis points, primarily due to increased costs of components resulting from global supply chain shortages and market-based price compression. The decrease also reflects the effect of a $4.2 million benefit received in the second quarter of fiscal 2021 from the now-expired CEWS program.

[0000936395-22-000045:mdna:86]
•Gross profit on services increased by $27.9 million. Services gross margin increased by 160 basis points, due to higher margin on consulting and professional services and installation and deployment services. This increase offset the effect of a $2.6 million benefit from the now-expired CEWS program recorded in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:87]
[same as prior period, unchanged from 0000936395-22-000029:mdna:71]

[0000936395-22-000045:mdna:88]
[same as prior period, unchanged from 0000936395-22-000029:mdna:72]

[0000936395-22-000045:mdna:89]
Approximately 51.0% of our operating expense was non-U.S. Dollar-denominated during the second quarter and first six months of fiscal 2022, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the second quarter of fiscal 2022, as compared to the second quarter of fiscal 2021, and the first six months of fiscal 2022, as compared to the first six months of fiscal 2021, the U.S. Dollar primarily strengthened against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $4.1 million, or 1.2%, and $5.5 million, or 0.8%, respectively.

[0000936395-22-000045:mdna:90]
CEWS Program Benefits

[0000936395-22-000045:mdna:91]
In the first six months of fiscal 2021, we recorded CEWS benefits of $33.6 million, net of certain fees, related to the particular line item within operating expense in our Condensed Consolidated Statement of Operations to which the grant activity related. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000045:mdna:92]
[same as prior period, unchanged from 0000936395-22-000029:mdna:74]

[0000936395-22-000045:mdna:93]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Research and development | $ | 159,324 |  |  | $ | 110,246 |  |  |  |  | 44.5 | % |  | $ | 307,733 |  |  | $ | 242,987 |  |  |  |  | 26.6 | % |
| %** | 16.8 | % |  | 13.2 | % |  |  |  |  |  | 17.2 | % |  | 15.3 | % |  |  |  |  |
| Selling and marketing | 119,939 |  |  | 110,387 |  |  |  |  | 8.7 | % |  | 238,820 |  |  | 207,665 |  |  |  |  | 15.0 | % |
| %** | 12.6 | % |  | 13.2 | % |  |  |  |  |  | 13.3 | % |  | 13.1 | % |  |  |  |  |
| General and administrative | 45,572 |  |  | 43,635 |  |  |  |  | 4.4 | % |  | 90,070 |  |  | 83,628 |  |  |  |  | 7.7 | % |
| %** | 4.8 | % |  | 5.2 | % |  |  |  |  |  | 5.0 | % |  | 5.3 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 9,102 |  |  | 8,209 |  |  |  |  | 10.9 | % |  | 12,511 |  |  | 14,076 |  |  |  |  | (11.1) | % |
| %** | 1.0 | % |  | 1.0 | % |  |  |  |  |  | 0.7 | % |  | 0.9 | % |  |  |  |  |
| Amortization of intangible assets | 8,920 |  |  | 6,019 |  |  |  |  | 48.2 | % |  | 17,838 |  |  | 11,929 |  |  |  |  | 49.5 | % |
| %** | 0.9 | % |  | 0.7 | % |  |  |  |  |  | 1.0 | % |  | 0.7 | % |  |  |  |  |
| Acquisition and integration costs | 495 |  |  | 294 |  |  |  |  | 68.4 | % |  | 563 |  |  | 601 |  |  |  |  | (6.3) | % |
| %** | 0.1 | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 343,352 |  |  | $ | 278,790 |  |  |  |  | 23.2 | % |  | $ | 667,535 |  |  | $ | 560,886 |  |  |  |  | 19.0 | % |
| %** | 36.2 | % |  | 33.4 | % |  |  |  |  |  | 37.2 | % |  | 35.3 | % |  |  |  |  |

[0000936395-22-000045:mdna:94]
[same as prior period, unchanged from 0000936395-22-000029:mdna:76]

[0000936395-22-000045:mdna:95]
[same as prior period, unchanged from 0000936395-22-000029:mdna:77]

[0000936395-22-000045:mdna:96]
[same as prior period, unchanged from 0000936395-22-000029:mdna:58]

[0000936395-22-000045:mdna:97]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:98]
•Research and development expense benefited from $2.2 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Indian Rupee and Canadian Dollar. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $49.1 million. This increase primarily reflects a $28.9 million benefit from the now-expired CEWS program recorded in the second quarter of fiscal 2021 and increases in employee headcount and related compensation costs, professional services and technology and related costs.

[0000936395-22-000045:mdna:99]
•Selling and marketing expense benefited from $1.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $9.6 million. This increase primarily reflects an increase in employee headcount and related compensation costs, travel and entertainment costs and a $2.6 million benefit from the now-expired CEWS program recorded in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:100]
•General and administrative expense increased by $1.9 million. This increase primarily reflects increases in employee headcount and related compensation costs and professional services and a $2.2 million benefit from the now-expired CEWS program recorded in the second quarter of fiscal 2021, partially offset by reduced legal costs.

[0000936395-22-000045:mdna:101]
•Significant asset impairments and restructuring costs slightly increased by $0.9 million, reflecting an impairment charge of $4.1 million due to our suspended operations in Russia partially offset by reduced costs associated with actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-22-000045:mdna:102]
•Amortization of intangible assets increased by $2.9 million due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic in the second quarter of fiscal 2022.

[0000936395-22-000045:mdna:103]
•Acquisition and integration costs remained relatively unchanged.

[0000936395-22-000045:mdna:104]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:105]
•Research and development expense benefited from $2.3 million as a result of foreign exchange rates, net of hedging, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $64.7 million. This increase primarily reflects the effect of a $28.9 million benefit received from the now-expired CEWS program

[0000936395-22-000045:mdna:106]
recorded in the second quarter of fiscal 2021 and increases in employee headcount and related compensation costs, professional services and technology and related costs.

[0000936395-22-000045:mdna:107]
•Selling and marketing expense benefited from $2.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $31.2 million. This increase primarily reflects an increase in compensation costs and travel and entertainment costs and the effect of a $2.6 million benefit received from the now-expired CEWS program recorded in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:108]
•General and administrative expense increased by $6.4 million. This increase primarily reflects increases in employee headcount and related compensation costs and professional services and the effect of a $2.2 million benefit received from the now-expired CEWS program recorded in the second quarter of fiscal 2021, partially offset by reduced legal costs.

[0000936395-22-000045:mdna:109]
•Significant asset impairments and restructuring costs decreased by $1.6 million, reflecting reduced costs associated with actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense, offset by a $4.1 million impairment charge due to our suspended operations in Russia.

[0000936395-22-000045:mdna:110]
•Amortization of intangible assets increased by $5.9 million due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic during the second quarter of fiscal 2022.

[0000936395-22-000045:mdna:111]
•Acquisition and integration costs remained relatively unchanged.

[0000936395-22-000045:mdna:112]
[same as prior period, unchanged from 0000936395-22-000029:mdna:86]

[0000936395-22-000045:mdna:113]
[same as prior period, unchanged from 0000936395-22-000029:mdna:87]

[0000936395-22-000045:mdna:114]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Interest and other income (loss), net | $ | 808 |  |  | $ | (1,274) |  |  |  |  | 163.4 | % |  | $ | 4,494 |  |  | $ | (2,395) |  |  |  |  | 287.6 | % |
| %** | 0.1 | % |  | (0.2) | % |  |  |  |  |  | 0.3 | % |  | (0.2) | % |  |  |  |  |
| Interest expense | $ | 11,985 |  |  | $ | 7,785 |  |  |  |  | 53.9 | % |  | $ | 20,633 |  |  | $ | 15,145 |  |  |  |  | 36.2 | % |
| %** | 1.3 | % |  | 0.9 | % |  |  |  |  |  | 1.2 | % |  | 1.0 | % |  |  |  |  |
| Provision for income taxes | $ | 8,330 |  |  | $ | 21,453 |  |  |  |  | (61.2) | % |  | $ | 17,549 |  |  | $ | 33,419 |  |  |  |  | (47.5) | % |
| %** | 0.9 | % |  | 2.6 | % |  |  |  |  |  | 1.0 | % |  | 2.1 | % |  |  |  |  |

[0000936395-22-000045:mdna:115]
[same as prior period, unchanged from 0000936395-22-000029:mdna:89]

[0000936395-22-000045:mdna:116]
[same as prior period, unchanged from 0000936395-22-000029:mdna:90]

[0000936395-22-000045:mdna:117]
[same as prior period, unchanged from 0000936395-22-000029:mdna:78]

[0000936395-22-000045:mdna:118]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:119]
•Interest and other income (loss), net primarily reflects the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-22-000045:mdna:120]
•Interest expense increased primarily due to additional outstanding indebtedness, including our 4.00% senior notes due 2030 (the “2030 Notes”) issued in the first quarter of fiscal 2022.

[0000936395-22-000045:mdna:121]
•Provision for income taxes decreased by $13.1 million due to a decrease in pre-tax income for the second quarter of fiscal 2022. The effective tax rate for the second quarter of fiscal 2022 was higher compared to the second quarter of fiscal 2021, primarily due to a higher foreign tax rate.

[0000936395-22-000045:mdna:122]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:123]
•Interest and other income (loss), net primarily reflects a favorable adjustment to the carrying value of a cost method equity investment and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-22-000045:mdna:124]
•Interest expense increased primarily due to additional outstanding indebtedness, including the 2030 Notes.

[0000936395-22-000045:mdna:125]
•Provision for income taxes decreased by $15.9 million due to a decrease in pre-tax income for the first six months of fiscal 2022. The effective tax rate for the first six months of fiscal 2022 was lower compared to the first six months of fiscal 2021, primarily due to a lower foreign tax rate in fiscal 2022.

[0000936395-22-000045:mdna:126]
[same as prior period, unchanged from 0000936395-22-000029:mdna:96]

[0000936395-22-000045:mdna:127]
[same as prior period, unchanged from 0000936395-22-000029:mdna:97]

[0000936395-22-000045:mdna:128]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |  | April 30, 2022 |  | May 1, 2021 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 152,769 |  |  | $ | 211,412 |  |  |  |  | (27.7) | % |  | $ | 286,894 |  |  | $ | 367,843 |  |  |  |  | (22.0) | % |
| Platform Software and Services | $ | 43,556 |  |  | $ | 36,506 |  |  |  |  | 19.3 | % |  | $ | 93,052 |  |  | $ | 64,166 |  |  |  |  | 45.0 | % |
| Blue Planet Automation Software and Services | $ | (6,520) |  |  | $ | 5,688 |  |  |  |  | (214.6) | % |  | $ | (7,554) |  |  | $ | 3,254 |  |  |  |  | (332.1) | % |
| Global Services | $ | 52,652 |  |  | $ | 48,567 |  |  |  |  | 8.4 | % |  | $ | 105,843 |  |  | $ | 92,060 |  |  |  |  | 15.0 | % |

[0000936395-22-000045:mdna:129]
[same as prior period, unchanged from 0000936395-22-000029:mdna:99]

[0000936395-22-000045:mdna:130]
[same as prior period, unchanged from 0000936395-22-000029:mdna:100]

[0000936395-22-000045:mdna:131]
Segment profit (loss) includes CEWS benefits of $35.7 million in the first six months of fiscal 2021, net of certain fees. For further discussion of benefits from the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000045:mdna:132]
Quarter ended April 30, 2022 as compared to the quarter ended May 1, 2021

[0000936395-22-000045:mdna:133]
•Networking Platforms segment profit decreased by $58.6 million, primarily due to lower gross margin as described above and higher research and development costs including the effect of a $29.7 million benefit received from the  now-expired CEWS program in the second quarter of fiscal 2021, partially offset by higher sales volume.

[0000936395-22-000045:mdna:134]
•Platform Software and Services segment profit increased by $7.1 million, primarily due to higher sales volume, offset by lower gross margin, and higher research and development costs including the effect of a $2.5 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:135]
•Blue Planet Automation Software and Services segment reflects lower sales volume, lower gross margin, and higher research and development costs, including the effect of a $1.2 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:136]
•Global Services segment profit increased by $4.1 million, primarily due to higher sales volume, offset by lower gross margin on services as described above and the effect of a $2.3 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:137]
Six months ended April 30, 2022 as compared to the six months ended May 1, 2021

[0000936395-22-000045:mdna:138]
•Networking Platforms segment profit decreased by $80.9 million, primarily due to lower gross margin as described above, and higher research and development costs, including the effect of a $29.7 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021, partially offset by higher sales volume.

[0000936395-22-000045:mdna:139]
•Platform Software and Services segment profit increased by $28.9 million, primarily due to higher sales volume, offset by slightly lower gross margin and higher research and development costs including the effect of a $2.5 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:140]
•Blue Planet Automation Software and Services segment reflects reduced gross margin, lower sales volume and higher research and development costs including the effect of a $1.2 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:141]
•Global Services segment profit increased by $13.8 million, primarily due to higher sales volume and higher gross margin on services as described above, offset by the effect of a $2.3 million benefit received from the now-expired CEWS program in the second quarter of fiscal 2021.

[0000936395-22-000045:mdna:142]
[same as prior period, unchanged from 0000936395-22-000029:mdna:106]

[0000936395-22-000045:mdna:143]
Overview. For the six months ended April 30, 2022, $52.1 million of cash was provided by operating activities as our net income (adjusted for non-cash charges) of $202.6 million exceeded our working capital requirements of $150.5 million. For additional details, see “Cash Provided By Operating Activities” below.

[0000936395-22-000045:mdna:144]
Despite the cash provided by operating activities, cash, cash equivalents and investments decreased by $37.5 million during the first six months of fiscal 2022 due to the following items: (i) cash used to fund our investing activities for capital expenditures totaling $45.2 million; (ii) cash used for acquisition of businesses of $62.0 million; (iii) cash used for stock repurchases under our stock repurchase program of $332.8 million; (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $35.0 million; (v) purchase of a cost method equity investment of $8.0 million; and (vi) net decreases due to the impact of exchange rate changes on cash and cash equivalents of $8.8 million. Proceeds from the issuance of the 2030 Notes provided $394.9 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan provided $15.2 million in cash during the six months ended April 30, 2022.

[0000936395-22-000045:mdna:145]
See Notes 4, 16 and 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for additional information on these transactions.

[0000936395-22-000045:mdna:146]
[same as prior period, unchanged from 0000936395-22-000029:mdna:110]

[0000936395-22-000045:mdna:147]
|  | April 30,2022 |  | October 30,2021 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,019,863 |  |  | $ | 1,422,546 |  |  | $ | (402,683) |  |
| Short-term investments in marketable debt securities | 529,552 |  |  | 181,483 |  |  | 348,069 |  |
| Long-term investments in marketable debt securities | 87,142 |  |  | 70,038 |  |  | 17,104 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,636,557 |  |  | $ | 1,674,067 |  |  | $ | (37,510) |  |

[0000936395-22-000045:mdna:148]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which, as of April 30, 2022 totaled $1.6 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of April 30, 2022, letters of credit totaling $84.2 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2022.

[0000936395-22-000045:mdna:149]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $269.1 million as of April 30, 2022. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $33.0 million.

[0000936395-22-000045:mdna:150]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During the second quarter of fiscal 2022, we repurchased an additional $87.0 million of our common stock under the stock repurchase program, and we had $663.0 million remaining under the current repurchase authorization as of April 30, 2022. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000045:mdna:151]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market

[0000936395-22-000045:mdna:152]
opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-22-000045:mdna:153]
Cash Provided By Operating Activities

[0000936395-22-000045:mdna:154]
The following sections set forth the components of our $52.1 million of cash provided by operating activities during the first six months of fiscal 2022:

[0000936395-22-000045:mdna:155]
[same as prior period, unchanged from 0000936395-22-000029:mdna:119]

[0000936395-22-000045:mdna:156]
[same as prior period, unchanged from 0000936395-22-000029:mdna:120]

[0000936395-22-000045:mdna:157]
|  | Six Months Ended |
|  | April 30, 2022 |
| Net income | $ | 84,745 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 46,030 |  |
| Share-based compensation expenses | 50,970 |  |
| Amortization of intangible assets | 24,463 |  |
| Provision for inventory excess and obsolescence | 8,487 |  |
| Provision for warranty | 7,228 |  |
| Deferred taxes | (13,474) |  |
| Other | (5,833) |  |
| Net income (adjusted for non-cash charges) | $ | 202,616 |  |

[0000936395-22-000045:mdna:158]
[same as prior period, unchanged from 0000936395-22-000029:mdna:122]

[0000936395-22-000045:mdna:159]
We used $150.5 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-22-000045:mdna:160]
|  | Six Months Ended |
|  | April 30, 2022 |
| Cash provided by accounts receivable | $ | 104,455 |  |
| Cash used in inventories | (171,056) |  |
| Cash used in prepaid expenses and other | (36,673) |  |
| Cash used in accounts payable, accruals and other obligations | (88,960) |  |
| Cash provided by deferred revenue | 43,753 |  |
| Cash used in operating lease assets and liabilities, net | (1,994) |  |
| Total cash used for working capital | $ | (150,475) |  |

[0000936395-22-000045:mdna:161]
[same as prior period, unchanged from 0000936395-22-000029:mdna:125]

[0000936395-22-000045:mdna:162]
•The $104.5 million of cash provided by accounts receivable during the first six months of fiscal 2022 reflects increased cash collections;

[0000936395-22-000045:mdna:163]
•The $171.1 million of cash used in inventories during the first six months of fiscal 2022 primarily reflects increases in raw materials inventory related to the steps that we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-22-000045:mdna:164]
•The $36.7 million of cash used in prepaid expense and other during the first six months of fiscal 2022 primarily reflects increases in contract assets and product demonstration equipment, partially offset by decreases in prepaid foreign currency forward contracts;

[0000936395-22-000045:mdna:165]
•The $89.0 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2022 primarily reflects the payment to employees under our annual cash incentive compensation plans;

[0000936395-22-000045:mdna:166]
•The $43.8 million of cash provided by deferred revenue during the first six months of fiscal 2022 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-22-000045:mdna:167]
•The $2.0 million of cash used in operating lease assets and liabilities, net, during the first six months of fiscal 2022 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-22-000045:mdna:168]
The days sales outstanding (“DSOs”) for the first six months of fiscal 2022 were 86 days, and the inventory turns for the first six months of fiscal 2022 were 3.1. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-22-000045:mdna:169]
[same as prior period, unchanged from 0000936395-22-000029:mdna:133]

[0000936395-22-000045:mdna:170]
[same as prior period, unchanged from 0000936395-22-000029:mdna:134]

[0000936395-22-000045:mdna:171]
|  | Six Months Ended |
|  | April 30, 2022 |
| Term Loan due September 28, 2025(1) | $ | 8,316 |  |
| Senior Notes due January 31, 2030(2) | — |  |
| Interest rate swaps(3) | 4,940 |  |
| ABL Credit Facility(4) | 1,211 |  |
| Finance leases | 2,342 |  |
| Cash paid during period | $ | 16,809 |  |

[0000936395-22-000045:mdna:172]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the second quarter of fiscal 2022, the interest rate on the 2025 Term Loan was 2.34%.

[0000936395-22-000045:mdna:173]
(2) The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022. See Note 16 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report.

[0000936395-22-000045:mdna:174]
[same as prior period, unchanged from 0000936395-22-000029:mdna:138]

[0000936395-22-000045:mdna:175]
(4) During the first six months of fiscal 2022, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.2 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-22-000045:mdna:176]
[same as prior period, unchanged from 0000936395-22-000029:mdna:140]

[0000936395-22-000045:mdna:177]
Our contractual obligations have not changed materially since October 30, 2021, except for the items listed below. For a summary of our contractual obligations, see Item 7 of Part II of the 2021 Annual Report.

[0000936395-22-000045:mdna:178]
Debt. As of April 30, 2022, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes total $128.6 million, with $16.6 million payable within 12 months. For additional information about the 2030 Notes, see Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-22-000045:mdna:179]
Purchase Order Obligations. Beginning in the second half of fiscal 2021, we started placing significant advance orders for supply of certain components to address our expected strong customer demand for fiscal 2022 and the corresponding long lead times resulting from the emerging supply chain challenges at that time. As of October 30, 2021, we had $430.7 million in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory, which did not include approximately $624.4 million in longer-term, cancellable advance orders that we did not consider to be firm commitments. As of April 30, 2022 we had $1.8 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory, including approximately $1.2 billion in such advance orders that, due to the ongoing nature of the supply chain shortage, we now consider to be firm commitments that are unlikely to be cancelled. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancellable and unconditional obligations.

[0000936395-22-000045:mdna:180]
[same as prior period, unchanged from 0000936395-22-000029:mdna:143]

[0000936395-22-000045:mdna:181]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic and the armed conflict between Russia and Ukraine, and expectations as to their impacts on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-22-000045:mdna:182]
[same as prior period, unchanged from 0000936395-22-000029:mdna:146]

[0000936395-22-000045:mdna:183]
[same as prior period, unchanged from 0000936395-22-000029:mdna:147]

[0000936395-22-000045:mdna:184]
[same as prior period, unchanged from 0000936395-22-000029:mdna:148]
