# CIEN note change history — 0000936395-16-000104 → 0000936395-16-000115


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-09-07):
[0000936395-16-000115:note_history:1]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- changed (2016-09-07):
[0000936395-16-000115:note_history:2]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2016-06-08, similarity 0.8688):
[0000936395-16-000104:note_history:2]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015.  On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court.  Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- removed (2016-09-07):
[0000936395-16-000104:note_history:3]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:

- removed (2016-09-07):
[0000936395-16-000104:note_history:4]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

- removed (2016-09-07):
[0000936395-16-000104:note_history:5]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

- removed (2016-09-07):
[0000936395-16-000104:note_history:6]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

- removed (2016-09-07):
[0000936395-16-000104:note_history:7]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

- removed (2016-09-07):
[0000936395-16-000104:note_history:8]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

- removed (2016-09-07):
[0000936395-16-000104:note_history:9]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss.  In response, plaintiffs filed a motion for leave to amend their complaint. The defendants opposed the motion and it is set for hearing on June 14, 2016.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:10]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in assets and liabilities” of $19.0 million for the nine-month period ending July 31, 2015.
  (was, 2016-06-08, similarity 0.9852):
[0000936395-16-000104:note_history:10]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $10.4 million for the six-month period ending April 30, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:11]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.
  (was, 2016-06-08, similarity 0.9945):
[0000936395-16-000104:note_history:11]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2016-09-07):
[0000936395-16-000115:note_history:12]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2016 and July 31, 2015 was 0.3% and 1.9%, respectively.
  (was, 2016-06-08, similarity 0.9724):
[0000936395-16-000104:note_history:12]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2016 and April 30, 2015 was 0.4% and 1.7%, respectively.

- changed (2016-09-07):
[0000936395-16-000115:note_history:13]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2016-06-08, similarity 0.8856):
[0000936395-16-000104:note_history:13]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:14]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of July 31, 2016 (in thousands):
  (was, 2016-06-08, similarity 0.9738):
[0000936395-16-000104:note_history:14]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of April 30, 2016 (in thousands):

- changed (2016-09-07):
[0000936395-16-000115:note_history:15]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,192 |  |  | $ | 251,557 |  |
  (was, 2016-06-08, similarity 0.971):
[0000936395-16-000104:note_history:15]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,753 |  |  | $ | 250,938 |  |

- changed (2016-09-07):
[0000936395-16-000115:note_history:16]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):
  (was, 2016-06-08, similarity 0.9899):
[0000936395-16-000104:note_history:16]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):

- changed (2016-09-07):
[0000936395-16-000115:note_history:17]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,144 |  |  | $ | 247,144 |  |
  (was, 2016-06-08, similarity 0.9707):
[0000936395-16-000104:note_history:17]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,696 |  |  | $ | 245,011 |  |

- added (2016-09-07):
[0000936395-16-000115:note_history:18]
During the first nine months of fiscal 2016, Ciena entered into certain private transactions to repurchase $43.5 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for cash purchase prices slightly below par. See Note 23 below for information regarding a repurchase transaction in the fourth quarter of fiscal 2016.

- changed (2016-09-07):
[0000936395-16-000115:note_history:19]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of July 31, 2016:
  (was, 2016-06-08, similarity 0.9819):
[0000936395-16-000104:note_history:19]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of April 30, 2016:

- changed (2016-09-07):
[0000936395-16-000115:note_history:20]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2016:
  (was, 2016-06-08, similarity 0.9508):
[0000936395-16-000104:note_history:20]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes:

- added (2016-09-07):
[0000936395-16-000115:note_history:21]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 450,465 |  |  | $ | 449,339 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,938 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 188,348 |  |  | 239,072 |  |
|  |  | $ | 988,813 |  |  | $ | 1,105,349 |  |

- removed (2016-09-07):
[0000936395-16-000104:note_history:22]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for a cash purchase price slightly below par.

- removed (2016-09-07):
[0000936395-16-000104:note_history:23]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 479,985 |  |  | $ | 471,585 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 395,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 186,954 |  |  | 224,766 |  |
|  |  | $ | 1,016,939 |  |  | $ | 1,091,414 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:24]
|  | July 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 265,168 |  |  | $ | 187 |  |  | (3 | ) |  | $ | 265,352 |  |
| Included in long-term investments | 115,182 |  |  | 186 |  |  | (2 | ) |  | 115,366 |  |
|  | $ | 380,350 |  |  | $ | 373 |  |  | $ | (5 | ) |  | $ | 380,718 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,970 |  |  | — |  |  | — |  |  | $ | 29,970 |  |
|  | $ | 29,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,970 |  |
  (was, 2016-06-08, similarity 0.9915):
[0000936395-16-000104:note_history:24]
|  | April 30, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 190,123 |  |  | $ | 87 |  |  | (28 | ) |  | $ | 190,182 |  |
| Included in long-term investments | 125,091 |  |  | 157 |  |  | (15 | ) |  | 125,233 |  |
|  | $ | 315,214 |  |  | $ | 244 |  |  | $ | (43 | ) |  | $ | 315,415 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 4,997 |  |  | — |  |  | — |  |  | $ | 4,997 |  |
|  | $ | 4,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,997 |  |

- changed (2016-09-07):
[0000936395-16-000115:note_history:25]
The following table summarizes the final legal maturities of debt investments at July 31, 2016 (in thousands):
  (was, 2016-06-08, similarity 0.9668):
[0000936395-16-000104:note_history:25]
The following table summarizes the final legal maturities of debt investments at April 30, 2016 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:26]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of July 31, 2016 (in thousands):
  (was, 2016-06-08, similarity 0.9738):
[0000936395-16-000104:note_history:26]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of April 30, 2016 (in thousands):

- changed (2016-09-07):
[0000936395-16-000115:note_history:27]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,192 |  |  | $ | 251,557 |  |
  (was, 2016-06-08, similarity 0.971):
[0000936395-16-000104:note_history:27]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,753 |  |  | $ | 250,938 |  |

- changed (2016-09-07):
[0000936395-16-000115:note_history:28]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2016:
  (was, 2016-06-08, similarity 0.9508):
[0000936395-16-000104:note_history:28]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes:

- added (2016-09-07):
[0000936395-16-000115:note_history:29]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 450,465 |  |  | $ | 449,339 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,938 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 188,348 |  |  | 239,072 |  |
|  |  | $ | 988,813 |  |  | $ | 1,105,349 |  |

- changed (2016-09-07):
[0000936395-16-000115:note_history:30]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):
  (was, 2016-06-08, similarity 0.9738):
[0000936395-16-000104:note_history:30]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):

- changed (2016-09-07):
[0000936395-16-000115:note_history:31]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,144 |  |  | $ | 247,144 |  |
  (was, 2016-06-08, similarity 0.9707):
[0000936395-16-000104:note_history:31]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,696 |  |  | $ | 245,011 |  |

- removed (2016-09-07):
[0000936395-16-000104:note_history:32]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 479,985 |  |  | $ | 471,585 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 395,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 186,954 |  |  | 224,766 |  |
|  |  | $ | 1,016,939 |  |  | $ | 1,091,414 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:33]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of July 31, 2016:
  (was, 2016-06-08, similarity 0.9819):
[0000936395-16-000104:note_history:33]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of April 30, 2016:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-09-07):
[0000936395-16-000115:note_history:34]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2016 and July 31, 2015 was 0.3% and 1.9%, respectively.
  (was, 2016-06-08, similarity 0.9724):
[0000936395-16-000104:note_history:34]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2016 and April 30, 2015 was 0.4% and 1.7%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2016-09-07):
[0000936395-16-000115:note_history:35]
SUBSEQUENT EVENT

- added (2016-09-07):
[0000936395-16-000115:note_history:36]
On August 5, 2016, Ciena repurchased approximately $205 million in aggregate principal amount of its outstanding 0.875% Convertible Senior Notes due 2017 (the “2017 Notes”) in a private transaction, for an aggregate purchase price of approximately $205 million, inclusive of accrued interest. Following the transaction, $245.3 million in aggregate principal amount of the 2017 Notes remain outstanding.
