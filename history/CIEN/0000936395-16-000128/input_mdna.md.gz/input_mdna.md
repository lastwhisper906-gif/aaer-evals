# CIEN MD&A — 0000936395-16-000128


## mdna

[0000936395-16-000128:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-16-000128:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-16-000128:mdna:3]
Overview

[0000936395-16-000128:mdna:4]
We are a network strategy and technology company, providing solutions that enable a wide range of network operators to adopt next-generation communication architectures and to deliver a broad array of services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. Our high-capacity hardware and network management and control software solutions enable open, multi-vendor, programmable networks that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to support new applications, introduce new revenue-generating services and reduce network complexity and expense.

[0000936395-16-000128:mdna:5]
Our Converged Packet Optical, Packet Networking and Optical Transport products are used by a diverse set of customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other emerging network operators. These products, which can be applied from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware platforms, we offer network management and control software platforms designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. Our software solutions are oriented around our modular Blue Planet software platform for multi-domain service orchestration, network function virtualization, and network management and control. To complement our hardware and software solutions, we offer a broad range of transformation and automation services that help our customers design, optimize, integrate, deploy, manage and maintain their networks.

[0000936395-16-000128:mdna:6]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC’s website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-16-000128:mdna:7]
Market Opportunity

[0000936395-16-000128:mdna:8]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, evolving cloud-based service offerings, and heightened end-user service demands. These conditions have placed significant demands on networks, challenged the business models of network operators, and altered the overall competitive landscape of network operators. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services, while managing the costs of their networks and seeking to ensure a profitable business model. These dynamics are driving convergence of network features, functions and layers, virtualization of certain network functions, and solutions that leverage increased software-based network control and programmability. We believe that these dynamics, and the need to adapt to rapidly changing business and network demands, will cause network operators to adopt or evolve their networks to be more open, programmable and automated.

[0000936395-16-000128:mdna:9]
While drivers of bandwidth growth and network evolution remain strong, in recent periods certain of our customers, including several of our larger communications service provider customers in North America and Europe, Middle East and Africa (EMEA), have taken steps to constrain their capital expenditure budgets. As a result of the measured spending environment and efforts to manage network costs, growth rates in some of our markets have slowed. Some of our market segments have been adversely impacted and we have experienced lower spending levels on networking equipment from some existing customers as compared to prior periods. Notwithstanding these market dynamics, during fiscal 2016 we continued to improve our financial results and increased our revenue. Revenue growth during fiscal 2016 benefited meaningfully from our continued efforts to diversify our business to include additional customer and geographic markets, and to take market share from or displace competitors. Specifically, we continue to diversify our customer base to include additional customer segments, such as Web-scale providers, cable and multiservice operators, data center operators and enterprise customers, which

[0000936395-16-000128:mdna:10]
contributed to our growth in North America during fiscal 2016.  We benefited from geographic diversification and growth of our business in Asia-Pacific during fiscal 2016, including sales to additional service provider customers and submarine consortia and network operators. Our diversification efforts also include the broadening of our solutions portfolio, focusing on certain higher growth applications for our network infrastructure products, including metro networking, data center interconnect and submarine networks, and the adoption of our Blue Planet software platform.  We believe that continued diversification of our business is an important part of our strategy and necessary for continued revenue growth.

[0000936395-16-000128:mdna:11]
Our corporate strategy to capitalize on these market dynamics, promote openness and drive the profitable growth of our business includes the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-16-000128:mdna:12]
Competitive Landscape

[0000936395-16-000128:mdna:13]
The markets in which we compete are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to displace incumbent vendors and to capture market share. The markets for our solutions are both highly competitive and fragmented. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, higher-capacity, higher-speed network solutions with improved reach, spectral efficiency, automation, power consumption and cost per bit. We expect the competitive landscape in which we operate to continue to broaden and to remain challenging and dynamic. As we have expanded our solutions offerings to include our 8700 Packetwave Platform and Waveserver DCI platform, our solutions have become increasingly competitive with IP router vendors, data center switch providers, and other IT suppliers or integrators. In addition, as we seek increased customer adoption of our Blue Planet software platform, we expect to compete more directly with additional software vendors and information technology vendors or integrators of these solutions. As network operators' consumption models evolve towards a disaggregated approach to the procurement of hardware and software, we may also face competition from alternative system vendors or component vendors, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware.

[0000936395-16-000128:mdna:14]
Given this dynamic competitive landscape and the market-based price erosion for our products that we regularly encounter, we expect that, in order to achieve sustained revenue growth, we will be required to continue to increase our volume of product shipments, continue to diversify our business and customer base, and introduce new solutions that address evolving service and network demands. In addition, in order to maintain incumbency with key customers and to secure new opportunities, we are often required to agree to aggressive pricing, incur significant costs early in network deployment, or make significant commercial concessions.  These terms have previously, and may in the future, adversely affect our results of operations and contribute to fluctuations in our financial results.

[0000936395-16-000128:mdna:15]
See the “Industry Background” and “Competition” sections of the description of our business in Item 1 of Part 1 of this annual report for more information related to the competitive landscape of our markets.

[0000936395-16-000128:mdna:16]
Repurchase of Convertible Notes

[0000936395-16-000128:mdna:17]
During fiscal 2016, we repurchased approximately $262.5 million of the outstanding aggregate principal amount of our 0.875% convertible senior notes due June 15, 2017 (the “2017 Notes”) in private transactions, for cash purchase prices slightly below par. As of the end of fiscal 2016, $231.6 million in aggregate principal amount of the 2017 Notes remained outstanding. See Note 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information regarding our repurchase of $46.3 million in aggregate principal amount of our 2017 Notes following the end of fiscal 2016. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-16-000128:mdna:18]
See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our outstanding convertible notes.

[0000936395-16-000128:mdna:19]
Term Loan due April 25, 2021

[0000936395-16-000128:mdna:20]
On April 25, 2016, we entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the “Term Loan Credit Agreement”), dated July 15, 2014. As more fully described in Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report, the Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million maturing on April 25, 2021 (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, initially supplemented cash on the balance sheet and are

[0000936395-16-000128:mdna:21]
expected to provide additional liquidity to contribute, in part, to the repayment of the remaining outstanding principal amount owing under our 0.875% senior convertible notes due June 15, 2017.

[0000936395-16-000128:mdna:22]
See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our term loans.

[0000936395-16-000128:mdna:23]
Purchase of High-Speed Photonic Component Assets of TeraXion, Inc.

[0000936395-16-000128:mdna:24]
On January 19, 2016, Ciena Canada, Inc., a wholly-owned subsidiary of Ciena Corporation, entered into a definitive agreement with TeraXion, Inc. (“TeraXion”) and its wholly-owned subsidiary to acquire certain high-speed photonics components (“HSPC”) assets for approximately $32 million in cash. The assets purchased included, among other things, TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as certain underlying intellectual property, that support development of our WaveLogic coherent optical chipsets. This transaction has been accounted for as an acquisition of a business. As a result of this transaction, we also gained key research and development personnel in Ottawa and Quebec City, Canada. We believe that this acquisition affords us greater control over important component technologies used in our business and provides us opportunities to accelerate the further development of our coherent packet-optical solutions. We completed our acquisition of these assets on February 1, 2016, and the acquisition of these assets and related expense are reflected in our financial results for the second fiscal quarter of 2016.

[0000936395-16-000128:mdna:25]
Financial Results for Fourth Quarter of Fiscal 2016 and Sequential Comparison

[0000936395-16-000128:mdna:26]
Revenue for the fourth quarter of fiscal 2016 was $716.2 million, representing a sequential increase of 6.8% from $670.6 million in the third quarter of fiscal 2016. Revenues for the fourth and third quarters of fiscal 2016 includes $34.9 million and $32.9 million, respectively, from products and services relating to the Cyan business acquired on August 3, 2015. Revenue-related details reflecting sequential changes from the third quarter of fiscal 2016 include the following:

[0000936395-16-000128:mdna:27]
| • | Product revenue for the fourth quarter of fiscal 2016 increased by $29.0 million, primarily reflecting increases of $25.3 million in Networking Platforms and $3.7 million in Software and Software-Related Services. |

[0000936395-16-000128:mdna:28]
| • | Services revenue for the fourth quarter of fiscal 2016 increased by $16.6 million. |

[0000936395-16-000128:mdna:29]
| • | Revenue from North America for the fourth quarter of fiscal 2016 was $463.1 million, an increase from $438.0 million in the third quarter of fiscal 2016. This reflects increases of $12.1 million in Networking Platforms, $7.6 million in Global Services and $5.3 million in Software and Software-Related Services. |

[0000936395-16-000128:mdna:30]
| • | Revenue from EMEA for the fourth quarter of fiscal 2016 was $112.5 million, an increase from $104.3 million in the third quarter of fiscal 2016. This primarily reflects increases of $7.6 million in Global Services and $1.5 million in Networking Platforms. |

[0000936395-16-000128:mdna:31]
| • | Caribbean and Latin America (“CALA”) revenue for the fourth quarter of fiscal 2016 was $46.8 million, a slight increase from $46.6 million in the third quarter of fiscal 2016. |

[0000936395-16-000128:mdna:32]
| • | Asia Pacific (“APAC”) revenue for the fourth quarter of fiscal 2016 was $93.8 million, an increase from $81.7 million in the third quarter of fiscal 2016. This reflects increases of $9.4 million in Networking Platforms, $1.5 million in Global Services and $1.2 million in Software and Software-Related Services. |

[0000936395-16-000128:mdna:33]
| • | For the fourth quarter and third quarter of fiscal 2016, AT&T accounted for 18.3% and 15.7% of total revenue, respectively. |

[0000936395-16-000128:mdna:34]
Gross margin for the fourth quarter of fiscal 2016 was 44.5%, a decrease from 46.0% in the third quarter of fiscal 2016. The reduced gross margin reflects unfavorable product mix and higher deployment and installation services costs from early stages of network deployments.

[0000936395-16-000128:mdna:35]
Operating expense was $258.9 million for the fourth quarter of fiscal 2016, a $7.4 million increase from $251.5 million in the third quarter of fiscal 2016. This reflects increases of $13.1 million in selling and marketing expense, primarily due to increased incentive sales compensation, partially offset by decreases of $4.3 million in research and development expense and $2.2 million for general and administrative expense.

[0000936395-16-000128:mdna:36]
Income from operations for the fourth quarter of fiscal 2016 was $59.7 million, as compared to $57.0 million during the third quarter of fiscal 2016. Our net income for the fourth quarter of fiscal 2016 was $36.6 million, or $0.25 per diluted common share. This compares to a net income of $33.5 million or $0.23 per diluted common share, for the third quarter of fiscal 2016.

[0000936395-16-000128:mdna:37]
We generated $136.7 million of cash from operations during the fourth quarter of fiscal 2016. This compares with $77.1 million in cash generated from operations during the third quarter of fiscal 2016. As of October 31, 2016, we had $777.6 million in cash and cash equivalents, $275.2 million of short-term investments in U.S. treasury securities and commercial paper and $90.2 million of long-term investments in U.S. treasury securities. This compares to $854.9 million in cash and cash equivalents, $295.3 million of short-term investments in U.S. treasury securities and commercial paper, and $115.4 million of long-term investments in U.S. treasury securities at July 31, 2016.

[0000936395-16-000128:mdna:38]
As of October 31, 2016, we had 5,555 employees, a decrease from 5,559 as of July 31, 2016 and an increase from 5,345 and 5,161 at October 31, 2015 and 2014, respectively.

[0000936395-16-000128:mdna:39]
43

[0000936395-16-000128:mdna:40]
Consolidated Results of Operations

[0000936395-16-000128:mdna:41]
Operating Segments

[0000936395-16-000128:mdna:42]
During the first quarter of fiscal 2016, we reorganized our internal organizational structure, the management of our business, and the reporting of our operating segments. This resulted in three new operating segments: Networking Platforms, Software and Software-Related Services, and Global Services. Ciena’s previous Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form the Networking Platforms segment under a single operating segment manager. Our previous Software and Services operating segment was reorganized into two separate operating segments: (i) Software and Software-Related Services, and (ii) Global Services. Segment revenue and segment profit for fiscal 2015 and fiscal 2014 have been restated to reflect the new operating segments adopted in fiscal 2016. For the periods covered by this report, our internal organizational structure and the management of its business were grouped into the following operating segments: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services, each of which is more fully described in the “Products and Services” section of the description of our business in Item 1 of Part I of this annual report.

[0000936395-16-000128:mdna:43]
| • | Networking Platforms reflects sales of our Converged Packet Optical, Packet Networking and Optical Transport product lines. |

[0000936395-16-000128:mdna:44]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature our WaveLogic coherent optical processors. Products also include the Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000128:mdna:45]
| ◦ | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. |

[0000936395-16-000128:mdna:46]
| ◦ | Optical Transport — includes the 4200 Advanced Services Platform, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-16-000128:mdna:47]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations.

[0000936395-16-000128:mdna:48]
| • | Software and Software-Related Services reflects sales of our network virtualization, management, control and orchestration software solutions and software-related services, including subscription, installation, support, and consulting services. |

[0000936395-16-000128:mdna:49]
| ◦ | This segment includes our element and network management solutions and planning tools, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As we transition features, functionality and customers from our element and network management solutions to our Blue Planet software platform, we expect revenue declines for our existing element and network management solutions. |

[0000936395-16-000128:mdna:50]
| ◦ | This segment also includes our Blue Planet network virtualization, service orchestration and network management software platform, including the multi-domain service orchestration (MDSO), network function virtualization orchestration (NFVO), and our SDN Multilayer WAN Controller and related applications. |

[0000936395-16-000128:mdna:51]
Revenue from the software platforms is included in product revenue on the Consolidated Statement of Operations. Revenue from software-related services is included in services revenue on the Consolidated Statement of Operations.

[0000936395-16-000128:mdna:52]
| • | Global Services reflects sales of a broad range of our services offering for consulting and network design, installation and deployment, maintenance support and training activities. Revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-16-000128:mdna:53]
Fiscal 2016 compared to Fiscal 2015

[0000936395-16-000128:mdna:54]
Revenue

[0000936395-16-000128:mdna:55]
Our total revenue in fiscal 2016 was slightly impacted by the strengthening of the U.S. Dollar. During fiscal 2016, as compared to fiscal 2015, the U.S. Dollar strengthened against a number of foreign currencies, including the Canadian Dollar

[0000936395-16-000128:mdna:56]
and Brazilian Real, in which we have our most significant foreign currency revenue exposure. As a result, our total revenue reported in U.S. Dollars during fiscal 2016 was adversely impacted by approximately $16.7 million or 0.6% as compared to fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000128:mdna:57]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,779,932 |  |  | 68.5 |  | $ | 1,661,702 |  |  | 67.9 |  | $ | 118,230 |  |  | 7.1 |  |
| Packet Networking | 252,862 |  |  | 9.7 |  | 229,223 |  |  | 9.4 |  | 23,639 |  |  | 10.3 |  |
| Optical Transport | 35,989 |  |  | 1.4 |  | 73,004 |  |  | 3.0 |  | (37,015 | ) |  | (50.7 | ) |
| Total Networking Platforms | 2,068,783 |  |  | 79.6 |  | $ | 1,963,929 |  |  | 80.3 |  | 104,854 |  |  | 5.3 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 48,689 |  |  | 1.9 |  | 38,466 |  |  | 1.6 |  | 10,223 |  |  | 26.6 |  |
| Software-Related Services | 76,380 |  |  | 2.9 |  | 61,821 |  |  | 2.5 |  | 14,559 |  |  | 23.6 |  |
| Total Software and Software-Related Services | 125,069 |  |  | 4.8 |  | 100,287 |  |  | 4.1 |  | 24,782 |  |  | 24.7 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 228,982 |  |  | 8.8 |  | 224,079 |  |  | 9.2 |  | 4,903 |  |  | 2.2 |  |
| Installation and Deployment | 130,916 |  |  | 5.0 |  | 115,531 |  |  | 4.7 |  | 15,385 |  |  | 13.3 |  |
| Consulting and Network Design | 46,823 |  |  | 1.8 |  | 41,843 |  |  | 1.7 |  | 4,980 |  |  | 11.9 |  |
| Total Global Services | 406,721 |  |  | 15.6 |  | $ | 381,453 |  |  | 15.6 |  | 25,268 |  |  | 6.6 |  |
| Consolidated revenue | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |  |

[0000936395-16-000128:mdna:58]
_________________________________

[0000936395-16-000128:mdna:59]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:60]
| • | Networking Platforms revenue increased, primarily reflecting product line sales increases of $118.2 million of our Converged Packet Optical products and $23.6 million of our Packet Networking products, partially offset by a decrease of $37.0 million in sales of our Optical Transport products. |

[0000936395-16-000128:mdna:61]
| ◦ | Converged Packet Optical sales primarily reflect increases of $107.7 million of our 6500 Packet-Optical Platform, $33.7 million in sales relating to the Z-Series Packet-Optical Platform, acquired from Cyan in the fourth quarter of fiscal 2015, and $8.2 million in sales of our Waveserver stackable data center interconnect system. Increased 6500 Packet-Optical Platform revenue reflects increased sales to a diverse set of customers including communications service providers, Web-scale providers and enterprise customers, partially offset by a decrease in sales to AT&T. These increases were also partially offset by decreases of $23.7 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $7.9 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-16-000128:mdna:62]
| ◦ | Packet Networking sales reflect increases of $16.2 million in sales of our 3000 and 5000 family of service delivery and aggregation switches and $9.3 million in sales of our 8700 Packetwave Platform, partially offset by a decrease of $1.4 million in sales of Ethernet packet configuration for our 5410 Service Aggregation Switch. |

[0000936395-16-000128:mdna:63]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-16-000128:mdna:64]
45

[0000936395-16-000128:mdna:65]
| • | Software and Software-Related Services revenue increased, primarily reflecting increases of $14.6 million in software-related services sales and $10.2 million in sales of our software platforms. The increase in software-related services revenue primarily reflects increased sales of software subscription services. The increase in software platform revenue reflects $6.7 million in initial sales of our Blue Planet software platform and advanced software applications and a $1.4 million increase in sales of our OneControl Unified Management System. Segment revenue also includes $2.1 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-16-000128:mdna:66]
| • | Global Services revenue increased, primarily reflecting increases of $15.4 million in sales of our installation and deployment services, $5.0 million in sales of our consulting and network design services and $4.9 million in sales of our maintenance and support services. Global Services segment revenue includes $16.1 million and $3.4 million of services revenue acquired from Cyan for fiscal 2016 and fiscal 2015, respectively. |

[0000936395-16-000128:mdna:67]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated principally based on the relevant location for our delivery of products and performance of services:

[0000936395-16-000128:mdna:68]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,689,263 |  |  | 65.0 |  | $ | 1,598,328 |  |  | 65.4 |  | $ | 90,935 |  |  | 5.7 |  |
| EMEA | 393,705 |  |  | 15.1 |  | 400,294 |  |  | 16.4 |  | (6,589 | ) |  | (1.6 | ) |
| CALA | 195,085 |  |  | 7.5 |  | 201,499 |  |  | 8.2 |  | (6,414 | ) |  | (3.2 | ) |
| APAC | 322,520 |  |  | 12.4 |  | 245,548 |  |  | 10.0 |  | 76,972 |  |  | 31.3 |  |
| Total | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |  |

[0000936395-16-000128:mdna:69]
_________________________________

[0000936395-16-000128:mdna:70]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:71]
| • | North America revenue primarily reflects increases of $54.8 million within our Networking Platforms segment, $22.8 million within our Software and Software-Related Services segment and $13.3 million within our Global Services segment. Increased Networking Platforms segment revenue primarily reflects product line increases of $63.1 million of Converged Packet Optical sales and $11.0 million of Packet Networking sales, partially offset by a decrease of $19.3 million in Optical Transport sales. Converged Packet Optical sales reflect a $42.3 million increase in sales of our 6500 Packet-Optical Platform, reflecting increased sales to a diverse set of customers including communications service providers, Web-scale providers and enterprise customers, partially offset by a decrease in sales to AT&T and cable and multiservice operators. Converged Packet Optical sales also reflect an increase of $24.6 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000128:mdna:72]
| • | EMEA revenue primarily reflects a decrease of $9.6 million within our Networking Platforms segment, partially offset by an increase of $3.8 million within our Global Services segment. Networking Platforms segment revenue reflects product line decreases of $10.8 million in Optical Transport sales and $1.6 million in Converged Packet Optical sales, partially offset by a product line increase of $2.8 million in Packet Networking sales. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000128:mdna:73]
| • | CALA revenue primarily reflects a decrease of $11.1 million within our Networking Platform segment, partially offset by an increase of $4.5 million within our Global Services segment. CALA revenue reflects decreased sales to certain communication service providers, primarily in Brazil, partially offset by increased sales to AT&T in Mexico. |

[0000936395-16-000128:mdna:74]
| • | APAC revenue reflects increases of $70.8 million within our Networking Platform segment, $3.6 million within our Global Services segment and $2.5 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to certain communications service providers, particularly in India, enterprise customers, submarine network operators and sales through our strategic partnership with Ericsson. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-16-000128:mdna:75]
We have benefited from the diversification of our business and customer base, and the concentration of revenue among our largest customers has decreased over time. In fiscal 2016 and fiscal 2015, our top ten customers contributed 51.1% of and 52.5% revenue, respectively. A sizable portion of our revenue continues to be derived from sales to large service provider customers. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting their businesses. Our reliance upon a relatively small number of customers also increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending upon sales volumes and purchasing priorities with these large customers.

[0000936395-16-000128:mdna:76]
Sales to AT&T were $479.1 million, or 18.4% of total revenue, in fiscal 2016 and $487.8 million, or 19.9% of total revenue, in fiscal 2015. AT&T and other service provider customers have announced initiatives to reduce capital expenditures in future periods, including on network infrastructure, and there can be no assurance that we will be able to maintain the revenue levels we achieved during fiscal 2016. Moreover, some customers, including AT&T, are pursuing network strategies that seek to utilize enhanced software programmability, management and control of networks and to deploy off-the-shelf or commoditized hardware technology, referred to as “white box” hardware, in lieu of existing solutions. These strategies may present challenges and opportunities for our business, particularly where we are an incumbent equipment vendor. No other customer accounted for greater than 10% of our revenue in fiscal 2016 or fiscal 2015.

[0000936395-16-000128:mdna:77]
As our business has diversified, we have taken a number of steps to increase the velocity of our business and improve our operating efficiency, including through inventory management and lead time reduction. As a result, the percentage of quarterly product revenue that we generate from customer orders placed during that particular quarter has increased meaningfully, as compared to our historical periods. Our increased reliance upon orders placed during a particular quarter may make it harder to predict our revenue and results of operations, and may further increase the likelihood of fluctuations in our results.

[0000936395-16-000128:mdna:78]
Cost of Goods Sold and Gross Profit

[0000936395-16-000128:mdna:79]
Product cost of goods sold consists primarily of amounts paid to third party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-16-000128:mdna:80]
Services cost of goods sold consists primarily of direct and third party costs, including employee-related costs, associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third party contractor-related costs.

[0000936395-16-000128:mdna:81]
Although we have seen improvements in recent fiscal years, our gross profit as a percentage of revenue, or “gross margin,” remains susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography, and customers. Gross margin can also be affected by costs associated with the early stages of network deployments, the mix of lower margin “common” equipment sales as compared higher margin products including channel cards and software, and the mix of lower margin installation services. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations. We regularly encounter pricing pressure and market-based price erosion that can impact our results of operations. We expect that our gross margins will be subject to fluctuation and significantly dependent upon on our level of success in driving product cost reductions relative to the price erosion that we encounter or forward pricing that we offer. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and operations. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods, and there can be no guarantee that our gross margin will continue to improve or remain at current levels.

[0000936395-16-000128:mdna:82]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-16-000128:mdna:83]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-16-000128:mdna:84]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |
| Total cost of goods sold | 1,438,997 |  |  | 55.3 |  | 1,370,106 |  |  | 56.0 |  | 68,891 |  |  | 5.0 |
| Gross profit | $ | 1,161,576 |  |  | 44.7 |  | $ | 1,075,563 |  |  | 44.0 |  | $ | 86,013 |  |  | 8.0 |

[0000936395-16-000128:mdna:85]
_________________________________

[0000936395-16-000128:mdna:86]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:87]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,117,472 |  |  | 100.0 |  | $ | 2,002,395 |  |  | 100.0 |  | $ | 115,077 |  |  | 5.7 |
| Product cost of goods sold | 1,176,304 |  |  | 55.6 |  | 1,120,373 |  |  | 56.0 |  | 55,931 |  |  | 5.0 |
| Product gross profit | $ | 941,168 |  |  | 44.4 |  | $ | 882,022 |  |  | 44.0 |  | $ | 59,146 |  |  | 6.7 |

[0000936395-16-000128:mdna:88]
_________________________________

[0000936395-16-000128:mdna:89]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:90]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 483,101 |  |  | 100.0 |  | $ | 443,274 |  |  | 100.0 |  | $ | 39,827 |  |  | 9.0 |
| Service cost of goods sold | 262,693 |  |  | 54.4 |  | 249,733 |  |  | 56.3 |  | 12,960 |  |  | 5.2 |
| Service gross profit | $ | 220,408 |  |  | 45.6 |  | $ | 193,541 |  |  | 43.7 |  | $ | 26,867 |  |  | 13.9 |

[0000936395-16-000128:mdna:91]
_________________________________

[0000936395-16-000128:mdna:92]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:93]
| • | Gross profit as a percentage of revenue, or gross margin, increased as a result of the factors described below. |

[0000936395-16-000128:mdna:94]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, increased as a result of our success in driving product cost reductions as compared to the market-based price erosion we encountered during the period, and increased software revenue. |

[0000936395-16-000128:mdna:95]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, increased, primarily due to increased sales of higher margin software subscription services, reduced repair costs to support maintenance service contracts and increased sales and improved margins on consulting services. |

[0000936395-16-000128:mdna:96]
Operating Expense

[0000936395-16-000128:mdna:97]
Operating expense increased in fiscal 2016 from the level reported for fiscal 2015, in part due to the additional personnel and operations related to our acquisition of Cyan during the fourth quarter of fiscal 2015 and our acquisition of the HSPC assets of TeraXion on February 1, 2016. In addition, operating expense increased due to our research and development initiatives, investments in the upgrade of company-wide enterprise resource planning platforms, and the transition into new buildings at several locations where we maintain a large employee population. We expect operating expense to increase in fiscal 2017 from the level reported for fiscal 2016. In particular, the development of our new facilities and the transition of our operations in

[0000936395-16-000128:mdna:98]
Ottawa, Canada and Gurgaon, India have and will continue to require significant effort, time and cost. For additional information regarding this lease and the facility transition, see Item 2 of Part I of this annual report.

[0000936395-16-000128:mdna:99]
Operating expense consists of the component elements described below.

[0000936395-16-000128:mdna:100]
Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, and testing of our products, depreciation expense and third party consulting costs.

[0000936395-16-000128:mdna:101]
Selling and marketing expense primarily consists of salaries, incentive-based sales commissions and related employee expense (including share-based compensation expense), and sales and marketing support expense, including travel, demonstration units, trade show expense and third party consulting costs.

[0000936395-16-000128:mdna:102]
General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense), and costs for third party consulting and other services.

[0000936395-16-000128:mdna:103]
Amortization of intangible assets primarily reflects the amortization of purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-16-000128:mdna:104]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition of Cyan on August 3, 2015 and our acquisition of the HSPC assets from TeraXion and its wholly-owned subsidiary on February 1, 2016.

[0000936395-16-000128:mdna:105]
Restructuring costs primarily reflect actions we have taken to better align our workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions.

[0000936395-16-000128:mdna:106]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-16-000128:mdna:107]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 451,794 |  |  | 17.4 |  | $ | 414,201 |  |  | 16.9 |  | $ | 37,593 |  |  | 9.1 |  |
| Selling and marketing | 349,731 |  |  | 13.4 |  | 333,836 |  |  | 13.7 |  | 15,895 |  |  | 4.8 |  |
| General and administrative | 132,828 |  |  | 5.1 |  | 123,402 |  |  | 5.0 |  | 9,426 |  |  | 7.6 |  |
| Amortization of intangible assets | 61,508 |  |  | 2.4 |  | 69,511 |  |  | 2.8 |  | (8,003 | ) |  | (11.5 | ) |
| Acquisition and integration costs | 4,613 |  |  | 0.2 |  | 25,539 |  |  | 1.0 |  | (20,926 | ) |  | (81.9 | ) |
| Restructuring costs | 4,933 |  |  | 0.2 |  | 8,626 |  |  | 0.4 |  | (3,693 | ) |  | (42.8 | ) |
| Total operating expenses | $ | 1,005,407 |  |  | 38.7 |  | $ | 975,115 |  |  | 39.8 |  | $ | 30,292 |  |  | 3.1 |  |

[0000936395-16-000128:mdna:108]
_________________________________

[0000936395-16-000128:mdna:109]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:110]
| • | Research and development expense benefited by $16.4 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $37.6 million, primarily reflecting increases of $16.7 million in employee compensation and related costs, $11.0 million in facilities and information systems expense, $7.4 million in professional services and $4.0 million in depreciation expense. These increases were partially offset by a decrease of $4.8 million in prototype expense. |

[0000936395-16-000128:mdna:111]
| • | Selling and marketing expense benefited by $4.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expenses increased by $15.9 million, primarily reflecting increases of $7.2 million in employee compensation and related costs, $3.6 million in facilities and information systems expense, $3.5 million in professional services and $1.5 million in travel and related costs. These increases were partially offset by a decrease of $1.8 million in trade show and related costs. |

[0000936395-16-000128:mdna:112]
| • | General and administrative expense benefited by $1.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Brazilian Real. Including the effect of foreign exchange rates, general and administrative expense increased by $9.4 million, primarily reflecting increases of $5.0 million in employee compensation and related costs, $2.3 million in facilities and information systems expense and $1.6 million in professional services. |

[0000936395-16-000128:mdna:113]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-16-000128:mdna:114]
| • | Acquisition and integration costs reflect expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000128:mdna:115]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. See Note 3 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report for more information. |

[0000936395-16-000128:mdna:116]
Other items

[0000936395-16-000128:mdna:117]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-16-000128:mdna:118]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (12,795 | ) |  | (0.5 | ) |  | $ | (25,505 | ) |  | (1.0 | ) |  | $ | 12,710 |  |  | 49.8 |  |
| Interest expense | $ | 56,656 |  |  | 2.2 |  |  | $ | 51,179 |  |  | 2.1 |  |  | $ | 5,477 |  |  | 10.7 |  |
| Provision for income taxes | $ | 14,134 |  |  | 0.5 |  |  | $ | 12,097 |  |  | 0.5 |  |  | $ | 2,037 |  |  | 16.8 |  |

[0000936395-16-000128:mdna:119]
_________________________________

[0000936395-16-000128:mdna:120]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:121]
| • | Interest and other income (loss), net reflects a beneficial impact, as compared to the prior period, of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. Interest and other income (loss), net also reflects an increase in investment interest income. |

[0000936395-16-000128:mdna:122]
| • | Interest expense increased, primarily due to additional outstanding indebtedness, including our $250 million 2021 Term Loan that was entered into in the second quarter of fiscal 2016, as compared to fiscal 2015. See Note 16 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report for more information. |

[0000936395-16-000128:mdna:123]
| • | Provision for income taxes increased primarily due to state taxes. |

[0000936395-16-000128:mdna:124]
Fiscal 2015 compared to Fiscal 2014

[0000936395-16-000128:mdna:125]
Revenue

[0000936395-16-000128:mdna:126]
During fiscal 2015, the U.S. Dollar strengthened against a number of foreign currencies, including the Canadian Dollar and the Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. Dollars during fiscal 2015 was adversely impacted by approximately $48.4 million, or 1.9%, as compared to fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000128:mdna:127]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,661,702 |  |  | 67.9 |  | $ | 1,455,501 |  |  | 63.6 |  | $ | 206,201 |  |  | 14.2 |  |
| Packet Networking | 229,223 |  |  | 9.4 |  | 244,116 |  |  | 10.7 |  | (14,893 | ) |  | (6.1 | ) |
| Optical Transport | 73,004 |  |  | 3.0 |  | 127,215 |  |  | 5.6 |  | (54,211 | ) |  | (42.6 | ) |
| Total Networking Platforms | 1,963,929 |  |  | 80.3 |  | 1,826,832 |  |  | 79.9 |  | 137,097 |  |  | 7.5 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 38,466 |  |  | 1.6 |  | 38,994 |  |  | 1.7 |  | (528 | ) |  | (1.4 | ) |
| Software-Related Services | 61,821 |  |  | 2.5 |  | 49,070 |  |  | 2.1 |  | 12,751 |  |  | 26.0 |  |
| Total Software and Software-Related Services | 100,287 |  |  | 4.1 |  | 88,064 |  |  | 3.8 |  | 12,223 |  |  | 13.9 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 224,079 |  |  | 9.2 |  | 217,032 |  |  | 9.5 |  | 7,047 |  |  | 3.2 |  |
| Installation and Deployment | 115,531 |  |  | 4.7 |  | 112,417 |  |  | 4.9 |  | 3,114 |  |  | 2.8 |  |
| Consulting and Network Design | 41,843 |  |  | 1.7 |  | 43,944 |  |  | 1.9 |  | (2,101 | ) |  | (4.8 | ) |
| Total Global Services | 381,453 |  |  | 15.6 |  | 373,393 |  |  | 16.3 |  | 8,060 |  |  | 2.2 |  |
| Consolidated revenue | $ | 2,445,669 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |  |

[0000936395-16-000128:mdna:128]
_________________________________

[0000936395-16-000128:mdna:129]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:130]
| • | Networking Platforms revenue increased, primarily reflecting increases of $206.2 million in sales of our Converged Packet Optical products, offset by a decrease of $54.2 million in sales of our Optical Transport products and $14.9 million in sales of our Packet Networking products. |

[0000936395-16-000128:mdna:131]
| ◦ | Converged Packet Optical sales reflect a $139.7 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures, and a $19.1 million increase in sales of the OTN configuration for the 5410 Reconfigurable Switching System. Increased revenue also reflects the addition of $81.0 million relating to the Z-Series Packet-Optical Platform acquired from Cyan. These increases were partially offset by decreases of $16.8 million in sales of our CoreDirector® Multiservice Optical Switches and $16.8 million in sales of our 5430 Reconfigurable Switching System. |

[0000936395-16-000128:mdna:132]
| ◦ | Packet Networking sales reflect decreases of $15.8 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $2.6 million in sales of our legacy broadband products. These decreases were offset by a $3.8 million increase in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014. |

[0000936395-16-000128:mdna:133]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-16-000128:mdna:134]
| • | Software and Software-Related Services revenue increased, primarily reflecting increases of $12.8 million in software-related services sales, primarily due to increased sales of software subscription services. |

[0000936395-16-000128:mdna:135]
51

[0000936395-16-000128:mdna:136]
| • | Global Services revenue increased, primarily reflecting increases of $7.0 million in sales of our maintenance support and training and $3.1 million in sales of our installation and deployment services. These increases were partially offset by a decrease of $2.1 million in sales of our consulting and network design services. |

[0000936395-16-000128:mdna:137]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-16-000128:mdna:138]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,598,328 |  |  | 65.4 |  | $ | 1,477,329 |  |  | 64.6 |  | $ | 120,999 |  |  | 8.2 |  |
| EMEA | 400,294 |  |  | 16.4 |  | 417,399 |  |  | 18.2 |  | (17,105 | ) |  | (4.1 | ) |
| CALA | 201,499 |  |  | 8.2 |  | 212,018 |  |  | 9.3 |  | (10,519 | ) |  | (5.0 | ) |
| APAC | 245,548 |  |  | 10.0 |  | 181,543 |  |  | 7.9 |  | 64,005 |  |  | 35.3 |  |
| Total | $ | 2,445,669 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |  |

[0000936395-16-000128:mdna:139]
_________________________________

[0000936395-16-000128:mdna:140]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:141]
| • | North America revenue includes sales to AT&T for fiscal 2015 and fiscal 2014 of $487.8 million and $423.5 million , respectively. Revenue reflects increases of $114.8 million within our Networking Platform segment and $5.7 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment reflects an increase of $184.0 million in Converged Packet Optical sales, partially offset by decreases of $38.2 million in Optical Transport sales and $31.0 million in sales of Packet Networking. Converged Packet Optical sales principally reflect a $106.8 million increase in sales of our 6500 Packet-Optical Platform due to increased sales to AT&T, cable and multiservice operators, and Web-scale providers, and a $76.3 million increase due to sales of our Z-Series Packet-Optical Platform. |

[0000936395-16-000128:mdna:142]
| • | EMEA revenue reflects decreases of $10.6 million within our Networking Platforms segment and $8.9 million within our Global Services segment, partially offset by an increase of $2.4 million within our Software and Software-Related Services segment. The revenue decrease within our Networking Platforms segment reflects a decrease of $13.2 million in Optical Transport sales partially offset by an increase of $2.2 million in sales of Converged Packet Optical sales. |

[0000936395-16-000128:mdna:143]
| • | CALA revenue reflects a decrease of $20.2 million within our Networking Platforms segment, partially offset by increases of $8.3 million within our Global Services segment and $1.4 million within our Software and Software-Related Services segment. The revenue decrease within our Networking Platforms segment primarily reflects a $20.6 million decrease in Converged Packet Optical sales. Converged Packet Optical sales reflect a $41.3 million decrease in sales of our 5430 Reconfigurable Switching System, partially offset primarily by a $15.5 million increase in sales of our 6500 Packet-Optical Platform primarily to certain communications service providers. Global Services sales reflect increases of $5.7 million in installation and deployment services sales, $1.4 million of maintenance support and training and $1.2 million in our consulting services sales. |

[0000936395-16-000128:mdna:144]
| • | APAC revenue reflects increases of $53.2 million within our Networking Platforms segment, $8.1 million within our Global Services segment and $2.7 million in Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment reflects product line increases of $40.6 million in Converged Packet Optical sales and $16.0 million in Packet Networking sales, partially offset by a decrease of $3.4 million in sales of Optical Transport. Converged Packet Optical sales reflect increases of $18.7 million of sales of our 6500 Packet-Optical Platform, $18.6 million of sales of our 5430 Reconfigurable Switching System, principally to communication service providers and submarine network operators, and $1.3 million of the Z-Series Packet-Optical Platform. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers, sales through our strategic relationship with Ericsson and sales to submarine network providers. |

[0000936395-16-000128:mdna:145]
Cost of Goods Sold and Gross Profit

[0000936395-16-000128:mdna:146]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-16-000128:mdna:147]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,445,669 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |
| Total cost of goods sold | 1,370,106 |  |  | 56.0 |  | 1,339,937 |  |  | 58.6 |  | 30,169 |  |  | 2.3 |
| Gross profit | $ | 1,075,563 |  |  | 44.0 |  | $ | 948,352 |  |  | 41.4 |  | $ | 127,211 |  |  | 13.4 |

[0000936395-16-000128:mdna:148]
_________________________________

[0000936395-16-000128:mdna:149]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:150]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,002,395 |  |  | 100.0 |  | $ | 1,865,826 |  |  | 100.0 |  | $ | 136,569 |  |  | 7.3 |
| Product cost of goods sold | 1,120,373 |  |  | 56.0 |  | 1,083,022 |  |  | 58.0 |  | 37,351 |  |  | 3.4 |
| Product gross profit | $ | 882,022 |  |  | 44.0 |  | $ | 782,804 |  |  | 42.0 |  | $ | 99,218 |  |  | 12.7 |

[0000936395-16-000128:mdna:151]
_________________________________

[0000936395-16-000128:mdna:152]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:153]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 443,274 |  |  | 100.0 |  | $ | 422,463 |  |  | 100.0 |  | $ | 20,811 |  |  | 4.9 |  |
| Service cost of goods sold | 249,733 |  |  | 56.3 |  | 256,915 |  |  | 60.8 |  | (7,182 | ) |  | (2.8 | ) |
| Service gross profit | $ | 193,541 |  |  | 43.7 |  | $ | 165,548 |  |  | 39.2 |  | $ | 27,993 |  |  | 16.9 |  |

[0000936395-16-000128:mdna:154]
_________________________________

[0000936395-16-000128:mdna:155]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:156]
| • | Gross profit as a percentage of revenue, or gross margin, increased as a result of the factors described below. |

[0000936395-16-000128:mdna:157]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, increased as a result of our success in driving product cost reductions and realizing improved manufacturing efficiencies as compared to the market-based price erosion we encountered during the period. |

[0000936395-16-000128:mdna:158]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, increased, primarily due to increased sales of higher margin software subscription services and reduced repair costs to support maintenance service contracts. |

[0000936395-16-000128:mdna:159]
Operating expense

[0000936395-16-000128:mdna:160]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-16-000128:mdna:161]
53

[0000936395-16-000128:mdna:162]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 414,201 |  |  | 16.9 |  | $ | 401,180 |  |  | 17.5 |  | $ | 13,021 |  |  | 3.2 |  |
| Selling and marketing | 333,836 |  |  | 13.7 |  | 328,325 |  |  | 14.3 |  | 5,511 |  |  | 1.7 |  |
| General and administrative | 123,402 |  |  | 5.0 |  | 126,824 |  |  | 5.5 |  | (3,422 | ) |  | (2.7 | ) |
| Amortization of intangible assets | 69,511 |  |  | 2.8 |  | 45,970 |  |  | 2.0 |  | 23,541 |  |  | 51.2 |  |
| Acquisition and integration costs | 25,539 |  |  | 1.0 |  | — |  |  | — |  | 25,539 |  |  | — |  |
| Restructuring costs | 8,626 |  |  | 0.4 |  | 349 |  |  | — |  | 8,277 |  |  | 2,371.6 |  |
| Total operating expenses | $ | 975,115 |  |  | 39.8 |  | $ | 902,648 |  |  | 39.3 |  | $ | 72,467 |  |  | 8.0 |  |

[0000936395-16-000128:mdna:163]
_________________________________

[0000936395-16-000128:mdna:164]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:165]
| • | Research and development expense benefited by $28.0 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $13.0 million, primarily reflecting increases of $8.6 million in facilities and information systems expense, $6.3 million in employee compensation and related costs, $1.2 million in technology and related expense and $1.1 million in depreciation expense. These increases were partially offset by decreases of $7.0 million in professional services and $2.3 million in prototype expense. Research and development expense also reflects a $4.5 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario as the maximum funding limit under this grant was met in the second quarter of fiscal 2015. |

[0000936395-16-000128:mdna:166]
| • | Selling and marketing expense benefited by $16.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expenses increased by $5.5 million, primarily reflecting increases of $10.4 million in employee compensation and related costs and $1.2 million in customer demonstration equipment. These increases were partially offset by decreases of $2.2 million in trade show and related costs, $2.2 million in travel and related costs, and $1.5 million in professional services. |

[0000936395-16-000128:mdna:167]
| • | General and administrative expense benefited by $4.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense decreased by $3.4 million, reflecting an $8.5 million decrease in legal fees, primarily due to certain patent litigation costs incurred during fiscal 2014. This decrease was partially offset by increases of $4.5 million in employee compensation and related costs and $1.0 million in facilities and information systems expense. |

[0000936395-16-000128:mdna:168]
| • | Amortization of intangible assets increased due to expense related to acquired intangible assets from our acquisition of Cyan during the fourth quarter of fiscal 2015. |

[0000936395-16-000128:mdna:169]
| • | Acquisition and integration costs increased, reflecting financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our acquisition of Cyan during fiscal 2015. |

[0000936395-16-000128:mdna:170]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. During fiscal 2015, we incurred approximately $8.6 million in restructuring costs, primarily reflecting a workforce reduction of approximately 125 employees in the first quarter of fiscal 2015 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-16-000128:mdna:171]
Other items

[0000936395-16-000128:mdna:172]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-16-000128:mdna:173]
|  | Fiscal Year |  |  |  |  |
|  | 2015 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (25,505 | ) |  | (1.0 | ) |  | $ | (25,262 | ) |  | (1.1 | ) |  | $ | (243 | ) |  | (1.0 | ) |
| Interest expense | $ | 51,179 |  |  | 2.1 |  |  | $ | 47,115 |  |  | 2.1 |  |  | $ | 4,064 |  |  | 8.6 |  |
| Provision for income taxes | $ | 12,097 |  |  | 0.5 |  |  | $ | 13,964 |  |  | 0.6 |  |  | $ | (1,867 | ) |  | (13.4 | ) |

[0000936395-16-000128:mdna:174]
_________________________________

[0000936395-16-000128:mdna:175]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:176]
| • | Interest and other income (loss), net reflects a $2.9 million increase in losses related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, offset by a $2.7 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 4.0% convertible senior notes due March 15, 2015, which matured during the second quarter of fiscal 2015. |

[0000936395-16-000128:mdna:177]
| • | Interest expense increased, primarily due to a higher level of outstanding debt in fiscal 2015 as compared to fiscal 2014. See Note 16 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report for more information. |

[0000936395-16-000128:mdna:178]
| • | Provision for income taxes was primarily due to foreign and state taxes. |

[0000936395-16-000128:mdna:179]
Segment Profit

[0000936395-16-000128:mdna:180]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-16-000128:mdna:181]
|  | Fiscal Year |  |  |
|  | 2016 |  | 2015 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 544,744 |  |  | $ | 515,550 |  |  | $ | 29,194 |  |  | 5.7 |
| Software and Software-Related Services | $ | 7,123 |  |  | $ | 4,174 |  |  | $ | 2,949 |  |  | 70.7 |
| Global Services | $ | 157,915 |  |  | $ | 141,638 |  |  | $ | 16,277 |  |  | 11.5 |

[0000936395-16-000128:mdna:182]
_________________________________

[0000936395-16-000128:mdna:183]
| * | Denotes % change from 2015 to 2016 |

[0000936395-16-000128:mdna:184]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin, partially offset by higher research and development costs. The improved gross margin was the result of product cost reductions, including on our WaveLogic coherent optical processor for 100G and 200G optical transport, partially offset by market-based price erosion |

[0000936395-16-000128:mdna:185]
| • | Software and Software-Related Services segment profit increased, primarily reflecting higher sales volume, partially offset by higher research and development costs and reduced gross margin from increased amortization of intangibles expense. Higher research and development costs reflect the addition of expenses relating to the development of our Blue Planet software platform. |

[0000936395-16-000128:mdna:186]
| • | Global Services segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin. The improved gross margin was the result of improved efficiencies for consulting and network design services. |

[0000936395-16-000128:mdna:187]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-16-000128:mdna:188]
55

[0000936395-16-000128:mdna:189]
|  | Fiscal Year |  |  |
|  | 2015 |  | 2014 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 515,550 |  |  | $ | 412,383 |  |  | $ | 103,167 |  |  | 25.0 |  |
| Software and Software-Related Services | $ | 4,174 |  |  | $ | 9,498 |  |  | $ | (5,324 | ) |  | (56.1 | ) |
| Global Services | $ | 141,638 |  |  | $ | 125,291 |  |  | $ | 16,347 |  |  | 13.0 |  |

[0000936395-16-000128:mdna:190]
_________________________________

[0000936395-16-000128:mdna:191]
| * | Denotes % change from 2014 to 2015 |

[0000936395-16-000128:mdna:192]
| • | Networking Platforms segment profit increased, due to increased sales volume, improved gross margin and reduced research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-16-000128:mdna:193]
| • | Software and Software-Related Services segment profit decreased due to increased research and development expense. Decreased segment profit was partially offset by increased sales volume, primarily due to increased sales of software subscription services. |

[0000936395-16-000128:mdna:194]
| • | Global Services segment profit increased, primarily due to improved gross margin and increased sales volume. The improved gross margin was primarily due to reduced repair costs to support maintenance service contracts. |

[0000936395-16-000128:mdna:195]
Liquidity and Capital Resources

[0000936395-16-000128:mdna:196]
For the fiscal year ended October 31, 2016, we generated $289.5 million in cash from operations. This amount was sufficient to fund our capital expenditures of $107.2 million for the purchase of equipment, furniture and fixtures and intellectual property, and our settlement of certain foreign currency forward contracts of $18.5 million. We further invested $4.0 million from cash on hand to fund an investment in securities of a privately-held company and $32.0 million to acquire the high-speed photonics components (“HSPC”) assets of TeraXion Inc. (“TeraXion”). For additional detail, see the discussion below entitled “Cash from Operations.”

[0000936395-16-000128:mdna:197]
As more fully described in Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report, during the second quarter of fiscal 2016 we entered into an Incremental Term Loan Credit Agreement that provided for a new tranche of senior secured term loans (under our existing Credit Agreement dated July 15, 2014) in an aggregate principal amount of $250 million maturing on April 25, 2021(“2021 Term Loan”). The net proceeds of approximately $246.1 million, plus existing cash and investments on hand, supported the repurchase during fiscal 2016 of approximately $262.5 million in face value of our 0.875% Convertible Senior Notes due June 15, 2017 (“2017 Notes”).We expect to repay the balance of this issuance with additional cash and investments on hand.

[0000936395-16-000128:mdna:198]
Our total cash, cash equivalents, and investments increased by $121.9 million during fiscal 2016 as our net cash from operations exceeded our investment activity, as well as the excess of our debt repurchases over the net proceeds of our 2021 Term Loan, and capital lease payments of $6.0 million, term loan installment payments of $3.6 million and debt issuance costs of $1.4 million related to our senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Proceeds from the issuance of equity under our employee stock purchase plans also provided approximately $23.1 million in cash. The effect of exchange rate changes resulted in a $2.4 million decrease in cash and cash equivalents. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-16-000128:mdna:199]
|  | October 31, |  | Increase |
|  | 2016 |  | 2015 |  | (decrease) |
| Cash and cash equivalents | $ | 777,615 |  |  | $ | 790,971 |  |  | $ | (13,356 | ) |
| Short-term investments in marketable debt securities | 275,248 |  |  | 135,107 |  |  | 140,141 |  |
| Long-term investments in marketable debt securities | 90,172 |  |  | 95,105 |  |  | (4,933 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,143,035 |  |  | $ | 1,021,183 |  |  | $ | 121,852 |  |

[0000936395-16-000128:mdna:200]
Our principal sources of liquidity on hand include our cash and investments, which as of October 31, 2016 totaled $1.1 billion, as well as our ABL credit facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based

[0000936395-16-000128:mdna:201]
revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 31, 2016, letters of credit totaling $65.1 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2016. Based on past performance and current expectations, we believe that cash from operations, cash and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and debt repayment obligations associated with our operations through at least the next 12 months.

[0000936395-16-000128:mdna:202]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $44.4 million as of October 31, 2016. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-16-000128:mdna:203]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. During fiscal 2016 we have repurchased approximately $262.5 million in aggregate principal amount of our outstanding 2017 Notes. For additional information about our convertible notes, including certain repurchases during fiscal 2015 and 2016, see Note 16 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-16-000128:mdna:204]
Cash from Operations

[0000936395-16-000128:mdna:205]
The following sections set forth the components of our $289.5 million of cash provided by operating activities for fiscal 2016:

[0000936395-16-000128:mdna:206]
Net income adjusted for non-cash charges

[0000936395-16-000128:mdna:207]
The following tables set forth (in thousands) our net income adjusted for non-cash charges during fiscal 2016:

[0000936395-16-000128:mdna:208]
|  | Year ended |
|  | October 31, 2016 |
| Net income | $ | 72,584 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 63,394 |  |
| Share-based compensation costs | 51,993 |  |
| Amortization of intangible assets | 78,298 |  |
| Provision for inventory excess and obsolescence | 33,713 |  |
| Provision for warranty | 15,483 |  |
| Other | 25,514 |  |
| Net income adjusted for non-cash charges | $ | 340,979 |  |

[0000936395-16-000128:mdna:209]
Working Capital

[0000936395-16-000128:mdna:210]
Our working capital used $51.5 million of cash during fiscal 2016. The following tables set forth (in thousands) the major components of the reduction in working capital:

[0000936395-16-000128:mdna:211]
|  | Year ended |
|  | October 31, 2016 |
| Cash used in accounts receivable | $ | (26,074 | ) |
| Cash used in inventories | (53,000 | ) |
| Cash provided by prepaid expenses and other | 30,047 |  |
| Cash provided by accounts payable, accruals and other obligations | 7,153 |  |
| Cash used in deferred revenue | (9,585 | ) |
| Cash used in working capital | $ | (51,459 | ) |

[0000936395-16-000128:mdna:212]
As compared to the end of fiscal 2015:

[0000936395-16-000128:mdna:213]
| • | The $26.1 million of cash used in accounts receivable during fiscal 2016 reflects the higher sales volume in the fourth quarter of fiscal 2016 compared to the fourth quarter of fiscal 2015; |

[0000936395-16-000128:mdna:214]
| • | The $53.0 million in cash used in inventory during fiscal 2016 primarily reflects increases in finished goods to meet expected customer deliveries for the beginning of the first quarter of fiscal 2017; |

[0000936395-16-000128:mdna:215]
| • | Cash provided by prepaid expenses and other during fiscal 2016 was $30.0 million, primarily reflecting payment of a financing receivable; |

[0000936395-16-000128:mdna:216]
| • | The $7.2 million of cash provided by accounts payable, accruals and other obligations during fiscal 2016 reflects increased inventory purchases at the end of fiscal 2016; and |

[0000936395-16-000128:mdna:217]
| • | The $9.6 million of cash used in deferred revenue represents an increase in the recognition of revenue for which we received advanced payments from customers. |

[0000936395-16-000128:mdna:218]
Our days sales outstanding (DSOs) improved slightly to 80 days for fiscal 2016 compared to 81 days for fiscal 2015. Our inventory turns decreased slightly from 5.9 turns during fiscal 2015 to 5.6 turns during fiscal 2016.

[0000936395-16-000128:mdna:219]
Cash paid for interest

[0000936395-16-000128:mdna:220]
The following tables set forth (in thousands) our interest paid during fiscal 2016:

[0000936395-16-000128:mdna:221]
|  | Year ended |
|  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 (1) | $ | 4,262 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (2) | 13,125 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 7,500 |  |
| Term Loan Payable due July 15, 2019 (4) | 9,354 |  |
| Term Loan Payable due April 25, 2021 (5) | 5,363 |  |
| Interest rate swaps (6) | 3,656 |  |
| ABL Credit Facility (7) | 1,762 |  |
| Capital leases | 1,875 |  |
| Total | $ | 46,897 |  |

[0000936395-16-000128:mdna:222]
| (1) | Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. |

[0000936395-16-000128:mdna:223]
| (2) | Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. |

[0000936395-16-000128:mdna:224]
| (3) | Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. |

[0000936395-16-000128:mdna:225]
| (4) | Interest on our outstanding Term Loan, due July 15, 2019 (the “2019 Term Loan), is payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bears interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. At the end of fiscal 2016, the interest rate on the 2019 Term Loan was 3.75%. |

[0000936395-16-000128:mdna:226]
58

[0000936395-16-000128:mdna:227]
| (5) | Interest on our outstanding 2021 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2021 Term Loan bears interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. At the end of fiscal 2016, the interest rate on the 2021 Term Loan was 4.25%. |

[0000936395-16-000128:mdna:228]
| (6) | Payments on our interest rate swaps are variable and effectively fix the total interest rate under the 2019 Term Loan at 5.00% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. |

[0000936395-16-000128:mdna:229]
| (7) | During fiscal 2016, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.8 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-16-000128:mdna:230]
For additional information about our convertible notes, term loans, ABL Credit Facility and interest rate swaps see Note 16 and 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-16-000128:mdna:231]
Contractual Obligations

[0000936395-16-000128:mdna:232]
The following is a summary of our future minimum payments under contractual obligations as of October 31, 2016 (in thousands):

[0000936395-16-000128:mdna:233]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 798,685 |  |  | $ | 231,558 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on term loans | 493,125 |  |  | 5,000 |  |  | 246,875 |  |  | 241,250 |  |  | — |  |
| Interest due on convertible notes | 62,026 |  |  | 22,651 |  |  | 28,125 |  |  | 11,250 |  |  | — |  |
| Interest due on term loans (2) | 72,486 |  |  | 19,942 |  |  | 36,976 |  |  | 15,568 |  |  | — |  |
| Payments due under interest rate swaps (2) | 10,989 |  |  | 4,640 |  |  | 5,342 |  |  | 1,007 |  |  | — |  |
| Operating leases (3) | 141,573 |  |  | 36,133 |  |  | 40,457 |  |  | 27,171 |  |  | 37,812 |  |
| Purchase obligations (4) | 247,119 |  |  | 247,119 |  |  | — |  |  | — |  |  | — |  |
| Capital leases - equipment | 5,145 |  |  | 2,034 |  |  | 2,973 |  |  | 138 |  |  | — |  |
| Capital leases - buildings (5) | 122,843 |  |  | 2,950 |  |  | 14,389 |  |  | 14,739 |  |  | 90,765 |  |
| Other obligations | 3,090 |  |  | 1,252 |  |  | 1,804 |  |  | 34 |  |  | — |  |
| Total (6) | $ | 1,957,081 |  |  | $ | 573,279 |  |  | $ | 726,941 |  |  | $ | 528,284 |  |  | $ | 128,577 |  |

[0000936395-16-000128:mdna:234]
_________________________________

[0000936395-16-000128:mdna:235]
| (1) | Includes the accretion of the principal amount on the 2020 Notes payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-16-000128:mdna:236]
| (2) | Interest on the term loans and payments under the interest rate swaps are variable and were calculated using the rate and applicable margin in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Note 16 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report. |

[0000936395-16-000128:mdna:237]
| (3) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-16-000128:mdna:238]
| (4) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-16-000128:mdna:239]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the excepted commencement of the lease term. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-16-000128:mdna:240]
| (6) | As of October 31, 2016, we also had approximately $14.1 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-16-000128:mdna:241]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit

[0000936395-16-000128:mdna:242]
Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2016 (in thousands):

[0000936395-16-000128:mdna:243]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 70,403 |  |  | $ | 27,732 |  |  | $ | 16,310 |  |  | $ | 12,617 |  |  | $ | 13,744 |  |

[0000936395-16-000128:mdna:244]
Off-Balance Sheet Arrangements

[0000936395-16-000128:mdna:245]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-16-000128:mdna:246]
Critical Accounting Policies and Estimates

[0000936395-16-000128:mdna:247]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-16-000128:mdna:248]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-16-000128:mdna:249]
Revenue Recognition

[0000936395-16-000128:mdna:250]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-16-000128:mdna:251]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of “actual costs incurred to date” to “total estimated costs expected to be incurred.” In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the fiscal years ended October 31, 2016, October 31, 2015 and October 31, 2014 were 0.3%, 1.8% and 4.0%, respectively.

[0000936395-16-000128:mdna:252]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-16-000128:mdna:253]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-16-000128:mdna:254]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence (“VSOE”) of selling price, if it exists, or third party evidence (“TPE”) of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price (“BESP”) for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-16-000128:mdna:255]
VSOE, when determinable, is established based on our pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. We have generally been unable to establish TPE of selling price because our go-to-market strategy differs from that of others in our markets, and the extent of customization and differentiated features and functions varies among comparable products or services from our peers. We determine BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-16-000128:mdna:256]
Our total deferred revenue for products was $45.2 million and $66.5 million as of October 31, 2016 and October 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $137.7 million and $122.5 million as of October 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000128:mdna:257]
Business Combinations

[0000936395-16-000128:mdna:258]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates. During fiscal 2015, we completed the Cyan acquisition for a purchase price of $335.7 million. During fiscal 2016, we completed the acquisition of TeraXion’s HSPC assets for a purchase price of $32.0 million. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-16-000128:mdna:259]
Share-Based Compensation

[0000936395-16-000128:mdna:260]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-16-000128:mdna:261]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 21 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2016, total unrecognized compensation expense was $70.2 million: (i) $0.6 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.5 years; and (ii) $69.6 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.

[0000936395-16-000128:mdna:262]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

[0000936395-16-000128:mdna:263]
Reserve for Inventory Obsolescence

[0000936395-16-000128:mdna:264]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in the sales of certain products, and general market conditions. We recorded charges for excess and obsolete inventory of $33.7 million, $26.8 million and $32.3 million in fiscal 2016, 2015 and 2014, respectively. The charges in fiscal 2016 were primarily related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. The charges in fiscal 2015 were primarily related to the discontinuance of certain parts and components used in the manufacture of our Converged Packet Optical products and a decrease in the forecasted demand for both our Optical Transport platforms and our 5410 Service Aggregation Switch. The charges in fiscal 2014 were primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Our inventory net of allowance for excess and obsolescence was $211.3 million and $191.2 million as of October 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000128:mdna:265]
Allowance for Doubtful Accounts Receivable

[0000936395-16-000128:mdna:266]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $576.2 million and $550.8 million as of October 31, 2016 and October 31, 2015, respectively. Our allowance for doubtful accounts was $4.0 million and $3.0 million as of October 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000128:mdna:267]
Goodwill

[0000936395-16-000128:mdna:268]
Our goodwill was generated from the acquisition of Cyan during fiscal 2015 and the acquisition of the HSPC assets from TeraXion during the second quarter of fiscal 2016, and is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-16-000128:mdna:269]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. At the end of fiscal 2016 and 2015, the goodwill balance was $267.0 million and $256.4 million, respectively. There were no goodwill impairments resulting from fiscal 2016 and 2015 impairment tests and no reporting unit was determined to be at risk of failing step one of the goodwill impairment test. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-16-000128:mdna:270]
Long-lived Assets

[0000936395-16-000128:mdna:271]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets, in-process research and development, and maintenance spares. As of October 31, 2016 and October 31, 2015 these assets totaled $484.7 million and $449.9 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-16-000128:mdna:272]
Deferred Tax Valuation Allowance

[0000936395-16-000128:mdna:273]
We provide a valuation allowance for our deferred tax assets in excess of deferred tax liabilities because we have concluded that it is more likely than not that such deferred tax assets will ultimately not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. We assess available positive and negative evidence regarding our ability to realize our deferred tax assets and record a valuation allowance when it is more likely than not that deferred tax assets will not be realized. To form a conclusion, management considers our recent financial results and trends and makes judgments and estimates related to projections of profitability, the timing and extent of the use of net operating loss carryforwards, and tax planning strategies. At October 31, 2016, we were not in a three-year cumulative loss position. However, management determined that a valuation allowance is still necessary, due to, among other things, the relatively low level of cumulative pre-tax income during this period — which was only initially achieved in the second half of fiscal 2016  — and our history of operating losses. We will continue to evaluate future financial performance to determine whether such profitability is both sustainable and significant enough to provide sufficient evidence to support reversal of all or a portion of the valuation allowance. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.  The valuation allowance balance at October 31, 2016 was $1.5 billion.

[0000936395-16-000128:mdna:274]
Warranty

[0000936395-16-000128:mdna:275]
Our liability for product warranties, included in other accrued liabilities, was $52.3 million and $56.7 million as of October 31, 2016 and October 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $15.5 million, $17.9 million and $22.1 million for fiscal 2016, 2015 and 2014 respectively. See Note 13 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-16-000128:mdna:276]
Effects of Recent Accounting Pronouncements

[0000936395-16-000128:mdna:277]
See Note 1 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-16-000128:mdna:278]
Unaudited Quarterly Results of Operations

[0000936395-16-000128:mdna:279]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2016. Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as “book to revenue”) has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-16-000128:mdna:280]
64

[0000936395-16-000128:mdna:281]
|  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |
|  | 2016 |  | 2016 |  | 2016 |  | 2016 |  | 2015 |  | 2015 |  | 2015 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 582,455 |  |  | $ | 553,450 |  |  | $ | 523,978 |  |  | $ | 457,589 |  |  | $ | 574,281 |  |  | $ | 493,919 |  |  | $ | 511,880 |  |  | $ | 422,315 |  |
| Services | 133,736 |  |  | 117,100 |  |  | 116,739 |  |  | 115,526 |  |  | 117,692 |  |  | 109,013 |  |  | 109,722 |  |  | 106,847 |  |
| Total Revenue | 716,191 |  |  | 670,550 |  |  | 640,717 |  |  | 573,115 |  |  | 691,973 |  |  | 602,932 |  |  | 621,602 |  |  | 529,162 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 324,663 |  |  | 299,381 |  |  | 291,778 |  |  | 260,482 |  |  | 323,090 |  |  | 273,837 |  |  | 286,898 |  |  | 236,548 |  |
| Services | 72,980 |  |  | 62,684 |  |  | 65,846 |  |  | 61,183 |  |  | 65,895 |  |  | 59,226 |  |  | 62,293 |  |  | 62,319 |  |
| Total costs of goods sold | 397,643 |  |  | 362,065 |  |  | 357,624 |  |  | 321,665 |  |  | 388,985 |  |  | 333,063 |  |  | 349,191 |  |  | 298,867 |  |
| Gross profit | 318,548 |  |  | 308,485 |  |  | 283,093 |  |  | 251,450 |  |  | 302,988 |  |  | 269,869 |  |  | 272,411 |  |  | 230,295 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 112,448 |  |  | 116,697 |  |  | 114,603 |  |  | 108,046 |  |  | 107,859 |  |  | 100,379 |  |  | 105,202 |  |  | 100,761 |  |
| Selling and marketing | 96,853 |  |  | 83,732 |  |  | 86,668 |  |  | 82,478 |  |  | 93,003 |  |  | 81,650 |  |  | 82,471 |  |  | 76,712 |  |
| General and administrative | 32,147 |  |  | 34,336 |  |  | 35,203 |  |  | 31,142 |  |  | 33,804 |  |  | 29,743 |  |  | 30,302 |  |  | 29,553 |  |
| Amortization of intangible assets | 14,551 |  |  | 14,529 |  |  | 15,566 |  |  | 16,862 |  |  | 36,454 |  |  | 11,019 |  |  | 11,019 |  |  | 11,019 |  |
| Acquisition and integration costs | — |  |  | 1,029 |  |  | 2,285 |  |  | 1,299 |  |  | 22,084 |  |  | 2,435 |  |  | 1,020 |  |  | — |  |
| Restructuring costs | 2,876 |  |  | 1,138 |  |  | 535 |  |  | 384 |  |  | 366 |  |  | 192 |  |  | (17 | ) |  | 8,085 |  |
| Total operating expenses | 258,875 |  |  | 251,461 |  |  | 254,860 |  |  | 240,211 |  |  | 293,570 |  |  | 225,418 |  |  | 229,997 |  |  | 226,130 |  |
| Income from operations | 59,673 |  |  | 57,024 |  |  | 28,233 |  |  | 11,239 |  |  | 9,418 |  |  | 44,451 |  |  | 42,414 |  |  | 4,165 |  |
| Interest and other income (loss), net | (1,339 | ) |  | (3,647 | ) |  | 967 |  |  | (8,776 | ) |  | (6,232 | ) |  | (5,491 | ) |  | (5,549 | ) |  | (8,233 | ) |
| Interest expense | (15,371 | ) |  | (15,967 | ) |  | (12,608 | ) |  | (12,710 | ) |  | (12,688 | ) |  | (11,883 | ) |  | (12,947 | ) |  | (13,661 | ) |
| Income (loss) before income taxes | 42,963 |  |  | 37,410 |  |  | 16,592 |  |  | (10,247 | ) |  | (9,502 | ) |  | 27,077 |  |  | 23,918 |  |  | (17,729 | ) |
| Provision for income tax | 6,376 |  |  | 3,864 |  |  | 2,595 |  |  | 1,299 |  |  | 4,330 |  |  | 3,452 |  |  | 3,265 |  |  | 1,050 |  |
| Net income (loss) | $ | 36,587 |  |  | $ | 33,546 |  |  | $ | 13,997 |  |  | $ | (11,546 | ) |  | $ | (13,832 | ) |  | $ | 23,625 |  |  | $ | 20,653 |  |  | $ | (18,779 | ) |
| Basic net income (loss) per common share | $ | 0.26 |  |  | $ | 0.24 |  |  | $ | 0.10 |  |  | $ | (0.08 | ) |  | $ | (0.10 | ) |  | $ | 0.20 |  |  | $ | 0.18 |  |  | $ | (0.17 | ) |
| Diluted net income (loss) per potential common share | $ | 0.25 |  |  | $ | 0.23 |  |  | $ | 0.10 |  |  | $ | (0.08 | ) |  | $ | (0.10 | ) |  | $ | 0.19 |  |  | $ | 0.17 |  |  | $ | (0.17 | ) |
| Weighted average basic common shares outstanding | 139,741 |  |  | 138,881 |  |  | 137,950 |  |  | 136,675 |  |  | 134,097 |  |  | 118,413 |  |  | 113,555 |  |  | 107,773 |  |
| Weighted average diluted potential common shares outstanding | 165,298 |  |  | 169,349 |  |  | 138,889 |  |  | 136,675 |  |  | 134,097 |  |  | 133,233 |  |  | 128,017 |  |  | 107,773 |  |
