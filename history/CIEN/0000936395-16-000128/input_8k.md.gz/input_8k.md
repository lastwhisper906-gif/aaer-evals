# CIEN 8-K — 0000936395-16-000124 filed 2016-12-08

## item codes, every 8-K on or before 2016-12-21

- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2016-12-21

- none on or before 2016-12-21

## item 2.02 — earnings release, exhibit 99.1

[0000936395-16-000124:8k_2_02:1]
EX-99.1
2
ex9912016q4pressrelease.htm
EXHIBIT 99.1 PRESS RELEASE

[0000936395-16-000124:8k_2_02:2]
Exhibit

[0000936395-16-000124:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-16-000124:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2016 and Year-End Financial Results

[0000936395-16-000124:8k_2_02:5]
HANOVER, Md. - December 8, 2016 - Ciena® Corporation (NYSE: CIEN), the network specialist, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2016.

[0000936395-16-000124:8k_2_02:6]
For the fiscal fourth quarter 2016, Ciena reported revenue of $716.2 million as compared to $692.0 million for the fiscal fourth quarter 2015. For fiscal year 2016, Ciena reported revenue of $2.6 billion, as compared to $2.4 billion for fiscal year 2015.

[0000936395-16-000124:8k_2_02:7]
On the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal fourth quarter 2016 was $36.6 million, or $0.25 per diluted common share, which compares to a GAAP net loss of $13.8 million, or $0.10 per diluted common share, for the fiscal fourth quarter 2015. For fiscal year 2016, Ciena had a GAAP net income of $72.6 million, or $0.51 per diluted common share, which compares to a GAAP net income of $11.7 million or $0.10 per diluted common share for fiscal year 2015.

[0000936395-16-000124:8k_2_02:8]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2016 was $69.4 million, or $0.44 per diluted common share, which compares to an adjusted (non-GAAP) net income of $67.3 million, or $0.42 per diluted common share, for the fiscal fourth quarter 2015. For fiscal year 2016, Ciena's adjusted (non-GAAP) net income was $214.6 million, or $1.38 per diluted common share, as compared to an adjusted (non-GAAP) net income of $179.0 million, or $1.31 per diluted common share for fiscal year 2015.

[0000936395-16-000124:8k_2_02:9]
“Our strong fiscal 2016 results demonstrate our increasingly differentiated performance versus our competitors, marking Ciena's seventh consecutive year of growing faster than the overall market as well as steady improvement in our operating leverage, profitability and cash flow,” said Gary Smith, president and CEO, Ciena. “We believe that the combination of our leading technology, strategic investments, global scale and business diversification will enable us to continue to take market share and drive operating leverage in fiscal 2017.”

[0000936395-16-000124:8k_2_02:10]
Fiscal Fourth Quarter 2016 Performance Summary

[0000936395-16-000124:8k_2_02:11]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarterly and year over year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendices A and B.

[0000936395-16-000124:8k_2_02:12]
|  |  | GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 716.2 |  |  | $ | 670.6 |  |  | $ | 692.0 |  |  | 6.8 | % |  | 3.5 | % |
| Gross margin |  | 44.5 | % |  | 46.0 | % |  | 43.8 | % |  | (1.5 | )% |  | 0.7 | % |
| Operating expense |  | $ | 258.9 |  |  | $ | 251.5 |  |  | $ | 293.6 |  |  | 2.9 | % |  | (11.8 | )% |
| Operating margin |  | 8.3 | % |  | 8.5 | % |  | 1.4 | % |  | (0.2 | )% |  | 6.9 | % |

[0000936395-16-000124:8k_2_02:13]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 716.2 |  |  | $ | 670.6 |  |  | $ | 692.0 |  |  | 6.8 | % |  | 3.5 | % |
| Adj. gross margin |  | 45.2 | % |  | 46.8 | % |  | 44.9 | % |  | (1.6 | )% |  | 0.3 | % |
| Adj. operating expense |  | $ | 232.4 |  |  | $ | 223.4 |  |  | $ | 220.5 |  |  | 4.0 | % |  | 5.4 | % |
| Adj. operating margin |  | 12.8 | % |  | 13.5 | % |  | 13.0 | % |  | (0.7 | )% |  | (0.2 | )% |

[0000936395-16-000124:8k_2_02:14]
* Denotes % change, or in the case of margin, absolute change

[0000936395-16-000124:8k_2_02:15]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q4 FY 2016 |  | Q3 FY 2016 |  | Q4 FY 2015 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 488.0 |  |  | 68.1 |  | $ | 467.6 |  |  | 69.7 |  | $ | 484.3 |  |  | 70.0 |
| Packet Networking |  | 72.4 |  |  | 10.1 |  | 63.7 |  |  | 9.5 |  | 63.7 |  |  | 9.2 |
| Optical Transport |  | 5.8 |  |  | 0.8 |  | 9.6 |  |  | 1.4 |  | 16.7 |  |  | 2.4 |
| Total Networking Platforms |  | 566.2 |  |  | 79.0 |  | 540.9 |  |  | 80.6 |  | 564.7 |  |  | 81.6 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms |  | 16.3 |  |  | 2.3 |  | 12.6 |  |  | 1.9 |  | 9.6 |  |  | 1.4 |
| Software-Related Services |  | 21.3 |  |  | 3.0 |  | 19.0 |  |  | 2.8 |  | 16.7 |  |  | 2.4 |
| Total Software and Software-Related Services |  | 37.6 |  |  | 5.3 |  | 31.6 |  |  | 4.7 |  | 26.3 |  |  | 3.8 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 59.8 |  |  | 8.3 |  | 56.0 |  |  | 8.4 |  | 57.2 |  |  | 8.3 |
| Installation and Deployment |  | 38.6 |  |  | 5.4 |  | 31.2 |  |  | 4.7 |  | 33.5 |  |  | 4.8 |
| Consulting and Network Design |  | 14.0 |  |  | 2.0 |  | 10.9 |  |  | 1.6 |  | 10.3 |  |  | 1.5 |
| Total Global Services |  | 112.4 |  |  | 15.7 |  | 98.1 |  |  | 14.7 |  | 101.0 |  |  | 14.6 |
| Total |  | $ | 716.2 |  |  | 100.0 |  | $ | 670.6 |  |  | 100.0 |  | $ | 692.0 |  |  | 100.0 |

[0000936395-16-000124:8k_2_02:16]
Additional Performance Metrics for Fiscal Fourth Quarter 2016

[0000936395-16-000124:8k_2_02:17]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q4 FY 2016 |  | Q3 FY 2016 |  | Q4 FY 2015 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 463.1 |  |  | 64.7 |  | $ | 438.0 |  |  | 65.3 |  | $ | 480.0 |  |  | 69.4 |
| Europe, Middle East and Africa |  | 112.5 |  |  | 15.7 |  | 104.3 |  |  | 15.6 |  | 94.0 |  |  | 13.6 |
| Caribbean and Latin America |  | 46.8 |  |  | 6.5 |  | 46.6 |  |  | 6.9 |  | 45.7 |  |  | 6.6 |
| Asia Pacific |  | 93.8 |  |  | 13.1 |  | 81.7 |  |  | 12.2 |  | 72.3 |  |  | 10.4 |
| Total |  | $ | 716.2 |  |  | 100.0 |  | $ | 670.6 |  |  | 100.0 |  | $ | 692.0 |  |  | 100.0 |

[0000936395-16-000124:8k_2_02:18]
| • | U.S. customers contributed 61% of total revenue |

[0000936395-16-000124:8k_2_02:19]
| • | One 10%-plus customer represented a total of 18.3% of revenue |

[0000936395-16-000124:8k_2_02:20]
| • | Cash and investments totaled $1.14 billion |

[0000936395-16-000124:8k_2_02:21]
| • | Cash flow from operations totaled $136.7 million |

[0000936395-16-000124:8k_2_02:22]
| • | Average days' sales outstanding (DSOs) were 72 |

[0000936395-16-000124:8k_2_02:23]
| • | Accounts receivable balance was $576.2 million |

[0000936395-16-000124:8k_2_02:24]
| • | Inventories totaled $211.3 million, including: |

[0000936395-16-000124:8k_2_02:25]
| ◦ | Raw materials: $44.6 million |

[0000936395-16-000124:8k_2_02:26]
| ◦ | Work in process: $12.9 million |

[0000936395-16-000124:8k_2_02:27]
| ◦ | Finished goods: $156.4 million |

[0000936395-16-000124:8k_2_02:28]
| ◦ | Deferred cost of sales: $59.9 million |

[0000936395-16-000124:8k_2_02:29]
| ◦ | Reserve for excess and obsolescence: $(62.5) million |

[0000936395-16-000124:8k_2_02:30]
| • | Product inventory turns were 6.1 |

[0000936395-16-000124:8k_2_02:31]
| • | Headcount totaled 5,555 |

[0000936395-16-000124:8k_2_02:32]
Business Outlook for Fiscal First Quarter 2017

[0000936395-16-000124:8k_2_02:33]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-16-000124:8k_2_02:34]
Ciena expects financial performance for fiscal first quarter 2017 to include:

[0000936395-16-000124:8k_2_02:35]
| • | Revenue in the range of $615 million to $645 million |

[0000936395-16-000124:8k_2_02:36]
| • | Adjusted (non-GAAP) gross margin in the mid-40s percentage range |

[0000936395-16-000124:8k_2_02:37]
| • | Adjusted (non-GAAP) operating expense in the range of $220 million to $225 million |

[0000936395-16-000124:8k_2_02:38]
Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2016 Results

[0000936395-16-000124:8k_2_02:39]
Ciena will host a discussion of its unaudited fiscal fourth quarter 2016 results with investors and financial analysts today, Thursday, December 8, 2016 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-16-000124:8k_2_02:40]
Notes to Investors

[0000936395-16-000124:8k_2_02:41]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our strong fiscal 2016 results demonstrate our increasingly differentiated performance versus our competitors, marking Ciena's seventh consecutive year of growing faster than the overall market as well as steady improvement in our operating leverage, profitability and cash flow."; "We believe that the combination of our leading technology, strategic investments, global scale and business diversification will enable us to continue to take market share and drive operating leverage in fiscal 2017." "Ciena expects fiscal first quarter 2017 financial performance to include: Revenue in the range of $615 million to $645 million; Adjusted (non-GAAP) gross margin in the mid-40s percentage range; Adjusted (non-GAAP) operating expense in the range of $220 million to $225 million."

[0000936395-16-000124:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on September 7, 2016. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-16-000124:8k_2_02:43]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. Adjustments made in calculating Adjusted (non-GAAP) net income do not result in any incremental income tax due to the availability of Ciena's deferred tax assets which would offset any additional income. As such, the tax effect of these adjustments is not presented as a separate reconciling item. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-16-000124:8k_2_02:44]
With respect to Ciena’s expectations under “Business Outlook for Fiscal First Quarter 2017” above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin and adjusted (non-GAAP) operating expense guidance measures to the corresponding gross profit and gross profit percentage, and operating expense GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty.  For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0000936395-16-000124:8k_2_02:45]
About Ciena.  Ciena (NYSE: CIEN) is a network strategy and technology company. We translate best-in-class technology into value through a high-touch, consultative business model - with a relentless drive to create exceptional experiences measured by outcomes. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-16-000124:8k_2_02:46]
CIENA CORPORATION

[0000936395-16-000124:8k_2_02:47]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-16-000124:8k_2_02:48]
(in thousands, except per share data)

[0000936395-16-000124:8k_2_02:49]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 582,455 |  |  | $ | 574,281 |  |  | $ | 2,117,472 |  |  | $ | 2,002,395 |  |
| Services |  | 133,736 |  |  | 117,692 |  |  | 483,101 |  |  | 443,274 |  |
| Total revenue |  | 716,191 |  |  | 691,973 |  |  | 2,600,573 |  |  | 2,445,669 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 324,663 |  |  | 323,090 |  |  | 1,176,304 |  |  | 1,120,373 |  |
| Services |  | 72,980 |  |  | 65,895 |  |  | 262,693 |  |  | 249,733 |  |
| Total cost of goods sold |  | 397,643 |  |  | 388,985 |  |  | 1,438,997 |  |  | 1,370,106 |  |
| Gross profit |  | 318,548 |  |  | 302,988 |  |  | 1,161,576 |  |  | 1,075,563 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 112,448 |  |  | 107,859 |  |  | 451,794 |  |  | 414,201 |  |
| Selling and marketing |  | 96,853 |  |  | 93,003 |  |  | 349,731 |  |  | 333,836 |  |
| General and administrative |  | 32,147 |  |  | 33,804 |  |  | 132,828 |  |  | 123,402 |  |
| Amortization of intangible assets |  | 14,551 |  |  | 36,454 |  |  | 61,508 |  |  | 69,511 |  |
| Acquisition and integration costs |  | — |  |  | 22,084 |  |  | 4,613 |  |  | 25,539 |  |
| Restructuring costs |  | 2,876 |  |  | 366 |  |  | 4,933 |  |  | 8,626 |  |
| Total operating expenses |  | 258,875 |  |  | 293,570 |  |  | 1,005,407 |  |  | 975,115 |  |
| Income from operations |  | 59,673 |  |  | 9,418 |  |  | 156,169 |  |  | 100,448 |  |
| Interest and other income (loss), net |  | (1,339 | ) |  | (6,232 | ) |  | (12,795 | ) |  | (25,505 | ) |
| Interest expense |  | (15,371 | ) |  | (12,688 | ) |  | (56,656 | ) |  | (51,179 | ) |
| Income (loss) before income taxes |  | 42,963 |  |  | (9,502 | ) |  | 86,718 |  |  | 23,764 |  |
| Provision for income taxes |  | 6,376 |  |  | 4,330 |  |  | 14,134 |  |  | 12,097 |  |
| Net income (loss) |  | $ | 36,587 |  |  | $ | (13,832 | ) |  | $ | 72,584 |  |  | $ | 11,667 |  |
| Net Income (loss) per Common Share |  |  |  |  |  |  |  |  |
| Basic net income (loss) per common share |  | $ | 0.26 |  |  | $ | (0.10 | ) |  | $ | 0.52 |  |  | $ | 0.10 |  |
| Diluted net income (loss) per potential common share1 |  | $ | 0.25 |  |  | $ | (0.10 | ) |  | $ | 0.51 |  |  | $ | 0.10 |  |
| Weighted average basic common shares outstanding |  | 139,741 |  |  | 134,097 |  |  | 138,312 |  |  | 118,416 |  |
| Weighted average diluted potential common shares outstanding 2 |  | 165,298 |  |  | 134,097 |  |  | 150,704 |  |  | 120,101 |  |

[0000936395-16-000124:8k_2_02:50]
1.  The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2016 requires adding back interest expense of approximately $0.7 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 and approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:51]
The calculation of GAAP diluted net income per common share for fiscal 2016 requires adding back interest expense of approximately $4.8 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:52]
2. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2016 includes 1.6 million shares underlying certain stock options and restricted stock units, 6.6 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017 and 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018.

[0000936395-16-000124:8k_2_02:53]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2016 includes 1.3 million shares underlying certain stock options and restricted stock units and 11.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-16-000124:8k_2_02:54]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units.

[0000936395-16-000124:8k_2_02:55]
CIENA CORPORATION

[0000936395-16-000124:8k_2_02:56]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-16-000124:8k_2_02:57]
(in thousands, except share data)

[0000936395-16-000124:8k_2_02:58]
|  | October 31, |
|  | 2016 |  | 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 777,615 |  |  | $ | 790,971 |  |
| Short-term investments | 275,248 |  |  | 135,107 |  |
| Accounts receivable, net | 576,235 |  |  | 550,792 |  |
| Inventories | 211,251 |  |  | 191,162 |  |
| Prepaid expenses and other | 172,843 |  |  | 196,178 |  |
| Total current assets | 2,013,192 |  |  | 1,864,210 |  |
| Long-term investments | 90,172 |  |  | 95,105 |  |
| Equipment, building, furniture and fixtures, net | 288,406 |  |  | 191,973 |  |
| Goodwill, net | 266,974 |  |  | 256,434 |  |
| Other intangible assets, net | 146,711 |  |  | 202,673 |  |
| Other long-term assets | 76,987 |  |  | 84,656 |  |
| Total assets | $ | 2,882,442 |  |  | $ | 2,695,051 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 235,942 |  |  | $ | 222,140 |  |
| Accrued liabilities and other short-term obligations | 310,353 |  |  | 316,283 |  |
| Deferred revenue | 109,009 |  |  | 126,111 |  |
| Current portion of long-term debt | 236,558 |  |  | 2,500 |  |
| Total current liabilities | 891,862 |  |  | 667,034 |  |
| Long-term deferred revenue | 73,854 |  |  | 62,962 |  |
| Other long-term obligations | 124,394 |  |  | 72,540 |  |
| Long-term debt, net | 1,025,991 |  |  | 1,271,639 |  |
| Total liabilities | $ | 2,116,101 |  |  | $ | 2,074,175 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 139,767,627 and 135,612,217 shares issued and outstanding | 1,398 |  |  | 1,356 |  |
| Additional paid-in capital | 6,715,478 |  |  | 6,640,436 |  |
| Accumulated other comprehensive loss | (24,329 | ) |  | (22,126 | ) |
| Accumulated deficit | (5,926,206 | ) |  | (5,998,790 | ) |
| Total stockholders’ equity | 766,341 |  |  | 620,876 |  |
| Total liabilities and stockholders’ equity | $ | 2,882,442 |  |  | $ | 2,695,051 |  |

[0000936395-16-000124:8k_2_02:59]
CIENA CORPORATION

[0000936395-16-000124:8k_2_02:60]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-16-000124:8k_2_02:61]
(in thousands)

[0000936395-16-000124:8k_2_02:62]
|  | Year Ended October 31, |
|  | 2016 |  | 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 72,584 |  |  | $ | 11,667 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 63,394 |  |  | 55,901 |  |
| Share-based compensation costs | 51,993 |  |  | 55,340 |  |
| Amortization of intangible assets | 78,298 |  |  | 79,866 |  |
| Provision for inventory excess and obsolescence | 33,713 |  |  | 26,846 |  |
| Provision for warranty | 15,483 |  |  | 17,881 |  |
| Other | 25,514 |  |  | 27,373 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (26,074 | ) |  | (37,297 | ) |
| Inventories | (53,000 | ) |  | 46,898 |  |
| Prepaid expenses and other | 30,047 |  |  | (46,383 | ) |
| Accounts payable, accruals and other obligations | 7,153 |  |  | (10,505 | ) |
| Deferred revenue | (9,585 | ) |  | 34,525 |  |
| Net cash provided by operating activities | 289,520 |  |  | 262,112 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (107,185 | ) |  | (62,109 | ) |
| Restricted cash | 11 |  |  | (40 | ) |
| Purchase of available for sale securities | (365,191 | ) |  | (245,323 | ) |
| Proceeds from maturities of available for sale securities | 230,612 |  |  | 205,000 |  |
| Settlement of foreign currency forward contracts, net | (18,506 | ) |  | 24,133 |  |
| Purchase of cost method investment | (4,000 | ) |  | (2,000 | ) |
| Acquisition of business, net of cash acquired | (32,000 | ) |  | 37,212 |  |
| Net cash used in investing activities | (296,259 | ) |  | (43,127 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | 248,750 |  |  | — |  |
| Payment of long-term debt | (266,116 | ) |  | (29,867 | ) |
| Payment of debt and equity issuance costs | (3,987 | ) |  | (421 | ) |
| Payment of capital lease obligations | (5,966 | ) |  | (8,038 | ) |
| Proceeds from issuance of common stock | 23,091 |  |  | 30,275 |  |
| Net cash used in financing activities | (4,228 | ) |  | (8,051 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (2,389 | ) |  | (6,683 | ) |
| Net increase in cash and cash equivalents | (13,356 | ) |  | 204,251 |  |
| Cash and cash equivalents at beginning of fiscal year | 790,971 |  |  | 586,720 |  |
| Cash and cash equivalents at end of fiscal year | $ | 777,615 |  |  | $ | 790,971 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 46,897 |  |  | $ | 40,772 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 15,268 |  |  | $ | 10,668 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 15,030 |  |  | $ | 20,922 |  |
| Equipment acquired under capital leases | $ | 5,322 |  |  | $ | 464 |  |
| Building subject to capital lease | $ | 8,993 |  |  | $ | 14,939 |  |
| Construction in progress subject to build-to-suit lease | $ | 39,914 |  |  | $ | 18,663 |  |
| Non-cash financing activities |  |  |  |
| Conversion of 4.0% convertible senior notes, due March 15, 2015 into 8,898,387 shares of common stock | $ | — |  |  | $ | 180,645 |  |
| Conversion of 8.0% convertible senior notes, due December 15, 2019, assumed from the Cyan acquisition, into 4,589,626 shares of common stock | $ | — |  |  | $ | 117,140 |  |
| Fair value of shares issued related to acquisition of business | $ | — |  |  | $ | 302,114 |  |

[0000936395-16-000124:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements (unaudited) |
|  |  | Quarter Ended |
|  |  | October 31, |
|  |  | 2016 |  | 2015 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 318,548 |  |  | $ | 302,988 |  |
| Share-based compensation-products |  | 612 |  |  | 589 |  |
| Share-based compensation-services |  | 557 |  |  | 573 |  |
| Amortization of intangible assets |  | 4,320 |  |  | 3,438 |  |
| Fair value adjustment of acquired inventory |  | — |  |  | 3,069 |  |
| Total adjustments related to gross profit |  | 5,489 |  |  | 7,669 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 324,037 |  |  | $ | 310,657 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 45.2 | % |  | 44.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 258,875 |  |  | $ | 293,570 |  |
| Share-based compensation-research and development |  | 3,172 |  |  | 3,850 |  |
| Share-based compensation-sales and marketing |  | 2,890 |  |  | 4,468 |  |
| Share-based compensation-general and administrative |  | 2,961 |  |  | 5,860 |  |
| Share-based compensation-acquisition and integration |  | — |  |  | 7,588 |  |
| Amortization of intangible assets |  | 14,551 |  |  | 36,454 |  |
| Acquisition and integration costs, excluding share-based compensation |  | — |  |  | 14,496 |  |
| Restructuring costs |  | 2,876 |  |  | 366 |  |
| Total adjustments related to operating expense |  | 26,450 |  |  | 73,082 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 232,425 |  |  | $ | 220,488 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 59,673 |  |  | $ | 9,418 |  |
| Total adjustments related to gross profit |  | 5,489 |  |  | 7,669 |  |
| Total adjustments related to operating expense |  | 26,450 |  |  | 73,082 |  |
| Adjusted (non-GAAP) income from operations |  | 91,612 |  |  | $ | 90,169 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 12.8 | % |  | 13.0 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income (loss) |  | $ | 36,587 |  |  | $ | (13,832 | ) |
| Total adjustments related to gross profit |  | 5,489 |  |  | 7,669 |  |
| Total adjustments related to operating expense |  | 26,450 |  |  | 73,082 |  |
| Loss on extinguishment of debt |  | 376 |  |  | — |  |
| Non-cash interest expense |  | 500 |  |  | 362 |  |
| Adjusted (non-GAAP) net income |  | $ | 69,402 |  |  | $ | 67,281 |  |
| Weighted average basic common shares outstanding |  | 139,741 |  |  | 134,097 |  |
| Weighted average dilutive potential common shares outstanding1 |  | 174,496 |  |  | 177,054 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | 0.25 |  |  | $ | (0.10 | ) |
| Adjusted (non-GAAP) diluted net income per common share2 |  | $ | 0.44 |  |  | $ | 0.42 |  |

[0000936395-16-000124:8k_2_02:64]
| APPENDIX B - Reconciliation of Adjusted (Non- GAAP) Annual Measurements (unaudited) |
|  |  | Year Ended |
|  |  | October 31, |
|  |  | 2016 |  | 2015 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 1,161,576 |  |  | $ | 1,075,563 |  |
| Share-based compensation-products |  | 2,457 |  |  | 2,400 |  |
| Share-based compensation-services |  | 2,479 |  |  | 2,156 |  |
| Amortization of intangible assets |  | 16,401 |  |  | 10,039 |  |
| Fair value adjustment of acquired inventory |  | — |  |  | 3,069 |  |
| Total adjustments related to gross profit |  | 21,337 |  |  | 17,664 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 1,182,913 |  |  | $ | 1,093,227 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 45.5 | % |  | 44.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 1,005,407 |  |  | $ | 975,115 |  |
| Share-based compensation-research and development |  | 13,870 |  |  | 10,665 |  |
| Share-based compensation-sales and marketing |  | 15,138 |  |  | 15,539 |  |
| Share-based compensation-general and administrative |  | 17,342 |  |  | 17,018 |  |
| Share-based compensation-acquisition and integration |  | 714 |  |  | 7,588 |  |
| Amortization of intangible assets |  | 61,508 |  |  | 69,511 |  |
| Acquisition and integration costs, excluding share-based compensation |  | 3,899 |  |  | 17,951 |  |
| Restructuring costs |  | 4,933 |  |  | 8,626 |  |
| Settlement of patent litigation |  | 1,200 |  |  | 500 |  |
| Total adjustments related to operating expense |  | 118,604 |  |  | 147,398 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 886,803 |  |  | $ | 827,717 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 156,169 |  |  | $ | 100,448 |  |
| Total adjustments related to gross profit |  | 21,337 |  |  | 17,664 |  |
| Total adjustments related to operating expense |  | 118,604 |  |  | 147,398 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 296,110 |  |  | $ | 265,510 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 11.4 | % |  | 10.9 | % |
| Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 72,584 |  |  | $ | 11,667 |  |
| Total adjustments related to gross profit |  | 21,337 |  |  | 17,664 |  |
| Total adjustments related to operating expense |  | 118,604 |  |  | 147,398 |  |
| Loss on extinguishment of debt |  | 226 |  |  | — |  |
| Non-cash expense associated with the conversion of convertible notes |  | — |  |  | 768 |  |
| Non-cash interest expense |  | 1,881 |  |  | 1,491 |  |
| Adjusted (non-GAAP) net income |  | $ | 214,632 |  |  | $ | 178,988 |  |
| Weighted average basic common shares outstanding |  | 138,312 |  |  | 118,416 |  |
| Weighted average dilutive potential common shares outstanding3 |  | 177,258 |  |  | 163,308 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.51 |  |  | $ | 0.10 |  |
| Adjusted (non-GAAP) diluted net income per common share4 |  | $ | 1.38 |  |  | $ | 1.31 |  |

[0000936395-16-000124:8k_2_02:65]
1.  Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2016 includes 1.6 million shares underlying certain stock options and restricted stock units, 6.6 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-16-000124:8k_2_02:66]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2015 includes 2.7 million shares underlying certain stock options and restricted stock units, 13.0 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018, 0.7 million shares underlying the 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-16-000124:8k_2_02:67]
2. The calculation of Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2016 requires adding back interest expense of approximately $0.7 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:68]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018, approximately $0.1 million associated with Ciena's 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:69]
3.   Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2016 includes 1.3 million shares underlying certain stock options and restricted stock units, 11.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-16-000124:8k_2_02:70]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units, 3.4 million shares underlying Ciena's 4.0% convertible senior notes (which were paid at maturity during the second quarter of fiscal 2015), 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018, 0.2 million shares underlying Ciena's 8.0% convertible senior notes assumed from the Cyan acquisition, due December 15, 2019, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-16-000124:8k_2_02:71]
4. The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2016 requires adding back interest expense of  approximately $4.8 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $14.3 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $11.4 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:72]
The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2015 requires adding back interest expense of approximately $3.2 million approximately associated with Ciena's 4.0% convertible senior notes (which were paid at maturity during the second quarter of fiscal 2015), approximately $5.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $14.3 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018, approximately $0.1 million associated with Ciena's 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and approximately $11.4 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000124:8k_2_02:73]
* * *

[0000936395-16-000124:8k_2_02:74]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-16-000124:8k_2_02:75]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-16-000124:8k_2_02:76]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our recent acquisitions of Cyan and TeraXion. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-16-000124:8k_2_02:77]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over the expected useful life. |

[0000936395-16-000124:8k_2_02:78]
| • | Fair value adjustment of acquired inventory - an infrequent charge required by acquisition accounting rules resulting from the required revaluation of inventory acquired from Cyan to estimated fair value. This revaluation resulted in a net increase in inventory carrying value and an increase in cost of goods sold for the period indicated. |

[0000936395-16-000124:8k_2_02:79]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-16-000124:8k_2_02:80]
| • | Settlement of patent litigation - included in general and administrative expense is a $1.2 million patent litigation settlement during the second quarter of fiscal 2016 and a $0.5 million patent litigation settlement during the third quarter of fiscal 2015. |

[0000936395-16-000124:8k_2_02:81]
| • | Loss on extinguishment of debt - a loss related to certain private repurchases conducted with several holders of Ciena's 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-16-000124:8k_2_02:82]
| • | Non-cash expense associated with the conversion of convertible notes - a non-cash expense related to certain private exchange offers conducted with several holders of Ciena's 4.0% senior convertible notes due March 15, 2015 prior to maturity of such notes. |

[0000936395-16-000124:8k_2_02:83]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |
