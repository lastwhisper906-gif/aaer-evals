# CIEN MD&A — 0001628280-26-060361


## mdna

[0001628280-26-060361:mdna:1]
[same as prior period, unchanged from 0001628280-26-040767:mdna:1]

[0001628280-26-060361:mdna:2]
[same as prior period, unchanged from 0001628280-26-040767:mdna:2]

[0001628280-26-060361:mdna:3]
[same as prior period, unchanged from 0001628280-26-040767:mdna:3]

[0001628280-26-060361:mdna:4]
[same as prior period, unchanged from 0001628280-26-040767:mdna:4]

[0001628280-26-060361:mdna:5]
[same as prior period, unchanged from 0001628280-26-040767:mdna:5]

[0001628280-26-060361:mdna:6]
[same as prior period, unchanged from 0001628280-26-040767:mdna:6]

[0001628280-26-060361:mdna:7]
[same as prior period, unchanged from 0001628280-26-040767:mdna:7]

[0001628280-26-060361:mdna:8]
Our industry has been experiencing unprecedented increases in demand, in particular due to capital expenditures related to AI and other cloud-based applications. As a result, we experienced strong momentum and growth in fiscal 2025 that continued in the first three quarters of fiscal 2026. As our sales to cloud providers grow, we are seeing a small number of those customers become a larger portion of our business across multiple revenue segments. Our revenue increased by 37% to $1.7 billion in the third quarter of fiscal 2026 as compared to $1.2 billion in the third quarter of fiscal 2025, with orders for our products and services significantly exceeding our revenue. This dynamic, together with an industry-wide constrained supply environment, has resulted in historically high backlog. As part of our efforts to secure both long-term supply and demand, we have, and are seeking to continue to, enter into multi-year supply agreements with certain of our suppliers, some of which involve firm purchase commitments and prepayment arrangements, and long-term purchase arrangements with customers.

[0001628280-26-060361:mdna:9]
[same as prior period, unchanged from 0001628280-26-040767:mdna:9]

[0001628280-26-060361:mdna:10]
Our gross margin increased to 45.4% in the third quarter of fiscal 2026, compared to 41.3% in the third quarter of fiscal 2025, primarily due to higher product gross margin associated with cost reduction, pricing optimization, product mix, and tariff refunds.

[0001628280-26-060361:mdna:11]
[same as prior period, unchanged from 0001628280-26-040767:mdna:11]

[0001628280-26-060361:mdna:12]
Our operating expense grew from $430 million in the third quarter of fiscal 2025 to $458 million in the third quarter of fiscal 2026. During the third quarter of fiscal 2026, we invested $237 million in research and development activities, an increase of 12% compared to the third quarter of fiscal 2025. We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets, which requires both investment capacity and expenditures. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we continued to increase the performance of and enhance the capabilities for our leading WaveLogicTM coherent modem technology, through which we seek to extend our leadership in optical networking, and leverage it to expand our addressable market, including inside and around the data center.

[0001628280-26-060361:mdna:13]
[same as prior period, unchanged from 0001628280-26-040767:mdna:13]

[0001628280-26-060361:mdna:14]
During the third quarter of fiscal 2026, we completed a convertible note offering of $2.9 billion and immediately used the proceeds to repay our term loan as described in Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0001628280-26-060361:mdna:15]
Our capital allocation strategy is focused on maintaining our significant innovation investment, investing in select transactions, and returning value to stockholders, while preserving our strategic and operational flexibility. We continuously work to improve our cash cycle and evaluate alternatives to manage our capital structure in order to enhance our liquidity. We ended the first nine months of fiscal 2026 with $2.8 billion of cash, cash equivalents, and investments. As of the end of the first nine months of fiscal 2026, cash generated from operations increased to $684 million as compared to $435 million as of the end of the first nine months of fiscal 2025. Consistent with our capital allocation priorities, during the first nine months of fiscal 2026, we invested $195 million in capital purchases, primarily for supply chain equipment and research and development, and $338 million and $278 million to repurchase shares through our share buyback program and for tax withholding purposes associated with employee stock awards, respectively.

[0001628280-26-060361:mdna:16]
[same as prior period, unchanged from 0001628280-26-040767:mdna:15]

[0001628280-26-060361:mdna:17]
[same as prior period, unchanged from 0001628280-26-040767:mdna:16]

[0001628280-26-060361:mdna:18]
[same as prior period, unchanged from 0001628280-26-040767:mdna:17]

[0001628280-26-060361:mdna:19]
[same as prior period, unchanged from 0001628280-26-040767:mdna:18]

[0001628280-26-060361:mdna:20]
[same as prior period, unchanged from 0001628280-26-040767:mdna:19]

[0001628280-26-060361:mdna:21]
As a result of the increased demand described above, our revenue increased by approximately 37% in the third quarter and first nine months of fiscal 2026 as compared to the third quarter and first nine months of fiscal 2025, or $451.7 million and $1.3 billion, respectively.

[0001628280-26-060361:mdna:22]
[same as prior period, unchanged from 0001628280-26-040767:mdna:21]

[0001628280-26-060361:mdna:23]
[same as prior period, unchanged from 0001628280-26-040767:mdna:22]

[0001628280-26-060361:mdna:24]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,191,307 |  |  | $ | 815,497 |  |  |  |  | 46.1 | % |  | $ | 3,314,317 |  |  | $ | 2,317,062 |  |  |  |  | 43.0 | % |
| %** | 71.3 | % |  | 66.9 | % |  |  |  |  |  | 71.0 | % |  | 67.8 | % |  |  |  |  |
| Routing and Switching | 164,368 |  |  | 125,857 |  |  |  |  | 30.6 | % |  | 464,604 |  |  | 311,749 |  |  |  |  | 49.0 | % |
| %** | 9.8 | % |  | 10.3 | % |  |  |  |  |  | 10.0 | % |  | 9.1 | % |  |  |  |  |
| Total Networking Platforms | 1,355,675 |  |  | 941,354 |  |  |  |  | 44.0 | % |  | 3,778,921 |  |  | 2,628,811 |  |  |  |  | 43.8 | % |
| %** | 81.1 | % |  | 77.2 | % |  |  |  |  |  | 81.0 | % |  | 76.9 | % |  |  |  |  |
| Platform Software and Services | 98,657 |  |  | 89,961 |  |  |  |  | 9.7 | % |  | 285,919 |  |  | 270,469 |  |  |  |  | 5.7 | % |
| %** | 5.9 | % |  | 7.4 | % |  |  |  |  |  | 6.1 | % |  | 7.9 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 23,205 |  |  | 27,805 |  |  |  |  | (16.5) | % |  | 66,986 |  |  | 81,787 |  |  |  |  | (18.1) | % |
| %** | 1.4 | % |  | 2.3 | % |  |  |  |  |  | 1.4 | % |  | 2.4 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning | 89,851 |  |  | 80,743 |  |  |  |  | 11.3 | % |  | 266,687 |  |  | 234,758 |  |  |  |  | 13.6 | % |
| %** | 5.4 | % |  | 6.6 | % |  |  |  |  |  | 5.7 | % |  | 6.9 | % |  |  |  |  |
| Implementation | 87,871 |  |  | 65,878 |  |  |  |  | 33.4 | % |  | 235,522 |  |  | 171,735 |  |  |  |  | 37.1 | % |
| %** | 5.3 | % |  | 5.4 | % |  |  |  |  |  | 5.0 | % |  | 5.0 | % |  |  |  |  |
| Advisory and Enablement | 15,870 |  |  | 13,644 |  |  |  |  | 16.3 | % |  | 34,875 |  |  | 29,963 |  |  |  |  | 16.4 | % |
| %** | 0.9 | % |  | 1.1 | % |  |  |  |  |  | 0.8 | % |  | 0.9 | % |  |  |  |  |
| Total Global Services | 193,592 |  |  | 160,265 |  |  |  |  | 20.8 | % |  | 537,084 |  |  | 436,456 |  |  |  |  | 23.1 | % |
| %** | 11.6 | % |  | 13.1 | % |  |  |  |  |  | 11.5 | % |  | 12.8 | % |  |  |  |  |
| Total revenue | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  |  |  | 37.0 | % |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |  |  |  | 36.6 | % |

[0001628280-26-060361:mdna:25]
[same as prior period, unchanged from 0001628280-26-040767:mdna:24]

[0001628280-26-060361:mdna:26]
[same as prior period, unchanged from 0001628280-26-040767:mdna:25]

[0001628280-26-060361:mdna:27]
[same as prior period, unchanged from 0001628280-26-040767:mdna:26]

[0001628280-26-060361:mdna:28]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:29]
•Networking Platforms segment revenue increased by $414.3 million.

[0001628280-26-060361:mdna:30]
•Optical Networking products revenue increased by $375.8 million, primarily driven by increases in sales of our 6500 Reconfigurable Line Systems (RLS), Waveserver® systems, and coherent pluggable transceivers.

[0001628280-26-060361:mdna:31]
•Routing and Switching products revenue increased by $38.5 million, primarily driven by an increase in sales of our 3000 and 5000 series of service delivery and aggregation platforms in our DCOM solution, partially offset by a sales decrease in our virtualization software.

[0001628280-26-060361:mdna:32]
•Platform Software and Services segment revenue increased by $8.7 million, primarily reflecting a sales increase in our Navigator Network Control Suite (“NCS”) software solution.

[0001628280-26-060361:mdna:33]
•Blue Planet Automation Software and Services segment revenue decreased by $4.6 million, primarily reflecting a sales decrease in our orchestration software.

[0001628280-26-060361:mdna:34]
•Global Services segment revenue increased by $33.3 million, primarily reflecting sales increases in our implementation services.

[0001628280-26-060361:mdna:35]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:36]
•Networking Platforms segment revenue increased by $1.2 billion.

[0001628280-26-060361:mdna:37]
•Optical Networking revenue increased by $997.3 million, primarily driven by increases in sales of our 6500 Reconfigurable Line Systems (RLS), Waveserver® systems, and coherent pluggable transceivers.

[0001628280-26-060361:mdna:38]
•Routing and Switching revenue increased by $152.9 million, primarily driven by increases in sales of our 3000 and 5000 series of service delivery and aggregation platforms, and 8100 Coherent IP networking platforms in our DCOM solution, partially offset by a sales decrease in our virtualization software.

[0001628280-26-060361:mdna:39]
•Platform Software and Services segment revenue increased by $15.5 million, primarily reflecting a sales increase in our Navigator NCS software solution, partially offset by decreases in sales of our software consulting services.

[0001628280-26-060361:mdna:40]
•Blue Planet Automation Software and Services segment revenue decreased by $14.8 million, primarily reflecting sales decreases in our unified assurance and analytics software and orchestration software.

[0001628280-26-060361:mdna:41]
•Global Services segment revenue increased by $100.6 million, primarily reflecting sales increases in our implementation services and maintenance support and learning services.

[0001628280-26-060361:mdna:42]
[same as prior period, unchanged from 0001628280-26-040767:mdna:41]

[0001628280-26-060361:mdna:43]
[same as prior period, unchanged from 0001628280-26-040767:mdna:42]

[0001628280-26-060361:mdna:44]
[same as prior period, unchanged from 0001628280-26-040767:mdna:43]

[0001628280-26-060361:mdna:45]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |
| Americas | $ | 1,316,796 |  |  | $ | 923,627 |  |  |  |  | 42.6 | % |  | $ | 3,637,233 |  |  | $ | 2,553,081 |  |  |  |  | 42.5 | % |
| %** | 78.8 | % |  | 75.7 | % |  |  |  |  |  | 77.9 | % |  | 74.7 | % |  |  |  |  |
| EMEA | 180,550 |  |  | 186,018 |  |  |  |  | (2.9) | % |  | 577,175 |  |  | 535,519 |  |  |  |  | 7.8 | % |
| %** | 10.8 | % |  | 15.3 | % |  |  |  |  |  | 12.4 | % |  | 15.7 | % |  |  |  |  |
| APAC | 173,783 |  |  | 109,740 |  |  |  |  | 58.4 | % |  | 454,502 |  |  | 328,923 |  |  |  |  | 38.2 | % |
| %** | 10.4 | % |  | 9.0 | % |  |  |  |  |  | 9.7 | % |  | 9.6 | % |  |  |  |  |
| Total | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  |  |  | 37.0 | % |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |  |  |  | 36.6 | % |

[0001628280-26-060361:mdna:46]
[same as prior period, unchanged from 0001628280-26-040767:mdna:45]

[0001628280-26-060361:mdna:47]
[same as prior period, unchanged from 0001628280-26-040767:mdna:46]

[0001628280-26-060361:mdna:48]
[same as prior period, unchanged from 0001628280-26-040767:mdna:47]

[0001628280-26-060361:mdna:49]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:50]
•Americas revenue increased by $393.2 million, primarily driven by increased sales to cloud provider customers in the United States.

[0001628280-26-060361:mdna:51]
•EMEA revenue decreased by $5.5 million, primarily driven by decreased sales to cloud provider customers in the Netherlands.

[0001628280-26-060361:mdna:52]
•APAC revenue increased by $64.0 million, primarily driven by increased sales in India, Singapore, and Australia.

[0001628280-26-060361:mdna:53]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:54]
•Americas revenue increased by $1.1 billion, primarily driven by increased sales to cloud provider customers and service provider customers in the United States.

[0001628280-26-060361:mdna:55]
•EMEA revenue increased by $41.7 million, primarily driven by increased sales to cloud provider customers in the Netherlands and service provider customers in Great Britain.

[0001628280-26-060361:mdna:56]
•APAC revenue increased by $125.6 million, primarily driven by increased sales in India, Singapore, and Australia.

[0001628280-26-060361:mdna:57]
[same as prior period, unchanged from 0001628280-26-040767:mdna:56]

[0001628280-26-060361:mdna:58]
During the third quarter and first nine months of fiscal 2026, approximately 10% and 9% of our revenue was non-U.S. Dollar-denominated, respectively. During the third quarter of fiscal 2026 as compared to the third quarter of fiscal 2025, and the first nine months of fiscal 2026 as compared to the first nine months of fiscal 2025, the U.S. Dollar fluctuated against other currencies with minimal impact.

[0001628280-26-060361:mdna:59]
[same as prior period, unchanged from 0001628280-26-040767:mdna:58]

[0001628280-26-060361:mdna:60]
[same as prior period, unchanged from 0001628280-26-040767:mdna:59]

[0001628280-26-060361:mdna:61]
[same as prior period, unchanged from 0001628280-26-040767:mdna:60]

[0001628280-26-060361:mdna:62]
[same as prior period, unchanged from 0001628280-26-040767:mdna:61]

[0001628280-26-060361:mdna:63]
[same as prior period, unchanged from 0001628280-26-040767:mdna:62]

[0001628280-26-060361:mdna:64]
[same as prior period, unchanged from 0001628280-26-040767:mdna:63]

[0001628280-26-060361:mdna:65]
|  | Quarter Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  |  |
|  | Revenue |  | Gross Margin (%)** |  | Revenue |  | Gross Margin (%)** |  | Revenue Change (%)* |  | Gross Margin Change |
| Total | $ | 1,671,129 |  |  | 45.4 | % |  | $ | 1,219,385 |  |  | 41.3 | % |  | 37.0 | % |  | 4.1 | % |
| Products | $ | 1,390,274 |  |  | 44.7 | % |  | $ | 976,801 |  |  | 40.6 | % |  | 42.3 | % |  | 4.1 | % |
| Services | $ | 280,855 |  |  | 49.0 | % |  | $ | 242,584 |  |  | 43.8 | % |  | 15.8 | % |  | 5.2 | % |
|  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  |  |
|  | Revenue |  | Gross Margin (%)** |  | Revenue |  | Gross Margin (%)** |  | Revenue Change (%)* |  | Gross Margin Change |
| Total | $ | 4,668,910 |  |  | 44.5 | % |  | $ | 3,417,523 |  |  | 41.8 | % |  | 36.6 | % |  | 2.7 | % |
| Products | $ | 3,881,632 |  |  | 44.1 | % |  | $ | 2,730,167 |  |  | 40.6 | % |  | 42.2 | % |  | 3.5 | % |
| Services | $ | 787,278 |  |  | 46.5 | % |  | $ | 687,356 |  |  | 46.3 | % |  | 14.5 | % |  | 0.2 | % |

[0001628280-26-060361:mdna:66]
[same as prior period, unchanged from 0001628280-26-040767:mdna:65]

[0001628280-26-060361:mdna:67]
[same as prior period, unchanged from 0001628280-26-040767:mdna:66]

[0001628280-26-060361:mdna:68]
[same as prior period, unchanged from 0001628280-26-040767:mdna:67]

[0001628280-26-060361:mdna:69]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:70]
•Gross margin increased by 410 basis points, reflecting increased product and services margin.

[0001628280-26-060361:mdna:71]
•Product gross margin increased by 410 basis points, primarily due to cost reductions, pricing optimization, product mix, and tariff recoveries, partially offset by lower manufacturing efficiencies and an increased provision for excess and obsolete inventory.

[0001628280-26-060361:mdna:72]
•Services gross margin increased by 520 basis points, primarily due to increased volume of higher margin implementation services.

[0001628280-26-060361:mdna:73]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:74]
•Gross margin increased by 270 basis points, primarily reflecting increased product margin.

[0001628280-26-060361:mdna:75]
•Product gross margin increased by 350 basis points, primarily due to pricing optimization, product mix, cost reductions, and tariff recoveries, partially offset by lower manufacturing efficiencies and increased provision for excess and obsolete inventory.

[0001628280-26-060361:mdna:76]
•Services gross margin remained relatively unchanged.

[0001628280-26-060361:mdna:77]
[same as prior period, unchanged from 0001628280-26-040767:mdna:76]

[0001628280-26-060361:mdna:78]
[same as prior period, unchanged from 0001628280-26-040767:mdna:77]

[0001628280-26-060361:mdna:79]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |
| Research and development | $ | 236,673 |  |  | $ | 211,898 |  |  |  |  | 11.7 | % |  | $ | 696,036 |  |  | $ | 619,429 |  |  |  |  | 12.4 | % |
| %** | 14.2 | % |  | 17.4 | % |  |  |  |  |  | 14.9 | % |  | 18.1 | % |  |  |  |  |
| Selling and marketing | 153,969 |  |  | 148,724 |  |  |  |  | 3.5 | % |  | 452,875 |  |  | 424,911 |  |  |  |  | 6.6 | % |
| %** | 9.2 | % |  | 12.2 | % |  |  |  |  |  | 9.7 | % |  | 12.4 | % |  |  |  |  |
| General and administrative | 62,844 |  |  | 60,596 |  |  |  |  | 3.7 | % |  | 183,308 |  |  | 171,450 |  |  |  |  | 6.9 | % |
| %** | 3.8 | % |  | 5.0 | % |  |  |  |  |  | 3.9 | % |  | 5.0 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 887 |  |  | 1,770 |  |  |  |  | (49.9) | % |  | 3,190 |  |  | 5,262 |  |  |  |  | (39.4) | % |
| %** | — | % |  | 0.1 | % |  |  |  |  |  | 0.1 | % |  | 0.2 | % |  |  |  |  |
| Amortization of intangible assets | 3,713 |  |  | 6,556 |  |  |  |  | (43.4) | % |  | 12,162 |  |  | 19,646 |  |  |  |  | (38.1) | % |
| %** | 0.2 | % |  | 0.5 | % |  |  |  |  |  | 0.3 | % |  | 0.6 | % |  |  |  |  |
| Acquisition and integration costs | — |  |  | — |  |  |  |  | — | % |  | 306 |  |  | — |  |  |  |  | 100.0 | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 458,086 |  |  | $ | 429,544 |  |  |  |  | 6.6 | % |  | $ | 1,347,877 |  |  | $ | 1,240,698 |  |  |  |  | 8.6 | % |
| %** | 27.4 | % |  | 35.2 | % |  |  |  |  |  | 28.9 | % |  | 36.3 | % |  |  |  |  |

[0001628280-26-060361:mdna:80]
[same as prior period, unchanged from 0001628280-26-040767:mdna:79]

[0001628280-26-060361:mdna:81]
[same as prior period, unchanged from 0001628280-26-040767:mdna:80]

[0001628280-26-060361:mdna:82]
[same as prior period, unchanged from 0001628280-26-040767:mdna:81]

[0001628280-26-060361:mdna:83]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:84]
•Research and development expense increased by $24.8 million. Net of hedging, this primarily reflects higher employee headcount and related costs, including from our acquisition of Nubis Communications and engineering design and development costs, prototype costs and technology-related costs.

[0001628280-26-060361:mdna:85]
•Selling and marketing expense increased by $5.2 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-060361:mdna:86]
•General and administrative expense increased by $2.2 million, which primarily reflects increases in professional services.

[0001628280-26-060361:mdna:87]
[same as prior period, unchanged from 0001628280-26-040767:mdna:86]

[0001628280-26-060361:mdna:88]
[same as prior period, unchanged from 0001628280-26-040767:mdna:87]

[0001628280-26-060361:mdna:89]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:90]
•Research and development expense increased by $76.6 million. Net of hedging, this primarily reflects higher employee headcount and related costs, including from our acquisition of Nubis Communications, engineering design and development costs and technology-related costs.

[0001628280-26-060361:mdna:91]
•Selling and marketing expense increased by $28.0 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-060361:mdna:92]
•General and administrative expense increased by $11.9 million, which primarily reflects increases in employee-related compensation costs and professional services.

[0001628280-26-060361:mdna:93]
•Significant asset impairments and restructuring costs decreased by $2.1 million primarily related to higher facilities restructuring costs in fiscal 2025.

[0001628280-26-060361:mdna:94]
•Amortization of intangible assets decreased by $7.5 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0001628280-26-060361:mdna:95]
•Acquisition and integration costs reflect financial, legal, and accounting advisory costs and certain employee-related costs related to our acquisition of Nubis Communications in the fourth quarter of fiscal 2025.

[0001628280-26-060361:mdna:96]
[same as prior period, unchanged from 0001628280-26-040767:mdna:95]

[0001628280-26-060361:mdna:97]
During both the third quarter and first nine months of fiscal 2026, approximately 51% of our operating expense was non-U.S. Dollar-denominated. During the third quarter and first nine months of fiscal 2026, as compared to the third quarter and first nine months of fiscal 2025, the U.S. Dollar fluctuated against other currencies. These currency fluctuations, net of hedging, had minimal impact.

[0001628280-26-060361:mdna:98]
[same as prior period, unchanged from 0001628280-26-040767:mdna:97]

[0001628280-26-060361:mdna:99]
[same as prior period, unchanged from 0001628280-26-040767:mdna:98]

[0001628280-26-060361:mdna:100]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 412,944 |  |  | $ | 199,445 |  |  |  |  | 107.0 | % |  | $ | 1,091,125 |  |  | $ | 533,029 |  |  |  |  | 104.7 | % |
| Platform Software and Services | $ | 66,690 |  |  | $ | 57,070 |  |  |  |  | 16.9 | % |  | $ | 190,853 |  |  | $ | 175,490 |  |  |  |  | 8.8 | % |
| Blue Planet Automation Software and Services | $ | 482 |  |  | $ | 6,366 |  |  |  |  | (92.4) | % |  | $ | (6,175) |  |  | $ | 19,342 |  |  |  |  | (131.9) | % |
| Global Services | $ | 79,142 |  |  | $ | 53,250 |  |  |  |  | 48.6 | % |  | $ | 202,279 |  |  | $ | 152,289 |  |  |  |  | 32.8 | % |

[0001628280-26-060361:mdna:101]
[same as prior period, unchanged from 0001628280-26-040767:mdna:100]

[0001628280-26-060361:mdna:102]
[same as prior period, unchanged from 0001628280-26-040767:mdna:101]

[0001628280-26-060361:mdna:103]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:104]
•Networking Platforms segment profit increased by $213.5 million, primarily due to higher sales volume and improved gross margin as described above, partially offset by higher research and development costs.

[0001628280-26-060361:mdna:105]
•Platform Software and Services segment profit increased by $9.6 million, primarily due to higher product sales volume, as described above, and improved services gross margin.

[0001628280-26-060361:mdna:106]
•Blue Planet Automation Software and Services segment decreased by $5.9 million, primarily due to lower software sales volume as described above and reduced product gross margin.

[0001628280-26-060361:mdna:107]
•Global Services segment profit increased by $25.9 million, primarily due to increased implementation sales and improved services gross margin as described above.

[0001628280-26-060361:mdna:108]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:109]
•Networking Platforms segment profit increased by $558.1 million, primarily due to higher sales volume and improved gross margin as described above, partially offset by higher research and development costs.

[0001628280-26-060361:mdna:110]
•Platform Software and Services segment profit increased by $15.4 million, primarily due to higher product sales and higher gross margin, partially offset by lower services sales volume and increased research and development costs.

[0001628280-26-060361:mdna:111]
•Blue Planet Automation Software and Services segment primarily reflects lower software sales volume as described above and reduced gross margins and increased research and development costs.

[0001628280-26-060361:mdna:112]
•Global Services segment profit increased by $50.0 million, primarily due to increased implementation sales and improved services gross margin as described above.

[0001628280-26-060361:mdna:113]
[same as prior period, unchanged from 0001628280-26-040767:mdna:112]

[0001628280-26-060361:mdna:114]
[same as prior period, unchanged from 0001628280-26-040767:mdna:113]

[0001628280-26-060361:mdna:115]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |  | August 1, 2026 |  | August 2, 2025 |  |  |  | %* |
| Interest and other income, net | $ | 22,388 |  |  | $ | 15,090 |  |  |  |  | 48.4 | % |  | $ | 49,456 |  |  | $ | 34,539 |  |  |  |  | 43.2 | % |
| %** | 1.3 | % |  | 1.2 | % |  |  |  |  |  | 1.1 | % |  | 1.0 | % |  |  |  |  |
| Interest expense | $ | 5,803 |  |  | $ | 22,806 |  |  |  |  | (74.6) | % |  | $ | 47,979 |  |  | $ | 67,421 |  |  |  |  | (28.8) | % |
| %** | 0.3 | % |  | 1.9 | % |  |  |  |  |  | 1.0 | % |  | 2.0 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | 7,143 |  |  | $ | — |  |  |  |  | 100.0 | % |  | $ | 7,143 |  |  | $ | 729 |  |  |  |  | 879.8 | % |
| %** | 0.4 | % |  | — | % |  |  |  |  |  | 0.2 | % |  | — | % |  |  |  |  |
| Provision for income taxes | $ | 44,203 |  |  | $ | 15,511 |  |  |  |  | 185.0 | % |  | $ | 87,875 |  |  | $ | 49,580 |  |  |  |  | 77.2 | % |
| %** | 2.6 | % |  | 1.3 | % |  |  |  |  |  | 1.9 | % |  | 1.5 | % |  |  |  |  |

[0001628280-26-060361:mdna:116]
[same as prior period, unchanged from 0001628280-26-040767:mdna:115]

[0001628280-26-060361:mdna:117]
[same as prior period, unchanged from 0001628280-26-040767:mdna:116]

[0001628280-26-060361:mdna:118]
[same as prior period, unchanged from 0001628280-26-040767:mdna:117]

[0001628280-26-060361:mdna:119]
Quarter ended August 1, 2026 as compared to the quarter ended August 2, 2025

[0001628280-26-060361:mdna:120]
•Interest and other income, net increased by $7.3 million, primarily resulting from higher interest income on our investments.

[0001628280-26-060361:mdna:121]
•Interest expense decreased by $17.0 million primarily due to refinancing of debt at a 0% interest rate, net of the effect of a related termination of interest rate swaps, see notes 12 and 13.

[0001628280-26-060361:mdna:122]
•Loss on extinguishment and modification of debt reflects the early extinguishment of our 2030 Term Loan in the third quarter of fiscal 2026, see note 13.

[0001628280-26-060361:mdna:123]
•Provision for income taxes increased by $28.7 million, primarily due to the increase in pre-tax book income.

[0001628280-26-060361:mdna:124]
Nine months ended August 1, 2026 as compared to the nine months ended August 2, 2025

[0001628280-26-060361:mdna:125]
•Interest and other income, net increased by $14.9 million, primarily resulting from higher interest income on our investments and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0001628280-26-060361:mdna:126]
•Interest expense decreased by $19.4 million, primarily due to refinancing debt at 0% interest rate, net of the effect of a related termination of interest rate swaps, see notes 12 and 13.

[0001628280-26-060361:mdna:127]
•Loss on extinguishment and modification of debt reflects the early extinguishment of our 2030 Term Loan in the third quarter of fiscal 2026 and refinancing of our 2030 Term Loan in the first quarter of fiscal 2025, see note 13.

[0001628280-26-060361:mdna:128]
•Provision for income taxes increased by $38.3 million, primarily due to the increase in pre-tax book income.

[0001628280-26-060361:mdna:129]
[same as prior period, unchanged from 0001628280-26-040767:mdna:127]

[0001628280-26-060361:mdna:130]
[same as prior period, unchanged from 0001628280-26-040767:mdna:128]

[0001628280-26-060361:mdna:131]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of August 1, 2026, totaled $2.8 billion, as well as our credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2030. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of August 1, 2026, letters of credit totaling $40.7 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of August 1, 2026.

[0001628280-26-060361:mdna:132]
Financing Arrangements. On June 11, 2026, we closed a private offering of $2.9 billion aggregate principal amount of 2031 Notes to qualified institutional buyers. The 2031 Notes will mature on September 15, 2031 unless earlier converted, redeemed or repurchased. Concurrently with the issuance of the 2031 Notes, we entered into convertible note hedge transactions that reduce potential dilution upon conversion of the notes and entered into warrant transactions to raise additional capital to partially offset the costs of entering into the convertible note hedge transactions. See Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report

[0001628280-26-060361:mdna:133]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $245.3 million as of August 1, 2026. Approximately $92.3 million of undistributed earnings from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability has been accrued to account for the anticipated repatriation amount. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0001628280-26-060361:mdna:134]
Stock Repurchases. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first nine months of fiscal 2026, we repurchased $335.3 million of our common stock under the stock repurchase program, and $335.0 million remained under the current repurchase authorization as of August 1, 2026. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. During the first nine months of fiscal 2026, we also repurchased $278.3 million of our common stock in settlement of employee tax withholding obligations due upon the vesting of stock unit awards. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as “Issuer Purchases of Equity Securities” in Item 2 of Part II of this report.

[0001628280-26-060361:mdna:135]
[same as prior period, unchanged from 0001628280-26-040767:mdna:132]

[0001628280-26-060361:mdna:136]
[same as prior period, unchanged from 0001628280-26-040767:mdna:133]

[0001628280-26-060361:mdna:137]
|  | August 1,2026 |  | November 1,2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 2,445,708 |  |  | $ | 1,091,952 |  |  | $ | 1,353,756 |  |
| Short-term investments in marketable debt securities | 184,293 |  |  | 216,148 |  |  | (31,855) |  |
| Long-term investments in marketable debt securities | 213,553 |  |  | 57,142 |  |  | 156,411 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 2,843,554 |  |  | $ | 1,365,242 |  |  | $ | 1,478,312 |  |

[0001628280-26-060361:mdna:138]
Cash, cash equivalents and investments increased by $1.5 billion during the first nine months of fiscal 2026. Operating activities generated $683.6 million of cash. In addition to the cash provided by operating activities, proceeds from the issuance of the 2031 Notes and the 2031 Warrants provided $1.6 billion in cash net of the following items: (i) repayment of the Refinanced 2030 Term Loan in full; (ii) 2031 Hedge Transaction purchase; and (iii) paid debt issuance costs. Proceeds from the issuance of equity under our employee stock purchase plan also provided $38.0 million in cash during the nine months ended August 1, 2026. The cash generated was partially offset by (i) cash used for stock repurchases under our stock repurchase program of $337.9 million; (ii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $278.3 million; and (iii) cash used to fund our investing activities for capital expenditures totaling $194.9 million during the nine months ended August 1, 2026.

[0001628280-26-060361:mdna:139]
For additional information about our debt transactions see Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0001628280-26-060361:mdna:140]
[same as prior period, unchanged from 0001628280-26-040767:mdna:136]

[0001628280-26-060361:mdna:141]
The following sections set forth the components of our $683.6 million of cash provided by operating activities during the first nine months of fiscal 2026. Net income (adjusted for non-cash charges) provided cash of $1.1 billion, offset by cash used in operating assets and liabilities of $410.4 million.

[0001628280-26-060361:mdna:142]
[same as prior period, unchanged from 0001628280-26-040767:mdna:138]

[0001628280-26-060361:mdna:143]
[same as prior period, unchanged from 0001628280-26-040767:mdna:139]

[0001628280-26-060361:mdna:144]
|  | Nine Months Ended |
|  | August 1, 2026 |
| Net income | $ | 634,921 |  |
| Adjustments for non-cash charges: |  |
| Loss on extinguishment of debt | 7,143 |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 102,347 |  |
| Share-based compensation expense | 163,178 |  |
| Amortization of intangible assets | 35,386 |  |
| Deferred taxes | 49,266 |  |
| Provision for inventory excess and obsolescence | 72,428 |  |
| Provision for warranty | 30,050 |  |
| Other | (724) |  |
| Net income (adjusted for non-cash charges) | $ | 1,093,995 |  |

[0001628280-26-060361:mdna:145]
[same as prior period, unchanged from 0001628280-26-040767:mdna:141]

[0001628280-26-060361:mdna:146]
Operating asset and liability requirements increased by $410.4 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0001628280-26-060361:mdna:147]
|  | Nine Months Ended |
|  | August 1, 2026 |
| Accounts receivable | $ | (251,531) |  |
| Inventories | (118,334) |  |
| Prepaid expenses and other | (111,567) |  |
| Accounts payable, accruals, and other obligations | 66,956 |  |
| Deferred revenue | 6,764 |  |
| Operating lease assets and liabilities, net | (2,677) |  |
| Total cash consumed by operating assets and liabilities | $ | (410,389) |  |

[0001628280-26-060361:mdna:148]
As compared to the end of fiscal 2025, for the first nine months of fiscal 2026:

[0001628280-26-060361:mdna:149]
•The change in accounts receivable primarily reflects increased sales volume and the timing of cash collections from customers;

[0001628280-26-060361:mdna:150]
•The change in inventory primarily reflects component purchases as part of our effort to optimize the cost and functioning of our supply chain;

[0001628280-26-060361:mdna:151]
•The change in prepaid expenses and other primarily reflects increases in non-trade receivables and prepaid income taxes;

[0001628280-26-060361:mdna:152]
•The change in accounts payable, accruals, and other obligations primarily reflects the timing of payments to suppliers, partially offset by the timing of payments associated with our annual incentive compensation plan;

[0001628280-26-060361:mdna:153]
•The change in deferred revenue primarily represents an increase in advanced payments received primarily on multi-year maintenance contracts from customers prior to revenue recognition; and

[0001628280-26-060361:mdna:154]
[same as prior period, unchanged from 0001628280-26-040767:mdna:150]

[0001628280-26-060361:mdna:155]
[same as prior period, unchanged from 0001628280-26-040767:mdna:151]

[0001628280-26-060361:mdna:156]
[same as prior period, unchanged from 0001628280-26-040767:mdna:152]

[0001628280-26-060361:mdna:157]
|  | Nine Months Ended |
|  | August 1, 2026 |
| Refinanced 2030 Term Loan due October 28, 2030(1) | $ | 40,991 |  |
| 2030 Senior Notes due January 31, 2030(2) | 16,000 |  |
| Interest rate swaps(3) | (1,703) |  |
| Revolving Credit Facility(4) | 1,102 |  |
| Finance leases | 2,322 |  |
| Cash paid during period | $ | 58,712 |  |

[0001628280-26-060361:mdna:158]
(1) The Refinanced 2030 Term Loan bore interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. The Refinanced 2030 Term Loan terminated on June 11, 2026.

[0001628280-26-060361:mdna:159]
[same as prior period, unchanged from 0001628280-26-040767:mdna:155]

[0001628280-26-060361:mdna:160]
(3) Our interest rate swaps fixed the SOFR rate for our Refinanced 2030 Term Loan through termination on June 11, 2026.

[0001628280-26-060361:mdna:161]
(4) During the first nine months of fiscal 2026, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0001628280-26-060361:mdna:162]
For additional information about our debt and interest rate swaps, see Notes 12, 13, and 14 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0001628280-26-060361:mdna:163]
[same as prior period, unchanged from 0001628280-26-040767:mdna:159]

[0001628280-26-060361:mdna:164]
[same as prior period, unchanged from 0001628280-26-040767:mdna:160]

[0001628280-26-060361:mdna:165]
Purchase Order Obligations. As of August 1, 2026, we had $3.3 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0001628280-26-060361:mdna:166]
[same as prior period, unchanged from 0001628280-26-040767:mdna:162]

[0001628280-26-060361:mdna:167]
[same as prior period, unchanged from 0001628280-26-040767:mdna:163]

[0001628280-26-060361:mdna:168]
[same as prior period, unchanged from 0001628280-26-040767:mdna:164]

[0001628280-26-060361:mdna:169]
[same as prior period, unchanged from 0001628280-26-040767:mdna:165]
