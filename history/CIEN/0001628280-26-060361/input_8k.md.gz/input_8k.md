# CIEN 8-K — 0001628280-26-060245 filed 2026-09-03

## item codes, every 8-K on or before 2026-09-03

- 2026-09-03 0001628280-26-060245 — 2.02, 9.01
- 2026-06-11 0001193125-26-267607 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2026-06-08 0001193125-26-260665 — 8.01, 9.01
- 2026-06-04 0001628280-26-040614 — 2.02, 9.01
- 2026-03-31 0001628280-26-022342 — 5.07
- 2026-03-05 0001628280-26-015006 — 2.02, 9.01
- 2025-12-11 0001628280-25-056425 — 2.02, 9.01
- 2025-12-04 0001628280-25-055133 — 5.02
- 2025-10-07 0001628280-25-044494 — 8.01
- 2025-09-22 0001628280-25-042266 — 8.01, 9.01
- 2025-09-04 0000936395-25-000037 — 2.02, 9.01
- 2025-06-18 0000936395-25-000029 — 5.02, 7.01, 9.01
- 2025-06-05 0000936395-25-000023 — 2.02, 9.01
- 2025-04-01 0000936395-25-000015 — 5.07
- 2025-03-11 0000936395-25-000005 — 2.02, 9.01
- 2025-01-21 0001193125-25-009588 — 1.01, 2.03, 9.01
- 2024-12-12 0000936395-24-000037 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2024-10-02 0000936395-24-000035 — 8.01, 9.01
- 2024-09-04 0000936395-24-000030 — 2.02, 5.02, 9.01
- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2026-09-03

- none on or before 2026-09-03

## item 2.02 — earnings release, exhibit 99.1

[0001628280-26-060245:8k_2_02:1]
EX-99.1
2
ex9912026q3earningspressre.htm
EX-99.1

[0001628280-26-060245:8k_2_02:2]
Document

[0001628280-26-060245:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001628280-26-060245:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2026 Financial Results

[0001628280-26-060245:8k_2_02:5]
Summary

[0001628280-26-060245:8k_2_02:6]
•Fiscal third quarter 2026 revenue was $1.67 billion, up 37% year-over-year

[0001628280-26-060245:8k_2_02:7]
•Fiscal third quarter 2026 adjusted Earnings Per Share (EPS) was $2.11, an increase of 215% compared to fiscal third quarter 2025

[0001628280-26-060245:8k_2_02:8]
•Providing revenue guidance for fiscal fourth quarter 2026 of $1.75 billion plus or minus $50 million

[0001628280-26-060245:8k_2_02:9]
•Raising revenue guidance for fiscal year 2026 to $6.42 billion plus or minus $50 million, a 35% increase year-over-year at the midpoint

[0001628280-26-060245:8k_2_02:10]
FULTON, Md. - September 3, 2026 - Ciena® Corporation (NYSE: CIEN) today announced financial results for its fiscal third quarter ended August 1, 2026.

[0001628280-26-060245:8k_2_02:11]
"Today’s outstanding financial performance demonstrates Ciena’s leadership in providing industry-leading, high-speed connectivity solutions as AI continues to drive compounding waves of network investment,” said Gary Smith, president and CEO, Ciena. “As the only pure-play optical systems and interconnects provider, Ciena’s unmatched combination of incumbency, technology innovation, and deep expertise gives us a powerful competitive edge."

[0001628280-26-060245:8k_2_02:12]
"Our record fiscal third quarter results reflect Ciena’s ability to deliver increasingly profitable growth while positioning for future opportunities,” said Marc Graff, Ciena’s Chief Financial Officer. “Our expanding supply capacity, strengthening business fundamentals, and increasing operating leverage set the stage to continue to accelerate earnings and deliver long-term value for customers and shareholders.”

[0001628280-26-060245:8k_2_02:13]
Performance Summary for Fiscal Third Quarter Ended August 1, 2026

[0001628280-26-060245:8k_2_02:14]
Revenue:

[0001628280-26-060245:8k_2_02:15]
•$1.67 billion in the fiscal third quarter 2026, compared to $1.22 billion in the fiscal third quarter 2025

[0001628280-26-060245:8k_2_02:16]
Net Income per diluted share:

[0001628280-26-060245:8k_2_02:17]
•$1.83 GAAP and $2.11 adjusted (non-GAAP) for the fiscal third quarter 2026, compared to $0.35 and $0.67 for fiscal third quarter 2025, respectively

[0001628280-26-060245:8k_2_02:18]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0001628280-26-060245:8k_2_02:19]
|  |  | GAAP Results (unaudited) |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Quarter Ended |  | Period |
|  |  | August 1, |  | August 2, |  | Change |  | August 1, |  | August 2, |  | Change |
|  |  | 2026 |  | 2025 |  | Y-T-Y* |  | 2026 |  | 2025 |  | Y-T-Y* |
| Revenue |  | $ | 1,671.1 |  |  | $ | 1,219.4 |  |  | 37.0 | % |  | $ | 1,671.1 |  |  | $ | 1,219.4 |  |  | 37.0 | % |
| Gross margin |  | 45.4 | % |  | 41.3 | % |  | 4.1 | % |  | 46.4 | % |  | 41.9 | % |  | 4.5 | % |
| Operating expense |  | $ | 458.1 |  |  | $ | 429.5 |  |  | 6.6 | % |  | $ | 400.0 |  |  | $ | 380.2 |  |  | 5.2 | % |
| Operating margin |  | 18.0 | % |  | 6.1 | % |  | 11.9 | % |  | 22.5 | % |  | 10.7 | % |  | 11.8 | % |
| EBITDA |  | $ | 349.9 |  |  | $ | 109.2 |  |  | 220.4 | % |  | $ | 411.1 |  |  | $ | 158.0 |  |  | 160.2 | % |

[0001628280-26-060245:8k_2_02:20]
*  Denotes % change, or in the case of margin, absolute change

[0001628280-26-060245:8k_2_02:21]
Business Outlook

[0001628280-26-060245:8k_2_02:22]
Ciena expects fiscal fourth quarter 2026 to include:

[0001628280-26-060245:8k_2_02:23]
•Revenue of $1.75B billion plus or minus $50 million

[0001628280-26-060245:8k_2_02:24]
•Adjusted (non-GAAP) gross margin in the range of 45% plus or minus 50 bps

[0001628280-26-060245:8k_2_02:25]
•Adjusted (non-GAAP) operating expense in the range of $415 million plus or minus $10 million

[0001628280-26-060245:8k_2_02:26]
•Adjusted (non-GAAP) operating margin in the range of 20% plus or minus 50 bps

[0001628280-26-060245:8k_2_02:27]
Financial Highlights for the Fiscal Third Quarter 2026

[0001628280-26-060245:8k_2_02:28]
•Two customers represented 10%-plus of revenue for a total of 41.7% of revenue.

[0001628280-26-060245:8k_2_02:29]
•Average days' sales outstanding (DSOs) were 76.

[0001628280-26-060245:8k_2_02:30]
•Inventory turns were 3.5.

[0001628280-26-060245:8k_2_02:31]
•Repurchased approximately 0.4 million shares of common stock for an aggregate price of $171.7 million under the $1 billion share repurchase program.

[0001628280-26-060245:8k_2_02:32]
Financial Performance by Segment

[0001628280-26-060245:8k_2_02:33]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | August 1, 2026 |  | August 2, 2025 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 1,191.3 |  |  | 71.3 |  |  | $ | 815.5 |  |  | 66.9 |  |
| Routing and Switching |  | 164.4 |  |  | 9.8 |  |  | 125.9 |  |  | 10.3 |  |
| Total Networking Platforms |  | 1,355.7 |  |  | 81.1 |  |  | 941.4 |  |  | 77.2 |  |
| Platform Software and Services |  | 98.6 |  |  | 5.9 |  |  | 90.0 |  |  | 7.4 |  |
| Blue Planet Automation Software and Services |  | 23.2 |  |  | 1.4 |  |  | 27.8 |  |  | 2.3 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning |  | 89.8 |  |  | 5.4 |  |  | 80.7 |  |  | 6.6 |  |
| Implementation |  | 87.9 |  |  | 5.3 |  |  | 65.9 |  |  | 5.4 |  |
| Advisory and Enablement |  | 15.9 |  |  | 0.9 |  |  | 13.6 |  |  | 1.1 |  |
| Total Global Services |  | 193.6 |  |  | 11.6 |  |  | 160.2 |  |  | 13.1 |  |
| Total |  | $ | 1,671.1 |  |  | 100.0 |  |  | $ | 1,219.4 |  |  | 100.0 |  |

[0001628280-26-060245:8k_2_02:34]
**  Denotes % of total revenue

[0001628280-26-060245:8k_2_02:35]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2026 Results

[0001628280-26-060245:8k_2_02:36]
Today, Thursday, September 3, 2026, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal third quarter 2026 results.

[0001628280-26-060245:8k_2_02:37]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com. An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0001628280-26-060245:8k_2_02:38]
3

[0001628280-26-060245:8k_2_02:39]
Notes to Investors

[0001628280-26-060245:8k_2_02:40]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include the "Business Outlook" section of this press release and "Today’s outstanding financial performance demonstrates Ciena’s leadership in providing industry-leading, high-speed connectivity solutions as AI continues to drive compounding waves of network investment. As the only pure-play optical systems and interconnects provider, Ciena’s unmatched combination of incumbency, technology innovation, and deep expertise gives us a powerful competitive edge. Our record fiscal third quarter results reflect Ciena’s ability to deliver increasingly profitable growth while positioning for future opportunities. Our expanding supply capacity, strengthening business fundamentals, and increasing operating leverage set the stage to continue to accelerate earnings and deliver long-term value for customers and shareholders.”

[0001628280-26-060245:8k_2_02:41]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our business and that of our customers, including their spending; the development and use of artificial intelligence and its impact on overall networking technology spending; our ability to execute our business and growth strategies; supply chain constraints or disruptions including increased costs and lead times; the introduction of new technologies by us or our competitors; the timing and size of customer orders, their delivery dates and our ability to fulfill and recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, and public health emergencies, epidemics, or pandemics; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Annual Report on Form 10-K filed with the SEC on December 12, 2025 and included in its Quarterly Report on Form 10-Q for the third quarter of fiscal 2026 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0001628280-26-060245:8k_2_02:42]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0001628280-26-060245:8k_2_02:43]
With respect to Ciena’s expectations under “Business Outlook” above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin, adjusted (non-GAAP) operating expense, and adjusted (non-GAAP) operating margin guidance measures to the corresponding gross margin, operating expense, and operating margin GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty. For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0001628280-26-060245:8k_2_02:44]
About Ciena. Ciena is the global leader in high-speed connectivity. We build the world’s most advanced networks to support exponential growth in bandwidth demand. By harnessing the power of our networking systems, interconnects, automation software, and services, Ciena revolutionizes data transmission and network management. With unparalleled expertise and innovation, we empower our customers, partners, and communities to thrive in the AI era. For updates on Ciena, follow us on LinkedIn, X, the Ciena Insights blog, or visit www.ciena.com.

[0001628280-26-060245:8k_2_02:45]
5

[0001628280-26-060245:8k_2_02:46]
CIENA CORPORATION

[0001628280-26-060245:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-26-060245:8k_2_02:48]
(in thousands, except per share data)

[0001628280-26-060245:8k_2_02:49]
(unaudited)

[0001628280-26-060245:8k_2_02:50]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 1,390,274 |  |  | $ | 976,801 |  |  | $ | 3,881,632 |  |  | $ | 2,730,167 |  |
| Services | 280,855 |  |  | 242,584 |  |  | 787,278 |  |  | 687,356 |  |
| Total revenue | 1,671,129 |  |  | 1,219,385 |  |  | 4,668,910 |  |  | 3,417,523 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 768,661 |  |  | 580,028 |  |  | 2,171,342 |  |  | 1,620,816 |  |
| Services | 143,203 |  |  | 136,278 |  |  | 421,229 |  |  | 368,969 |  |
| Total cost of goods sold | 911,864 |  |  | 716,306 |  |  | 2,592,571 |  |  | 1,989,785 |  |
| Gross profit | 759,265 |  |  | 503,079 |  |  | 2,076,339 |  |  | 1,427,738 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 236,673 |  |  | 211,898 |  |  | 696,036 |  |  | 619,429 |  |
| Selling and marketing | 153,969 |  |  | 148,724 |  |  | 452,875 |  |  | 424,911 |  |
| General and administrative | 62,844 |  |  | 60,596 |  |  | 183,308 |  |  | 171,450 |  |
| Significant asset impairments and restructuring costs | 887 |  |  | 1,770 |  |  | 3,190 |  |  | 5,262 |  |
| Amortization of intangible assets | 3,713 |  |  | 6,556 |  |  | 12,162 |  |  | 19,646 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 306 |  |  | — |  |
| Total operating expenses | 458,086 |  |  | 429,544 |  |  | 1,347,877 |  |  | 1,240,698 |  |
| Income from operations | 301,179 |  |  | 73,535 |  |  | 728,462 |  |  | 187,040 |  |
| Interest and other income, net | 22,388 |  |  | 15,090 |  |  | 49,456 |  |  | 34,539 |  |
| Interest expense | (5,803) |  |  | (22,806) |  |  | (47,979) |  |  | (67,421) |  |
| Loss on extinguishment and modification of debt | (7,143) |  |  | — |  |  | (7,143) |  |  | (729) |  |
| Income before income taxes | 310,621 |  |  | 65,819 |  |  | 722,796 |  |  | 153,429 |  |
| Provision for income taxes | 44,203 |  |  | 15,511 |  |  | 87,875 |  |  | 49,580 |  |
| Net income | $ | 266,418 |  |  | $ | 50,308 |  |  | $ | 634,921 |  |  | $ | 103,849 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 1.88 |  |  | $ | 0.35 |  |  | $ | 4.46 |  |  | $ | 0.73 |  |
| Diluted net income per potential common share | $ | 1.83 |  |  | $ | 0.35 |  |  | $ | 4.34 |  |  | $ | 0.72 |  |
| Weighted average basic common shares outstanding | 142,061 |  |  | 141,846 |  |  | 142,229 |  |  | 142,437 |  |
| Weighted average dilutive potential common shares outstanding1 | 145,967 |  |  | 144,499 |  |  | 146,227 |  |  | 145,158 |  |

[0001628280-26-060245:8k_2_02:51]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 3.9 million and 4.0 million for the third quarter and first nine months ended fiscal 2026, respectively; and (ii) 2.7 million for both the third quarter and first nine months ended fiscal 2025.

[0001628280-26-060245:8k_2_02:52]
`CIENA CORPORATION

[0001628280-26-060245:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-26-060245:8k_2_02:54]
(in thousands, except share data)

[0001628280-26-060245:8k_2_02:55]
(unaudited)

[0001628280-26-060245:8k_2_02:56]
|  | August 1, |  | November 1, |
|  | 2026 |  | 2025 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 2,445,708 |  |  | $ | 1,091,952 |  |
| Short-term investments | 184,293 |  |  | 216,148 |  |
| Accounts receivable, net | 1,233,610 |  |  | 975,856 |  |
| Inventories, net | 871,987 |  |  | 826,235 |  |
| Prepaid expenses and other | 527,014 |  |  | 455,316 |  |
| Total current assets | 5,262,612 |  |  | 3,565,507 |  |
| Long-term investments | 213,553 |  |  | 57,142 |  |
| Equipment, building, furniture and fixtures, net | 491,656 |  |  | 386,779 |  |
| Operating lease right-of-use assets | 45,667 |  |  | 38,613 |  |
| Goodwill | 513,340 |  |  | 521,204 |  |
| Other intangible assets, net | 188,824 |  |  | 224,210 |  |
| Deferred tax asset, net | 1,092,726 |  |  | 884,889 |  |
| Other long-term assets | 188,862 |  |  | 186,323 |  |
| Total assets | $ | 7,997,240 |  |  | $ | 5,864,667 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 654,070 |  |  | $ | 542,841 |  |
| Accrued liabilities and other short-term obligations | 508,149 |  |  | 531,081 |  |
| Deferred revenue | 211,453 |  |  | 208,936 |  |
| Operating lease liabilities | 12,261 |  |  | 13,956 |  |
| Current portion of long-term debt | — |  |  | 11,580 |  |
| Total current liabilities | 1,385,933 |  |  | 1,308,394 |  |
| Long-term deferred revenue | 99,828 |  |  | 94,850 |  |
| Other long-term obligations | 186,265 |  |  | 175,426 |  |
| Long-term operating lease liabilities | 38,633 |  |  | 32,516 |  |
| Long-term debt, net | 3,229,843 |  |  | 1,524,158 |  |
| Total liabilities | 4,940,502 |  |  | 3,135,344 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 141,897,511 and 141,016,300 shares issued and outstanding | 1,419 |  |  | 1,410 |  |
| Additional paid-in capital | 5,655,535 |  |  | 5,953,057 |  |
| Accumulated other comprehensive loss | (65,028) |  |  | (55,035) |  |
| Accumulated deficit | (2,535,188) |  |  | (3,170,109) |  |
| Total stockholders’ equity | 3,056,738 |  |  | 2,729,323 |  |
| Total liabilities and stockholders’ equity | $ | 7,997,240 |  |  | $ | 5,864,667 |  |

[0001628280-26-060245:8k_2_02:57]
7

[0001628280-26-060245:8k_2_02:58]
CIENA CORPORATION

[0001628280-26-060245:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-26-060245:8k_2_02:60]
(in thousands)

[0001628280-26-060245:8k_2_02:61]
(unaudited)

[0001628280-26-060245:8k_2_02:62]
|  | Nine Months Ended |
|  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 634,921 |  |  | $ | 103,849 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on extinguishment of debt | 7,143 |  |  | 159 |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 102,347 |  |  | 76,637 |  |
| Share-based compensation expense | 163,178 |  |  | 135,696 |  |
| Amortization of intangible assets | 35,386 |  |  | 26,343 |  |
| Deferred taxes | 49,266 |  |  | (21,709) |  |
| Provision for inventory excess and obsolescence | 72,428 |  |  | 34,185 |  |
| Provision for warranty | 30,050 |  |  | 16,302 |  |
| Other | (724) |  |  | (1,997) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (251,531) |  |  | (116,887) |  |
| Inventories | (118,334) |  |  | (73,493) |  |
| Prepaid expenses and other | (111,567) |  |  | 137,440 |  |
| Operating lease right-of-use assets | 7,956 |  |  | 8,759 |  |
| Accounts payable, accruals and other obligations | 66,956 |  |  | 83,354 |  |
| Deferred revenue | 6,764 |  |  | 38,246 |  |
| Short and long-term operating lease liabilities | (10,633) |  |  | (11,868) |  |
| Net cash provided by operating activities | 683,606 |  |  | 435,016 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, and fixtures | (194,893) |  |  | (95,373) |  |
| Purchases of investments | (325,629) |  |  | (191,335) |  |
| Proceeds from sales and maturities of investments | 203,097 |  |  | 261,611 |  |
| Settlement of foreign currency forward contracts, net | 2,259 |  |  | (2,635) |  |
| Net cash used in investing activities | (315,166) |  |  | (27,732) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds for modification of debt, net | — |  |  | 19,175 |  |
| Cash paid for extinguishment of debt | (1,140,930) |  |  | (19,175) |  |
| Payment of long term debt | (5,790) |  |  | (8,685) |  |
| Payment for convertible bond hedge | (988,425) |  |  | — |  |
| Proceeds from sale of warrants | 873,425 |  |  | — |  |
| Proceeds from issuance of convertible notes | 2,875,000 |  |  | — |  |
| Payment of debt issuance costs | (43,622) |  |  | (12) |  |
| Payment of finance lease obligations | (3,572) |  |  | (3,244) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (278,338) |  |  | (60,043) |  |
| Repurchases of common stock - repurchase program, net | (337,914) |  |  | (250,035) |  |
| Proceeds from issuance of common stock | 38,025 |  |  | 35,874 |  |
| Net cash provided by (used in) financing activities | 987,859 |  |  | (286,145) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (2,554) |  |  | 60 |  |
| Net increase in cash, cash equivalents and restricted cash | 1,353,745 |  |  | 121,199 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,092,197 |  |  | 935,026 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 2,445,942 |  |  | $ | 1,056,225 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 58,712 |  |  | $ | 68,243 |  |
| Cash paid during the period for income taxes, net | $ | 84,583 |  |  | $ | 84,898 |  |
| Operating lease payments | $ | 12,383 |  |  | $ | 13,246 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 24,987 |  |  | $ | 14,819 |  |
| Repurchase of common stock in accrued liabilities from repurchase program, net | $ | — |  |  | $ | 2,231 |  |
| Operating right-of-use assets subject to lease liability | $ | 16,144 |  |  | $ | 21,850 |  |

[0001628280-26-060245:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | August 1, |  | August 2, |  |  |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 759,265 |  |  | $ | 503,079 |  |  |  |  |  |
| Share-based compensation-products |  | 2,175 |  |  | 2,027 |  |  |  |  |  |
| Share-based compensation-services |  | 4,666 |  |  | 3,942 |  |  |  |  |  |
| Amortization of intangible assets |  | 9,652 |  |  | 2,232 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 16,493 |  |  | 8,201 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 775,758 |  |  | $ | 511,280 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 46.4 | % |  | 41.9 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 458,086 |  |  | $ | 429,544 |  |  |  |  |  |
| Share-based compensation-research and development |  | 20,173 |  |  | 16,749 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 16,623 |  |  | 13,277 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 14,241 |  |  | 11,008 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 887 |  |  | 1,770 |  |  |  |  |  |
| Amortization of intangible assets |  | 3,713 |  |  | 6,556 |  |  |  |  |  |
| Holdback arrangement |  | 2,419 |  |  | — |  |  |  |  |  |
| Total adjustments related to operating expense |  | 58,056 |  |  | 49,360 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 400,030 |  |  | $ | 380,184 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 301,179 |  |  | $ | 73,535 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 16,493 |  |  | 8,201 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 58,056 |  |  | 49,360 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 74,549 |  |  | 57,561 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 375,728 |  |  | $ | 131,096 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 22.5 | % |  | 10.7 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 266,418 |  |  | $ | 50,308 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 44,203 |  |  | 15,511 |  |  |  |  |  |
| Income before income taxes |  | 310,621 |  |  | 65,819 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 74,549 |  |  | 57,561 |  |  |  |  |  |
| Loss on extinguishment of debt |  | 7,143 |  |  | — |  |  |  |  |  |
| Gain on early termination of interest rate swaps |  | (7,720) |  |  | — |  |  |  |  |  |
| Adjusted income before income taxes |  | 384,593 |  |  | 123,380 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 76,919 |  |  | 27,144 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 307,674 |  |  | $ | 96,236 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 142,061 |  | 141,846 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 145,967 |  | 144,499 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 1.83 |  |  | $ | 0.35 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 2.11 |  |  | $ | 0.67 |  |  |  |  |  |

[0001628280-26-060245:8k_2_02:64]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 3.9 million for the third quarter ended fiscal 2026; and (ii) 2.7 million for the third quarter ended fiscal 2025.

[0001628280-26-060245:8k_2_02:65]
9

[0001628280-26-060245:8k_2_02:66]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | August 1, |  | August 2, |  |  |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 266,418 |  |  | $ | 50,308 |  |  |  |  |  |
| Add: Interest expense |  | 5,803 |  |  | 22,806 |  |  |  |  |  |
| Less: Interest and other income, net |  | 22,388 |  |  | 15,090 |  |  |  |  |  |
| Add: Loss on extinguishment of debt |  | 7,143 |  |  | — |  |  |  |  |  |
| Add: Provision for income taxes |  | 44,203 |  |  | 15,511 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 35,326 |  |  | 26,866 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 13,365 |  |  | 8,788 |  |  |  |  |  |
| EBITDA |  | $ | 349,870 |  |  | $ | 109,189 |  |  |  |  |  |
| Add: Share-based compensation expense |  | 57,878 |  |  | 47,003 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 887 |  |  | 1,770 |  |  |  |  |  |
| Add: Holdback arrangement |  | 2,419 |  |  | — |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 411,054 |  |  | $ | 157,962 |  |  |  |  |  |

[0001628280-26-060245:8k_2_02:67]
* * *

[0001628280-26-060245:8k_2_02:68]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0001628280-26-060245:8k_2_02:69]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0001628280-26-060245:8k_2_02:70]
•Significant asset impairments and restructuring costs - non-recurring costs primarily reflecting expenses associated with actions Ciena has taken to restructure our business, including reductions in force, facility optimization, and the redesign of business processes.

[0001628280-26-060245:8k_2_02:71]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0001628280-26-060245:8k_2_02:72]
•Holdback arrangement - reflects a one-time holdback of a portion of the merger consideration otherwise payable at closing to certain key employee shareholders of Nubis Communications, Inc. who became employees of Ciena, which is treated as contingent compensation for GAAP reporting purposes. These transaction-related amounts are not part of Ciena's standard compensation and benefits.

[0001628280-26-060245:8k_2_02:73]
•Loss on extinguishment of debt - reflects extinguishment expenses related to repayment of Ciena's term loan in connection with Ciena's convertible notes offering during the third quarter of fiscal 2026.

[0001628280-26-060245:8k_2_02:74]
•Gain on early termination of swaps - reflects the market value at settlement of Ciena's interest rate swaps designated as cash flow hedges which were terminated in parallel with the repayment of our refinanced 2030 term loan during the third quarter of fiscal 2026.

[0001628280-26-060245:8k_2_02:75]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20% for the third quarter of fiscal 2026 and 22% for the third quarter of fiscal 2025. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
