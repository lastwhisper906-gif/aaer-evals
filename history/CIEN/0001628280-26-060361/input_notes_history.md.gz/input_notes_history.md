# CIEN note change history — 0001628280-26-040767 → 0001628280-26-060361


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:1]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property-related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.
  (was, 2026-06-04, similarity 0.9982):
[0001628280-26-040767:note_history:1]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

- changed (2026-09-03):
[0001628280-26-060361:note_history:2]
Purchase Order Obligations 
Ciena has certain advanced orders for supply of certain long lead time components. As of August 1, 2026, Ciena had $3.3 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust a portion of these orders.
  (was, 2026-06-04, similarity 0.9872):
[0001628280-26-040767:note_history:2]
Purchase Order Obligations 
Ciena has certain advanced orders for supply of certain long lead time components. As of May 2, 2026, Ciena had $2.8 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust a portion of these orders.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:3]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Convertible Notes Payable
  (was, 2026-06-04, similarity 0.8571):
[0001628280-26-040767:note_history:3]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

- added (2026-09-03):
[0001628280-26-060361:note_history:4]
2031 Convertible Senior Notes

- added (2026-09-03):
[0001628280-26-060361:note_history:5]
On June 11, 2026, Ciena closed a private offering of $2.88 billion aggregate principal amount of 0.00% Convertible Senior Notes due 2031 (the “2031 Notes”) to qualified buyers, which includes $375.0 million aggregate principal amount of 2031 Notes issued in connection with the initial purchasers’ full exercise of their option to acquire additional 2031 Notes, pursuant to an indenture, dated June 11, 2026 (the “Indenture”). The 2031 Notes will not bear regular interest and the principal amount of the 2031 Notes will not accrete. The 2031 Notes will mature on September 15, 2031 unless earlier converted, redeemed or repurchased. Ciena intends to use the net proceeds in excess of the repayment of the Refinanced 2030 Term Loan described below, related fees, and expenses for general corporate purposes and investments to enhance supply chain capacity.  In addition, a portion of the proceeds from the 2031 Notes were used to repurchase $140.0 million, or approximately 0.3 million shares, of Ciena’s common stock pursuant to its existing stock repurchase program concurrent to settlement.

- added (2026-09-03):
[0001628280-26-060361:note_history:6]
The initial conversion rate for the 2031 Notes is 1.3393 shares of Ciena’s common stock per $1,000 principal amount of 2031 Notes, which is equivalent to an initial conversion price of approximately $746.66 per share. If certain corporate events occur prior to the maturity date, or if Ciena delivers a notice of redemption, Ciena will, in certain circumstances, increase the conversion rate.

- added (2026-09-03):
[0001628280-26-060361:note_history:7]
On or after September 20, 2029, Ciena has the option to redeem for cash all or any portion of the 2031 Notes if the last reported sale price of Ciena’s common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which Ciena provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2031 Notes to be redeemed plus accrued and unpaid interest to, but excluding, the redemption date. If Ciena redeems less than all the outstanding 2031 Notes, at least $100 million aggregate principal amount of the 2031 Notes must be outstanding and not subject to redemption as of the relevant redemption date.

- added (2026-09-03):
[0001628280-26-060361:note_history:8]
Prior to the close of business on the business day immediately preceding June 15, 2031, the 2031 Notes are convertible at the option of the holders only under the following circumstances:

- added (2026-09-03):
[0001628280-26-060361:note_history:9]
•at any time during the 30 consecutive trading day period beginning on, and including, the 21st trading day of any fiscal quarter commencing after the fiscal quarter ending on October 31, 2026, if the last reported sale price of Ciena’s common stock is greater than or equal to 130% of the conversion price for each of at least five trading days (whether or not consecutive) during the first 20 consecutive trading days of such fiscal quarter;

- added (2026-09-03):
[0001628280-26-060361:note_history:10]
•during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of 2031 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the common stock and the conversion rate on each such trading day;

- added (2026-09-03):
[0001628280-26-060361:note_history:11]
•if Ciena calls such 2031 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2031 Notes called (or deemed called) for redemption; or

- added (2026-09-03):
[0001628280-26-060361:note_history:12]
•upon the occurrence of certain corporate events, as specified in the Indenture.

- added (2026-09-03):
[0001628280-26-060361:note_history:13]
In addition, at any time on or after June 15, 2031, holders may convert their 2031 Notes at their option, and in multiples of $1,000 principal amount, without regard to the foregoing circumstances. Upon conversion, Ciena is required to satisfy its conversion obligation with respect to such converted 2031 Notes by delivering cash equal to the principal amount of such converted 2031 Notes and will settle any conversion value in excess in cash, shares of common stock or a combination of cash and shares of common stock, at Ciena’s election.

- added (2026-09-03):
[0001628280-26-060361:note_history:14]
Upon the occurrence of a fundamental change (as defined in the Indenture), subject to certain conditions, the holders of the 2031 Notes may require Ciena to repurchase for cash all or any portion of their 2031 Notes in multiples of $1,000 principal amount, at a repurchase price of the principal amount of the 2031 Notes to be purchased, plus accrued and unpaid interest to, but excluding the repurchase date.

- added (2026-09-03):
[0001628280-26-060361:note_history:15]
The Indenture contains customary covenants and events of default.

- changed (2026-09-03):
[0001628280-26-060361:note_history:16]
The net carrying value of Ciena’s convertible notes was comprised of the following as of the date indicated (in thousands):
  (was, 2026-06-04, similarity 0.9244):
[0001628280-26-040767:note_history:16]
The net carrying value of Ciena’s term loan was comprised of the following as of the date indicated (in thousands):

- added (2026-09-03):
[0001628280-26-060361:note_history:17]
|  |  | August 1, 2026 |  |  |
|  |  | Principal Balance |  |  |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2031 Notes |  | $ | 2,875,000 |  |  |  |  | $ | (42,794) |  |  | $ | 2,832,206 |  |  |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:18]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the convertible note. The amortization of deferred debt issuance costs for the 2031 Notes is included in interest expense and was minimal during the first nine months of fiscal 2026.
  (was, 2026-06-04, similarity 0.9):
[0001628280-26-040767:note_history:18]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first six months of fiscal 2026 and fiscal 2025.

- changed (2026-09-03):
[0001628280-26-060361:note_history:19]
As of August 1, 2026, the estimated fair value of the 2031 Convertible Notes was $2.7 billion. The 2031 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2031 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2026-06-04, similarity 0.9631):
[0001628280-26-040767:note_history:19]
As of May 2, 2026, the estimated fair value of the 2030 Notes was $382.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2026-09-03):
[0001628280-26-060361:note_history:20]
2031 Note Hedge Transactions

- added (2026-09-03):
[0001628280-26-060361:note_history:21]
On June 11, 2026, Ciena paid an aggregate amount of $988.4 million for convertible note hedge transactions entered into in connection with the issuance of the 2031 Notes (the “2031 Hedge Transactions”). The 2031 Hedge Transactions cover, subject to anti-dilution adjustments substantially similar to those in the 2031 Notes, approximately 3.9 million shares of Ciena’s common stock, which is the same number of shares initially underlying the 2031 Notes, at a strike price of $746.66, subject to customary adjustments. The 2031 Hedge Transactions will expire upon the maturity of the 2031 Notes, subject to earlier exercise or termination.

- added (2026-09-03):
[0001628280-26-060361:note_history:22]
The 2031 Hedge Transactions are expected generally to reduce the potential dilutive effect of the conversion of the 2031 Notes and/or offset any cash payments Ciena makes in excess of the principal amount of the converted 2031 Notes, in the event that the market price per share of Ciena’s common stock, as measured under the terms of the 2031 Hedge Transactions, is greater than the 2031 Hedge Transactions strike price of $746.66. The 2031 Hedge Transactions meet the criteria in ASC 815-40 to be classified within Stockholders' Equity, and therefore these transactions are not revalued after their issuance.

- added (2026-09-03):
[0001628280-26-060361:note_history:23]
Ciena made a tax election to integrate the 2031 Notes and the 2031 Hedge Transactions. As a result of this election, Ciena expects the cost of the 2031 Hedge Transactions to be deductible as original issue discount interest for tax purposes over the term of the 2031 Notes. Ciena recorded a $230.0 million deferred tax asset with a corresponding adjustment to additional paid-in capital on our Condensed Consolidated Balance Sheet.

- added (2026-09-03):
[0001628280-26-060361:note_history:24]
Warrant Transactions

- added (2026-09-03):
[0001628280-26-060361:note_history:25]
On June 11, 2026, concurrently with entering into the 2031 Hedge Transactions, Ciena separately entered into privately-negotiated warrant transactions (the “2031 Warrant Transactions”), whereby Ciena sold to the counterparties warrants (the “2031 Warrants”) to purchase, subject to anti-dilution adjustments, 3.9 million shares, of its common stock at an initial strike price of $1,000 per share. Ciena received aggregate proceeds of $873.4 million from the 2031 Warrant Transactions with the counterparties. The 2031 Warrants expire in December 2031.

- added (2026-09-03):
[0001628280-26-060361:note_history:26]
If the market value per share of the common stock exceeds the strike price of the 2031 Warrants, the 2031 Warrants will have a dilutive effect on our earnings per share, unless Ciena elects, subject to certain conditions, to settle the 2031 Warrants in cash. The 2031 Warrants meet the criteria in ASC 815-40 to be classified within Stockholders' Equity, and therefore the 2031 Warrants are not revalued after issuance.

- added (2026-09-03):
[0001628280-26-060361:note_history:27]
Term Loan Payable

- changed (2026-09-03):
[0001628280-26-060361:note_history:28]
On June 11, 2026, outstanding amounts under Ciena’s Refinanced 2030 Term Loan due October 28, 2030 were repaid in full. The net carrying value of the Refinanced 2030 Term Loan as of November 1, 2025 was $1.14 billion. Deferred debt issuance costs were amortized using the straight-line method, which approximated the effect of the effective interest rate method, through the maturity of the Refinanced 2030 Term Loan. The amortization of deferred debt issuance costs for the Refinanced 2030 Term Loan was included in interest expense, and was minimal during both the first nine months of fiscal 2026 and fiscal 2025.
  (was, 2026-06-04, similarity 0.6351):
[0001628280-26-040767:note_history:28]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during both the first six months of fiscal 2026 and fiscal 2025.

- added (2026-09-03):
[0001628280-26-060361:note_history:29]
The proceeds from Ciena’s 2031 Notes were used to repay the full $1.14 billion for the outstanding principal of the Refinanced 2030 Term Loan, including accrued interest.

- changed (2026-09-03):
[0001628280-26-060361:note_history:30]
|  |  | August 1, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,363) |  |  | $ | 397,637 |  |  | $ | 397,119 |  |  |  |
  (was, 2026-06-04, similarity 0.9788):
[0001628280-26-040767:note_history:30]
|  |  | May 2, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,535) |  |  | $ | 397,465 |  |  | $ | 397,119 |  |  |  |

- added (2026-09-03):
[0001628280-26-060361:note_history:31]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first nine months of fiscal 2026 and fiscal 2025.

- added (2026-09-03):
[0001628280-26-060361:note_history:32]
As of August 1, 2026, the estimated fair value of the 2030 Notes was $379.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
REVOLVING CREDIT FACILITY
On February 10, 2023, pursuant to an ABL Credit Agreement dated October 28, 2019, as amended (the “ABL Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto (the “ABL Lenders”), and Bank of America, as administrative agent, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provided for a total commitment of $300.0 million to extend its maturity date to September 28, 2025.

- added (2026-09-03):
[0001628280-26-060361:note_history:33]
On October 24, 2023, pursuant to the Incremental Amendment Agreement to the Credit Agreement among Ciena, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC, and Blue Planet Software, Inc., as guarantors, Ciena incurred a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”), which replaced the ABL Credit Facility.

- added (2026-09-03):
[0001628280-26-060361:note_history:34]
On June 11, 2026, and in connection with the 2031 Notes offering (as defined in Note 13 above) Ciena, modified its Revolving Credit Facility to amend by, among other things:

- added (2026-09-03):
[0001628280-26-060361:note_history:35]
•extending the maturity date of the Revolving Credit Facility from October 24, 2028 to October 24, 2030;

- added (2026-09-03):
[0001628280-26-060361:note_history:36]
•removing the credit spread adjustment applicable to SOFR-based borrowings under the Revolving Credit Facility;

- added (2026-09-03):
[0001628280-26-060361:note_history:37]
•adding daily SOFR as an interest rate option for borrowings under the Revolving Credit Facility;

- added (2026-09-03):
[0001628280-26-060361:note_history:38]
•providing that the outstanding borrowings under the Revolving Credit Facility bear interest, at Ciena’s election, at a rate per annum (which is subject to increase during an event of default) of, at Ciena’s option, either term SOFR or daily SOFR (subject to a floor of 0.00%) plus a margin ranging from 1.25% to 2.00%, as applicable, or a base rate (subject to a floor of 1.00%) plus a margin ranging from 0.25% to 1.00%, in each case, with such interest rate margin based on Ciena’s consolidated net leverage ratio (the “Total Net Leverage Ratio”);

- added (2026-09-03):
[0001628280-26-060361:note_history:39]
•providing for a commitment fee payable on the unused portion of the Revolving Credit Facility at a per annum rate ranging from 0.20% to 0.30%, with the actual rate determined according to the Total Net Leverage Ratio; and

- added (2026-09-03):
[0001628280-26-060361:note_history:40]
•providing for increased flexibility with respect to the 2031 Notes offering, the 2031 Hedge Transactions, and the 2031 Warrant Transactions (as defined in Note 13 above).

- added (2026-09-03):
[0001628280-26-060361:note_history:41]
Under the Revolving Credit Facility, Ciena is also required to maintain certain financial maintenance covenants, including:

- added (2026-09-03):
[0001628280-26-060361:note_history:42]
•prior to an Investment Grade Event, a maximum Total Secured Net Leverage Ratio of no greater than 3.50 to 1.00 as of the end of any period of four fiscal quarters (provided, that in the event Ciena consummates a qualifying acquisition, Ciena can elect to increase the maximum Total Secured Net Leverage Ratio level to 4.00 to 1.00 for the fiscal quarter in which such qualifying acquisition is consummated and for the next five consecutive fiscal quarters);

- added (2026-09-03):
[0001628280-26-060361:note_history:43]
•on or after an Investment Grade Event, a maximum Total Net Leverage Ratio of no greater than 4.00 to 1.00 as of the end of any period of four fiscal quarters; and

- added (2026-09-03):
[0001628280-26-060361:note_history:44]
•a minimum Interest Coverage Ratio of no less than 3.00 to 1.00 as of the end of any period of four fiscal quarters.

- added (2026-09-03):
[0001628280-26-060361:note_history:45]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

- added (2026-09-03):
[0001628280-26-060361:note_history:46]
As of August 1, 2026, Ciena was in compliance with the above financial maintenance covenants. Also as of August 1, 2026, letters of credit totaling $40.7 million were issued under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of August 1, 2026.

- removed (2026-09-03):
[0001628280-26-040767:note_history:47]
On January 17, 2025, Ciena entered into a Refinancing Amendment to its Credit Agreement under which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.2 billion (the “Refinanced 2030 Term Loan”). The Refinanced 2030 Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.6 million annually, with the remaining balance payable at maturity.

- removed (2026-09-03):
[0001628280-26-040767:note_history:48]
|  |  | May 2, 2026 |  | November 1, 2025 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,140,930 |  |  | $ | (3,194) |  |  | $ | (4,082) |  |  | $ | 1,133,654 |  |  | $ | 1,138,619 |  |

- removed (2026-09-03):
[0001628280-26-040767:note_history:49]
As of May 2, 2026, the estimated fair value of the Refinanced 2030 Term Loan was $1.14 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-09-03):
[0001628280-26-060361:note_history:50]
|  | August 1, 2026 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 184,411 |  |  | $ | 1 |  |  | $ | (578) |  |  | $ | 183,834 |  |
| Corporate debt securities | 222,685 |  |  | 1 |  |  | (269) |  |  | 222,417 |  |
| Time deposits | 93,091 |  |  | — |  |  | (4) |  |  | 93,087 |  |
|  | $ | 500,187 |  |  | $ | 2 |  |  | $ | (851) |  |  | $ | 499,338 |  |
| Included in cash equivalents | $ | 101,492 |  |  | $ | — |  |  | $ | — |  |  | $ | 101,492 |  |
| Included in short-term investments | 184,489 |  |  | 1 |  |  | (197) |  |  | 184,293 |  |
| Included in long-term investments | 214,206 |  |  | 1 |  |  | (654) |  |  | 213,553 |  |
|  | $ | 500,187 |  |  | $ | 2 |  |  | $ | (851) |  |  | $ | 499,338 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:51]
The following table summarizes the legal maturities of debt investments as of August 1, 2026 (in thousands):
  (was, 2026-06-04, similarity 0.9659):
[0001628280-26-040767:note_history:51]
The following table summarizes the legal maturities of debt investments as of May 2, 2026 (in thousands):

- removed (2026-09-03):
[0001628280-26-040767:note_history:52]
|  | May 2, 2026 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 208,870 |  |  | $ | 71 |  |  | $ | (63) |  |  | $ | 208,878 |  |
| Corporate debt securities | 147,153 |  |  | 44 |  |  | (106) |  |  | 147,091 |  |
| Time deposits | 112,407 |  |  | 1 |  |  | — |  |  | 112,408 |  |
|  | $ | 468,430 |  |  | $ | 116 |  |  | $ | (169) |  |  | $ | 468,377 |  |
| Included in cash equivalents | $ | 110,563 |  |  | $ | — |  |  | $ | — |  |  | $ | 110,563 |  |
| Included in short-term investments | 157,619 |  |  | 99 |  |  | (10) |  |  | 157,708 |  |
| Included in long-term investments | 200,248 |  |  | 17 |  |  | (159) |  |  | 200,106 |  |
|  | $ | 468,430 |  |  | $ | 116 |  |  | $ | (169) |  |  | $ | 468,377 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:53]
The net carrying value of Ciena’s convertible notes was comprised of the following as of the date indicated (in thousands):
  (was, 2026-06-04, similarity 0.9244):
[0001628280-26-040767:note_history:53]
The net carrying value of Ciena’s term loan was comprised of the following as of the date indicated (in thousands):

- added (2026-09-03):
[0001628280-26-060361:note_history:54]
|  |  | August 1, 2026 |  |  |
|  |  | Principal Balance |  |  |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2031 Notes |  | $ | 2,875,000 |  |  |  |  | $ | (42,794) |  |  | $ | 2,832,206 |  |  |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:55]
|  |  | August 1, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,363) |  |  | $ | 397,637 |  |  | $ | 397,119 |  |  |  |
  (was, 2026-06-04, similarity 0.9788):
[0001628280-26-040767:note_history:55]
|  |  | May 2, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,535) |  |  | $ | 397,465 |  |  | $ | 397,119 |  |  |  |

- removed (2026-09-03):
[0001628280-26-040767:note_history:56]
|  |  | May 2, 2026 |  | November 1, 2025 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,140,930 |  |  | $ | (3,194) |  |  | $ | (4,082) |  |  | $ | 1,133,654 |  |  | $ | 1,138,619 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:57]
|  | Quarter Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,191,307 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,191,307 |  |
| Routing and Switching | 164,368 |  |  | — |  |  | — |  |  | — |  |  | 164,368 |  |
| Platform Software and Services | — |  |  | 98,657 |  |  | — |  |  | — |  |  | 98,657 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 89,851 |  |  | 89,851 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 87,871 |  |  | 87,871 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 15,870 |  |  | 15,870 |  |
| Total revenue by product line | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,355,675 |  |  | $ | 30,403 |  |  | $ | 4,955 |  |  | $ | 36,183 |  |  | $ | 1,427,216 |  |
| Services transferred over time | — |  |  | 68,254 |  |  | 18,250 |  |  | 157,409 |  |  | 243,913 |  |
| Total revenue by timing of revenue recognition | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |
  (was, 2026-06-04, similarity 0.9961):
[0001628280-26-040767:note_history:57]
|  | Quarter Ended May 2, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,099,848 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099,848 |  |
| Routing and Switching | 174,230 |  |  | — |  |  | — |  |  | — |  |  | 174,230 |  |
| Platform Software and Services | — |  |  | 93,878 |  |  | — |  |  | — |  |  | 93,878 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,361 |  |  | — |  |  | 23,361 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 89,286 |  |  | 89,286 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 79,702 |  |  | 79,702 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 10,434 |  |  | 10,434 |  |
| Total revenue by product line | $ | 1,274,078 |  |  | $ | 93,878 |  |  | $ | 23,361 |  |  | $ | 179,422 |  |  | $ | 1,570,739 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,274,078 |  |  | $ | 29,413 |  |  | $ | 8,487 |  |  | $ | 21,543 |  |  | $ | 1,333,521 |  |
| Services transferred over time | — |  |  | 64,465 |  |  | 14,874 |  |  | 157,879 |  |  | 237,218 |  |
| Total revenue by timing of revenue recognition | $ | 1,274,078 |  |  | $ | 93,878 |  |  | $ | 23,361 |  |  | $ | 179,422 |  |  | $ | 1,570,739 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:58]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
  (was, 2026-06-04, similarity 0.9961):
[0001628280-26-040767:note_history:58]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:59]
|  | Nine Months Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 3,314,317 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,314,317 |  |
| Routing and Switching | 464,604 |  |  | — |  |  | — |  |  | — |  |  | 464,604 |  |
| Platform Software and Services | — |  |  | 285,919 |  |  | — |  |  | — |  |  | 285,919 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 66,986 |  |  | — |  |  | 66,986 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 266,687 |  |  | 266,687 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 235,522 |  |  | 235,522 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 34,875 |  |  | 34,875 |  |
| Total revenue by product line | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,778,921 |  |  | $ | 88,999 |  |  | $ | 15,336 |  |  | $ | 74,613 |  |  | $ | 3,957,869 |  |
| Services transferred over time | — |  |  | 196,920 |  |  | 51,650 |  |  | 462,471 |  |  | 711,041 |  |
| Total revenue by timing of revenue recognition | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |
  (was, 2026-06-04, similarity 0.993):
[0001628280-26-040767:note_history:59]
|  | Six Months Ended May 2, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,123,010 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,123,010 |  |
| Routing and Switching | 300,236 |  |  | — |  |  | — |  |  | — |  |  | 300,236 |  |
| Platform Software and Services | — |  |  | 187,262 |  |  | — |  |  | — |  |  | 187,262 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 43,781 |  |  | — |  |  | 43,781 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 176,837 |  |  | 176,837 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 147,650 |  |  | 147,650 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 19,005 |  |  | 19,005 |  |
| Total revenue by product line | $ | 2,423,246 |  |  | $ | 187,262 |  |  | $ | 43,781 |  |  | $ | 343,492 |  |  | $ | 2,997,781 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,423,246 |  |  | $ | 58,596 |  |  | $ | 10,381 |  |  | $ | 38,430 |  |  | $ | 2,530,653 |  |
| Services transferred over time | — |  |  | 128,666 |  |  | 33,400 |  |  | 305,062 |  |  | 467,128 |  |
| Total revenue by timing of revenue recognition | $ | 2,423,246 |  |  | $ | 187,262 |  |  | $ | 43,781 |  |  | $ | 343,492 |  |  | $ | 2,997,781 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:60]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
  (was, 2026-06-04, similarity 0.993):
[0001628280-26-040767:note_history:60]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:61]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,316,796 |  |  | $ | 923,627 |  |  | $ | 3,637,233 |  |  | $ | 2,553,081 |  |
| EMEA |  | 180,550 |  |  | 186,018 |  |  | 577,175 |  |  | 535,519 |  |
| APAC |  | 173,783 |  |  | 109,740 |  |  | 454,502 |  |  | 328,923 |  |
| Total revenue by geographic distribution |  | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |
  (was, 2026-06-04, similarity 0.8941):
[0001628280-26-040767:note_history:61]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 3, |  | May 2, |  | May 3, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,202,214 |  |  | $ | 833,822 |  |  | $ | 2,320,437 |  |  | $ | 1,629,454 |  |
| EMEA |  | 196,037 |  |  | 191,585 |  |  | 396,625 |  |  | 349,501 |  |
| APAC |  | 172,488 |  |  | 100,471 |  |  | 280,719 |  |  | 219,183 |  |
| Total revenue by geographic distribution |  | $ | 1,570,739 |  |  | $ | 1,125,878 |  |  | $ | 2,997,781 |  |  | $ | 2,198,138 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:62]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cloud provider A | $ | 476,570 |  |  | $ | 217,954 |  |  | $ | 1,128,775 |  |  | $ | 538,195 |  |
| Cloud provider B | 219,644 |  |  | n/a* |  | 592,137 |  |  | n/a* |
| Service provider | n/a* |  | 133,014 |  |  | n/a* |  | 361,394 |  |
| Total | $ | 696,214 |  |  | $ | 350,968 |  |  | $ | 1,720,912 |  |  | $ | 899,589 |  |
  (was, 2026-06-04, similarity 0.8763):
[0001628280-26-040767:note_history:62]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 3, |  | May 2, |  | May 3, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cloud provider A | $ | 321,224 |  |  | $ | 151,345 |  |  | $ | 652,206 |  |  | $ | 320,242 |  |
| Cloud provider B | 212,288 |  |  | n/a* |  | 372,493 |  |  | n/a* |
| Service provider | n/a* |  | 117,355 |  |  | n/a* |  | 228,379 |  |
| Total | $ | 533,512 |  |  | $ | 268,700 |  |  | $ | 1,024,699 |  |  | $ | 548,621 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:63]
|  | Quarter Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,191,307 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,191,307 |  |
| Routing and Switching | 164,368 |  |  | — |  |  | — |  |  | — |  |  | 164,368 |  |
| Platform Software and Services | — |  |  | 98,657 |  |  | — |  |  | — |  |  | 98,657 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 89,851 |  |  | 89,851 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 87,871 |  |  | 87,871 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 15,870 |  |  | 15,870 |  |
| Total revenue by product line | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,355,675 |  |  | $ | 30,403 |  |  | $ | 4,955 |  |  | $ | 36,183 |  |  | $ | 1,427,216 |  |
| Services transferred over time | — |  |  | 68,254 |  |  | 18,250 |  |  | 157,409 |  |  | 243,913 |  |
| Total revenue by timing of revenue recognition | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |
  (was, 2026-06-04, similarity 0.9961):
[0001628280-26-040767:note_history:63]
|  | Quarter Ended May 2, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,099,848 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,099,848 |  |
| Routing and Switching | 174,230 |  |  | — |  |  | — |  |  | — |  |  | 174,230 |  |
| Platform Software and Services | — |  |  | 93,878 |  |  | — |  |  | — |  |  | 93,878 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,361 |  |  | — |  |  | 23,361 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 89,286 |  |  | 89,286 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 79,702 |  |  | 79,702 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 10,434 |  |  | 10,434 |  |
| Total revenue by product line | $ | 1,274,078 |  |  | $ | 93,878 |  |  | $ | 23,361 |  |  | $ | 179,422 |  |  | $ | 1,570,739 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,274,078 |  |  | $ | 29,413 |  |  | $ | 8,487 |  |  | $ | 21,543 |  |  | $ | 1,333,521 |  |
| Services transferred over time | — |  |  | 64,465 |  |  | 14,874 |  |  | 157,879 |  |  | 237,218 |  |
| Total revenue by timing of revenue recognition | $ | 1,274,078 |  |  | $ | 93,878 |  |  | $ | 23,361 |  |  | $ | 179,422 |  |  | $ | 1,570,739 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:64]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
  (was, 2026-06-04, similarity 0.9961):
[0001628280-26-040767:note_history:64]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:65]
|  | Nine Months Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 3,314,317 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,314,317 |  |
| Routing and Switching | 464,604 |  |  | — |  |  | — |  |  | — |  |  | 464,604 |  |
| Platform Software and Services | — |  |  | 285,919 |  |  | — |  |  | — |  |  | 285,919 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 66,986 |  |  | — |  |  | 66,986 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 266,687 |  |  | 266,687 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 235,522 |  |  | 235,522 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 34,875 |  |  | 34,875 |  |
| Total revenue by product line | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,778,921 |  |  | $ | 88,999 |  |  | $ | 15,336 |  |  | $ | 74,613 |  |  | $ | 3,957,869 |  |
| Services transferred over time | — |  |  | 196,920 |  |  | 51,650 |  |  | 462,471 |  |  | 711,041 |  |
| Total revenue by timing of revenue recognition | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |
  (was, 2026-06-04, similarity 0.993):
[0001628280-26-040767:note_history:65]
|  | Six Months Ended May 2, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,123,010 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,123,010 |  |
| Routing and Switching | 300,236 |  |  | — |  |  | — |  |  | — |  |  | 300,236 |  |
| Platform Software and Services | — |  |  | 187,262 |  |  | — |  |  | — |  |  | 187,262 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 43,781 |  |  | — |  |  | 43,781 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 176,837 |  |  | 176,837 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 147,650 |  |  | 147,650 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 19,005 |  |  | 19,005 |  |
| Total revenue by product line | $ | 2,423,246 |  |  | $ | 187,262 |  |  | $ | 43,781 |  |  | $ | 343,492 |  |  | $ | 2,997,781 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,423,246 |  |  | $ | 58,596 |  |  | $ | 10,381 |  |  | $ | 38,430 |  |  | $ | 2,530,653 |  |
| Services transferred over time | — |  |  | 128,666 |  |  | 33,400 |  |  | 305,062 |  |  | 467,128 |  |
| Total revenue by timing of revenue recognition | $ | 2,423,246 |  |  | $ | 187,262 |  |  | $ | 43,781 |  |  | $ | 343,492 |  |  | $ | 2,997,781 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:66]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
  (was, 2026-06-04, similarity 0.993):
[0001628280-26-040767:note_history:66]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:67]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,316,796 |  |  | $ | 923,627 |  |  | $ | 3,637,233 |  |  | $ | 2,553,081 |  |
| EMEA |  | 180,550 |  |  | 186,018 |  |  | 577,175 |  |  | 535,519 |  |
| APAC |  | 173,783 |  |  | 109,740 |  |  | 454,502 |  |  | 328,923 |  |
| Total revenue by geographic distribution |  | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |
  (was, 2026-06-04, similarity 0.8941):
[0001628280-26-040767:note_history:67]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 3, |  | May 2, |  | May 3, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,202,214 |  |  | $ | 833,822 |  |  | $ | 2,320,437 |  |  | $ | 1,629,454 |  |
| EMEA |  | 196,037 |  |  | 191,585 |  |  | 396,625 |  |  | 349,501 |  |
| APAC |  | 172,488 |  |  | 100,471 |  |  | 280,719 |  |  | 219,183 |  |
| Total revenue by geographic distribution |  | $ | 1,570,739 |  |  | $ | 1,125,878 |  |  | $ | 2,997,781 |  |  | $ | 2,198,138 |  |

- added (2026-09-03):
[0001628280-26-060361:note_history:68]
Ciena’s revenue includes $1.3 billion and $882.8 million of U.S. revenue for the third quarter of fiscal 2026 and 2025, respectively. For the nine months ended August 1, 2026 and August 2, 2025, U.S. revenue was $3.5 billion and $2.4 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- changed (2026-09-03):
[0001628280-26-060361:note_history:69]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cloud provider A | $ | 476,570 |  |  | $ | 217,954 |  |  | $ | 1,128,775 |  |  | $ | 538,195 |  |
| Cloud provider B | 219,644 |  |  | n/a* |  | 592,137 |  |  | n/a* |
| Service provider | n/a* |  | 133,014 |  |  | n/a* |  | 361,394 |  |
| Total | $ | 696,214 |  |  | $ | 350,968 |  |  | $ | 1,720,912 |  |  | $ | 899,589 |  |
  (was, 2026-06-04, similarity 0.8763):
[0001628280-26-040767:note_history:69]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 3, |  | May 2, |  | May 3, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cloud provider A | $ | 321,224 |  |  | $ | 151,345 |  |  | $ | 652,206 |  |  | $ | 320,242 |  |
| Cloud provider B | 212,288 |  |  | n/a* |  | 372,493 |  |  | n/a* |
| Service provider | n/a* |  | 117,355 |  |  | n/a* |  | 228,379 |  |
| Total | $ | 533,512 |  |  | $ | 268,700 |  |  | $ | 1,024,699 |  |  | $ | 548,621 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:70]
|  |  | Balance at August 1, 2026 |  | Balance at November 1, 2025 |
| Accounts receivable, net |  | $ | 1,233,610 |  |  | $ | 975,856 |  |
| Long-term accounts receivable |  | $ | 18,043 |  |  | $ | 28,610 |  |
| Deferred revenue |  | $ | 311,281 |  |  | $ | 303,786 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 160,888 |  |  | $ | 157,868 |  |
  (was, 2026-06-04, similarity 0.9847):
[0001628280-26-040767:note_history:70]
|  |  | Balance at May 2, 2026 |  | Balance at November 1, 2025 |
| Accounts receivable, net |  | $ | 1,052,569 |  |  | $ | 975,856 |  |
| Long-term accounts receivable |  | $ | 21,265 |  |  | $ | 28,610 |  |
| Deferred revenue |  | $ | 340,487 |  |  | $ | 303,786 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 163,614 |  |  | $ | 157,868 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:71]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $174.3 million and $134.6 million of revenue during the first nine months of fiscal 2026 and 2025, respectively, that was included in the deferred revenue balance as of November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 1, 2026 and August 2, 2025.
  (was, 2026-06-04, similarity 0.9271):
[0001628280-26-040767:note_history:71]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $149.6 million and $111.3 million of revenue during the first six months of fiscal 2026 and 2025, respectively, that was included in the deferred revenue balance as of November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 2, 2026 and May 3, 2025.

- changed (2026-09-03):
[0001628280-26-060361:note_history:72]
|  | August 1,2026 |  | November 1,2025 |
| Products | $ | 30,428 |  |  | $ | 65,382 |  |
| Services | 280,853 |  |  | 238,404 |  |
| Total deferred revenue | 311,281 |  |  | 303,786 |  |
| Less current portion | (211,453) |  |  | (208,936) |  |
| Long-term deferred revenue | $ | 99,828 |  |  | $ | 94,850 |  |
  (was, 2026-06-04, similarity 0.9845):
[0001628280-26-040767:note_history:72]
|  | May 2,2026 |  | November 1,2025 |
| Products | $ | 31,649 |  |  | $ | 65,382 |  |
| Services | 308,838 |  |  | 238,404 |  |
| Total deferred revenue | 340,487 |  |  | 303,786 |  |
| Less current portion | (238,380) |  |  | (208,936) |  |
| Long-term deferred revenue | $ | 102,107 |  |  | $ | 94,850 |  |

- changed (2026-09-03):
[0001628280-26-060361:note_history:73]
Capitalized contract acquisition costs consist of deferred sales commissions and were $38.9 million and $37.4 million as of August 1, 2026 and November 1, 2025, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $28.1 million and $26.0 million during the first nine months of fiscal 2026 and 2025, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2026-06-04, similarity 0.9848):
[0001628280-26-040767:note_history:73]
Capitalized contract acquisition costs consist of deferred sales commissions and were $35.5 million and $37.4 million as of May 2, 2026 and November 1, 2025, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $19.7 million and $16.7 million during the first six months of fiscal 2026 and 2025, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2026-09-03):
[0001628280-26-060361:note_history:74]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. The timing of fulfillment of remaining performance obligations can be impacted by supply conditions. As of August 1, 2026, the aggregate amount of RPO was $2.5 billion. The majority of Ciena’s performance obligations will be satisfied within a year and any remaining performance obligations are typically recognized within three years.
  (was, 2026-06-04, similarity 0.9923):
[0001628280-26-040767:note_history:74]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. The timing of fulfillment of remaining performance obligations can be impacted by supply conditions. As of May 2, 2026, the aggregate amount of RPO was $2.5 billion. The majority of Ciena’s performance obligations will be satisfied within a year and any remaining performance obligations are typically recognized within three years.

- removed (2026-09-03):
[0001628280-26-040767:note_history:75]
Ciena’s revenue includes $1.2 billion and $0.8 billion of U.S. revenue for the second quarter of fiscal 2026 and 2025, respectively. For the six months ended May 2, 2026 and May 3, 2025, U.S. revenue was $2.2 billion and $1.6 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-09-03):
[0001628280-26-060361:note_history:76]
From the end of the third quarter of fiscal 2026 through August 28, 2026, Ciena repurchased 88,896 shares of its common stock for an aggregate purchase price of $36.0 million at an average price of $404.52 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of August 28, 2026, Ciena has an aggregate of $299.0 million of authorized funds remaining under this repurchase program.
  (was, 2026-06-04, similarity 0.9658):
[0001628280-26-040767:note_history:76]
From the end of the second quarter of fiscal 2026 through May 29, 2026, Ciena repurchased 44,628 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $561.86 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of May 29, 2026, Ciena has an aggregate of $481.6 million of authorized funds remaining under this repurchase program.
