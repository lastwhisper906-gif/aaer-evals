# CIEN notes — 0001628280-26-060361


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-26-060361:notes:1]
[same as prior period, unchanged from 0001628280-26-040767:notes:1]

[0001628280-26-060361:notes:2]
[same as prior period, unchanged from 0001628280-26-040767:notes:2]

[0001628280-26-060361:notes:3]
[same as prior period, unchanged from 0001628280-26-040767:notes:3]

[0001628280-26-060361:notes:4]
[same as prior period, unchanged from 0001628280-26-040767:notes:4]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-26-060361:notes:5]
[same as prior period, unchanged from 0001628280-26-040767:notes:5]

[0001628280-26-060361:notes:6]
[same as prior period, unchanged from 0001628280-26-040767:notes:6]

[0001628280-26-060361:notes:7]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures to decision makers. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, and will result in changes to certain income tax disclosures including substantially more information on a disaggregated basis, but it does not affect recognition or measurement of income taxes and therefore is not expected to have a material effect on our consolidated financial statements. The amendments are applied on a prospective basis; however, retrospective application is permitted.

[0001628280-26-060361:notes:8]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026 and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-060361:notes:9]
In July 2025, the FASB issued ASU No. 2025-05 (“ASU 2025-05”), Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, to introduce a practical expedient for all entities, which simplifies the calculation required for estimating credit losses and assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. ASU 2025-05 is effective for annual reporting periods beginning after December 15, 2025 and interim reporting periods within those annual reporting periods; however, early adoption is permitted. ASU 2025-05 allows for adoption using a prospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-060361:notes:10]
In September 2025, the FASB issued ASU No. 2025-06 (“ASU 2025-06”), Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) to modernize the accounting for software costs that are accounted for under Subtopic 350-40 by shifting away from prescriptive and sequential software development stages to an incremental and iterative method when capitalizing software costs. ASU 2025-06 is effective for annual reporting periods beginning after December 15, 2027 and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-060361:notes:11]
In December 2025, the FASB issued ASU No. 2025-11 (“ASU 2025-11”), Interim Reporting (Topic 270): Narrow-Scope Improvements, to improve the navigability of required interim disclosures, clarify when that guidance applies, and provide additional guidance on what disclosures should be provided in interim reporting periods. ASU 2025-11 is effective for interim reporting periods with annual reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2025-11 allows for adoption using the prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its interim financial statements and related disclosures.
In May 2026, the FASB  issued ASU No. 2026-02 (“ASU 2026-02”), Environmental Credits and Environmental Credit Obligations, to clarify the accounting treatment and reporting standards of environmental credits and environmental credit obligations. ASU 2026-02 is effective for annual reporting periods beginning after December 15, 2027 and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period and should be applied on a retrospective basis. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-060361:notes:12]
[same as prior period, unchanged from 0001628280-26-040767:notes:12]

[0001628280-26-060361:notes:13]
Ciena’s disaggregated segment and product line revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 19 below.

[0001628280-26-060361:notes:14]
[same as prior period, unchanged from 0001628280-26-040767:notes:14]

[0001628280-26-060361:notes:15]
|  | Quarter Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,191,307 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,191,307 |  |
| Routing and Switching | 164,368 |  |  | — |  |  | — |  |  | — |  |  | 164,368 |  |
| Platform Software and Services | — |  |  | 98,657 |  |  | — |  |  | — |  |  | 98,657 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,205 |  |  | — |  |  | 23,205 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 89,851 |  |  | 89,851 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 87,871 |  |  | 87,871 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 15,870 |  |  | 15,870 |  |
| Total revenue by product line | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,355,675 |  |  | $ | 30,403 |  |  | $ | 4,955 |  |  | $ | 36,183 |  |  | $ | 1,427,216 |  |
| Services transferred over time | — |  |  | 68,254 |  |  | 18,250 |  |  | 157,409 |  |  | 243,913 |  |
| Total revenue by timing of revenue recognition | $ | 1,355,675 |  |  | $ | 98,657 |  |  | $ | 23,205 |  |  | $ | 193,592 |  |  | $ | 1,671,129 |  |

[0001628280-26-060361:notes:16]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |

[0001628280-26-060361:notes:17]
|  | Nine Months Ended August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 3,314,317 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,314,317 |  |
| Routing and Switching | 464,604 |  |  | — |  |  | — |  |  | — |  |  | 464,604 |  |
| Platform Software and Services | — |  |  | 285,919 |  |  | — |  |  | — |  |  | 285,919 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 66,986 |  |  | — |  |  | 66,986 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 266,687 |  |  | 266,687 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 235,522 |  |  | 235,522 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 34,875 |  |  | 34,875 |  |
| Total revenue by product line | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,778,921 |  |  | $ | 88,999 |  |  | $ | 15,336 |  |  | $ | 74,613 |  |  | $ | 3,957,869 |  |
| Services transferred over time | — |  |  | 196,920 |  |  | 51,650 |  |  | 462,471 |  |  | 711,041 |  |
| Total revenue by timing of revenue recognition | $ | 3,778,921 |  |  | $ | 285,919 |  |  | $ | 66,986 |  |  | $ | 537,084 |  |  | $ | 4,668,910 |  |

[0001628280-26-060361:notes:18]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |

[0001628280-26-060361:notes:19]
[same as prior period, unchanged from 0001628280-26-040767:notes:19]

[0001628280-26-060361:notes:20]
[same as prior period, unchanged from 0001628280-26-040767:notes:20]

[0001628280-26-060361:notes:21]
[same as prior period, unchanged from 0001628280-26-040767:notes:21]

[0001628280-26-060361:notes:22]
[same as prior period, unchanged from 0001628280-26-040767:notes:22]

[0001628280-26-060361:notes:23]
[same as prior period, unchanged from 0001628280-26-040767:notes:23]

[0001628280-26-060361:notes:24]
[same as prior period, unchanged from 0001628280-26-040767:notes:24]

[0001628280-26-060361:notes:25]
[same as prior period, unchanged from 0001628280-26-040767:notes:25]

[0001628280-26-060361:notes:26]
[same as prior period, unchanged from 0001628280-26-040767:notes:26]

[0001628280-26-060361:notes:27]
[same as prior period, unchanged from 0001628280-26-040767:notes:27]

[0001628280-26-060361:notes:28]
[same as prior period, unchanged from 0001628280-26-040767:notes:28]

[0001628280-26-060361:notes:29]
[same as prior period, unchanged from 0001628280-26-040767:notes:29]

[0001628280-26-060361:notes:30]
[same as prior period, unchanged from 0001628280-26-040767:notes:30]

[0001628280-26-060361:notes:31]
[same as prior period, unchanged from 0001628280-26-040767:notes:31]

[0001628280-26-060361:notes:32]
[same as prior period, unchanged from 0001628280-26-040767:notes:32]

[0001628280-26-060361:notes:33]
[same as prior period, unchanged from 0001628280-26-040767:notes:33]

[0001628280-26-060361:notes:34]
[same as prior period, unchanged from 0001628280-26-040767:notes:34]

[0001628280-26-060361:notes:35]
[same as prior period, unchanged from 0001628280-26-040767:notes:35]

[0001628280-26-060361:notes:36]
[same as prior period, unchanged from 0001628280-26-040767:notes:36]

[0001628280-26-060361:notes:37]
[same as prior period, unchanged from 0001628280-26-040767:notes:37]

[0001628280-26-060361:notes:38]
[same as prior period, unchanged from 0001628280-26-040767:notes:38]

[0001628280-26-060361:notes:39]
[same as prior period, unchanged from 0001628280-26-040767:notes:39]

[0001628280-26-060361:notes:40]
[same as prior period, unchanged from 0001628280-26-040767:notes:40]

[0001628280-26-060361:notes:41]
[same as prior period, unchanged from 0001628280-26-040767:notes:41]

[0001628280-26-060361:notes:42]
[same as prior period, unchanged from 0001628280-26-040767:notes:42]

[0001628280-26-060361:notes:43]
[same as prior period, unchanged from 0001628280-26-040767:notes:43]

[0001628280-26-060361:notes:44]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  |  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,316,796 |  |  | $ | 923,627 |  |  | $ | 3,637,233 |  |  | $ | 2,553,081 |  |
| EMEA |  | 180,550 |  |  | 186,018 |  |  | 577,175 |  |  | 535,519 |  |
| APAC |  | 173,783 |  |  | 109,740 |  |  | 454,502 |  |  | 328,923 |  |
| Total revenue by geographic distribution |  | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |

[0001628280-26-060361:notes:45]
Ciena’s revenue includes $1.3 billion and $882.8 million of U.S. revenue for the third quarter of fiscal 2026 and 2025, respectively. For the nine months ended August 1, 2026 and August 2, 2025, U.S. revenue was $3.5 billion and $2.4 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0001628280-26-060361:notes:46]
[same as prior period, unchanged from 0001628280-26-040767:notes:46]

[0001628280-26-060361:notes:47]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Cloud provider A | $ | 476,570 |  |  | $ | 217,954 |  |  | $ | 1,128,775 |  |  | $ | 538,195 |  |
| Cloud provider B | 219,644 |  |  | n/a* |  | 592,137 |  |  | n/a* |
| Service provider | n/a* |  | 133,014 |  |  | n/a* |  | 361,394 |  |
| Total | $ | 696,214 |  |  | $ | 350,968 |  |  | $ | 1,720,912 |  |  | $ | 899,589 |  |

[0001628280-26-060361:notes:48]
[same as prior period, unchanged from 0001628280-26-040767:notes:48]

[0001628280-26-060361:notes:49]
[same as prior period, unchanged from 0001628280-26-040767:notes:49]

[0001628280-26-060361:notes:50]
[same as prior period, unchanged from 0001628280-26-040767:notes:50]

[0001628280-26-060361:notes:51]
[same as prior period, unchanged from 0001628280-26-040767:notes:51]

[0001628280-26-060361:notes:52]
|  |  | Balance at August 1, 2026 |  | Balance at November 1, 2025 |
| Accounts receivable, net |  | $ | 1,233,610 |  |  | $ | 975,856 |  |
| Long-term accounts receivable |  | $ | 18,043 |  |  | $ | 28,610 |  |
| Deferred revenue |  | $ | 311,281 |  |  | $ | 303,786 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 160,888 |  |  | $ | 157,868 |  |

[0001628280-26-060361:notes:53]
[same as prior period, unchanged from 0001628280-26-040767:notes:53]

[0001628280-26-060361:notes:54]
[same as prior period, unchanged from 0001628280-26-040767:notes:54]

[0001628280-26-060361:notes:55]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $174.3 million and $134.6 million of revenue during the first nine months of fiscal 2026 and 2025, respectively, that was included in the deferred revenue balance as of November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 1, 2026 and August 2, 2025.

[0001628280-26-060361:notes:56]
[same as prior period, unchanged from 0001628280-26-040767:notes:56]

[0001628280-26-060361:notes:57]
|  | August 1,2026 |  | November 1,2025 |
| Products | $ | 30,428 |  |  | $ | 65,382 |  |
| Services | 280,853 |  |  | 238,404 |  |
| Total deferred revenue | 311,281 |  |  | 303,786 |  |
| Less current portion | (211,453) |  |  | (208,936) |  |
| Long-term deferred revenue | $ | 99,828 |  |  | $ | 94,850 |  |

[0001628280-26-060361:notes:58]
[same as prior period, unchanged from 0001628280-26-040767:notes:58]

[0001628280-26-060361:notes:59]
Capitalized contract acquisition costs consist of deferred sales commissions and were $38.9 million and $37.4 million as of August 1, 2026 and November 1, 2025, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $28.1 million and $26.0 million during the first nine months of fiscal 2026 and 2025, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0001628280-26-060361:notes:60]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. The timing of fulfillment of remaining performance obligations can be impacted by supply conditions. As of August 1, 2026, the aggregate amount of RPO was $2.5 billion. The majority of Ciena’s performance obligations will be satisfied within a year and any remaining performance obligations are typically recognized within three years.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-26-060361:notes:61]
[same as prior period, unchanged from 0001628280-26-040767:notes:61]

[0001628280-26-060361:notes:62]
Ciena regularly monitors its spending to optimize operating expenses and to ensure that its strategic investments are aligned with its highest-growth demand opportunities. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended August 1, 2026 (in thousands):

[0001628280-26-060361:notes:63]
|  | Workforce restructuring |  | Other restructuring activities |  | Total |
| Balance at November 1, 2025 | $ | 8,436 |  |  | $ | — |  |  | $ | 8,436 |  |
| Charges | 1,815 |  |  | 1,375 |  | (1) | 3,190 |  |
| Cash payments | (9,712) |  |  | (1,375) |  |  | (11,087) |  |
| Balance at August 1, 2026 | $ | 539 |  |  | $ | — |  |  | $ | 539 |  |
| Current restructuring liabilities | $ | 539 |  |  | $ | — |  |  | $ | 539 |  |

[0001628280-26-060361:notes:64]
[same as prior period, unchanged from 0001628280-26-040767:notes:64]

[0001628280-26-060361:notes:65]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended August 2, 2025 (in thousands):

[0001628280-26-060361:notes:66]
|  | Workforce restructuring |  | Other restructuring activities |  | Total |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Charges | 1,996 |  |  | 3,266 |  | (1) | 5,262 |  |
| Cash payments | (3,389) |  |  | (3,266) |  |  | (6,655) |  |
| Balance at August 2, 2025 | $ | 534 |  |  | $ | — |  |  | $ | 534 |  |
| Current restructuring liabilities | $ | 534 |  |  | $ | — |  |  | $ | 534 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001628280-26-060361:notes:67]
[same as prior period, unchanged from 0001628280-26-040767:notes:67]

[0001628280-26-060361:notes:68]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Interest income | $ | 22,161 |  |  | $ | 16,173 |  |  | $ | 49,681 |  |  | $ | 43,318 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts (1) | (622) |  |  | 744 |  |  | 542 |  |  | (1,593) |  |
| Foreign currency exchange losses (2) | (271) |  |  | (1,796) |  |  | (3,003) |  |  | (4,799) |  |
| Other | 1,120 |  |  | (31) |  |  | 2,236 |  |  | (2,387) |  |
| Interest and other income, net | $ | 22,388 |  |  | $ | 15,090 |  |  | $ | 49,456 |  |  | $ | 34,539 |  |

[0001628280-26-060361:notes:69]
[same as prior period, unchanged from 0001628280-26-040767:notes:69]

[0001628280-26-060361:notes:70]
(2) Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar (“USD”) as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-060361:notes:71]
INCOME TAXES
The effective tax rate for the third quarter and first nine months of fiscal 2026 was lower than the effective tax rate for the third quarter and first nine months of fiscal 2025. The decrease was primarily due to an income tax benefit for share-based compensation expense and a change in mix of earnings in jurisdictions with lower tax rates.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-26-060361:notes:72]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0001628280-26-060361:notes:73]
|  | August 1, 2026 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 184,411 |  |  | $ | 1 |  |  | $ | (578) |  |  | $ | 183,834 |  |
| Corporate debt securities | 222,685 |  |  | 1 |  |  | (269) |  |  | 222,417 |  |
| Time deposits | 93,091 |  |  | — |  |  | (4) |  |  | 93,087 |  |
|  | $ | 500,187 |  |  | $ | 2 |  |  | $ | (851) |  |  | $ | 499,338 |  |
| Included in cash equivalents | $ | 101,492 |  |  | $ | — |  |  | $ | — |  |  | $ | 101,492 |  |
| Included in short-term investments | 184,489 |  |  | 1 |  |  | (197) |  |  | 184,293 |  |
| Included in long-term investments | 214,206 |  |  | 1 |  |  | (654) |  |  | 213,553 |  |
|  | $ | 500,187 |  |  | $ | 2 |  |  | $ | (851) |  |  | $ | 499,338 |  |

[0001628280-26-060361:notes:74]
|  | November 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 147,466 |  |  | $ | 304 |  |  | $ | — |  |  | $ | 147,770 |  |
| Corporate debt securities | 119,808 |  |  | 260 |  |  | — |  |  | 120,068 |  |
| Time deposits | 74,984 |  |  | 6 |  |  | — |  |  | 74,990 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |
| Included in cash equivalents | $ | 69,538 |  |  | $ | — |  |  | $ | — |  |  | $ | 69,538 |  |
| Included in short-term investments | 215,786 |  |  | 362 |  |  | — |  |  | 216,148 |  |
| Included in long-term investments | 56,934 |  |  | 208 |  |  | — |  |  | 57,142 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |

[0001628280-26-060361:notes:75]
The following table summarizes the legal maturities of debt investments as of August 1, 2026 (in thousands):

[0001628280-26-060361:notes:76]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 285,981 |  |  | $ | 285,785 |  |
| Due in 1-2 years | 214,206 |  |  | 213,553 |  |
|  | $ | 500,187 |  |  | $ | 499,338 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-060361:notes:77]
[same as prior period, unchanged from 0001628280-26-040767:notes:77]

[0001628280-26-060361:notes:78]
|  | August 1, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,877,098 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,877,098 |  |
| Bond mutual fund | 121,272 |  |  | — |  |  | — |  |  | 121,272 |  |
| Time deposits | 93,087 |  |  | — |  |  | — |  |  | 93,087 |  |
| Deferred compensation plan assets | 27,357 |  |  | — |  |  | — |  |  | 27,357 |  |
| U.S. government obligations | — |  |  | 183,834 |  |  | — |  |  | 183,834 |  |
| Corporate debt securities | — |  |  | 222,417 |  |  | — |  |  | 222,417 |  |
| Foreign currency forward contracts | — |  |  | 4,322 |  |  | — |  |  | 4,322 |  |
| Total assets measured at fair value | $ | 2,118,814 |  |  | $ | 410,573 |  |  | $ | — |  |  | $ | 2,529,387 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 11,003 |  |  | $ | — |  |  | $ | 11,003 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 11,003 |  |  | $ | — |  |  | $ | 11,003 |  |

[0001628280-26-060361:notes:79]
[same as prior period, unchanged from 0001628280-26-040767:notes:79]

[0001628280-26-060361:notes:80]
[same as prior period, unchanged from 0001628280-26-040767:notes:80]

[0001628280-26-060361:notes:81]
|  | August 1, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 2,087,490 |  |  | $ | 12,372 |  |  | $ | — |  |  | $ | 2,099,862 |  |
| Short-term investments | 3,967 |  |  | 180,326 |  |  | — |  |  | 184,293 |  |
| Prepaid expenses and other | — |  |  | 4,322 |  |  | — |  |  | 4,322 |  |
| Long-term investments | — |  |  | 213,553 |  |  | — |  |  | 213,553 |  |
| Other long-term assets | 27,357 |  |  | — |  |  | — |  |  | 27,357 |  |
| Total assets measured at fair value | $ | 2,118,814 |  |  | $ | 410,573 |  |  | $ | — |  |  | $ | 2,529,387 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 11,003 |  |  | $ | — |  |  | $ | 11,003 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 11,003 |  |  | $ | — |  |  | $ | 11,003 |  |

[0001628280-26-060361:notes:82]
[same as prior period, unchanged from 0001628280-26-040767:notes:82]

[0001628280-26-060361:notes:83]
[same as prior period, unchanged from 0001628280-26-040767:notes:83]


## us-gaap:InventoryDisclosureTextBlock

[0001628280-26-060361:notes:84]
[same as prior period, unchanged from 0001628280-26-040767:notes:84]

[0001628280-26-060361:notes:85]
|  | August 1,2026 |  | November 1,2025 |
| Raw materials | $ | 631,322 |  |  | $ | 593,783 |  |
| Work-in-process | 56,693 |  |  | 35,051 |  |
| Finished goods | 305,714 |  |  | 286,050 |  |
| Deferred cost of goods sold | 54,124 |  |  | 40,759 |  |
| Gross inventories | 1,047,853 |  |  | 955,643 |  |
| Reserve for inventory excess and obsolescence | (175,866) |  |  | (129,408) |  |
| Inventories, net | $ | 871,987 |  |  | $ | 826,235 |  |

[0001628280-26-060361:notes:86]
During the first nine months of fiscal 2026, Ciena recorded a provision for inventory excess and obsolescence of $72.4 million, primarily driven by reductions in forecasted demand for certain products. Deductions from the reserve were primarily attributable to sales and disposal activities.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-26-060361:notes:87]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0001628280-26-060361:notes:88]
|  | August 1,2026 |  | November 1,2025 |
| Equipment, furniture and fixtures (1) | $ | 1,075,544 |  |  | $ | 892,223 |  |
| Building subject to capital lease | 67,218 |  |  | 67,242 |  |
| Leasehold improvements | 88,647 |  |  | 91,562 |  |
|  | 1,231,409 |  |  | 1,051,027 |  |
| Accumulated depreciation and amortization | (739,753) |  |  | (664,248) |  |
|  | $ | 491,656 |  |  | $ | 386,779 |  |

[0001628280-26-060361:notes:89]
(1) Increase is primarily due to investments in our production capacity.

[0001628280-26-060361:notes:90]
The total of the depreciation of equipment, furniture and fixtures and the amortization of leasehold improvements was $94.6 million and $69.5 million for the first nine months of fiscal 2026 and 2025, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-060361:notes:91]
[same as prior period, unchanged from 0001628280-26-040767:notes:87]

[0001628280-26-060361:notes:92]
[same as prior period, unchanged from 0001628280-26-040767:notes:88]

[0001628280-26-060361:notes:93]
|  | August 1,2026 |  | November 1,2025 |
| Compensation, payroll related tax and benefits | $ | 248,651 |  |  | $ | 281,542 |  |
| Warranty | 66,500 |  |  | 55,533 |  |
| Vacation | 35,743 |  |  | 33,708 |  |
| Foreign currency forward contracts | 11,003 |  |  | 6,314 |  |
| Finance lease liabilities | 5,140 |  |  | 4,741 |  |
| Income taxes payable | 117 |  |  | 10,729 |  |
| Interest payable | — |  |  | 6,101 |  |
| Other | 140,995 |  |  | 132,413 |  |
|  | $ | 508,149 |  |  | $ | 531,081 |  |

[0001628280-26-060361:notes:94]
[same as prior period, unchanged from 0001628280-26-040767:notes:91]

[0001628280-26-060361:notes:95]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Nine Months Ended August 2, 2025 |  | $ | 55,267 |  |  |  |  | 16,302 |  |  | (18,503) |  |  | $ | 53,066 |  |
| Nine Months Ended August 1, 2026 |  | $ | 55,533 |  |  |  |  | 30,050 |  |  | (19,083) |  |  | $ | 66,500 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-26-060361:notes:96]
[same as prior period, unchanged from 0001628280-26-040767:notes:93]

[0001628280-26-060361:notes:97]
[same as prior period, unchanged from 0001628280-26-040767:notes:94]

[0001628280-26-060361:notes:98]
As of August 1, 2026 and November 1, 2025, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $491.8 million and $431.4 million as of August 1, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0001628280-26-060361:notes:99]
As of August 1, 2026 and November 1, 2025, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $57.7 million and $62.0 million as of August 1, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0001628280-26-060361:notes:100]
As of August 1, 2026 and November 1, 2025, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $68.3 million and $175.7 million as of August 1, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0001628280-26-060361:notes:101]
[same as prior period, unchanged from 0001628280-26-040767:notes:98]

[0001628280-26-060361:notes:102]
Ciena was exposed to floating rates of interest on its term loan borrowings (see Note 13 below) and hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0001628280-26-060361:notes:103]
Ciena expected the variable rate payments to be received under the terms of these interest rate swaps to offset, exactly, the forecasted variable rate payments on the equivalent notional amount of the Refinanced 2030 Term Loan (as defined in Note 13 below). These derivative contracts were designated as cash flow hedges and fixed the Secured Overnight Financing Rate (“SOFR”) for $350.0 million of its floating rate debt at 3.47% through January 2028, and an additional $350.0 million at 3.287% through December 2028. The total notional amount of such swaps in effect was $350.0 million, each, as of November 1, 2025.

[0001628280-26-060361:notes:104]
In June 2026, Ciena terminated its interest rate swaps in conjunction with the extinguishment of the Refinanced 2030 Term Loan (see Note 13). Ciena received cash and recognized a $7.8 million gain for the termination of the swaps reported in interest expense on the Condensed Consolidated Statements of Operations. As of August 1, 2026, Ciena did not have any interest rate swap agreements.

[0001628280-26-060361:notes:105]
[same as prior period, unchanged from 0001628280-26-040767:notes:103]


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-060361:notes:106]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Convertible Notes Payable

[0001628280-26-060361:notes:107]
2031 Convertible Senior Notes

[0001628280-26-060361:notes:108]
On June 11, 2026, Ciena closed a private offering of $2.88 billion aggregate principal amount of 0.00% Convertible Senior Notes due 2031 (the “2031 Notes”) to qualified buyers, which includes $375.0 million aggregate principal amount of 2031 Notes issued in connection with the initial purchasers’ full exercise of their option to acquire additional 2031 Notes, pursuant to an indenture, dated June 11, 2026 (the “Indenture”). The 2031 Notes will not bear regular interest and the principal amount of the 2031 Notes will not accrete. The 2031 Notes will mature on September 15, 2031 unless earlier converted, redeemed or repurchased. Ciena intends to use the net proceeds in excess of the repayment of the Refinanced 2030 Term Loan described below, related fees, and expenses for general corporate purposes and investments to enhance supply chain capacity.  In addition, a portion of the proceeds from the 2031 Notes were used to repurchase $140.0 million, or approximately 0.3 million shares, of Ciena’s common stock pursuant to its existing stock repurchase program concurrent to settlement.

[0001628280-26-060361:notes:109]
The initial conversion rate for the 2031 Notes is 1.3393 shares of Ciena’s common stock per $1,000 principal amount of 2031 Notes, which is equivalent to an initial conversion price of approximately $746.66 per share. If certain corporate events occur prior to the maturity date, or if Ciena delivers a notice of redemption, Ciena will, in certain circumstances, increase the conversion rate.

[0001628280-26-060361:notes:110]
On or after September 20, 2029, Ciena has the option to redeem for cash all or any portion of the 2031 Notes if the last reported sale price of Ciena’s common stock has been at least 130% of the conversion price then in effect for at least 20 trading days (whether or not consecutive) during any 30 consecutive trading day period (including the last trading day of such period) ending on, and including, the trading day immediately preceding the date on which Ciena provides notice of redemption at a redemption price equal to 100% of the principal amount of the 2031 Notes to be redeemed plus accrued and unpaid interest to, but excluding, the redemption date. If Ciena redeems less than all the outstanding 2031 Notes, at least $100 million aggregate principal amount of the 2031 Notes must be outstanding and not subject to redemption as of the relevant redemption date.

[0001628280-26-060361:notes:111]
Prior to the close of business on the business day immediately preceding June 15, 2031, the 2031 Notes are convertible at the option of the holders only under the following circumstances:

[0001628280-26-060361:notes:112]
•at any time during the 30 consecutive trading day period beginning on, and including, the 21st trading day of any fiscal quarter commencing after the fiscal quarter ending on October 31, 2026, if the last reported sale price of Ciena’s common stock is greater than or equal to 130% of the conversion price for each of at least five trading days (whether or not consecutive) during the first 20 consecutive trading days of such fiscal quarter;

[0001628280-26-060361:notes:113]
•during the five business day period after any ten consecutive trading day period (the “measurement period”) in which the trading price per $1,000 principal amount of 2031 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price of the common stock and the conversion rate on each such trading day;

[0001628280-26-060361:notes:114]
•if Ciena calls such 2031 Notes for redemption, at any time prior to the close of business on the scheduled trading day immediately preceding the redemption date, but only with respect to the 2031 Notes called (or deemed called) for redemption; or

[0001628280-26-060361:notes:115]
•upon the occurrence of certain corporate events, as specified in the Indenture.

[0001628280-26-060361:notes:116]
In addition, at any time on or after June 15, 2031, holders may convert their 2031 Notes at their option, and in multiples of $1,000 principal amount, without regard to the foregoing circumstances. Upon conversion, Ciena is required to satisfy its conversion obligation with respect to such converted 2031 Notes by delivering cash equal to the principal amount of such converted 2031 Notes and will settle any conversion value in excess in cash, shares of common stock or a combination of cash and shares of common stock, at Ciena’s election.

[0001628280-26-060361:notes:117]
Upon the occurrence of a fundamental change (as defined in the Indenture), subject to certain conditions, the holders of the 2031 Notes may require Ciena to repurchase for cash all or any portion of their 2031 Notes in multiples of $1,000 principal amount, at a repurchase price of the principal amount of the 2031 Notes to be purchased, plus accrued and unpaid interest to, but excluding the repurchase date.

[0001628280-26-060361:notes:118]
The Indenture contains customary covenants and events of default.

[0001628280-26-060361:notes:119]
The net carrying value of Ciena’s convertible notes was comprised of the following as of the date indicated (in thousands):

[0001628280-26-060361:notes:120]
|  |  | August 1, 2026 |  |  |
|  |  | Principal Balance |  |  |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2031 Notes |  | $ | 2,875,000 |  |  |  |  | $ | (42,794) |  |  | $ | 2,832,206 |  |  |  |

[0001628280-26-060361:notes:121]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the convertible note. The amortization of deferred debt issuance costs for the 2031 Notes is included in interest expense and was minimal during the first nine months of fiscal 2026.

[0001628280-26-060361:notes:122]
As of August 1, 2026, the estimated fair value of the 2031 Convertible Notes was $2.7 billion. The 2031 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2031 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0001628280-26-060361:notes:123]
2031 Note Hedge Transactions

[0001628280-26-060361:notes:124]
On June 11, 2026, Ciena paid an aggregate amount of $988.4 million for convertible note hedge transactions entered into in connection with the issuance of the 2031 Notes (the “2031 Hedge Transactions”). The 2031 Hedge Transactions cover, subject to anti-dilution adjustments substantially similar to those in the 2031 Notes, approximately 3.9 million shares of Ciena’s common stock, which is the same number of shares initially underlying the 2031 Notes, at a strike price of $746.66, subject to customary adjustments. The 2031 Hedge Transactions will expire upon the maturity of the 2031 Notes, subject to earlier exercise or termination.

[0001628280-26-060361:notes:125]
The 2031 Hedge Transactions are expected generally to reduce the potential dilutive effect of the conversion of the 2031 Notes and/or offset any cash payments Ciena makes in excess of the principal amount of the converted 2031 Notes, in the event that the market price per share of Ciena’s common stock, as measured under the terms of the 2031 Hedge Transactions, is greater than the 2031 Hedge Transactions strike price of $746.66. The 2031 Hedge Transactions meet the criteria in ASC 815-40 to be classified within Stockholders' Equity, and therefore these transactions are not revalued after their issuance.

[0001628280-26-060361:notes:126]
Ciena made a tax election to integrate the 2031 Notes and the 2031 Hedge Transactions. As a result of this election, Ciena expects the cost of the 2031 Hedge Transactions to be deductible as original issue discount interest for tax purposes over the term of the 2031 Notes. Ciena recorded a $230.0 million deferred tax asset with a corresponding adjustment to additional paid-in capital on our Condensed Consolidated Balance Sheet.

[0001628280-26-060361:notes:127]
Warrant Transactions

[0001628280-26-060361:notes:128]
On June 11, 2026, concurrently with entering into the 2031 Hedge Transactions, Ciena separately entered into privately-negotiated warrant transactions (the “2031 Warrant Transactions”), whereby Ciena sold to the counterparties warrants (the “2031 Warrants”) to purchase, subject to anti-dilution adjustments, 3.9 million shares, of its common stock at an initial strike price of $1,000 per share. Ciena received aggregate proceeds of $873.4 million from the 2031 Warrant Transactions with the counterparties. The 2031 Warrants expire in December 2031.

[0001628280-26-060361:notes:129]
If the market value per share of the common stock exceeds the strike price of the 2031 Warrants, the 2031 Warrants will have a dilutive effect on our earnings per share, unless Ciena elects, subject to certain conditions, to settle the 2031 Warrants in cash. The 2031 Warrants meet the criteria in ASC 815-40 to be classified within Stockholders' Equity, and therefore the 2031 Warrants are not revalued after issuance.

[0001628280-26-060361:notes:130]
Term Loan Payable

[0001628280-26-060361:notes:131]
Refinanced 2030 Term Loan

[0001628280-26-060361:notes:132]
On June 11, 2026, outstanding amounts under Ciena’s Refinanced 2030 Term Loan due October 28, 2030 were repaid in full. The net carrying value of the Refinanced 2030 Term Loan as of November 1, 2025 was $1.14 billion. Deferred debt issuance costs were amortized using the straight-line method, which approximated the effect of the effective interest rate method, through the maturity of the Refinanced 2030 Term Loan. The amortization of deferred debt issuance costs for the Refinanced 2030 Term Loan was included in interest expense, and was minimal during both the first nine months of fiscal 2026 and fiscal 2025.

[0001628280-26-060361:notes:133]
The proceeds from Ciena’s 2031 Notes were used to repay the full $1.14 billion for the outstanding principal of the Refinanced 2030 Term Loan, including accrued interest.

[0001628280-26-060361:notes:134]
Outstanding Senior Notes Payable

[0001628280-26-060361:notes:135]
2030 Notes

[0001628280-26-060361:notes:136]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0001628280-26-060361:notes:137]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0001628280-26-060361:notes:138]
|  |  | August 1, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,363) |  |  | $ | 397,637 |  |  | $ | 397,119 |  |  |  |

[0001628280-26-060361:notes:139]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first nine months of fiscal 2026 and fiscal 2025.

[0001628280-26-060361:notes:140]
As of August 1, 2026, the estimated fair value of the 2030 Notes was $379.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
REVOLVING CREDIT FACILITY
On February 10, 2023, pursuant to an ABL Credit Agreement dated October 28, 2019, as amended (the “ABL Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto (the “ABL Lenders”), and Bank of America, as administrative agent, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provided for a total commitment of $300.0 million to extend its maturity date to September 28, 2025.

[0001628280-26-060361:notes:141]
On October 24, 2023, pursuant to the Incremental Amendment Agreement to the Credit Agreement among Ciena, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC, and Blue Planet Software, Inc., as guarantors, Ciena incurred a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”), which replaced the ABL Credit Facility.

[0001628280-26-060361:notes:142]
On June 11, 2026, and in connection with the 2031 Notes offering (as defined in Note 13 above) Ciena, modified its Revolving Credit Facility to amend by, among other things:

[0001628280-26-060361:notes:143]
•extending the maturity date of the Revolving Credit Facility from October 24, 2028 to October 24, 2030;

[0001628280-26-060361:notes:144]
•removing the credit spread adjustment applicable to SOFR-based borrowings under the Revolving Credit Facility;

[0001628280-26-060361:notes:145]
•adding daily SOFR as an interest rate option for borrowings under the Revolving Credit Facility;

[0001628280-26-060361:notes:146]
•providing that the outstanding borrowings under the Revolving Credit Facility bear interest, at Ciena’s election, at a rate per annum (which is subject to increase during an event of default) of, at Ciena’s option, either term SOFR or daily SOFR (subject to a floor of 0.00%) plus a margin ranging from 1.25% to 2.00%, as applicable, or a base rate (subject to a floor of 1.00%) plus a margin ranging from 0.25% to 1.00%, in each case, with such interest rate margin based on Ciena’s consolidated net leverage ratio (the “Total Net Leverage Ratio”);

[0001628280-26-060361:notes:147]
•providing for a commitment fee payable on the unused portion of the Revolving Credit Facility at a per annum rate ranging from 0.20% to 0.30%, with the actual rate determined according to the Total Net Leverage Ratio; and

[0001628280-26-060361:notes:148]
•providing for increased flexibility with respect to the 2031 Notes offering, the 2031 Hedge Transactions, and the 2031 Warrant Transactions (as defined in Note 13 above).

[0001628280-26-060361:notes:149]
Under the Revolving Credit Facility, Ciena is also required to maintain certain financial maintenance covenants, including:

[0001628280-26-060361:notes:150]
•prior to an Investment Grade Event, a maximum Total Secured Net Leverage Ratio of no greater than 3.50 to 1.00 as of the end of any period of four fiscal quarters (provided, that in the event Ciena consummates a qualifying acquisition, Ciena can elect to increase the maximum Total Secured Net Leverage Ratio level to 4.00 to 1.00 for the fiscal quarter in which such qualifying acquisition is consummated and for the next five consecutive fiscal quarters);

[0001628280-26-060361:notes:151]
•on or after an Investment Grade Event, a maximum Total Net Leverage Ratio of no greater than 4.00 to 1.00 as of the end of any period of four fiscal quarters; and

[0001628280-26-060361:notes:152]
•a minimum Interest Coverage Ratio of no less than 3.00 to 1.00 as of the end of any period of four fiscal quarters.

[0001628280-26-060361:notes:153]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0001628280-26-060361:notes:154]
As of August 1, 2026, Ciena was in compliance with the above financial maintenance covenants. Also as of August 1, 2026, letters of credit totaling $40.7 million were issued under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of August 1, 2026.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-060361:notes:155]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended August 1, 2026 (in thousands):

[0001628280-26-060361:notes:156]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 1, 2025 | $ | 422 |  |  | $ | (3,803) |  |  |  |  | $ | (1,054) |  |  | $ | (50,600) |  |  | $ | (55,035) |  |
| Other comprehensive gain (loss) before reclassifications | (1,290) |  |  | (6,283) |  |  |  |  | 10,576 |  |  | (6,500) |  |  | (3,497) |  |
| Amounts reclassified from AOCI | — |  |  | 3,026 |  |  |  |  | (9,522) |  |  | — |  |  | (6,496) |  |
| Balance at August 1, 2026 | $ | (868) |  |  | $ | (7,060) |  |  |  |  | $ | — |  |  | $ | (57,100) |  |  | $ | (65,028) |  |

[0001628280-26-060361:notes:157]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended August 2, 2025 (in thousands):

[0001628280-26-060361:notes:158]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 2, 2024 | $ | 798 |  |  | $ | (4,880) |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications | (430) |  |  | 2,871 |  |  | (2,826) |  |  | 5,619 |  |  | 5,234 |  |
| Amounts reclassified from AOCI | — |  |  | 2,932 |  |  | (6,284) |  |  | — |  |  | (3,352) |  |
| Balance at August 2, 2025 | $ | 368 |  |  | $ | 923 |  |  | $ | (442) |  |  | $ | (45,678) |  |  | $ | (44,829) |  |

[0001628280-26-060361:notes:159]
[same as prior period, unchanged from 0001628280-26-040767:notes:122]


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-060361:notes:160]
[same as prior period, unchanged from 0001628280-26-040767:notes:123]

[0001628280-26-060361:notes:161]
[same as prior period, unchanged from 0001628280-26-040767:notes:124]

[0001628280-26-060361:notes:162]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Net income | $ | 266,418 |  |  | $ | 50,308 |  |  | $ | 634,921 |  |  | $ | 103,849 |  |
| Basic weighted average shares outstanding | 142,061 |  |  | 141,846 |  |  | 142,229 |  |  | 142,437 |  |
| Effect of dilutive potential common shares | 3,906 |  |  | 2,653 |  |  | 3,998 |  |  | 2,721 |  |
| Diluted weighted average shares outstanding | 145,967 |  |  | 144,499 |  |  | 146,227 |  |  | 145,158 |  |
| Basic EPS | $ | 1.88 |  |  | $ | 0.35 |  |  | $ | 4.46 |  |  | $ | 0.73 |  |
| Diluted EPS | $ | 1.83 |  |  | $ | 0.35 |  |  | $ | 4.34 |  |  | $ | 0.72 |  |
| Anti-dilutive stock unit awards, excluded | 2 |  |  | 1,371 |  |  | 9 |  |  | 1,330 |  |

[0001628280-26-060361:notes:163]
2031 Notes and Warrant Transactions

[0001628280-26-060361:notes:164]
Diluted EPS only includes the potential impact of the 2031 Notes and the 2031 Warrant Transactions when dilutive. The 2031 Notes are repayable in cash up to par value, and in cash or shares of common stock for the excess over par value. When the stock price is lower than the strike price, there is no dilutive or anti-dilutive impact. There is a dilutive impact only to the extent the average market price of Ciena’s common stock exceeds the conversion price. The 2031 Warrant Transactions

[0001628280-26-060361:notes:165]
increase the weighted-average number of common shares outstanding when the average market price of our common stock exceeds the $1,000 exercise price under the treasury stock method. See Note 13 above.
Neither the 2031 Notes nor the 2031 Warrant Transactions were included in Diluted EPS in the third quarter and first nine months of fiscal 2026.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-060361:notes:166]
[same as prior period, unchanged from 0001628280-26-040767:notes:126]

[0001628280-26-060361:notes:167]
[same as prior period, unchanged from 0001628280-26-040767:notes:127]

[0001628280-26-060361:notes:168]
During the first nine months of fiscal 2026, Ciena repurchased approximately 1.0 million shares of its common stock for an aggregate purchase price of approximately $335.3 million, which equates to an average price of $352.06 per share. As of August 1, 2026, Ciena has (i) repurchased 4.9 million shares for an aggregate purchase price of $665.0 million at an average price of $135.55 per share and (ii) has an aggregate of $335.0 million authorized and remaining under its stock repurchase program.

[0001628280-26-060361:notes:169]
Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0001628280-26-060361:notes:170]
[same as prior period, unchanged from 0001628280-26-040767:notes:129]

[0001628280-26-060361:notes:171]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $278.3 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2026 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-26-060361:notes:172]
[same as prior period, unchanged from 0001628280-26-040767:notes:131]

[0001628280-26-060361:notes:173]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Products | $ | 2,175 |  |  | $ | 2,027 |  |  | $ | 6,007 |  |  | $ | 5,810 |  |
| Services | 4,666 |  |  | 3,941 |  |  | 13,195 |  |  | 11,327 |  |
| Share-based compensation expense included in cost of goods sold | 6,841 |  |  | 5,968 |  |  | 19,202 |  |  | 17,137 |  |
| Research and development | 20,173 |  |  | 16,749 |  |  | 55,353 |  |  | 48,007 |  |
| Selling and marketing | 16,623 |  |  | 13,277 |  |  | 47,863 |  |  | 38,523 |  |
| General and administrative | 14,241 |  |  | 11,008 |  |  | 40,760 |  |  | 32,176 |  |
| Share-based compensation expense included in operating expense | 51,037 |  |  | 41,034 |  |  | 143,976 |  |  | 118,706 |  |
| Share-based compensation expense capitalized in inventory, net (1) | — |  |  | (74) |  |  | — |  |  | (147) |  |
| Total share-based compensation expense | $ | 57,878 |  |  | $ | 46,928 |  |  | $ | 163,178 |  |  | $ | 135,696 |  |

[0001628280-26-060361:notes:174]
[same as prior period, unchanged from 0001628280-26-040767:notes:133]

[0001628280-26-060361:notes:175]
As of August 1, 2026, total unrecognized share-based compensation expense was $394.9 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.52 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-060361:notes:176]
[same as prior period, unchanged from 0001628280-26-040767:notes:135]

[0001628280-26-060361:notes:177]
[same as prior period, unchanged from 0001628280-26-040767:notes:136]

[0001628280-26-060361:notes:178]
[same as prior period, unchanged from 0001628280-26-040767:notes:137]

[0001628280-26-060361:notes:179]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 1, |  | August 2, |  | August 1, |  | August 2, |
|  | 2026 |  | 2025 |  | 2026 |  | 2025 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 1,355,675 |  |  | $ | 941,354 |  |  | $ | 3,778,921 |  |  | $ | 2,628,811 |  |
| Platform Software and Services | 98,657 |  |  | 89,961 |  |  | 285,919 |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | 23,205 |  |  | 27,805 |  |  | 66,986 |  |  | 81,787 |  |
| Global Services | 193,592 |  |  | 160,265 |  |  | 537,084 |  |  | 436,456 |  |
| Total revenue | $ | 1,671,129 |  |  | $ | 1,219,385 |  |  | $ | 4,668,910 |  |  | $ | 3,417,523 |  |
| Segment gross profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 600,633 |  |  | $ | 365,769 |  |  | $ | 1,643,367 |  |  | $ | 1,021,850 |  |
| Platform Software and Services | 85,603 |  |  | 75,609 |  |  | 247,456 |  |  | 228,560 |  |
| Blue Planet Automation Software and Services | 9,376 |  |  | 15,527 |  |  | 22,339 |  |  | 45,709 |  |
| Global Services | 80,146 |  |  | 54,375 |  |  | 205,603 |  |  | 155,453 |  |
| Total segment gross profit | $ | 775,758 |  |  | $ | 511,280 |  |  | $ | 2,118,765 |  |  | $ | 1,451,572 |  |
| Research and development expense: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 187,689 |  |  | $ | 166,324 |  |  | $ | 552,242 |  |  | $ | 488,821 |  |
| Platform Software and Services | 18,913 |  |  | 18,539 |  |  | 56,603 |  |  | 53,070 |  |
| Blue Planet Automation Software and Services | 8,894 |  |  | 9,161 |  |  | 28,514 |  |  | 26,367 |  |
| Global Services | 1,004 |  |  | 1,125 |  |  | 3,324 |  |  | 3,164 |  |
| Total segment research and development expense | $ | 216,500 |  |  | $ | 195,149 |  |  | $ | 640,683 |  |  | $ | 571,422 |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 412,944 |  |  | $ | 199,445 |  |  | $ | 1,091,125 |  |  | $ | 533,029 |  |
| Platform Software and Services | 66,690 |  |  | 57,070 |  |  | 190,853 |  |  | 175,490 |  |
| Blue Planet Automation Software and Services | 482 |  |  | 6,366 |  |  | (6,175) |  |  | 19,342 |  |
| Global Services | 79,142 |  |  | 53,250 |  |  | 202,279 |  |  | 152,289 |  |
| Total segment profit | $ | 559,258 |  |  | $ | 316,131 |  |  | $ | 1,478,082 |  |  | $ | 880,150 |  |
| Less: Unallocated cost of goods sold | $ | 16,493 |  |  | $ | 8,201 |  |  | $ | 42,426 |  |  | $ | 23,834 |  |
| Less: Unallocated operating and non-operating expenses | 276,347 |  |  | 257,622 |  |  | 800,735 |  |  | 752,467 |  |
| Consolidated net income | $ | 266,418 |  |  | $ | 50,308 |  |  | $ | 634,921 |  |  | $ | 103,849 |  |

[0001628280-26-060361:notes:180]
[same as prior period, unchanged from 0001628280-26-040767:notes:139]

[0001628280-26-060361:notes:181]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets, goodwill, and maintenance spares, are not reviewed by Ciena's CODM for purposes of evaluating performance and allocating resources. As of August 1, 2026, equipment, building, furniture and fixtures, net, totaled $491.7 million, and operating ROU assets totaled $45.7 million, both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities.

[0001628280-26-060361:notes:182]
[same as prior period, unchanged from 0001628280-26-040767:notes:141]

[0001628280-26-060361:notes:183]
|  | August 1, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 188,824 |  |  | — |  |  | — |  |  | — |  |  | $ | 188,824 |  |
| Goodwill | $ | 268,100 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 513,340 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 102,280 |  |  | $ | 102,280 |  |
| Total assets assigned to segments |  |  |  |  |  |  |  |  | $ | 804,444 |  |
| Other unallocated assets |  |  |  |  |  |  |  |  | 7,192,796 |  |
| Total assets |  |  |  |  |  |  |  |  | $ | 7,997,240 |  |

[0001628280-26-060361:notes:184]
[same as prior period, unchanged from 0001628280-26-040767:notes:143]

[0001628280-26-060361:notes:185]
[same as prior period, unchanged from 0001628280-26-040767:notes:144]

[0001628280-26-060361:notes:186]
|  | August 1,2026 |  | November 1,2025 |
| Canada | $ | 427,861 |  |  | $ | 325,584 |  |
| United States | 53,412 |  |  | 44,634 |  |
| Other International (1) | 56,050 |  |  | 55,174 |  |
| Total | $ | 537,323 |  |  | $ | 425,392 |  |

[0001628280-26-060361:notes:187]
[same as prior period, unchanged from 0001628280-26-040767:notes:146]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-26-060361:notes:188]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0001628280-26-060361:notes:189]
Ciena is subject to various tax contingencies arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these contingencies will have a material effect on its financial position or cash flows.

[0001628280-26-060361:notes:190]
Share-based compensation expense impacts Ciena’s tax rate. These deductions are valued at vesting for tax purposes and can increase or decrease the effective tax rate in the period in which they vest.

[0001628280-26-060361:notes:191]
Litigation

[0001628280-26-060361:notes:192]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property-related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0001628280-26-060361:notes:193]
Purchase Order Obligations 
Ciena has certain advanced orders for supply of certain long lead time components. As of August 1, 2026, Ciena had $3.3 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust a portion of these orders.


## us-gaap:SubsequentEventsTextBlock

[0001628280-26-060361:notes:194]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0001628280-26-060361:notes:195]
From the end of the third quarter of fiscal 2026 through August 28, 2026, Ciena repurchased 88,896 shares of its common stock for an aggregate purchase price of $36.0 million at an average price of $404.52 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of August 28, 2026, Ciena has an aggregate of $299.0 million of authorized funds remaining under this repurchase program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-060361:notes:196]
The following table describes, for the third quarter of fiscal 2026, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0001628280-26-060361:notes:197]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Dino DiPerna(Executive Vice President and Chief Research & Development Officer) | Adoption (June 10, 2026) | Rule 10b5-1 trading arrangement | Sales | Until July 30, 2027, or such earlier date upon which all transactions are completed or expire without execution (1) | (2) |

[0001628280-26-060361:notes:198]
(1)    Sales under this arrangement will not begin until September 15, 2026, following expiration of Mr. DiPerna’s existing Rule 10b5-1 trading arrangement.

[0001628280-26-060361:notes:199]
(2)    The aggregate number of shares of common stock to be sold pursuant to Mr. DiPerna’s arrangement is up to (i) 996 shares of common stock, plus (ii) up to 100% of the net after-tax shares of common stock to be received as a result of the vesting on September 20, 2026 of an aggregate of 3,830 restricted stock units, plus (iii) up to 100% of the net after-tax shares of common stock to be received as a result of the vesting on December 20, 2026 of an aggregate of (a) 3,832 restricted stock units, (b) 7,162 earned performance stock units, (c) performance stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 2,216 shares subject to the award at the target level of performance, and (d) market stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 8,720 shares subject to the award at the target level of performance, plus (iv) up to 100% of the net after-tax shares of common stock to be received as a result of the vesting on March 20, 2027 of an aggregate of 3,001 restricted stock units, plus (v) up to 100% of the net after-tax shares of common stock to be received as a result of the vesting on June 20, 2027 of an aggregate of 3,004 restricted stock units. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.
