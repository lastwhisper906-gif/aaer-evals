# CIEN MD&A — 0000936395-25-000011


## mdna

[0000936395-25-000011:mdna:1]
[same as prior period, unchanged from 0000936395-24-000032:mdna:1]

[0000936395-25-000011:mdna:2]
[same as prior period, unchanged from 0000936395-24-000032:mdna:2]

[0000936395-25-000011:mdna:3]
[same as prior period, unchanged from 0000936395-24-000032:mdna:3]

[0000936395-25-000011:mdna:4]
[same as prior period, unchanged from 0000936395-24-000032:mdna:4]

[0000936395-25-000011:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations is designed to provide an understanding of Ciena’s financial condition, results of operations, and cash flows, and should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and in Item 8 of Part II of our 2024 Annual Report.

[0000936395-25-000011:mdna:6]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, video, data, AI, and voice. Our network solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network™, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking portfolio and our Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently, and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator NCS and advanced applications that deliver multi-layer domain control and operations for network operators. Through our Blue Planet Automation Software, we also enable complete service lifecycle management automation with productized OSS, including inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-25-000011:mdna:7]
Market Opportunity and Investment in Technology Innovation

[0000936395-25-000011:mdna:8]
23

[0000936395-25-000011:mdna:9]
The market into which we sell our communications networking solutions is dynamic and characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services, and new approaches, or “consumption models,” for designing and procuring networking solutions. Drivers of increased bandwidth demand include enterprise and consumer cloud network adoption, generative AI, 5G, high-definition video, and network operator focus on resilience and automation. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation.

[0000936395-25-000011:mdna:10]
We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures, and research and development spending represented 18.0% of our revenue in the first quarter of fiscal 2025. During the first quarter of fiscal 2025, we invested $192.7 million in research and development activities, an increase of 2.9% compared to first quarter of fiscal 2024. In particular, in an effort to capture certain market opportunities created by the impact of artificial intelligence (AI) on networks, we have continued to innovate, increase the performance of, and enhance the capabilities for our leading WaveLogicTM coherent modem technology in multiple form factors. Through this innovation, we seek to extend our leadership in our core business and leverage this to expand our addressable market into complementary and adjacent network applications, including inside and around the data center.

[0000936395-25-000011:mdna:11]
Business Momentum

[0000936395-25-000011:mdna:12]
During the first quarter of fiscal 2025, we continued to experience broad-based business momentum, with year-over-year order growth in our major customer segments, led by cloud providers and including continued improvement in orders from communications service providers. As a result, our revenue increased by 3.3% to $1.07 billion in the first quarter of fiscal 2025 as compared to $1.04 billion in the first quarter of fiscal 2024. Although our business remains subject to quarterly fluctuations due to customer purchasing patterns and supply chain dynamics, we continue to believe that certain trends and shifts in business and consumer behaviors and the drivers of bandwidth demand described above under “Market Opportunity and Investment in Technology Innovation” represent long-term opportunities for our business.

[0000936395-25-000011:mdna:13]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2024 Annual Report.

[0000936395-25-000011:mdna:14]
[same as prior period, unchanged from 0000936395-24-000032:mdna:14]

[0000936395-25-000011:mdna:15]
[same as prior period, unchanged from 0000936395-24-000032:mdna:15]

[0000936395-25-000011:mdna:16]
[same as prior period, unchanged from 0000936395-24-000032:mdna:16]

[0000936395-25-000011:mdna:17]
[same as prior period, unchanged from 0000936395-24-000032:mdna:17]

[0000936395-25-000011:mdna:18]
As a result of the factors described under “Overview” above, our revenue increased by 3.3%, or $34.5 million in the first quarter of fiscal 2025 as compared to the first quarter of fiscal 2024.

[0000936395-25-000011:mdna:19]
[same as prior period, unchanged from 0000936395-24-000032:mdna:20]

[0000936395-25-000011:mdna:20]
[same as prior period, unchanged from 0000936395-24-000032:mdna:21]

[0000936395-25-000011:mdna:21]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | 695,849 |  |  |  |  | 4.6 | % |  |  |  |  |  |  |  |  |
| %** | 67.9 | % |  | 67.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Routing and Switching | 93,169 |  |  | 111,387 |  |  |  |  | (16.4) | % |  |  |  |  |  |  |  |  |
| %** | 8.7 | % |  | 10.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Networking Platforms | 821,142 |  |  | 807,236 |  |  |  |  | 1.7 | % |  |  |  |  |  |  |  |  |
| %** | 76.6 | % |  | 77.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 95,067 |  |  | 89,745 |  |  |  |  | 5.9 | % |  |  |  |  |  |  |  |  |
| %** | 8.9 | % |  | 8.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | 26,032 |  |  | 13,942 |  |  |  |  | 86.7 | % |  |  |  |  |  |  |  |  |
| %** | 2.4 | % |  | 1.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 74,573 |  |  | 74,115 |  |  |  |  | 0.6 | % |  |  |  |  |  |  |  |  |
| %** | 7.0 | % |  | 7.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Installation and Deployment | 47,682 |  |  | 42,723 |  |  |  |  | 11.6 | % |  |  |  |  |  |  |  |  |
| %** | 4.4 | % |  | 4.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Consulting and Network Design | 7,764 |  |  | 9,948 |  |  |  |  | (22.0) | % |  |  |  |  |  |  |  |  |
| %** | 0.7 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Global Services | 130,019 |  |  | 126,786 |  |  |  |  | 2.5 | % |  |  |  |  |  |  |  |  |
| %** | 12.1 | % |  | 12.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  | 3.3 | % |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:22]
[same as prior period, unchanged from 0000936395-24-000032:mdna:23]

[0000936395-25-000011:mdna:23]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:24]
[same as prior period, unchanged from 0000936395-24-000032:mdna:25]

[0000936395-25-000011:mdna:25]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:26]
•Networking Platforms segment revenue increased by $13.9 million.

[0000936395-25-000011:mdna:27]
•Optical Networking products revenue increased by $32.1 million, primarily driven by increases in sales of our 6500 Packet-Optical Platforms, primarily to service provider customers, our 6500 Reconfigurable Line Systems (RLS) and our coherent pluggables, both primarily to cloud provider customers. These increases were partially offset by a reduction in Waveserver revenue, primarily related to decreased sales to cloud provider customers.

[0000936395-25-000011:mdna:28]
•Routing and Switching products revenue decreased by $18.2 million, primarily driven by decreases in sales of our 3000 and 5000 families of service delivery and aggregation switches, partially offset by an increase in sales of our virtualization software.

[0000936395-25-000011:mdna:29]
•Platform Software and Services segment revenue increased by $5.3 million, primarily reflecting sales increases of our software maintenance services, partially offset by sales decreases of our software platforms.

[0000936395-25-000011:mdna:30]
•Blue Planet Automation Software and Services segment revenue increased by $12.1 million primarily reflecting sales increases in software and services for our unified assurance and analytics.

[0000936395-25-000011:mdna:31]
•Global Services segment revenue increased by $3.2 million, primarily reflecting a sales increase in our installation and deployment services, partially offset by a sales decrease in our consulting and network design services.

[0000936395-25-000011:mdna:32]
[same as prior period, unchanged from 0000936395-24-000032:mdna:41]

[0000936395-25-000011:mdna:33]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period.

[0000936395-25-000011:mdna:34]
[same as prior period, unchanged from 0000936395-24-000032:mdna:43]

[0000936395-25-000011:mdna:35]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Americas | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  | 10.8 | % |  |  |  |  |  |  |  |  |
| %** | 74.2 | % |  | 69.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA | 157,916 |  |  | 207,413 |  |  |  |  | (23.9) | % |  |  |  |  |  |  |  |  |
| %** | 14.7 | % |  | 20.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APAC | 118,712 |  |  | 112,098 |  |  |  |  | 5.9 | % |  |  |  |  |  |  |  |  |
| %** | 11.1 | % |  | 10.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  | 3.3 | % |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:36]
[same as prior period, unchanged from 0000936395-24-000032:mdna:45]

[0000936395-25-000011:mdna:37]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:38]
[same as prior period, unchanged from 0000936395-24-000032:mdna:47]

[0000936395-25-000011:mdna:39]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:40]
•Americas revenue increased by $77.4 million, primarily driven by increased sales to communications service providers and cloud providers, partially offset by decreased sales to cable and multiservice operators, each primarily in the United States.

[0000936395-25-000011:mdna:41]
•EMEA revenue decreased by $49.5 million, primarily driven by decreased sales to cloud providers and to submarine network operators.

[0000936395-25-000011:mdna:42]
•APAC revenue increased by $6.6 million, primarily driven by increased sales to communications service providers in India.

[0000936395-25-000011:mdna:43]
[same as prior period, unchanged from 0000936395-24-000032:mdna:80]

[0000936395-25-000011:mdna:44]
During the first quarter of fiscal 2025, approximately 15.2% of our revenue was non-U.S. Dollar-denominated. During the first quarter of fiscal 2025 as compared to the first quarter of fiscal 2024, the U.S. Dollar primarily strengthened against other currencies. These currency fluctuations had an adverse effect on our revenue reported in U.S. Dollars of approximately $6.5 million, or 0.6%, as compared to the first quarter of fiscal 2024.

[0000936395-25-000011:mdna:45]
[same as prior period, unchanged from 0000936395-24-000032:mdna:56]

[0000936395-25-000011:mdna:46]
There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. For example, early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonic line systems, pluggable solutions, and installation services, with the intent to improve margin as we sell channel cards, advanced software, and maintenance services to customers as they add capacity. The component elements that comprise our product cost of goods sold and services cost of goods sold, and certain factors that can cause gross margin to fluctuate, are described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2024 Annual Report.

[0000936395-25-000011:mdna:47]
[same as prior period, unchanged from 0000936395-24-000032:mdna:58]

[0000936395-25-000011:mdna:48]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  | 3.3 | % |  |  |  |  |  |  |  |  |
| Total cost of goods sold | 600,439 |  |  | 570,747 |  |  |  |  | 5.2 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 471,821 |  |  | $ | 466,962 |  |  |  |  | 1.0 | % |  |  |  |  |  |  |  |  |
| %** | 44.0 | % |  | 45.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:49]
[same as prior period, unchanged from 0000936395-24-000032:mdna:60]

[0000936395-25-000011:mdna:50]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:51]
[same as prior period, unchanged from 0000936395-24-000032:mdna:62]

[0000936395-25-000011:mdna:52]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:53]
•Gross profit increased by $4.9 million. Gross margin decreased by 100 basis points, primarily reflecting decreased product margin, partially offset by increased services margin.

[0000936395-25-000011:mdna:54]
•Gross profit on products decreased by $5.3 million from $369.3 million for the first quarter of fiscal 2024 to $364.0 million for the first quarter of fiscal 2025. Product gross margin decreased by 160 basis points, from 44.2% for the first quarter of fiscal 2024 to 42.6% for the first quarter of fiscal 2025, primarily due to product mix, partially offset by certain manufacturing efficiencies.

[0000936395-25-000011:mdna:55]
•Gross profit on services increased by $10.2 million from $97.7 million for the first quarter of fiscal 2024 to $107.8 million for the first quarter of fiscal 2025. Gross margin increased by 120 basis points, from 48.4% for the first quarter of fiscal 2024 to 49.6% for the first quarter of fiscal 2025, primarily due to efficiencies in delivering platform software related services.

[0000936395-25-000011:mdna:56]
[same as prior period, unchanged from 0000936395-24-000032:mdna:79]

[0000936395-25-000011:mdna:57]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2024 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-25-000011:mdna:58]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Research and development | $ | 192,663 |  |  | $ | 187,269 |  |  |  |  | 2.9 | % |  |  |  |  |  |  |  |  |
| %** | 18.0 | % |  | 18.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing | 136,504 |  |  | 128,158 |  |  |  |  | 6.5 | % |  |  |  |  |  |  |  |  |
| %** | 12.7 | % |  | 12.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | 53,902 |  |  | 54,683 |  |  |  |  | (1.4) | % |  |  |  |  |  |  |  |  |
| %** | 5.0 | % |  | 5.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,544 |  |  | 4,971 |  |  |  |  | (68.9) | % |  |  |  |  |  |  |  |  |
| %** | 0.1 | % |  | 0.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets | 6,545 |  |  | 7,252 |  |  |  |  | (9.7) | % |  |  |  |  |  |  |  |  |
| %** | 0.6 | % |  | 0.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 391,158 |  |  | $ | 382,333 |  |  |  |  | 2.3 | % |  |  |  |  |  |  |  |  |
| %** | 36.5 | % |  | 36.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:59]
[same as prior period, unchanged from 0000936395-24-000032:mdna:64]

[0000936395-25-000011:mdna:60]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:61]
[same as prior period, unchanged from 0000936395-24-000032:mdna:87]

[0000936395-25-000011:mdna:62]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:63]
•Research and development expense increased by $5.4 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs partially offset by lower prototype expense.

[0000936395-25-000011:mdna:64]
•Selling and marketing expense increased by $8.3 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs primarily due to higher commission expense.

[0000936395-25-000011:mdna:65]
•General and administrative expense remained relatively unchanged.

[0000936395-25-000011:mdna:66]
•Significant asset impairments and restructuring costs decreased by $3.4 million, primarily due to a reduction in restructuring activities that we have taken with respect to our global workforce.

[0000936395-25-000011:mdna:67]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-25-000011:mdna:68]
Currency Fluctuations

[0000936395-25-000011:mdna:69]
Approximately 47.5% of our operating expense was non-U.S. Dollar-denominated during the first quarter of fiscal 2025. During the first quarter of fiscal 2025, as compared to the first quarter of fiscal 2024, the U.S. Dollar primarily strengthened against other currencies. These currency fluctuations, net of hedging, had the effect of reducing our operating expense by approximately $5.5 million, or 1.4%, as compared to the first quarter of fiscal 2024.

[0000936395-25-000011:mdna:70]
[same as prior period, unchanged from 0000936395-24-000032:mdna:116]

[0000936395-25-000011:mdna:71]
Segment profit (loss) is determined based on internal performance measures used by our chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; interest and other income, net; interest expense; loss on extinguishment and modification of debt; and provision for income taxes.

[0000936395-25-000011:mdna:72]
[same as prior period, unchanged from 0000936395-24-000032:mdna:117]

[0000936395-25-000011:mdna:73]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 167,079 |  |  | $ | 183,775 |  |  |  |  | (9.1) | % |  |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 63,125 |  |  | $ | 58,004 |  |  |  |  | 8.8 | % |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | $ | 4,576 |  |  | $ | (7,069) |  |  |  |  | 164.7 | % |  |  |  |  |  |  |  |  |
| Global Services | $ | 44,378 |  |  | $ | 44,983 |  |  |  |  | (1.3) | % |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:74]
[same as prior period, unchanged from 0000936395-24-000032:mdna:68]

[0000936395-25-000011:mdna:75]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:76]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:77]
•Networking Platforms segment profit decreased by $16.7 million, primarily due to lower product margin as described above and higher research and development costs, partially offset by higher sales volume.

[0000936395-25-000011:mdna:78]
•Platform Software and Services segment profit increased by $5.1 million, primarily due to higher services sales volume and improved services margin as described above.

[0000936395-25-000011:mdna:79]
•Blue Planet Automation Software and Services segment profit increased by $11.6 million, primarily due to higher sales volume as described above, and improved margins on services.

[0000936395-25-000011:mdna:80]
•Global Services segment profit slightly decreased, primarily due to reduced margins on maintenance support and training partially offset by increased sales volume.

[0000936395-25-000011:mdna:81]
[same as prior period, unchanged from 0000936395-24-000032:mdna:102]

[0000936395-25-000011:mdna:82]
[same as prior period, unchanged from 0000936395-24-000032:mdna:103]

[0000936395-25-000011:mdna:83]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | February 1, 2025 |  | January 27, 2024 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Interest and other income, net | $ | 11,578 |  |  | $ | 10,650 |  |  |  |  | 8.7 | % |  |  |  |  |  |  |  |  |
| %** | 1.1 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | (22,918) |  |  | $ | (23,776) |  |  |  |  | (3.6) | % |  |  |  |  |  |  |  |  |
| %** | 2.1 | % |  | 2.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | (729) |  |  | $ | — |  |  |  |  | 100.0 | % |  |  |  |  |  |  |  |  |
| %** | (0.1) | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | $ | 24,022 |  |  | $ | 21,956 |  |  |  |  | 9.4 | % |  |  |  |  |  |  |  |  |
| %** | 2.2 | % |  | 2.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-25-000011:mdna:84]
[same as prior period, unchanged from 0000936395-24-000032:mdna:85]

[0000936395-25-000011:mdna:85]
*    Denotes % change from fiscal 2024 to fiscal 2025

[0000936395-25-000011:mdna:86]
[same as prior period, unchanged from 0000936395-24-000032:mdna:107]

[0000936395-25-000011:mdna:87]
Quarter ended February 1, 2025 as compared to the quarter ended January 27, 2024

[0000936395-25-000011:mdna:88]
•Interest and other income, net increased primarily resulting from the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-25-000011:mdna:89]
•Interest expense remained relatively unchanged. For more information on our short-term and long-term debt, see Note 11 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000011:mdna:90]
•Loss on extinguishment and modification of debt reflects the refinance of our 2030 Term Loan. See Note 11 to our Condensed Consolidated Financial Statements in Item 1 of Part 1 of this report for more details.

[0000936395-25-000011:mdna:91]
•Provision for income taxes increased by $2.1 million, primarily due to income in jurisdictions with higher tax rates.

[0000936395-25-000011:mdna:92]
[same as prior period, unchanged from 0000936395-24-000032:mdna:131]

[0000936395-25-000011:mdna:93]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-25-000011:mdna:94]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of February 1, 2025, totaled $1.3 billion, as well as the unused portion of our senior secured revolving credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of February 1, 2025, letters of credit totaling $58.3 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of February 1, 2025.

[0000936395-25-000011:mdna:95]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $157.9 million as of February 1, 2025. Approximately $92.5 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-25-000011:mdna:96]
Stock Repurchase Authorization. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first three months of fiscal 2025, we repurchased $79.2 million of our common stock under the stock repurchase program, and $920.8 million remained under the current repurchase authorization as of February 1, 2025. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 14 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as Item 2 of Part II of this report.

[0000936395-25-000011:mdna:97]
Cash Flows

[0000936395-25-000011:mdna:98]
[same as prior period, unchanged from 0000936395-24-000032:mdna:135]

[0000936395-25-000011:mdna:99]
|  | February 1,2025 |  | November 2,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 874,749 |  |  | $ | 934,863 |  |  | $ | (60,114) |  |
| Short-term investments in marketable debt securities | 337,320 |  |  | 316,343 |  |  | 20,977 |  |
| Long-term investments in marketable debt securities | 105,035 |  |  | 80,920 |  |  | 24,115 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,317,104 |  |  | $ | 1,332,126 |  |  | $ | (15,022) |  |

[0000936395-25-000011:mdna:100]
Cash, cash equivalents and investments decreased by $15.0 million during the first three months of fiscal 2025. Cash from operations generated $103.7 million which was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $81.2 million; (ii) cash used to fund our investing activities for capital expenditures totaling $26.9 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $25.5 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $17.1 million in cash during the three months ended February 1, 2025.

[0000936395-25-000011:mdna:101]
[same as prior period, unchanged from 0000936395-24-000032:mdna:141]

[0000936395-25-000011:mdna:102]
The following sections set forth the components of our $103.7 million of cash provided by operating activities during the first three months of fiscal 2025 as net income (adjusted for non-cash charges) of $111.7 million was partially offset by a net use of cash in operating assets and liabilities of $8.0 million.

[0000936395-25-000011:mdna:103]
[same as prior period, unchanged from 0000936395-24-000032:mdna:143]

[0000936395-25-000011:mdna:104]
[same as prior period, unchanged from 0000936395-24-000032:mdna:144]

[0000936395-25-000011:mdna:105]
|  | Three Months Ended |
|  | February 1, 2025 |
| Net income | $ | 44,572 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 24,679 |  |
| Share-based compensation expense | 40,806 |  |
| Amortization of intangible assets | 8,778 |  |
| Deferred taxes | (17,085) |  |
| Provision for inventory excess and obsolescence | 10,918 |  |
| Provision for warranty | 5,697 |  |
| Other | (6,655) |  |
| Net income (adjusted for non-cash charges) | $ | 111,710 |  |

[0000936395-25-000011:mdna:106]
Operating Assets and Liabilities

[0000936395-25-000011:mdna:107]
Operating asset and liability requirements increased by $8.0 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0000936395-25-000011:mdna:108]
|  | Three Months Ended |
|  | February 1, 2025 |
| Accounts receivable | $ | (33,454) |  |
| Inventories | (35,844) |  |
| Prepaid expenses and other | 92,036 |  |
| Accounts payable, accruals, and other obligations | (49,577) |  |
| Deferred revenue | 20,311 |  |
| Operating lease assets and liabilities, net | (1,459) |  |
| Total cash consumed in operating assets and liabilities | $ | (7,987) |  |

[0000936395-25-000011:mdna:109]
As compared to the end of fiscal 2024, for the first three months of fiscal 2025:

[0000936395-25-000011:mdna:110]
•The change in accounts receivable primarily reflects the timing of cash collections from customers;

[0000936395-25-000011:mdna:111]
•The change in inventories primarily reflects increases in raw materials;

[0000936395-25-000011:mdna:112]
•The change in prepaid expenses and other primarily reflects reduced refundable cash advances to a third-party contract manufacturer and lower non-trade receivables;

[0000936395-25-000011:mdna:113]
•The change in accounts payable, accruals, and other obligations primarily reflects the timing of payments to suppliers, our annual cash incentive compensation plans and income taxes;

[0000936395-25-000011:mdna:114]
•The change in deferred revenue represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-25-000011:mdna:115]
•The change in operating lease assets and liabilities, net, represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-25-000011:mdna:116]
Our days sales outstanding (“DSOs”) increased from 88 for the first three months of fiscal 2024 to 90 for the first three months of fiscal 2025. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 1.9 for the first three months of fiscal 2024 to 2.3 for the first three months of fiscal 2025.

[0000936395-25-000011:mdna:117]
[same as prior period, unchanged from 0000936395-24-000032:mdna:157]

[0000936395-25-000011:mdna:118]
[same as prior period, unchanged from 0000936395-24-000032:mdna:158]

[0000936395-25-000011:mdna:119]
|  | Three Months Ended |
|  | February 1, 2025 |
| 2030 Term Loan terminated January 17, 2025(1) | $ | 18,639 |  |
| Refinanced 2030 Term Loan due October 28, 2030(2) | 9 |  |
| 2030 Senior Notes due January 31, 2030(3) | 8,000 |  |
| Interest rate swaps(4) | (2,424) |  |
| Revolving Credit Facility(5) | 466 |  |
| Finance leases | 869 |  |
| Cash paid during period | $ | 25,559 |  |

[0000936395-25-000011:mdna:120]
(1) The 2030 Term Loan bore interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%.

[0000936395-25-000011:mdna:121]
(2) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the first quarter of fiscal 2025, the interest rate on the Refinanced 2030 Term Loan was 6.05%.

[0000936395-25-000011:mdna:122]
(3) The 2030 Notes bear interest at a rate of 4.00% per annum. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year.

[0000936395-25-000011:mdna:123]
(4) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loan at 3.47% through January 2028 and another $350.0 million of our Term Loan at 2.968% through September 2025.

[0000936395-25-000011:mdna:124]
(5) During the first three months of fiscal 2025, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-25-000011:mdna:125]
For additional information about our debt and interest rate swaps, see Notes 10 and 11 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000011:mdna:126]
[same as prior period, unchanged from 0000936395-24-000032:mdna:165]

[0000936395-25-000011:mdna:127]
Our contractual obligations have not changed materially since November 2, 2024. For a summary of our contractual obligations, see Item 7 of Part II of the 2024 Annual Report.

[0000936395-25-000011:mdna:128]
[same as prior period, unchanged from 0000936395-24-000032:mdna:168]

[0000936395-25-000011:mdna:129]
Our critical accounting policies and estimates have not changed materially since November 2, 2024. For a discussion of our critical accounting policies and estimates, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Item 7 of Part II of our 2024 Annual Report.

[0000936395-25-000011:mdna:130]
[same as prior period, unchanged from 0000936395-24-000032:mdna:170]

[0000936395-25-000011:mdna:131]
[same as prior period, unchanged from 0000936395-24-000032:mdna:171]
