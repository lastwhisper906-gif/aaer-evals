# CIEN note change history — 0000936395-24-000032 → 0000936395-25-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:1]
Purchase Obligations
  (was, 2024-09-04, similarity 0.8696):
[0000936395-24-000032:note_history:1]
Purchase Order Obligations

- changed (2025-03-12):
[0000936395-25-000011:note_history:2]
Ciena has certain advanced commitments for supply of certain long lead time components. As of February 1, 2025, Ciena had $1.7 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.
  (was, 2024-09-04, similarity 0.9456):
[0000936395-24-000032:note_history:2]
Ciena has certain advanced orders for supply of certain long lead time components. As of July 27, 2024, Ciena had $1.5 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:3]
INTERIM FINANCIAL STATEMENTS
The interim financial statements for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) included herein have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”).
  (was, 2024-09-04, similarity 0.9439):
[0000936395-24-000032:note_history:3]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”).

- changed (2025-03-12):
[0000936395-25-000011:note_history:4]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.
  (was, 2024-09-04, similarity 0.9544):
[0000936395-24-000032:note_history:4]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 28, 2023 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended October 28, 2023 (the “2023 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2024 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2023 was a 52-week fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:5]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.
  (was, 2024-09-04, similarity 0.916):
[0000936395-24-000032:note_history:5]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2023 Annual Report.

- changed (2025-03-12):
[0000936395-25-000011:note_history:6]
Accounting Standards - Not Yet Effective
  (was, 2024-09-04, similarity 0.8602):
[0000936395-24-000032:note_history:6]
Newly Issued Accounting Standards - Not Yet Effective

- added (2025-03-12):
[0000936395-25-000011:note_history:7]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

- added (2025-03-12):
[0000936395-25-000011:note_history:8]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- added (2025-03-12):
[0000936395-25-000011:note_history:9]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- removed (2025-03-12):
[0000936395-24-000032:note_history:10]
Newly Issued Accounting Standards - Effective

- removed (2025-03-12):
[0000936395-24-000032:note_history:11]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

- removed (2025-03-12):
[0000936395-24-000032:note_history:12]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- removed (2025-03-12):
[0000936395-24-000032:note_history:13]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- removed (2025-03-12):
[0000936395-24-000032:note_history:14]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate Related Disclosures for Investors, which will require registrants to provide certain climate-related information in their registration statements and annual reports. The rules will require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. Ciena is currently evaluating the impact of these final rules on its consolidated financial statements and related disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:15]
Refinanced 2030 Term Loan
  (was, 2024-09-04, similarity 0.9302):
[0000936395-24-000032:note_history:15]
Refinanced Term Loans

- added (2025-03-12):
[0000936395-25-000011:note_history:16]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena

- added (2025-03-12):
[0000936395-25-000011:note_history:17]
maintained a senior secured term loan with an outstanding aggregate principal amount as of January 17, 2025 of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

- added (2025-03-12):
[0000936395-25-000011:note_history:18]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

- added (2025-03-12):
[0000936395-25-000011:note_history:19]
•mature on October 24, 2030;

- added (2025-03-12):
[0000936395-25-000011:note_history:20]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date, with the balance payable at maturity;

- added (2025-03-12):
[0000936395-25-000011:note_history:21]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

- added (2025-03-12):
[0000936395-25-000011:note_history:22]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

- added (2025-03-12):
[0000936395-25-000011:note_history:23]
•be repayable at any time at Ciena’s election, provided that repayment of the Refinanced 2030 Term Loan with proceeds of certain indebtedness prior to July 17, 2025 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and

- added (2025-03-12):
[0000936395-25-000011:note_history:24]
•except as described above or otherwise set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

- added (2025-03-12):
[0000936395-25-000011:note_history:25]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

- changed (2025-03-12):
[0000936395-25-000011:note_history:26]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):
  (was, 2024-09-04, similarity 0.9328):
[0000936395-24-000032:note_history:26]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

- added (2025-03-12):
[0000936395-25-000011:note_history:27]
|  |  | February 1, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,155,405 |  |  | $ | (4,103) |  |  | $ | (5,238) |  |  | $ | 1,146,064 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:28]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during the first three months of fiscal 2025 and fiscal 2024.
  (was, 2024-09-04, similarity 0.6528):
[0000936395-24-000032:note_history:28]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $5.8 million as of July 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.7 million during the first nine months of fiscal 2024.

- changed (2025-03-12):
[0000936395-25-000011:note_history:29]
As of February 1, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.16 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2024-09-04, similarity 0.8923):
[0000936395-24-000032:note_history:29]
As of July 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2025-03-12):
[0000936395-25-000011:note_history:30]
|  |  | February 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,400) |  |  | $ | 396,600 |  |  | $ | 396,427 |  |  |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:31]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first three months of fiscal 2025 and fiscal 2024.
  (was, 2024-09-04, similarity 0.6991):
[0000936395-24-000032:note_history:31]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $3.7 million as of July 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.5 million during both the first nine months of fiscal 2024 and fiscal 2023.

- changed (2025-03-12):
[0000936395-25-000011:note_history:32]
As of February 1, 2025, the estimated fair value of the 2030 Notes was $368.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2024-09-04, similarity 0.9837):
[0000936395-24-000032:note_history:32]
As of July 27, 2024, the estimated fair value of the 2030 Notes was $367.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2025-03-12):
[0000936395-24-000032:note_history:33]
2030 New Term Loan

- removed (2025-03-12):
[0000936395-24-000032:note_history:34]
On October 24, 2023, Ciena entered into an Incremental Amendment Agreement to its Credit Agreement to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion maturing on October 24, 2030 (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”). The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.7 million annually, with the remaining balance payable at maturity.

- removed (2025-03-12):
[0000936395-24-000032:note_history:35]
|  |  | July 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,164,150 |  |  | $ | (4,560) |  |  | $ | (5,830) |  |  | $ | 1,153,760 |  |  | $ | 1,159,371 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:36]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the 2025 Term Loan (as defined below) and the 2030 Term Loan (as defined below), together the Refinanced Term Loans, including accrued interest.

- removed (2025-03-12):
[0000936395-24-000032:note_history:37]
2025 Term Loan

- removed (2025-03-12):
[0000936395-24-000032:note_history:38]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace the London Interbank Offered Rate (LIBOR) with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million for the first nine months of fiscal 2023.

- removed (2025-03-12):
[0000936395-24-000032:note_history:39]
2030 Term Loan

- removed (2025-03-12):
[0000936395-24-000032:note_history:40]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.3 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was $0.4 million for the first nine months of fiscal 2023.

- removed (2025-03-12):
[0000936395-24-000032:note_history:41]
|  |  | July 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,745) |  |  | $ | 396,255 |  |  | $ | 395,735 |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:42]
|  | February 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 328,949 |  |  | $ | 591 |  |  | $ | (44) |  |  | $ | 329,496 |  |
| Corporate debt securities | 106,044 |  |  | 126 |  |  | (53) |  |  | 106,117 |  |
| Time deposits | 92,937 |  |  | 2 |  |  | (2) |  |  | 92,937 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |
| Included in cash equivalents | $ | 86,195 |  |  | $ | — |  |  | $ | — |  |  | $ | 86,195 |  |
| Included in short-term investments | 336,734 |  |  | 608 |  |  | (22) |  |  | 337,320 |  |
| Included in long-term investments | 105,001 |  |  | 111 |  |  | (77) |  |  | 105,035 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |
  (was, 2024-09-04, similarity 0.9897):
[0000936395-24-000032:note_history:42]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

- added (2025-03-12):
[0000936395-25-000011:note_history:43]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:44]
The following table summarizes the final legal maturities of debt investments as of February 1, 2025 (in thousands):
  (was, 2024-09-04, similarity 0.9636):
[0000936395-24-000032:note_history:44]
The following table summarizes the final legal maturities of debt investments as of July 27, 2024 (in thousands):

- removed (2025-03-12):
[0000936395-24-000032:note_history:45]
|  | July 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 260,879 |  |  | $ | 250 |  |  | $ | (119) |  |  | $ | 261,010 |  |
| Corporate debt securities | 57,791 |  |  | 64 |  |  | (19) |  |  | 57,836 |  |
| Time deposits | 96,127 |  |  | 7 |  |  | — |  |  | 96,134 |  |
|  | $ | 414,797 |  |  | $ | 321 |  |  | $ | (138) |  |  | $ | 414,980 |  |
| Included in cash equivalents | $ | 85,337 |  |  | $ | — |  |  | $ | — |  |  | $ | 85,337 |  |
| Included in short-term investments | 217,761 |  |  | 158 |  |  | (109) |  |  | 217,810 |  |
| Included in long-term investments | 111,699 |  |  | 163 |  |  | (29) |  |  | 111,833 |  |
|  | $ | 414,797 |  |  | $ | 321 |  |  | $ | (138) |  |  | $ | 414,980 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:46]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):
  (was, 2024-09-04, similarity 0.9328):
[0000936395-24-000032:note_history:46]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

- added (2025-03-12):
[0000936395-25-000011:note_history:47]
|  |  | February 1, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,155,405 |  |  | $ | (4,103) |  |  | $ | (5,238) |  |  | $ | 1,146,064 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- added (2025-03-12):
[0000936395-25-000011:note_history:48]
|  |  | February 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,400) |  |  | $ | 396,600 |  |  | $ | 396,427 |  |  |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:49]
|  |  | July 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,164,150 |  |  | $ | (4,560) |  |  | $ | (5,830) |  |  | $ | 1,153,760 |  |  | $ | 1,159,371 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:50]
|  |  | July 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,745) |  |  | $ | 396,255 |  |  | $ | 395,735 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:51]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2024-09-04, similarity 0.8934):
[0000936395-24-000032:note_history:51]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- changed (2025-03-12):
[0000936395-25-000011:note_history:52]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
  (was, 2024-09-04, similarity 0.8777):
[0000936395-24-000032:note_history:52]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:53]
|  | Quarter Ended January 27, 2024 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
  (was, 2024-09-04, similarity 0.8909):
[0000936395-24-000032:note_history:53]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:54]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2024-09-04, similarity 0.9388):
[0000936395-24-000032:note_history:54]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2025-03-12):
[0000936395-25-000011:note_history:55]
|  |  | Quarter Ended |  |  |
|  |  | February 1, |  | January 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  |  |
| EMEA |  | 157,916 |  |  | 207,413 |  |  |  |  |  |
| APAC |  | 118,712 |  |  | 112,098 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  |  |
  (was, 2024-09-04, similarity 0.7414):
[0000936395-24-000032:note_history:55]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,605 |  |  | $ | 749,479 |  |  | $ | 2,099,680 |  |  | $ | 2,308,934 |  |
| EMEA |  | 135,009 |  |  | 152,834 |  |  | 498,212 |  |  | 479,053 |  |
| APAC |  | 88,694 |  |  | 165,573 |  |  | 292,951 |  |  | 469,075 |  |
| Total revenue by geographic distribution |  | $ | 942,308 |  |  | $ | 1,067,886 |  |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:56]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:57]
|  | Nine months ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:58]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- removed (2025-03-12):
[0000936395-24-000032:note_history:59]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cloud Provider | $ | 137,184 |  |  | $ | 124,897 |  |  | $ | 331,631 |  |  | $ | 369,678 |  |
| AT&T | 113,082 |  |  | n/a |  | 324,787 |  |  | 357,382 |  |
| Total | $ | 250,266 |  |  | $ | 124,897 |  |  | $ | 656,418 |  |  | $ | 727,060 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:60]
_____________________________________

- removed (2025-03-12):
[0000936395-24-000032:note_history:61]
n/a    Denotes revenue representing less than 10% of total revenue for the period


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-03-12):
[0000936395-25-000011:note_history:62]
REVENUE
Segment and Product Line Disaggregation of Revenue
  (was, 2024-09-04, similarity 0.7253):
[0000936395-24-000032:note_history:62]
REVENUE
Disaggregation of Revenue

- added (2025-03-12):
[0000936395-25-000011:note_history:63]
Ciena’s disaggregated segment and product line revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 16 below.

- changed (2025-03-12):
[0000936395-25-000011:note_history:64]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2024-09-04, similarity 0.8934):
[0000936395-24-000032:note_history:64]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- changed (2025-03-12):
[0000936395-25-000011:note_history:65]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
  (was, 2024-09-04, similarity 0.8777):
[0000936395-24-000032:note_history:65]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:66]
|  | Quarter Ended January 27, 2024 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
  (was, 2024-09-04, similarity 0.8909):
[0000936395-24-000032:note_history:66]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:67]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products.
  (was, 2024-09-04, similarity 0.6042):
[0000936395-24-000032:note_history:67]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system. This product line also includes the WaveLogic 5 Nano (WL5n) 100G-400G coherent pluggable transceivers.

- added (2025-03-12):
[0000936395-25-000011:note_history:68]
•Routing and Switching - includes the 3000 and 5000 series of service delivery and aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and passive optical network and other routing and switching portfolio products.

- added (2025-03-12):
[0000936395-25-000011:note_history:69]
Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations.

- added (2025-03-12):
[0000936395-25-000011:note_history:70]
•Platform Software and Services revenue reflects sales of Ciena’s Platform Software and Platform Services.

- added (2025-03-12):
[0000936395-25-000011:note_history:71]
•Platform Software - includes Ciena’s Navigator Network Control SuiteTM domain controller solution and its applications, and legacy software solutions.

- added (2025-03-12):
[0000936395-25-000011:note_history:72]
•Platform Services - includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

- added (2025-03-12):
[0000936395-25-000011:note_history:73]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2025-03-12):
[0000936395-25-000011:note_history:74]
•Blue Planet Automation Software and Services revenue reflects sales of Blue Planet Automation Software and Blue Planet Services.

- added (2025-03-12):
[0000936395-25-000011:note_history:75]
•Blue Planet Automation Software - includes inventory management, orchestration, route optimization and analysis, and unified assurance and analytics software.

- added (2025-03-12):
[0000936395-25-000011:note_history:76]
•Blue Planet Services - includes sales of subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.

- added (2025-03-12):
[0000936395-25-000011:note_history:77]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2025-03-12):
[0000936395-25-000011:note_history:78]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities.

- added (2025-03-12):
[0000936395-25-000011:note_history:79]
Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2025-03-12):
[0000936395-25-000011:note_history:80]
Revenue Recognition

- added (2025-03-12):
[0000936395-25-000011:note_history:81]
•Revenue from the Networking Platforms segment includes, in addition to the products described above, sales of operating system software and enhanced software features embedded therein, which are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- added (2025-03-12):
[0000936395-25-000011:note_history:82]
•Revenue from software platforms typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control.

- added (2025-03-12):
[0000936395-25-000011:note_history:83]
•Revenue from software subscription and support is recognized ratably over the period during which the services are performed.

- added (2025-03-12):
[0000936395-25-000011:note_history:84]
•Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Global Services are considered a distinct performance obligation where revenue is generally recognized over time.

- added (2025-03-12):
[0000936395-25-000011:note_history:85]
•Revenue from maintenance support is recognized ratably over the period during which the services are performed.

- added (2025-03-12):
[0000936395-25-000011:note_history:86]
•Revenue from installation and deployment services and consulting and network design services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- added (2025-03-12):
[0000936395-25-000011:note_history:87]
•Revenue from training services is generally recognized at a point in time upon completion of the service.

- added (2025-03-12):
[0000936395-25-000011:note_history:88]
For additional information on Ciena’s revenue recognition policy, see the Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

- added (2025-03-12):
[0000936395-25-000011:note_history:89]
Geographic Disaggregation of Revenue

- changed (2025-03-12):
[0000936395-25-000011:note_history:90]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2024-09-04, similarity 0.9993):
[0000936395-24-000032:note_history:90]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2025-03-12):
[0000936395-25-000011:note_history:91]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2024-09-04, similarity 0.9388):
[0000936395-24-000032:note_history:91]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2025-03-12):
[0000936395-25-000011:note_history:92]
|  |  | Quarter Ended |  |  |
|  |  | February 1, |  | January 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  |  |
| EMEA |  | 157,916 |  |  | 207,413 |  |  |  |  |  |
| APAC |  | 118,712 |  |  | 112,098 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  |  |
  (was, 2024-09-04, similarity 0.7414):
[0000936395-24-000032:note_history:92]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,605 |  |  | $ | 749,479 |  |  | $ | 2,099,680 |  |  | $ | 2,308,934 |  |
| EMEA |  | 135,009 |  |  | 152,834 |  |  | 498,212 |  |  | 479,053 |  |
| APAC |  | 88,694 |  |  | 165,573 |  |  | 292,951 |  |  | 469,075 |  |
| Total revenue by geographic distribution |  | $ | 942,308 |  |  | $ | 1,067,886 |  |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |

- added (2025-03-12):
[0000936395-25-000011:note_history:93]
Ciena’s revenue includes $752.5 million and $677.6 million from the United States for the first quarter of fiscal 2025 and 2024, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- added (2025-03-12):
[0000936395-25-000011:note_history:94]
Ciena’s revenue includes $168.9 million and $109.1 million from a cloud provider for the first quarter of fiscal 2025 and 2024, respectively. Revenue also includes $111.0 million from AT&T for the first quarter of fiscal 2025 and $166.0 million from an additional cloud provider for the first quarter of fiscal 2024. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

- changed (2025-03-12):
[0000936395-25-000011:note_history:95]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):
  (was, 2024-09-04, similarity 0.9244):
[0000936395-24-000032:note_history:95]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

- changed (2025-03-12):
[0000936395-25-000011:note_history:96]
|  |  | Balance at February 1, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 938,703 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 138,718 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 257,277 |  |  | $ | 237,619 |  |
  (was, 2024-09-04, similarity 0.9598):
[0000936395-24-000032:note_history:96]
|  |  | Balance at July 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 899,877 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 142,769 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 257,085 |  |  | $ | 228,460 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:97]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets.
  (was, 2024-09-04, similarity 0.9802):
[0000936395-24-000032:note_history:97]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 10 below.

- changed (2025-03-12):
[0000936395-25-000011:note_history:98]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $74.5 million and $70.6 million of revenue during the first three months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance at November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended February 1, 2025 and January 27, 2024.
  (was, 2024-09-04, similarity 0.8422):
[0000936395-24-000032:note_history:98]
Deferred revenue represents contract liabilities and consists of advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $130.5 million and $119.8 million of revenue during the first nine months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance as of October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 27, 2024 and July 29, 2023.

- added (2025-03-12):
[0000936395-25-000011:note_history:99]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

- added (2025-03-12):
[0000936395-25-000011:note_history:100]
|  | February 1,2025 |  | November 2,2024 |
| Products | $ | 26,413 |  |  | $ | 19,017 |  |
| Services | 230,864 |  |  | 218,602 |  |
| Total deferred revenue | 257,277 |  |  | 237,619 |  |
| Less current portion | (174,151) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,126 |  |  | $ | 81,240 |  |

- changed (2025-03-12):
[0000936395-25-000011:note_history:101]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.4 million and $28.4 million as of February 1, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $8.5 million and $7.7 million during the first three months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2024-09-04, similarity 0.9367):
[0000936395-24-000032:note_history:101]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $25.5 million and $30.2 million as of July 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $22.9 million and $26.0 million during the first nine months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2025-03-12):
[0000936395-25-000011:note_history:102]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of February 1, 2025, the aggregate amount of RPO was $1.7 billion. As of February 1, 2025, Ciena expects approximately 79% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2024-09-04, similarity 0.9651):
[0000936395-24-000032:note_history:102]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 27, 2024, the aggregate amount of RPO was $1.6 billion. As of July 27, 2024, Ciena expects approximately 78% of the RPO balance to be recognized as revenue within the next 12 months.

- removed (2025-03-12):
[0000936395-24-000032:note_history:103]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue for similar groupings of Ciena’s products and services. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.

- removed (2025-03-12):
[0000936395-24-000032:note_history:104]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:105]
|  | Nine months ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:106]
Ciena’s revenue includes $676.0 million and $685.8 million of United States revenue for the third quarter of fiscal 2024 and 2023, respectively. For the nine months ended July 27, 2024 and July 29, 2023, United States revenue was $2.0 billion and $2.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- removed (2025-03-12):
[0000936395-24-000032:note_history:107]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- removed (2025-03-12):
[0000936395-24-000032:note_history:108]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cloud Provider | $ | 137,184 |  |  | $ | 124,897 |  |  | $ | 331,631 |  |  | $ | 369,678 |  |
| AT&T | 113,082 |  |  | n/a |  | 324,787 |  |  | 357,382 |  |
| Total | $ | 250,266 |  |  | $ | 124,897 |  |  | $ | 656,418 |  |  | $ | 727,060 |  |

- removed (2025-03-12):
[0000936395-24-000032:note_history:109]
_____________________________________

- removed (2025-03-12):
[0000936395-24-000032:note_history:110]
n/a    Denotes revenue representing less than 10% of total revenue for the period

- removed (2025-03-12):
[0000936395-24-000032:note_history:111]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented. The cloud provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented.

- removed (2025-03-12):
[0000936395-24-000032:note_history:112]
A description of each of Ciena’s operating segments is set forth below:

- removed (2025-03-12):
[0000936395-24-000032:note_history:113]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, virtualization software and Ciena’s WaveRouter® product. This product line also includes SD-Edge software and passive optical network (PON) routing and switching portfolio products.

- removed (2025-03-12):
[0000936395-24-000032:note_history:114]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- removed (2025-03-12):
[0000936395-24-000032:note_history:115]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, previously referred to as “Manage, Control and Plan (MCP),” its OneControl Unified Management System, and planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2025-03-12):
[0000936395-24-000032:note_history:116]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), multi-cloud orchestration (MCO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2025-03-12):
[0000936395-24-000032:note_history:117]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- removed (2025-03-12):
[0000936395-24-000032:note_history:118]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-03-12):
[0000936395-25-000011:note_history:119]
SUBSEQUENT EVENTS
Stock Repurchase Program

- added (2025-03-12):
[0000936395-25-000011:note_history:120]
From the end of the first quarter of fiscal 2025 through March 7, 2025, Ciena repurchased 382,834 shares of its common stock for an aggregate purchase price of $31.7 million at an average price of $82.75 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of March 7, 2025, Ciena has an aggregate of $889.1 million of authorized funds remaining under this repurchase program.
