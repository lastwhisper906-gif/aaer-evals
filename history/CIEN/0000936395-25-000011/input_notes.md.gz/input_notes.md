# CIEN notes — 0000936395-25-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-25-000011:notes:1]
INTERIM FINANCIAL STATEMENTS
The interim financial statements for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) included herein have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”).

[0000936395-25-000011:notes:2]
[same as prior period, unchanged from 0000936395-24-000032:notes:2]

[0000936395-25-000011:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-25-000011:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

[0000936395-25-000011:notes:5]
Accounting Standards - Not Yet Effective

[0000936395-25-000011:notes:6]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

[0000936395-25-000011:notes:7]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-25-000011:notes:8]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-25-000011:notes:9]
REVENUE
Segment and Product Line Disaggregation of Revenue

[0000936395-25-000011:notes:10]
Ciena’s disaggregated segment and product line revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 16 below.

[0000936395-25-000011:notes:11]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

[0000936395-25-000011:notes:12]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

[0000936395-25-000011:notes:13]
|  | Quarter Ended January 27, 2024 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

[0000936395-25-000011:notes:14]
[same as prior period, unchanged from 0000936395-24-000032:notes:28]

[0000936395-25-000011:notes:15]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products.

[0000936395-25-000011:notes:16]
•Routing and Switching - includes the 3000 and 5000 series of service delivery and aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and passive optical network and other routing and switching portfolio products.

[0000936395-25-000011:notes:17]
Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:18]
•Platform Software and Services revenue reflects sales of Ciena’s Platform Software and Platform Services.

[0000936395-25-000011:notes:19]
•Platform Software - includes Ciena’s Navigator Network Control SuiteTM domain controller solution and its applications, and legacy software solutions.

[0000936395-25-000011:notes:20]
•Platform Services - includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

[0000936395-25-000011:notes:21]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:22]
•Blue Planet Automation Software and Services revenue reflects sales of Blue Planet Automation Software and Blue Planet Services.

[0000936395-25-000011:notes:23]
•Blue Planet Automation Software - includes inventory management, orchestration, route optimization and analysis, and unified assurance and analytics software.

[0000936395-25-000011:notes:24]
•Blue Planet Services - includes sales of subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.

[0000936395-25-000011:notes:25]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:26]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities.

[0000936395-25-000011:notes:27]
Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:28]
Revenue Recognition

[0000936395-25-000011:notes:29]
•Revenue from the Networking Platforms segment includes, in addition to the products described above, sales of operating system software and enhanced software features embedded therein, which are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-25-000011:notes:30]
•Revenue from software platforms typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-25-000011:notes:31]
•Revenue from software subscription and support is recognized ratably over the period during which the services are performed.

[0000936395-25-000011:notes:32]
•Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Global Services are considered a distinct performance obligation where revenue is generally recognized over time.

[0000936395-25-000011:notes:33]
•Revenue from maintenance support is recognized ratably over the period during which the services are performed.

[0000936395-25-000011:notes:34]
•Revenue from installation and deployment services and consulting and network design services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-25-000011:notes:35]
•Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-25-000011:notes:36]
For additional information on Ciena’s revenue recognition policy, see the Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

[0000936395-25-000011:notes:37]
Geographic Disaggregation of Revenue

[0000936395-25-000011:notes:38]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-25-000011:notes:39]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-25-000011:notes:40]
|  |  | Quarter Ended |  |  |
|  |  | February 1, |  | January 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  |  |
| EMEA |  | 157,916 |  |  | 207,413 |  |  |  |  |  |
| APAC |  | 118,712 |  |  | 112,098 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  |  |

[0000936395-25-000011:notes:41]
Ciena’s revenue includes $752.5 million and $677.6 million from the United States for the first quarter of fiscal 2025 and 2024, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-25-000011:notes:42]
Ciena’s revenue includes $168.9 million and $109.1 million from a cloud provider for the first quarter of fiscal 2025 and 2024, respectively. Revenue also includes $111.0 million from AT&T for the first quarter of fiscal 2025 and $166.0 million from an additional cloud provider for the first quarter of fiscal 2024. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

[0000936395-25-000011:notes:43]
[same as prior period, unchanged from 0000936395-24-000032:notes:36]

[0000936395-25-000011:notes:44]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-25-000011:notes:45]
|  |  | Balance at February 1, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 938,703 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 138,718 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 257,277 |  |  | $ | 237,619 |  |

[0000936395-25-000011:notes:46]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets.

[0000936395-25-000011:notes:47]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $74.5 million and $70.6 million of revenue during the first three months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance at November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended February 1, 2025 and January 27, 2024.

[0000936395-25-000011:notes:48]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-25-000011:notes:49]
|  | February 1,2025 |  | November 2,2024 |
| Products | $ | 26,413 |  |  | $ | 19,017 |  |
| Services | 230,864 |  |  | 218,602 |  |
| Total deferred revenue | 257,277 |  |  | 237,619 |  |
| Less current portion | (174,151) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,126 |  |  | $ | 81,240 |  |

[0000936395-25-000011:notes:50]
[same as prior period, unchanged from 0000936395-24-000032:notes:41]

[0000936395-25-000011:notes:51]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.4 million and $28.4 million as of February 1, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $8.5 million and $7.7 million during the first three months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:52]
[same as prior period, unchanged from 0000936395-24-000032:notes:43]

[0000936395-25-000011:notes:53]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of February 1, 2025, the aggregate amount of RPO was $1.7 billion. As of February 1, 2025, Ciena expects approximately 79% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-25-000011:notes:54]
[same as prior period, unchanged from 0000936395-24-000032:notes:47]

[0000936395-25-000011:notes:55]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the three months ended February 1, 2025 (in thousands):

[0000936395-25-000011:notes:56]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Charges | 278 |  |  | 1,266 |  | (1) | 1,544 |  |
| Cash payments | (1,762) |  |  | (1,266) |  |  | (3,028) |  |
| Balance at February 1, 2025 | $ | 443 |  |  | $ | — |  |  | $ | 443 |  |
| Current restructuring liabilities | $ | 443 |  |  | $ | — |  |  | $ | 443 |  |

[0000936395-25-000011:notes:57]
(1) Primarily represents costs related to restructured real estate facilities.

[0000936395-25-000011:notes:58]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the three months ended January 27, 2024 (in thousands):

[0000936395-25-000011:notes:59]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 2,861 |  |  | 2,110 |  | (1) | 4,971 |  |
| Cash payments | (4,058) |  |  | (2,110) |  |  | (6,168) |  |
| Balance at January 27, 2024 | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Current restructuring liabilities | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |

[0000936395-25-000011:notes:60]
(1) Primarily represents costs related to restructured real estate facilities and the redesign of certain business processes associated with Ciena’s supply chain and distribution structure.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-25-000011:notes:61]
[same as prior period, unchanged from 0000936395-24-000032:notes:55]

[0000936395-25-000011:notes:62]
|  | Quarter Ended |  |  |
|  | February 1, |  | January 27, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Interest income | $ | 13,710 |  |  | $ | 15,177 |  |  |  |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts(1) | (2,873) |  |  | 3,112 |  |  |  |  |  |
| Foreign currency exchange gains (losses)(2) | 1,240 |  |  | (9,192) |  |  |  |  |  |
| Other | (499) |  |  | 1,553 |  |  |  |  |  |
| Interest and other income, net | $ | 11,578 |  |  | $ | 10,650 |  |  |  |  |  |

[0000936395-25-000011:notes:63]
(1) Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations.

[0000936395-25-000011:notes:64]
(2) Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-25-000011:notes:65]
INCOME TAXES
The effective tax rate for the first quarter of fiscal 2025 was higher than the effective tax rate for the first quarter of fiscal 2024. The increase was primarily due to income in jurisdictions with higher tax rates.

[0000936395-25-000011:notes:66]
For the three months ended February 1, 2025, the impact of the 15% global minimum tax, referred to as Pillar Two, was not material to the consolidated financial statements. Ciena is continuing to monitor and evaluate legislative developments related to Pillar Two and to the extent additional legislative changes take place in the countries in which Ciena operates, it is possible that these changes may yield an adverse impact on the effective tax rate.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-25-000011:notes:67]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-25-000011:notes:68]
|  | February 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 328,949 |  |  | $ | 591 |  |  | $ | (44) |  |  | $ | 329,496 |  |
| Corporate debt securities | 106,044 |  |  | 126 |  |  | (53) |  |  | 106,117 |  |
| Time deposits | 92,937 |  |  | 2 |  |  | (2) |  |  | 92,937 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |
| Included in cash equivalents | $ | 86,195 |  |  | $ | — |  |  | $ | — |  |  | $ | 86,195 |  |
| Included in short-term investments | 336,734 |  |  | 608 |  |  | (22) |  |  | 337,320 |  |
| Included in long-term investments | 105,001 |  |  | 111 |  |  | (77) |  |  | 105,035 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |

[0000936395-25-000011:notes:69]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

[0000936395-25-000011:notes:70]
The following table summarizes the final legal maturities of debt investments as of February 1, 2025 (in thousands):

[0000936395-25-000011:notes:71]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 422,929 |  |  | $ | 423,515 |  |
| Due in 1-2 years | 105,001 |  |  | 105,035 |  |
|  | $ | 527,930 |  |  | $ | 528,550 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-25-000011:notes:72]
[same as prior period, unchanged from 0000936395-24-000032:notes:64]

[0000936395-25-000011:notes:73]
|  | February 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 581,415 |  |  | $ | — |  |  | $ | — |  |  | $ | 581,415 |  |
| Bond mutual fund | 114,061 |  |  | — |  |  | — |  |  | 114,061 |  |
| Time deposits | 92,937 |  |  | — |  |  | — |  |  | 92,937 |  |
| Deferred compensation plan assets | 17,659 |  |  | — |  |  | — |  |  | 17,659 |  |
| U.S. government obligations | — |  |  | 329,496 |  |  | — |  |  | 329,496 |  |
| Corporate debt securities | — |  |  | 106,117 |  |  | — |  |  | 106,117 |  |
| Foreign currency forward contracts | — |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Interest rate swaps | — |  |  | 13,978 |  |  | — |  |  | 13,978 |  |
| Total assets measured at fair value | $ | 806,072 |  |  | $ | 451,671 |  |  | $ | — |  |  | $ | 1,257,743 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 14,325 |  |  | $ | — |  |  | $ | 14,325 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,325 |  |  | $ | — |  |  | $ | 14,325 |  |

[0000936395-25-000011:notes:74]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 636,097 |  |  | $ | — |  |  | $ | — |  |  | $ | 636,097 |  |
| Bond mutual fund | 112,703 |  |  | — |  |  | — |  |  | 112,703 |  |
| Time deposits | 92,804 |  |  | — |  |  | — |  |  | 92,804 |  |
| Deferred compensation plan assets | 16,519 |  |  | — |  |  | — |  |  | 16,519 |  |
| U.S. government obligations | — |  |  | 286,181 |  |  | — |  |  | 286,181 |  |
| Corporate debt securities | — |  |  | 111,143 |  |  | — |  |  | 111,143 |  |
| Foreign currency forward contracts | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Interest rate swaps | — |  |  | 11,777 |  |  | — |  |  | 11,777 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0000936395-25-000011:notes:75]
[same as prior period, unchanged from 0000936395-24-000032:notes:67]

[0000936395-25-000011:notes:76]
|  | February 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 781,671 |  |  | $ | — |  |  | $ | — |  |  | $ | 781,671 |  |
| Short-term investments | 6,742 |  |  | 330,578 |  |  | — |  |  | 337,320 |  |
| Prepaid expenses and other | — |  |  | 2,080 |  |  | — |  |  | 2,080 |  |
| Long-term investments | — |  |  | 105,035 |  |  | — |  |  | 105,035 |  |
| Other long-term assets | 17,659 |  |  | 13,978 |  |  | — |  |  | 31,637 |  |
| Total assets measured at fair value | $ | 806,072 |  |  | $ | 451,671 |  |  | $ | — |  |  | $ | 1,257,743 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 14,325 |  |  | $ | — |  |  | $ | 14,325 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,325 |  |  | $ | — |  |  | $ | 14,325 |  |

[0000936395-25-000011:notes:77]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 832,239 |  |  | $ | 9,426 |  |  | $ | — |  |  | $ | 841,665 |  |
| Short-term investments | 9,365 |  |  | 306,978 |  |  | — |  |  | 316,343 |  |
| Prepaid expenses and other | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Long-term investments | — |  |  | 80,920 |  |  | — |  |  | 80,920 |  |
| Other long-term assets | 16,519 |  |  | 11,777 |  |  | — |  |  | 28,296 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0000936395-25-000011:notes:78]
[same as prior period, unchanged from 0000936395-24-000032:notes:70]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-25-000011:notes:79]
[same as prior period, unchanged from 0000936395-24-000032:notes:71]

[0000936395-25-000011:notes:80]
|  | February 1,2025 |  | November 2,2024 |
| Raw materials | $ | 601,893 |  |  | $ | 542,785 |  |
| Work-in-process | 32,688 |  |  | 32,219 |  |
| Finished goods | 289,162 |  |  | 324,697 |  |
| Deferred cost of goods sold | 30,116 |  |  | 27,902 |  |
| Gross inventories | 953,859 |  |  | 927,603 |  |
| Reserve for inventory excess and obsolescence | (108,727) |  |  | (107,173) |  |
| Inventories, net | $ | 845,132 |  |  | $ | 820,430 |  |

[0000936395-25-000011:notes:81]
During the first three months of fiscal 2025, Ciena recorded a provision for inventory excess and obsolescence of $10.9 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the reserve for excess and obsolete inventory relate primarily to sales and disposal activities.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-25-000011:notes:82]
[same as prior period, unchanged from 0000936395-24-000032:notes:88]

[0000936395-25-000011:notes:83]
Ciena conducts business globally in many currencies, and thus is exposed to foreign currency exchange rate changes. To limit this exposure, Ciena entered into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-25-000011:notes:84]
As of February 1, 2025 and November 2, 2024, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $356.9 million and $257.0 million as of February 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-25-000011:notes:85]
As of February 1, 2025 and November 2, 2024, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $63.5 million and $65.4 million as of February 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0000936395-25-000011:notes:86]
As of February 1, 2025 and November 2, 2024, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $117.5 million and $201.2 million as of February 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-25-000011:notes:87]
[same as prior period, unchanged from 0000936395-24-000032:notes:93]

[0000936395-25-000011:notes:88]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 11 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0000936395-25-000011:notes:89]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest rate swaps was $350.0 million as of February 1, 2025 and November 2, 2024.

[0000936395-25-000011:notes:90]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of these interest rate swaps was $350.0 million as of February 1, 2025 and November 2, 2024.

[0000936395-25-000011:notes:91]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of February 1, 2025 and November 2, 2024.

[0000936395-25-000011:notes:92]
Ciena expects the variable rate payments to be received under the terms of these interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the Refinanced 2030 Term Loan (as defined in Note 11 below). These derivative contracts have been designated as cash flow hedges.

[0000936395-25-000011:notes:93]
[same as prior period, unchanged from 0000936395-24-000032:notes:99]


## us-gaap:DebtDisclosureTextBlock

[0000936395-25-000011:notes:94]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-25-000011:notes:95]
Refinanced 2030 Term Loan

[0000936395-25-000011:notes:96]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena

[0000936395-25-000011:notes:97]
maintained a senior secured term loan with an outstanding aggregate principal amount as of January 17, 2025 of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

[0000936395-25-000011:notes:98]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

[0000936395-25-000011:notes:99]
•mature on October 24, 2030;

[0000936395-25-000011:notes:100]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date, with the balance payable at maturity;

[0000936395-25-000011:notes:101]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-25-000011:notes:102]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

[0000936395-25-000011:notes:103]
•be repayable at any time at Ciena’s election, provided that repayment of the Refinanced 2030 Term Loan with proceeds of certain indebtedness prior to July 17, 2025 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and

[0000936395-25-000011:notes:104]
•except as described above or otherwise set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

[0000936395-25-000011:notes:105]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-25-000011:notes:106]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):

[0000936395-25-000011:notes:107]
|  |  | February 1, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,155,405 |  |  | $ | (4,103) |  |  | $ | (5,238) |  |  | $ | 1,146,064 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

[0000936395-25-000011:notes:108]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during the first three months of fiscal 2025 and fiscal 2024.

[0000936395-25-000011:notes:109]
As of February 1, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.16 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-25-000011:notes:110]
Outstanding Senior Notes Payable

[0000936395-25-000011:notes:111]
2030 Notes

[0000936395-25-000011:notes:112]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-25-000011:notes:113]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-25-000011:notes:114]
|  |  | February 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,400) |  |  | $ | 396,600 |  |  | $ | 396,427 |  |  |  |

[0000936395-25-000011:notes:115]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first three months of fiscal 2025 and fiscal 2024.

[0000936395-25-000011:notes:116]
As of February 1, 2025, the estimated fair value of the 2030 Notes was $368.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-25-000011:notes:117]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended February 1, 2025 (in thousands):

[0000936395-25-000011:notes:118]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 2, 2024 | $ | 798 |  |  | $ | (4,880) |  |  |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications | (345) |  |  | (6,841) |  |  |  |  | 4,377 |  |  | (17,702) |  |  | (20,511) |  |
| Amounts reclassified from AOCI | — |  |  | 2,357 |  |  |  |  | (2,424) |  |  | — |  |  | (67) |  |
| Balance at February 1, 2025 | $ | 453 |  |  | $ | (9,364) |  |  |  |  | $ | 10,621 |  |  | $ | (68,999) |  |  | $ | (67,289) |  |

[0000936395-25-000011:notes:119]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 27, 2024 (in thousands):

[0000936395-25-000011:notes:120]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain before reclassifications | 895 |  |  | 6,448 |  |  | (5,592) |  |  | 14,323 |  |  | 16,074 |  |
| Amounts reclassified from AOCI | — |  |  | 708 |  |  | (3,882) |  |  | — |  |  | (3,174) |  |
| Balance at January 27, 2024 | $ | 523 |  |  | $ | (1,000) |  |  | $ | 9,488 |  |  | $ | (33,878) |  |  | $ | (24,867) |  |

[0000936395-25-000011:notes:121]
[same as prior period, unchanged from 0000936395-24-000032:notes:124]


## us-gaap:EarningsPerShareTextBlock

[0000936395-25-000011:notes:122]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan, using the treasury stock method.

[0000936395-25-000011:notes:123]
The following table presents the calculation of Basic EPS and Diluted EPS for the periods indicated (in thousands, except per share amounts):

[0000936395-25-000011:notes:124]
|  | Quarter Ended |  |  |
|  | February 1, |  | January 27, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Net income | $ | 44,572 |  |  | $ | 49,547 |  |  |  |  |  |
| Basic weighted average shares outstanding | 142,880 |  |  | 145,291 |  |  |  |  |  |
| Effect of dilutive potential common shares | 3,064 |  |  | 557 |  |  |  |  |  |
| Diluted weighted average shares | 145,944 |  |  | 145,848 |  |  |  |  |  |
| Basic EPS | $ | 0.31 |  |  | $ | 0.34 |  |  |  |  |  |
| Diluted EPS | $ | 0.31 |  |  | $ | 0.34 |  |  |  |  |  |
| Antidilutive employee share-based awards, excluded | 989 |  |  | 2,491 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-25-000011:notes:125]
[same as prior period, unchanged from 0000936395-24-000032:notes:128]

[0000936395-25-000011:notes:126]
On October 2, 2024, Ciena announced that its Board of Directors authorized a three-year program to repurchase up to $1.0 billion of its common stock, commencing in fiscal 2025 and continuing through the end of fiscal 2027.

[0000936395-25-000011:notes:127]
Under this program, during the first three months of fiscal 2025, Ciena repurchased approximately 1.0 million shares of its common stock for an aggregate purchase price of approximately $79.2 million, which equates to an average price of $77.88 per share. As of February 1, 2025, Ciena has an aggregate of $920.8 million authorized and remaining under its stock repurchase program. Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0000936395-25-000011:notes:128]
[same as prior period, unchanged from 0000936395-24-000032:notes:131]

[0000936395-25-000011:notes:129]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $25.5 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2025 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-25-000011:notes:130]
SHARE-BASED COMPENSATION EXPENSE
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-25-000011:notes:131]
|  | Quarter Ended |  |  |
|  | February 1, |  | January 27, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Products | $ | 1,750 |  |  | $ | 1,318 |  |  |  |  |  |
| Services | 3,405 |  |  | 3,020 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 5,155 |  |  | 4,338 |  |  |  |  |  |
| Research and development | 14,237 |  |  | 12,880 |  |  |  |  |  |
| Selling and marketing | 11,597 |  |  | 10,305 |  |  |  |  |  |
| General and administrative | 9,827 |  |  | 10,079 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 35,661 |  |  | 33,264 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net | (10) |  |  | 225 |  |  |  |  |  |
| Total share-based compensation expense | $ | 40,806 |  |  | $ | 37,827 |  |  |  |  |  |

[0000936395-25-000011:notes:132]
As of February 1, 2025, total unrecognized share-based compensation expense was approximately $347.0 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.53 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-25-000011:notes:133]
[same as prior period, unchanged from 0000936395-24-000032:notes:137]

[0000936395-25-000011:notes:134]
[same as prior period, unchanged from 0000936395-24-000032:notes:138]

[0000936395-25-000011:notes:135]
[same as prior period, unchanged from 0000936395-24-000032:notes:141]

[0000936395-25-000011:notes:136]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; interest and other income, net; interest expense; loss on extinguishment and modification of debt; and provision for income taxes.

[0000936395-25-000011:notes:137]
[same as prior period, unchanged from 0000936395-24-000032:notes:143]

[0000936395-25-000011:notes:138]
|  | Quarter Ended |  |  |
|  | February 1, |  | January 27, |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 167,079 |  |  | $ | 183,775 |  |  |  |  |  |
| Platform Software and Services | 63,125 |  |  | 58,004 |  |  |  |  |  |
| Blue Planet Automation Software and Services | 4,576 |  |  | (7,069) |  |  |  |  |  |
| Global Services | 44,378 |  |  | 44,983 |  |  |  |  |  |
| Total segment profit | 279,158 |  |  | 279,693 |  |  |  |  |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 136,504 |  |  | 128,158 |  |  |  |  |  |
| General and administrative | 53,902 |  |  | 54,683 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,544 |  |  | 4,971 |  |  |  |  |  |
| Amortization of intangible assets | 6,545 |  |  | 7,252 |  |  |  |  |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 11,578 |  |  | 10,650 |  |  |  |  |  |
| Interest expense | (22,918) |  |  | (23,776) |  |  |  |  |  |
| Loss on extinguishment and modification of debt | (729) |  |  | — |  |  |  |  |  |
| Less: Provision for income taxes | 24,022 |  |  | 21,956 |  |  |  |  |  |
| Net income | $ | 44,572 |  |  | $ | 49,547 |  |  |  |  |  |

[0000936395-25-000011:notes:139]
[same as prior period, unchanged from 0000936395-24-000032:notes:145]

[0000936395-25-000011:notes:140]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of February 1, 2025, equipment, building, furniture and fixtures, net, totaled $320.4 million, and operating ROU assets totaled $25.1 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of February 1, 2025, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-25-000011:notes:141]
|  | February 1, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 151,788 |  |  | — |  |  | 4,417 |  |  | — |  |  | $ | 156,205 |  |
| Goodwill | $ | 199,066 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 444,306 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 82,846 |  |  | $ | 82,846 |  |

[0000936395-25-000011:notes:142]
The following table represents Ciena’s geographic distribution of equipment, building, furniture and fixtures, net and operating ROU assets, specifically identifying any country that accounts for at least 10% of the total of these assets. Assets attributable to geographic regions not identified are reflected as “Other International”. For the periods indicated, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-25-000011:notes:143]
|  | February 1,2025 |  | November 2,2024 |
| Canada | $ | 269,647 |  |  | $ | 283,760 |  |
| United States | 46,024 |  |  | 49,195 |  |
| Other International | 29,824 |  |  | 32,184 |  |
| Total | $ | 345,495 |  |  | $ | 365,139 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-25-000011:notes:144]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-25-000011:notes:145]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-25-000011:notes:146]
Litigation

[0000936395-25-000011:notes:147]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-25-000011:notes:148]
Purchase Obligations

[0000936395-25-000011:notes:149]
Ciena has certain advanced commitments for supply of certain long lead time components. As of February 1, 2025, Ciena had $1.7 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-25-000011:notes:150]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-25-000011:notes:151]
From the end of the first quarter of fiscal 2025 through March 7, 2025, Ciena repurchased 382,834 shares of its common stock for an aggregate purchase price of $31.7 million at an average price of $82.75 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of March 7, 2025, Ciena has an aggregate of $889.1 million of authorized funds remaining under this repurchase program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000936395-25-000011:notes:152]
The following table describes, for the first quarter of fiscal 2025, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0000936395-25-000011:notes:153]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Joseph Cumello (Senior Vice President and General Manager of Blue Planet) | Adoption (January 14, 2025) | Rule 10b5-1 trading arrangement | Sales | Until December 31, 2026, or such earlier date upon which all transactions are completed or expire without execution | (1) |
| David M. Rothenstein (Senior Vice President, Chief Strategy Officer and Secretary) | Adoption (December 23, 2024) | Rule 10b5-1 trading arrangement | Sales | Until December 23, 2025, or such earlier date upon which all transactions are completed or expire without execution | Up to 25,000 shares of common stock |

[0000936395-25-000011:notes:154]
(1)    The aggregate number of shares of common stock to be sold pursuant to Mr. Cumello’s arrangement is up to 100% of the net after-tax shares of common stock to be received as a result of the vesting of an aggregate of 23,496 restricted stock units on June 20, 2025, September 20, 2025, December 20, 2025, March 20, 2026, June 20, 2026, September 20, 2026, and

[0000936395-25-000011:notes:155]
December 20, 2026. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.
