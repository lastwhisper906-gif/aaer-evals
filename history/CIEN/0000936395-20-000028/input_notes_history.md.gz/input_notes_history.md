# CIEN note change history — 0000936395-20-000011 → 0000936395-20-000028


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $40.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 2, 2020, Ciena has recorded CAD$34.5 million (approximately $24.5 million) in cumulative benefits as a reduction in research and development expense of which CAD$5.6 million ($4.2 million) was recorded in the first six months of fiscal 2020. As of May 2, 2020, amounts receivable from this grant were CAD$7.3 million ($5.2 million).
  (was, 2020-03-11, similarity 0.9141):
[0000936395-20-000011:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.5 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2020, Ciena has recorded CAD$32.5 million (approximately $24.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million (approximately $2.7 million) was recorded in the first three months of fiscal 2020. As of January 31, 2020, amounts receivable from this grant were CAD$12.0 million (approximately $9.1 million).


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2020-06-10):
[0000936395-20-000028:note_history:2]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”).

- added (2020-06-10):
[0000936395-20-000028:note_history:3]
The preparation of financial statements and related disclosures in conformity with GAAP requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions and estimates reflected the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. The actual results that Ciena experiences may differ materially from such inputs into Ciena’s critical and significant accounting estimates. As the duration and severity of the COVID-19 pandemic are unclear, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility as compared to prior periods. As events continue to evolve, Ciena’s estimates may change materially in future periods.

- changed (2020-06-10):
[0000936395-20-000028:note_history:4]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2019 (the “2019 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years and quarterly periods ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its quarters ended on January 31, April 30, July 31 and October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. References to prior reported periods have been changed to reflect the actual period end dates of May 2, 2020, May 4, 2019, November 2, 2019 and November 3, 2018 for periods reported herein.
  (was, 2020-03-11, similarity 0.683):
[0000936395-20-000011:note_history:4]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2019.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:5]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.
  (was, 2020-03-11, similarity 0.7935):
[0000936395-20-000011:note_history:5]
similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

- changed (2020-06-10):
[0000936395-20-000028:note_history:6]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of November 2, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.
  (was, 2020-03-11, similarity 0.9948):
[0000936395-20-000011:note_history:6]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of October 31, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.

- changed (2020-06-10):
[0000936395-20-000028:note_history:7]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in thousands):
  (was, 2020-03-11, similarity 0.9688):
[0000936395-20-000011:note_history:7]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in millions):

- changed (2020-06-10):
[0000936395-20-000028:note_history:8]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
  (was, 2020-03-11, similarity 0.9931):
[0000936395-20-000011:note_history:8]
|  |  | Balance at October 31, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 1, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:9]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets.
  (was, 2020-03-11, similarity 0.9916):
[0000936395-20-000011:note_history:9]
| (1) | Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets. |

- changed (2020-06-10):
[0000936395-20-000028:note_history:10]
(2) Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets.
  (was, 2020-03-11, similarity 0.976):
[0000936395-20-000011:note_history:10]
| (2) | Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets. |

- changed (2020-06-10):
[0000936395-20-000028:note_history:11]
(3) Represents $20.5 million of lease liabilities for operating leases.
  (was, 2020-03-11, similarity 0.9577):
[0000936395-20-000011:note_history:11]
| (3) | Represents $20.5 million of lease liabilities for operating leases. |

- changed (2020-06-10):
[0000936395-20-000028:note_history:12]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets.
  (was, 2020-03-11, similarity 0.9851):
[0000936395-20-000011:note_history:12]
| (4) | Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets. |

- changed (2020-06-10):
[0000936395-20-000028:note_history:13]
(5) Represents $55.6 million of lease liabilities for operating leases.
  (was, 2020-03-11, similarity 0.9577):
[0000936395-20-000011:note_history:13]
| (5) | Represents $55.6 million of lease liabilities for operating leases. |

- removed (2020-06-10):
[0000936395-20-000011:note_history:14]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-10):
[0000936395-20-000028:note_history:15]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”) and incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”).

- added (2020-06-10):
[0000936395-20-000028:note_history:16]
|  |  | May 2, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 691,268 |  |  | $ | (1,742 | ) |  | $ | (3,240 | ) |  | $ | 686,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:17]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.2 million at May 2, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.3 million during the first six months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.
  (was, 2020-03-11, similarity 0.9794):
[0000936395-20-000011:note_history:17]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.4 million at January 31, 2020 and $3.6 million at October 31, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.2 million during the first three months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.

- changed (2020-06-10):
[0000936395-20-000028:note_history:18]
As of May 2, 2020, the estimated fair value of the New 2025 Term Loan was $677.4 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2020-03-11, similarity 0.9875):
[0000936395-20-000011:note_history:18]
As of January 31, 2020, the estimated fair value of the New 2025 Term Loan was $694.7 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2020-06-10):
[0000936395-20-000011:note_history:19]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained an existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”).

- removed (2020-06-10):
[0000936395-20-000011:note_history:20]
On January 23, 2020, Ciena, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Refinancing Agreement”), pursuant to which Ciena consummated a permitted refinancing of the entire outstanding amount of the Old 2025 Term Loan, and in accordance therewith, incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”). The proceeds of the New 2025 Term Loan were used in their entirety to

- removed (2020-06-10):
[0000936395-20-000011:note_history:21]
refinance the 2025 Term Loan. This arrangement was primarily accounted for as a modification of debt and, as such, $0.1 million of debt issuance costs associated with the New 2025 Term Loan was expensed.

- removed (2020-06-10):
[0000936395-20-000011:note_history:22]
The Refinancing Agreement amends the Credit Agreement and provides that the New 2025 Term Loan will, among other things:

- removed (2020-06-10):
[0000936395-20-000011:note_history:23]
| • | mature on September 28, 2025; |

- removed (2020-06-10):
[0000936395-20-000011:note_history:24]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25%, or $1.73 million, of the principal amount of the New 2025 Term Loan as of January 23, 2020, with the balance payable at maturity; |

- removed (2020-06-10):
[0000936395-20-000011:note_history:25]
| • | be subject to mandatory prepayment provisions on the occurrence of certain specified events substantially similar to the 2025 Term Loan, including certain asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement); |

- removed (2020-06-10):
[0000936395-20-000011:note_history:26]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%; and |

- removed (2020-06-10):
[0000936395-20-000011:note_history:27]
| • | be repayable at any time at Ciena’s election, provided that repayment of the New 2025 Term Loan with proceeds of certain indebtedness prior to July 23, 2020 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment. |

- removed (2020-06-10):
[0000936395-20-000011:note_history:28]
Except as amended by the Refinancing Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

- removed (2020-06-10):
[0000936395-20-000011:note_history:29]
|  |  | January 31, 2020 |  | October 31, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 (New) |  | $ | 693,000 |  |  | $ | (1,824 | ) |  | $ | (3,390 | ) |  | $ | 687,786 |  |  | $ | — |  |
| Term Loan Payable due September 28, 2025 (Old) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:30]
|  | May 2, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
  (was, 2020-03-11, similarity 0.7732):
[0000936395-20-000011:note_history:30]
|  | January 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,962 |  |  | $ | 105 |  |  | $ | — |  |  | $ | 110,067 |  |
| Included in long-term investments | 10,073 |  |  | 3 |  |  | — |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 120,143 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:31]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

- removed (2020-06-10):
[0000936395-20-000011:note_history:32]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:33]
|  | May 2, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
  (was, 2020-03-11, similarity 0.7732):
[0000936395-20-000011:note_history:33]
|  | January 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,962 |  |  | $ | 105 |  |  | $ | — |  |  | $ | 110,067 |  |
| Included in long-term investments | 10,073 |  |  | 3 |  |  | — |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 120,143 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:34]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:35]
The following table summarizes the final legal maturities of debt investments at May 2, 2020 (in thousands):
  (was, 2020-03-11, similarity 0.9717):
[0000936395-20-000011:note_history:35]
The following table summarizes the final legal maturities of debt investments at January 31, 2020 (in thousands):

- changed (2020-06-10):
[0000936395-20-000028:note_history:36]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 100,116 |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 100,742 |  |
  (was, 2020-03-11, similarity 0.8669):
[0000936395-20-000011:note_history:36]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 109,962 |  |  | $ | 110,067 |  |
| Due in 1-2 years | 10,073 |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 120,143 |  |

- removed (2020-06-10):
[0000936395-20-000011:note_history:37]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-06-10):
[0000936395-20-000028:note_history:38]
|  |  | May 2, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 691,268 |  |  | $ | (1,742 | ) |  | $ | (3,240 | ) |  | $ | 686,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- removed (2020-06-10):
[0000936395-20-000011:note_history:39]
|  |  | January 31, 2020 |  | October 31, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 (New) |  | $ | 693,000 |  |  | $ | (1,824 | ) |  | $ | (3,390 | ) |  | $ | 687,786 |  |  | $ | — |  |
| Term Loan Payable due September 28, 2025 (Old) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:40]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Packet Networking | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
  (was, 2020-03-11, similarity 0.9966):
[0000936395-20-000011:note_history:40]
|  | Quarter Ended January 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Packet Networking | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:41]
|  | Quarter Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 11,101 |  |  | $ | 3,047 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 24,128 |  |  | 9,426 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
  (was, 2020-03-11, similarity 0.9966):
[0000936395-20-000011:note_history:41]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 16,044 |  |  | $ | 6,228 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 25,554 |  |  | 8,746 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:42]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Packet Networking | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,518 |  |  | $ | 30,092 |  |  | $ | 8,482 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,518 |  |  | $ | 96,873 |  |  | $ | 30,483 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:43]
|  | Six Months Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 27,145 |  |  | $ | 9,275 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 49,682 |  |  | 18,172 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:44]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.
  (was, 2020-03-11, similarity 0.9226):
[0000936395-20-000011:note_history:44]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, we maintain specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel, who ensure that we maintain a high-touch, consultative relationship with our customers.

- changed (2020-06-10):
[0000936395-20-000028:note_history:45]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 650,381 |  |  | $ | 615,492 |  |  | $ | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |
  (was, 2020-03-11, similarity 0.7417):
[0000936395-20-000011:note_history:45]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 832,912 |  |  | $ | 778,527 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-06-10):
[0000936395-20-000028:note_history:46]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Packet Networking | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
  (was, 2020-03-11, similarity 0.9966):
[0000936395-20-000011:note_history:46]
|  | Quarter Ended January 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Packet Networking | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:47]
|  | Quarter Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 11,101 |  |  | $ | 3,047 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 24,128 |  |  | 9,426 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
  (was, 2020-03-11, similarity 0.9966):
[0000936395-20-000011:note_history:47]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 16,044 |  |  | $ | 6,228 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 25,554 |  |  | 8,746 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:48]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Packet Networking | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,518 |  |  | $ | 30,092 |  |  | $ | 8,482 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,518 |  |  | $ | 96,873 |  |  | $ | 30,483 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:49]
|  | Six Months Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 27,145 |  |  | $ | 9,275 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 49,682 |  |  | 18,172 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:50]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.
  (was, 2020-03-11, similarity 0.9226):
[0000936395-20-000011:note_history:50]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, we maintain specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel, who ensure that we maintain a high-touch, consultative relationship with our customers.

- changed (2020-06-10):
[0000936395-20-000028:note_history:51]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 650,381 |  |  | $ | 615,492 |  |  | $ | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |
  (was, 2020-03-11, similarity 0.7417):
[0000936395-20-000011:note_history:51]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 832,912 |  |  | $ | 778,527 |  |

- added (2020-06-10):
[0000936395-20-000028:note_history:52]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service. |

- changed (2020-06-10):
[0000936395-20-000028:note_history:53]
|  |  | Balance at May 2, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 693,963 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 87,746 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 149,917 |  |  | $ | 156,873 |  |
  (was, 2020-03-11, similarity 0.8925):
[0000936395-20-000011:note_history:53]
|  |  | Balance at January 31, 2020 |  | Balance at October 31, 2019 |
| Accounts receivable, net |  | $ | 655,105 |  |  | $ | 724,854 |  |
| Contract assets |  | $ | 83,717 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 166,835 |  |  | $ | 156,873 |  |

- changed (2020-06-10):
[0000936395-20-000028:note_history:54]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets.
  (was, 2020-03-11, similarity 0.9662):
[0000936395-20-000011:note_history:54]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 for further discussion.

- changed (2020-06-10):
[0000936395-20-000028:note_history:55]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $76.5 million and $73.0 million of revenue during the first six months of fiscal 2020 and 2019 that was included in the deferred revenue balance at November 2, 2019 and November 3, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 2, 2020 and May 4, 2019.
  (was, 2020-03-11, similarity 0.9394):
[0000936395-20-000011:note_history:55]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $49.0 million and $39.4 million of revenue during the first three months of fiscal 2020 and 2019 that was included in the deferred revenue balance at October 31, 2019 and November 1, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 31, 2020 and 2019.

- changed (2020-06-10):
[0000936395-20-000028:note_history:56]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.3 million and $15.7 million as of May 2, 2020 and November 2, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $10.1 million and $8.4 million during the first six months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.
  (was, 2020-03-11, similarity 0.9696):
[0000936395-20-000011:note_history:56]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.1 million and $15.7 million as of January 31, 2020 and October 31, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $5.6 million and $4.1 million during the first three months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.

- changed (2020-06-10):
[0000936395-20-000028:note_history:57]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 2, 2020, the aggregate amount of RPO was $1.078 billion. As of May 2, 2020, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2020-03-11, similarity 0.6809):
[0000936395-20-000011:note_history:57]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2020, the aggregate amount of RPO was $905 million. As of January 31, 2020, Ciena expects approximately 82% of the RPO to be recognized as revenue within the next twelve months.

- removed (2020-06-10):
[0000936395-20-000011:note_history:58]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

- removed (2020-06-10):
[0000936395-20-000011:note_history:59]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2020-06-10):
[0000936395-20-000011:note_history:60]
SUBSEQUENT EVENTS

- removed (2020-06-10):
[0000936395-20-000011:note_history:61]
Stock Repurchase Program

- removed (2020-06-10):
[0000936395-20-000011:note_history:62]
From the end of the first quarter of fiscal 2020 through March 6, 2020, Ciena repurchased an additional 443,958 shares of its common stock, for an aggregate purchase price of $18.6 million at an average price of $41.90 per share, inclusive of repurchases pending settlement. As of March 6, 2020, Ciena has repurchased an aggregate of 5,570,535 shares and has an aggregate of $280.6 million of authorized funds remaining under its stock repurchase program.
