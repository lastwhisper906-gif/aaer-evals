# CIEN MD&A — 0000936395-20-000028


## mdna

[0000936395-20-000028:mdna:1]
[same as prior period, unchanged from 0000936395-20-000011:mdna:1]

[0000936395-20-000028:mdna:2]
[same as prior period, unchanged from 0000936395-20-000011:mdna:2]

[0000936395-20-000028:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things: our competitive landscape; market conditions and growth opportunities;

[0000936395-20-000028:mdna:4]
factors impacting our industry and markets; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and automation of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including information technology (IT) transitions or initiatives; the impact of the Tax Cuts and Jobs Act and changes in our effective tax rates; market risks associated with financial instruments and foreign currency exchange rates; and future responses to and effects of the COVID-19 pandemic on our business, operations, liquidity and financial results. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-20-000028:mdna:5]
[same as prior period, unchanged from 0000936395-20-000011:mdna:4]

[0000936395-20-000028:mdna:6]
[same as prior period, unchanged from 0000936395-20-000011:mdna:5]

[0000936395-20-000028:mdna:7]
| • | the loss of our customers, including the loss of a single large customer, a significant reduction in one or more customers’ spending, or a material change in their networking or procurement strategies; |

[0000936395-20-000028:mdna:8]
| • | the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; |

[0000936395-20-000028:mdna:9]
[same as prior period, unchanged from 0000936395-20-000011:mdna:7]

[0000936395-20-000028:mdna:10]
[same as prior period, unchanged from 0000936395-20-000011:mdna:8]

[0000936395-20-000028:mdna:11]
[same as prior period, unchanged from 0000936395-20-000011:mdna:9]

[0000936395-20-000028:mdna:12]
[same as prior period, unchanged from 0000936395-20-000011:mdna:10]

[0000936395-20-000028:mdna:13]
[same as prior period, unchanged from 0000936395-20-000011:mdna:11]

[0000936395-20-000028:mdna:14]
[same as prior period, unchanged from 0000936395-20-000011:mdna:12]

[0000936395-20-000028:mdna:15]
[same as prior period, unchanged from 0000936395-20-000011:mdna:13]

[0000936395-20-000028:mdna:16]
[same as prior period, unchanged from 0000936395-20-000011:mdna:14]

[0000936395-20-000028:mdna:17]
[same as prior period, unchanged from 0000936395-20-000011:mdna:15]

[0000936395-20-000028:mdna:18]
[same as prior period, unchanged from 0000936395-20-000011:mdna:16]

[0000936395-20-000028:mdna:19]
[same as prior period, unchanged from 0000936395-20-000011:mdna:17]

[0000936395-20-000028:mdna:20]
[same as prior period, unchanged from 0000936395-20-000011:mdna:18]

[0000936395-20-000028:mdna:21]
[same as prior period, unchanged from 0000936395-20-000011:mdna:19]

[0000936395-20-000028:mdna:22]
[same as prior period, unchanged from 0000936395-20-000011:mdna:20]

[0000936395-20-000028:mdna:23]
[same as prior period, unchanged from 0000936395-20-000011:mdna:21]

[0000936395-20-000028:mdna:24]
[same as prior period, unchanged from 0000936395-20-000011:mdna:22]

[0000936395-20-000028:mdna:25]
[same as prior period, unchanged from 0000936395-20-000011:mdna:23]

[0000936395-20-000028:mdna:26]
[same as prior period, unchanged from 0000936395-20-000011:mdna:24]

[0000936395-20-000028:mdna:27]
[same as prior period, unchanged from 0000936395-20-000011:mdna:25]

[0000936395-20-000028:mdna:28]
[same as prior period, unchanged from 0000936395-20-000011:mdna:26]

[0000936395-20-000028:mdna:29]
[same as prior period, unchanged from 0000936395-20-000011:mdna:27]

[0000936395-20-000028:mdna:30]
[same as prior period, unchanged from 0000936395-20-000011:mdna:28]

[0000936395-20-000028:mdna:31]
[same as prior period, unchanged from 0000936395-20-000011:mdna:29]

[0000936395-20-000028:mdna:32]
[same as prior period, unchanged from 0000936395-20-000011:mdna:30]

[0000936395-20-000028:mdna:33]
[same as prior period, unchanged from 0000936395-20-000011:mdna:31]

[0000936395-20-000028:mdna:34]
[same as prior period, unchanged from 0000936395-20-000011:mdna:32]

[0000936395-20-000028:mdna:35]
29

[0000936395-20-000028:mdna:36]
[same as prior period, unchanged from 0000936395-20-000011:mdna:33]

[0000936395-20-000028:mdna:37]
[same as prior period, unchanged from 0000936395-20-000011:mdna:34]

[0000936395-20-000028:mdna:38]
| • | future legislation or executive action in the U.S. or foreign counties relating to trade regulations, including the imposition of tariffs and duties or efforts to withdraw from or materially modify international trade agreements; |

[0000936395-20-000028:mdna:39]
| • | factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies, including the COVID-19 pandemic; |

[0000936395-20-000028:mdna:40]
[same as prior period, unchanged from 0000936395-20-000011:mdna:37]

[0000936395-20-000028:mdna:41]
[same as prior period, unchanged from 0000936395-20-000011:mdna:38]

[0000936395-20-000028:mdna:42]
| • | adverse results in litigation matters. |

[0000936395-20-000028:mdna:43]
[same as prior period, unchanged from 0000936395-20-000011:mdna:40]

[0000936395-20-000028:mdna:44]
[same as prior period, unchanged from 0000936395-20-000011:mdna:41]

[0000936395-20-000028:mdna:45]
Our solutions include our portfolio of Networking Platforms, including our Converged Packet Optical and Packet Networking products, that can be applied from the network core to end user access points, and that allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We offer Platform Software that provides management and domain control of our hardware solutions and automates network lifecycle operations, including provisioning equipment and services. Through our Blue Planet® Automation Software, we enable network providers to use network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments, streamlining key business and network processes. To complement our hardware and software products, we offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments.

[0000936395-20-000028:mdna:46]
[same as prior period, unchanged from 0000936395-20-000011:mdna:45]

[0000936395-20-000028:mdna:47]
Impact of the COVID-19 Pandemic

[0000936395-20-000028:mdna:48]
COVID-19 was declared a pandemic in March 2020 and continues to have a significant impact on the global economy, the industries we serve and our operations. In response to the COVID-19 pandemic, we have prioritized the safety of our employees and business partners, while continuing to support the needs of our customers and communities during this unprecedented period.

[0000936395-20-000028:mdna:49]
Employees.  We have implemented travel bans and restrictions, temporarily closed offices and, as of June 10, 2020 approximately 96% of our employees globally were working from home on a regular basis. Given our long-standing practice of flexible working arrangements, our distributed workforce is accustomed to the digital platforms and virtual collaboration tools we use to maintain productivity and to remain in contact with one another and our business partners. For the small number of employees who need to be in offices, laboratory environments or at business partner sites to perform their roles, we are taking appropriate precautions to protect their health and safety. We have adopted new employee benefits and wellbeing initiatives to support our employees, including initiatives for those who are now working remotely. We also continue to hire and on-board new employees in a remote environment, including 229 new hires, which resulted in net headcount growth of approximately 96 employees, during the second quarter of fiscal 2020. We are proud of the way in which our employees have continued to productively execute on our innovation roadmap and operating goals, including achieving the commercial availability of our fifth-generation WaveLogic coherent modem technology. However, sustained restrictions on the ability of our research and development employees to work in our facilities as a result of restrictions imposed by governments, or us, could make it more difficult for them to collaborate as effectively in the development of new solutions.

[0000936395-20-000028:mdna:50]
Business & Operations. We have implemented business continuity plans designed to minimize potential business disruption from the COVID-19 pandemic and to protect our supply chain and customer fulfillment and support operations. During the second quarter of fiscal 2020, we experienced higher than typical orders for our products and services among a concentrated set of larger customers with whom we have existing positions as a supplier. We believe some portion of these orders, in the face of the pandemic, likely reflects short-term purchasing behaviors based on customer-specific considerations described below. However, our revenue for the second quarter of fiscal 2020 was negatively impacted by some disruption within our supply chain, customer fulfillment and logistics, and sales and marketing activities, which adversely impacted our business as described below.

[0000936395-20-000028:mdna:51]
Supply Chain. We rely on third-party manufacturing operations in Mexico, Thailand, the United States and Canada. We also rely on a global component supply network involving many vendors and countries throughout the world. During the second quarter of fiscal 2020, some of our component suppliers – particularly those with facilities in China and Malaysia – experienced challenges related to COVID-19 that resulted in temporary closures or reductions of supply capacity. Although in many cases we were able to overcome these conditions through execution of our mitigation planning, supply chain disruptions negatively impacted our revenue for the second fiscal quarter of 2020. We continue to take steps, including multi-sourcing and pre-ordering components and finished goods inventory, in an effort to reduce the impact should such conditions persist or exacerbate. However, such supply chain disruptions may continue, or worsen, in the future.

[0000936395-20-000028:mdna:52]
Services and Customer Fulfillment. During the second quarter of fiscal 2020, we experienced some disruption in our ability to provide installation, professional and fulfillment services to customers due to site access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings, which adversely impacted revenue. These conditions have also made it more challenging to ramp and operationalize newer projects and recent customer design wins, primarily in international markets. We continue to take steps and work with customers to ensure their business needs are supported, while protecting the health and safety of our employees, customers and business partners. However, should restrictions or disruptions of transportation persist or worsen, such as reduced availability of air transport, port closures, or increased border controls or closures, our operations and ability to meet customer demand could be materially adversely affected.

[0000936395-20-000028:mdna:53]
Sales & Marketing.  The competitive nature of our business depends on our ability to conduct sales and marketing activities with our customers. For instance, in the past few years, our ability to be first to market with leading networking solutions, and to conduct sales and marketing activities around these new technology offerings, has had a significant impact on our revenue and growth. However, restrictions on travel due to COVID-19 and limitations on interactions with customers, such as field and lab trials, have negatively impacted our ability to carry out certain sales and marketing activities, including our ability to secure new customers, to qualify and sell new products, and to grow sales with customers. This is particularly the case where we do not have longer-standing supply relationships, such as within international markets and for our Blue Planet Automation Software & Services segment and our Packet Networking product line.

[0000936395-20-000028:mdna:54]
Demand for Products & Services. As a result of the unique and increased demands placed on network infrastructures as a result of the COVID-19 pandemic and the related increase in remote working worldwide, we believe certain longer-term trends associated with cloud network adoption, networking resilience and flexibility, and the need to promote automation, may be accelerated. During the second quarter of fiscal 2020, we experienced higher than typical orders for our products and services among a concentrated set of larger customers with whom we have existing positions as a supplier. We believe some portion of these orders likely reflects short-term purchasing behaviors based on customer-specific considerations in the face of the pandemic, including: customer concerns about future continued availability of supply; implementation of customer business continuity actions; our desire for increased visibility into expected demand; customer consumption of existing inventory or spare equipment; additional network capacity requirements; acceleration of capital spending; and, possibly, increased bandwidth demands being placed on networks due to the pandemic. We cannot predict whether this increase in orders will continue and, if so, for how long. Due to the unprecedented nature of the COVID-19 pandemic, it is unclear whether the current bandwidth demand, or the increased demand for our solutions experienced in the second quarter of fiscal 2020, will continue or is sustainable during the pandemic or the remainder of fiscal 2020.

[0000936395-20-000028:mdna:55]
Liquidity & Balance Sheet.  As of the end of the second quarter of fiscal 2020, we had $988.5 million in cash and short-term investments. We believe our strong liquidity and balance sheet position is an important competitive differentiator at this time. It enables us to continue to invest in innovation, ensure a strong inventory position to support customers and provide for working capital needs. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020 we temporarily suspended purchases of our common stock under our stock repurchase program and have primarily reallocated our investments principally to U.S. government-backed funds.

[0000936395-20-000028:mdna:56]
Community.  Our global workforce has undertaken a range of volunteering and charitable actions to support our neighbors, communities and front-line health care workers during this challenging time. We have enhanced by three times our corporate charitable matching program for employee donations and volunteering, and our employees have volunteered their time in important ways during this crisis. For example, we have donated personal protective equipment and have been 3-D printing and designing faces shields and components for health care workers.

[0000936395-20-000028:mdna:57]
The COVID-19 pandemic and resulting countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic, and the duration and severity of its impact on our business and results of operations during fiscal 2020 and beyond remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our operations, or in economic activity and demand generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-20-000028:mdna:58]
[same as prior period, unchanged from 0000936395-20-000011:mdna:49]

[0000936395-20-000028:mdna:59]
We have continued to use our significant research and development investment capacity to push the pace of innovation in our markets and provide offerings that promote our Adaptive Network vision through further advances in programmable hardware, analytics, and control and automation. In the first quarter of fiscal 2020, we began market trials of our fifth-generation WaveLogic coherent modem technology, which is capable of delivering 800 gigabits of capacity per second over a single wavelength. In the second quarter of fiscal 2020, this technology became commercially available and began shipping on certain Converged Packet Optical platforms.

[0000936395-20-000028:mdna:60]
In February 2020, we also announced the future addition of several new routing platforms to support the demands of mobile xHaul (fronthaul, midhaul and backhaul) transport, which we expect to make available in the second half of calendar 2020. Designed to enable mobile network operators to migrate from 4G to 5G networks, these routers leverage our Adaptive Network vision and Blue Planet Automation Software to deliver end-to-end IP-based services in a more simplified and modular manner than traditional router-based IP network designs. In addition, we enhanced our Blue Planet Intelligent Automation software portfolio for 5G automation applications, including vendor-agnostic network slicing features and dynamic planning capabilities that are intended to better enable mobile network operators to deliver 5G mobile services.

[0000936395-20-000028:mdna:61]
Available Information. Our quarterly reports on Form 10-Q, annual reports on Form 10-K, current reports on Form 8-K, and any amendments thereto filed or furnished with the SEC are available through the SEC’s website at www.sec.gov and are available free of charge on our website as soon as reasonably practicable after we file or furnish these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Information on our website is not deemed to be incorporated by reference into this report. Investors are encouraged to review the “Investors” section of our website because, as

[0000936395-20-000028:mdna:62]
with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-20-000028:mdna:63]
[same as prior period, unchanged from 0000936395-20-000011:mdna:57]

[0000936395-20-000028:mdna:64]
[same as prior period, unchanged from 0000936395-20-000011:mdna:59]

[0000936395-20-000028:mdna:65]
[same as prior period, unchanged from 0000936395-20-000011:mdna:60]

[0000936395-20-000028:mdna:66]
[same as prior period, unchanged from 0000936395-20-000011:mdna:61]

[0000936395-20-000028:mdna:67]
Quarter ended May 2, 2020 compared to the quarter ended May 4, 2019

[0000936395-20-000028:mdna:68]
[same as prior period, unchanged from 0000936395-20-000011:mdna:63]

[0000936395-20-000028:mdna:69]
Despite increases in revenue within certain segments in the second quarter of fiscal 2020 as compared to the second quarter of fiscal 2019, our revenue was adversely affected during the second quarter of fiscal 2020 due to the impact of the COVID-19 pandemic and its resulting supply chain and customer fulfillment disruptions described above.

[0000936395-20-000028:mdna:70]
During the second quarter of fiscal 2020, approximately 15.0% of our revenue was non-U.S. Dollar-denominated, primarily including sales in Euros, Canadian Dollars, Japanese Yen, British Pounds, and Brazilian Reais. During the second quarter of fiscal 2020, as compared to the second quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced slightly by approximately $5.8 million, or 0.6%, as compared to the second quarter of fiscal 2019. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:71]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | 73.2 |  | $ | 623,838 |  |  | 72.1 |  | $ | 30,456 |  |  | 4.9 |  |
| Packet Networking | 64,167 |  |  | 7.2 |  | 73,138 |  |  | 8.5 |  | (8,971 | ) |  | (12.3 | ) |
| Total Networking Platforms | 718,461 |  |  | 80.4 |  | 696,976 |  |  | 80.6 |  | 21,485 |  |  | 3.1 |  |
| Platform Software and Services | 44,985 |  |  | 5.0 |  | 35,229 |  |  | 4.0 |  | 9,756 |  |  | 27.7 |  |
| Blue Planet Automation Software and Services | 15,017 |  |  | 1.7 |  | 12,473 |  |  | 1.4 |  | 2,544 |  |  | 20.4 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 71,479 |  |  | 8.0 |  | 68,788 |  |  | 8.0 |  | 2,691 |  |  | 3.9 |  |
| Installation and Deployment | 34,242 |  |  | 3.8 |  | 41,322 |  |  | 4.8 |  | (7,080 | ) |  | (17.1 | ) |
| Consulting and Network Design | 9,869 |  |  | 1.1 |  | 10,223 |  |  | 1.2 |  | (354 | ) |  | (3.5 | ) |
| Total Global Services | 115,590 |  |  | 12.9 |  | 120,333 |  |  | 14.0 |  | (4,743 | ) |  | (3.9 | ) |
| Consolidated revenue | $ | 894,053 |  |  | 100.0 |  | $ | 865,011 |  |  | 100.0 |  | $ | 29,042 |  |  | 3.4 |  |

[0000936395-20-000028:mdna:72]
[same as prior period, unchanged from 0000936395-20-000011:mdna:66]

[0000936395-20-000028:mdna:73]
[same as prior period, unchanged from 0000936395-20-000011:mdna:67]

[0000936395-20-000028:mdna:74]
[same as prior period, unchanged from 0000936395-20-000011:mdna:68]

[0000936395-20-000028:mdna:75]
| • | Networking Platforms segment revenue increased, reflecting a product line sales increase of $30.5 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $9.0 million of our Packet Networking products. |

[0000936395-20-000028:mdna:76]
| ◦ | Converged Packet Optical sales increased, primarily reflecting an increase of $42.2 million of our Waveserver products primarily to Web-scale providers and cable and multi service operators. This increase was partially offset by a sales decrease of $8.8 million of our 5430 Reconfigurable Switching Systems to communications service providers. |

[0000936395-20-000028:mdna:77]
| ◦ | Packet Networking sales decreased, primarily reflecting sales decreases of $11.2 million of our 6500 Packet Transport System (PTS) to communications service providers and $3.4 million of our 8700 Packetwave Platform to communication service providers. These sales decreases were partially offset by a sales increase of $6.1 million of our 3000 and 5000 families of service delivery and aggregation switches to cable and multiservice operators, enterprise customers and Web-scale providers. |

[0000936395-20-000028:mdna:78]
| • | Platform Software and Services segment revenue increased, reflecting increases of $6.1 million in software sales and $3.7 million related to services. |

[0000936395-20-000028:mdna:79]
| • | Blue Planet Automation Software and Services segment revenue increased, reflecting increases of $1.6 million in software platforms and $1.0 million in software services. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date. |

[0000936395-20-000028:mdna:80]
| • | Global Services segment revenue decreased, primarily reflecting a sales decrease of $7.1 million of our installation and deployment services, in part due to impacts of COVID-19 as described above, offset by a sales increase of $2.7 million of our maintenance support and training. |

[0000936395-20-000028:mdna:81]
Our operating segments engage in business and operations across three geographic regions: Americas, EMEA and APAC. As discussed in Note 3, effective the beginning of fiscal 2020, our Global Sales and Marketing organization combined our previous North America and CALA regions into a new Americas sales region. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:82]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Americas | $ | 650,381 |  |  | 72.7 |  | $ | 615,492 |  |  | 71.1 |  | $ | 34,889 |  |  | 5.7 |  |
| EMEA | 141,431 |  |  | 15.8 |  | 114,993 |  |  | 13.3 |  | 26,438 |  |  | 23.0 |  |
| APAC | 102,241 |  |  | 11.5 |  | 134,526 |  |  | 15.6 |  | (32,285 | ) |  | (24.0 | ) |
| Total | $ | 894,053 |  |  | 100.0 |  | $ | 865,011 |  |  | 100.0 |  | $ | 29,042 |  |  | 3.4 |  |

[0000936395-20-000028:mdna:83]
[same as prior period, unchanged from 0000936395-20-000011:mdna:78]

[0000936395-20-000028:mdna:84]
[same as prior period, unchanged from 0000936395-20-000011:mdna:79]

[0000936395-20-000028:mdna:85]
[same as prior period, unchanged from 0000936395-20-000011:mdna:80]

[0000936395-20-000028:mdna:86]
| • | Americas revenue increased primarily reflecting sales increases of $22.5 million within our Networking Platforms segment, $9.7 million within our Platform Software and Services segment and $4.1 million in our Global Services segment. The increase within our Networking Platforms segment reflects a product line sales increase of $31.9 million of Converged Packet Optical products, primarily related to sales increases of $18.2 million of our Waveserver products and $17.3 million of our 6500 Packet-Optical Platform, partially offset by a decrease of $5.7 million of our 5430 Reconfigurable Switching Systems. Our Waveserver sales increase primarily reflects increased sales to cable and multiservice operators. Our 6500 Packet-Optical Platform sales increase primarily reflects increased sales to government customers, cable and multiservice providers, communications service providers and Web-scale providers, partially offset by decreased sales to enterprise customers. Our 5430 Reconfigurable Switching Systems sales decrease primarily reflects decreased sales to communications service providers. |

[0000936395-20-000028:mdna:87]
| • | EMEA revenue increased primarily reflecting an increase of $29.1 million within our Networking Platforms segment partially offset by a decrease of $3.8 million in our Global Services segment. The revenue increase within our Networking Platforms segment reflects a product line sales increase of $28.4 million of Converged Packet Optical products, primarily related to sales increases of $16.7 million of our Waveserver products and $13.3 million of our 6500 Packet-Optical Platform, primarily to Web-scale providers. |

[0000936395-20-000028:mdna:88]
| • | APAC revenue decreased primarily reflecting decreases of $30.1 million within our Networking Platforms segment and $5.0 million of our Global Services segment, partially offset by sales increases of $3.1 million within our Blue |

[0000936395-20-000028:mdna:89]
[same as prior period, unchanged from 0000936395-20-000011:mdna:85]

[0000936395-20-000028:mdna:90]
Planet Automation Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $34.6 million in sales of our 6500 Packet-Optical Platform primarily to communications service providers in India and Japan, partially offset by an increase of $7.4 million in sales of our Waveserver products primarily to Web-scale providers.

[0000936395-20-000028:mdna:91]
[same as prior period, unchanged from 0000936395-20-000011:mdna:84]

[0000936395-20-000028:mdna:92]
[same as prior period, unchanged from 0000936395-20-000011:mdna:86]

[0000936395-20-000028:mdna:93]
[same as prior period, unchanged from 0000936395-20-000011:mdna:87]

[0000936395-20-000028:mdna:94]
[same as prior period, unchanged from 0000936395-20-000011:mdna:88]

[0000936395-20-000028:mdna:95]
[same as prior period, unchanged from 0000936395-20-000011:mdna:89]

[0000936395-20-000028:mdna:96]
[same as prior period, unchanged from 0000936395-20-000011:mdna:90]

[0000936395-20-000028:mdna:97]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 894,053 |  |  | 100.0 |  | $ | 865,011 |  |  | 100.0 |  | $ | 29,042 |  |  | 3.4 |  |
| Total cost of goods sold | 480,727 |  |  | 53.8 |  | 490,334 |  |  | 56.7 |  | (9,607 | ) |  | (2.0 | ) |
| Gross profit | $ | 413,326 |  |  | 46.2 |  | $ | 374,677 |  |  | 43.3 |  | $ | 38,649 |  |  | 10.3 |  |

[0000936395-20-000028:mdna:98]
[same as prior period, unchanged from 0000936395-20-000011:mdna:92]

[0000936395-20-000028:mdna:99]
[same as prior period, unchanged from 0000936395-20-000011:mdna:93]

[0000936395-20-000028:mdna:100]
[same as prior period, unchanged from 0000936395-20-000011:mdna:94]

[0000936395-20-000028:mdna:101]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 739,892 |  |  | 100.0 |  | $ | 710,688 |  |  | 100.0 |  | $ | 29,204 |  |  | 4.1 |  |
| Product cost of goods sold | 405,138 |  |  | 54.8 |  | 411,050 |  |  | 57.8 |  | (5,912 | ) |  | (1.4 | ) |
| Product gross profit | $ | 334,754 |  |  | 45.2 |  | $ | 299,638 |  |  | 42.2 |  | $ | 35,116 |  |  | 11.7 |  |

[0000936395-20-000028:mdna:102]
[same as prior period, unchanged from 0000936395-20-000011:mdna:96]

[0000936395-20-000028:mdna:103]
[same as prior period, unchanged from 0000936395-20-000011:mdna:97]

[0000936395-20-000028:mdna:104]
[same as prior period, unchanged from 0000936395-20-000011:mdna:98]

[0000936395-20-000028:mdna:105]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 154,161 |  |  | 100.0 |  | $ | 154,323 |  |  | 100.0 |  | $ | (162 | ) |  | (0.1 | ) |
| Service cost of goods sold | 75,589 |  |  | 49.0 |  | 79,284 |  |  | 51.4 |  | (3,695 | ) |  | (4.7 | ) |
| Service gross profit | $ | 78,572 |  |  | 51.0 |  | $ | 75,039 |  |  | 48.6 |  | $ | 3,533 |  |  | 4.7 |  |

[0000936395-20-000028:mdna:106]
[same as prior period, unchanged from 0000936395-20-000011:mdna:100]

[0000936395-20-000028:mdna:107]
[same as prior period, unchanged from 0000936395-20-000011:mdna:101]

[0000936395-20-000028:mdna:108]
[same as prior period, unchanged from 0000936395-20-000011:mdna:102]

[0000936395-20-000028:mdna:109]
| • | Gross profit as a percentage of revenue increased, as our gross margin benefited significantly from a favorable mix of customers and product lines that we believe to be a short-term effect due to COVID-19 related factors, as well as continued improvement in our service margin. Due to the impact of COVID-19 and related restrictions upon sales and marketing activities described in “Overview” above, during the second quarter of fiscal 2020, a higher proportion of our revenue consisted of sales of existing technology to existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms. Efforts to expand our customer base or market share can adversely affect our gross margin as a result of the more aggressive pricing, commercial concessions and other unfavorable terms often required to be successful within our competitive markets. In recent periods, we have encountered fluctuations in our gross margin as a result of our ongoing strategy to leverage our technology leadership, displace competitors and to capture aggressively additional market share. The resulting mix of revenues from such new wins or early stage deployments during a particular period can adversely impact gross margins. However, the intent of this strategy would be to improve margin in the longer term, as we sell channel cards adding capacity or services to their networks, maintenance services, and other higher margin products over time. |

[0000936395-20-000028:mdna:110]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and product lines, as described above, and continued product cost reductions, partially offset by market-based price compression we encountered during the period. |

[0000936395-20-000028:mdna:111]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to a higher concentration of revenue from maintenance service contracts with relatively low incremental costs, and fewer early stage network deployment activities due to the impact of COVID-19. |

[0000936395-20-000028:mdna:112]
[same as prior period, unchanged from 0000936395-20-000011:mdna:106]

[0000936395-20-000028:mdna:113]
[same as prior period, unchanged from 0000936395-20-000011:mdna:107]

[0000936395-20-000028:mdna:114]
[same as prior period, unchanged from 0000936395-20-000011:mdna:108]

[0000936395-20-000028:mdna:115]
[same as prior period, unchanged from 0000936395-20-000011:mdna:109]

[0000936395-20-000028:mdna:116]
[same as prior period, unchanged from 0000936395-20-000011:mdna:110]

[0000936395-20-000028:mdna:117]
[same as prior period, unchanged from 0000936395-20-000011:mdna:111]

[0000936395-20-000028:mdna:118]
[same as prior period, unchanged from 0000936395-20-000011:mdna:112]

[0000936395-20-000028:mdna:119]
[same as prior period, unchanged from 0000936395-20-000011:mdna:115]

[0000936395-20-000028:mdna:120]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of DonRiver and Centina, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition. |

[0000936395-20-000028:mdna:121]
During the second quarter of fiscal 2020, approximately 51.0% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, Indian Rupees and British Pounds. During the second quarter of fiscal 2020 as compared to the second quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our operating expense reported in U.S. Dollars was reduced slightly by approximately $3.5 million, or 1.2%, as compared to the second quarter of fiscal 2019, due to the strengthening U.S. Dollar, net of hedging. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:122]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 131,530 |  |  | 14.7 |  | $ | 137,969 |  |  | 15.9 |  | $ | (6,439 | ) |  | (4.7 | ) |
| Selling and marketing | 101,214 |  |  | 11.3 |  | 103,502 |  |  | 12.0 |  | (2,288 | ) |  | (2.2 | ) |
| General and administrative | 42,030 |  |  | 4.7 |  | 42,154 |  |  | 4.9 |  | (124 | ) |  | (0.3 | ) |
| Amortization of intangible assets | 5,839 |  |  | 0.7 |  | 5,529 |  |  | 0.6 |  | 310 |  |  | 5.6 |  |
| Significant asset impairments and restructuring costs | 3,811 |  |  | 0.4 |  | 4,068 |  |  | 0.5 |  | (257 | ) |  | (6.3 | ) |
| Acquisition and integration costs | 1,414 |  |  | 0.2 |  | 1,135 |  |  | 0.1 |  | 279 |  |  | 24.6 |  |
| Total operating expenses | $ | 285,838 |  |  | 32.0 |  | $ | 294,357 |  |  | 34.0 |  | $ | (8,519 | ) |  | (2.9 | ) |

[0000936395-20-000028:mdna:123]
[same as prior period, unchanged from 0000936395-20-000011:mdna:118]

[0000936395-20-000028:mdna:124]
[same as prior period, unchanged from 0000936395-20-000011:mdna:119]

[0000936395-20-000028:mdna:125]
[same as prior period, unchanged from 0000936395-20-000011:mdna:120]

[0000936395-20-000028:mdna:126]
| • | Research and development expense decreased by $6.4 million, primarily reflecting a decrease in professional services. |

[0000936395-20-000028:mdna:127]
| • | Selling and marketing expense decreased by $2.3 million, primarily reflecting decreases in travel and entertainment costs due to restrictions on travel and limitations on our interactions with customers as a result of COVID-19. This decrease was partially offset by an increase in employee and compensation cost. |

[0000936395-20-000028:mdna:128]
| • | General and administrative expense remained relatively unchanged. |

[0000936395-20-000028:mdna:129]
| • | Amortization of intangible assets slightly increased due to additional intangibles acquired in connection with our acquisition of Centina in the first quarter of fiscal 2020. |

[0000936395-20-000028:mdna:130]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. |

[0000936395-20-000028:mdna:131]
| • | Acquisition and integration costs primarily reflect employment-related costs related to our acquisition of DonRiver. |

[0000936395-20-000028:mdna:132]
[same as prior period, unchanged from 0000936395-20-000011:mdna:127]

[0000936395-20-000028:mdna:133]
[same as prior period, unchanged from 0000936395-20-000011:mdna:128]

[0000936395-20-000028:mdna:134]
|  | Quarter Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,665 | ) |  | (0.3 | ) |  | $ | (244 | ) |  | 0.0 |  |  | $ | (2,421 | ) |  | 992.2 |  |
| Interest expense | $ | 7,860 |  |  | 0.9 |  |  | $ | 9,471 |  |  | 1.1 |  |  | $ | (1,611 | ) |  | (17.0 | ) |
| Provision for income taxes | $ | 25,308 |  |  | 2.8 |  |  | $ | 17,867 |  |  | 2.1 |  |  | $ | 7,441 |  |  | 41.6 |  |

[0000936395-20-000028:mdna:135]
[same as prior period, unchanged from 0000936395-20-000011:mdna:130]

[0000936395-20-000028:mdna:136]
[same as prior period, unchanged from 0000936395-20-000011:mdna:131]

[0000936395-20-000028:mdna:137]
[same as prior period, unchanged from 0000936395-20-000011:mdna:132]

[0000936395-20-000028:mdna:138]
| • | Interest and other income (loss), net primarily reflects lower interest income due to reduced interest rates on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-20-000028:mdna:139]
| • | Interest expense decreased, primarily due to a reduction of LIBOR rates impacting our New 2025 Term Loan. |

[0000936395-20-000028:mdna:140]
| • | Provision for income taxes increased, due to higher earnings for the second quarter of fiscal 2020. The effective tax rate for the second quarter of fiscal 2020 was lower compared to the second quarter of fiscal 2019, primarily due to reduced BEAT. |

[0000936395-20-000028:mdna:141]
Six months ended May 2, 2020 compared to the six months ended May 4, 2019

[0000936395-20-000028:mdna:142]
Revenue

[0000936395-20-000028:mdna:143]
During the first six months of fiscal 2020, approximately 16.3% of our revenue was non-U.S. Dollar-denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, British Pounds, Indian Rupees and United Arab Emirates Dirham. During the first six months of fiscal 2020, as compared to the first six months of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced by approximately $6.5 million or 0.4%. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:144]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | 72.1 |  | $ | 1,172,835 |  |  | 71.4 |  | 73,009 |  |  | 6.2 |  |
| Packet Networking | 131,675 |  |  | 7.6 |  | 144,707 |  |  | 8.8 |  | (13,032 | ) |  | (9.0 | ) |
| Total Networking Platforms | 1,377,519 |  |  | 79.7 |  | 1,317,542 |  |  | 80.2 |  | 59,977 |  |  | 4.6 |  |
| Platform Software and Services | 96,873 |  |  | 5.6 |  | 76,827 |  |  | 4.7 |  | 20,046 |  |  | 26.1 |  |
| Blue Planet Automation Software and Services | 30,482 |  |  | 1.8 |  | 27,447 |  |  | 1.6 |  | 3,035 |  |  | 11.1 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 133,271 |  |  | 7.8 |  | 130,065 |  |  | 7.9 |  | 3,206 |  |  | 2.5 |  |
| Installation and Deployment | 69,196 |  |  | 4.0 |  | 71,944 |  |  | 4.4 |  | (2,748 | ) |  | (3.8 | ) |
| Consulting and Network Design | 19,624 |  |  | 1.1 |  | 19,713 |  |  | 1.2 |  | (89 | ) |  | (0.5 | ) |
| Total Global Services | 222,091 |  |  | 12.9 |  | 221,722 |  |  | 13.5 |  | 369 |  |  | 0.2 |  |
| Consolidated revenue | $ | 1,726,965 |  |  | 100.0 |  | $ | 1,643,538 |  |  | 100.0 |  | $ | 83,427 |  |  | 5.1 |  |

[0000936395-20-000028:mdna:145]
_____________________________

[0000936395-20-000028:mdna:146]
*    Denotes % of total revenue

[0000936395-20-000028:mdna:147]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:148]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $73.0 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $13.0 million of our Packet Networking products. |

[0000936395-20-000028:mdna:149]
| ◦ | Converged Packet Optical sales increased, reflecting increases of $38.6 million of our 6500 Packet-Optical Platform primarily to government customers, Web-scale providers and cable and multi service operators, $25.5 million of our 5430 Reconfigurable Switching Systems to communications service providers and $6.8 million of our Waveserver products which benefited from increased sales to cable and multiservice operators. |

[0000936395-20-000028:mdna:150]
| ◦ | Packet Networking sales decreased, primarily reflecting a sales decrease of $25.6 million of our 6500 Packet Transport System (PTS) to communications service providers. These sales decreases were partially offset by a sales increase of $14.2 million of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers, cable and multiservice operators and enterprise customers. |

[0000936395-20-000028:mdna:151]
38

[0000936395-20-000028:mdna:152]
| • | Platform Software and Services segment revenue increased, reflecting an increase of $14.7 million in software sales and $5.3 million primarily related to services to communications service providers. |

[0000936395-20-000028:mdna:153]
| • | Blue Planet Automation Software and Services segment revenue increased, reflecting an increase of $3.9 million in software services partially offset by a decrease in software sales of $1.0 million. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date. |

[0000936395-20-000028:mdna:154]
| • | Global Services segment revenue slightly increased, primarily reflecting a sales increase of $3.2 million of our maintenance support and training offset by a sales decrease of $2.7 million of our installation and deployment services. |

[0000936395-20-000028:mdna:155]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of Americas, can result in large variations in geographic revenue results in any particular quarter. The increase in our EMEA region for the six months ended May 2, 2020 was primarily driven by increased sales in the Netherlands, the United Arab Emirates and Germany. The decrease in our APAC region for the six months ended May 2, 2020 was primarily driven by decreased sales in India and Japan, partially offset by increased sales in Singapore and Australia. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:156]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,224,385 |  |  | 70.9 |  | $ | 1,131,973 |  |  | 68.8 |  | $ | 92,412 |  |  | 8.2 |  |
| EMEA | 271,396 |  |  | 15.7 |  | 244,183 |  |  | 14.9 |  | 27,213 |  |  | 11.1 |  |
| APAC | 231,184 |  |  | 13.4 |  | 267,382 |  |  | 16.3 |  | (36,198 | ) |  | (13.5 | ) |
| Total | $ | 1,726,965 |  |  | 100.0 |  | $ | 1,643,538 |  |  | 100.0 |  | $ | 83,427 |  |  | 5.1 |  |

[0000936395-20-000028:mdna:157]
[same as prior period, unchanged from 0000936395-20-000011:mdna:140]

[0000936395-20-000028:mdna:158]
*    Denotes % of total revenue

[0000936395-20-000028:mdna:159]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:160]
| • | Americas revenue increased, primarily reflecting sales increases of $68.7 million within our Networking Platforms segment, $16.9 million within our Platform Software and Services segment and $10.5 million within our Global Services segment. These sales increases were slightly offset by a sales decrease of $3.8 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $83.3 million of Converged Packet Optical products, partially offset by a decrease of $14.6 million of Packet Networking products. Our Converged Packet Optical revenue increase reflects sales increases of $72.2 million of our 6500 Packet-Optical Platform and $17.9 million of our 5430 Reconfigurable Switching Systems, partially offset by a decrease of $10.5 million of our Waveserver products. Our 6500 Packet-Optical Platform revenue increase primarily reflects increased sales to communications service providers, government customers and cable and multiservice operators. Our 5430 Reconfigurable Switching Systems sales increase primarily reflect increased sales to communications service providers. Waveserver sales reflect decreased sales to Web-scale providers, partially offset by increased sales to cable and multiservice operators. |

[0000936395-20-000028:mdna:161]
| • | EMEA revenue increased, primarily reflecting an increase of $31.2 million within our Networking Platforms segment, partially offset by a decrease of $5.2 million within our Global Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $30.3 million of Converged Packet Optical products, primarily related to sales increases of $17.7 million of our 6500 Packet-Optical Platform to Web-scale providers and communications service providers, $8.4 million of our 5430 Reconfigurable Switching Systems to communication service providers and $6.0 million of Waveserver to cable and multiservice operators. |

[0000936395-20-000028:mdna:162]
| • | APAC revenue decreased, primarily reflecting decreases of $39.9 million within our Networking Platforms segment and $5.0 million of our Global Services segment. These decreases were partially offset by sales increases of $6.2 million within our Blue Planet Automation Software and Services segment and $2.5 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $51.3 million in sales of our 6500 Packet-Optical Platform, primarily to communications service providers in Japan and India, partially offset by an increase of $11.3 million in sales of our Waveserver products primarily to Web-scale providers. |

[0000936395-20-000028:mdna:163]
Cost of Goods Sold and Gross Profit

[0000936395-20-000028:mdna:164]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:165]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,726,965 |  |  | 100.0 |  | $ | 1,643,538 |  |  | 100.0 |  | $ | 83,427 |  |  | 5.1 |  |
| Total cost of goods sold | 943,104 |  |  | 54.6 |  | 945,520 |  |  | 57.5 |  | (2,416 | ) |  | (0.3 | ) |
| Gross profit | $ | 783,861 |  |  | 45.4 |  | $ | 698,018 |  |  | 42.5 |  | $ | 85,843 |  |  | 12.3 |  |

[0000936395-20-000028:mdna:166]
_____________________________________

[0000936395-20-000028:mdna:167]
*    Denotes % of total revenue

[0000936395-20-000028:mdna:168]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:169]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,427,107 |  |  | 100.0 |  | $ | 1,353,220 |  |  | 100.0 |  | $ | 73,887 |  |  | 5.5 |
| Product cost of goods sold | 794,151 |  |  | 55.6 |  | 791,492 |  |  | 58.5 |  | 2,659 |  |  | 0.3 |
| Product gross profit | $ | 632,956 |  |  | 44.4 |  | $ | 561,728 |  |  | 41.5 |  | $ | 71,228 |  |  | 12.7 |

[0000936395-20-000028:mdna:170]
_____________________________________

[0000936395-20-000028:mdna:171]
*    Denotes % of product revenue

[0000936395-20-000028:mdna:172]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:173]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 299,858 |  |  | 100.0 |  | $ | 290,318 |  |  | 100.0 |  | $ | 9,540 |  |  | 3.3 |  |
| Service cost of goods sold | 148,953 |  |  | 49.7 |  | 154,028 |  |  | 53.1 |  | (5,075 | ) |  | (3.3 | ) |
| Service gross profit | $ | 150,905 |  |  | 50.3 |  | $ | 136,290 |  |  | 46.9 |  | $ | 14,615 |  |  | 10.7 |  |

[0000936395-20-000028:mdna:174]
_____________________________________

[0000936395-20-000028:mdna:175]
*    Denotes % of services revenue

[0000936395-20-000028:mdna:176]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:177]
| • | Gross profit as a percentage of revenue reflects improved product and services gross profit as described below. |

[0000936395-20-000028:mdna:178]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and product lines and product cost reductions, partially offset by market-based price compression we encountered during the period. |

[0000936395-20-000028:mdna:179]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to higher revenues on maintenance contracts with relatively low incremental costs. |

[0000936395-20-000028:mdna:180]
Operating Expense

[0000936395-20-000028:mdna:181]
During the first six months of fiscal 2020, approximately 50.9% of our operating expense was non-U.S. Dollar-denominated, including Canadian Dollars, Indian Rupees, British Pounds, and Euros. Consequently, our operating expense reported in U.S. Dollars was reduced by approximately $3.7 million, or 0.6%, during the first six months of fiscal 2020 as compared to the first six months of fiscal 2019, due to the strengthening U.S. Dollar, net of hedging. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:182]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 262,430 |  |  | 15.2 |  | $ | 266,602 |  |  | 16.2 |  | $ | (4,172 | ) |  | (1.6 | ) |
| Selling and marketing | 208,280 |  |  | 12.1 |  | 201,615 |  |  | 12.3 |  | 6,665 |  |  | 3.3 |  |
| General and administrative | 84,498 |  |  | 4.9 |  | 81,397 |  |  | 5.0 |  | 3,101 |  |  | 3.8 |  |
| Amortization of intangible assets | 11,692 |  |  | 0.7 |  | 11,057 |  |  | 0.7 |  | 635 |  |  | 5.7 |  |
| Significant asset impairments and restructuring costs | 8,283 |  |  | 0.4 |  | 6,341 |  |  | 0.4 |  | 1,942 |  |  | 30.6 |  |
| Acquisition and integration costs | 3,233 |  |  | 0.2 |  | 2,743 |  |  | 0.2 |  | 490 |  |  | 17.9 |  |
| Total operating expenses | $ | 578,416 |  |  | 33.5 |  | $ | 569,755 |  |  | 34.8 |  | $ | 8,661 |  |  | 1.5 |  |

[0000936395-20-000028:mdna:183]
_____________________________________

[0000936395-20-000028:mdna:184]
*    Denotes % of total revenue

[0000936395-20-000028:mdna:185]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:186]
| • | Research and development expense decreased by $4.2 million primarily reflecting a decrease in professional services, partially offset by an increase of employee and compensation costs. |

[0000936395-20-000028:mdna:187]
| • | Selling and marketing expense benefited by $2.2 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Euro and Australian Dollar. Including the effect of foreign exchange rates, net of hedging, sales and marketing expense increased by $6.7 million primarily reflecting an increase in employee and compensation costs partially offset by a decrease in travel and entertainment costs due to restrictions on travel as a result of COVID-19. |

[0000936395-20-000028:mdna:188]
| • | General and administrative expense increased by $3.1 million primarily reflecting an increase in bad debt expense and employee and compensation costs. |

[0000936395-20-000028:mdna:189]
[same as prior period, unchanged from 0000936395-20-000011:mdna:124]

[0000936395-20-000028:mdna:190]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. |

[0000936395-20-000028:mdna:191]
| • | Acquisition and integration costs reflect employment-related costs related to our acquisition of DonRiver and legal, employee-related and other costs related to our acquisition of Centina in the first quarter of fiscal 2020. |

[0000936395-20-000028:mdna:192]
Other items

[0000936395-20-000028:mdna:193]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-20-000028:mdna:194]
|  | Six Months Ended |  | Increase |  |  |
|  | May 2, 2020 |  | %* |  | May 4, 2019 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 981 |  |  | 0.1 |  | $ | 4,009 |  |  | 0.2 |  | $ | (3,028 | ) |  | (75.5 | ) |
| Interest expense | $ | 16,675 |  |  | 1.0 |  | $ | 18,912 |  |  | 1.2 |  | $ | (2,237 | ) |  | (11.8 | ) |
| Loss on extinguishment of debt | $ | 646 |  |  | — |  | $ | — |  |  | — |  | $ | 646 |  |  | 100.0 |  |
| Provision for income taxes | $ | 35,122 |  |  | 2.0 |  | $ | 27,006 |  |  | 1.6 |  | $ | 8,116 |  |  | 30.1 |  |

[0000936395-20-000028:mdna:195]
_____________________________________

[0000936395-20-000028:mdna:196]
*    Denotes % of total revenue

[0000936395-20-000028:mdna:197]
**    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:198]
| • | Interest and other income (loss), net primarily reflects lower interest income due to reduced interest rates on our investments. |

[0000936395-20-000028:mdna:199]
[same as prior period, unchanged from 0000936395-20-000011:mdna:134]

[0000936395-20-000028:mdna:200]
| • | Loss on extinguishment of debt reflects the refinance of our Old 2025 Term Loan into our New 2025 Term Loan in the first quarter of fiscal 2020. |

[0000936395-20-000028:mdna:201]
| • | Provision for income taxes increased, due to higher earnings for the first six months of fiscal 2020. The effective tax rate for the first six months of fiscal 2020 was lower compared to the first six months of fiscal 2019, primarily due to reduced BEAT and the effect of the final regulations released on December 2, 2019. |

[0000936395-20-000028:mdna:202]
[same as prior period, unchanged from 0000936395-20-000011:mdna:137]

[0000936395-20-000028:mdna:203]
[same as prior period, unchanged from 0000936395-20-000011:mdna:138]

[0000936395-20-000028:mdna:204]
|  | Quarter Ended |  |  |  |  |
|  | May 2, 2020 |  | May 4, 2019 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 210,987 |  |  | $ | 175,191 |  |  | $ | 35,796 |  |  | 20.4 |  |
| Platform Software and Services | $ | 21,668 |  |  | $ | 12,477 |  |  | $ | 9,191 |  |  | 73.7 |  |
| Blue Planet Automation Software and Services | $ | (4,399 | ) |  | $ | (5,941 | ) |  | $ | 1,542 |  |  | (26.0 | ) |
| Global Services | $ | 53,540 |  |  | $ | 54,981 |  |  | $ | (1,441 | ) |  | (2.6 | ) |

[0000936395-20-000028:mdna:205]
_____________________________________

[0000936395-20-000028:mdna:206]
[same as prior period, unchanged from 0000936395-20-000011:mdna:141]

[0000936395-20-000028:mdna:207]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, higher gross margin as described above and lower research and development costs. |

[0000936395-20-000028:mdna:208]
| • | Platform Software and Services segment profit increased, primarily due to higher sales volume as described above. |

[0000936395-20-000028:mdna:209]
| • | Blue Planet Automation Software and Services segment loss decreased, primarily due to improved gross margin and higher sales volume partially offset by higher research and development costs. |

[0000936395-20-000028:mdna:210]
| • | Global Services segment profit decreased, primarily due to lower sales volume slightly offset by improved gross margin, as described above. |

[0000936395-20-000028:mdna:211]
|  | Six Months Ended |  |  |  |  |
|  | May 2, 2020 |  | May 4, 2019 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 379,256 |  |  | $ | 311,782 |  |  | $ | 67,474 |  |  | 21.6 |  |
| Platform Software and Services | $ | 50,619 |  |  | $ | 32,940 |  |  | $ | 17,679 |  |  | 53.7 |  |
| Blue Planet Automation Software and Services | $ | (7,512 | ) |  | $ | (7,988 | ) |  | $ | 476 |  |  | (6.0 | ) |
| Global Services | $ | 99,068 |  |  | $ | 94,682 |  |  | $ | 4,386 |  |  | 4.6 |  |

[0000936395-20-000028:mdna:212]
_____________________________________

[0000936395-20-000028:mdna:213]
*    Denotes % change from 2019 to 2020

[0000936395-20-000028:mdna:214]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume and higher gross margin as described above and lower research and development costs. |

[0000936395-20-000028:mdna:215]
| • | Platform Software and Services segment profit increased, primarily due to higher sales volume and improved gross margin on product sales, as described above, partially offset by reduced gross margin on software-related services. |

[0000936395-20-000028:mdna:216]
| • | Blue Planet Automation Software and Services segment loss decreased, primarily due to higher gross margin on software-related services and higher sales volume, partially offset by higher research and development costs and lower gross margin on product sales. |

[0000936395-20-000028:mdna:217]
| • | Global Services segment profit increased, primarily due to improved gross margin as described above. |

[0000936395-20-000028:mdna:218]
[same as prior period, unchanged from 0000936395-20-000011:mdna:146]

[0000936395-20-000028:mdna:219]
Overview. For the six months ended May 2, 2020, we generated $130.9 million of cash from operating activities, as our net income (adjusted for non-cash charges) of $323.3 million exceeded our working capital requirements of $192.4 million. For additional details on our cash provided by operating activities, see the discussion below entitled “Cash Provided By Operating Activities.”

[0000936395-20-000028:mdna:220]
Despite our cash generated from operations, cash, cash equivalents and investments decreased by $35.5 million during the first six months of fiscal 2020. The decrease in cash primarily reflects (i) cash used to fund our investing activities for capital expenditures totaling $45.5 million, (ii) cash used for the acquisition of Centina of $28.3 million, (iii) cash used for stock repurchases under our stock repurchase program of $74.5 million, and (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $18.2 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $12.3 million in cash during the six months ended May 2, 2020.

[0000936395-20-000028:mdna:221]
|  | May 2, 2020 |  | November 2, 2019 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 887,732 |  |  | $ | 904,045 |  |  | $ | (16,313 | ) |
| Short-term investments in marketable debt securities | 100,742 |  |  | 109,940 |  |  | (9,198 | ) |
| Long-term investments in marketable debt securities | — |  |  | 10,014 |  |  | (10,014 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 988,474 |  |  | $ | 1,023,999 |  |  | $ | (35,525 | ) |

[0000936395-20-000028:mdna:222]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of May 2, 2020 totaled $988.5 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of May 2, 2020, letters of credit totaling $80.8 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of May 2, 2020.

[0000936395-20-000028:mdna:223]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $81.4 million as of May 2, 2020. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $27.0 million.

[0000936395-20-000028:mdna:224]
Stock Repurchase Authorization. On December 13, 2018, we announced that the Board of Directors authorized a program to repurchase up to $500 million of its common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020, we temporarily suspended purchases of our common stock under this program. We repurchased $74.5 million under this program during the first six months of fiscal 2020, and had $275.4 million remaining under the current authorization as of May 2, 2020. The reinstatement of the program and amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be reinstated, modified, suspended, or discontinued at any time.

[0000936395-20-000028:mdna:225]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and to reduce our debt. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-20-000028:mdna:226]
[same as prior period, unchanged from 0000936395-20-000011:mdna:157]

[0000936395-20-000028:mdna:227]
The following sections set forth the components of our $130.9 million of cash provided by operating activities during the first six months of fiscal 2020:

[0000936395-20-000028:mdna:228]
[same as prior period, unchanged from 0000936395-20-000011:mdna:159]

[0000936395-20-000028:mdna:229]
[same as prior period, unchanged from 0000936395-20-000011:mdna:160]

[0000936395-20-000028:mdna:230]
|  | Six Months Ended |
|  | May 2, 2020 |
| Net income | $ | 153,983 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 48,381 |  |
| Share-based compensation costs | 33,579 |  |
| Amortization of intangible assets | 19,361 |  |
| Deferred taxes | 25,420 |  |
| Provision for inventory excess and obsolescence | 12,640 |  |
| Provision for warranty | 13,793 |  |
| Other | 16,190 |  |
| Net income (adjusted for non-cash charges) | $ | 323,347 |  |

[0000936395-20-000028:mdna:231]
[same as prior period, unchanged from 0000936395-20-000011:mdna:162]

[0000936395-20-000028:mdna:232]
We used $192.4 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-20-000028:mdna:233]
|  | Six Months Ended |
|  | May 2, 2020 |
| Cash provided by accounts receivable | $ | 15,865 |  |
| Cash provided by inventories | 5,618 |  |
| Cash used in prepaid expenses and other | (54,839 | ) |
| Cash used in accounts payable, accruals and other obligations | (151,713 | ) |
| Cash used in deferred revenue | (5,679 | ) |
| Cash used in operating lease assets and liabilities, net | (1,669 | ) |
| Total cash used for working capital | $ | (192,417 | ) |

[0000936395-20-000028:mdna:234]
[same as prior period, unchanged from 0000936395-20-000011:mdna:165]

[0000936395-20-000028:mdna:235]
| • | The $15.9 million of cash provided by accounts receivable during the first six months of fiscal 2020 reflects increased cash collections; |

[0000936395-20-000028:mdna:236]
| • | The $5.6 million of cash provided by inventory during the first six months of fiscal 2020 primarily reflects lower finished goods. During the second quarter of fiscal 2020, we experienced temporary closures of certain third-party facilities, reduced operation levels or capacity, lead time extensions for certain parts and component supply delays within our supply chain as a result of various COVID-19 safety countermeasures implemented globally; |

[0000936395-20-000028:mdna:237]
| • | The $54.8 million of cash used in prepaid expense and other during the first six months of fiscal 2020 primarily reflects increases in upfront future discounts paid to customers and higher non-customer receivables; |

[0000936395-20-000028:mdna:238]
| • | The $151.7 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2020 primarily reflects the timing of payments for bonuses to employees under our annual cash incentive compensation plan and inventory purchases; |

[0000936395-20-000028:mdna:239]
| • | The $5.7 million of cash used in deferred revenue during the first six months of fiscal 2020 represents a decrease in advanced payments received from customers prior to revenue recognition; and |

[0000936395-20-000028:mdna:240]
| • | The $1.7 million of cash used in operating lease assets and liabilities, net, during the first six months of fiscal 2020 represents cash paid for operating leases. For more details, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-20-000028:mdna:241]
Our days sales outstanding (“DSOs”) for the first six months of fiscal 2020 were 81 days, and our inventory turns for the first six months of fiscal 2020 were 4.9. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-20-000028:mdna:242]
44

[0000936395-20-000028:mdna:243]
[same as prior period, unchanged from 0000936395-20-000011:mdna:173]

[0000936395-20-000028:mdna:244]
[same as prior period, unchanged from 0000936395-20-000011:mdna:174]

[0000936395-20-000028:mdna:245]
|  | Six Months Ended |
|  | May 2, 2020 |
| Term Loan due September 28, 2025 (Old) (1) | $ | 6,691 |  |
| Term Loan due September 28, 2025 (New) (2) | 5,241 |  |
| Interest rate swaps(3) | 2,462 |  |
| ABL Credit Facility(4) | 779 |  |
| Finance leases | 2,417 |  |
| Cash paid during period | $ | 17,590 |  |

[0000936395-20-000028:mdna:246]
(1) Interest on the Old 2025 Term Loan was payable periodically based on the interest period selected for borrowing. The Old 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. On January 23, 2020, we refinanced and replaced this term loan with the New 2025 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report for more information.

[0000936395-20-000028:mdna:247]
(2) Interest on the New 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The New 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the second quarter of fiscal 2020, the interest rate on the New 2025 Term Loan was 2.47%.

[0000936395-20-000028:mdna:248]
(3) The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan at 2.957% through September 2023.

[0000936395-20-000028:mdna:249]
(4) During the first six months of fiscal 2020, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.8 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-20-000028:mdna:250]
[same as prior period, unchanged from 0000936395-20-000011:mdna:180]

[0000936395-20-000028:mdna:251]
There have been no material changes to our contractual obligations since November 2, 2019. For a summary of our contractual obligations, see Item 7 of Part II of our 2019 Annual Report.

[0000936395-20-000028:mdna:252]
[same as prior period, unchanged from 0000936395-20-000011:mdna:182]

[0000936395-20-000028:mdna:253]
[same as prior period, unchanged from 0000936395-20-000011:mdna:183]

[0000936395-20-000028:mdna:254]
[same as prior period, unchanged from 0000936395-20-000011:mdna:184]

[0000936395-20-000028:mdna:255]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflected the information available to us regarding the economic implications of the COVID-19 pandemic, expectations as to its impact on our business, and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, as the duration and severity of COVID-19 pandemic are uncertain, certain of our estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000936395-20-000028:mdna:256]
Our critical accounting policies and estimates have not changed materially since November 2, 2019, except for items listed below. For a discussion of our critical accounting policies and estimates, see Item 7 of Part II of our 2019 Annual Report.

[0000936395-20-000028:mdna:257]
[same as prior period, unchanged from 0000936395-20-000011:mdna:187]

[0000936395-20-000028:mdna:258]
[same as prior period, unchanged from 0000936395-20-000011:mdna:188]

[0000936395-20-000028:mdna:259]
[same as prior period, unchanged from 0000936395-20-000011:mdna:189]

[0000936395-20-000028:mdna:260]
[same as prior period, unchanged from 0000936395-20-000011:mdna:190]

[0000936395-20-000028:mdna:261]
46
