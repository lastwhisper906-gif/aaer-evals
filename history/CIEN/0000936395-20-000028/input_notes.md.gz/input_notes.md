# CIEN notes — 0000936395-20-000028


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-20-000028:notes:1]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”).

[0000936395-20-000028:notes:2]
The preparation of financial statements and related disclosures in conformity with GAAP requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions and estimates reflected the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. The actual results that Ciena experiences may differ materially from such inputs into Ciena’s critical and significant accounting estimates. As the duration and severity of the COVID-19 pandemic are unclear, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility as compared to prior periods. As events continue to evolve, Ciena’s estimates may change materially in future periods.

[0000936395-20-000028:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2019 (the “2019 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years and quarterly periods ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its quarters ended on January 31, April 30, July 31 and October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. References to prior reported periods have been changed to reflect the actual period end dates of May 2, 2020, May 4, 2019, November 2, 2019 and November 3, 2018 for periods reported herein.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-20-000028:notes:4]
[same as prior period, unchanged from 0000936395-20-000011:notes:2]

[0000936395-20-000028:notes:5]
[same as prior period, unchanged from 0000936395-20-000011:notes:3]

[0000936395-20-000028:notes:6]
[same as prior period, unchanged from 0000936395-20-000011:notes:4]

[0000936395-20-000028:notes:7]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification ASC 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 3, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

[0000936395-20-000028:notes:8]
Ciena adopted the guidance on a modified retrospective basis as of November 3, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient for disclosure, Ciena has elected not to separate lease and non-lease components on operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass through operating expenses like common area maintenance and utilities.

[0000936395-20-000028:notes:9]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

[0000936395-20-000028:notes:10]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of November 2, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.

[0000936395-20-000028:notes:11]
[same as prior period, unchanged from 0000936395-20-000011:notes:10]

[0000936395-20-000028:notes:12]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in thousands):

[0000936395-20-000028:notes:13]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

[0000936395-20-000028:notes:14]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets.

[0000936395-20-000028:notes:15]
(2) Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets.

[0000936395-20-000028:notes:16]
(3) Represents $20.5 million of lease liabilities for operating leases.

[0000936395-20-000028:notes:17]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets.

[0000936395-20-000028:notes:18]
(5) Represents $55.6 million of lease liabilities for operating leases.

[0000936395-20-000028:notes:19]
[same as prior period, unchanged from 0000936395-20-000011:notes:18]

[0000936395-20-000028:notes:20]
[same as prior period, unchanged from 0000936395-20-000011:notes:19]

[0000936395-20-000028:notes:21]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-20-000028:notes:22]
[same as prior period, unchanged from 0000936395-20-000011:notes:21]

[0000936395-20-000028:notes:23]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-20-000028:notes:24]
[same as prior period, unchanged from 0000936395-20-000011:notes:23]

[0000936395-20-000028:notes:25]
[same as prior period, unchanged from 0000936395-20-000011:notes:24]

[0000936395-20-000028:notes:26]
[same as prior period, unchanged from 0000936395-20-000011:notes:25]

[0000936395-20-000028:notes:27]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Packet Networking | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

[0000936395-20-000028:notes:28]
|  | Quarter Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 11,101 |  |  | $ | 3,047 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 24,128 |  |  | 9,426 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

[0000936395-20-000028:notes:29]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Packet Networking | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,518 |  |  | $ | 30,092 |  |  | $ | 8,482 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,518 |  |  | $ | 96,873 |  |  | $ | 30,483 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

[0000936395-20-000028:notes:30]
|  | Six Months Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 27,145 |  |  | $ | 9,275 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 49,682 |  |  | 18,172 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

[0000936395-20-000028:notes:31]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.

[0000936395-20-000028:notes:32]
[same as prior period, unchanged from 0000936395-20-000011:notes:29]

[0000936395-20-000028:notes:33]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 650,381 |  |  | $ | 615,492 |  |  | $ | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |

[0000936395-20-000028:notes:34]
[same as prior period, unchanged from 0000936395-20-000011:notes:31]

[0000936395-20-000028:notes:35]
[same as prior period, unchanged from 0000936395-20-000011:notes:32]

[0000936395-20-000028:notes:36]
[same as prior period, unchanged from 0000936395-20-000011:notes:33]

[0000936395-20-000028:notes:37]
[same as prior period, unchanged from 0000936395-20-000011:notes:34]

[0000936395-20-000028:notes:38]
[same as prior period, unchanged from 0000936395-20-000011:notes:35]

[0000936395-20-000028:notes:39]
[same as prior period, unchanged from 0000936395-20-000011:notes:36]

[0000936395-20-000028:notes:40]
[same as prior period, unchanged from 0000936395-20-000011:notes:37]

[0000936395-20-000028:notes:41]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service. |

[0000936395-20-000028:notes:42]
[same as prior period, unchanged from 0000936395-20-000011:notes:40]

[0000936395-20-000028:notes:43]
[same as prior period, unchanged from 0000936395-20-000011:notes:41]

[0000936395-20-000028:notes:44]
|  |  | Balance at May 2, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 693,963 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 87,746 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 149,917 |  |  | $ | 156,873 |  |

[0000936395-20-000028:notes:45]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets.

[0000936395-20-000028:notes:46]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $76.5 million and $73.0 million of revenue during the first six months of fiscal 2020 and 2019 that was included in the deferred revenue balance at November 2, 2019 and November 3, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 2, 2020 and May 4, 2019.

[0000936395-20-000028:notes:47]
[same as prior period, unchanged from 0000936395-20-000011:notes:45]

[0000936395-20-000028:notes:48]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.3 million and $15.7 million as of May 2, 2020 and November 2, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $10.1 million and $8.4 million during the first six months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.

[0000936395-20-000028:notes:49]
[same as prior period, unchanged from 0000936395-20-000011:notes:47]

[0000936395-20-000028:notes:50]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 2, 2020, the aggregate amount of RPO was $1.078 billion. As of May 2, 2020, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-20-000028:notes:51]
[same as prior period, unchanged from 0000936395-20-000011:notes:49]

[0000936395-20-000028:notes:52]
[same as prior period, unchanged from 0000936395-20-000011:notes:50]

[0000936395-20-000028:notes:53]
[same as prior period, unchanged from 0000936395-20-000011:notes:51]

[0000936395-20-000028:notes:54]
During the first six months of fiscal 2020, Ciena incurred approximately $0.7 million of acquisition-related costs associated with this transaction. These costs primarily reflect fees associated with financial, legal and accounting advisors.

[0000936395-20-000028:notes:55]
[same as prior period, unchanged from 0000936395-20-000011:notes:53]

[0000936395-20-000028:notes:56]
[same as prior period, unchanged from 0000936395-20-000011:notes:54]

[0000936395-20-000028:notes:57]
[same as prior period, unchanged from 0000936395-20-000011:notes:55]

[0000936395-20-000028:notes:58]
[same as prior period, unchanged from 0000936395-20-000011:notes:56]

[0000936395-20-000028:notes:59]
[same as prior period, unchanged from 0000936395-20-000011:notes:57]

[0000936395-20-000028:notes:60]
[same as prior period, unchanged from 0000936395-20-000011:notes:58]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-20-000028:notes:61]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets, for the six months ended May 2, 2020 (in thousands):

[0000936395-20-000028:notes:62]
|  | Workforcereduction |  | Consolidationof excessfacilities and other restructuring activities |  | Total |
| Balance at November 2, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 4,426 |  | (1) | 3,857 |  | (2) | 8,283 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160 | ) | (3) | (11,160 | ) |
| Cash payments | (5,982 | ) |  | (3,857 | ) |  | (9,839 | ) |
| Balance at May 2, 2020 | $ | 2,427 |  |  | $ | — |  |  | $ | 2,427 |  |
| Current restructuring liabilities | $ | 2,427 |  |  | $ | — |  |  | $ | 2,427 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-20-000028:notes:63]
(1) Reflects a global workforce reduction of 86 employees during the six months ended May 2, 2020 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-20-000028:notes:64]
(2) Primarily represents variable costs and imputed interest expense related to restructured facilities.

[0000936395-20-000028:notes:65]
(3) Represents restructuring reserve liability recognized as a reduction to Operating right-of-use assets, net in relation to adoption of ASC 842. See Notes 2 and 15 for further discussion.

[0000936395-20-000028:notes:66]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets for the six months ended May 4, 2019 (in thousands):

[0000936395-20-000028:notes:67]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at November 3, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Charges | 5,661 |  | (1) | 680 |  | (2) | 6,341 |  |
| Cash payments | (6,667 | ) |  | (847 | ) |  | (7,514 | ) |
| Balance at May 4, 2019 | $ | 1,102 |  |  | $ | 1,572 |  |  | $ | 2,674 |  |
| Current restructuring liabilities | $ | 1,102 |  |  | $ | 347 |  |  | $ | 1,449 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,225 |  |  | $ | 1,225 |  |

[0000936395-20-000028:notes:68]
(1) Reflects a global workforce reduction of approximately 95 employees during the six months ended May 4, 2019 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.
(2) Reflects unfavorable lease commitments in connection with a portion of the facilities for certain locations in the United States and India where Ciena has vacated unused space.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-20-000028:notes:69]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, are as follows (in thousands):

[0000936395-20-000028:notes:70]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Interest income | $ | 2,023 |  |  | $ | 3,519 |  |  | $ | 5,413 |  |  | $ | 7,391 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 1,086 |  |  | (898 | ) |  | 1,723 |  |  | (877 | ) |
| Foreign currency exchange losses | (4,067 | ) |  | (2,995 | ) |  | (4,839 | ) |  | (2,212 | ) |
| Other | (1,707 | ) |  | 130 |  |  | (1,316 | ) |  | (293 | ) |
| Interest and other income (loss), net | $ | (2,665 | ) |  | $ | (244 | ) |  | $ | 981 |  |  | $ | 4,009 |  |

[0000936395-20-000028:notes:71]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $4.8 million and $2.2 million in foreign currency exchange rate losses during the first six months of fiscal 2020 and 2019, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. See Note 13 for further discussion. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2020, Ciena recorded gains of $1.7 million from non-hedge designated foreign currency forward contracts. During the first six months of fiscal 2019, Ciena recorded losses of $0.9 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-20-000028:notes:72]
[same as prior period, unchanged from 0000936395-20-000011:notes:72]

[0000936395-20-000028:notes:73]
On December 2, 2019, the U.S. Department of the Treasury released final regulations and proposed regulations under Section 59A of the Internal Revenue Code, the Base Erosion and Anti-Abuse Tax (“BEAT”). BEAT, which requires certain U.S. corporations to pay a minimum tax associated with deductible payments to non-U.S. related parties, was enacted as part of the Tax Cuts and Jobs Act (the “Tax Act”). Also, on December 2, 2019, the U.S. Department of the Treasury released final regulations that provide additional guidance with respect to the foreign tax credit regime under the Tax Act.

[0000936395-20-000028:notes:74]
The effective tax rate for the second quarter and six months ended May 2, 2020 was lower than the effective tax rate for the second quarter and six months ended May 4, 2019, primarily due to reduced BEAT and the effect of the final regulations released on December 2, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-20-000028:notes:75]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-20-000028:notes:76]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-20-000028:notes:77]
|  | May 2, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |

[0000936395-20-000028:notes:78]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

[0000936395-20-000028:notes:79]
The following table summarizes the final legal maturities of debt investments at May 2, 2020 (in thousands):

[0000936395-20-000028:notes:80]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 100,116 |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 100,742 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-20-000028:notes:81]
[same as prior period, unchanged from 0000936395-20-000011:notes:81]

[0000936395-20-000028:notes:82]
[same as prior period, unchanged from 0000936395-20-000011:notes:82]

[0000936395-20-000028:notes:83]
|  | May 2, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 699,957 |  |  | $ | — |  |  | $ | — |  |  | $ | 699,957 |  |
| Bond mutual fund | 50,165 |  |  | — |  |  | — |  |  | 50,165 |  |
| Deferred compensation plan assets | 6,428 |  |  | — |  |  | — |  |  | 6,428 |  |
| U.S. government obligations | — |  |  | 100,742 |  |  | — |  |  | 100,742 |  |
| Foreign currency forward contracts | — |  |  | 345 |  |  | — |  |  | 345 |  |
| Total assets measured at fair value | $ | 756,550 |  |  | $ | 101,087 |  |  | $ | — |  |  | $ | 857,637 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 9,747 |  |  | $ | — |  |  | $ | 9,747 |  |
| Forward starting interest rate swaps | — |  |  | 32,665 |  |  | — |  |  | 32,665 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 42,412 |  |  | $ | 3,705 |  |  | $ | 46,117 |  |

[0000936395-20-000028:notes:84]
|  | November 2, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Deferred compensation plan assets | 4,974 |  |  |  |  |  |  | 4,974 |  |
| U.S. government obligations | — |  |  | 119,954 |  |  | — |  |  | 119,954 |  |
| Foreign currency forward contracts | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Total assets measured at fair value | $ | 764,088 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 885,612 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Forward starting interest rate swaps | — |  |  | 21,093 |  |  | — |  |  | 21,093 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000028:notes:85]
[same as prior period, unchanged from 0000936395-20-000011:notes:85]

[0000936395-20-000028:notes:86]
|  | May 2, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 750,122 |  |  | $ | — |  |  | $ | — |  |  | $ | 750,122 |  |
| Short-term investments | — |  |  | 100,742 |  |  | — |  |  | 100,742 |  |
| Prepaid expenses and other | — |  |  | 345 |  |  | — |  |  | 345 |  |
| Other long-term assets | 6,428 |  |  | — |  |  | — |  |  | 6,428 |  |
| Total assets measured at fair value | $ | 756,550 |  |  | $ | 101,087 |  |  | $ | — |  |  | $ | 857,637 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 9,747 |  |  | $ | 3,705 |  |  | $ | 13,452 |  |
| Other long-term obligations | — |  |  | 32,665 |  |  | — |  |  | 32,665 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 42,412 |  |  | $ | 3,705 |  |  | $ | 46,117 |  |

[0000936395-20-000028:notes:87]
|  | November 2, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Short-term investments | — |  |  | 109,940 |  |  | — |  |  | 109,940 |  |
| Prepaid expenses and other | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Long-term investments | — |  |  | 10,014 |  |  | — |  |  | 10,014 |  |
| Other long-term assets | 4,974 |  |  | — |  |  | — |  |  | 4,974 |  |
| Total assets measured at fair value | $ | 764,088 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 885,612 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Other long-term obligations | — |  |  | 21,093 |  |  | 3,705 |  |  | 24,798 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000028:notes:88]
[same as prior period, unchanged from 0000936395-20-000011:notes:88]

[0000936395-20-000028:notes:89]
Ciena’s Level 3 liability includes $3.7 million in accrued liabilities and other short-term obligations as of May 2, 2020. This reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver Holdings, LLC (“DonRiver”) in the fourth quarter of fiscal 2018. As of May 2, 2020, there was no material change to the fair value.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-20-000028:notes:90]
[same as prior period, unchanged from 0000936395-20-000011:notes:90]

[0000936395-20-000028:notes:91]
|  | May 2, 2020 |  | November 2, 2019 |
| Raw materials | $ | 106,193 |  |  | $ | 99,041 |  |
| Work-in-process | 11,471 |  |  | 13,657 |  |
| Finished goods | 194,532 |  |  | 226,622 |  |
| Deferred cost of goods sold | 56,904 |  |  | 53,051 |  |
| Gross inventories | 369,100 |  |  | 392,371 |  |
| Provision for excess and obsolescence | (43,347 | ) |  | (47,322 | ) |
| Inventories, net | $ | 325,753 |  |  | $ | 345,049 |  |

[0000936395-20-000028:notes:92]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first six months of fiscal 2020, Ciena recorded a provision for excess and obsolescence of $12.6 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-20-000028:notes:93]
[same as prior period, unchanged from 0000936395-20-000011:notes:93]

[0000936395-20-000028:notes:94]
|  | May 2, 2020 |  | November 2, 2019 |
| Contract assets for unbilled accounts receivable | $ | 87,746 |  |  | $ | 84,046 |  |
| Prepaid VAT and other taxes | 78,275 |  |  | 84,706 |  |
| Prepaid expenses | 65,127 |  |  | 48,680 |  |
| Other non-trade receivables | 54,269 |  |  | 28,136 |  |
| Product demonstration equipment, net | 36,212 |  |  | 38,900 |  |
| Capitalized contract acquisition costs | 9,424 |  |  | 11,677 |  |
| Deferred deployment expense | 623 |  |  | 125 |  |
| Derivative assets | 345 |  |  | 1,570 |  |
| Restricted cash | — |  |  | 74 |  |
|  | $ | 332,021 |  |  | $ | 297,914 |  |

[0000936395-20-000028:notes:95]
Depreciation of product demonstration equipment was $4.2 million and $4.3 million during the first six months of fiscal 2020 and 2019, respectively.

[0000936395-20-000028:notes:96]
[same as prior period, unchanged from 0000936395-20-000011:notes:96]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-20-000028:notes:97]
[same as prior period, unchanged from 0000936395-20-000011:notes:97]

[0000936395-20-000028:notes:98]
|  | May 2, 2020 |  | November 2, 2019 |
| Compensation, payroll related tax and benefits (1) | $ | 96,195 |  |  | $ | 182,363 |  |
| Warranty | 51,863 |  |  | 48,498 |  |
| Vacation | 23,363 |  |  | 22,290 |  |
| Foreign currency forward contracts | 9,747 |  |  | 35 |  |
| Contingent consideration | 3,705 |  |  | 4,372 |  |
| Contingent compensation | 3,420 |  |  | — |  |
| Finance lease obligations | 2,585 |  |  | 2,764 |  |
| Interest payable | 808 |  |  | 1,007 |  |
| Other | 97,087 |  |  | 121,411 |  |
|  | $ | 288,773 |  |  | $ | 382,740 |  |

[0000936395-20-000028:notes:99]
(1) Reduction is primarily due to the timing of bonus payments to employees under Ciena’s annual cash incentive compensation plan.

[0000936395-20-000028:notes:100]
[same as prior period, unchanged from 0000936395-20-000011:notes:100]

[0000936395-20-000028:notes:101]
|  |  | Beginning Balance |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Six Months Ended May 4, 2019 |  | $ | 44,740 |  |  | 9,276 |  |  | (9,109 | ) |  | $ | 44,907 |  |
| Six Months Ended May 2, 2020 |  | $ | 48,498 |  |  | 13,793 |  |  | (10,428 | ) |  | $ | 51,863 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-20-000028:notes:102]
[same as prior period, unchanged from 0000936395-20-000011:notes:102]

[0000936395-20-000028:notes:103]
[same as prior period, unchanged from 0000936395-20-000011:notes:103]

[0000936395-20-000028:notes:104]
As of May 2, 2020 and November 2, 2019, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar- and Indian Rupee-denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $162.9 million and $197.4 million as of May 2, 2020 and November 2, 2019, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-20-000028:notes:105]
As of May 2, 2020 and November 2, 2019, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $202.0 million and $206.0 million as of May 2, 2020 and November 2, 2019, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-20-000028:notes:106]
[same as prior period, unchanged from 0000936395-20-000011:notes:106]

[0000936395-20-000028:notes:107]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of May 2, 2020 and November 2, 2019.

[0000936395-20-000028:notes:108]
[same as prior period, unchanged from 0000936395-20-000011:notes:108]

[0000936395-20-000028:notes:109]
[same as prior period, unchanged from 0000936395-20-000011:notes:109]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-20-000028:notes:110]
[same as prior period, unchanged from 0000936395-20-000011:notes:110]

[0000936395-20-000028:notes:111]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended May 2, 2020:

[0000936395-20-000028:notes:112]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 2, 2019 | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686 | ) |  | $ | (9,475 | ) |  | $ | (22,084 | ) |
| Other comprehensive gain (loss) before reclassifications | 310 |  |  | (9,559 | ) |  | (10,932 | ) |  | (21,490 | ) |  | (41,671 | ) |
| Amounts reclassified from AOCI | — |  |  | 1,540 |  |  | 829 |  |  | — |  |  | 2,369 |  |
| Balance at May 2, 2020 | $ | 462 |  |  | $ | (7,094 | ) |  | $ | (23,789 | ) |  | $ | (30,965 | ) |  | $ | (61,386 | ) |

[0000936395-20-000028:notes:113]
The following table summarizes the changes in AOCI, net of tax, for the six months ended May 4, 2019:

[0000936395-20-000028:notes:114]
|  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 3, 2018 | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |
| Other comprehensive income (loss) before reclassifications | 413 |  |  | (1,613 | ) |  | (10,013 | ) |  | (3,846 | ) |  | (15,059 | ) |
| Amounts reclassified from AOCI | — |  |  | 2,317 |  |  | (684 | ) |  | — |  |  | 1,633 |  |
| Balance at May 4, 2019 | $ | (12 | ) |  | $ | (2,356 | ) |  | $ | (4,280 | ) |  | $ | (12,558 | ) |  | $ | (19,206 | ) |

[0000936395-20-000028:notes:115]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net, on the Condensed Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-20-000028:notes:116]
[same as prior period, unchanged from 0000936395-20-000011:notes:116]

[0000936395-20-000028:notes:117]
[same as prior period, unchanged from 0000936395-20-000011:notes:117]

[0000936395-20-000028:notes:118]
As discussed in Note 2, the restructuring reserve liability related to Ciena’s subleased space and vacated space for which subleases are being pursued was $11.1 million as of November 2, 2019. Upon Ciena’s adoption of ASC 842 on November 3, 2019, the existing Accrued liabilities and other short-term obligations and Other long-term obligations were reclassified as a reduction of the Operating right-of-use assets recorded in accordance with the updated guidance.

[0000936395-20-000028:notes:119]
[same as prior period, unchanged from 0000936395-20-000011:notes:119]

[0000936395-20-000028:notes:120]
|  | Classification |  | As of May 2, 2020 |
| Operating leases: |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 47,864 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 69,196 |  |
| Finance leases: |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 66,931 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (14,734 | ) |
| Buildings, net |  |  | $ | 52,197 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 62,152 |  |

[0000936395-20-000028:notes:121]
[same as prior period, unchanged from 0000936395-20-000011:notes:121]

[0000936395-20-000028:notes:122]
|  |  |  | Quarter Ended | Six Months Ended |
|  | Classification |  | May 2, 2020 | May 2, 2020 |
| Operating lease costs | Operating expense |  | $ | 4,744 |  | $ | 9,201 |  |
| Finance lease cost: |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 1,093 |  | 2,233 |  |
| Interest on finance lease liabilities | Interest expense |  | 1,168 |  | 2,412 |  |
| Total finance lease cost |  |  | 2,261 |  | 4,645 |  |
| Non-capitalized lease cost | Operating expense |  | 707 |  | 1,328 |  |
| Variable lease cost(1) | Operating expense |  | 1,324 |  | 2,635 |  |
| Net lease cost(2) |  |  | $ | 9,036 |  | $ | 17,809 |  |

[0000936395-20-000028:notes:123]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-20-000028:notes:124]
(2) Excludes other operating expense of $2.2 million and $6.5 million for the quarter and six months ended May 2, 2020, respectively, related to amortization of leasehold improvements.

[0000936395-20-000028:notes:125]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of May 2, 2020 were as follows:

[0000936395-20-000028:notes:126]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remaining fiscal 2020 | $ | 10,052 |  |  | $ | 7,039 |  |  | $ | 17,091 |  |
| 2021 | 18,592 |  |  | 7,089 |  |  | 25,681 |  |
| 2022 | 14,030 |  |  | 7,524 |  |  | 21,554 |  |
| 2023 | 10,867 |  |  | 7,524 |  |  | 18,391 |  |
| 2024 | 8,805 |  |  | 7,584 |  |  | 16,389 |  |
| Thereafter | 12,464 |  |  | 58,786 |  |  | 71,250 |  |
| Total lease payments | 74,810 |  |  | 95,546 |  |  | 170,356 |  |
| Less: Imputed interest | (5,614 | ) |  | (33,394 | ) |  | (39,008 | ) |
| Present value of lease liabilities | 69,196 |  |  | 62,152 |  |  | 131,348 |  |
| Less: Current portion of present value of minimum lease payments | (18,096 | ) |  | (2,585 | ) |  | (20,681 | ) |
| Long-term portion of present value of minimum lease payments | $ | 51,100 |  |  | $ | 59,567 |  |  | $ | 110,667 |  |

[0000936395-20-000028:notes:127]
As of May 2, 2020, the weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows:

[0000936395-20-000028:notes:128]
| Weighted-average remaining lease term in years: |  |
| Operating leases | 4.79 |  |
| Finance leases | 12.22 |  |
| Weighted-average discount rates: |  |
| Operating leases | 3.12 | % |
| Finance leases | 7.56 | % |

[0000936395-20-000028:notes:129]
As of November 2, 2019, minimum aggregate rentals under operating leases were as follows:

[0000936395-20-000028:notes:130]
[same as prior period, unchanged from 0000936395-20-000011:notes:132]

[0000936395-20-000028:notes:131]
(1) The amount for operating lease commitments above include estimated variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-20-000028:notes:132]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-20-000028:notes:133]
New 2025 Term Loan

[0000936395-20-000028:notes:134]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”) and incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”).

[0000936395-20-000028:notes:135]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-20-000028:notes:136]
|  |  | May 2, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 691,268 |  |  | $ | (1,742 | ) |  | $ | (3,240 | ) |  | $ | 686,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

[0000936395-20-000028:notes:137]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.2 million at May 2, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.3 million during the first six months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.

[0000936395-20-000028:notes:138]
As of May 2, 2020, the estimated fair value of the New 2025 Term Loan was $677.4 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-20-000028:notes:139]
[same as prior period, unchanged from 0000936395-20-000011:notes:150]

[0000936395-20-000028:notes:140]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
| Numerator | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Net income used to calculate Basic and Diluted EPS | $ | 91,655 |  |  | $ | 52,738 |  |  | $ | 153,983 |  |  | $ | 86,354 |  |

[0000936395-20-000028:notes:141]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
| Denominator | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Basic weighted average shares outstanding | 153,858 |  |  | 156,170 |  |  | 154,099 |  |  | 156,244 |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 1,283 |  |  | 2,119 |  |  | 1,344 |  |  | 1,967 |  |
| Dilutive weighted average shares outstanding | 155,141 |  |  | 158,289 |  |  | 155,443 |  |  | 158,211 |  |

[0000936395-20-000028:notes:142]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
| EPS | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Basic EPS | $ | 0.60 |  |  | $ | 0.34 |  |  | $ | 1.00 |  |  | $ | 0.55 |  |
| Diluted EPS | $ | 0.59 |  |  | $ | 0.33 |  |  | $ | 0.99 |  |  | $ | 0.55 |  |

[0000936395-20-000028:notes:143]
[same as prior period, unchanged from 0000936395-20-000011:notes:154]

[0000936395-20-000028:notes:144]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Shares underlying stock options and stock unit awards | 203 |  |  | 283 |  |  | 467 |  |  | 257 |  |
| Total shares excluded due to anti-dilutive effect | 203 |  |  | 283 |  |  | 467 |  |  | 257 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-20-000028:notes:145]
[same as prior period, unchanged from 0000936395-20-000011:notes:156]

[0000936395-20-000028:notes:146]
[same as prior period, unchanged from 0000936395-20-000011:notes:157]

[0000936395-20-000028:notes:147]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. The program may be modified, suspended, or discontinued at any time. Due to the continued uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, Ciena considered it prudent to temporarily suspend purchases of our common stock under our stock repurchase program effective as of March 17, 2020. The reinstatement of the program and the amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions.

[0000936395-20-000028:notes:148]
[same as prior period, unchanged from 0000936395-20-000011:notes:159]

[0000936395-20-000028:notes:149]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at November 2, 2019 | 3,838,466 |  |  | $ | 39.10 |  |  | $ | 150,076 |  |
| Repurchase of common stock under the stock repurchase program | 1,872,446 |  |  | 39.81 |  |  | 74,535 |  |
| Cumulative balance at May 2, 2020 | 5,710,912 |  |  | $ | 39.33 |  |  | $ | 224,611 |  |

[0000936395-20-000028:notes:150]
[same as prior period, unchanged from 0000936395-20-000011:notes:161]

[0000936395-20-000028:notes:151]
[same as prior period, unchanged from 0000936395-20-000011:notes:162]

[0000936395-20-000028:notes:152]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $18.2 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2020 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-20-000028:notes:153]
[same as prior period, unchanged from 0000936395-20-000011:notes:164]

[0000936395-20-000028:notes:154]
At Ciena’s 2020 Annual Meeting of Stockholders on April 2, 2020, Ciena’s stockholders approved an amendment to Ciena's 2017 Omnibus Incentive Plan (the “2017 Plan”) to increase the number of shares available for issuance thereunder by 12.2 million shares, which became effective as of such date. As of May 2, 2020, the total number of shares authorized for issuance under the 2017 Plan is 21.1 million and approximately 14.9 million shares remained available for issuance thereunder.

[0000936395-20-000028:notes:155]
[same as prior period, unchanged from 0000936395-20-000011:notes:165]

[0000936395-20-000028:notes:156]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Product costs | $ | 827 |  |  | $ | 702 |  |  | $ | 1,498 |  |  | $ | 1,339 |  |
| Service costs | 1,036 |  |  | 907 |  |  | 1,878 |  |  | 1,677 |  |
| Share-based compensation expense included in cost of goods sold | 1,863 |  |  | 1,609 |  |  | 3,376 |  |  | 3,016 |  |
| Research and development | 4,822 |  |  | 4,083 |  |  | 8,671 |  |  | 7,474 |  |
| Sales and marketing | 5,264 |  |  | 4,346 |  |  | 9,877 |  |  | 8,131 |  |
| General and administrative | 5,975 |  |  | 5,491 |  |  | 11,502 |  |  | 10,603 |  |
| Share-based compensation expense included in operating expense | 16,061 |  |  | 13,920 |  |  | 30,050 |  |  | 26,208 |  |
| Share-based compensation expense capitalized in inventory, net | 53 |  |  | 78 |  |  | 153 |  |  | 138 |  |
| Total share-based compensation | $ | 17,977 |  |  | $ | 15,607 |  |  | $ | 33,579 |  |  | $ | 29,362 |  |

[0000936395-20-000028:notes:157]
As of May 2, 2020, total unrecognized share-based compensation expense was approximately $135.1 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-20-000028:notes:158]
[same as prior period, unchanged from 0000936395-20-000011:notes:168]

[0000936395-20-000028:notes:159]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. During fiscal 2019, Ciena separated its previous Software and Software-Related Services segment into two stand-alone operating segments. Because Ciena previously disclosed its Platform Software and Services and Blue Planet Automation Software and Services as distinct product lines in its presentation of segment revenue for Software and Software-Related Services, there is no significant change to the presentation of segment revenues as a result of this separation. Comparative periods have been retrospectively adjusted to disclose segment profit for Platform Software and Services and Blue Planet Automation Software and Services. See Note 3 to Ciena’s Condensed Consolidated Financial Statements.

[0000936395-20-000028:notes:160]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of May 2, 2020, equipment, building, furniture and fixtures, net, totaled $260.9 million, and operating right-of-use assets totaled $47.9 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of May 2, 2020, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-20-000028:notes:161]
|  | May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 15,586 |  |  | $ | — |  |  | $ | 99,950 |  |  | $ | — |  |  | $ | 115,536 |  |
| Goodwill | $ | 65,029 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 310,269 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 58,476 |  |  | $ | 58,476 |  |

[0000936395-20-000028:notes:162]
[same as prior period, unchanged from 0000936395-20-000011:notes:171]

[0000936395-20-000028:notes:163]
[same as prior period, unchanged from 0000936395-20-000011:notes:172]

[0000936395-20-000028:notes:164]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | 623,838 |  |  | $ | 1,245,844 |  |  | $ | 1,172,835 |  |
| Packet Networking | 64,167 |  |  | 73,138 |  |  | 131,675 |  |  | 144,707 |  |
| Total Networking Platforms | 718,461 |  |  | 696,976 |  |  | 1,377,519 |  |  | 1,317,542 |  |
| Platform Software and Services | 44,985 |  |  | 35,229 |  |  | 96,873 |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | 15,017 |  |  | 12,473 |  |  | 30,482 |  |  | 27,447 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 71,479 |  |  | 68,788 |  |  | 133,271 |  |  | 130,065 |  |
| Installation and Deployment | 34,242 |  |  | 41,322 |  |  | 69,196 |  |  | 71,944 |  |
| Consulting and Network Design | 9,869 |  |  | 10,223 |  |  | 19,624 |  |  | 19,713 |  |
| Total Global Services | 115,590 |  |  | 120,333 |  |  | 222,091 |  |  | 221,722 |  |
| Consolidated revenue | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |

[0000936395-20-000028:notes:165]
[same as prior period, unchanged from 0000936395-20-000011:notes:174]

[0000936395-20-000028:notes:166]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs; acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision for income taxes.

[0000936395-20-000028:notes:167]
[same as prior period, unchanged from 0000936395-20-000011:notes:177]

[0000936395-20-000028:notes:168]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 210,987 |  |  | $ | 175,191 |  |  | $ | 379,256 |  |  | $ | 311,782 |  |
| Platform Software and Services | 21,668 |  |  | 12,477 |  |  | 50,619 |  |  | 32,940 |  |
| Blue Planet Automation Software and Services | (4,399 | ) |  | (5,941 | ) |  | (7,512 | ) |  | (7,988 | ) |
| Global Services | 53,540 |  |  | 54,981 |  |  | 99,068 |  |  | 94,682 |  |
| Total segment profit | 281,796 |  |  | 236,708 |  |  | 521,431 |  |  | 431,416 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 101,214 |  |  | 103,502 |  |  | 208,280 |  |  | 201,615 |  |
| General and administrative | 42,030 |  |  | 42,154 |  |  | 84,498 |  |  | 81,397 |  |
| Amortization of intangible assets | 5,839 |  |  | 5,529 |  |  | 11,692 |  |  | 11,057 |  |
| Significant asset impairments and restructuring costs | 3,811 |  |  | 4,068 |  |  | 8,283 |  |  | 6,341 |  |
| Acquisition and integration costs | 1,414 |  |  | 1,135 |  |  | 3,233 |  |  | 2,743 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (10,525 | ) |  | (9,715 | ) |  | (15,694 | ) |  | (14,903 | ) |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (646 | ) |  | — |  |
| Less: Provision for income taxes | 25,308 |  |  | 17,867 |  |  | 35,122 |  |  | 27,006 |  |
| Consolidated net income | $ | 91,655 |  |  | $ | 52,738 |  |  | $ | 153,983 |  |  | $ | 86,354 |  |

[0000936395-20-000028:notes:169]
[same as prior period, unchanged from 0000936395-20-000011:notes:179]

[0000936395-20-000028:notes:170]
[same as prior period, unchanged from 0000936395-20-000011:notes:180]

[0000936395-20-000028:notes:171]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Americas |  | 650,381 |  |  | 615,492 |  |  | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |

[0000936395-20-000028:notes:172]
Ciena’s revenue includes $598.4 million and $545.6 million of United States revenue for the second quarter of fiscal 2020 and 2019, respectively. For the six months ended May 2, 2020 and May 4, 2019, United States revenue was $1.1 billion and $1.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-20-000028:notes:173]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating right-of-use assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating right-of-use assets specifically identified. Equipment, building, furniture and fixtures, net, and operating right-of-use assets attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating right-of-use assets was as follows (in thousands):

[0000936395-20-000028:notes:174]
|  | May 2, 2020 |  | November 2, 2019 |
| Canada | $ | 198,334 |  |  | $ | 211,901 |  |
| United States | 75,110 |  |  | 58,119 |  |
| Other International | 35,287 |  |  | 16,864 |  |
| Total | $ | 308,731 |  |  | $ | 286,884 |  |

[0000936395-20-000028:notes:175]
[same as prior period, unchanged from 0000936395-20-000011:notes:185]

[0000936395-20-000028:notes:176]
|  | Quarter Ended |  | Six Months Ended |
|  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| AT&T | $ | 105,630 |  |  | $ | 108,416 |  |  | $ | 189,640 |  |  | $ | 195,125 |  |
| Verizon | n/a |  |  | 106,350 |  |  | 203,630 |  |  | 202,587 |  |
| Web-scale provider | n/a |  |  | n/a |  |  | n/a |  |  | 174,853 |  |
| Total | $ | 105,630 |  |  | $ | 214,766 |  |  | $ | 393,270 |  |  | $ | 572,565 |  |

[0000936395-20-000028:notes:177]
[same as prior period, unchanged from 0000936395-20-000011:notes:187]

[0000936395-20-000028:notes:178]
[same as prior period, unchanged from 0000936395-20-000011:notes:188]


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-20-000028:notes:179]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating right-of-use assets was as follows (in thousands):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-20-000028:notes:180]
COMMITMENTS AND CONTINGENCIES

[0000936395-20-000028:notes:181]
Canadian Grant

[0000936395-20-000028:notes:182]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $40.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 2, 2020, Ciena has recorded CAD$34.5 million (approximately $24.5 million) in cumulative benefits as a reduction in research and development expense of which CAD$5.6 million ($4.2 million) was recorded in the first six months of fiscal 2020. As of May 2, 2020, amounts receivable from this grant were CAD$7.3 million ($5.2 million).

[0000936395-20-000028:notes:183]
Tax Contingencies

[0000936395-20-000028:notes:184]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-20-000028:notes:185]
Litigation

[0000936395-20-000028:notes:186]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.
