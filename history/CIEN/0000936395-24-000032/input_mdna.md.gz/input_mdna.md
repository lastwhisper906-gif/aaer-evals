# CIEN MD&A — 0000936395-24-000032


## mdna

[0000936395-24-000032:mdna:1]
[same as prior period, unchanged from 0000936395-24-000025:mdna:1]

[0000936395-24-000032:mdna:2]
[same as prior period, unchanged from 0000936395-24-000025:mdna:2]

[0000936395-24-000032:mdna:3]
[same as prior period, unchanged from 0000936395-24-000025:mdna:3]

[0000936395-24-000032:mdna:4]
[same as prior period, unchanged from 0000936395-24-000025:mdna:5]

[0000936395-24-000032:mdna:5]
[same as prior period, unchanged from 0000936395-24-000025:mdna:6]

[0000936395-24-000032:mdna:6]
[same as prior period, unchanged from 0000936395-24-000025:mdna:7]

[0000936395-24-000032:mdna:7]
[same as prior period, unchanged from 0000936395-24-000025:mdna:8]

[0000936395-24-000032:mdna:8]
For large portions of fiscal 2021 and fiscal 2022, we received an unprecedented volume of orders for our products and services, which significantly exceeded our revenue and historical order volumes. We believe some portion of these orders reflected customer acceleration of future orders due to long lead times during the constrained supply environment of that period, as well as orders that were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022, and we experienced order levels below revenue during fiscal 2023 and the first half of fiscal 2024, particularly from our communications service provider customers. We believe this was, in part, due to communications service providers in North America working through relatively high levels of inventory previously acquired, which has been made more difficult due to challenges installing and deploying equipment, including site readiness and access to fiber or other resources. In addition, in certain international geographies, we believe that caution driven by macroeconomic concerns and market-specific issues contributed to lower-than-expected order volumes from communications service providers. These dynamics have begun to improve, and order levels relative to revenue increased in the third quarter of fiscal 2024 compared to prior quarters in fiscal 2024, in part due to increased bandwidth demand related to generative AI. We continue to expect that improvements to these dynamics will be gradual and will not be linear. Notwithstanding these near-term impacts, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term drivers of bandwidth demand and long-term opportunities for our business.

[0000936395-24-000032:mdna:9]
[same as prior period, unchanged from 0000936395-24-000025:mdna:10]

[0000936395-24-000032:mdna:10]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and was therefore less predictable and subject to fluctuation. As a result of elevated order volumes during portions of fiscal 2021 and fiscal 2022, however, our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. Accordingly, our revenue in recent fiscal years has been more significantly impacted by factors including availability of supply and customer delivery deferrals, as we converted our existing backlog to revenue. As supply chain conditions have improved, and we have been able to increase shipment volumes and reduce lead times, our backlog decreased to $2.1 billion as of the end of the third quarter of fiscal 2024. As backlog consumption reduces and represents a relatively smaller portion of our quarterly revenue, we expect that our reliance upon securing quarterly book to revenue orders will grow, and that increased orders and a return to a more typical composition of our quarterly revenue will be a critical element of any future revenue growth.

[0000936395-24-000032:mdna:11]
The timing, pace, and degree to which we fulfill our backlog will have a significant impact on our revenue and can be affected by factors outside of our control, including customer readiness and willingness to receive shipment against existing orders. During fiscal 2023 and the first nine months of fiscal 2024, certain customers, including communications service providers and cable and multiservice operators in North America, that had earlier placed significant advanced orders, rescheduled deliveries for a portion of such orders. We believe that this was the result of a number of factors, including the rapid improvement in our delivery lead times as supply chain conditions improved, constraints on customer capital expenditures, and high levels of network equipment inventory held by many of our customers. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period.

[0000936395-24-000032:mdna:12]
27

[0000936395-24-000032:mdna:13]
[same as prior period, unchanged from 0000936395-24-000025:mdna:13]

[0000936395-24-000032:mdna:14]
[same as prior period, unchanged from 0000936395-24-000025:mdna:14]

[0000936395-24-000032:mdna:15]
[same as prior period, unchanged from 0000936395-24-000025:mdna:15]

[0000936395-24-000032:mdna:16]
[same as prior period, unchanged from 0000936395-24-000025:mdna:16]

[0000936395-24-000032:mdna:17]
[same as prior period, unchanged from 0000936395-24-000025:mdna:17]

[0000936395-24-000032:mdna:18]
[same as prior period, unchanged from 0000936395-24-000025:mdna:18]

[0000936395-24-000032:mdna:19]
As a result of the factors impacting order volumes and order delivery timing described under “Overview” above, our revenue declined by 11.8% in the third quarter of fiscal 2024 as compared to the third quarter of fiscal 2023, and 11.2% in the first nine months of fiscal 2024 as compared to the first nine months of fiscal 2023. In addition, during both the third quarter and first nine months of fiscal 2024, approximately 14.4% of our revenue was non-U.S. Dollar-denominated, primarily including sales in Euros, Canadian Dollars, and Indian Rupees. During the third quarter of fiscal 2024 as compared to the third quarter of fiscal 2023, the U.S. Dollar primarily strengthened against these and other currencies. As a result of these currency fluctuations, our revenue reported in U.S. Dollars was adversely impacted by approximately $2.5 million, or 0.3%, as compared to the third quarter of fiscal 2023. During the first nine months of fiscal 2024 as compared to the first nine months of fiscal 2023, the U.S. Dollar fluctuated against these and other currencies, however, there was minimal impact as compared to the first nine months of fiscal 2023.

[0000936395-24-000032:mdna:20]
[same as prior period, unchanged from 0000936395-24-000025:mdna:20]

[0000936395-24-000032:mdna:21]
[same as prior period, unchanged from 0000936395-24-000025:mdna:21]

[0000936395-24-000032:mdna:22]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | 718,997 |  |  |  |  | (15.6) | % |  | $ | 1,862,917 |  |  | $ | 2,239,180 |  |  |  |  | (16.8) | % |
| %** | 64.4 | % |  | 67.3 | % |  |  |  |  |  | 64.4 | % |  | 68.7 | % |  |  |  |  |
| Routing and Switching | 92,692 |  |  | 127,563 |  |  |  |  | (27.3) | % |  | 320,113 |  |  | 377,378 |  |  |  |  | (15.2) | % |
| %** | 9.8 | % |  | 12.0 | % |  |  |  |  |  | 11.1 | % |  | 11.6 | % |  |  |  |  |
| Total Networking Platforms | 699,537 |  |  | 846,560 |  |  |  |  | (17.4) | % |  | 2,183,030 |  |  | 2,616,558 |  |  |  |  | (16.6) | % |
| %** | 74.2 | % |  | 79.3 | % |  |  |  |  |  | 75.5 | % |  | 80.3 | % |  |  |  |  |
| Platform Software and Services | 83,212 |  |  | 78,880 |  |  |  |  | 5.5 | % |  | 258,402 |  |  | 221,768 |  |  |  |  | 16.5 | % |
| %** | 8.9 | % |  | 7.4 | % |  |  |  |  |  | 8.9 | % |  | 6.8 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 25,791 |  |  | 13,167 |  |  |  |  | 95.9 | % |  | 54,167 |  |  | 49,139 |  |  |  |  | 10.2 | % |
| %** | 2.7 | % |  | 1.2 | % |  |  |  |  |  | 1.9 | % |  | 1.5 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 74,344 |  |  | 72,887 |  |  |  |  | 2.0 | % |  | 225,869 |  |  | 213,938 |  |  |  |  | 5.6 | % |
| %** | 7.9 | % |  | 6.8 | % |  |  |  |  |  | 7.8 | % |  | 6.6 | % |  |  |  |  |
| Installation and Deployment | 46,484 |  |  | 46,840 |  |  |  |  | (0.8) | % |  | 132,993 |  |  | 120,901 |  |  |  |  | 10.0 | % |
| %** | 4.9 | % |  | 4.4 | % |  |  |  |  |  | 4.6 | % |  | 3.7 | % |  |  |  |  |
| Consulting and Network Design | 12,940 |  |  | 9,552 |  |  |  |  | 35.5 | % |  | 36,382 |  |  | 34,758 |  |  |  |  | 4.7 | % |
| %** | 1.4 | % |  | 0.9 | % |  |  |  |  |  | 1.3 | % |  | 1.1 | % |  |  |  |  |
| Total Global Services | 133,768 |  |  | 129,279 |  |  |  |  | 3.5 | % |  | 395,244 |  |  | 369,597 |  |  |  |  | 6.9 | % |
| %** | 14.2 | % |  | 12.1 | % |  |  |  |  |  | 13.7 | % |  | 11.4 | % |  |  |  |  |
| Total revenue | $ | 942,308 |  |  | $ | 1,067,886 |  |  |  |  | (11.8) | % |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |  |  |  | (11.2) | % |

[0000936395-24-000032:mdna:23]
[same as prior period, unchanged from 0000936395-24-000025:mdna:23]

[0000936395-24-000032:mdna:24]
[same as prior period, unchanged from 0000936395-24-000025:mdna:24]

[0000936395-24-000032:mdna:25]
[same as prior period, unchanged from 0000936395-24-000025:mdna:25]

[0000936395-24-000032:mdna:26]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:27]
•Networking Platforms segment revenue decreased by $147.0 million, reflecting product line sales decreases of $112.1 million of our Optical Networking products and $34.9 million of our Routing and Switching products.

[0000936395-24-000032:mdna:28]
◦Optical Networking sales decreased, primarily reflecting sales decreases of $110.0 million of our 6500 Packet-Optical Platform, primarily to communications service providers, enterprise customers and cable and multiservice operators, and $59.7 million of our 6500 Reconfigurable Line System (RLS) products, primarily to cloud providers. These sales decreases were partially offset by a sales increase of $41.5 million of our Waveserver® modular interconnect system, primarily to cloud providers and communications service providers. Also partially offsetting the sales decreases were $17.6 million of increased sales primarily of our WaveLogic 5 Nano 100G-400G coherent pluggable transceivers primarily to cloud providers.

[0000936395-24-000032:mdna:29]
◦Routing and Switching sales decreased, primarily reflecting a sales decrease of $53.3 million of our 3000 and 5000 families of service delivery and aggregation switches primarily to communications service providers, cable and multiservice operators and enterprise customers, partially offset by a sales increase of $20.2 million of our virtualization software, primarily to communications service providers.

[0000936395-24-000032:mdna:30]
•Platform Software and Services segment revenue increased by $4.3 million, reflecting sales increases of $2.8 million of our software platforms and $1.5 million in our software maintenance services, both primarily for our Navigator NCS domain controller solution software platform.

[0000936395-24-000032:mdna:31]
•Blue Planet Automation Software and Services segment revenue increased by $12.6 million reflecting sales increases of $8.5 million in software platforms and $4.1 million in professional software services both primarily for our inventory management (“BPI”) and route optimization and analysis (“ROA”) platforms.

[0000936395-24-000032:mdna:32]
•Global Services segment revenue increased by $4.5 million, primarily reflecting sales increases of $3.4 million of our consulting and network design services and $1.5 million of our maintenance support and training.

[0000936395-24-000032:mdna:33]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:34]
•Networking Platforms segment revenue decreased by $433.5 million, reflecting product line sales decreases of $376.2 million of our Optical Networking products and $57.3 million of our Routing and Switching products.

[0000936395-24-000032:mdna:35]
◦Optical Networking sales decreased, primarily reflecting sales decreases of $476.7 million of our 6500

[0000936395-24-000032:mdna:36]
Packet-Optical Platform, primarily to communications service providers, enterprise customers, cable and multiservice operators, and cloud providers, and $16.2 million of our 5400 family of Packet-Optical Platforms, primarily to communications service providers. These sales decreases were partially offset by sales increases of $65.9 million of our Waveserver® products, primarily to cloud providers and communications service providers and $27.0 million of our 6500 RLS products, primarily to enterprise customers and cable and multiservice operators, partially offset by a sales decrease to communications service providers. Also partially offsetting the sales decreases were $25.5 million of increased sales primarily of our WaveLogic 5 Nano 100G-400G coherent pluggable transceivers primarily to cloud providers.

[0000936395-24-000032:mdna:37]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $50.3 million of our 3000 and 5000 families of service delivery and aggregation switches primarily to communications service providers, enterprise customers, and cable and multiservice operators, $14.1 million of our virtualization software, primarily to communications service providers, and $6.6 million of our 8700 Packetwave Platform, primarily to communications service providers. These sales decreases were partially offset by sales increases of $9.0 million of our 8100 Coherent IP networking platforms, primarily to enterprise customers and communications service providers, and $6.4 million of our platform independent software, primarily to communications service providers.

[0000936395-24-000032:mdna:38]
•Platform Software and Services segment revenue increased by $36.6 million, reflecting sales increases of $20.9 million in sales of software platforms and $15.7 million in sales of our software maintenance services, both primarily for our Navigator NCS software platform.

[0000936395-24-000032:mdna:39]
•Blue Planet Automation Software and Services segment revenue increased by $5.0 million, primarily reflecting sales increases of $4.0 million in professional software services primarily for our BPI and ROA platforms and $1.0 million in software platforms.

[0000936395-24-000032:mdna:40]
•Global Services segment revenue increased by $25.6 million, reflecting sales increases of $12.1 million of our installation and deployment services, $11.9 million of our maintenance support and training and $1.6 million of our consulting and network design services.

[0000936395-24-000032:mdna:41]
[same as prior period, unchanged from 0000936395-24-000025:mdna:41]

[0000936395-24-000032:mdna:42]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The decrease in our Americas region revenue for the quarter and nine months ended July 27, 2024 was primarily driven by decreased sales in the United States and Canada. The decrease in our APAC region revenue for the quarter and nine months ended July 27, 2024 was primarily driven by decreased sales in India and Australia. The decrease in our EMEA region revenue for the quarter ended July 27, 2024 was primarily driven by decreased sales in the Netherlands and Great Britain. The increase in our EMEA region revenue for the nine months ended July 27, 2024 was partially offset by sales decreases in Great Britain and France.

[0000936395-24-000032:mdna:43]
[same as prior period, unchanged from 0000936395-24-000025:mdna:43]

[0000936395-24-000032:mdna:44]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Americas | $ | 718,605 |  |  | $ | 749,479 |  |  |  |  | (4.1) | % |  | $ | 2,099,680 |  |  | $ | 2,308,934 |  |  |  |  | (9.1) | % |
| %** | 76.3 | % |  | 70.2 | % |  |  |  |  |  | 72.6 | % |  | 70.9 | % |  |  |  |  |
| EMEA | 135,009 |  |  | 152,834 |  |  |  |  | (11.7) | % |  | 498,212 |  |  | 479,053 |  |  |  |  | 4.0 | % |
| %** | 14.3 | % |  | 14.3 | % |  |  |  |  |  | 17.3 | % |  | 14.7 | % |  |  |  |  |
| APAC | 88,694 |  |  | 165,573 |  |  |  |  | (46.4) | % |  | 292,951 |  |  | 469,075 |  |  |  |  | (37.5) | % |
| %** | 9.4 | % |  | 15.5 | % |  |  |  |  |  | 10.1 | % |  | 14.4 | % |  |  |  |  |
| Total | $ | 942,308 |  |  | $ | 1,067,886 |  |  |  |  | (11.8) | % |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |  |  |  | (11.2) | % |

[0000936395-24-000032:mdna:45]
[same as prior period, unchanged from 0000936395-24-000025:mdna:45]

[0000936395-24-000032:mdna:46]
[same as prior period, unchanged from 0000936395-24-000025:mdna:46]

[0000936395-24-000032:mdna:47]
[same as prior period, unchanged from 0000936395-24-000025:mdna:47]

[0000936395-24-000032:mdna:48]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:49]
•Americas revenue decreased by $30.9 million, primarily reflecting a sales decrease of $41.8 million within our Networking Platforms segment. This sales decrease was offset by sales increases of $4.4 million within our Blue Planet Automation Software and Services segment, $3.4 million within our Global Services segment, and $3.1 million within our Platform Software and Services segment. The decrease within our Networking Platforms segment reflects product line sales decreases of $21.5 million of our Optical Networking products and $20.3 million of our Routing and Switching products. The decrease within our Optical Networking product line was primarily related to sales decreases of $46.5 million of our 6500 Packet-Optical Platform, primarily to communications service providers and cable and multiservice operators, and $37.5 million of our 6500 RLS products, primarily to cloud providers, partially offset by a sales increase of $44.8 million of our Waveserver® modular interconnect system, primarily to cloud providers and communications service providers. Also partially offsetting the sales decreases were $16.7 million of increased sales primarily of our WaveLogic 5 Nano 100G-400G coherent pluggable transceivers primarily to cloud providers. The decrease within our Routing and Switching product line primarily reflects a sales decrease of $40.7 million of our 3000 and 5000 families of service delivery and aggregation switches primarily to communications service providers and enterprise customers, partially offset by a sales increase of $20.2 million of our virtualization software, primarily to communications service providers.

[0000936395-24-000032:mdna:50]
•EMEA revenue decreased by $17.8 million, primarily reflecting a sales decrease of $27.0 million within our Networking Platforms segment, partially offset by a sales increase of $8.5 million within our Blue Planet Software and Services segment. The decrease within our Networking Platforms segment primarily reflects product line sales decreases of $15.9 million of our Routing and Switching products and $11.1 million of our Optical Networking product line. The decrease within our Routing and Switching product line was primarily related to a sales decrease of $14.8 million of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers and cable and multiservice operators. The decrease within our Optical Networking product line was primarily related to a sales decrease of $17.8 million of our 6500 RLS products, primarily to cloud providers, partially offset by a sales increase of $6.2 million of our Waveserver® products, primarily to communications service providers and cloud providers.

[0000936395-24-000032:mdna:51]
•APAC revenue decreased by $76.9 million, primarily reflecting a sales decrease of $78.3 million within our Networking Platforms segment, partially offset by a sales increase of $1.5 million within our Platform Software and Services segment. The decrease within our Networking Platforms segment primarily reflects a product line sales decrease of $79.5 million of Optical Networking products, which primarily reflects sales decreases of $63.6 million of our 6500 Packet-Optical Platform, primarily to enterprise customers and communications service providers and $9.6 million of our Waveserver® products.

[0000936395-24-000032:mdna:52]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:53]
•Americas revenue decreased by $209.3 million, reflecting sales decreases of $245.2 million within our Networking Platforms segment. This sales decrease was offset by sales increases of $25.3 million within our Platform Software and Services segment, $8.7 million within our Global Services segment and $1.9 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue decrease reflects product line sales decreases of $197.6 million of Optical Networking products and $47.6 million of Routing and Switching products. Our Optical Networking revenue primarily reflects a sales decrease of $281.8 million of our 6500 Packet-Optical Platform, primarily to communications service providers, cloud providers and cable and multiservice operators, partially offset by a sales increase of $61.5 million of our Waveserver® modular interconnect system, primarily to communications service providers and cloud providers. Also partially offsetting the sales decrease were $19.9 million of increased sales primarily of our WaveLogic 5 Nano 100G-400G coherent pluggable transceivers primarily to cloud providers and $13.4 million of increased sales of our 6500 RLS products, primarily to enterprise customers and cable and multiservice operators, partially offset by a sales decrease to communications service providers. Routing and Switching product line sales primarily reflect sales decreases of $42.2 million of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers, cable and multiservice operators and enterprise customers and $14.1 million of our virtualization software primarily to communications service providers, partially offset by a sales increase of $8.9 million of our 8100 Coherent IP networking platforms, primarily to enterprise customers and communications service providers.

[0000936395-24-000032:mdna:54]
•EMEA revenue increased by $19.2 million, reflecting sales increases of $13.8 million within our Global Services segment, $4.0 million within our Platform Software and Services segment and $3.2 million within our Blue Planet Automation Software and Services segment. These sales increases were offset by a sales decrease of $1.8 million within our Networking Platforms segment. Our Global Services segment revenue increase primarily reflects sales increases of $7.7 million of our installation and deployment services and $5.3 million of our maintenance support and training.

[0000936395-24-000032:mdna:55]
•APAC revenue decreased by $176.1 million, primarily reflecting a sales decrease of $186.6 million within our Networking Platforms segment. This sales decrease was partially offset by sales increases of $7.3 million within our Platform Software and Services segment and $3.2 million within our Global Services segment. Our Networking Platforms segment revenue decrease primarily reflects a product line sales decrease of $192.8 million of Optical Networking products, including a sales decrease of $171.9 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers.

[0000936395-24-000032:mdna:56]
[same as prior period, unchanged from 0000936395-24-000025:mdna:56]

[0000936395-24-000032:mdna:57]
[same as prior period, unchanged from 0000936395-24-000025:mdna:57]

[0000936395-24-000032:mdna:58]
[same as prior period, unchanged from 0000936395-24-000025:mdna:58]

[0000936395-24-000032:mdna:59]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Total revenue | $ | 942,308 |  |  | $ | 1,067,886 |  |  |  |  | (11.8) | % |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |  |  |  | (11.2) | % |
| Total cost of goods sold | 538,363 |  |  | 618,945 |  |  |  |  | (13.0) | % |  | 1,631,275 |  |  | 1,864,492 |  |  |  |  | (12.5) | % |
| Gross profit | $ | 403,945 |  |  | $ | 448,941 |  |  |  |  | (10.0) | % |  | $ | 1,259,568 |  |  | $ | 1,392,570 |  |  |  |  | (9.6) | % |
| %** | 42.9 | % |  | 42.0 | % |  |  |  |  |  | 43.6 | % |  | 42.8 | % |  |  |  |  |

[0000936395-24-000032:mdna:60]
[same as prior period, unchanged from 0000936395-24-000025:mdna:60]

[0000936395-24-000032:mdna:61]
[same as prior period, unchanged from 0000936395-24-000025:mdna:61]

[0000936395-24-000032:mdna:62]
[same as prior period, unchanged from 0000936395-24-000025:mdna:62]

[0000936395-24-000032:mdna:63]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Product revenue | $ | 729,503 |  |  | $ | 865,197 |  |  |  |  | (15.7) | % |  | $ | 2,266,596 |  |  | $ | 2,678,242 |  |  |  |  | (15.4) | % |
| Product cost of goods sold | 433,533 |  |  | 516,900 |  |  |  |  | (16.1) | % |  | 1,315,737 |  |  | 1,559,120 |  |  |  |  | (15.6) | % |
| Product gross profit | $ | 295,970 |  |  | $ | 348,297 |  |  |  |  | (15.0) | % |  | $ | 950,859 |  |  | $ | 1,119,122 |  |  |  |  | (15.0) | % |
| %** | 40.6 | % |  | 40.3 | % |  |  |  |  |  | 42.0 | % |  | 41.8 | % |  |  |  |  |

[0000936395-24-000032:mdna:64]
[same as prior period, unchanged from 0000936395-24-000025:mdna:64]

[0000936395-24-000032:mdna:65]
[same as prior period, unchanged from 0000936395-24-000025:mdna:65]

[0000936395-24-000032:mdna:66]
[same as prior period, unchanged from 0000936395-24-000025:mdna:66]

[0000936395-24-000032:mdna:67]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Services revenue | $ | 212,805 |  |  | $ | 202,689 |  |  |  |  | 5.0 | % |  | $ | 624,247 |  |  | $ | 578,820 |  |  |  |  | 7.8 | % |
| Services cost of goods sold | 104,830 |  |  | 102,045 |  |  |  |  | 2.7 | % |  | 315,538 |  |  | 305,372 |  |  |  |  | 3.3 | % |
| Services gross profit | $ | 107,975 |  |  | $ | 100,644 |  |  |  |  | 7.3 | % |  | $ | 308,709 |  |  | $ | 273,448 |  |  |  |  | 12.9 | % |
| % ** | 50.7 | % |  | 49.7 | % |  |  |  |  |  | 49.5 | % |  | 47.2 | % |  |  |  |  |

[0000936395-24-000032:mdna:68]
[same as prior period, unchanged from 0000936395-24-000025:mdna:68]

[0000936395-24-000032:mdna:69]
[same as prior period, unchanged from 0000936395-24-000025:mdna:69]

[0000936395-24-000032:mdna:70]
[same as prior period, unchanged from 0000936395-24-000025:mdna:70]

[0000936395-24-000032:mdna:71]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:72]
•Gross profit decreased by $45.0 million. Gross margin increased by 90 basis points, primarily due to product cost reductions, improved manufacturing efficiencies and improved margins on Blue Planet software services, partially offset by higher inventory excess and obsolescence costs and a higher concentration of lower margin “common” equipment and photonic sales.

[0000936395-24-000032:mdna:73]
•Gross profit on products decreased by $52.3 million. Product gross margin slightly increased by 30 basis points, primarily due to product cost reductions and improved manufacturing efficiencies partially offset by higher inventory excess and obsolescence costs and a higher concentration of lower margin product mix, as described above.

[0000936395-24-000032:mdna:74]
•Gross profit on services increased by $7.3 million. Gross margin increased by 100 basis points, primarily due to improved margins on Blue Planet software services due to improved efficiencies on delivery, partially offset by lower margins on maintenance support and training.

[0000936395-24-000032:mdna:75]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:76]
•Gross profit decreased by $133.0 million. Gross margin increased by 80 basis points, primarily due to product cost reductions, improved manufacturing efficiencies and improved margins on Blue Planet software services, partially offset by higher inventory excess and obsolescence costs and a higher concentration of lower margin “common” equipment and photonic sales.

[0000936395-24-000032:mdna:77]
•Gross profit on products decreased by $168.3 million. Product gross margin slightly increased by 20 basis points, primarily due to product cost reductions and improved manufacturing efficiencies partially offset by higher inventory excess and obsolescence costs and a higher concentration of lower margin product mix, as described above.

[0000936395-24-000032:mdna:78]
•Gross profit on services increased by $35.3 million. Services gross margin increased by 230 basis points, primarily due to improved margins on Blue Planet software services due to improved efficiencies on delivery, partially offset by lower margins on maintenance support and training.

[0000936395-24-000032:mdna:79]
[same as prior period, unchanged from 0000936395-24-000025:mdna:79]

[0000936395-24-000032:mdna:80]
[same as prior period, unchanged from 0000936395-24-000025:mdna:80]

[0000936395-24-000032:mdna:81]
Approximately 47.7% and 48.7% of our operating expense was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2024, respectively, primarily including expenses in Canadian Dollars, Indian Rupees, and Euros. During the third quarter of fiscal 2024, as compared to the third quarter of fiscal 2023, the U.S. Dollar strengthened against these and other currencies. As a result of these currency fluctuations, our operating expense, net of hedging, reported in U.S. Dollars, slightly decreased by approximately $1.5 million, or 0.4%, as compared to the third quarter of fiscal 2023. During the first nine months of fiscal 2024 as compared to the first nine months of fiscal 2023 the U.S. Dollar primarily strengthened against these and other currencies, however, net of hedging, there was minimal impact as compared to the first nine months of fiscal 2023.

[0000936395-24-000032:mdna:82]
Operating Segment Revenue

[0000936395-24-000032:mdna:83]
[same as prior period, unchanged from 0000936395-24-000025:mdna:82]

[0000936395-24-000032:mdna:84]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Research and development | $ | 188,888 |  |  | $ | 189,392 |  |  |  |  | (0.3) | % |  | $ | 571,537 |  |  | $ | 561,115 |  |  |  |  | 1.9 | % |
| %** | 20.0 | % |  | 17.7 | % |  |  |  |  |  | 19.8 | % |  | 17.2 | % |  |  |  |  |
| Selling and marketing | 121,520 |  |  | 118,266 |  |  |  |  | 2.8 | % |  | 373,749 |  |  | 367,156 |  |  |  |  | 1.8 | % |
| %** | 12.9 | % |  | 11.1 | % |  |  |  |  |  | 12.9 | % |  | 11.4 | % |  |  |  |  |
| General and administrative | 58,248 |  |  | 49,349 |  |  |  |  | 18.0 | % |  | 162,504 |  |  | 151,184 |  |  |  |  | 7.5 | % |
| %** | 6.2 | % |  | 4.6 | % |  |  |  |  |  | 5.6 | % |  | 4.6 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,361 |  |  | 4,174 |  |  |  |  | (67.4) | % |  | 21,987 |  |  | 16,625 |  |  |  |  | 32.3 | % |
| %** | 0.1 | % |  | 0.4 | % |  |  |  |  |  | 0.8 | % |  | 0.5 | % |  |  |  |  |
| Amortization of intangible assets | 7,185 |  |  | 9,487 |  |  |  |  | (24.3) | % |  | 22,384 |  |  | 26,773 |  |  |  |  | (16.4) | % |
| %** | 0.8 | % |  | 0.9 | % |  |  |  |  |  | 0.8 | % |  | 0.8 | % |  |  |  |  |
| Acquisition and integration costs | — |  |  | 59 |  |  |  |  | (100.0) | % |  | — |  |  | 3,474 |  |  |  |  | (100.0) | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | 0.1 | % |  |  |  |  |
| Total operating expenses | $ | 377,202 |  |  | $ | 370,727 |  |  |  |  | 1.7 | % |  | $ | 1,152,161 |  |  | $ | 1,126,327 |  |  |  |  | 2.3 | % |
| %** | 40.0 | % |  | 34.7 | % |  |  |  |  |  | 39.9 | % |  | 34.6 | % |  |  |  |  |

[0000936395-24-000032:mdna:85]
[same as prior period, unchanged from 0000936395-24-000025:mdna:84]

[0000936395-24-000032:mdna:86]
[same as prior period, unchanged from 0000936395-24-000025:mdna:85]

[0000936395-24-000032:mdna:87]
[same as prior period, unchanged from 0000936395-24-000025:mdna:86]

[0000936395-24-000032:mdna:88]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:89]
•Research and development expense decreased by $0.5 million. This decrease primarily reflects decreases in professional services, partially offset by increases in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan, prototype expense, and facility and information technology costs.

[0000936395-24-000032:mdna:90]
•Selling and marketing expense increased by $3.3 million. This increase primarily reflects increases in employee-related compensation costs primarily due to higher commission expense, partially offset by a decrease in travel and entertainment costs.

[0000936395-24-000032:mdna:91]
•General and administrative expense increased by $8.9 million. This increase primarily reflects an increase in legal fees.

[0000936395-24-000032:mdna:92]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities.

[0000936395-24-000032:mdna:93]
•Amortization of intangible assets decreased by $2.3 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-24-000032:mdna:94]
[same as prior period, unchanged from 0000936395-24-000025:mdna:93]

[0000936395-24-000032:mdna:95]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:96]
•Research and development expense increased by $10.4 million, net of hedging. This increase primarily reflects increases in employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan, facility and information technology costs and higher technology related costs, partially offset by decreased professional services.

[0000936395-24-000032:mdna:97]
•Selling and marketing expense increased by $6.6 million. This increase primarily reflects increases in employee-related compensation costs and increases in travel and entertainment costs, partially offset by decreased facility and information technology costs and selling and marketing costs.

[0000936395-24-000032:mdna:98]
•General and administrative expense increased by $11.3 million. This increase primarily reflects increases in legal fees, employee-related compensation costs, net of a lower provision associated with our annual cash incentive compensation plan, facility and information technology costs, and bad debt expense.

[0000936395-24-000032:mdna:99]
[same as prior period, unchanged from 0000936395-24-000025:mdna:91]

[0000936395-24-000032:mdna:100]
•Amortization of intangible assets decreased by $4.4 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-24-000032:mdna:101]
[same as prior period, unchanged from 0000936395-24-000025:mdna:101]

[0000936395-24-000032:mdna:102]
[same as prior period, unchanged from 0000936395-24-000025:mdna:102]

[0000936395-24-000032:mdna:103]
[same as prior period, unchanged from 0000936395-24-000025:mdna:103]

[0000936395-24-000032:mdna:104]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Interest and other income, net | $ | 14,013 |  |  | $ | 10,187 |  |  |  |  | 37.6 | % |  | $ | 36,460 |  |  | $ | 50,711 |  |  |  |  | (28.1) | % |
| %** | 1.5 | % |  | 1.0 | % |  |  |  |  |  | 1.3 | % |  | 1.6 | % |  |  |  |  |
| Interest expense | $ | 24,401 |  |  | $ | 24,060 |  |  |  |  | 1.4 | % |  | $ | 72,038 |  |  | $ | 63,819 |  |  |  |  | 12.9 | % |
| %** | 2.6 | % |  | 2.3 | % |  |  |  |  |  | 2.5 | % |  | 2.0 | % |  |  |  |  |
| Provision for income taxes | $ | 2,125 |  |  | $ | 34,608 |  |  |  |  | (93.9) | % |  | $ | 24,901 |  |  | $ | 89,507 |  |  |  |  | (72.2) | % |
| %** | 0.2 | % |  | 3.2 | % |  |  |  |  |  | 0.9 | % |  | 2.7 | % |  |  |  |  |

[0000936395-24-000032:mdna:105]
[same as prior period, unchanged from 0000936395-24-000025:mdna:105]

[0000936395-24-000032:mdna:106]
[same as prior period, unchanged from 0000936395-24-000025:mdna:106]

[0000936395-24-000032:mdna:107]
[same as prior period, unchanged from 0000936395-24-000025:mdna:107]

[0000936395-24-000032:mdna:108]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:109]
•Interest and other income, net increased by $3.8 million, primarily resulting from higher interest income on our investments and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-24-000032:mdna:110]
[same as prior period, unchanged from 0000936395-24-000025:mdna:110]

[0000936395-24-000032:mdna:111]
•Provision for income taxes decreased by $32.5 million, primarily due to the decrease in pre-tax book income for the quarter ended July 27, 2024. The effective tax rate for the third quarter of fiscal 2024 was lower than the effective tax rate for the third quarter of fiscal 2023, primarily due to the reduction in the amount of research and development expenses capitalized with respect to foreign subsidiaries.

[0000936395-24-000032:mdna:112]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:113]
•Interest and other income, net decreased by $14.3 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, in fiscal 2023, which resulted in a gain on our equity investment of $26.5 million and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. These decreases were partially offset by higher interest income on our investments.

[0000936395-24-000032:mdna:114]
•Interest expense increased by $8.2 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000032:mdna:115]
•Provision for income taxes decreased by $64.6 million, primarily due to the decrease in pre-tax book income for the first nine months of fiscal 2024. The effective tax rate for the first nine months of fiscal 2024 was lower than the effective tax rate for the first nine months of fiscal 2023, primarily due to a reduction in the amount of research and development expenses capitalized with respect to foreign subsidiaries.

[0000936395-24-000032:mdna:116]
[same as prior period, unchanged from 0000936395-24-000025:mdna:116]

[0000936395-24-000032:mdna:117]
[same as prior period, unchanged from 0000936395-24-000025:mdna:117]

[0000936395-24-000032:mdna:118]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |  | July 27, 2024 |  | July 29, 2023 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 106,870 |  |  | $ | 171,380 |  |  |  |  | (37.6) | % |  | $ | 387,211 |  |  | $ | 588,281 |  |  |  |  | (34.2) | % |
| Platform Software and Services | $ | 53,131 |  |  | $ | 49,691 |  |  |  |  | 6.9 | % |  | $ | 165,171 |  |  | $ | 136,028 |  |  |  |  | 21.4 | % |
| Blue Planet Automation Software and Services | $ | 4,705 |  |  | $ | (12,072) |  |  |  |  | 139.0 | % |  | $ | (10,127) |  |  | $ | (30,044) |  |  |  |  | 66.3 | % |
| Global Services | $ | 50,351 |  |  | $ | 50,550 |  |  |  |  | (0.4) | % |  | $ | 145,776 |  |  | $ | 137,190 |  |  |  |  | 6.3 | % |

[0000936395-24-000032:mdna:119]
[same as prior period, unchanged from 0000936395-24-000025:mdna:119]

[0000936395-24-000032:mdna:120]
[same as prior period, unchanged from 0000936395-24-000025:mdna:120]

[0000936395-24-000032:mdna:121]
Quarter ended July 27, 2024 as compared to the quarter ended July 29, 2023

[0000936395-24-000032:mdna:122]
•Networking Platforms segment profit decreased by $64.5 million, primarily due to lower product sales volume as described above.

[0000936395-24-000032:mdna:123]
•Platform Software and Services segment profit increased by $3.4 million, primarily due to higher sales volume as described above.

[0000936395-24-000032:mdna:124]
•Blue Planet Automation Software and Services segment profit increased by $16.8 million, primarily due to higher sales volume and improved margins on software services as described above, and decreased research and development costs.

[0000936395-24-000032:mdna:125]
•Global Services segment profit slightly decreased, primarily due to reduced margins on maintenance support and training partially offset by increased sales volume, as described above.

[0000936395-24-000032:mdna:126]
Nine months ended July 27, 2024 as compared to the nine months ended July 29, 2023

[0000936395-24-000032:mdna:127]
•Networking Platforms segment profit decreased by $201.1 million, primarily due to lower product sales volume as described above and increased research and development costs.

[0000936395-24-000032:mdna:128]
•Platform Software and Services segment profit increased by $29.1 million, primarily due to higher sales volume as described above, partially offset by increased research and development costs.

[0000936395-24-000032:mdna:129]
•Blue Planet Automation Software and Services segment loss decreased by $19.9 million, primarily due to higher gross margin on software-related services, increased sales volume, as described above, and decreased research and development costs.

[0000936395-24-000032:mdna:130]
•Global Services segment profit increased by $8.6 million, primarily due to higher sales volume offset by lower gross margin on maintenance support and training as described above.

[0000936395-24-000032:mdna:131]
[same as prior period, unchanged from 0000936395-24-000025:mdna:131]

[0000936395-24-000032:mdna:132]
Overview. For the nine months ended July 27, 2024, we generated $165.2 million of cash from operations, as our net income (adjusted for non-cash charges) of $304.2 million exceeded our working capital requirements of approximately $139.0 million. For additional details, see “Cash Provided By Operating Activities” below.

[0000936395-24-000032:mdna:133]
Cash, cash equivalents and investments decreased by $36.6 million during the first nine months of fiscal 2024. Cash from operations was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $125.8 million; (ii) cash used to fund our investing activities for capital expenditures totaling $53.1 million; (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $33.5 million; and (iv) cash used for our purchase of an equity investment in a privately held technology company of $21.7 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $34.3 million in cash during the nine months ended July 27, 2024.

[0000936395-24-000032:mdna:134]
[same as prior period, unchanged from 0000936395-24-000025:mdna:135]

[0000936395-24-000032:mdna:135]
[same as prior period, unchanged from 0000936395-24-000025:mdna:136]

[0000936395-24-000032:mdna:136]
|  | July 27,2024 |  | October 28,2023 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 883,365 |  |  | $ | 1,010,618 |  |  | $ | (127,253) |  |
| Short-term investments in marketable debt securities | 217,810 |  |  | 104,753 |  |  | 113,057 |  |
| Long-term investments in marketable debt securities | 111,833 |  |  | 134,278 |  |  | (22,445) |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,213,008 |  |  | $ | 1,249,649 |  |  | $ | (36,641) |  |

[0000936395-24-000032:mdna:137]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of July 27, 2024, totaled $1.2 billion, as well as the unused portion of the Revolving Credit Facility, to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of July 27, 2024, letters of credit totaling $72.0 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of July 27, 2024.

[0000936395-24-000032:mdna:138]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $155.9 million as of July 27, 2024. Approximately $93.0 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-24-000032:mdna:139]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the first nine months of fiscal 2024, we repurchased an additional $118.0 million of our common stock under the stock repurchase program, and $132.0 million remained under the current repurchase authorization as of July 27, 2024. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as Item 2 of Part II of this report.

[0000936395-24-000032:mdna:140]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-24-000032:mdna:141]
[same as prior period, unchanged from 0000936395-24-000025:mdna:142]

[0000936395-24-000032:mdna:142]
The following sections set forth the components of our $165.2 million of cash provided by operating activities during the first nine months of fiscal 2024:

[0000936395-24-000032:mdna:143]
[same as prior period, unchanged from 0000936395-24-000025:mdna:144]

[0000936395-24-000032:mdna:144]
[same as prior period, unchanged from 0000936395-24-000025:mdna:145]

[0000936395-24-000032:mdna:145]
|  | Nine Months Ended |
|  | July 27, 2024 |
| Net income | $ | 46,928 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 68,997 |  |
| Share-based compensation expense | 115,433 |  |
| Amortization of intangible assets | 30,675 |  |
| Deferred taxes | (19,909) |  |
| Provision for inventory excess and obsolescence | 35,400 |  |
| Provision for warranty | 14,708 |  |
| Other | 11,968 |  |
| Net income (adjusted for non-cash charges) | $ | 304,200 |  |

[0000936395-24-000032:mdna:146]
[same as prior period, unchanged from 0000936395-24-000025:mdna:147]

[0000936395-24-000032:mdna:147]
Working capital used $139.0 million of cash during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-24-000032:mdna:148]
|  | Nine Months Ended |
|  | July 27, 2024 |
| Cash provided by accounts receivable | $ | 92,421 |  |
| Cash provided by inventories | 78,220 |  |
| Cash used in prepaid expenses and other | (221,823) |  |
| Cash used in accounts payable, accruals, and other obligations | (112,352) |  |
| Cash provided by deferred revenue | 28,833 |  |
| Cash used in operating lease assets and liabilities, net | (4,327) |  |
| Total cash provided by working capital | $ | (139,028) |  |

[0000936395-24-000032:mdna:149]
[same as prior period, unchanged from 0000936395-24-000025:mdna:150]

[0000936395-24-000032:mdna:150]
•The $92.4 million of cash provided by accounts receivable during the first nine months of fiscal 2024 primarily reflects increased cash collections and lower sales volume during the first nine months of fiscal 2024;

[0000936395-24-000032:mdna:151]
•The $78.2 million of cash provided by inventories during the first nine months of fiscal 2024 primarily reflects the consumption of raw materials in excess of purchases;

[0000936395-24-000032:mdna:152]
•The $221.8 million of cash used in prepaid expense and other during the first nine months of fiscal 2024 primarily reflects refundable cash advances to a third-party contract manufacturer. See Note 10 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information relating to these transactions;

[0000936395-24-000032:mdna:153]
•The $112.4 million of cash used in accounts payable, accruals, and other obligations during the first nine months of fiscal 2024 primarily reflects the timing of payments for inventory purchases, payroll, our annual cash incentive compensation plans and income taxes;

[0000936395-24-000032:mdna:154]
•The $28.8 million of cash provided by deferred revenue during the first nine months of fiscal 2024 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-24-000032:mdna:155]
•The $4.3 million of cash used in operating lease assets and liabilities, net, during the first nine months of fiscal 2024 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-24-000032:mdna:156]
Our days sales outstanding (“DSOs”) increased from 94 for the first nine months of fiscal 2023 to 97 for the first nine months of fiscal 2024. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 1.7 for the first nine months of fiscal 2023 to 1.9 for the first nine months of fiscal 2024.

[0000936395-24-000032:mdna:157]
[same as prior period, unchanged from 0000936395-24-000025:mdna:158]

[0000936395-24-000032:mdna:158]
[same as prior period, unchanged from 0000936395-24-000025:mdna:159]

[0000936395-24-000032:mdna:159]
|  | Nine Months Ended |
|  | July 27, 2024 |
| 2030 New Term Loan due October 28, 2030(1) | $ | 64,654 |  |
| 2030 Senior Notes due January 31, 2030(2) | 8,000 |  |
| Interest rate swaps(3) | (11,343) |  |
| Revolving Credit Facility(4) | 834 |  |
| Finance leases | 2,854 |  |
| Cash paid during period | $ | 64,999 |  |

[0000936395-24-000032:mdna:160]
(1) Interest on the 2030 New Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 New Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%. At the end of the third quarter of fiscal 2024, the interest rate on the 2030 New Term Loan was 7.35%.

[0000936395-24-000032:mdna:161]
[same as prior period, unchanged from 0000936395-24-000025:mdna:162]

[0000936395-24-000032:mdna:162]
(3) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loan at 3.47% through January 2028 and another $350.0 million of our Term Loan at 2.968% through September 2025.

[0000936395-24-000032:mdna:163]
(4) During the first nine months of fiscal 2024, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-24-000032:mdna:164]
[same as prior period, unchanged from 0000936395-24-000025:mdna:165]

[0000936395-24-000032:mdna:165]
[same as prior period, unchanged from 0000936395-24-000025:mdna:166]

[0000936395-24-000032:mdna:166]
[same as prior period, unchanged from 0000936395-24-000025:mdna:167]

[0000936395-24-000032:mdna:167]
Purchase Order Obligations. As of July 27, 2024, we had $1.5 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-24-000032:mdna:168]
[same as prior period, unchanged from 0000936395-24-000025:mdna:169]

[0000936395-24-000032:mdna:169]
[same as prior period, unchanged from 0000936395-24-000025:mdna:170]

[0000936395-24-000032:mdna:170]
[same as prior period, unchanged from 0000936395-24-000025:mdna:171]

[0000936395-24-000032:mdna:171]
[same as prior period, unchanged from 0000936395-24-000025:mdna:172]
