# CIEN 8-K — 0000936395-24-000030 filed 2024-09-04

## item codes, every 8-K on or before 2024-09-04

- 2024-09-04 0000936395-24-000030 — 2.02, 5.02, 9.01
- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2024-09-04

- none on or before 2024-09-04

## item 2.02 — earnings release, exhibit 99.1

[0000936395-24-000030:8k_2_02:1]
EX-99.1
2
ex9912024q3earningspressre.htm
EX-99.1

[0000936395-24-000030:8k_2_02:2]
Document

[0000936395-24-000030:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-24-000030:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2024 Financial Results

[0000936395-24-000030:8k_2_02:5]
HANOVER, Md. - September 4, 2024 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal third quarter ended July 27, 2024.

[0000936395-24-000030:8k_2_02:6]
•Q3 Revenue: $942.3 million

[0000936395-24-000030:8k_2_02:7]
•Q3 Net Income per Share: $0.10 GAAP; $0.35 adjusted (non-GAAP)

[0000936395-24-000030:8k_2_02:8]
•Share Repurchases: Repurchased approximately 0.6 million shares of common stock for an aggregate price of $29.0 million during the quarter

[0000936395-24-000030:8k_2_02:9]
"We delivered strong results for the fiscal third quarter that reflect growing momentum with cloud providers and continued gradual recovery with service providers," said Gary Smith, president and CEO, Ciena. "With leading innovation that is well-aligned with our customers' focus on building cloud and AI-capable infrastructures, we are well-positioned to continue to gain share and deliver profitable growth.”

[0000936395-24-000030:8k_2_02:10]
For the fiscal third quarter 2024, Ciena reported revenue of $942.3 million as compared to $1.07 billion for the fiscal third quarter 2023.

[0000936395-24-000030:8k_2_02:11]
Ciena's GAAP net income for the fiscal third quarter 2024 was $14.2 million, or $0.10 per diluted common share, which compares to a GAAP net income of $29.7 million, or $0.20 per diluted common share, for the fiscal third quarter 2023.

[0000936395-24-000030:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2024 was $50.8 million, or $0.35 per diluted common share, which compares to an adjusted (non-GAAP) net income of $89.1 million, or $0.59 per diluted common share, for the fiscal third quarter 2023.

[0000936395-24-000030:8k_2_02:13]
Fiscal Third Quarter 2024 Performance Summary

[0000936395-24-000030:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-24-000030:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |
|  |  | FY 2024 |  | FY 2023 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 942.3 |  |  | $ | 1,067.9 |  |  | (11.8) | % |  |  |  |  |  |  |
| Gross margin |  | 42.9 | % |  | 42.0 | % |  | 0.9 | % |  |  |  |  |  |  |
| Operating expense |  | $ | 377.2 |  |  | $ | 370.7 |  |  | 1.7 | % |  |  |  |  |  |  |
| Operating margin |  | 2.9 | % |  | 7.3 | % |  | (4.4) | % |  |  |  |  |  |  |

[0000936395-24-000030:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |
|  |  | FY 2024 |  | FY 2023 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 942.3 |  |  | $ | 1,067.9 |  |  | (11.8) | % |  |  |  |  |  |  |
| Adj. gross margin |  | 43.7 | % |  | 42.7 | % |  | 1.0 | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 336.0 |  |  | $ | 327.9 |  |  | 2.5 | % |  |  |  |  |  |  |
| Adj. operating margin |  | 8.0 | % |  | 12.0 | % |  | (4.0) | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 98.5 |  |  | $ | 151.3 |  |  | (34.9) | % |  |  |  |  |  |  |

[0000936395-24-000030:8k_2_02:17]
*  Denotes % change, or in the case of margin, absolute change

[0000936395-24-000030:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q3 FY 2024 |  | Q3 FY 2023 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 606.8 |  |  | 64.4 |  |  | $ | 719.0 |  |  | 67.3 |  |
| Routing and Switching |  | 92.7 |  |  | 9.8 |  |  | 127.6 |  |  | 11.9 |  |
| Total Networking Platforms |  | 699.5 |  |  | 74.2 |  |  | 846.6 |  |  | 79.2 |  |
| Platform Software and Services |  | 83.2 |  |  | 8.9 |  |  | 78.9 |  |  | 7.4 |  |
| Blue Planet Automation Software and Services |  | 25.8 |  |  | 2.7 |  |  | 13.1 |  |  | 1.3 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 74.4 |  |  | 7.9 |  |  | 72.9 |  |  | 6.8 |  |
| Installation and Deployment |  | 46.5 |  |  | 4.9 |  |  | 46.8 |  |  | 4.4 |  |
| Consulting and Network Design |  | 12.9 |  |  | 1.4 |  |  | 9.6 |  |  | 0.9 |  |
| Total Global Services |  | 133.8 |  |  | 14.2 |  |  | 129.3 |  |  | 12.1 |  |
| Total |  | $ | 942.3 |  |  | 100.0 |  |  | $ | 1,067.9 |  |  | 100.0 |  |

[0000936395-24-000030:8k_2_02:19]
**  Denotes % of total revenue

[0000936395-24-000030:8k_2_02:20]
Additional Performance Metrics for Fiscal Third Quarter 2024

[0000936395-24-000030:8k_2_02:21]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q3 FY 2024 |  | Q3 FY 2023 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 718.6 |  |  | 76.3 |  |  | $ | 749.5 |  |  | 70.2 |  |
| Europe, Middle East and Africa |  | 135.0 |  |  | 14.3 |  |  | 152.8 |  |  | 14.3 |  |
| Asia Pacific |  | 88.7 |  |  | 9.4 |  |  | 165.6 |  |  | 15.5 |  |
| Total |  | $ | 942.3 |  |  | 100.0 |  |  | $ | 1,067.9 |  |  | 100.0 |  |

[0000936395-24-000030:8k_2_02:22]
**  Denotes % of total revenue

[0000936395-24-000030:8k_2_02:23]
•Two 10%-plus customers represented a total 26.6% of revenue

[0000936395-24-000030:8k_2_02:24]
•Cash and investments totaled $1.2 billion

[0000936395-24-000030:8k_2_02:25]
•Cash flow used in operations totaled $159.4 million

[0000936395-24-000030:8k_2_02:26]
•Average days' sales outstanding (DSOs) were 100

[0000936395-24-000030:8k_2_02:27]
•Accounts receivable, net balance was $899.9 million

[0000936395-24-000030:8k_2_02:28]
•Unbilled contract asset, net balance was $142.8 million

[0000936395-24-000030:8k_2_02:29]
•Inventories totaled $937.4 million, including:

[0000936395-24-000030:8k_2_02:30]
◦Raw materials: $612.7 million

[0000936395-24-000030:8k_2_02:31]
◦Work in process: $44.4 million

[0000936395-24-000030:8k_2_02:32]
◦Finished goods: $314.0 million

[0000936395-24-000030:8k_2_02:33]
◦Deferred cost of sales: $36.0 million

[0000936395-24-000030:8k_2_02:34]
◦Reserve for excess and obsolescence: $(69.7) million

[0000936395-24-000030:8k_2_02:35]
•Product inventory turns were 1.8

[0000936395-24-000030:8k_2_02:36]
•Headcount totaled 8,781

[0000936395-24-000030:8k_2_02:37]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2024 Results

[0000936395-24-000030:8k_2_02:38]
Today, Wednesday, September 4, 2024, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal third quarter 2024 results.

[0000936395-24-000030:8k_2_02:39]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com. An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-24-000030:8k_2_02:40]
Notes to Investors

[0000936395-24-000030:8k_2_02:41]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered strong results for the fiscal third quarter that reflect growing momentum with cloud providers and continued gradual recovery with service providers. With leading innovation that is well-aligned with our customers' focus on building cloud and AI-capable infrastructures, we are well-positioned to continue to gain share and deliver profitable growth.”

[0000936395-24-000030:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers, their spending and their businesses and markets; our ability to execute our business and growth strategies; the impact of macroeconomic conditions and global supply chain constraints or disruptions including increased supply costs and lead times; the impact of the introduction of new technologies by us or our competitors; seasonality and the timing and size of customer orders, their delivery dates and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, including but not limited to the ongoing conflicts between Ukraine and Russia, and Israel and Hamas, and public health emergencies or epidemics, including the COVID-19 pandemic; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or

[0000936395-24-000030:8k_2_02:43]
our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Annual Report on Form 10-K filed with the SEC on December 15, 2023 and included in its Quarterly Report on Form 10-Q for the third quarter of fiscal 2024 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-24-000030:8k_2_02:44]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-24-000030:8k_2_02:45]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on LinkedIn, X, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-24-000030:8k_2_02:46]
4

[0000936395-24-000030:8k_2_02:47]
CIENA CORPORATION

[0000936395-24-000030:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-24-000030:8k_2_02:49]
(in thousands, except per share data)

[0000936395-24-000030:8k_2_02:50]
(unaudited)

[0000936395-24-000030:8k_2_02:51]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 729,503 |  |  | $ | 865,197 |  |  | $ | 2,266,596 |  |  | $ | 2,678,242 |  |
| Services | 212,805 |  |  | 202,689 |  |  | 624,247 |  |  | 578,820 |  |
| Total revenue | 942,308 |  |  | 1,067,886 |  |  | 2,890,843 |  |  | 3,257,062 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 433,533 |  |  | 516,900 |  |  | 1,315,737 |  |  | 1,559,120 |  |
| Services | 104,830 |  |  | 102,045 |  |  | 315,538 |  |  | 305,372 |  |
| Total cost of goods sold | 538,363 |  |  | 618,945 |  |  | 1,631,275 |  |  | 1,864,492 |  |
| Gross profit | 403,945 |  |  | 448,941 |  |  | 1,259,568 |  |  | 1,392,570 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 188,888 |  |  | 189,392 |  |  | 571,537 |  |  | 561,115 |  |
| Selling and marketing | 121,520 |  |  | 118,266 |  |  | 373,749 |  |  | 367,156 |  |
| General and administrative | 58,248 |  |  | 49,349 |  |  | 162,504 |  |  | 151,184 |  |
| Significant asset impairments and restructuring costs | 1,361 |  |  | 4,174 |  |  | 21,987 |  |  | 16,625 |  |
| Amortization of intangible assets | 7,185 |  |  | 9,487 |  |  | 22,384 |  |  | 26,773 |  |
| Acquisition and integration costs | — |  |  | 59 |  |  | — |  |  | 3,474 |  |
| Total operating expenses | 377,202 |  |  | 370,727 |  |  | 1,152,161 |  |  | 1,126,327 |  |
| Income from operations | 26,743 |  |  | 78,214 |  |  | 107,407 |  |  | 266,243 |  |
| Interest and other income, net | 14,013 |  |  | 10,187 |  |  | 36,460 |  |  | 50,711 |  |
| Interest expense | (24,401) |  |  | (24,060) |  |  | (72,038) |  |  | (63,819) |  |
| Income before income taxes | 16,355 |  |  | 64,341 |  |  | 71,829 |  |  | 253,135 |  |
| Provision for income taxes | 2,125 |  |  | 34,608 |  |  | 24,901 |  |  | 89,507 |  |
| Net income | $ | 14,230 |  |  | $ | 29,733 |  |  | $ | 46,928 |  |  | $ | 163,628 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.10 |  |  | $ | 0.20 |  |  | $ | 0.32 |  |  | $ | 1.09 |  |
| Diluted net income per potential common share | $ | 0.10 |  |  | $ | 0.20 |  |  | $ | 0.32 |  |  | $ | 1.09 |  |
| Weighted average basic common shares outstanding | 144,394 |  |  | 149,690 |  |  | 144,876 |  |  | 149,472 |  |
| Weighted average dilutive potential common shares outstanding 1 | 145,361 |  |  | 149,977 |  |  | 145,795 |  |  | 149,867 |  |

[0000936395-24-000030:8k_2_02:52]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 1.0 million and 0.9 million for the third quarter and first nine months of fiscal 2024, respectively, and (ii) 0.3 million and 0.4 million for the third quarter and first nine months of fiscal 2023, respectively.

[0000936395-24-000030:8k_2_02:53]
CIENA CORPORATION

[0000936395-24-000030:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-24-000030:8k_2_02:55]
(in thousands, except share data)

[0000936395-24-000030:8k_2_02:56]
(unaudited)

[0000936395-24-000030:8k_2_02:57]
|  | July 27,2024 |  | October 28,2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 883,365 |  |  | $ | 1,010,618 |  |
| Short-term investments | 217,810 |  |  | 104,753 |  |
| Accounts receivable, net | 899,877 |  |  | 1,003,876 |  |
| Inventories, net | 937,399 |  |  | 1,050,838 |  |
| Prepaid expenses and other | 600,008 |  |  | 405,694 |  |
| Total current assets | 3,538,459 |  |  | 3,575,779 |  |
| Long-term investments | 111,833 |  |  | 134,278 |  |
| Equipment, building, furniture and fixtures, net | 299,161 |  |  | 280,147 |  |
| Operating lease right-of-use assets | 28,717 |  |  | 35,140 |  |
| Goodwill | 444,791 |  |  | 444,765 |  |
| Other intangible assets, net | 174,974 |  |  | 205,627 |  |
| Deferred tax asset, net | 831,682 |  |  | 809,306 |  |
| Other long-term assets | 145,513 |  |  | 116,453 |  |
| Total assets | $ | 5,575,130 |  |  | $ | 5,601,495 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 316,599 |  |  | $ | 317,828 |  |
| Accrued liabilities and other short-term obligations | 347,238 |  |  | 431,419 |  |
| Deferred revenue | 179,457 |  |  | 154,419 |  |
| Operating lease liabilities | 15,565 |  |  | 16,655 |  |
| Current portion of long-term debt | 11,700 |  |  | 11,700 |  |
| Total current liabilities | 870,559 |  |  | 932,021 |  |
| Long-term deferred revenue | 77,628 |  |  | 74,041 |  |
| Other long-term obligations | 171,014 |  |  | 170,407 |  |
| Long-term operating lease liabilities | 26,742 |  |  | 33,259 |  |
| Long-term debt, net | 1,538,315 |  |  | 1,543,406 |  |
| Total liabilities | 2,684,258 |  |  | 2,753,134 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 144,426,873 and 144,829,938 shares issued and outstanding | 1,444 |  |  | 1,448 |  |
| Additional paid-in capital | 6,260,095 |  |  | 6,262,083 |  |
| Accumulated other comprehensive loss | (40,192) |  |  | (37,767) |  |
| Accumulated deficit | (3,330,475) |  |  | (3,377,403) |  |
| Total stockholders’ equity | 2,890,872 |  |  | 2,848,361 |  |
| Total liabilities and stockholders’ equity | $ | 5,575,130 |  |  | $ | 5,601,495 |  |

[0000936395-24-000030:8k_2_02:58]
6

[0000936395-24-000030:8k_2_02:59]
CIENA CORPORATION

[0000936395-24-000030:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-24-000030:8k_2_02:61]
(in thousands) (unaudited)

[0000936395-24-000030:8k_2_02:62]
|  | Nine Months Ended |
|  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income | $ | 46,928 |  |  | $ | 163,628 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 68,997 |  |  | 69,213 |  |
| Share-based compensation expense | 115,433 |  |  | 95,405 |  |
| Amortization of intangible assets | 30,675 |  |  | 36,274 |  |
| Deferred taxes | (19,909) |  |  | (64,005) |  |
| Provision for inventory excess and obsolescence | 35,400 |  |  | 18,767 |  |
| Provision for warranty | 14,708 |  |  | 18,860 |  |
| Gain on equity investments, net | — |  |  | (26,368) |  |
| Other | 11,968 |  |  | 13,694 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 92,421 |  |  | (80,399) |  |
| Inventories | 78,220 |  |  | (262,345) |  |
| Prepaid expenses and other | (221,823) |  |  | 72,062 |  |
| Operating lease right-of-use assets | 8,963 |  |  | 11,003 |  |
| Accounts payable, accruals and other obligations | (112,352) |  |  | (133,880) |  |
| Deferred revenue | 28,833 |  |  | 57,547 |  |
| Short and long-term operating lease liabilities | (13,290) |  |  | (16,596) |  |
| Net cash provided by (used in) operating activities | 165,172 |  |  | (27,140) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (53,098) |  |  | (83,422) |  |
| Purchases of investments | (197,303) |  |  | (119,240) |  |
| Proceeds from sales and maturities of investments | 114,899 |  |  | 150,646 |  |
| Settlement of foreign currency forward contracts, net | (362) |  |  | (3,272) |  |
| Purchase of equity investments | (21,682) |  |  | — |  |
| Acquisition of business, net of cash acquired | — |  |  | (230,048) |  |
| Net cash used in investing activities | (157,546) |  |  | (285,336) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | — |  |  | 497,500 |  |
| Payment of long term debt | (5,850) |  |  | (6,448) |  |
| Payment of debt issuance costs | (2,554) |  |  | (5,422) |  |
| Payment of finance lease obligations | (3,004) |  |  | (2,830) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (33,450) |  |  | (29,794) |  |
| Repurchases of common stock - repurchase program, net | (125,816) |  |  | (57,736) |  |
| Proceeds from issuance of common stock | 34,292 |  |  | 31,276 |  |
| Net cash provided by (used in) financing activities | (136,382) |  |  | 426,546 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 1,499 |  |  | 9,501 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (127,257) |  |  | 123,571 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,010,786 |  |  | 994,378 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 883,529 |  |  | $ | 1,117,949 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 64,999 |  |  | $ | 56,709 |  |
| Cash paid during the period for income taxes, net | $ | 41,736 |  |  | $ | 68,058 |  |
| Operating lease payments | $ | 14,672 |  |  | $ | 18,038 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 35,316 |  |  | $ | 4,579 |  |
| Repurchase of common stock in accrued liabilities from repurchase program, net | $ | 1,762 |  |  | $ | 3,500 |  |
| Operating right-of-use assets subject to lease liability | $ | 5,326 |  |  | $ | 9,771 |  |
| Gain on equity investments, net | $ | — |  |  | $ | 26,368 |  |

[0000936395-24-000030:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | July 27, |  | July 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 403,945 |  |  | $ | 448,941 |  |  |  |  |  |
| Share-based compensation-products |  | 1,660 |  |  | 1,118 |  |  |  |  |  |
| Share-based compensation-services |  | 3,122 |  |  | 2,687 |  |  |  |  |  |
| Amortization of intangible assets |  | 2,764 |  |  | 3,187 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,546 |  |  | 6,992 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 411,491 |  |  | $ | 455,933 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.7 | % |  | 42.7 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 377,202 |  |  | $ | 370,727 |  |  |  |  |  |
| Share-based compensation-research and development |  | 13,118 |  |  | 10,954 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 10,315 |  |  | 8,770 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 9,257 |  |  | 9,377 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 1,361 |  |  | 4,174 |  |  |  |  |  |
| Amortization of intangible assets |  | 7,185 |  |  | 9,487 |  |  |  |  |  |
| Acquisition and integration costs |  | — |  |  | 59 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 41,236 |  |  | 42,821 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 335,966 |  |  | $ | 327,906 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 26,743 |  |  | $ | 78,214 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,546 |  |  | 6,992 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 41,236 |  |  | 42,821 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 48,782 |  |  | 49,813 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 75,525 |  |  | $ | 128,027 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 8.0 | % |  | 12.0 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 14,230 |  |  | $ | 29,733 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 2,125 |  |  | 34,608 |  |  |  |  |  |
| Income before income taxes |  | 16,355 |  |  | 64,341 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 48,782 |  |  | 49,813 |  |  |  |  |  |
| Loss on equity investment |  | — |  |  | 87 |  |  |  |  |  |
| Adjusted income before income taxes |  | 65,137 |  |  | 114,241 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 14,330 |  |  | 25,133 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 50,807 |  |  | $ | 89,108 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 144,394 |  | 149,690 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 145,361 |  | 149,977 |  |  |  |  |

[0000936395-24-000030:8k_2_02:64]
8

[0000936395-24-000030:8k_2_02:65]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | July 27, |  | July 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.10 |  |  | $ | 0.20 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.35 |  |  | $ | 0.59 |  |  |  |  |  |

[0000936395-24-000030:8k_2_02:66]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 1.0 million for the third quarter of fiscal 2024; and (ii) 0.3 million for the third quarter of fiscal 2023.

[0000936395-24-000030:8k_2_02:67]
9

[0000936395-24-000030:8k_2_02:68]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | July 27, |  | July 29, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 14,230 |  |  | $ | 29,733 |  |  |  |  |  |
| Add: Interest expense |  | 24,401 |  |  | 24,060 |  |  |  |  |  |
| Less: Interest and other income, net |  | 14,013 |  |  | 10,187 |  |  |  |  |  |
| Add: Provision for income taxes |  | 2,125 |  |  | 34,608 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 22,981 |  |  | 23,310 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 9,949 |  |  | 12,674 |  |  |  |  |  |
| EBITDA |  | $ | 59,673 |  |  | $ | 114,198 |  |  |  |  |  |
| Add: Share-based compensation expense |  | 37,472 |  |  | 32,906 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 1,361 |  |  | 4,174 |  |  |  |  |  |
| Add: Acquisition and integration costs |  | — |  |  | 59 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 98,506 |  |  | $ | 151,337 |  |  |  |  |  |

[0000936395-24-000030:8k_2_02:69]
* * *

[0000936395-24-000030:8k_2_02:70]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-24-000030:8k_2_02:71]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-24-000030:8k_2_02:72]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes and restructuring certain real estate facilities.

[0000936395-24-000030:8k_2_02:73]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0000936395-24-000030:8k_2_02:74]
•Acquisition and integration costs - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2023.

[0000936395-24-000030:8k_2_02:75]
•Loss on equity investment - reflects changes in the carrying value of a certain equity investment due to triggering events.

[0000936395-24-000030:8k_2_02:76]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for both the fiscal third quarter 2024 and the fiscal third quarter 2023. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.

## item 5.02 — body, verbatim

[0000936395-24-000030:8k_body:1]
ITEM 5.02 - DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0000936395-24-000030:8k_body:2]
On August 28, 2024, James E. Moylan, Jr., (age 73), Senior Vice President and Chief Financial Officer, notified Ciena of his decision to retire in twelve months, effective August 28, 2025 (the “Effective Date”), following more than 16 years of dedicated and distinguished service in such role.

[0000936395-24-000030:8k_body:3]
Ciena is commencing a search process to identify Mr. Moylan's successor. Mr. Moylan and Ciena expect that he will continue in his role until such time as his successor is in place and responsibilities have been transitioned, and that he will remain an employee and continue to provide support until the Effective Date.

[0000936395-24-000030:8k_body:4]
In connection with this announcement, Ciena issued a press release, which is furnished as Exhibit 99.3 to this Report.
