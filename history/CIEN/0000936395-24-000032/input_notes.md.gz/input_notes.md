# CIEN notes — 0000936395-24-000032


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-24-000032:notes:1]
[same as prior period, unchanged from 0000936395-24-000025:notes:1]

[0000936395-24-000032:notes:2]
[same as prior period, unchanged from 0000936395-24-000025:notes:2]

[0000936395-24-000032:notes:3]
[same as prior period, unchanged from 0000936395-24-000025:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-24-000032:notes:4]
[same as prior period, unchanged from 0000936395-24-000025:notes:4]

[0000936395-24-000032:notes:5]
[same as prior period, unchanged from 0000936395-24-000025:notes:5]

[0000936395-24-000032:notes:6]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

[0000936395-24-000032:notes:7]
[same as prior period, unchanged from 0000936395-24-000025:notes:7]

[0000936395-24-000032:notes:8]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-24-000032:notes:9]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-24-000032:notes:10]
In March 2024, the SEC adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate Related Disclosures for Investors, which will require registrants to provide certain climate-related information in their registration statements and annual reports. The rules will require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks will also include disclosure of a registrant's greenhouse gas emissions. In addition, the rules will require registrants to present certain climate-related financial metrics in their audited financial statements. Disclosures will be required prospectively, with information for prior periods required only to the extent it was previously disclosed in an SEC filing. Ciena is currently evaluating the impact of these final rules on its consolidated financial statements and related disclosures. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-24-000032:notes:11]
[same as prior period, unchanged from 0000936395-24-000025:notes:12]

[0000936395-24-000032:notes:12]
[same as prior period, unchanged from 0000936395-24-000025:notes:13]

[0000936395-24-000032:notes:13]
[same as prior period, unchanged from 0000936395-24-000025:notes:14]

[0000936395-24-000032:notes:14]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

[0000936395-24-000032:notes:15]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

[0000936395-24-000032:notes:16]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |

[0000936395-24-000032:notes:17]
|  | Nine months ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

[0000936395-24-000032:notes:18]
[same as prior period, unchanged from 0000936395-24-000025:notes:19]

[0000936395-24-000032:notes:19]
[same as prior period, unchanged from 0000936395-24-000025:notes:20]

[0000936395-24-000032:notes:20]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,605 |  |  | $ | 749,479 |  |  | $ | 2,099,680 |  |  | $ | 2,308,934 |  |
| EMEA |  | 135,009 |  |  | 152,834 |  |  | 498,212 |  |  | 479,053 |  |
| APAC |  | 88,694 |  |  | 165,573 |  |  | 292,951 |  |  | 469,075 |  |
| Total revenue by geographic distribution |  | $ | 942,308 |  |  | $ | 1,067,886 |  |  | $ | 2,890,843 |  |  | $ | 3,257,062 |  |

[0000936395-24-000032:notes:21]
Ciena’s revenue includes $676.0 million and $685.8 million of United States revenue for the third quarter of fiscal 2024 and 2023, respectively. For the nine months ended July 27, 2024 and July 29, 2023, United States revenue was $2.0 billion and $2.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0000936395-24-000032:notes:22]
[same as prior period, unchanged from 0000936395-24-000025:notes:23]

[0000936395-24-000032:notes:23]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Cloud Provider | $ | 137,184 |  |  | $ | 124,897 |  |  | $ | 331,631 |  |  | $ | 369,678 |  |
| AT&T | 113,082 |  |  | n/a |  | 324,787 |  |  | 357,382 |  |
| Total | $ | 250,266 |  |  | $ | 124,897 |  |  | $ | 656,418 |  |  | $ | 727,060 |  |

[0000936395-24-000032:notes:24]
[same as prior period, unchanged from 0000936395-24-000025:notes:25]

[0000936395-24-000032:notes:25]
[same as prior period, unchanged from 0000936395-24-000025:notes:26]

[0000936395-24-000032:notes:26]
[same as prior period, unchanged from 0000936395-24-000025:notes:27]

[0000936395-24-000032:notes:27]
[same as prior period, unchanged from 0000936395-24-000025:notes:28]

[0000936395-24-000032:notes:28]
[same as prior period, unchanged from 0000936395-24-000025:notes:29]

[0000936395-24-000032:notes:29]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system. This product line also includes the WaveLogic 5 Nano (WL5n) 100G-400G coherent pluggable transceivers.

[0000936395-24-000032:notes:30]
[same as prior period, unchanged from 0000936395-24-000025:notes:31]

[0000936395-24-000032:notes:31]
[same as prior period, unchanged from 0000936395-24-000025:notes:32]

[0000936395-24-000032:notes:32]
[same as prior period, unchanged from 0000936395-24-000025:notes:33]

[0000936395-24-000032:notes:33]
[same as prior period, unchanged from 0000936395-24-000025:notes:34]

[0000936395-24-000032:notes:34]
[same as prior period, unchanged from 0000936395-24-000025:notes:35]

[0000936395-24-000032:notes:35]
[same as prior period, unchanged from 0000936395-24-000025:notes:36]

[0000936395-24-000032:notes:36]
[same as prior period, unchanged from 0000936395-24-000025:notes:37]

[0000936395-24-000032:notes:37]
[same as prior period, unchanged from 0000936395-24-000025:notes:38]

[0000936395-24-000032:notes:38]
|  |  | Balance at July 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 899,877 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 142,769 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 257,085 |  |  | $ | 228,460 |  |

[0000936395-24-000032:notes:39]
[same as prior period, unchanged from 0000936395-24-000025:notes:40]

[0000936395-24-000032:notes:40]
Deferred revenue represents contract liabilities and consists of advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $130.5 million and $119.8 million of revenue during the first nine months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance as of October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 27, 2024 and July 29, 2023.

[0000936395-24-000032:notes:41]
[same as prior period, unchanged from 0000936395-24-000025:notes:42]

[0000936395-24-000032:notes:42]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $25.5 million and $30.2 million as of July 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $22.9 million and $26.0 million during the first nine months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-24-000032:notes:43]
[same as prior period, unchanged from 0000936395-24-000025:notes:44]

[0000936395-24-000032:notes:44]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 27, 2024, the aggregate amount of RPO was $1.6 billion. As of July 27, 2024, Ciena expects approximately 78% of the RPO balance to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-24-000032:notes:45]
[same as prior period, unchanged from 0000936395-24-000025:notes:46]

[0000936395-24-000032:notes:46]
|  | July 27,2024 |  | October 28,2023 |
| Products | $ | 20,081 |  |  | $ | 28,353 |  |
| Services | 237,004 |  |  | 200,107 |  |
| Total deferred revenue | 257,085 |  |  | 228,460 |  |
| Less current portion | (179,457) |  |  | (154,419) |  |
| Long-term deferred revenue | $ | 77,628 |  |  | $ | 74,041 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-24-000032:notes:47]
[same as prior period, unchanged from 0000936395-24-000025:notes:48]

[0000936395-24-000032:notes:48]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the nine months ended July 27, 2024 (in thousands):

[0000936395-24-000032:notes:49]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 13,708 |  | (1) | 8,279 |  | (2) | 21,987 |  |
| Cash payments | (14,379) |  |  | (8,279) |  |  | (22,658) |  |
| Balance at July 27, 2024 | $ | 1,242 |  |  | $ | — |  |  | $ | 1,242 |  |
| Current restructuring liabilities | $ | 1,242 |  |  | $ | — |  |  | $ | 1,242 |  |

[0000936395-24-000032:notes:50]
(1) Reflects a global workforce reduction of approximately 390 employees during the nine months ended July 27, 2024 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-24-000032:notes:51]
[same as prior period, unchanged from 0000936395-24-000025:notes:52]

[0000936395-24-000032:notes:52]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended July 29, 2023 (in thousands):

[0000936395-24-000032:notes:53]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 4,509 |  | (1) | 12,116 |  | (2) | 16,625 |  |
| Cash payments | (4,920) |  |  | (16,736) |  |  | (21,656) |  |
| Balance at July 29, 2023 | $ | 804 |  |  | $ | — |  |  | $ | 804 |  |
| Current restructuring liabilities | $ | 804 |  |  | $ | — |  |  | $ | 804 |  |

[0000936395-24-000032:notes:54]
(1) Reflects employee costs associated with workforce reductions during the nine months ended July 29, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-24-000032:notes:55]
[same as prior period, unchanged from 0000936395-24-000025:notes:56]

[0000936395-24-000032:notes:56]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Interest income | $ | 15,876 |  |  | $ | 12,835 |  |  | $ | 46,309 |  |  | $ | 30,365 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 519 |  |  | 1,679 |  |  | 2,517 |  |  | (2,885) |  |
| Foreign currency exchange losses | (1,611) |  |  | (4,031) |  |  | (11,215) |  |  | (2,927) |  |
| Gain (loss) on equity investments, net | — |  |  | (87) |  |  | — |  |  | 26,368 |  |
| Other | (771) |  |  | (209) |  |  | (1,151) |  |  | (210) |  |
| Interest and other income, net | $ | 14,013 |  |  | $ | 10,187 |  |  | $ | 36,460 |  |  | $ | 50,711 |  |

[0000936395-24-000032:notes:57]
During the first quarter of fiscal 2023, the acquisition of Tibit Communications, Inc. (“Tibit”) by Ciena triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its equity investment of $26.5 million. 
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. During the first nine months of fiscal 2024 and fiscal 2023, Ciena recorded $11.2 million and $2.9 million, respectively, in foreign currency exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first nine months of fiscal 2024, Ciena recorded gains of $2.5 million from non-hedge designated foreign currency forward contracts. During the first nine months of fiscal 2023, Ciena recorded losses of $2.9 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-24-000032:notes:58]
INCOME TAXESThe effective tax rate for the third quarter and nine months ended July 27, 2024 was lower than the effective tax rate for the third quarter and nine months ended July 29, 2023, primarily due to the reduction in the amount of research and development expenses capitalized with respect to foreign subsidiaries.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-24-000032:notes:59]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-24-000032:notes:60]
|  | July 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 260,879 |  |  | $ | 250 |  |  | $ | (119) |  |  | $ | 261,010 |  |
| Corporate debt securities | 57,791 |  |  | 64 |  |  | (19) |  |  | 57,836 |  |
| Time deposits | 96,127 |  |  | 7 |  |  | — |  |  | 96,134 |  |
|  | $ | 414,797 |  |  | $ | 321 |  |  | $ | (138) |  |  | $ | 414,980 |  |
| Included in cash equivalents | $ | 85,337 |  |  | $ | — |  |  | $ | — |  |  | $ | 85,337 |  |
| Included in short-term investments | 217,761 |  |  | 158 |  |  | (109) |  |  | 217,810 |  |
| Included in long-term investments | 111,699 |  |  | 163 |  |  | (29) |  |  | 111,833 |  |
|  | $ | 414,797 |  |  | $ | 321 |  |  | $ | (138) |  |  | $ | 414,980 |  |

[0000936395-24-000032:notes:61]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

[0000936395-24-000032:notes:62]
The following table summarizes the final legal maturities of debt investments as of July 27, 2024 (in thousands):

[0000936395-24-000032:notes:63]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 303,098 |  |  | $ | 303,147 |  |
| Due in 1-2 years | 111,699 |  |  | 111,833 |  |
|  | $ | 414,797 |  |  | $ | 414,980 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-24-000032:notes:64]
[same as prior period, unchanged from 0000936395-24-000025:notes:67]

[0000936395-24-000032:notes:65]
|  | July 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 427,818 |  |  | $ | — |  |  | $ | — |  |  | $ | 427,818 |  |
| Bond mutual fund | 160,513 |  |  | — |  |  | — |  |  | 160,513 |  |
| Time deposits | 96,134 |  |  | — |  |  | — |  |  | 96,134 |  |
| Deferred compensation plan assets | 15,590 |  |  | — |  |  | — |  |  | 15,590 |  |
| U.S. government obligations | — |  |  | 261,010 |  |  | — |  |  | 261,010 |  |
| Corporate debt securities | — |  |  | 57,836 |  |  | — |  |  | 57,836 |  |
| Foreign currency forward contracts | — |  |  | 1,232 |  |  | — |  |  | 1,232 |  |
| Interest rate swaps | — |  |  | 12,316 |  |  | — |  |  | 12,316 |  |
| Total assets measured at fair value | $ | 700,055 |  |  | $ | 332,394 |  |  | $ | — |  |  | $ | 1,032,449 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 7,271 |  |  | $ | — |  |  | $ | 7,271 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,271 |  |  | $ | — |  |  | $ | 7,271 |  |

[0000936395-24-000032:notes:66]
[same as prior period, unchanged from 0000936395-24-000025:notes:69]

[0000936395-24-000032:notes:67]
[same as prior period, unchanged from 0000936395-24-000025:notes:70]

[0000936395-24-000032:notes:68]
|  | July 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 669,655 |  |  | $ | 4,013 |  |  | $ | — |  |  | $ | 673,668 |  |
| Short-term investments | 14,810 |  |  | 203,000 |  |  | — |  |  | 217,810 |  |
| Prepaid expenses and other | — |  |  | 1,232 |  |  | — |  |  | 1,232 |  |
| Long-term investments | — |  |  | 111,833 |  |  | — |  |  | 111,833 |  |
| Other long-term assets | 15,590 |  |  | 12,316 |  |  | — |  |  | 27,906 |  |
| Total assets measured at fair value | $ | 700,055 |  |  | $ | 332,394 |  |  | $ | — |  |  | $ | 1,032,449 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 7,271 |  |  | $ | — |  |  | $ | 7,271 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,271 |  |  | $ | — |  |  | $ | 7,271 |  |

[0000936395-24-000032:notes:69]
[same as prior period, unchanged from 0000936395-24-000025:notes:72]

[0000936395-24-000032:notes:70]
[same as prior period, unchanged from 0000936395-24-000025:notes:73]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-24-000032:notes:71]
[same as prior period, unchanged from 0000936395-24-000025:notes:74]

[0000936395-24-000032:notes:72]
|  | July 27,2024 |  | October 28,2023 |
| Raw materials | $ | 612,768 |  |  | $ | 664,797 |  |
| Work-in-process | 44,364 |  |  | 55,242 |  |
| Finished goods | 313,977 |  |  | 314,168 |  |
| Deferred cost of goods sold | 35,983 |  |  | 66,634 |  |
| Gross inventories | 1,007,092 |  |  | 1,100,841 |  |
| Reserve for inventory excess and obsolescence | (69,693) |  |  | (50,003) |  |
| Inventories, net | $ | 937,399 |  |  | $ | 1,050,838 |  |

[0000936395-24-000032:notes:73]
Ciena has been expanding its manufacturing capacity and had been accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly upon the easing of supply constraints for certain common components. During the first nine months of fiscal 2024 Ciena reduced its raw materials inventory of components due to the consumption of raw materials in excess of purchases.

[0000936395-24-000032:notes:74]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For the periods presented, future demand was calculated using both customer backlog and future forecasted sales. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services, although instances of both cancellation and non-acceptance are rare. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first nine months of fiscal 2024, Ciena recorded a provision for inventory excess and obsolescence of $35.4 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-24-000032:notes:75]
[same as prior period, unchanged from 0000936395-24-000025:notes:78]

[0000936395-24-000032:notes:76]
|  | July 27,2024 |  | October 28,2023 |
| Cash advances to contract manufacturers(1) | $ | 182,886 |  |  | $ | — |  |
| Contract assets for unbilled accounts receivable, net | 142,769 |  |  | 150,312 |  |
| Prepaid VAT and other taxes | 112,997 |  |  | 96,724 |  |
| Prepaid expenses | 53,950 |  |  | 58,954 |  |
| Product demonstration equipment, net(2) | 43,854 |  |  | 40,682 |  |
| Other non-trade receivables | 42,482 |  |  | 33,408 |  |
| Capitalized contract acquisition costs | 18,033 |  |  | 23,326 |  |
| Deferred deployment expense | 1,805 |  |  | 1,170 |  |
| Foreign currency forward contracts | 1,232 |  |  | 1,118 |  |
|  | $ | 600,008 |  |  | $ | 405,694 |  |

[0000936395-24-000032:notes:77]
(1) Amount reflects refundable cash advances to a third-party contract manufacturer for potential future inventory purchases and transition and logistic costs for future asset relocation. Ciena has initiated a strategic reengineering and realignment of its supply chain, including changes to its systems, processes, partners and people, and this cash advance assists in facilitating such activities.

[0000936395-24-000032:notes:78]
(2) Depreciation of product demonstration equipment was $6.1 million during the first nine months of fiscal 2024 and $5.9 million during the first nine months of fiscal 2023.

[0000936395-24-000032:notes:79]
[same as prior period, unchanged from 0000936395-24-000025:notes:81]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-24-000032:notes:80]
[same as prior period, unchanged from 0000936395-24-000025:notes:82]

[0000936395-24-000032:notes:81]
|  | July 27,2024 |  | October 28,2023 |
| Maintenance spares inventory, net | $ | 68,100 |  |  | $ | 54,042 |  |
| Equity investments(1) | 21,730 |  |  | 48 |  |
| Deferred compensation plan assets | 15,590 |  |  | 11,456 |  |
| Forward starting interest rate swaps | 12,316 |  |  | 24,953 |  |
| Capitalized contract acquisition costs | 7,423 |  |  | 6,879 |  |
| Cloud computing arrangements(2) | 6,946 |  |  | 8,589 |  |
| Deferred debt issuance costs, net | 1,806 |  |  | 1,956 |  |
| Restricted cash | 164 |  |  | 168 |  |
| Other | 11,438 |  |  | 8,362 |  |
|  | $ | 145,513 |  |  | $ | 116,453 |  |

[0000936395-24-000032:notes:82]
(1) Increase is due to an equity investment in a privately held technology company during fiscal 2024.

[0000936395-24-000032:notes:83]
(2) Amortization of cloud computing arrangements was $3.4 million and $1.9 million during the first nine months of fiscal 2024 and fiscal 2023, respectively.

[0000936395-24-000032:notes:84]
[same as prior period, unchanged from 0000936395-24-000025:notes:86]

[0000936395-24-000032:notes:85]
|  | July 27,2024 |  | October 28,2023 |
| Compensation, payroll related tax and benefits | $ | 120,889 |  |  | $ | 159,530 |  |
| Warranty | 49,933 |  |  | 57,089 |  |
| Vacation | 31,419 |  |  | 29,503 |  |
| Interest payable | 8,806 |  |  | 4,514 |  |
| Foreign currency forward contracts | 7,271 |  |  | 14,509 |  |
| Income taxes payable | 6,537 |  |  | 16,341 |  |
| Finance lease liabilities | 4,306 |  |  | 3,953 |  |
| Other | 118,077 |  |  | 145,980 |  |
|  | $ | 347,238 |  |  | $ | 431,419 |  |

[0000936395-24-000032:notes:86]
[same as prior period, unchanged from 0000936395-24-000025:notes:88]

[0000936395-24-000032:notes:87]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Nine Months Ended July 29, 2023 |  | $ | 45,503 |  |  |  |  | 18,860 |  |  | (14,859) |  |  | $ | 49,504 |  |
| Nine Months Ended July 27, 2024 |  | $ | 57,089 |  |  |  |  | 14,708 |  |  | (21,864) |  |  | $ | 49,933 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-24-000032:notes:88]
[same as prior period, unchanged from 0000936395-24-000025:notes:90]

[0000936395-24-000032:notes:89]
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To hedge this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-24-000032:notes:90]
As of July 27, 2024 and October 28, 2023, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $286.2 million and $367.3 million as of July 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-24-000032:notes:91]
As of July 27, 2024 and October 28, 2023, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. In April 2024, Ciena terminated a portion of its existing net investment hedges for a cash loss of $0.6 million, which was recorded to Other Comprehensive Income (Loss). Ciena replaced its terminated net investment hedges with new net investment hedges. The notional amount of these contracts was approximately $65.7 million and $48.0 million as of July 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0000936395-24-000032:notes:92]
As of July 27, 2024 and October 28, 2023, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $142.6 million and $226.3 million as of July 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-24-000032:notes:93]
[same as prior period, unchanged from 0000936395-24-000025:notes:96]

[0000936395-24-000032:notes:94]
[same as prior period, unchanged from 0000936395-24-000025:notes:97]

[0000936395-24-000032:notes:95]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest swaps was $350.0 million as of July 27, 2024 and October 28, 2023.

[0000936395-24-000032:notes:96]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of these interest rate swaps in effect as of July 27, 2024 and October 28, 2023 was $350.0 million.

[0000936395-24-000032:notes:97]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of July 27, 2024.

[0000936395-24-000032:notes:98]
[same as prior period, unchanged from 0000936395-24-000025:notes:101]

[0000936395-24-000032:notes:99]
[same as prior period, unchanged from 0000936395-24-000025:notes:102]


## us-gaap:DebtDisclosureTextBlock

[0000936395-24-000032:notes:100]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-24-000032:notes:101]
2030 New Term Loan

[0000936395-24-000032:notes:102]
On October 24, 2023, Ciena entered into an Incremental Amendment Agreement to its Credit Agreement to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion maturing on October 24, 2030 (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”). The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.7 million annually, with the remaining balance payable at maturity.

[0000936395-24-000032:notes:103]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-24-000032:notes:104]
|  |  | July 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,164,150 |  |  | $ | (4,560) |  |  | $ | (5,830) |  |  | $ | 1,153,760 |  |  | $ | 1,159,371 |  |

[0000936395-24-000032:notes:105]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $5.8 million as of July 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.7 million during the first nine months of fiscal 2024.

[0000936395-24-000032:notes:106]
As of July 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-24-000032:notes:107]
Refinanced Term Loans

[0000936395-24-000032:notes:108]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the 2025 Term Loan (as defined below) and the 2030 Term Loan (as defined below), together the Refinanced Term Loans, including accrued interest.

[0000936395-24-000032:notes:109]
2025 Term Loan

[0000936395-24-000032:notes:110]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace the London Interbank Offered Rate (LIBOR) with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million for the first nine months of fiscal 2023.

[0000936395-24-000032:notes:111]
2030 Term Loan

[0000936395-24-000032:notes:112]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.3 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was $0.4 million for the first nine months of fiscal 2023.

[0000936395-24-000032:notes:113]
Outstanding Senior Notes Payable

[0000936395-24-000032:notes:114]
2030 Notes

[0000936395-24-000032:notes:115]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-24-000032:notes:116]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-24-000032:notes:117]
|  |  | July 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,745) |  |  | $ | 396,255 |  |  | $ | 395,735 |  |  |  |

[0000936395-24-000032:notes:118]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $3.7 million as of July 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.5 million during both the first nine months of fiscal 2024 and fiscal 2023.

[0000936395-24-000032:notes:119]
As of July 27, 2024, the estimated fair value of the 2030 Notes was $367.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-24-000032:notes:120]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended July 27, 2024 (in thousands):

[0000936395-24-000032:notes:121]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications | 493 |  |  | (112) |  |  |  |  | 1,728 |  |  | 2,961 |  |  | 5,070 |  |
| Amounts reclassified from AOCI | — |  |  | 3,848 |  |  |  |  | (11,343) |  |  | — |  |  | (7,495) |  |
| Balance at July 27, 2024 | $ | 121 |  |  | $ | (4,420) |  |  |  |  | $ | 9,347 |  |  | $ | (45,240) |  |  | $ | (40,192) |  |

[0000936395-24-000032:notes:122]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended July 29, 2023 (in thousands):

[0000936395-24-000032:notes:123]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain before reclassifications | 2,075 |  |  | 17,070 |  |  | 11,763 |  |  | 17,981 |  |  | 48,889 |  |
| Amounts reclassified from AOCI | — |  |  | (7,756) |  |  | (6,266) |  |  | — |  |  | (14,022) |  |
| Balance at July 29, 2023 | $ | (890) |  |  | $ | (883) |  |  | $ | 14,894 |  |  | $ | (24,899) |  |  | $ | (11,778) |  |

[0000936395-24-000032:notes:124]
All amounts reclassified from AOCI, related to settlements on foreign currency forward contracts designated as cash flow hedges, impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI, related to settlements on interest rate swaps designated as cash flow hedges, impacted interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:EarningsPerShareTextBlock

[0000936395-24-000032:notes:125]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-24-000032:notes:126]
[same as prior period, unchanged from 0000936395-24-000025:notes:129]

[0000936395-24-000032:notes:127]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Net income | $ | 14,230 |  |  | $ | 29,733 |  |  | $ | 46,928 |  |  | $ | 163,628 |  |
| Basic weighted average shares outstanding | 144,394 |  |  | 149,690 |  |  | 144,876 |  |  | 149,472 |  |
| Effect of dilutive potential common shares | 967 |  |  | 287 |  |  | 919 |  |  | 395 |  |
| Diluted weighted average shares | 145,361 |  |  | 149,977 |  |  | 145,795 |  |  | 149,867 |  |
| Basic EPS | $ | 0.10 |  |  | $ | 0.20 |  |  | $ | 0.32 |  |  | $ | 1.09 |  |
| Diluted EPS | $ | 0.10 |  |  | $ | 0.20 |  |  | $ | 0.32 |  |  | $ | 1.09 |  |
| Antidilutive employee share-based awards, excluded | 690 |  |  | 3,383 |  |  | 1,286 |  |  | 2,567 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-24-000032:notes:128]
[same as prior period, unchanged from 0000936395-24-000025:notes:131]

[0000936395-24-000032:notes:129]
[same as prior period, unchanged from 0000936395-24-000025:notes:132]

[0000936395-24-000032:notes:130]
Under this program, during the first nine months of fiscal 2024, Ciena repurchased an additional 2.4 million shares of its common stock for an aggregate purchase price of approximately $118.0 million which equates to an average price of $48.86 per share. As of July 27, 2024, Ciena (i) has repurchased 16.5 million shares for an aggregate purchase price of $868.0 million at an average price of $52.54 per share and (ii) has an aggregate of $132.0 million authorized and remaining under its stock repurchase program. Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0000936395-24-000032:notes:131]
[same as prior period, unchanged from 0000936395-24-000025:notes:135]

[0000936395-24-000032:notes:132]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $33.4 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2024 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-24-000032:notes:133]
SHARE-BASED COMPENSATION EXPENSE
At Ciena’s 2024 Annual Meeting of Stockholders on March 21, 2024, Ciena’s stockholders approved an amendment to the Ciena Corporation 2017 Omnibus Incentive Plan (the “2017 Plan”), effective as of such date, to (i) increase the number of shares available for issuance thereunder by 10.1 million shares, and (ii) increase the recoupment period for misconduct relating to accounting restatements from 12 months to three years. As of July 27, 2024, the total number of shares authorized for issuance under the 2017 Plan is 31.2 million and approximately 10.9 million shares remained available for issuance thereunder.

[0000936395-24-000032:notes:134]
[same as prior period, unchanged from 0000936395-24-000025:notes:138]

[0000936395-24-000032:notes:135]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Products | $ | 1,660 |  |  | $ | 1,118 |  |  | $ | 4,738 |  |  | $ | 3,324 |  |
| Services | 3,122 |  |  | 2,687 |  |  | 9,486 |  |  | 7,643 |  |
| Share-based compensation expense included in cost of goods sold | 4,782 |  |  | 3,805 |  |  | 14,224 |  |  | 10,967 |  |
| Research and development | 13,118 |  |  | 10,954 |  |  | 40,064 |  |  | 30,919 |  |
| Selling and marketing | 10,315 |  |  | 8,770 |  |  | 31,786 |  |  | 25,949 |  |
| General and administrative | 9,257 |  |  | 9,377 |  |  | 29,211 |  |  | 27,313 |  |
| Share-based compensation expense included in operating expense | 32,690 |  |  | 29,101 |  |  | 101,061 |  |  | 84,181 |  |
| Share-based compensation expense capitalized in inventory, net | (114) |  |  | 127 |  |  | 148 |  |  | 257 |  |
| Total share-based compensation expense | $ | 37,358 |  |  | $ | 33,033 |  |  | $ | 115,433 |  |  | $ | 95,405 |  |

[0000936395-24-000032:notes:136]
As of July 27, 2024, total unrecognized share-based compensation expense was approximately $251.9 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-24-000032:notes:137]
[same as prior period, unchanged from 0000936395-24-000025:notes:141]

[0000936395-24-000032:notes:138]
[same as prior period, unchanged from 0000936395-24-000025:notes:142]

[0000936395-24-000032:notes:139]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 27, 2024, equipment, building, furniture and fixtures, net, totaled $299.2 million, and operating ROU assets totaled $28.7 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of July 27, 2024, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-24-000032:notes:140]
|  | July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 166,067 |  |  | — |  |  | 8,907 |  |  | — |  |  | $ | 174,974 |  |
| Goodwill | $ | 199,551 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 444,791 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 68,100 |  |  | $ | 68,100 |  |

[0000936395-24-000032:notes:141]
[same as prior period, unchanged from 0000936395-24-000025:notes:145]

[0000936395-24-000032:notes:142]
[same as prior period, unchanged from 0000936395-24-000025:notes:146]

[0000936395-24-000032:notes:143]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to net income for the periods indicated (in thousands):

[0000936395-24-000032:notes:144]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 27, |  | July 29, |  | July 27, |  | July 29, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 106,870 |  |  | $ | 171,380 |  |  | $ | 387,211 |  |  | $ | 588,281 |  |
| Platform Software and Services | 53,131 |  |  | 49,691 |  |  | 165,171 |  |  | 136,028 |  |
| Blue Planet Automation Software and Services | 4,705 |  |  | (12,072) |  |  | (10,127) |  |  | (30,044) |  |
| Global Services | 50,351 |  |  | 50,550 |  |  | 145,776 |  |  | 137,190 |  |
| Total segment profit | 215,057 |  |  | 259,549 |  |  | 688,031 |  |  | 831,455 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 121,520 |  |  | 118,266 |  |  | 373,749 |  |  | 367,156 |  |
| General and administrative | 58,248 |  |  | 49,349 |  |  | 162,504 |  |  | 151,184 |  |
| Significant asset impairments and restructuring costs | 1,361 |  |  | 4,174 |  |  | 21,987 |  |  | 16,625 |  |
| Amortization of intangible assets | 7,185 |  |  | 9,487 |  |  | 22,384 |  |  | 26,773 |  |
| Acquisition and integration costs | — |  |  | 59 |  |  | — |  |  | 3,474 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 14,013 |  |  | 10,187 |  |  | 36,460 |  |  | 50,711 |  |
| Interest expense | (24,401) |  |  | (24,060) |  |  | (72,038) |  |  | (63,819) |  |
| Less: Provision for income taxes | 2,125 |  |  | 34,608 |  |  | 24,901 |  |  | 89,507 |  |
| Net income | $ | 14,230 |  |  | $ | 29,733 |  |  | $ | 46,928 |  |  | $ | 163,628 |  |

[0000936395-24-000032:notes:145]
[same as prior period, unchanged from 0000936395-24-000025:notes:149]

[0000936395-24-000032:notes:146]
[same as prior period, unchanged from 0000936395-24-000025:notes:150]

[0000936395-24-000032:notes:147]
|  | July 27,2024 |  | October 28,2023 |
| Canada | $ | 248,024 |  |  | $ | 229,707 |  |
| United States | 46,781 |  |  | 46,933 |  |
| Other International | 33,073 |  |  | 38,647 |  |
| Total | $ | 327,878 |  |  | $ | 315,287 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-24-000032:notes:148]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-24-000032:notes:149]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000032:notes:150]
Litigation

[0000936395-24-000032:notes:151]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000032:notes:152]
Purchase Order Obligations

[0000936395-24-000032:notes:153]
Ciena has certain advanced orders for supply of certain long lead time components. As of July 27, 2024, Ciena had $1.5 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.
