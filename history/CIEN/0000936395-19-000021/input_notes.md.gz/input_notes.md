# CIEN notes — 0000936395-19-000021


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-19-000021:notes:1]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2018 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-19-000021:notes:2]
[same as prior period, unchanged from 0000936395-19-000010:notes:183]

[0000936395-19-000021:notes:3]
[same as prior period, unchanged from 0000936395-19-000010:notes:184]

[0000936395-19-000021:notes:4]
Newly Issued Accounting Standards - Effective

[0000936395-19-000021:notes:5]
Revenue Recognition

[0000936395-19-000021:notes:6]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-19-000021:notes:7]
ASC 606 allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). Effective upon the start of its first quarter of fiscal 2019, Ciena adopted ASC 606 using the modified retrospective method and accordingly recognized the cumulative effect in accumulated deficit for those contracts that were not completed as of October 31, 2018. Accordingly, results for the reporting periods after October 31, 2018 are presented under ASC 606, while prior periods have not been adjusted and continue to be reported in accordance with Ciena’s historical revenue recognition practices. Refer to Opening Balance Adjustments below for the impact of ASC 606 adoption on Ciena’s Condensed Consolidated Financial Statements. In connection with its adoption of ASC 606, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 606.

[0000936395-19-000021:notes:8]
Revenue Recognition Timing Differences

[0000936395-19-000021:notes:9]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services. Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to

[0000936395-19-000021:notes:10]
such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-19-000021:notes:11]
Revenue Recognition Policy Under ASC 606

[0000936395-19-000021:notes:12]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration that Ciena expects to be entitled to in exchange for those products or services.

[0000936395-19-000021:notes:13]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-19-000021:notes:14]
•identification of the contract, or contracts, with a customer;

[0000936395-19-000021:notes:15]
•identification of the performance obligations in the contract;

[0000936395-19-000021:notes:16]
•determination of the transaction price;

[0000936395-19-000021:notes:17]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-19-000021:notes:18]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-19-000021:notes:19]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-19-000021:notes:20]
Purchase orders are invoiced based upon the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-19-000021:notes:21]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-19-000021:notes:22]
Significant Judgments

[0000936395-19-000021:notes:23]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-19-000021:notes:24]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-19-000021:notes:25]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-19-000021:notes:26]
Capitalized Contract Acquisition Costs

[0000936395-19-000021:notes:27]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-19-000021:notes:28]
For the additional disclosures required as part of ASC 606, see Note 3 below.

[0000936395-19-000021:notes:29]
Impact of ASC 606 Adoption

[0000936395-19-000021:notes:30]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statements of Operations (in millions):

[0000936395-19-000021:notes:31]
|  |  | Quarter Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 865,011 |  |  | $ | (14,219 | ) |  | $ | 850,792 |  |
| Total cost of goods sold |  | $ | 490,334 |  |  | $ | (13,436 | ) |  | $ | 476,898 |  |
| Net income |  | $ | 52,738 |  |  | $ | (467 | ) |  | $ | 52,271 |  |
| Diluted net income per potential common share |  | $ | 0.33 |  |  | $ | — |  |  | $ | 0.33 |  |

[0000936395-19-000021:notes:32]
|  |  | Six Months Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 1,643,538 |  |  | $ | (25,119 | ) |  | $ | 1,618,419 |  |
| Total cost of goods sold |  | $ | 945,520 |  |  | $ | (22,565 | ) |  | $ | 922,955 |  |
| Net income |  | $ | 86,354 |  |  | $ | (862 | ) |  | $ | 85,492 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.01 | ) |  | $ | 0.54 |  |

[0000936395-19-000021:notes:33]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of April 30, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

[0000936395-19-000021:notes:34]
Opening Balance Adjustments

[0000936395-19-000021:notes:35]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheets in connection with the adoption of ASC 606 (in millions):

[0000936395-19-000021:notes:36]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

[0000936395-19-000021:notes:37]
| (1) | Unpaid accounts receivable and related deferred revenue related to rights and obligations in a contract are interdependent and therefore recorded net within Ciena’s balance sheet. This represents an increase of $12.5 million from the reversal of certain net unpaid accounts receivable and related deferred revenue. |

[0000936395-19-000021:notes:38]
| (2) | Represents a decrease of $2.5 million in deferred costs of goods sold due to change in revenue recognition for certain product sales. |

[0000936395-19-000021:notes:39]
| (3) | Represents increases of $27.5 million in unbilled accounts receivable for change in recognizing revenue for installation services, $3.9 million in unbilled accounts receivable from change in recognizing revenue for certain product sales and $9.6 million related to short-term capitalized acquisition costs (e.g., commissions) and a decrease of $19.5 million related to prepaid cost of installation services. |

[0000936395-19-000021:notes:40]
| (4) | Represents a decrease of $14.4 million in deferred tax asset, net, related to the unrecognized income tax effects of the net adjustments from the new revenue recognition standard. |

[0000936395-19-000021:notes:41]
| (5) | Represents an increase of $4.0 million related to long-term capitalized acquisition costs (e.g., commissions). |

[0000936395-19-000021:notes:42]
| (6) | Represents decreases of $23.6 million in deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue, primarily due to a change in revenue recognition for certain product sales, and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

[0000936395-19-000021:notes:43]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

[0000936395-19-000021:notes:44]
| (8) | Accumulated deficit impact from the adjustments noted above. |

[0000936395-19-000021:notes:45]
Intangibles

[0000936395-19-000021:notes:46]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software, which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software.

[0000936395-19-000021:notes:47]
Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

[0000936395-19-000021:notes:48]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-19-000021:notes:49]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be recognized as assets and liabilities on Ciena’s balance sheet. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-19-000021:notes:50]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and disclosures.

[0000936395-19-000021:notes:51]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020 and early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-19-000021:notes:52]
[same as prior period, unchanged from 0000936395-19-000010:notes:143]

[0000936395-19-000021:notes:53]
[same as prior period, unchanged from 0000936395-19-000010:notes:144]

[0000936395-19-000021:notes:54]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-19-000021:notes:55]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:

[0000936395-19-000021:notes:56]
|  | Quarter Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 14,148 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 33,554 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

[0000936395-19-000021:notes:57]
|  | Six Months Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 36,420 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 67,854 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

[0000936395-19-000021:notes:58]
|  |  | Quarter Ended April 30, 2019 |  | Six Months Ended April 30, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 576,093 |  |  | $ | 1,061,599 |  |
| EMEA |  | 114,993 |  |  | 244,183 |  |
| CALA |  | 39,399 |  |  | 70,374 |  |
| APAC |  | 134,526 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 865,011 |  |  | $ | 1,643,538 |  |

[0000936395-19-000021:notes:59]
[same as prior period, unchanged from 0000936395-19-000010:notes:146]

[0000936395-19-000021:notes:60]
[same as prior period, unchanged from 0000936395-19-000010:notes:147]

[0000936395-19-000021:notes:61]
[same as prior period, unchanged from 0000936395-19-000010:notes:148]

[0000936395-19-000021:notes:62]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-19-000021:notes:63]
[same as prior period, unchanged from 0000936395-19-000010:notes:150]

[0000936395-19-000021:notes:64]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

[0000936395-19-000021:notes:65]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

[0000936395-19-000021:notes:66]
[same as prior period, unchanged from 0000936395-19-000010:notes:153]

[0000936395-19-000021:notes:67]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-19-000021:notes:68]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

[0000936395-19-000021:notes:69]
[same as prior period, unchanged from 0000936395-19-000010:notes:156]

[0000936395-19-000021:notes:70]
[same as prior period, unchanged from 0000936395-19-000010:notes:157]

[0000936395-19-000021:notes:71]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-19-000021:notes:72]
|  |  | Balance at April 30, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 756,607 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,439 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,022 |  |  | $ | 140,704 |  |

[0000936395-19-000021:notes:73]
[same as prior period, unchanged from 0000936395-19-000010:notes:158]

[0000936395-19-000021:notes:74]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $73.0 million of revenue during the first six months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial during the six months ended April 30, 2019.

[0000936395-19-000021:notes:75]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.2 million and $13.6 million as of April 30, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $8.4 million during the first six months of fiscal 2019 and was included in sales and marketing expense.

[0000936395-19-000021:notes:76]
[same as prior period, unchanged from 0000936395-19-000010:notes:161]

[0000936395-19-000021:notes:77]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2019, the aggregate amount of RPO was $1.28 billion. As of April 30, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-19-000021:notes:78]
[same as prior period, unchanged from 0000936395-19-000010:notes:134]

[0000936395-19-000021:notes:79]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2019 (in thousands):

[0000936395-19-000021:notes:80]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Additional liability recorded | 5,661 |  | (1) | 680 |  | (2) | 6,341 |  |
| Cash payments | (6,667 | ) |  | (847 | ) |  | (7,514 | ) |
| Balance at April 30, 2019 | $ | 1,102 |  |  | $ | 1,572 |  |  | $ | 2,674 |  |
| Current restructuring liabilities | $ | 1,102 |  |  | $ | 347 |  |  | $ | 1,449 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,225 |  |  | $ | 1,225 |  |

[0000936395-19-000021:notes:81]
| (1) | Reflects a global workforce reduction of approximately 95 employees during the six months ended April 30, 2019 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000021:notes:82]
| (2) | Reflects unfavorable lease commitments in connection with a portion of the facilities for certain locations in the United States and India where Ciena has vacated unused space. |

[0000936395-19-000021:notes:83]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2018 (in thousands):

[0000936395-19-000021:notes:84]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 8,232 |  | (1) | 2,088 |  | (2) | 10,320 |  |
| Cash payments | (8,211 | ) |  | (1,896 | ) |  | (10,107 | ) |
| Balance at April 30, 2018 | $ | 1,312 |  |  | $ | 1,840 |  |  | $ | 3,152 |  |
| Current restructuring liabilities | $ | 1,312 |  |  | $ | 865 |  |  | $ | 2,177 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 975 |  |  | $ | 975 |  |

[0000936395-19-000021:notes:85]
| (1) | Reflects a global workforce reduction of approximately 150 employees during fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000021:notes:86]
(2)
Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California where Ciena has vacated unused space.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-19-000021:notes:87]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-19-000021:notes:88]
[same as prior period, unchanged from 0000936395-19-000010:notes:127]

[0000936395-19-000021:notes:89]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income | $ | 3,519 |  |  | $ | 3,212 |  |  | $ | 7,391 |  |  | $ | 5,656 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (898 | ) |  | 2,868 |  |  | (877 | ) |  | 2,169 |  |
| Foreign currency exchange losses | (2,995 | ) |  | (4,804 | ) |  | (2,212 | ) |  | (4,791 | ) |
| Other | 130 |  |  | 20 |  |  | (293 | ) |  | (163 | ) |
| Interest and other income (loss), net | $ | (244 | ) |  | $ | 1,296 |  |  | $ | 4,009 |  |  | $ | 2,871 |  |

[0000936395-19-000021:notes:90]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $2.2 million and $4.8 million in foreign currency exchange rate losses during the first six months of fiscal 2019 and fiscal 2018, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the remeasurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These

[0000936395-19-000021:notes:91]
forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2019, Ciena recorded losses of $0.9 million from non-hedge designated foreign currency forward contracts. During the first six months of fiscal 2018, Ciena recorded gains of $2.2 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-19-000021:notes:92]
[same as prior period, unchanged from 0000936395-19-000010:notes:69]

[0000936395-19-000021:notes:93]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revised the U.S. corporate income tax laws by, among other things, lowering the statutory corporate income tax rate from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. The enactment of the Tax Act resulted in Ciena recording a provisional tax expense of $472.8 million in fiscal 2018.

[0000936395-19-000021:notes:94]
The effective tax rate for the second quarter and six months ended April 30, 2019 was lower than the effective tax rate for the second quarter and six months ended April 30, 2018, primarily due to the impact of the Tax Act. The reduction of the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018, required the remeasurement of the net deferred tax assets and liabilities (“DTA”). Also, Ciena recorded U.S. transition tax in the six months ended April 30, 2018.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-19-000021:notes:95]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-19-000021:notes:96]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-19-000021:notes:97]
|  | April 30, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
|  | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |

[0000936395-19-000021:notes:98]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

[0000936395-19-000021:notes:99]
The following table summarizes the final legal maturities of debt investments at April 30, 2019 (in thousands):

[0000936395-19-000021:notes:100]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 119,316 |  |  | $ | 119,327 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-19-000021:notes:101]
[same as prior period, unchanged from 0000936395-19-000010:notes:66]

[0000936395-19-000021:notes:102]
As of the date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-19-000021:notes:103]
|  | April 30, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 584,859 |  |  | $ | — |  |  | $ | — |  |  | $ | 584,859 |  |
| U.S. government obligations | — |  |  | 119,327 |  |  | — |  |  | 119,327 |  |
| Foreign currency forward contracts | — |  |  | 764 |  |  | — |  |  | 764 |  |
| Total assets measured at fair value | $ | 584,859 |  |  | $ | 120,091 |  |  | $ | — |  |  | $ | 704,950 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,630 |  |  | $ | — |  |  | $ | 3,630 |  |
| Forward starting interest rate swap | — |  |  | 10,927 |  |  | — |  |  | 10,927 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,557 |  |  | $ | 10,900 |  |  | $ | 25,457 |  |

[0000936395-19-000021:notes:104]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 590,684 |  |  | $ | — |  |  | $ | — |  |  | $ | 590,684 |  |
| U.S. government obligations | — |  |  | 197,988 |  |  | — |  |  | 197,988 |  |
| Commercial paper | — |  |  | 69,888 |  |  | — |  |  | 69,888 |  |
| Foreign currency forward contracts | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Forward starting interest rate swaps | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-19-000021:notes:105]
As of the date indicated, the assets and liabilities above are presented on Ciena’s Condensed Consolidated Balance Sheets as follows (in thousands):

[0000936395-19-000021:notes:106]
|  | April 30, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 584,859 |  |  | $ | — |  |  | $ | — |  |  | $ | 584,859 |  |
| Short-term investments | — |  |  | 119,327 |  |  | — |  |  | 119,327 |  |
| Prepaid expenses and other | — |  |  | 764 |  |  | — |  |  | 764 |  |
| Total assets measured at fair value | $ | 584,859 |  |  | $ | 120,091 |  |  | $ | — |  |  | $ | 704,950 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,630 |  |  | $ | 7,491 |  |  | $ | 11,121 |  |
| Other long-term obligations | — |  |  | 10,927 |  |  | 3,409 |  |  | 14,336 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,557 |  |  | $ | 10,900 |  |  | $ | 25,457 |  |

[0000936395-19-000021:notes:107]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 590,684 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 650,609 |  |
| Short-term investments | — |  |  | 148,981 |  |  | — |  |  | 148,981 |  |
| Prepaid expenses and other | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Long-term investments | — |  |  | 58,970 |  |  | — |  |  | 58,970 |  |
| Other long-term assets | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Other long-term obligations | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-19-000021:notes:108]
[same as prior period, unchanged from 0000936395-19-000010:notes:67]

[0000936395-19-000021:notes:109]
Ciena’s Level 3 liability is included in both accrued liabilities and other long-term obligations and reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. The contingent consideration is valued by applying the income approach based upon a discounted cash flow technique using Monte Carlo simulations. As of April 30, 2019, there was no material change to the fair value.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-19-000021:notes:110]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-19-000021:notes:111]
|  | April 30, 2019 |  | October 31, 2018 |
| Raw materials | $ | 90,317 |  |  | $ | 67,468 |  |
| Work-in-process | 11,986 |  |  | 9,589 |  |
| Finished goods | 205,440 |  |  | 188,575 |  |
| Deferred cost of goods sold | 100,637 |  |  | 48,057 |  |
|  | 408,380 |  |  | 313,689 |  |
| Provision for excess and obsolescence | (48,963 | ) |  | (50,938 | ) |
|  | $ | 359,417 |  |  | $ | 262,751 |  |

[0000936395-19-000021:notes:112]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2019, Ciena recorded a provision for excess and obsolescence of $10.2 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-19-000021:notes:113]
[same as prior period, unchanged from 0000936395-19-000010:notes:1]

[0000936395-19-000021:notes:114]
[same as prior period, unchanged from 0000936395-19-000010:notes:2]

[0000936395-19-000021:notes:115]
|  | April 30, 2019 |  | October 31, 2018 |
| Prepaid VAT and other taxes | $ | 77,788 |  |  | $ | 82,518 |  |
| Contract assets for unbilled accounts receivable | 74,439 |  |  | — |  |
| Product demonstration equipment, net | 39,323 |  |  | 37,623 |  |
| Prepaid expenses | 31,469 |  |  | 32,987 |  |
| Other non-trade receivables | 11,513 |  |  | 25,716 |  |
| Capitalized commissions - short term | 8,373 |  |  | — |  |
| Financing receivable | — |  |  | 626 |  |
| Deferred deployment expense | — |  |  | 19,342 |  |
| Derivative assets | 764 |  |  | 133 |  |
|  | $ | 243,669 |  |  | $ | 198,945 |  |

[0000936395-19-000021:notes:116]
Depreciation of product demonstration equipment was $4.3 million and $4.6 million first six months of fiscal 2019 and 2018, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-19-000021:notes:117]
ACCRUED LIABILITIES AND OTHER SHORT-TERM OBLIGATIONS
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-19-000021:notes:118]
|  | April 30, 2019 |  | October 31, 2018 |
| Compensation, payroll related tax and benefits (1) | $ | 94,235 |  |  | $ | 140,277 |  |
| Warranty | 44,907 |  |  | 44,740 |  |
| Vacation (2) | 21,648 |  |  | 42,507 |  |
| Contingent consideration | 7,491 |  |  | — |  |
| Capital lease obligations | 3,011 |  |  | 3,547 |  |
| Interest payable | 1,000 |  |  | 1,072 |  |
| Other | 119,125 |  |  | 107,932 |  |
|  | $ | 291,417 |  |  | $ | 340,075 |  |

[0000936395-19-000021:notes:119]
[same as prior period, unchanged from 0000936395-19-000010:notes:194]

[0000936395-19-000021:notes:120]
(2) Reduction is primarily due to the payout of North America vacation accruals in conjunction with adoption of a new vacation policy.

[0000936395-19-000021:notes:121]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal periods indicated (in thousands):

[0000936395-19-000021:notes:122]
| Six Months Ended April 30, |  | Beginning Balance |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| 2018 |  | $ | 42,456 |  |  | 10,565 |  |  | (9,629 | ) |  | $ | 43,392 |  |
| 2019 |  | $ | 44,740 |  |  | 9,276 |  |  | (9,109 | ) |  | $ | 44,907 |  |

[0000936395-19-000021:notes:123]
Settlement of Conversions of  3.75% Convertible Senior Notes due October 15, 2018 (“New Notes”)

[0000936395-19-000021:notes:124]
Debt Conversion Liability Associated With the New Notes

[0000936395-19-000021:notes:125]
[same as prior period, unchanged from 0000936395-19-000010:notes:197]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-19-000021:notes:126]
[same as prior period, unchanged from 0000936395-19-000010:notes:38]

[0000936395-19-000021:notes:127]
[same as prior period, unchanged from 0000936395-19-000010:notes:39]

[0000936395-19-000021:notes:128]
As of April 30, 2019 and October 31, 2018, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar- and Indian Rupee-denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $146.1 million and $163.2 million as of April 30, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-19-000021:notes:129]
During the first six months of fiscal 2019 and fiscal 2018, in order to hedge foreign exchange exposures of certain balance sheet items, Ciena entered into forward contracts to mitigate risk due to variability in various currencies. The notional amount of these contracts was approximately $164.8 million and $162.6 million as of April 30, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-19-000021:notes:130]
[same as prior period, unchanged from 0000936395-19-000010:notes:42]

[0000936395-19-000021:notes:131]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 14 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350 million of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of April 30, 2019 and October 31, 2018.

[0000936395-19-000021:notes:132]
[same as prior period, unchanged from 0000936395-19-000010:notes:44]

[0000936395-19-000021:notes:133]
[same as prior period, unchanged from 0000936395-19-000010:notes:45]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-19-000021:notes:134]
[same as prior period, unchanged from 0000936395-19-000010:notes:27]

[0000936395-19-000021:notes:135]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended April 30, 2019:

[0000936395-19-000021:notes:136]
|  | Unrealized |  | Unrealized Loss on |  | Unrealized Loss on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2018 | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |
| Other comprehensive income (loss) before reclassifications | 413 |  |  | (1,613 | ) |  | (10,013 | ) |  | (3,846 | ) |  | (15,059 | ) |
| Amounts reclassified from AOCI | — |  |  | 2,317 |  |  | (684 | ) |  | — |  |  | 1,633 |  |
| Balance at April 30, 2019 | $ | (12 | ) |  | $ | (2,356 | ) |  | $ | (4,280 | ) |  | $ | (12,558 | ) |  | $ | (19,206 | ) |

[0000936395-19-000021:notes:137]
The following table summarizes the changes in AOCI, net of tax, for the six months ended April 30, 2018:

[0000936395-19-000021:notes:138]
|  | Unrealized |  | Unrealized Losson |  | Unrealized Gain on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (337 | ) |  | (440 | ) |  | 4,725 |  |  | 1,069 |  |  | 5,017 |  |
| Amounts reclassified from AOCI | — |  |  | 405 |  |  | 523 |  |  | — |  |  | 928 |  |
| Balance at April 30, 2018 | $ | (788 | ) |  | $ | (1,421 | ) |  | $ | 5,466 |  |  | $ | (8,329 | ) |  | $ | (5,072 | ) |

[0000936395-19-000021:notes:139]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue and research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-19-000021:notes:140]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-19-000021:notes:141]
Outstanding Term Loan Payable

[0000936395-19-000021:notes:142]
2025 Term Loan

[0000936395-19-000021:notes:143]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-19-000021:notes:144]
|  |  | April 30, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 690,429 |  |  | $ | 693,450 |  |

[0000936395-19-000021:notes:145]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.9 million at April 30, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-19-000021:notes:146]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of April 30, 2019 (in thousands):

[0000936395-19-000021:notes:147]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 696,500 |  |  | $ | (2,129 | ) |  | $ | (3,942 | ) |  | $ | 690,429 |  |  | $ | 696,500 |  |

[0000936395-19-000021:notes:148]
(1)

[0000936395-19-000021:notes:149]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-19-000021:notes:150]
EARNINGS PER SHARE CALCULATION
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive:

[0000936395-19-000021:notes:151]
(i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-19-000021:notes:152]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net income (loss) | $ | 52,738 |  |  | $ | 13,856 |  |  | $ | 86,354 |  |  | $ | (459,507 | ) |

[0000936395-19-000021:notes:153]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Basic weighted average shares outstanding | 156,170 |  |  | 143,975 |  |  | 156,244 |  |  | 143,948 |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 2,119 |  |  | 1,345 |  |  | 1,967 |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New) | — |  |  | 2,653 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 158,289 |  |  | 147,973 |  |  | 158,211 |  |  | 143,948 |  |

[0000936395-19-000021:notes:154]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Basic EPS | $ | 0.34 |  |  | $ | 0.10 |  |  | $ | 0.55 |  |  | $ | (3.19 | ) |
| Diluted EPS | $ | 0.33 |  |  | $ | 0.09 |  |  | $ | 0.55 |  |  | $ | (3.19 | ) |

[0000936395-19-000021:notes:155]
[same as prior period, unchanged from 0000936395-19-000010:notes:58]

[0000936395-19-000021:notes:156]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Shares underlying stock options and stock unit awards | 283 |  |  | 304 |  |  | 257 |  |  | 2,496 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) | — |  |  | 3,038 |  |  | — |  |  | 3,038 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) | — |  |  | — |  |  | — |  |  | 1,672 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 9,198 |  |  | — |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 283 |  |  | 12,540 |  |  | 257 |  |  | 16,404 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-19-000021:notes:157]
[same as prior period, unchanged from 0000936395-19-000010:notes:185]

[0000936395-19-000021:notes:158]
[same as prior period, unchanged from 0000936395-19-000010:notes:186]

[0000936395-19-000021:notes:159]
[same as prior period, unchanged from 0000936395-19-000010:notes:187]

[0000936395-19-000021:notes:160]
A summary of the stock repurchase program, reported based on trade date, is summarized as follows:

[0000936395-19-000021:notes:161]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2018 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 1,752,525 |  |  | 37.97 |  |  | 66,544 |  |
| Cumulative balance at April 30, 2019 | 1,752,525 |  |  | $ | 37.97 |  |  | $ | 66,544 |  |

[0000936395-19-000021:notes:162]
[same as prior period, unchanged from 0000936395-19-000010:notes:188]

[0000936395-19-000021:notes:163]
[same as prior period, unchanged from 0000936395-19-000010:notes:189]

[0000936395-19-000021:notes:164]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The purchase price of $15.9 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2019 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-19-000021:notes:165]
[same as prior period, unchanged from 0000936395-19-000010:notes:49]

[0000936395-19-000021:notes:166]
[same as prior period, unchanged from 0000936395-19-000010:notes:50]

[0000936395-19-000021:notes:167]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Product costs | $ | 702 |  |  | $ | 824 |  |  | $ | 1,339 |  |  | $ | 1,496 |  |
| Service costs | 907 |  |  | 722 |  |  | 1,677 |  |  | 1,346 |  |
| Share-based compensation expense included in cost of sales | 1,609 |  |  | 1,546 |  |  | 3,016 |  |  | 2,842 |  |
| Research and development | 4,083 |  |  | 3,796 |  |  | 7,474 |  |  | 7,052 |  |
| Sales and marketing | 4,346 |  |  | 3,760 |  |  | 8,131 |  |  | 7,088 |  |
| General and administrative | 5,491 |  |  | 5,109 |  |  | 10,603 |  |  | 9,583 |  |
| Share-based compensation expense included in operating expense | 13,920 |  |  | 12,665 |  |  | 26,208 |  |  | 23,723 |  |
| Share-based compensation expense capitalized in inventory, net | 78 |  |  | (45 | ) |  | 138 |  |  | (6 | ) |
| Total share-based compensation | $ | 15,607 |  |  | $ | 14,166 |  |  | $ | 29,362 |  |  | $ | 26,559 |  |

[0000936395-19-000021:notes:168]
As of April 30, 2019, total unrecognized share-based compensation expense was approximately $110.7 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-19-000021:notes:169]
SEGMENTS AND ENTITY-WIDE DISCLOSURES
Segment Reporting

[0000936395-19-000021:notes:170]
[same as prior period, unchanged from 0000936395-19-000010:notes:174]

[0000936395-19-000021:notes:171]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2019, equipment, building, furniture and fixtures, net totaled $282.0 million, primarily supporting asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and supporting Ciena’s unallocated selling and general and administrative activities. As of April 30, 2019, $25.0 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Networking Platforms segment and $105.0 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of April 30, 2019, $65.5 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Networking Platforms segment and $232.2 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of April 30, 2019, all of the maintenance spares, net, totaling $50.9 million, were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-19-000021:notes:172]
[same as prior period, unchanged from 0000936395-19-000010:notes:176]

[0000936395-19-000021:notes:173]
The table below (in thousands) sets forth Ciena’s segment revenue for the respective periods:

[0000936395-19-000021:notes:174]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | 527,867 |  |  | $ | 1,172,835 |  |  | $ | 955,297 |  |
| Packet Networking | 73,138 |  |  | 63,815 |  |  | 144,707 |  |  | 132,418 |  |
| Total Networking Platforms | 696,976 |  |  | 591,682 |  |  | 1,317,542 |  |  | 1,087,715 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Platform Software and Services | 35,229 |  |  | 36,393 |  |  | 76,827 |  |  | 80,529 |  |
| Blue Planet Automation Software and Services | 12,473 |  |  | 2,352 |  |  | 27,447 |  |  | 11,703 |  |
| Total Software and Software-Related Services | 47,702 |  |  | 38,745 |  |  | 104,274 |  |  | 92,232 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 68,788 |  |  | 60,904 |  |  | 130,065 |  |  | 116,862 |  |
| Installation and Deployment | 41,322 |  |  | 28,209 |  |  | 71,944 |  |  | 58,225 |  |
| Consulting and Network Design | 10,223 |  |  | 10,438 |  |  | 19,713 |  |  | 21,079 |  |
| Total Global Services | 120,333 |  |  | 99,551 |  |  | 221,722 |  |  | 196,166 |  |
| Consolidated revenue | $ | 865,011 |  |  | $ | 729,978 |  |  | $ | 1,643,538 |  |  | $ | 1,376,113 |  |

[0000936395-19-000021:notes:175]
[same as prior period, unchanged from 0000936395-19-000010:notes:177]

[0000936395-19-000021:notes:176]
Segment profit is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets;  significant asset impairments and restructuring costs; acquisition and integration costs; interest and other income (loss), net; interest expense; and provision for income taxes.

[0000936395-19-000021:notes:177]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-19-000021:notes:178]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 175,191 |  |  | $ | 126,823 |  |  | $ | 311,782 |  |  | $ | 215,392 |  |
| Software and Software-Related Services | 6,536 |  |  | 8,276 |  |  | 24,952 |  |  | 31,911 |  |
| Global Services | 54,981 |  |  | 41,284 |  |  | 94,682 |  |  | 82,321 |  |
| Total segment profit | 236,708 |  |  | 176,383 |  |  | 431,416 |  |  | 329,624 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 103,502 |  |  | 97,359 |  |  | 201,615 |  |  | 185,874 |  |
| General and administrative | 42,154 |  |  | 38,976 |  |  | 81,397 |  |  | 77,382 |  |
| Amortization of intangible assets | 5,529 |  |  | 3,623 |  |  | 11,057 |  |  | 7,246 |  |
| Significant asset impairments and restructuring costs | 4,068 |  |  | 4,359 |  |  | 6,341 |  |  | 10,320 |  |
| Acquisition and integration costs | 1,135 |  |  | — |  |  | 2,743 |  |  | — |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (9,715 | ) |  | (11,735 | ) |  | (14,903 | ) |  | (23,894 | ) |
| Less: Provision for income taxes | 17,867 |  |  | 6,475 |  |  | 27,006 |  |  | 484,415 |  |
| Consolidated net income (loss) | $ | 52,738 |  |  | $ | 13,856 |  |  | $ | 86,354 |  |  | $ | (459,507 | ) |

[0000936395-19-000021:notes:179]
[same as prior period, unchanged from 0000936395-19-000010:notes:179]

[0000936395-19-000021:notes:180]
Ciena’s revenue includes $545.6 million and $392.8 million of United States revenue for the second quarter of fiscal 2019 and 2018, respectively. For the six months ended April 30, 2019 and 2018, United States revenue was $1.01 billion and $776.1 million, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-19-000021:notes:181]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-19-000021:notes:182]
|  | April 30, 2019 |  | October 31, 2018 |
| Canada | $ | 196,069 |  |  | $ | 198,028 |  |
| United States | 67,633 |  |  | 75,479 |  |
| Other International | 18,320 |  |  | 18,560 |  |
| Total | $ | 282,022 |  |  | $ | 292,067 |  |

[0000936395-19-000021:notes:183]
For the periods below, AT&T, Verizon and a Web-scale provider were the only customers that accounted for at least 10% of Ciena’s revenue as follows (in thousands):

[0000936395-19-000021:notes:184]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| AT&T | $ | 108,416 |  |  | $ | 85,419 |  |  | $ | 202,587 |  |  | $ | 176,065 |  |
| Verizon | 106,350 |  |  | n/a |  |  | 195,125 |  |  | n/a |  |
| Web-scale provider | n/a |  |  | n/a |  |  | 174,853 |  |  | n/a |  |
| Total | $ | 214,766 |  |  | $ | 85,419 |  |  | $ | 572,565 |  |  | $ | 176,065 |  |

[0000936395-19-000021:notes:185]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-19-000021:notes:186]
[same as prior period, unchanged from 0000936395-19-000010:notes:182]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-19-000021:notes:187]
COMMITMENTS AND CONTINGENCIES

[0000936395-19-000021:notes:188]
Canadian Grant

[0000936395-19-000021:notes:189]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $42.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2019, Ciena has recorded CAD$23.1 million (approximately $17.2 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.5 million (approximately $4.9 million) was recorded in the first six months of fiscal 2019. As of April 30, 2019, amounts receivable from this grant were CAD$7.9 million (approximately $5.9 million).

[0000936395-19-000021:notes:190]
Tax Contingencies

[0000936395-19-000021:notes:191]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-19-000021:notes:192]
Litigation

[0000936395-19-000021:notes:193]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement is subject to notice to class members and approval by the court. The terms of the proposed settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to the Ciena’s financial results. There is no assurance that the court will ultimately approve the settlement.

[0000936395-19-000021:notes:194]
Internal Investigation

[0000936395-19-000021:notes:195]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it has declined to prosecute this matter and that its investigation into the matter is now closed. Ciena continues to cooperate fully with the SEC in its investigation into this matter.

[0000936395-19-000021:notes:196]
Ciena’s operations in the relevant country constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year from 2012 through 2017. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-19-000021:notes:197]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that

[0000936395-19-000021:notes:198]
the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-19-000021:notes:199]
SUBSEQUENT EVENTS

[0000936395-19-000021:notes:200]
From the end of the second quarter of fiscal 2019 through June 7, 2019, Ciena repurchased an additional 485,235 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $35.63 per share, inclusive of repurchases pending settlement. As of June 7, 2019, Ciena has repurchased an aggregate of 2,237,760 shares and has an aggregate of $416.2 million of authorized funds remaining under its Stock Repurchase Program.
