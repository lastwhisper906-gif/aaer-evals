# CIEN note change history — 0000936395-19-000010 → 0000936395-19-000021


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $42.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2019, Ciena has recorded CAD$23.1 million (approximately $17.2 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.5 million (approximately $4.9 million) was recorded in the first six months of fiscal 2019. As of April 30, 2019, amounts receivable from this grant were CAD$7.9 million (approximately $5.9 million).
  (was, 2019-03-11, similarity 0.9445):
[0000936395-19-000010:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $44.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2019, Ciena recorded a CAD$19.1 million (approximately $14.8 million) benefit as a reduction in research and development expense of which CAD$2.5 million (approximately $1.9 million) was recorded in the first three months of fiscal 2019. As of January 31, 2019, amounts receivable from this grant were CAD$10.1 million (approximately $7.7 million).

- changed (2019-06-12):
[0000936395-19-000021:note_history:2]
Tax Contingencies
  (was, 2019-03-11, similarity 0.8095):
[0000936395-19-000010:note_history:2]
Foreign Tax Contingencies

- changed (2019-06-12):
[0000936395-19-000021:note_history:3]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that
  (was, 2019-03-11, similarity 0.8813):
[0000936395-19-000010:note_history:3]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

- added (2019-06-12):
[0000936395-19-000021:note_history:4]
the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:5]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2018 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.
  (was, 2019-03-11, similarity 0.8428):
[0000936395-19-000010:note_history:5]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2018 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.

- removed (2019-06-12):
[0000936395-19-000010:note_history:6]
INTERIM FINANCIAL STATEMENTS

- removed (2019-06-12):
[0000936395-19-000010:note_history:7]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-06-12):
[0000936395-19-000021:note_history:8]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services. Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to

- changed (2019-06-12):
[0000936395-19-000021:note_history:9]
such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.
  (was, 2019-03-11, similarity 0.8354):
[0000936395-19-000010:note_history:9]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services.  Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

- changed (2019-06-12):
[0000936395-19-000021:note_history:10]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.
  (was, 2019-03-11, similarity 0.9963):
[0000936395-19-000010:note_history:10]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

- added (2019-06-12):
[0000936395-19-000021:note_history:11]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- added (2019-06-12):
[0000936395-19-000021:note_history:12]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

- changed (2019-06-12):
[0000936395-19-000021:note_history:13]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.
  (was, 2019-03-11, similarity 0.9997):
[0000936395-19-000010:note_history:13]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services, with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

- changed (2019-06-12):
[0000936395-19-000021:note_history:14]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statements of Operations (in millions):
  (was, 2019-03-11, similarity 0.9962):
[0000936395-19-000010:note_history:14]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statement of Operations (in millions):

- added (2019-06-12):
[0000936395-19-000021:note_history:15]
|  |  | Quarter Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 865,011 |  |  | $ | (14,219 | ) |  | $ | 850,792 |  |
| Total cost of goods sold |  | $ | 490,334 |  |  | $ | (13,436 | ) |  | $ | 476,898 |  |
| Net income |  | $ | 52,738 |  |  | $ | (467 | ) |  | $ | 52,271 |  |
| Diluted net income per potential common share |  | $ | 0.33 |  |  | $ | — |  |  | $ | 0.33 |  |

- added (2019-06-12):
[0000936395-19-000021:note_history:16]
|  |  | Six Months Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 1,643,538 |  |  | $ | (25,119 | ) |  | $ | 1,618,419 |  |
| Total cost of goods sold |  | $ | 945,520 |  |  | $ | (22,565 | ) |  | $ | 922,955 |  |
| Net income |  | $ | 86,354 |  |  | $ | (862 | ) |  | $ | 85,492 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.01 | ) |  | $ | 0.54 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:17]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of April 30, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.
  (was, 2019-03-11, similarity 0.9877):
[0000936395-19-000010:note_history:17]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheet or any impact on net cash provided by operating activities as of January 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

- changed (2019-06-12):
[0000936395-19-000021:note_history:18]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheets in connection with the adoption of ASC 606 (in millions):
  (was, 2019-03-11, similarity 0.9972):
[0000936395-19-000010:note_history:18]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 606 (in millions):

- changed (2019-06-12):
[0000936395-19-000021:note_history:19]
| (6) | Represents decreases of $23.6 million in deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue, primarily due to a change in revenue recognition for certain product sales, and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |
  (was, 2019-03-11, similarity 0.9971):
[0000936395-19-000010:note_history:19]
| (6) | Represents decreases of $23.6 million in deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue primarily due to a change in revenue recognition for certain product sales and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

- changed (2019-06-12):
[0000936395-19-000021:note_history:20]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |
  (was, 2019-03-11, similarity 0.9986):
[0000936395-19-000010:note_history:20]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

- changed (2019-06-12):
[0000936395-19-000021:note_history:21]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software, which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software.
  (was, 2019-03-11, similarity 0.7852):
[0000936395-19-000010:note_history:21]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

- added (2019-06-12):
[0000936395-19-000021:note_history:22]
Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

- changed (2019-06-12):
[0000936395-19-000021:note_history:23]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be recognized as assets and liabilities on Ciena’s balance sheet. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.
  (was, 2019-03-11, similarity 0.7172):
[0000936395-19-000010:note_history:23]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

- added (2019-06-12):
[0000936395-19-000021:note_history:24]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and disclosures.

- changed (2019-06-12):
[0000936395-19-000021:note_history:25]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020 and early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.
  (was, 2019-03-11, similarity 0.9947):
[0000936395-19-000010:note_history:25]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

- removed (2019-06-12):
[0000936395-19-000010:note_history:26]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price that Ciena would expect to sell that product or service on a stand alone basis at contract inception and be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- removed (2019-06-12):
[0000936395-19-000010:note_history:27]
Ciena applies judgment in determining the transaction price as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

- removed (2019-06-12):
[0000936395-19-000010:note_history:28]
|  |  | Quarter Ended January 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 778,527 |  |  | $ | (10,900 | ) |  | $ | 767,627 |  |
| Total cost of goods sold |  | $ | 455,186 |  |  | $ | (9,129 | ) |  | $ | 446,057 |  |
| Net income |  | $ | 33,616 |  |  | $ | (399 | ) |  | $ | 33,217 |  |
| Diluted net income per potential common share |  | $ | 0.21 |  |  | $ | — |  |  | $ | 0.21 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:29]
|  |  | April 30, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 690,429 |  |  | $ | 693,450 |  |
  (was, 2019-03-11, similarity 0.9592):
[0000936395-19-000010:note_history:29]
|  |  | January 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 691,939 |  |  | $ | 693,450 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:30]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.9 million at April 30, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2019-03-11, similarity 0.9833):
[0000936395-19-000010:note_history:30]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $4.1 million at January 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2019-06-12):
[0000936395-19-000021:note_history:31]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of April 30, 2019 (in thousands):
  (was, 2019-03-11, similarity 0.9779):
[0000936395-19-000010:note_history:31]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of January 31, 2019 (in thousands):

- added (2019-06-12):
[0000936395-19-000021:note_history:32]
(1)

- changed (2019-06-12):
[0000936395-19-000021:note_history:33]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.
  (was, 2019-03-11, similarity 0.9798):
[0000936395-19-000010:note_history:33]
| (1) | The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:34]
|  | April 30, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
|  | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
  (was, 2019-03-11, similarity 0.9532):
[0000936395-19-000010:note_history:34]
|  | January 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,245 |  |  | $ | — |  |  | (102 | ) |  | $ | 119,143 |  |
|  | $ | 119,245 |  |  | $ | — |  |  | $ | (102 | ) |  | $ | 119,143 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:35]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
  (was, 2019-03-11, similarity 0.854):
[0000936395-19-000010:note_history:35]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | — |  |  | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:36]
|  | April 30, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
|  | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
  (was, 2019-03-11, similarity 0.9532):
[0000936395-19-000010:note_history:36]
|  | January 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,245 |  |  | $ | — |  |  | (102 | ) |  | $ | 119,143 |  |
|  | $ | 119,245 |  |  | $ | — |  |  | $ | (102 | ) |  | $ | 119,143 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:37]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
  (was, 2019-03-11, similarity 0.854):
[0000936395-19-000010:note_history:37]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | — |  |  | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:38]
The following table summarizes the final legal maturities of debt investments at April 30, 2019 (in thousands):
  (was, 2019-03-11, similarity 0.9626):
[0000936395-19-000010:note_history:38]
The following table summarizes the final legal maturities of debt investments at January 31, 2019 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:39]
|  |  | April 30, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 690,429 |  |  | $ | 693,450 |  |
  (was, 2019-03-11, similarity 0.9592):
[0000936395-19-000010:note_history:39]
|  |  | January 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 691,939 |  |  | $ | 693,450 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:40]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of April 30, 2019 (in thousands):
  (was, 2019-03-11, similarity 0.9779):
[0000936395-19-000010:note_history:40]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of January 31, 2019 (in thousands):

- added (2019-06-12):
[0000936395-19-000021:note_history:41]
(1)

- changed (2019-06-12):
[0000936395-19-000021:note_history:42]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.
  (was, 2019-03-11, similarity 0.9798):
[0000936395-19-000010:note_history:42]
| (1) | The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:43]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:
  (was, 2019-03-11, similarity 0.9949):
[0000936395-19-000010:note_history:43]
The tables below (in thousands) sets forth Ciena’s disaggregated revenue for the respective period:

- changed (2019-06-12):
[0000936395-19-000021:note_history:44]
|  | Quarter Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 14,148 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 33,554 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
  (was, 2019-03-11, similarity 0.9941):
[0000936395-19-000010:note_history:44]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 22,272 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 34,300 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2019-06-12):
[0000936395-19-000021:note_history:45]
|  | Six Months Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 36,420 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 67,854 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:46]
|  |  | Quarter Ended April 30, 2019 |  | Six Months Ended April 30, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 576,093 |  |  | $ | 1,061,599 |  |
| EMEA |  | 114,993 |  |  | 244,183 |  |
| CALA |  | 39,399 |  |  | 70,374 |  |
| APAC |  | 134,526 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 865,011 |  |  | $ | 1,643,538 |  |
  (was, 2019-03-11, similarity 0.8057):
[0000936395-19-000010:note_history:46]
|  |  | Quarter Ended January 31, 2019 |
| Geographic distribution: |  |  |
| North America |  | $ | 485,506 |  |
| EMEA |  | 129,190 |  |
| CALA |  | 30,975 |  |
| APAC |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 778,527 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:47]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.
  (was, 2019-03-11, similarity 0.986):
[0000936395-19-000010:note_history:47]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

- changed (2019-06-12):
[0000936395-19-000021:note_history:48]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:
  (was, 2019-03-11, similarity 0.9949):
[0000936395-19-000010:note_history:48]
The tables below (in thousands) sets forth Ciena’s disaggregated revenue for the respective period:

- changed (2019-06-12):
[0000936395-19-000021:note_history:49]
|  | Quarter Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 14,148 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 33,554 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
  (was, 2019-03-11, similarity 0.9941):
[0000936395-19-000010:note_history:49]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 22,272 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 34,300 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2019-06-12):
[0000936395-19-000021:note_history:50]
|  | Six Months Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 36,420 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 67,854 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:51]
|  |  | Quarter Ended April 30, 2019 |  | Six Months Ended April 30, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 576,093 |  |  | $ | 1,061,599 |  |
| EMEA |  | 114,993 |  |  | 244,183 |  |
| CALA |  | 39,399 |  |  | 70,374 |  |
| APAC |  | 134,526 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 865,011 |  |  | $ | 1,643,538 |  |
  (was, 2019-03-11, similarity 0.8057):
[0000936395-19-000010:note_history:51]
|  |  | Quarter Ended January 31, 2019 |
| Geographic distribution: |  |  |
| North America |  | $ | 485,506 |  |
| EMEA |  | 129,190 |  |
| CALA |  | 30,975 |  |
| APAC |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 778,527 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:52]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.
  (was, 2019-03-11, similarity 0.999):
[0000936395-19-000010:note_history:52]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- changed (2019-06-12):
[0000936395-19-000021:note_history:53]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |
  (was, 2019-03-11, similarity 0.7229):
[0000936395-19-000010:note_history:53]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design. Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver. Services includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

- changed (2019-06-12):
[0000936395-19-000021:note_history:54]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |
  (was, 2019-03-11, similarity 0.7375):
[0000936395-19-000010:note_history:54]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

- changed (2019-06-12):
[0000936395-19-000021:note_history:55]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2019-03-11, similarity 0.9888):
[0000936395-19-000010:note_history:55]
Ciena’s software platform revenue typically reflects either a perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, build-operate-transfer services relating to our software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2019-06-12):
[0000936395-19-000021:note_history:56]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |
  (was, 2019-03-11, similarity 0.9983):
[0000936395-19-000010:note_history:56]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

- changed (2019-06-12):
[0000936395-19-000021:note_history:57]
|  |  | Balance at April 30, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 756,607 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,439 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,022 |  |  | $ | 140,704 |  |
  (was, 2019-03-11, similarity 0.9712):
[0000936395-19-000010:note_history:57]
|  |  | Balance at January 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 761,186 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 47,542 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 136,141 |  |  | $ | 140,704 |  |

- changed (2019-06-12):
[0000936395-19-000021:note_history:58]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $73.0 million of revenue during the first six months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial during the six months ended April 30, 2019.
  (was, 2019-03-11, similarity 0.9299):
[0000936395-19-000010:note_history:58]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $39.4 million of revenue during the first three months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial in the first quarter of fiscal 2019.

- changed (2019-06-12):
[0000936395-19-000021:note_history:59]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.2 million and $13.6 million as of April 30, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $8.4 million during the first six months of fiscal 2019 and was included in sales and marketing expense.
  (was, 2019-03-11, similarity 0.9735):
[0000936395-19-000010:note_history:59]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.4 million and $13.6 million as of January 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $4.1 million during the first three months of fiscal 2019 and was included in sales and marketing expense.

- changed (2019-06-12):
[0000936395-19-000021:note_history:60]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2019, the aggregate amount of RPO was $1.28 billion. As of April 30, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2019-03-11, similarity 0.97):
[0000936395-19-000010:note_history:60]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2019, the aggregate amount of RPO was $1.07 billion. As of January 31, 2019, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-06-12):
[0000936395-19-000021:note_history:61]
From the end of the second quarter of fiscal 2019 through June 7, 2019, Ciena repurchased an additional 485,235 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $35.63 per share, inclusive of repurchases pending settlement. As of June 7, 2019, Ciena has repurchased an aggregate of 2,237,760 shares and has an aggregate of $416.2 million of authorized funds remaining under its Stock Repurchase Program.
  (was, 2019-03-11, similarity 0.9652):
[0000936395-19-000010:note_history:61]
From the end of the first quarter of fiscal 2019 through March 6, 2019, Ciena repurchased an additional 390,902 shares of its common stock, for an aggregate purchase price of $15.8 million at an average price of $40.54 per share, inclusive of repurchases pending settlement. As of March 6, 2019, Ciena has repurchased an aggregate of 982,799 shares and has an aggregate of $463.0 million of authorized funds remaining under its Stock Repurchase Program.
