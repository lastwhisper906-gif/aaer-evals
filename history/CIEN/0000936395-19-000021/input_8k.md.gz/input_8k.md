# CIEN 8-K — 0000936395-19-000017 filed 2019-06-06

## item codes, every 8-K on or before 2019-06-12

- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2019-06-12

- none on or before 2019-06-12

## item 2.02 — earnings release, exhibit 99.1

[0000936395-19-000017:8k_2_02:1]
EX-99.1
2
ex991-2019q2earningspressr.htm
EXHIBIT 99.1

[0000936395-19-000017:8k_2_02:2]
Exhibit

[0000936395-19-000017:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-19-000017:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2019 Financial Results

[0000936395-19-000017:8k_2_02:5]
HANOVER, Md. - June 6, 2019 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal second quarter ended April 30, 2019.

[0000936395-19-000017:8k_2_02:6]
| • | Q2 Revenue: $865.0 million, increasing 18.5% year over year |

[0000936395-19-000017:8k_2_02:7]
| • | Q2 Net Income per Share: $0.33 GAAP; $0.48 adjusted (non-GAAP) |

[0000936395-19-000017:8k_2_02:8]
| • | Share Repurchases: Repurchased approximately 1.2 million shares of common stock for an aggregate price of $45.4 million during the quarter |

[0000936395-19-000017:8k_2_02:9]
"Today we reported very strong quarterly performance, including continued market share gains, driven by our technology leadership and diversified customer base in high growth markets," said Gary Smith, President and CEO, Ciena. "We are entering the second half with strong visibility and increased confidence for the full fiscal year supported by favorable industry dynamics and growing competitive advantage."

[0000936395-19-000017:8k_2_02:10]
For the fiscal second quarter 2019, Ciena reported revenue of $865.0 million as compared to $730.0 million for the fiscal second quarter 2018.

[0000936395-19-000017:8k_2_02:11]
Ciena's GAAP net income for the fiscal second quarter 2019 was $52.7 million, or $0.33 per diluted common share, which compares to a GAAP net income of $13.9 million, or $0.09 per diluted common share, for the fiscal second quarter 2018.

[0000936395-19-000017:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2019 was $76.2 million, or $0.48 per diluted common share, which compares to an adjusted (non-GAAP) net income of $33.8 million, or $0.23 per diluted common share, for the fiscal second quarter 2018.

[0000936395-19-000017:8k_2_02:13]
Fiscal Second Quarter 2019 Performance Summary

[0000936395-19-000017:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendix A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-19-000017:8k_2_02:15]
|  |  | GAAP Results |
|  |  | Q2 |  | Q2 |  |  |
|  |  | FY 2019 |  | FY 2018 |  | Y-T-Y* |
| Revenue |  | $ | 865.0 |  |  | $ | 730.0 |  |  | 18.5 | % |
| Gross margin |  | 43.3 | % |  | 40.2 | % |  | 3.1 | % |
| Operating expense |  | $ | 294.4 |  |  | $ | 261.2 |  |  | 12.7 | % |
| Operating margin |  | 9.3 | % |  | 4.4 | % |  | 4.9 | % |

[0000936395-19-000017:8k_2_02:16]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q2 |  |  |
|  |  | FY 2019 |  | FY 2018 |  | Y-T-Y* |
| Revenue |  | $ | 865.0 |  |  | $ | 730.0 |  |  | 18.5 | % |
| Adj. gross margin |  | 43.9 | % |  | 40.7 | % |  | 3.2 | % |
| Adj. operating expense |  | $ | 269.7 |  |  | $ | 240.6 |  |  | 12.1 | % |
| Adj. operating margin |  | 12.7 | % |  | 7.7 | % |  | 5.0 | % |

[0000936395-19-000017:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-19-000017:8k_2_02:18]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2019 |  | Q2 FY 2018 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 623.9 |  |  | 72.1 |  | $ | 527.9 |  |  | 72.4 |
| Packet Networking |  | 73.1 |  |  | 8.5 |  | 63.8 |  |  | 8.7 |
| Total Networking Platforms |  | 697.0 |  |  | 80.6 |  | 591.7 |  |  | 81.1 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |
| Platform Software and Services |  | 35.2 |  |  | 4.0 |  | 36.4 |  |  | 5.0 |
| Blue Planet Automation Software and Services |  | 12.5 |  |  | 1.4 |  | 2.3 |  |  | 0.3 |
| Total Software and Software-Related Services |  | 47.7 |  |  | 5.4 |  | 38.7 |  |  | 5.3 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 68.8 |  |  | 8.0 |  | 60.9 |  |  | 8.3 |
| Installation and Deployment |  | 41.3 |  |  | 4.8 |  | 28.2 |  |  | 3.9 |
| Consulting and Network Design |  | 10.2 |  |  | 1.2 |  | 10.5 |  |  | 1.4 |
| Total Global Services |  | 120.3 |  |  | 14.0 |  | 99.6 |  |  | 13.6 |
| Total |  | $ | 865.0 |  |  | 100.0 |  | $ | 730.0 |  |  | 100.0 |

[0000936395-19-000017:8k_2_02:19]
Additional Performance Metrics for Fiscal Second Quarter 2019

[0000936395-19-000017:8k_2_02:20]
|  |  | Revenue by Geographic Region |
|  |  | Q2 FY 2019 |  | Q2 FY 2018 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 576.1 |  |  | 66.5 |  | $ | 431.2 |  |  | 59.1 |
| Europe, Middle East and Africa |  | 115.0 |  |  | 13.3 |  | 121.7 |  |  | 16.7 |
| Caribbean and Latin America |  | 39.4 |  |  | 4.6 |  | 25.1 |  |  | 3.4 |
| Asia Pacific |  | 134.5 |  |  | 15.6 |  | 152.0 |  |  | 20.8 |
| Total |  | $ | 865.0 |  |  | 100.0 |  | $ | 730.0 |  |  | 100.0 |

[0000936395-19-000017:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-19-000017:8k_2_02:22]
| • | Two 10%-plus customers represented a total of 25% of revenue |

[0000936395-19-000017:8k_2_02:23]
| • | Cash and investments totaled $818.5 million |

[0000936395-19-000017:8k_2_02:24]
| • | Cash flow from operations totaled $104.1 million |

[0000936395-19-000017:8k_2_02:25]
| • | Average days' sales outstanding (DSOs) were 86 |

[0000936395-19-000017:8k_2_02:26]
| • | Accounts receivable balance was $756.6 million |

[0000936395-19-000017:8k_2_02:27]
| • | Unbilled contract asset balance was $74.4 million |

[0000936395-19-000017:8k_2_02:28]
| • | Inventories totaled $359.4 million, including: |

[0000936395-19-000017:8k_2_02:29]
| ◦ | Raw materials: $90.3 million |

[0000936395-19-000017:8k_2_02:30]
| ◦ | Work in process: $12.0 million |

[0000936395-19-000017:8k_2_02:31]
| ◦ | Finished goods: $205.4 million |

[0000936395-19-000017:8k_2_02:32]
| ◦ | Deferred cost of sales: $100.6 million |

[0000936395-19-000017:8k_2_02:33]
| ◦ | Reserve for excess and obsolescence: $(48.9) million |

[0000936395-19-000017:8k_2_02:34]
| • | Product inventory turns were 4.6 |

[0000936395-19-000017:8k_2_02:35]
| • | Headcount totaled 6,176 |

[0000936395-19-000017:8k_2_02:36]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Second Quarter 2019 Results

[0000936395-19-000017:8k_2_02:37]
Today, Thursday, June 6, 2019, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website an accompanying investor presentation for its unaudited fiscal second quarter 2019 results.

[0000936395-19-000017:8k_2_02:38]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-19-000017:8k_2_02:39]
Notes to Investors

[0000936395-19-000017:8k_2_02:40]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or

[0000936395-19-000017:8k_2_02:41]
similar words. Forward-looking statements in this release include: “Today we reported very strong quarterly performance, including continued market share gains, driven by our technology leadership and diversified customer base in high growth markets"; "We are entering the second half with strong visibility and increased confidence for the full fiscal year supported by favorable industry dynamics and growing competitive advantage.”

[0000936395-19-000017:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs and duties; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise; and the other risk factors disclosed in Ciena's Quarterly Report on Form 10-Q filed with the SEC on March 11, 2019 and its Annual Report on Form 10-K filed with the SEC on December 21, 2018. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-19-000017:8k_2_02:43]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-19-000017:8k_2_02:44]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our clients create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-19-000017:8k_2_02:45]
CIENA CORPORATION

[0000936395-19-000017:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-19-000017:8k_2_02:47]
(in thousands, except per share data)

[0000936395-19-000017:8k_2_02:48]
(unaudited)

[0000936395-19-000017:8k_2_02:49]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 710,688 |  |  | $ | 604,226 |  |  | $ | 1,353,220 |  |  | $ | 1,129,835 |  |
| Services | 154,323 |  |  | 125,752 |  |  | 290,318 |  |  | 246,278 |  |
| Total revenue | 865,011 |  |  | 729,978 |  |  | 1,643,538 |  |  | 1,376,113 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 411,050 |  |  | 372,568 |  |  | 791,492 |  |  | 685,688 |  |
| Services | 79,284 |  |  | 64,103 |  |  | 154,028 |  |  | 125,353 |  |
| Total cost of goods sold | 490,334 |  |  | 436,671 |  |  | 945,520 |  |  | 811,041 |  |
| Gross profit | 374,677 |  |  | 293,307 |  |  | 698,018 |  |  | 565,072 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 137,969 |  |  | 116,924 |  |  | 266,602 |  |  | 235,448 |  |
| Selling and marketing | 103,502 |  |  | 97,359 |  |  | 201,615 |  |  | 185,874 |  |
| General and administrative | 42,154 |  |  | 38,976 |  |  | 81,397 |  |  | 77,382 |  |
| Amortization of intangible assets | 5,529 |  |  | 3,623 |  |  | 11,057 |  |  | 7,246 |  |
| Significant asset impairments and restructuring costs | 4,068 |  |  | 4,359 |  |  | 6,341 |  |  | 10,320 |  |
| Acquisition and integration costs | 1,135 |  |  | — |  |  | 2,743 |  |  | — |  |
| Total operating expenses | 294,357 |  |  | 261,241 |  |  | 569,755 |  |  | 516,270 |  |
| Income from operations | 80,320 |  |  | 32,066 |  |  | 128,263 |  |  | 48,802 |  |
| Interest and other income (loss), net | (244 | ) |  | 1,296 |  |  | 4,009 |  |  | 2,871 |  |
| Interest expense | (9,471 | ) |  | (13,031 | ) |  | (18,912 | ) |  | (26,765 | ) |
| Income before income taxes | 70,605 |  |  | 20,331 |  |  | 113,360 |  |  | 24,908 |  |
| Provision for income taxes | 17,867 |  |  | 6,475 |  |  | 27,006 |  |  | 484,415 |  |
| Net income (loss) | $ | 52,738 |  |  | $ | 13,856 |  |  | $ | 86,354 |  |  | $ | (459,507 | ) |
| Net Income (loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income (loss) per common share | $ | 0.34 |  |  | $ | 0.10 |  |  | $ | 0.55 |  |  | $ | (3.19 | ) |
| Diluted net income (loss) per potential common share | $ | 0.33 |  |  | $ | 0.09 |  |  | $ | 0.55 |  |  | $ | (3.19 | ) |
| Weighted average basic common shares outstanding | 156,170 |  |  | 143,975 |  |  | 156,244 |  |  | 143,948 |  |
| Weighted average dilutive potential common shares outstanding 1 | 158,289 |  |  | 147,973 |  |  | 158,211 |  |  | 143,948 |  |

[0000936395-19-000017:8k_2_02:50]
1. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2019 includes 2.1 million shares underlying certain stock options and stock unit awards.

[0000936395-19-000017:8k_2_02:51]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first six months of fiscal 2019 includes 2.0 million shares underlying certain stock options and stock unit awards.

[0000936395-19-000017:8k_2_02:52]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and stock unit awards and 2.7 million shares underlying Ciena's "New" 3.75% senior convertible notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018.

[0000936395-19-000017:8k_2_02:53]
CIENA CORPORATION

[0000936395-19-000017:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-19-000017:8k_2_02:55]
(in thousands, except share data)

[0000936395-19-000017:8k_2_02:56]
(unaudited)

[0000936395-19-000017:8k_2_02:57]
|  | April 30, 2019 |  | October 31, 2018 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 699,148 |  |  | $ | 745,423 |  |
| Short-term investments | 119,327 |  |  | 148,981 |  |
| Accounts receivable, net | 756,607 |  |  | 786,502 |  |
| Inventories | 359,417 |  |  | 262,751 |  |
| Prepaid expenses and other | 243,669 |  |  | 198,945 |  |
| Total current assets | 2,178,168 |  |  | 2,142,602 |  |
| Long-term investments | — |  |  | 58,970 |  |
| Equipment, building, furniture and fixtures, net | 282,022 |  |  | 292,067 |  |
| Goodwill | 297,711 |  |  | 297,968 |  |
| Other intangible assets, net | 129,971 |  |  | 148,225 |  |
| Deferred tax asset, net | 715,968 |  |  | 745,039 |  |
| Other long-term assets | 82,938 |  |  | 71,652 |  |
| Total assets | $ | 3,686,778 |  |  | $ | 3,756,523 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 366,932 |  |  | $ | 340,582 |  |
| Accrued liabilities and other short-term obligations | 291,417 |  |  | 340,075 |  |
| Deferred revenue | 104,030 |  |  | 111,134 |  |
| Current portion of long-term debt | 7,000 |  |  | 7,000 |  |
| Debt conversion liability | — |  |  | 164,212 |  |
| Total current liabilities | 769,379 |  |  | 963,003 |  |
| Long-term deferred revenue | 40,992 |  |  | 58,323 |  |
| Other long-term obligations | 129,779 |  |  | 119,413 |  |
| Long-term debt, net | 683,429 |  |  | 686,450 |  |
| Total liabilities | $ | 1,623,579 |  |  | $ | 1,827,189 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 155,566,701 and 154,318,531 shares issued and outstanding | 1,556 |  |  | 1,543 |  |
| Additional paid-in capital | 6,892,342 |  |  | 6,881,223 |  |
| Accumulated other comprehensive loss | (19,206 | ) |  | (5,780 | ) |
| Accumulated deficit | (4,811,493 | ) |  | (4,947,652 | ) |
| Total stockholders’ equity | 2,063,199 |  |  | 1,929,334 |  |
| Total liabilities and stockholders’ equity | $ | 3,686,778 |  |  | $ | 3,756,523 |  |

[0000936395-19-000017:8k_2_02:58]
CIENA CORPORATION

[0000936395-19-000017:8k_2_02:59]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-19-000017:8k_2_02:60]
(in thousands)

[0000936395-19-000017:8k_2_02:61]
(unaudited)

[0000936395-19-000017:8k_2_02:62]
|  | Six Months Ended April 30, |
|  | 2019 |  | 2018 |
| Cash flows provided by operating activities: |  |  |  |
| Net income (loss) | $ | 86,354 |  |  | $ | (459,507 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 42,995 |  |  | 41,400 |  |
| Share-based compensation costs | 29,362 |  |  | 26,559 |  |
| Amortization of intangible assets | 17,778 |  |  | 11,824 |  |
| Deferred taxes | 18,293 |  |  | 481,401 |  |
| Provision for inventory excess and obsolescence | 10,245 |  |  | 14,977 |  |
| Provision for warranty | 9,276 |  |  | 10,565 |  |
| Other | (2,259 | ) |  | 12,645 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 43,174 |  |  | (28,055 | ) |
| Inventories | (109,554 | ) |  | 20,420 |  |
| Prepaid expenses and other | (33,241 | ) |  | 2,623 |  |
| Accounts payable, accruals and other obligations | (26,971 | ) |  | (55,986 | ) |
| Deferred revenue | 4,560 |  |  | (5,736 | ) |
| Net cash provided by operating activities | 90,012 |  |  | 73,130 |  |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (35,289 | ) |  | (31,946 | ) |
| Restricted cash | — |  |  | 54 |  |
| Purchase of available for sale securities | (97,897 | ) |  | (198,026 | ) |
| Proceeds from maturities of available for sale securities | 90,000 |  |  | 200,000 |  |
| Proceeds from sales of available for sale securities | 98,263 |  |  | — |  |
| Settlement of foreign currency forward contracts, net | (2,741 | ) |  | 132 |  |
| Purchase of equity investment | (2,667 | ) |  | (767 | ) |
| Net cash provided by (used in) investing activities | 49,669 |  |  | (30,553 | ) |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (3,500 | ) |  | (2,000 | ) |
| Payment of capital lease obligations | (1,679 | ) |  | (1,868 | ) |
| Payment for debt conversion liability | (111,268 | ) |  | — |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (15,865 | ) |  | — |  |
| Repurchases of common stock - repurchase program | (65,103 | ) |  | (38,036 | ) |
| Proceeds from issuance of common stock | 11,235 |  |  | 11,804 |  |
| Net cash used in financing activities | (186,180 | ) |  | (30,100 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 224 |  |  | (894 | ) |
| Net increase (decrease) in cash and cash equivalents | (46,275 | ) |  | 11,583 |  |
| Cash and cash equivalents at beginning of period | 745,423 |  |  | 640,513 |  |
| Cash and cash equivalents at end of period | $ | 699,148 |  |  | $ | 652,096 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 19,978 |  |  | $ | 21,843 |  |
| Cash paid during the period for income taxes, net | $ | 9,258 |  |  | $ | 15,136 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 2,793 |  |  | $ | 3,226 |  |
| Non-cash financing activities |  |  |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 1,441 |  |  | $ | 1,111 |  |
| Conversion of debt conversion liability into 1,585,140 shares of common stock | $ | 52,944 |  |  | $ | — |  |

[0000936395-19-000017:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |
|  |  | Quarter Ended April 30, |
|  |  | 2019 |  | 2018 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 374,677 |  |  | $ | 293,307 |  |
| Share-based compensation-products |  | 702 |  |  | 824 |  |
| Share-based compensation-services |  | 907 |  |  | 722 |  |
| Amortization of intangible assets |  | 3,303 |  |  | 2,289 |  |
| Total adjustments related to gross profit |  | 4,912 |  |  | 3,835 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 379,589 |  |  | $ | 297,142 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.9 | % |  | 40.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 294,357 |  |  | $ | 261,241 |  |
| Share-based compensation-research and development |  | 4,083 |  |  | 3,796 |  |
| Share-based compensation-sales and marketing |  | 4,346 |  |  | 3,760 |  |
| Share-based compensation-general and administrative |  | 5,491 |  |  | 5,109 |  |
| Amortization of intangible assets |  | 5,529 |  |  | 3,623 |  |
| Significant asset impairments and restructuring costs |  | 4,068 |  |  | 4,359 |  |
| Acquisition and integration costs |  | 1,135 |  |  | — |  |
| Total adjustments related to operating expense |  | 24,652 |  |  | 20,647 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 269,705 |  |  | $ | 240,594 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 80,320 |  |  | $ | 32,066 |  |
| Total adjustments related to gross profit |  | 4,912 |  |  | 3,835 |  |
| Total adjustments related to operating expense |  | 24,652 |  |  | 20,647 |  |
| Total adjustments related to income from operations |  | 29,564 |  |  | 24,482 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 109,884 |  |  | $ | 56,548 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 12.7 | % |  | 7.7 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 52,738 |  |  | $ | 13,856 |  |
| Exclude GAAP provision for income taxes |  | 17,867 |  |  | 6,475 |  |
| Income before income taxes |  | 70,605 |  |  | 20,331 |  |
| Total adjustments related to income from operations |  | 29,564 |  |  | 24,482 |  |
| Non-cash interest expense |  | — |  |  | 759 |  |
| Adjusted income before income taxes |  | 100,169 |  |  | 45,572 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 23,940 |  |  | 11,789 |  |
| Adjusted (non-GAAP) net income |  | $ | 76,229 |  |  | $ | 33,783 |  |
| Weighted average basic common shares outstanding |  | 156,170 |  |  | 143,975 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 158,289 |  |  | 151,011 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.33 |  |  | $ | 0.09 |  |
| Adjusted (non-GAAP) diluted net income per common share2 |  | $ | 0.48 |  |  | $ | 0.23 |  |

[0000936395-19-000017:8k_2_02:64]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2019 includes 2.1 million shares underlying certain stock options and stock unit awards. |

[0000936395-19-000017:8k_2_02:65]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and stock unit awards, 2.7 million shares underlying Ciena's "New" 3.75% convertible senior notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, and 3.0 million shares underlying Ciena's "Original" 3.75% convertible senior notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018.

[0000936395-19-000017:8k_2_02:66]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2018 requires adding back interest expense of approximately $0.5 million associated with Ciena's "Original" 3.75% convertible senior notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-19-000017:8k_2_02:67]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |
|  |  | Quarter Ended April 30, |
|  |  | 2019 |  | 2018 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 52,738 |  |  | $ | 13,856 |  |
| Add: Interest expense |  | 9,471 |  |  | 13,031 |  |
| Less: Interest and other income (loss), net |  | (244 | ) |  | 1,296 |  |
| Add: Provision for income taxes |  | 17,867 |  |  | 6,475 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 21,482 |  |  | 20,567 |  |
| Add: Amortization of intangible assets |  | 8,832 |  |  | 5,912 |  |
| EBITDA |  | $ | 110,634 |  |  | $ | 58,545 |  |
| Add: Shared-based compensation cost |  | 15,607 |  |  | 14,166 |  |
| Add: Significant asset impairments and restructuring costs |  | 4,068 |  |  | 4,359 |  |
| Add: Acquisition and integration costs |  | 1,135 |  |  | — |  |
| Adjusted EBITDA |  | $ | 131,444 |  |  | $ | 77,070 |  |

[0000936395-19-000017:8k_2_02:68]
* * *

[0000936395-19-000017:8k_2_02:69]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-19-000017:8k_2_02:70]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-19-000017:8k_2_02:71]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-19-000017:8k_2_02:72]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-19-000017:8k_2_02:73]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors' costs and severance and other employment-related costs related to Ciena's acquisition of Packet Design and DonRiver, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-19-000017:8k_2_02:74]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes, which were converted during the fourth quarter of 2018, relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-19-000017:8k_2_02:75]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 23.9% for the second fiscal quarter of 2019, and 25.87% for the second fiscal quarter of 2018. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
