# CIEN MD&A — 0000936395-19-000021


## mdna

[0000936395-19-000021:mdna:1]
[same as prior period, unchanged from 0000936395-19-000010:mdna:1]

[0000936395-19-000021:mdna:2]
[same as prior period, unchanged from 0000936395-19-000010:mdna:2]

[0000936395-19-000021:mdna:3]
[same as prior period, unchanged from 0000936395-19-000010:mdna:3]

[0000936395-19-000021:mdna:4]
[same as prior period, unchanged from 0000936395-19-000010:mdna:4]

[0000936395-19-000021:mdna:5]
[same as prior period, unchanged from 0000936395-19-000010:mdna:5]

[0000936395-19-000021:mdna:6]
[same as prior period, unchanged from 0000936395-19-000010:mdna:6]

[0000936395-19-000021:mdna:7]
[same as prior period, unchanged from 0000936395-19-000010:mdna:7]

[0000936395-19-000021:mdna:8]
[same as prior period, unchanged from 0000936395-19-000010:mdna:8]

[0000936395-19-000021:mdna:9]
[same as prior period, unchanged from 0000936395-19-000010:mdna:9]

[0000936395-19-000021:mdna:10]
[same as prior period, unchanged from 0000936395-19-000010:mdna:10]

[0000936395-19-000021:mdna:11]
[same as prior period, unchanged from 0000936395-19-000010:mdna:11]

[0000936395-19-000021:mdna:12]
[same as prior period, unchanged from 0000936395-19-000010:mdna:12]

[0000936395-19-000021:mdna:13]
[same as prior period, unchanged from 0000936395-19-000010:mdna:13]

[0000936395-19-000021:mdna:14]
[same as prior period, unchanged from 0000936395-19-000010:mdna:14]

[0000936395-19-000021:mdna:15]
[same as prior period, unchanged from 0000936395-19-000010:mdna:15]

[0000936395-19-000021:mdna:16]
| • | the impact of pricing pressure and price compression that we regularly encounter in our markets; |

[0000936395-19-000021:mdna:17]
[same as prior period, unchanged from 0000936395-19-000010:mdna:17]

[0000936395-19-000021:mdna:18]
[same as prior period, unchanged from 0000936395-19-000010:mdna:18]

[0000936395-19-000021:mdna:19]
[same as prior period, unchanged from 0000936395-19-000010:mdna:19]

[0000936395-19-000021:mdna:20]
[same as prior period, unchanged from 0000936395-19-000010:mdna:20]

[0000936395-19-000021:mdna:21]
[same as prior period, unchanged from 0000936395-19-000010:mdna:21]

[0000936395-19-000021:mdna:22]
[same as prior period, unchanged from 0000936395-19-000010:mdna:22]

[0000936395-19-000021:mdna:23]
[same as prior period, unchanged from 0000936395-19-000010:mdna:23]

[0000936395-19-000021:mdna:24]
[same as prior period, unchanged from 0000936395-19-000010:mdna:24]

[0000936395-19-000021:mdna:25]
[same as prior period, unchanged from 0000936395-19-000010:mdna:25]

[0000936395-19-000021:mdna:26]
[same as prior period, unchanged from 0000936395-19-000010:mdna:26]

[0000936395-19-000021:mdna:27]
[same as prior period, unchanged from 0000936395-19-000010:mdna:27]

[0000936395-19-000021:mdna:28]
[same as prior period, unchanged from 0000936395-19-000010:mdna:28]

[0000936395-19-000021:mdna:29]
[same as prior period, unchanged from 0000936395-19-000010:mdna:29]

[0000936395-19-000021:mdna:30]
[same as prior period, unchanged from 0000936395-19-000010:mdna:30]

[0000936395-19-000021:mdna:31]
[same as prior period, unchanged from 0000936395-19-000010:mdna:31]

[0000936395-19-000021:mdna:32]
[same as prior period, unchanged from 0000936395-19-000010:mdna:32]

[0000936395-19-000021:mdna:33]
[same as prior period, unchanged from 0000936395-19-000010:mdna:33]

[0000936395-19-000021:mdna:34]
| • | the impact of the Tax Cuts and Jobs Act, future legislation or executive action in the U.S. relating to tax policy, changes in tax regulations and related accounting, and changes in our effective tax rates; |

[0000936395-19-000021:mdna:35]
| • | future legislation or executive action in the U.S. or foreign counties relating to trade regulations, including the imposition of tariffs and duties; |

[0000936395-19-000021:mdna:36]
[same as prior period, unchanged from 0000936395-19-000010:mdna:36]

[0000936395-19-000021:mdna:37]
[same as prior period, unchanged from 0000936395-19-000010:mdna:37]

[0000936395-19-000021:mdna:38]
| • | adverse results in litigation matters. |

[0000936395-19-000021:mdna:39]
[same as prior period, unchanged from 0000936395-19-000010:mdna:39]

[0000936395-19-000021:mdna:40]
[same as prior period, unchanged from 0000936395-19-000010:mdna:40]

[0000936395-19-000021:mdna:41]
Our solutions include a diverse portfolio of high-capacity Networking Platform products, which can be applied from the network core to network access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We also offer Platform Software that provides management and domain control of our next-generation packet and optical platforms and automates network lifecycle operations including provisioning equipment and services. In addition, through our comprehensive suite of Blue Planet Automation Software, we enable network operators to use network data and analytics to drive enhanced automation across multi-vendor and multi-domain network environments, accelerate service delivery, and enable an increasingly predictive and

[0000936395-19-000021:mdna:42]
32

[0000936395-19-000021:mdna:43]
autonomous network infrastructure. To complement our hardware and software solutions, we offer a broad range of attached and software-related services that help our customers design, optimize, integrate, deploy, manage and maintain their networks and associated operational environments. Through our complete portfolio of solutions, we enable our customers to transform their networks into dynamic, programmable environments driven by automation and analytics, which we refer to as the Adaptive Network. Our solutions for the Adaptive Network create business and operational value for our customers, enabling them to introduce new revenue-generating services, reduce costs and maximize the return on their network infrastructure investment.

[0000936395-19-000021:mdna:44]
Revenue and earnings growth, technology innovation and diversification of our business.

[0000936395-19-000021:mdna:45]
During the first six months of fiscal 2019, our revenue and earnings growth accelerated as we benefited meaningfully from strong network operator demand for capacity, favorable industry and competitive dynamics, and the continued execution of our strategy. Our strategy has focused on innovation leadership, the diversification of our business and customer base, and market share capture, particularly internationally. For the six months ended April 30, 2019, compared to the six months ended April 30, 2018, our revenue grew from $1.38 billion to $1.64 billion, or approximately 19%, and our income from operations grew from $48.8 million to $128.3 million, or approximately 163%. Our results can fluctuate from quarter to quarter and we do not expect that these revenue and profit growth rates will be sustainable long-term.

[0000936395-19-000021:mdna:46]
We believe that we continue to benefit from our efforts to push the pace of innovation in our markets and provide market-leading offerings. Keeping pace with the market’s demands for technology innovation requires considerable research and development investment capacity. For example, during the first six months of fiscal 2019, we invested $266.6 million in research and development activities, an increase of approximately 13% compared to the first six months of fiscal 2018. We believe that our investment capacity and innovation execution are important competitive differentiators and have been important contributors to the growth of our business. We believe that remaining competitive in the geographies, markets, and customer segments in which we sell depends upon our continued innovation.

[0000936395-19-000021:mdna:47]
We continue to diversify our business and, in the six months ended April 30, 2019, we benefited from revenue growth across a diverse set of geographies, product solutions and customer segments. During the six months ended April 30, 2019, we grew revenue in each of the geographic regions in which we operate and in each of our operating segments, with a diverse set of hardware, software and service offerings. We grew revenue with our largest service provider customers, and Web-scale providers, which have been increasingly important contributors to our overall growth, are included among our largest customers by revenue for the six months ended April 30, 2019. We believe that continued diversification of our business is important to address the dynamic industry environment in which we operate, to continue to grow our business, and to better withstand potential slowdowns that could adversely affect demand from particular geographies, markets, customers or customer segments.

[0000936395-19-000021:mdna:48]
Our revenue growth for the six months ended April 30, 2019 has also benefited from market share gains and our continued go-to-market strategy focused on generating new customer wins and displacing incumbent competitors in key accounts. An important part of our strategy is to leverage our technology leadership and to aggressively capture additional market share from competitors, particularly with communications service providers internationally. Our revenue growth, in part, reflects the benefits of this strategy, which has yielded revenue growth with additional customers and geographies in Europe, Middle East and Africa (“EMEA”) and Asia Pacific and India (“APAC”).

[0000936395-19-000021:mdna:49]
[same as prior period, unchanged from 0000936395-19-000010:mdna:46]

[0000936395-19-000021:mdna:50]
[same as prior period, unchanged from 0000936395-19-000010:mdna:47]

[0000936395-19-000021:mdna:51]
[same as prior period, unchanged from 0000936395-19-000010:mdna:48]

[0000936395-19-000021:mdna:52]
[same as prior period, unchanged from 0000936395-19-000010:mdna:49]

[0000936395-19-000021:mdna:53]
[same as prior period, unchanged from 0000936395-19-000010:mdna:50]

[0000936395-19-000021:mdna:54]
Quarter ended April 30, 2019 compared to the quarter ended April 30, 2018

[0000936395-19-000021:mdna:55]
[same as prior period, unchanged from 0000936395-19-000010:mdna:52]

[0000936395-19-000021:mdna:56]
[same as prior period, unchanged from 0000936395-19-000010:mdna:53]

[0000936395-19-000021:mdna:57]
During the second quarter of fiscal 2019, approximately 19.1% of our revenue was non-U.S. Dollar-denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, British Pounds and Indian Rupee. During the second quarter of fiscal 2019, as compared to the second quarter of fiscal 2018, foreign exchange rates between these currencies and the U.S. Dollar fluctuated. Consequently, our revenue reported in U.S. Dollars slightly decreased by approximately $19.8 million, or 2.2%, as compared to the second quarter of fiscal 2018, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000021:mdna:58]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | 72.1 |  | $ | 527,867 |  |  | 72.4 |  | $ | 95,971 |  |  | 18.2 |  |
| Packet Networking | 73,138 |  |  | 8.5 |  | 63,815 |  |  | 8.7 |  | 9,323 |  |  | 14.6 |  |
| Total Networking Platforms | 696,976 |  |  | 80.6 |  | 591,682 |  |  | 81.1 |  | 105,294 |  |  | 17.8 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 35,229 |  |  | 4.0 |  | 36,393 |  |  | 5.0 |  | (1,164 | ) |  | (3.2 | ) |
| Blue Planet Automation Software and Services | 12,473 |  |  | 1.4 |  | 2,352 |  |  | 0.3 |  | 10,121 |  |  | 430.3 |  |
| Total Software and Software-Related Services | 47,702 |  |  | 5.4 |  | 38,745 |  |  | 5.3 |  | 8,957 |  |  | 23.1 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 68,788 |  |  | 8.0 |  | 60,904 |  |  | 8.3 |  | 7,884 |  |  | 12.9 |  |
| Installation and Deployment | 41,322 |  |  | 4.8 |  | 28,209 |  |  | 3.9 |  | 13,113 |  |  | 46.5 |  |
| Consulting and Network Design | 10,223 |  |  | 1.2 |  | 10,438 |  |  | 1.4 |  | (215 | ) |  | (2.1 | ) |
| Total Global Services | 120,333 |  |  | 14.0 |  | 99,551 |  |  | 13.6 |  | 20,782 |  |  | 20.9 |  |
| Consolidated revenue | $ | 865,011 |  |  | 100.0 |  | $ | 729,978 |  |  | 100.0 |  | $ | 135,033 |  |  | 18.5 |  |

[0000936395-19-000021:mdna:59]
[same as prior period, unchanged from 0000936395-19-000010:mdna:56]

[0000936395-19-000021:mdna:60]
[same as prior period, unchanged from 0000936395-19-000010:mdna:57]

[0000936395-19-000021:mdna:61]
[same as prior period, unchanged from 0000936395-19-000010:mdna:58]

[0000936395-19-000021:mdna:62]
| • | Networking Platforms segment revenue increased, reflecting product line sales increases of $96.0 million of our Converged Packet Optical products and $9.3 million of our Packet Networking products. |

[0000936395-19-000021:mdna:63]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $102.7 million of our 6500 Packet-Optical Platform and $28.7 million of our Waveserver stackable interconnect system. These increases were partially |

[0000936395-19-000021:mdna:64]
offset by a sales decrease of $27.0 million of our 5410/5430 Reconfigurable Switching Systems. The sales increase from our 6500 Packet-Optical Platform is primarily due to increased sales to AT&T and other communications service providers, enterprise customers and Web-scale providers. Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers, which represent a growing portion of our business as we continue to diversify.

[0000936395-19-000021:mdna:65]
| ◦ | Packet Networking sales increased, primarily reflecting $17.0 million in initial sales of our 6500 Packet Transport System, partially offset by sales decreases of $3.5 million of our 8700 Packetwave Platform and $2.9 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to communications service providers. |

[0000936395-19-000021:mdna:66]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting a sales increase of $10.1 million of our Blue Planet Automation Software and Services, partially offset by a sales decrease of $1.2 million of our Platform Software and Services. The increase in our Blue Planet Automation Software and Services includes sales of $2.0 million and $3.9 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively, and a $2.4 million increase in sales of our Blue Planet management and orchestration (NFV MANO) software. |

[0000936395-19-000021:mdna:67]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $13.1 million of our installation and deployment services and $7.9 million of our maintenance support and training services. |

[0000936395-19-000021:mdna:68]
Our operating segments engage in business and operations across four geographic regions: North America; Europe, Middle EMEA; Caribbean and Latin America (“CALA”); and APAC. Results for North America include only activities in the U.S. and Canada. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The increase in our CALA region for the fiscal quarter ended April 30, 2019 was primarily driven by increased sales in Brazil, Argentina and Chile. The decrease in our APAC region for the fiscal quarter ended April 30, 2019 was primarily driven by decreased sales in India, which had been a key contributor to our revenue growth in recent periods. This decrease was partially offset by increased sales in Japan and continued execution of our strategy to capture new market share with communications service providers in the region. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000021:mdna:69]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| North America | $ | 576,093 |  |  | 66.5 |  | $ | 431,235 |  |  | 59.1 |  | $ | 144,858 |  |  | 33.6 |  |
| EMEA | 114,993 |  |  | 13.3 |  | 121,747 |  |  | 16.7 |  | (6,754 | ) |  | (5.5 | ) |
| CALA | 39,399 |  |  | 4.6 |  | 25,080 |  |  | 3.4 |  | 14,319 |  |  | 57.1 |  |
| APAC | 134,526 |  |  | 15.6 |  | 151,916 |  |  | 20.8 |  | (17,390 | ) |  | (11.4 | ) |
| Total | $ | 865,011 |  |  | 100.0 |  | $ | 729,978 |  |  | 100.0 |  | $ | 135,033 |  |  | 18.5 |  |

[0000936395-19-000021:mdna:70]
[same as prior period, unchanged from 0000936395-19-000010:mdna:73]

[0000936395-19-000021:mdna:71]
[same as prior period, unchanged from 0000936395-19-000010:mdna:74]

[0000936395-19-000021:mdna:72]
[same as prior period, unchanged from 0000936395-19-000010:mdna:75]

[0000936395-19-000021:mdna:73]
| • | North America revenue primarily reflects increases of $132.9 million within our Networking Platforms segment and $11.3 million within our Global Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $103.7 million of Converged Packet Optical products and $29.2 million of Packet Networking products. Converged Packet Optical sales primarily reflects sales increases of $83.0 million of our 6500 Packet-Optical Platform and $27.0 million of our Waveserver stackable interconnect system. Our 6500 Packet-Optical Platform sales primarily reflect increased sales to AT&T and other communications service providers and enterprise customers, Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers. |

[0000936395-19-000021:mdna:74]
| • | EMEA revenue primarily reflects a decrease of $11.6 million within our Networking Platforms segment partially offset by increases of $3.0 million within our Software and Software-Related Services segment and $1.8 million within our Global Services segment. |

[0000936395-19-000021:mdna:75]
| • | CALA revenue primarily reflects increases of $11.6 million within our Networking Platforms segment, $1.6 million within our Global Services segment and $1.1 million within our Software and Software-Related Services segment. |

[0000936395-19-000021:mdna:76]
35

[0000936395-19-000021:mdna:77]
Networking Platforms segment sales largely reflect increased sales to communications service providers, Web-scale providers and submarine network operators.

[0000936395-19-000021:mdna:78]
| • | APAC revenue primarily reflects a decrease of $27.6 million within our Networking Platforms segment partially offset by increases of $6.1 million within our Global Services segment and $4.1 million within our Software and Software-Related Services segment. Networking Platforms segment revenue primarily reflects a product line decrease of $19.8 million in Packet Networking sales primarily due to a decrease of $13.9 million in sales of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers in India. |

[0000936395-19-000021:mdna:79]
[same as prior period, unchanged from 0000936395-19-000010:mdna:81]

[0000936395-19-000021:mdna:80]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-19-000021:mdna:81]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-19-000021:mdna:82]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending upon our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price compression that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. When we have success in taking share and winning new business, it can result in additional pressure on gross margin from these pricing dynamics, particularly during the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common”  equipment sales and installation services, with our intent to improve margin as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. Gross margin and revenue can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that may carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-19-000021:mdna:83]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-19-000021:mdna:84]
[same as prior period, unchanged from 0000936395-19-000010:mdna:107]

[0000936395-19-000021:mdna:85]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 865,011 |  |  | 100.0 |  | $ | 729,978 |  |  | 100.0 |  | $ | 135,033 |  |  | 18.5 |
| Total cost of goods sold | 490,334 |  |  | 56.7 |  | 436,671 |  |  | 59.8 |  | 53,663 |  |  | 12.3 |
| Gross profit | $ | 374,677 |  |  | 43.3 |  | $ | 293,307 |  |  | 40.2 |  | $ | 81,370 |  |  | 27.7 |

[0000936395-19-000021:mdna:86]
[same as prior period, unchanged from 0000936395-19-000010:mdna:109]

[0000936395-19-000021:mdna:87]
[same as prior period, unchanged from 0000936395-19-000010:mdna:110]

[0000936395-19-000021:mdna:88]
[same as prior period, unchanged from 0000936395-19-000010:mdna:111]

[0000936395-19-000021:mdna:89]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 710,688 |  |  | 100.0 |  | $ | 604,226 |  |  | 100.0 |  | $ | 106,462 |  |  | 17.6 |
| Product cost of goods sold | 411,050 |  |  | 57.8 |  | 372,568 |  |  | 61.7 |  | 38,482 |  |  | 10.3 |
| Product gross profit | $ | 299,638 |  |  | 42.2 |  | $ | 231,658 |  |  | 38.3 |  | $ | 67,980 |  |  | 29.3 |

[0000936395-19-000021:mdna:90]
[same as prior period, unchanged from 0000936395-19-000010:mdna:113]

[0000936395-19-000021:mdna:91]
[same as prior period, unchanged from 0000936395-19-000010:mdna:114]

[0000936395-19-000021:mdna:92]
[same as prior period, unchanged from 0000936395-19-000010:mdna:115]

[0000936395-19-000021:mdna:93]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 154,323 |  |  | 100.0 |  | $ | 125,752 |  |  | 100.0 |  | $ | 28,571 |  |  | 22.7 |
| Service cost of goods sold | 79,284 |  |  | 51.4 |  | 64,103 |  |  | 51.0 |  | 15,181 |  |  | 23.7 |
| Service gross profit | $ | 75,039 |  |  | 48.6 |  | $ | 61,649 |  |  | 49.0 |  | $ | 13,390 |  |  | 21.7 |

[0000936395-19-000021:mdna:94]
[same as prior period, unchanged from 0000936395-19-000010:mdna:117]

[0000936395-19-000021:mdna:95]
[same as prior period, unchanged from 0000936395-19-000010:mdna:118]

[0000936395-19-000021:mdna:96]
[same as prior period, unchanged from 0000936395-19-000010:mdna:119]

[0000936395-19-000021:mdna:97]
| • | Gross profit as a percentage of revenue reflects improved product gross profit as described below. In recent periods, we have encountered fluctuations or reductions in our gross margin as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, with the intent to improve margin in the long term as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. In the fiscal quarter ended April 30, 2019, our gross margin benefited from the success of this ongoing strategy and the resulting favorable mix of customers, network deployments and capacity additions during the period. Continued implementation of this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, or result in an unfavorable mix of revenues from early stage deployments during a particular period, which can adversely impact quarterly gross margin. |

[0000936395-19-000021:mdna:98]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to product cost reductions, a favorable mix of customers, network deployments and capacity additions, and improved manufacturing efficiencies, partially offset by market-based price compression we encountered during the period. |

[0000936395-19-000021:mdna:99]
| • | Gross profit on services as a percentage of services revenue decreased slightly, primarily as a result of lower margins on our Blue Planet Automation software services. |

[0000936395-19-000021:mdna:100]
[same as prior period, unchanged from 0000936395-19-000010:mdna:123]

[0000936395-19-000021:mdna:101]
[same as prior period, unchanged from 0000936395-19-000010:mdna:124]

[0000936395-19-000021:mdna:102]
[same as prior period, unchanged from 0000936395-19-000010:mdna:125]

[0000936395-19-000021:mdna:103]
[same as prior period, unchanged from 0000936395-19-000010:mdna:126]

[0000936395-19-000021:mdna:104]
[same as prior period, unchanged from 0000936395-19-000010:mdna:127]

[0000936395-19-000021:mdna:105]
[same as prior period, unchanged from 0000936395-19-000010:mdna:129]

[0000936395-19-000021:mdna:106]
[same as prior period, unchanged from 0000936395-19-000010:mdna:128]

[0000936395-19-000021:mdna:107]
[same as prior period, unchanged from 0000936395-19-000010:mdna:130]

[0000936395-19-000021:mdna:108]
During the second quarter of fiscal 2019, approximately 50.6% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees and Euros. During the second quarter of fiscal 2019 as compared to the second quarter of fiscal 2018, foreign exchange rates between these currencies and the U.S. Dollar fluctuated. Consequently, our operating expense reported in U.S. Dollars slightly decreased by approximately $7.1 million, or 2.4%, as compared to the second quarter of fiscal 2018, due to fluctuations in foreign currency, net of hedging. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000021:mdna:109]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 137,969 |  |  | 15.9 |  | $ | 116,924 |  |  | 16.0 |  | $ | 21,045 |  |  | 18.0 |  |
| Selling and marketing | 103,502 |  |  | 12.0 |  | 97,359 |  |  | 13.3 |  | 6,143 |  |  | 6.3 |  |
| General and administrative | 42,154 |  |  | 4.9 |  | 38,976 |  |  | 5.3 |  | 3,178 |  |  | 8.2 |  |
| Amortization of intangible assets | 5,529 |  |  | 0.6 |  | 3,623 |  |  | 0.5 |  | 1,906 |  |  | 52.6 |  |
| Significant asset impairments and restructuring costs | 4,068 |  |  | 0.5 |  | 4,359 |  |  | 0.6 |  | (291 | ) |  | (6.7 | ) |
| Acquisition and integration costs | 1,135 |  |  | 0.1 |  | — |  |  | — |  | 1,135 |  |  | 100.0 |  |
| Total operating expenses | $ | 294,357 |  |  | 34.0 |  | $ | 261,241 |  |  | 35.7 |  | $ | 33,116 |  |  | 12.7 |  |

[0000936395-19-000021:mdna:110]
[same as prior period, unchanged from 0000936395-19-000010:mdna:135]

[0000936395-19-000021:mdna:111]
[same as prior period, unchanged from 0000936395-19-000010:mdna:136]

[0000936395-19-000021:mdna:112]
[same as prior period, unchanged from 0000936395-19-000010:mdna:137]

[0000936395-19-000021:mdna:113]
| • | Research and development expense benefited from $3.4 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $21.0 million. This increase primarily reflects increases of $5.9 million in professional services, $3.2 million in employee and compensation costs, $3.0 million in prototype expense, $1.5 million in technology and related expenses and $1.3 million for facility and information technology costs. Also contributing to the increase was a reduced benefit of $5.1 million for the ENCQOR grant reimbursement, as the amount reflected in operating expense for the second quarter of fiscal 2018 represents amounts incurred from the February 20, 2017 grant inception date through the end of such period. For more information on the ENCQOR grant, see Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-19-000021:mdna:114]
| • | Selling and marketing expense benefited from $3.0 million as a result of foreign exchange rates primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $6.1 million, primarily reflecting increases of $3.9 million in employee and compensation costs and $1.5 million in facilities and information technology costs. |

[0000936395-19-000021:mdna:115]
| • | General and administrative expense increased by $3.2 million, primarily reflecting increases of $1.3 million in employee and compensation costs, $1.2 million in bad debt expense, and $1.0 million in facilities and information technology costs. |

[0000936395-19-000021:mdna:116]
| • | Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisitions of Packet Design and DonRiver during fiscal 2018. |

[0000936395-19-000021:mdna:117]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes and unfavorable lease commitments for certain facility locations in the United States and India where we have vacated unused space. |

[0000936395-19-000021:mdna:118]
38

[0000936395-19-000021:mdna:119]
[same as prior period, unchanged from 0000936395-19-000010:mdna:143]

[0000936395-19-000021:mdna:120]
[same as prior period, unchanged from 0000936395-19-000010:mdna:144]

[0000936395-19-000021:mdna:121]
[same as prior period, unchanged from 0000936395-19-000010:mdna:145]

[0000936395-19-000021:mdna:122]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (244 | ) |  | 0.0 |  |  | $ | 1,296 |  |  | 0.2 |  | $ | (1,540 | ) |  | (118.8 | ) |
| Interest expense | $ | 9,471 |  |  | 1.1 |  |  | $ | 13,031 |  |  | 1.8 |  | $ | (3,560 | ) |  | (27.3 | ) |
| Provision for income taxes | $ | 17,867 |  |  | 2.1 |  |  | $ | 6,475 |  |  | 0.9 |  | $ | 11,392 |  |  | 175.9 |  |

[0000936395-19-000021:mdna:123]
[same as prior period, unchanged from 0000936395-19-000010:mdna:147]

[0000936395-19-000021:mdna:124]
[same as prior period, unchanged from 0000936395-19-000010:mdna:148]

[0000936395-19-000021:mdna:125]
[same as prior period, unchanged from 0000936395-19-000010:mdna:149]

[0000936395-19-000021:mdna:126]
| • | Interest and other income, net primarily reflects the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-19-000021:mdna:127]
[same as prior period, unchanged from 0000936395-19-000010:mdna:151]

[0000936395-19-000021:mdna:128]
| • | Provision for income taxes increased, due to higher earnings for the second quarter of fiscal 2019. The effective tax rate for the second quarter of 2019 was lower compared to the second quarter of fiscal 2018, primarily due to a lower statutory federal income tax rate in 2019. |

[0000936395-19-000021:mdna:129]
Six months ended April 30, 2018 compared to the six months ended April 30, 2019

[0000936395-19-000021:mdna:130]
Revenue

[0000936395-19-000021:mdna:131]
During the first six months of fiscal 2019, approximately 18.5% of our revenue was non-U.S. Dollar-denominated, including sales in Japanese Yen, Canadian Dollars, Indian Rupees, Euro, British Pounds and Brazilian Reais. During the first six months of fiscal 2019, as compared to the first six months of fiscal 2018, foreign exchange rates between these currencies and the U.S. Dollar fluctuated. Consequently, our revenue reported in U.S. Dollars was slightly reduced by approximately $29.0 million or 1.7%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000021:mdna:132]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | 71.4 |  | $ | 955,297 |  |  | 69.4 |  | $ | 217,538 |  |  | 22.8 |  |
| Packet Networking | 144,707 |  |  | 8.8 |  | 132,418 |  |  | 9.6 |  | 12,289 |  |  | 9.3 |  |
| Total Networking Platforms | 1,317,542 |  |  | 80.2 |  | 1,087,715 |  |  | 79.0 |  | 229,827 |  |  | 21.1 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 76,827 |  |  | 4.7 |  | 80,529 |  |  | 5.9 |  | (3,702 | ) |  | (4.6 | ) |
| Blue Planet Automation Software and Services | 27,447 |  |  | 1.6 |  | 11,703 |  |  | 0.8 |  | 15,744 |  |  | 134.5 |  |
| Total Software and Software-Related Services | 104,274 |  |  | 6.3 |  | 92,232 |  |  | 6.7 |  | 12,042 |  |  | 13.1 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 130,065 |  |  | 7.9 |  | 116,862 |  |  | 8.5 |  | 13,203 |  |  | 11.3 |  |
| Installation and Deployment | 71,944 |  |  | 4.4 |  | 58,225 |  |  | 4.2 |  | 13,719 |  |  | 23.6 |  |
| Consulting and Network Design | 19,713 |  |  | 1.2 |  | 21,079 |  |  | 1.6 |  | (1,366 | ) |  | (6.5 | ) |
| Total Global Services | 221,722 |  |  | 13.5 |  | 196,166 |  |  | 14.3 |  | 25,556 |  |  | 13.0 |  |
| Consolidated revenue | $ | 1,643,538 |  |  | 100.0 |  | $ | 1,376,113 |  |  | 100.0 |  | $ | 267,425 |  |  | 19.4 |  |

[0000936395-19-000021:mdna:133]
_____________________________

[0000936395-19-000021:mdna:134]
*    Denotes % of total revenue

[0000936395-19-000021:mdna:135]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:136]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $217.5 million of our Converged Packet Optical products and $12.3 million of our Packet Networking products. |

[0000936395-19-000021:mdna:137]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $156.3 million of our 6500 Packet-Optical Platform and $108.1 million of our Waveserver stackable interconnect system. These increases were partially offset by a sales decrease of $39.6 million of our 5410/5430 Reconfigurable Switching Systems. The sales increase of our 6500 Packet-Optical Platform is primarily due to increased sales to AT&T and other communications service providers, enterprise customers and Web-scale providers. Waveserver stackable interconnect system sales primarily reflect increased sales to Web-scale providers, which represent a growing portion of our business as we continue to diversify. |

[0000936395-19-000021:mdna:138]
| ◦ | Packet Networking sales increased, primarily reflecting $34.9 million in initial sales of our 6500 Packet Transport System to communications service providers, partially offset by a sales decrease of $18.0 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to communications service providers in India. |

[0000936395-19-000021:mdna:139]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting a sales increase of $15.7 million of our Blue Planet Automation Software and Services, partially offset by a sales decrease of $3.7 million of our Platform Software and Services. The increase in our Blue Planet Automation Software and Services includes sales of $6.8 million and $6.9 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. |

[0000936395-19-000021:mdna:140]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $13.7 million of our deployment and installation services and $13.2 million of our maintenance support and training services. |

[0000936395-19-000021:mdna:141]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America,

[0000936395-19-000021:mdna:142]
40

[0000936395-19-000021:mdna:143]
can result in large variations in geographic revenue results in any particular quarter. The increase in our CALA region for the six months ended April 30, 2019 was primarily driven by increased sales in Brazil, Chile and Argentina. The increase in our APAC region for the six months ended April 30, 2019 was primarily driven by increased sales in Japan, partially offset by decreased sales in India and Australia. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000021:mdna:144]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,061,599 |  |  | 64.5 |  | $ | 834,144 |  |  | 60.6 |  | $ | 227,455 |  |  | 27.3 |
| EMEA | 244,183 |  |  | 14.9 |  | 219,581 |  |  | 16.0 |  | 24,602 |  |  | 11.2 |
| CALA | 70,374 |  |  | 4.3 |  | 59,643 |  |  | 4.3 |  | 10,731 |  |  | 18.0 |
| APAC | 267,382 |  |  | 16.3 |  | 262,745 |  |  | 19.1 |  | 4,637 |  |  | 1.8 |
| Total | $ | 1,643,538 |  |  | 100.0 |  | $ | 1,376,113 |  |  | 100.0 |  | $ | 267,425 |  |  | 19.4 |

[0000936395-19-000021:mdna:145]
[same as prior period, unchanged from 0000936395-19-000010:mdna:156]

[0000936395-19-000021:mdna:146]
*    Denotes % of total revenue

[0000936395-19-000021:mdna:147]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:148]
| • | North America revenue primarily reflects increases of $217.3 million within our Networking Platforms segment and $11.6 million within our Global Services segment. This increase primarily reflects product line sales increases of $177.6 million of Converged Packet Optical products and $39.7 million of Packet Networking products. Converged Packet Optical sales primarily reflect sales increases of $109.2 million of our 6500 Packet-Optical Platform and $75.4 million of our Waveserver stackable interconnect system. 6500 Packet-Optical Platform sales reflect increased sales to AT&T and other communications service providers and enterprise customers. Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers. |

[0000936395-19-000021:mdna:149]
| • | EMEA revenue primarily reflects increases of $14.2 million within our Networking Platforms segment, $6.3 million within our Global Services segment and $4.1 million within our Software and Software-Related Services segment. These increases largely reflect sales to Web-scale providers. |

[0000936395-19-000021:mdna:150]
| • | CALA revenue primarily reflects increases of $9.4 million within our Networking Platforms segment and $1.9 million within our Software and Software-Related Services segment. Networking Platforms segment sales largely reflect increased sales to Web-scale providers and submarine network operators. |

[0000936395-19-000021:mdna:151]
| • | APAC revenue primarily reflects increases of $8.1 million within our Global Services segment and $7.5 million within our Software and Software-Related Services segment partially offset by a decrease of $11.0 million within our Networking Platforms segment. |

[0000936395-19-000021:mdna:152]
Cost of Goods Sold and Gross Profit

[0000936395-19-000021:mdna:153]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-19-000021:mdna:154]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,643,538 |  |  | 100.0 |  | $ | 1,376,113 |  |  | 100.0 |  | $ | 267,425 |  |  | 19.4 |
| Total cost of goods sold | 945,520 |  |  | 57.5 |  | 811,041 |  |  | 58.9 |  | 134,479 |  |  | 16.6 |
| Gross profit | $ | 698,018 |  |  | 42.5 |  | $ | 565,072 |  |  | 41.1 |  | $ | 132,946 |  |  | 23.5 |

[0000936395-19-000021:mdna:155]
_____________________________________

[0000936395-19-000021:mdna:156]
*    Denotes % of total revenue

[0000936395-19-000021:mdna:157]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:158]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,353,220 |  |  | 100.0 |  | $ | 1,129,835 |  |  | 100.0 |  | $ | 223,385 |  |  | 19.8 |
| Product cost of goods sold | 791,492 |  |  | 58.5 |  | 685,688 |  |  | 60.7 |  | 105,804 |  |  | 15.4 |
| Product gross profit | $ | 561,728 |  |  | 41.5 |  | $ | 444,147 |  |  | 39.3 |  | $ | 117,581 |  |  | 26.5 |

[0000936395-19-000021:mdna:159]
_____________________________________

[0000936395-19-000021:mdna:160]
*    Denotes % of product revenue

[0000936395-19-000021:mdna:161]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:162]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 290,318 |  |  | 100.0 |  | $ | 246,278 |  |  | 100.0 |  | $ | 44,040 |  |  | 17.9 |
| Service cost of goods sold | 154,028 |  |  | 53.1 |  | 125,353 |  |  | 50.9 |  | 28,675 |  |  | 22.9 |
| Service gross profit | $ | 136,290 |  |  | 46.9 |  | $ | 120,925 |  |  | 49.1 |  | $ | 15,365 |  |  | 12.7 |

[0000936395-19-000021:mdna:163]
_____________________________________

[0000936395-19-000021:mdna:164]
*    Denotes % of services revenue

[0000936395-19-000021:mdna:165]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:166]
| • | Gross profit as a percentage of revenue reflects improved product gross profit partially offset by lower services gross profit as described below. |

[0000936395-19-000021:mdna:167]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to product cost reductions and improved manufacturing efficiencies. This benefit was partially offset by an unfavorable mix of customers and early stage international network deployments, and market-based price compression we encountered during the period. |

[0000936395-19-000021:mdna:168]
| • | Gross profit on services as a percentage of services revenue decreased, primarily as a result of lower margins on our Blue Planet Automation software services and the impact of early stages of international network deployments. |

[0000936395-19-000021:mdna:169]
Operating Expense

[0000936395-19-000021:mdna:170]
During the first six months of fiscal 2019, approximately 51.2% of our operating expense was non-U.S. Dollar-denominated, including Canadian Dollars, British Pounds, Euros, Indian Rupees and Brazilian Reais. Consequently, our operating expense reported in U.S. Dollars slightly decreased by approximately $13.4 million, or 2.3%, during the first six months of fiscal 2019 as compared to the first six months fiscal 2018, due to fluctuations in foreign currency, net of hedging. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000021:mdna:171]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 266,602 |  |  | 16.2 |  | $ | 235,448 |  |  | 17.1 |  | $ | 31,154 |  |  | 13.2 |  |
| Selling and marketing | 201,615 |  |  | 12.3 |  | 185,874 |  |  | 13.5 |  | 15,741 |  |  | 8.5 |  |
| General and administrative | 81,397 |  |  | 5.0 |  | 77,382 |  |  | 5.6 |  | 4,015 |  |  | 5.2 |  |
| Amortization of intangible assets | 11,057 |  |  | 0.7 |  | 7,246 |  |  | 0.5 |  | 3,811 |  |  | 52.6 |  |
| Significant asset impairments and restructuring costs | 6,341 |  |  | 0.4 |  | 10,320 |  |  | 0.7 |  | (3,979 | ) |  | (38.6 | ) |
| Acquisition and integration costs | 2,743 |  |  | 0.2 |  | — |  |  | — |  | 2,743 |  |  | — |  |
| Total operating expenses | $ | 569,755 |  |  | 34.8 |  | $ | 516,270 |  |  | 37.4 |  | $ | 53,485 |  |  | 10.4 |  |

[0000936395-19-000021:mdna:172]
_____________________________________

[0000936395-19-000021:mdna:173]
*    Denotes % of total revenue

[0000936395-19-000021:mdna:174]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:175]
| • | Research and development expense benefited from $7.1 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $31.2 million. This increase primarily reflects increases of $11.1 million in professional services, $6.9 million in employee and compensation |

[0000936395-19-000021:mdna:176]
costs, $4.0 million in prototype expense, $1.8 million in technology and related costs and $1.6 million in facility and information technology costs. This increase also reflects a reduced benefit of $3.2 million for the ENCQOR grant reimbursement, as described above.

[0000936395-19-000021:mdna:177]
| • | Selling and marketing expense benefited from $4.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $15.7 million, primarily reflecting increases of $10.6 million in employee and compensation costs, $2.4 million in facilities and information technology costs and $1.1 million in travel and entertainment costs. |

[0000936395-19-000021:mdna:178]
| • | General and administrative expense benefited from $1.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro, Brazilian Real, Canadian Dollar and India Rupee. Including the effect of foreign exchange rates, general and administrative expenses increased by $4.0 million, primarily reflecting increases of $2.6 million in employee and compensation costs, $1.4 million in bad debt expense and $1.4 million for facilities and information technology costs. |

[0000936395-19-000021:mdna:179]
| • | Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisitions of Packet Design and DonRiver. |

[0000936395-19-000021:mdna:180]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes and unfavorable lease commitments for a few of our facility locations in the United States and India where we have vacated unused space. |

[0000936395-19-000021:mdna:181]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisitions of Packet Design and DonRiver. |

[0000936395-19-000021:mdna:182]
Other items

[0000936395-19-000021:mdna:183]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-19-000021:mdna:184]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 4,009 |  |  | 0.2 |  | $ | 2,871 |  |  | 0.2 |  | $ | 1,138 |  |  | 39.6 |  |
| Interest expense | $ | 18,912 |  |  | 1.2 |  | $ | 26,765 |  |  | 1.9 |  | $ | (7,853 | ) |  | (29.3 | ) |
| Provision for income taxes | $ | 27,006 |  |  | 1.6 |  | $ | 484,415 |  |  | 35.2 |  | $ | (457,409 | ) |  | (94.4 | ) |

[0000936395-19-000021:mdna:185]
_____________________________________

[0000936395-19-000021:mdna:186]
*    Denotes % of total revenue

[0000936395-19-000021:mdna:187]
**    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:188]
| • | Interest and other income (loss), net primarily reflects a $1.7 million gain in interest income due to higher interest rates on our investments during fiscal 2019. |

[0000936395-19-000021:mdna:189]
| • | Interest expense decreased, primarily due to a reduction in our aggregate outstanding debt during the fourth quarter of fiscal 2018. |

[0000936395-19-000021:mdna:190]
| • | Provision for income taxes decreased as the first six months of fiscal 2018 reflects the impact of the Tax Act, including $431.3 million in expense for the remeasurement of our net deferred tax assets and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. |

[0000936395-19-000021:mdna:191]
[same as prior period, unchanged from 0000936395-19-000010:mdna:153]

[0000936395-19-000021:mdna:192]
[same as prior period, unchanged from 0000936395-19-000010:mdna:154]

[0000936395-19-000021:mdna:193]
|  | Quarter Ended April 30, |  |  |  |
|  | 2019 |  | 2018 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 175,191 |  |  | $ | 126,823 |  |  | $ | 48,368 |  |  | 38.1 |  |
| Software and Software-Related Services | $ | 6,536 |  |  | $ | 8,276 |  |  | $ | (1,740 | ) |  | (21.0 | ) |
| Global Services | $ | 54,981 |  |  | $ | 41,284 |  |  | $ | 13,697 |  |  | 33.2 |  |

[0000936395-19-000021:mdna:194]
_____________________________________

[0000936395-19-000021:mdna:195]
[same as prior period, unchanged from 0000936395-19-000010:mdna:157]

[0000936395-19-000021:mdna:196]
[same as prior period, unchanged from 0000936395-19-000010:mdna:158]

[0000936395-19-000021:mdna:197]
| • | Software and Software-Related Services segment profit decreased, primarily due to reduced gross margin on software-related services, as described above, and higher research and development costs, partially offset by higher sales volume. |

[0000936395-19-000021:mdna:198]
| • | Global Services segment profit increased, primarily due to higher sales volume and improved gross margin. |

[0000936395-19-000021:mdna:199]
|  | Six Months Ended April 30, |  |  |  |
|  | 2019 |  | 2018 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 311,782 |  |  | $ | 215,392 |  |  | $ | 96,390 |  |  | 44.8 |  |
| Software and Software-Related Services | $ | 24,952 |  |  | $ | 31,911 |  |  | $ | (6,959 | ) |  | (21.8 | ) |
| Global Services | $ | 94,682 |  |  | $ | 82,321 |  |  | $ | 12,361 |  |  | 15.0 |  |

[0000936395-19-000021:mdna:200]
_____________________________________

[0000936395-19-000021:mdna:201]
*    Denotes % change from 2018 to 2019

[0000936395-19-000021:mdna:202]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume and higher gross margin as described above, partially offset by higher research and development costs. |

[0000936395-19-000021:mdna:203]
| • | Software and Software-Related Services segment profit decreased, primarily due to reduced gross margin on software-related services partially offset by higher sales volume as described above. |

[0000936395-19-000021:mdna:204]
| • | Global Services segment profit increased, primarily due to higher sales volume as described above. |

[0000936395-19-000021:mdna:205]
[same as prior period, unchanged from 0000936395-19-000010:mdna:161]

[0000936395-19-000021:mdna:206]
For the six months ended April 30, 2019, we generated $90.0 million of cash from operating activities, as our net income (adjusted for non-cash charges) of $212.0 million exceeded our working capital requirements of $122.0 million. The increase in working capital was primarily driven by inventory increases of $109.6 million. For additional details on our cash provided by operating activities, see the discussion below entitled “Cash Provided By Operating Activities.”

[0000936395-19-000021:mdna:207]
Despite our cash generated from operations, cash, cash equivalents and investments decreased by $134.9 million during the first six months of fiscal 2019. The decrease in cash primarily reflects (i) cash used for the payment of the debt conversion liability associated with our New Notes of $111.3 million on November 15, 2018, (ii) cash used to fund our investing activities for capital expenditures totaling $35.3 million, (iii) cash used for stock repurchase under our stock repurchase program of $65.1 million, (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $15.9 million and (v) cash used for payments on our 2025 term loan of $3.5 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $11.2 million in cash during the six months ended April 30, 2019.

[0000936395-19-000021:mdna:208]
|  | April 30, 2019 |  | October 31, 2018 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 699,148 |  |  | $ | 745,423 |  |  | $ | (46,275 | ) |
| Short-term investments in marketable debt securities | 119,327 |  |  | 148,981 |  |  | (29,654 | ) |
| Long-term investments in marketable debt securities | — |  |  | 58,970 |  |  | (58,970 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 818,475 |  |  | $ | 953,374 |  |  | $ | (134,899 | ) |

[0000936395-19-000021:mdna:209]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of April 30, 2019 totaled $818.5 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of April 30, 2019, letters of credit totaling $75.2 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2019.

[0000936395-19-000021:mdna:210]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $61.6 million as of April 30, 2019.We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these

[0000936395-19-000021:mdna:211]
[same as prior period, unchanged from 0000936395-19-000010:mdna:167]

[0000936395-19-000021:mdna:212]
withholding taxes would be approximately $27.0 million.

[0000936395-19-000021:mdna:213]
[same as prior period, unchanged from 0000936395-19-000010:mdna:169]

[0000936395-19-000021:mdna:214]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-19-000021:mdna:215]
Cash Provided By Operating Activities

[0000936395-19-000021:mdna:216]
The following sections set forth the components of our $90.0 million of cash provided by operating activities during the first six months of fiscal 2019:

[0000936395-19-000021:mdna:217]
[same as prior period, unchanged from 0000936395-19-000010:mdna:173]

[0000936395-19-000021:mdna:218]
[same as prior period, unchanged from 0000936395-19-000010:mdna:174]

[0000936395-19-000021:mdna:219]
|  | Six months ended |
|  | April 30, 2019 |
| Net income | $ | 86,354 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 42,995 |  |
| Share-based compensation costs | 29,362 |  |
| Amortization of intangible assets | 17,778 |  |
| Deferred taxes | 18,293 |  |
| Provision for inventory excess and obsolescence | 10,245 |  |
| Provision for warranty | 9,276 |  |
| Other | (2,259 | ) |
| Net income (adjusted for non-cash charges) | $ | 212,044 |  |

[0000936395-19-000021:mdna:220]
[same as prior period, unchanged from 0000936395-19-000010:mdna:176]

[0000936395-19-000021:mdna:221]
We used $122.0 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-19-000021:mdna:222]
|  | Six months ended |
|  | April 30, 2019 |
| Cash provided by accounts receivable | $ | 43,174 |  |
| Cash used in inventories | (109,554 | ) |
| Cash used in prepaid expenses and other | (33,241 | ) |
| Cash used in accounts payable, accruals and other obligations | (26,971 | ) |
| Cash provided by deferred revenue | 4,560 |  |
| Total cash used for working capital | $ | (122,032 | ) |

[0000936395-19-000021:mdna:223]
[same as prior period, unchanged from 0000936395-19-000010:mdna:179]

[0000936395-19-000021:mdna:224]
| • | The $43.2 million of cash provided by accounts receivable during the first six months of fiscal 2019 reflects increased cash collections; |

[0000936395-19-000021:mdna:225]
| • | The $109.6 million of cash used in inventory during the first six months of fiscal 2019 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-19-000021:mdna:226]
| • | The $33.2 million of cash used in prepaid expense and other during the first six months of fiscal 2019 primarily reflects increases in contract assets for unbilled accounts receivable due to changes in recognizing revenue for installation services and certain product sales, partially offset by lower non-customer receivables; |

[0000936395-19-000021:mdna:227]
| • | The $27.0 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2019 primarily reflects the timing of bonus payments to employees under our annual cash incentive compensation plan and employee payout of accrued leave in North America due to a new paid time off policy, which was offset by increased inventory purchases during fiscal 2019; and |

[0000936395-19-000021:mdna:228]
| • | The $4.6 million of cash provided by deferred revenue during the first six months of fiscal 2019 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-19-000021:mdna:229]
Our days sales outstanding (“DSOs”) for the first six months of fiscal 2019 were 91 days, and our inventory turns for the first six months of fiscal 2019 were 4.4. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-19-000021:mdna:230]
[same as prior period, unchanged from 0000936395-19-000010:mdna:186]

[0000936395-19-000021:mdna:231]
The following table sets forth the cash paid for interest during the period (in thousands):

[0000936395-19-000021:mdna:232]
|  | Six months ended |
|  | April 30, 2019 |
| Term Loan due September 28, 2025 (1) | $ | 15,718 |  |
| Interest rate swaps(2) | 949 |  |
| ABL Credit Facility(3) | 737 |  |
| Capital leases | 2,574 |  |
| Cash paid during period | $ | 19,978 |  |

[0000936395-19-000021:mdna:233]
| (1) | Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. At the end of the second quarter of fiscal 2019, the interest rate on the 2025 Term Loan was 4.50%. |

[0000936395-19-000021:mdna:234]
[same as prior period, unchanged from 0000936395-19-000010:mdna:190]

[0000936395-19-000021:mdna:235]
| (3) | During the first six months of fiscal 2019, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.7 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility. |

[0000936395-19-000021:mdna:236]
46

[0000936395-19-000021:mdna:237]
[same as prior period, unchanged from 0000936395-19-000010:mdna:192]

[0000936395-19-000021:mdna:238]
[same as prior period, unchanged from 0000936395-19-000010:mdna:193]

[0000936395-19-000021:mdna:239]
[same as prior period, unchanged from 0000936395-19-000010:mdna:195]

[0000936395-19-000021:mdna:240]
[same as prior period, unchanged from 0000936395-19-000010:mdna:196]

[0000936395-19-000021:mdna:241]
[same as prior period, unchanged from 0000936395-19-000010:mdna:197]

[0000936395-19-000021:mdna:242]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-19-000021:mdna:243]
[same as prior period, unchanged from 0000936395-19-000010:mdna:199]

[0000936395-19-000021:mdna:244]
[same as prior period, unchanged from 0000936395-19-000010:mdna:200]

[0000936395-19-000021:mdna:245]
[same as prior period, unchanged from 0000936395-19-000010:mdna:201]

[0000936395-19-000021:mdna:246]
[same as prior period, unchanged from 0000936395-19-000010:mdna:202]

[0000936395-19-000021:mdna:247]
[same as prior period, unchanged from 0000936395-19-000010:mdna:203]
