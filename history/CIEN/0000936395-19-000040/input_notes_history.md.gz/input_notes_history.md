# CIEN note change history — 0000936395-19-000021 → 0000936395-19-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.6 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2019, Ciena has recorded CAD$25.9 million (approximately $19.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$9.3 million (approximately $7.0 million) was recorded in the first nine months of fiscal 2019. As of July 31, 2019, amounts receivable from this grant were CAD$10.8 million (approximately $8.2 million).
  (was, 2019-06-12, similarity 0.8365):
[0000936395-19-000021:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $42.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2019, Ciena has recorded CAD$23.1 million (approximately $17.2 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.5 million (approximately $4.9 million) was recorded in the first six months of fiscal 2019. As of April 30, 2019, amounts receivable from this grant were CAD$7.9 million (approximately $5.9 million).

- changed (2019-09-11):
[0000936395-19-000040:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleged violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and sought unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement was subject to notice to class members and approval by the court. On August 8, 2019, the court approved the settlement and entered judgment in the case. The terms of the settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to Ciena’s financial results.
  (was, 2019-06-12, similarity 0.6388):
[0000936395-19-000021:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement is subject to notice to class members and approval by the court. The terms of the proposed settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to the Ciena’s financial results. There is no assurance that the court will ultimately approve the settlement.

- added (2019-09-11):
[0000936395-19-000040:note_history:3]
As first disclosed in Ciena’s Form 10-K for fiscal 2017, during that year one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act. In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (the “DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it declined to prosecute this matter and that its investigation into this matter is closed. On September 9, 2019, the SEC advised that it has concluded its investigation into this matter and that its staff does not intend to recommend any enforcement action by the SEC against Ciena.

- changed (2019-09-11):
[0000936395-19-000040:note_history:4]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.
  (was, 2019-06-12, similarity 0.8813):
[0000936395-19-000021:note_history:4]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that

- removed (2019-09-11):
[0000936395-19-000021:note_history:5]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it has declined to prosecute this matter and that its investigation into the matter is now closed. Ciena continues to cooperate fully with the SEC in its investigation into this matter.

- removed (2019-09-11):
[0000936395-19-000021:note_history:6]
Ciena’s operations in the relevant country constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year from 2012 through 2017. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

- removed (2019-09-11):
[0000936395-19-000021:note_history:7]
the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:8]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.
  (was, 2019-06-12, similarity 0.9621):
[0000936395-19-000021:note_history:8]
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.

- changed (2019-09-11):
[0000936395-19-000040:note_history:9]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.
  (was, 2019-06-12, similarity 0.9273):
[0000936395-19-000021:note_history:9]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- changed (2019-09-11):
[0000936395-19-000040:note_history:10]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.
  (was, 2019-06-12, similarity 0.972):
[0000936395-19-000021:note_history:10]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration that Ciena expects to be entitled to in exchange for those products or services.

- added (2019-09-11):
[0000936395-19-000040:note_history:11]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- changed (2019-09-11):
[0000936395-19-000040:note_history:12]
|  |  | Quarter Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 960,606 |  |  | $ | (2,413 | ) |  | $ | 958,193 |  |
| Total cost of goods sold |  | $ | 536,254 |  |  | $ | 1,789 |  |  | $ | 538,043 |  |
| Net income |  | $ | 86,749 |  |  | $ | (3,879 | ) |  | $ | 82,870 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.02 | ) |  | $ | 0.53 |  |
  (was, 2019-06-12, similarity 0.7126):
[0000936395-19-000021:note_history:12]
|  |  | Quarter Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 865,011 |  |  | $ | (14,219 | ) |  | $ | 850,792 |  |
| Total cost of goods sold |  | $ | 490,334 |  |  | $ | (13,436 | ) |  | $ | 476,898 |  |
| Net income |  | $ | 52,738 |  |  | $ | (467 | ) |  | $ | 52,271 |  |
| Diluted net income per potential common share |  | $ | 0.33 |  |  | $ | — |  |  | $ | 0.33 |  |

- added (2019-09-11):
[0000936395-19-000040:note_history:13]
|  |  | Nine Months Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 2,604,144 |  |  | $ | (27,533 | ) |  | $ | 2,576,611 |  |
| Total cost of goods sold |  | $ | 1,481,774 |  |  | $ | (20,776 | ) |  | $ | 1,460,998 |  |
| Net income |  | $ | 173,103 |  |  | $ | (4,781 | ) |  | $ | 168,322 |  |
| Diluted net income per potential common share |  | $ | 1.10 |  |  | $ | (0.03 | ) |  | $ | 1.07 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:14]
For the third quarter and first nine months of fiscal 2019, the increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services revenue that was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of July 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.
  (was, 2019-06-12, similarity 0.7314):
[0000936395-19-000021:note_history:14]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of April 30, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

- changed (2019-09-11):
[0000936395-19-000040:note_history:15]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders’ equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
  (was, 2019-06-12, similarity 0.9994):
[0000936395-19-000021:note_history:15]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

- added (2019-09-11):
[0000936395-19-000040:note_history:16]
Restricted Cash in Statement of Cash Flows

- added (2019-09-11):
[0000936395-19-000040:note_history:17]
In November 2016, the FASB issued ASU 2016-18 (“ASU 2016-18”), Statement of Cash Flows (Topic 230): Restricted Cash, which broadens the classification and presentation of changes in restricted cash in the statement of cash flows. Ciena adopted ASU 2016-18 during the first quarter of fiscal 2019. The application of this accounting standard update did not have a material impact on Ciena’s Condensed Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

- removed (2019-09-11):
[0000936395-19-000021:note_history:18]
SIGNIFICANT ACCOUNTING POLICIES

- removed (2019-09-11):
[0000936395-19-000021:note_history:19]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- removed (2019-09-11):
[0000936395-19-000021:note_history:20]
|  |  | Six Months Ended April 30, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 1,643,538 |  |  | $ | (25,119 | ) |  | $ | 1,618,419 |  |
| Total cost of goods sold |  | $ | 945,520 |  |  | $ | (22,565 | ) |  | $ | 922,955 |  |
| Net income |  | $ | 86,354 |  |  | $ | (862 | ) |  | $ | 85,492 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.01 | ) |  | $ | 0.54 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:21]
|  |  | July 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 688,918 |  |  | $ | 693,450 |  |
  (was, 2019-06-12, similarity 0.9637):
[0000936395-19-000021:note_history:21]
|  |  | April 30, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 690,429 |  |  | $ | 693,450 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:22]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.8 million at July 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2019-06-12, similarity 0.9866):
[0000936395-19-000021:note_history:22]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.9 million at April 30, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2019-09-11):
[0000936395-19-000040:note_history:23]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of July 31, 2019 (in thousands):
  (was, 2019-06-12, similarity 0.9805):
[0000936395-19-000021:note_history:23]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of April 30, 2019 (in thousands):


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:24]
|  | July 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
|  | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
  (was, 2019-06-12, similarity 0.7487):
[0000936395-19-000021:note_history:24]
|  | April 30, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
|  | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:25]
|  | July 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
|  | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
  (was, 2019-06-12, similarity 0.7487):
[0000936395-19-000021:note_history:25]
|  | April 30, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |
|  | $ | 119,316 |  |  | $ | 47 |  |  | $ | (36 | ) |  | $ | 119,327 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:26]
The following table summarizes the final legal maturities of debt investments at July 31, 2019 (in thousands):
  (was, 2019-06-12, similarity 0.9668):
[0000936395-19-000021:note_history:26]
The following table summarizes the final legal maturities of debt investments at April 30, 2019 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:27]
|  |  | July 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 688,918 |  |  | $ | 693,450 |  |
  (was, 2019-06-12, similarity 0.9637):
[0000936395-19-000021:note_history:27]
|  |  | April 30, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 690,429 |  |  | $ | 693,450 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:28]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of July 31, 2019 (in thousands):
  (was, 2019-06-12, similarity 0.9805):
[0000936395-19-000021:note_history:28]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of April 30, 2019 (in thousands):


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:29]
|  | Quarter Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 14,598 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 33,244 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
  (was, 2019-06-12, similarity 0.9955):
[0000936395-19-000021:note_history:29]
|  | Quarter Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 14,148 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 33,554 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:30]
|  | Nine Months Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 51,017 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Products and services transferred over time | — |  |  | 101,099 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
  (was, 2019-06-12, similarity 0.9857):
[0000936395-19-000021:note_history:30]
|  | Six Months Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 36,420 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 67,854 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:31]
|  |  | Quarter Ended July 31, 2019 |  | Nine Months Ended July 31, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 617,000 |  |  | $ | 1,678,599 |  |
| EMEA |  | 169,532 |  |  | 413,715 |  |
| CALA |  | 39,261 |  |  | 109,635 |  |
| APAC |  | 134,813 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 960,606 |  |  | $ | 2,604,144 |  |
  (was, 2019-06-12, similarity 0.9244):
[0000936395-19-000021:note_history:31]
|  |  | Quarter Ended April 30, 2019 |  | Six Months Ended April 30, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 576,093 |  |  | $ | 1,061,599 |  |
| EMEA |  | 114,993 |  |  | 244,183 |  |
| CALA |  | 39,399 |  |  | 70,374 |  |
| APAC |  | 134,526 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 865,011 |  |  | $ | 1,643,538 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:32]
REVENUE
Disaggregation of Revenue
  (was, 2019-06-12, similarity 0.8621):
[0000936395-19-000021:note_history:32]
Disaggregation of Revenue

- changed (2019-09-11):
[0000936395-19-000040:note_history:33]
|  | Quarter Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 14,598 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 33,244 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
  (was, 2019-06-12, similarity 0.9955):
[0000936395-19-000021:note_history:33]
|  | Quarter Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 14,148 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 33,554 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 47,702 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:34]
|  | Nine Months Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 51,017 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Products and services transferred over time | — |  |  | 101,099 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
  (was, 2019-06-12, similarity 0.9857):
[0000936395-19-000021:note_history:34]
|  | Six Months Ended April 30, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 36,420 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 67,854 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 104,274 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:35]
|  |  | Quarter Ended July 31, 2019 |  | Nine Months Ended July 31, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 617,000 |  |  | $ | 1,678,599 |  |
| EMEA |  | 169,532 |  |  | 413,715 |  |
| CALA |  | 39,261 |  |  | 109,635 |  |
| APAC |  | 134,813 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 960,606 |  |  | $ | 2,604,144 |  |
  (was, 2019-06-12, similarity 0.9244):
[0000936395-19-000021:note_history:35]
|  |  | Quarter Ended April 30, 2019 |  | Six Months Ended April 30, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 576,093 |  |  | $ | 1,061,599 |  |
| EMEA |  | 114,993 |  |  | 244,183 |  |
| CALA |  | 39,399 |  |  | 70,374 |  |
| APAC |  | 134,526 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 865,011 |  |  | $ | 1,643,538 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:36]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |
  (was, 2019-06-12, similarity 0.9944):
[0000936395-19-000021:note_history:36]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

- changed (2019-09-11):
[0000936395-19-000040:note_history:37]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |
  (was, 2019-06-12, similarity 0.9995):
[0000936395-19-000021:note_history:37]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

- changed (2019-09-11):
[0000936395-19-000040:note_history:38]
| • | Ciena’s Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |
  (was, 2019-06-12, similarity 0.9887):
[0000936395-19-000021:note_history:38]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

- changed (2019-09-11):
[0000936395-19-000040:note_history:39]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2019-06-12, similarity 0.9956):
[0000936395-19-000021:note_history:39]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services are generally recognized at a point in time upon completion of the service.

- changed (2019-09-11):
[0000936395-19-000040:note_history:40]
|  |  | Balance at July 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 798,884 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,348 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,030 |  |  | $ | 140,704 |  |
  (was, 2019-06-12, similarity 0.9249):
[0000936395-19-000021:note_history:40]
|  |  | Balance at April 30, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 756,607 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,439 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,022 |  |  | $ | 140,704 |  |

- changed (2019-09-11):
[0000936395-19-000040:note_history:41]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.
  (was, 2019-06-12, similarity 0.9771):
[0000936395-19-000021:note_history:41]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.

- changed (2019-09-11):
[0000936395-19-000040:note_history:42]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $77.4 million of revenue during the first nine months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2019.
  (was, 2019-06-12, similarity 0.8996):
[0000936395-19-000021:note_history:42]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $73.0 million of revenue during the first six months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial during the six months ended April 30, 2019.

- changed (2019-09-11):
[0000936395-19-000040:note_history:43]
Capitalized contract acquisition costs consist of deferred sales commissions and were $13.2 million and $13.6 million as of July 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $12.5 million during the first nine months of fiscal 2019 and was included in sales and marketing expense.
  (was, 2019-06-12, similarity 0.9787):
[0000936395-19-000021:note_history:43]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.2 million and $13.6 million as of April 30, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $8.4 million during the first six months of fiscal 2019 and was included in sales and marketing expense.

- added (2019-09-11):
[0000936395-19-000040:note_history:44]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2019, the aggregate amount of RPO was $1.15 billion. As of July 31, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.

- removed (2019-09-11):
[0000936395-19-000021:note_history:45]
REVENUE

- removed (2019-09-11):
[0000936395-19-000021:note_history:46]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2019, the aggregate amount of RPO was $1.28 billion. As of April 30, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-09-11):
[0000936395-19-000040:note_history:47]
From the end of the third quarter of fiscal 2019 through September 6, 2019, Ciena repurchased an additional 417,819 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $41.38 per share, inclusive of repurchases pending settlement. As of September 6, 2019, Ciena has repurchased an aggregate of 3,299,383 shares and has an aggregate of $370.8 million of authorized funds remaining under its Stock Repurchase Program.
  (was, 2019-06-12, similarity 0.9584):
[0000936395-19-000021:note_history:47]
From the end of the second quarter of fiscal 2019 through June 7, 2019, Ciena repurchased an additional 485,235 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $35.63 per share, inclusive of repurchases pending settlement. As of June 7, 2019, Ciena has repurchased an aggregate of 2,237,760 shares and has an aggregate of $416.2 million of authorized funds remaining under its Stock Repurchase Program.
