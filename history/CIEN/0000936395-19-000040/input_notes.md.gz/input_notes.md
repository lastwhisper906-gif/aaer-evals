# CIEN notes — 0000936395-19-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-19-000040:notes:1]
[same as prior period, unchanged from 0000936395-19-000021:notes:1]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-19-000040:notes:2]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.

[0000936395-19-000040:notes:3]
[same as prior period, unchanged from 0000936395-19-000021:notes:4]

[0000936395-19-000040:notes:4]
[same as prior period, unchanged from 0000936395-19-000021:notes:5]

[0000936395-19-000040:notes:5]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-19-000040:notes:6]
[same as prior period, unchanged from 0000936395-19-000021:notes:7]

[0000936395-19-000040:notes:7]
[same as prior period, unchanged from 0000936395-19-000021:notes:8]

[0000936395-19-000040:notes:8]
[same as prior period, unchanged from 0000936395-19-000021:notes:9]

[0000936395-19-000040:notes:9]
[same as prior period, unchanged from 0000936395-19-000021:notes:10]

[0000936395-19-000040:notes:10]
[same as prior period, unchanged from 0000936395-19-000021:notes:11]

[0000936395-19-000040:notes:11]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-19-000040:notes:12]
[same as prior period, unchanged from 0000936395-19-000021:notes:13]

[0000936395-19-000040:notes:13]
[same as prior period, unchanged from 0000936395-19-000021:notes:14]

[0000936395-19-000040:notes:14]
[same as prior period, unchanged from 0000936395-19-000021:notes:15]

[0000936395-19-000040:notes:15]
[same as prior period, unchanged from 0000936395-19-000021:notes:16]

[0000936395-19-000040:notes:16]
[same as prior period, unchanged from 0000936395-19-000021:notes:17]

[0000936395-19-000040:notes:17]
[same as prior period, unchanged from 0000936395-19-000021:notes:18]

[0000936395-19-000040:notes:18]
[same as prior period, unchanged from 0000936395-19-000021:notes:19]

[0000936395-19-000040:notes:19]
[same as prior period, unchanged from 0000936395-19-000021:notes:20]

[0000936395-19-000040:notes:20]
[same as prior period, unchanged from 0000936395-19-000021:notes:21]

[0000936395-19-000040:notes:21]
[same as prior period, unchanged from 0000936395-19-000021:notes:22]

[0000936395-19-000040:notes:22]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-19-000040:notes:23]
[same as prior period, unchanged from 0000936395-19-000021:notes:24]

[0000936395-19-000040:notes:24]
[same as prior period, unchanged from 0000936395-19-000021:notes:25]

[0000936395-19-000040:notes:25]
[same as prior period, unchanged from 0000936395-19-000021:notes:26]

[0000936395-19-000040:notes:26]
[same as prior period, unchanged from 0000936395-19-000021:notes:27]

[0000936395-19-000040:notes:27]
[same as prior period, unchanged from 0000936395-19-000021:notes:28]

[0000936395-19-000040:notes:28]
[same as prior period, unchanged from 0000936395-19-000021:notes:29]

[0000936395-19-000040:notes:29]
[same as prior period, unchanged from 0000936395-19-000021:notes:30]

[0000936395-19-000040:notes:30]
|  |  | Quarter Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 960,606 |  |  | $ | (2,413 | ) |  | $ | 958,193 |  |
| Total cost of goods sold |  | $ | 536,254 |  |  | $ | 1,789 |  |  | $ | 538,043 |  |
| Net income |  | $ | 86,749 |  |  | $ | (3,879 | ) |  | $ | 82,870 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.02 | ) |  | $ | 0.53 |  |

[0000936395-19-000040:notes:31]
|  |  | Nine Months Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 2,604,144 |  |  | $ | (27,533 | ) |  | $ | 2,576,611 |  |
| Total cost of goods sold |  | $ | 1,481,774 |  |  | $ | (20,776 | ) |  | $ | 1,460,998 |  |
| Net income |  | $ | 173,103 |  |  | $ | (4,781 | ) |  | $ | 168,322 |  |
| Diluted net income per potential common share |  | $ | 1.10 |  |  | $ | (0.03 | ) |  | $ | 1.07 |  |

[0000936395-19-000040:notes:32]
For the third quarter and first nine months of fiscal 2019, the increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services revenue that was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of July 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

[0000936395-19-000040:notes:33]
[same as prior period, unchanged from 0000936395-19-000021:notes:34]

[0000936395-19-000040:notes:34]
[same as prior period, unchanged from 0000936395-19-000021:notes:35]

[0000936395-19-000040:notes:35]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders’ equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

[0000936395-19-000040:notes:36]
[same as prior period, unchanged from 0000936395-19-000021:notes:37]

[0000936395-19-000040:notes:37]
[same as prior period, unchanged from 0000936395-19-000021:notes:38]

[0000936395-19-000040:notes:38]
[same as prior period, unchanged from 0000936395-19-000021:notes:39]

[0000936395-19-000040:notes:39]
[same as prior period, unchanged from 0000936395-19-000021:notes:40]

[0000936395-19-000040:notes:40]
[same as prior period, unchanged from 0000936395-19-000021:notes:41]

[0000936395-19-000040:notes:41]
[same as prior period, unchanged from 0000936395-19-000021:notes:42]

[0000936395-19-000040:notes:42]
[same as prior period, unchanged from 0000936395-19-000021:notes:43]

[0000936395-19-000040:notes:43]
[same as prior period, unchanged from 0000936395-19-000021:notes:44]

[0000936395-19-000040:notes:44]
[same as prior period, unchanged from 0000936395-19-000021:notes:45]

[0000936395-19-000040:notes:45]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software, which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software.

[0000936395-19-000040:notes:46]
Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

[0000936395-19-000040:notes:47]
Restricted Cash in Statement of Cash Flows

[0000936395-19-000040:notes:48]
In November 2016, the FASB issued ASU 2016-18 (“ASU 2016-18”), Statement of Cash Flows (Topic 230): Restricted Cash, which broadens the classification and presentation of changes in restricted cash in the statement of cash flows. Ciena adopted ASU 2016-18 during the first quarter of fiscal 2019. The application of this accounting standard update did not have a material impact on Ciena’s Condensed Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0000936395-19-000040:notes:49]
[same as prior period, unchanged from 0000936395-19-000021:notes:48]

[0000936395-19-000040:notes:50]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be recognized as assets and liabilities on Ciena’s balance sheet. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-19-000040:notes:51]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and disclosures.

[0000936395-19-000040:notes:52]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020 and early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-19-000040:notes:53]
REVENUE
Disaggregation of Revenue

[0000936395-19-000040:notes:54]
[same as prior period, unchanged from 0000936395-19-000021:notes:54]

[0000936395-19-000040:notes:55]
[same as prior period, unchanged from 0000936395-19-000021:notes:55]

[0000936395-19-000040:notes:56]
|  | Quarter Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 14,598 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 33,244 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |

[0000936395-19-000040:notes:57]
|  | Nine Months Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 51,017 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Products and services transferred over time | — |  |  | 101,099 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |

[0000936395-19-000040:notes:58]
|  |  | Quarter Ended July 31, 2019 |  | Nine Months Ended July 31, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 617,000 |  |  | $ | 1,678,599 |  |
| EMEA |  | 169,532 |  |  | 413,715 |  |
| CALA |  | 39,261 |  |  | 109,635 |  |
| APAC |  | 134,813 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 960,606 |  |  | $ | 2,604,144 |  |

[0000936395-19-000040:notes:59]
[same as prior period, unchanged from 0000936395-19-000021:notes:59]

[0000936395-19-000040:notes:60]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-19-000040:notes:61]
[same as prior period, unchanged from 0000936395-19-000021:notes:61]

[0000936395-19-000040:notes:62]
[same as prior period, unchanged from 0000936395-19-000021:notes:62]

[0000936395-19-000040:notes:63]
[same as prior period, unchanged from 0000936395-19-000021:notes:63]

[0000936395-19-000040:notes:64]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

[0000936395-19-000040:notes:65]
| • | Ciena’s Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

[0000936395-19-000040:notes:66]
[same as prior period, unchanged from 0000936395-19-000021:notes:66]

[0000936395-19-000040:notes:67]
[same as prior period, unchanged from 0000936395-19-000021:notes:67]

[0000936395-19-000040:notes:68]
[same as prior period, unchanged from 0000936395-19-000021:notes:68]

[0000936395-19-000040:notes:69]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-19-000040:notes:70]
[same as prior period, unchanged from 0000936395-19-000021:notes:70]

[0000936395-19-000040:notes:71]
[same as prior period, unchanged from 0000936395-19-000021:notes:71]

[0000936395-19-000040:notes:72]
|  |  | Balance at July 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 798,884 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,348 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,030 |  |  | $ | 140,704 |  |

[0000936395-19-000040:notes:73]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.

[0000936395-19-000040:notes:74]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $77.4 million of revenue during the first nine months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2019.

[0000936395-19-000040:notes:75]
Capitalized contract acquisition costs consist of deferred sales commissions and were $13.2 million and $13.6 million as of July 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $12.5 million during the first nine months of fiscal 2019 and was included in sales and marketing expense.

[0000936395-19-000040:notes:76]
[same as prior period, unchanged from 0000936395-19-000021:notes:76]

[0000936395-19-000040:notes:77]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2019, the aggregate amount of RPO was $1.15 billion. As of July 31, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-19-000040:notes:78]
BUSINESS COMBINATIONS

[0000936395-19-000040:notes:79]
Packet Design, LLC Acquisition

[0000936395-19-000040:notes:80]
On July 2, 2018, Ciena acquired Packet Design, LLC (“Packet Design”), a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics, for approximately $41 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-19-000040:notes:81]
During the third quarter of fiscal 2018, Ciena incurred approximately $1.3 million of acquisition-related costs associated with this transaction. These costs and expenses included fees associated with financial, legal and accounting advisors and severance and other employment-related costs, including payments to certain former Packet Design employees.

[0000936395-19-000040:notes:82]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-19-000040:notes:83]
|  | Amount |
| Cash and cash equivalents | $ | 642 |  |
| Accounts receivable | 1,525 |  |
| Prepaid expenses and other | 450 |  |
| Equipment, furniture and fixtures | 31 |  |
| Goodwill | 20,304 |  |
| Customer relationships and contracts | 2,200 |  |
| Developed technology | 21,900 |  |
| Accounts payable | (165 | ) |
| Accrued liabilities | (657 | ) |
| Deferred revenue | (5,176 | ) |
| Total purchase consideration | $ | 41,054 |  |

[0000936395-19-000040:notes:84]
Customer relationships and contracts represent agreements with existing Packet Design customers and have an estimated useful life of three years.

[0000936395-19-000040:notes:85]
Developed technology represents purchased technology that had reached technological feasibility and for which Packet Design had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-19-000040:notes:86]
The goodwill generated from the acquisition of Packet Design is primarily related to expected synergies. The total goodwill amount was recorded in the Software and Software-Related Services segment.

[0000936395-19-000040:notes:87]
Pro forma disclosures have not been included due to immateriality.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-19-000040:notes:88]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2019 (in thousands):

[0000936395-19-000040:notes:89]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Additional liability recorded | 10,309 |  | (1) | 1,387 |  | (2) | 11,696 |  |
| Cash payments | (10,021 | ) |  | (1,631 | ) |  | (11,652 | ) |
| Balance at July 31, 2019 | $ | 2,396 |  |  | $ | 1,495 |  |  | $ | 3,891 |  |
| Current restructuring liabilities | $ | 2,396 |  |  | $ | 348 |  |  | $ | 2,744 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,147 |  |  | $ | 1,147 |  |

[0000936395-19-000040:notes:90]
| (1) | Reflects a global workforce reduction of approximately 225 employees during the nine months ended July 31, 2019 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000040:notes:91]
[same as prior period, unchanged from 0000936395-19-000021:notes:82]

[0000936395-19-000040:notes:92]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2018 (in thousands):

[0000936395-19-000040:notes:93]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 12,876 |  | (1) | 3,803 |  | (2) | 16,679 |  |
| Cash payments | (10,987 | ) |  | (3,084 | ) |  | (14,071 | ) |
| Balance at July 31, 2018 | $ | 3,180 |  |  | $ | 2,367 |  |  | $ | 5,547 |  |
| Current restructuring liabilities | $ | 3,180 |  |  | $ | 1,076 |  |  | $ | 4,256 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,291 |  |  | $ | 1,291 |  |

[0000936395-19-000040:notes:94]
| (1) | Reflects a global workforce reduction of approximately 230 employees during the nine months ended July 31, 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000040:notes:95]
(2)
Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and  Gurgaon, India.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-19-000040:notes:96]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income, net, are as follows (in thousands):

[0000936395-19-000040:notes:97]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Interest income | $ | 3,475 |  |  | $ | 3,620 |  |  | $ | 10,866 |  |  | $ | 9,276 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 119 |  |  | 2,182 |  |  | (757 | ) |  | 4,351 |  |
| Foreign currency exchange losses | (2,373 | ) |  | (6,879 | ) |  | (4,585 | ) |  | (11,670 | ) |
| Other | (171 | ) |  | (466 | ) |  | (465 | ) |  | (629 | ) |
| Interest and other income (loss), net | $ | 1,050 |  |  | $ | (1,543 | ) |  | $ | 5,059 |  |  | $ | 1,328 |  |

[0000936395-19-000040:notes:98]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $4.6 million and $11.7 million in foreign currency exchange rate losses during the first nine months of fiscal 2019 and fiscal 2018, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the remeasurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. During the first nine months of fiscal 2019, Ciena recorded losses of $0.8 million from non-hedge designated foreign currency forward contracts. During the first nine months of fiscal 2018, Ciena recorded gains of $4.4 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-19-000040:notes:99]
[same as prior period, unchanged from 0000936395-19-000021:notes:92]

[0000936395-19-000040:notes:100]
[same as prior period, unchanged from 0000936395-19-000021:notes:93]

[0000936395-19-000040:notes:101]
The effective tax rate for the third quarter and nine months ended July 31, 2019 was lower than the effective tax rate for the third quarter and nine months ended July 31, 2018, primarily due to the impact of the Tax Act. The reduction of the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018, required the remeasurement of net deferred tax assets and liabilities (“DTA”). Ciena also recorded U.S. transition tax in the nine months ended July 31, 2018.

[0000936395-19-000040:notes:102]
As of July 31, 2019, Ciena continues to maintain a valuation allowance primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use. Ciena will continue to monitor its forecasts and results and may adjust the valuation allowance as conditions change.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-19-000040:notes:103]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-19-000040:notes:104]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-19-000040:notes:105]
|  | July 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
|  | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |

[0000936395-19-000040:notes:106]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

[0000936395-19-000040:notes:107]
The following table summarizes the final legal maturities of debt investments at July 31, 2019 (in thousands):

[0000936395-19-000040:notes:108]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 119,490 |  |  | $ | 119,670 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-19-000040:notes:109]
[same as prior period, unchanged from 0000936395-19-000021:notes:101]

[0000936395-19-000040:notes:110]
[same as prior period, unchanged from 0000936395-19-000021:notes:102]

[0000936395-19-000040:notes:111]
|  | July 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 595,556 |  |  | $ | — |  |  | $ | — |  |  | $ | 595,556 |  |
| U.S. government obligations | — |  |  | 119,670 |  |  | — |  |  | 119,670 |  |
| Foreign currency forward contracts | — |  |  | 882 |  |  | — |  |  | 882 |  |
| Total assets measured at fair value | $ | 595,556 |  |  | $ | 120,552 |  |  | $ | — |  |  | $ | 716,108 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,029 |  |  | $ | — |  |  | $ | 1,029 |  |
| Forward starting interest rate swap | — |  |  | 20,963 |  |  | — |  |  | 20,963 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,992 |  |  | $ | 10,900 |  |  | $ | 32,892 |  |

[0000936395-19-000040:notes:112]
[same as prior period, unchanged from 0000936395-19-000021:notes:104]

[0000936395-19-000040:notes:113]
[same as prior period, unchanged from 0000936395-19-000021:notes:105]

[0000936395-19-000040:notes:114]
|  | July 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 595,556 |  |  | $ | — |  |  | $ | — |  |  | $ | 595,556 |  |
| Short-term investments | — |  |  | 119,670 |  |  | — |  |  | 119,670 |  |
| Prepaid expenses and other | — |  |  | 882 |  |  | — |  |  | 882 |  |
| Total assets measured at fair value | $ | 595,556 |  |  | $ | 120,552 |  |  | $ | — |  |  | $ | 716,108 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,029 |  |  | $ | 7,491 |  |  | $ | 8,520 |  |
| Other long-term obligations | — |  |  | 20,963 |  |  | 3,409 |  |  | 24,372 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,992 |  |  | $ | 10,900 |  |  | $ | 32,892 |  |

[0000936395-19-000040:notes:115]
[same as prior period, unchanged from 0000936395-19-000021:notes:107]

[0000936395-19-000040:notes:116]
[same as prior period, unchanged from 0000936395-19-000021:notes:108]

[0000936395-19-000040:notes:117]
Ciena’s Level 3 liability is included in both accrued liabilities and other long-term obligations and reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. The contingent consideration is valued by applying the income approach based upon a discounted cash flow technique using Monte Carlo simulations. As of July 31, 2019, there was no material change to the fair value.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-19-000040:notes:118]
[same as prior period, unchanged from 0000936395-19-000021:notes:110]

[0000936395-19-000040:notes:119]
|  | July 31, 2019 |  | October 31, 2018 |
| Raw materials | $ | 102,240 |  |  | $ | 67,468 |  |
| Work-in-process | 15,456 |  |  | 9,589 |  |
| Finished goods | 193,487 |  |  | 188,575 |  |
| Deferred cost of goods sold | 93,448 |  |  | 48,057 |  |
|  | 404,631 |  |  | 313,689 |  |
| Provision for excess and obsolescence | (47,813 | ) |  | (50,938 | ) |
|  | $ | 356,818 |  |  | $ | 262,751 |  |

[0000936395-19-000040:notes:120]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2019, Ciena recorded a provision for excess and obsolescence of $18.8 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-19-000040:notes:121]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-19-000040:notes:122]
|  | July 31, 2019 |  | October 31, 2018 |
| Prepaid VAT and other taxes | $ | 84,359 |  |  | $ | 82,518 |  |
| Contract assets for unbilled accounts receivable | 74,348 |  |  | — |  |
| Product demonstration equipment, net | 39,977 |  |  | 37,623 |  |
| Prepaid expenses | 46,666 |  |  | 32,987 |  |
| Other non-trade receivables | 36,798 |  |  | 25,716 |  |
| Capitalized commissions - short term | 9,601 |  |  | — |  |
| Financing receivable | — |  |  | 626 |  |
| Deferred deployment expense | — |  |  | 19,342 |  |
| Derivative assets | 882 |  |  | 133 |  |
|  | $ | 292,631 |  |  | $ | 198,945 |  |

[0000936395-19-000040:notes:123]
Depreciation of product demonstration equipment was $6.5 million and $6.8 million during the first nine months of fiscal 2019 and 2018, respectively.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-19-000040:notes:124]
[same as prior period, unchanged from 0000936395-19-000021:notes:117]

[0000936395-19-000040:notes:125]
|  | July 31, 2019 |  | October 31, 2018 |
| Compensation, payroll related tax and benefits | $ | 125,651 |  |  | $ | 140,277 |  |
| Warranty | 46,680 |  |  | 44,740 |  |
| Vacation (1) | 22,076 |  |  | 42,507 |  |
| Contingent consideration | 7,491 |  |  | — |  |
| Capital lease obligations | 2,798 |  |  | 3,547 |  |
| Interest payable | 1,062 |  |  | 1,072 |  |
| Other | 119,379 |  |  | 107,932 |  |
|  | $ | 325,137 |  |  | $ | 340,075 |  |

[0000936395-19-000040:notes:126]
(1) Reduction is primarily due to the payout of North America vacation accruals in conjunction with adoption of a new vacation policy.

[0000936395-19-000040:notes:127]
[same as prior period, unchanged from 0000936395-19-000021:notes:121]

[0000936395-19-000040:notes:128]
| Nine Months Ended July 31, |  | Beginning Balance |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| 2018 |  | $ | 42,456 |  |  | 15,715 |  |  | (14,021 | ) |  | $ | 44,150 |  |
| 2019 |  | $ | 44,740 |  |  | 15,933 |  |  | (13,993 | ) |  | $ | 46,680 |  |

[0000936395-19-000040:notes:129]
Settlement of Conversions of 3.75% Convertible Senior Notes due October 15, 2018 (“New Notes”)

[0000936395-19-000040:notes:130]
[same as prior period, unchanged from 0000936395-19-000021:notes:124]

[0000936395-19-000040:notes:131]
[same as prior period, unchanged from 0000936395-19-000021:notes:125]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-19-000040:notes:132]
[same as prior period, unchanged from 0000936395-19-000021:notes:126]

[0000936395-19-000040:notes:133]
[same as prior period, unchanged from 0000936395-19-000021:notes:127]

[0000936395-19-000040:notes:134]
As of July 31, 2019 and October 31, 2018, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar- and Indian Rupee-denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $142.0 million and $163.2 million as of July 31, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-19-000040:notes:135]
During the first nine months of fiscal 2019 and fiscal 2018, in order to hedge foreign exchange exposures of certain balance sheet items, Ciena entered into forward contracts to mitigate risk due to variability in various currencies. The notional amount of these contracts was approximately $193.3 million and $162.6 million as of July 31, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-19-000040:notes:136]
[same as prior period, unchanged from 0000936395-19-000021:notes:130]

[0000936395-19-000040:notes:137]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 15 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of July 31, 2019 and October 31, 2018.

[0000936395-19-000040:notes:138]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-19-000040:notes:139]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 6 and Note 9 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-19-000040:notes:140]
[same as prior period, unchanged from 0000936395-19-000021:notes:134]

[0000936395-19-000040:notes:141]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended July 31, 2019:

[0000936395-19-000040:notes:142]
|  | Unrealized |  | Unrealized Loss on |  | Unrealized Loss on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2018 | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |
| Other comprehensive income (loss) before reclassifications | 581 |  |  | (349 | ) |  | (18,370 | ) |  | (1,903 | ) |  | (20,041 | ) |
| Amounts reclassified from AOCI | — |  |  | 3,100 |  |  | (1,043 | ) |  | — |  |  | 2,057 |  |
| Balance at July 31, 2019 | $ | 156 |  |  | $ | (309 | ) |  | $ | (12,996 | ) |  | $ | (10,615 | ) |  | $ | (23,764 | ) |

[0000936395-19-000040:notes:143]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended July 31, 2018:

[0000936395-19-000040:notes:144]
|  | Unrealized |  | Unrealized Losson |  | Unrealized Gain on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (59 | ) |  | (9 | ) |  | 5,330 |  |  | (2,161 | ) |  | 3,101 |  |
| Amounts reclassified from AOCI | — |  |  | (1,058 | ) |  | 269 |  |  | — |  |  | (789 | ) |
| Balance at July 31, 2018 | $ | (510 | ) |  | $ | (2,453 | ) |  | $ | 5,817 |  |  | $ | (11,559 | ) |  | $ | (8,705 | ) |

[0000936395-19-000040:notes:145]
[same as prior period, unchanged from 0000936395-19-000021:notes:139]


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-19-000040:notes:146]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-19-000040:notes:147]
Outstanding Term Loan Payable

[0000936395-19-000040:notes:148]
2025 Term Loan

[0000936395-19-000040:notes:149]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-19-000040:notes:150]
|  |  | July 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 688,918 |  |  | $ | 693,450 |  |

[0000936395-19-000040:notes:151]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.8 million at July 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-19-000040:notes:152]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of July 31, 2019 (in thousands):

[0000936395-19-000040:notes:153]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 694,750 |  |  | $ | (2,043 | ) |  | $ | (3,789 | ) |  | $ | 688,918 |  |  | $ | 696,487 |  |

[0000936395-19-000040:notes:154]
(1)

[0000936395-19-000040:notes:155]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-19-000040:notes:156]
EARNINGS PER SHARE CALCULATION
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-19-000040:notes:157]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net income (loss) | $ | 86,749 |  |  | $ | 50,840 |  |  | $ | 173,103 |  |  | $ | (408,667 | ) |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original) | — |  |  | 464 |  |  | — |  |  | — |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | — |  |  | 2,624 |  |  | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | 86,749 |  |  | $ | 53,928 |  |  | $ | 173,103 |  |  | $ | (408,667 | ) |

[0000936395-19-000040:notes:158]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Basic weighted average shares outstanding | 155,488 |  |  | 143,400 |  |  | 156,013 |  |  | 143,766 |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 1,967 |  |  | 1,330 |  |  | 1,936 |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New) | — |  |  | 3,032 |  |  | — |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original) | — |  |  | 3,038 |  |  | — |  |  | — |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | — |  |  | 9,198 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 157,455 |  |  | 159,998 |  |  | 157,949 |  |  | 143,766 |  |

[0000936395-19-000040:notes:159]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Basic EPS | $ | 0.56 |  |  | $ | 0.35 |  |  | $ | 1.11 |  |  | $ | (2.84 | ) |
| Diluted EPS | $ | 0.55 |  |  | $ | 0.34 |  |  | $ | 1.10 |  |  | $ | (2.84 | ) |

[0000936395-19-000040:notes:160]
[same as prior period, unchanged from 0000936395-19-000021:notes:155]

[0000936395-19-000040:notes:161]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Shares underlying stock options and stock unit awards | 253 |  |  | 318 |  |  | 256 |  |  | 2,183 |  |
| 3.75% Convertible Senior Notes due 2018 (Original) | — |  |  | — |  |  | — |  |  | 3,038 |  |
| 3.75% Convertible Senior Notes due 2018 (New) | — |  |  | — |  |  | — |  |  | 2,125 |  |
| 4.0% Convertible Senior Notes due 2020 | — |  |  | — |  |  | — |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 253 |  |  | 318 |  |  | 256 |  |  | 16,544 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-19-000040:notes:162]
[same as prior period, unchanged from 0000936395-19-000021:notes:157]

[0000936395-19-000040:notes:163]
[same as prior period, unchanged from 0000936395-19-000021:notes:158]

[0000936395-19-000040:notes:164]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-19-000040:notes:165]
The following table summarizes activity of the stock repurchase program, reported based on trade date:

[0000936395-19-000040:notes:166]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2018 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 2,881,564 |  |  | 38.84 |  |  | 111,925 |  |
| Cumulative balance at July 31, 2019 | 2,881,564 |  |  | $ | 38.84 |  |  | $ | 111,925 |  |

[0000936395-19-000040:notes:167]
[same as prior period, unchanged from 0000936395-19-000021:notes:162]

[0000936395-19-000040:notes:168]
[same as prior period, unchanged from 0000936395-19-000021:notes:163]

[0000936395-19-000040:notes:169]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The purchase price of $23.2 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2019 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-19-000040:notes:170]
[same as prior period, unchanged from 0000936395-19-000021:notes:165]

[0000936395-19-000040:notes:171]
[same as prior period, unchanged from 0000936395-19-000021:notes:166]

[0000936395-19-000040:notes:172]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Product costs | $ | 781 |  |  | $ | 783 |  |  | $ | 2,120 |  |  | $ | 2,279 |  |
| Service costs | 783 |  |  | 618 |  |  | 2,460 |  |  | 1,965 |  |
| Share-based compensation expense included in cost of sales | 1,564 |  |  | 1,401 |  |  | 4,580 |  |  | 4,244 |  |
| Research and development | 3,560 |  |  | 3,082 |  |  | 11,034 |  |  | 10,133 |  |
| Sales and marketing | 4,192 |  |  | 3,417 |  |  | 12,323 |  |  | 10,505 |  |
| General and administrative | 5,813 |  |  | 4,538 |  |  | 16,416 |  |  | 14,121 |  |
| Share-based compensation expense included in operating expense | 13,565 |  |  | 11,037 |  |  | 39,773 |  |  | 34,759 |  |
| Share-based compensation expense capitalized in inventory, net | (45 | ) |  | (101 | ) |  | 93 |  |  | (107 | ) |
| Total share-based compensation | $ | 15,084 |  |  | $ | 12,337 |  |  | $ | 44,446 |  |  | $ | 38,896 |  |

[0000936395-19-000040:notes:173]
As of July 31, 2019, total unrecognized share-based compensation expense was approximately $98.8 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-19-000040:notes:174]
[same as prior period, unchanged from 0000936395-19-000021:notes:169]

[0000936395-19-000040:notes:175]
[same as prior period, unchanged from 0000936395-19-000021:notes:170]

[0000936395-19-000040:notes:176]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2019, equipment, building, furniture and fixtures, net totaled $280.6 million, primarily supporting asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and supporting Ciena’s unallocated selling and general and administrative activities. As of July 31, 2019, $22.7 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Networking Platforms segment and $98.6 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of July 31, 2019, $65.7 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Networking Platforms segment and $232.2 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of July 31, 2019, all of the maintenance spares, net, totaling $51.1 million, were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-19-000040:notes:177]
[same as prior period, unchanged from 0000936395-19-000021:notes:172]

[0000936395-19-000040:notes:178]
[same as prior period, unchanged from 0000936395-19-000021:notes:173]

[0000936395-19-000040:notes:179]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | 592,892 |  |  | $ | 1,897,080 |  |  | $ | 1,548,189 |  |
| Packet Networking | 71,823 |  |  | 84,559 |  |  | 216,529 |  |  | 216,977 |  |
| Total Networking Platforms | 796,068 |  |  | 677,451 |  |  | 2,113,609 |  |  | 1,765,166 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Platform Software and Services | 37,312 |  |  | 36,818 |  |  | 114,139 |  |  | 117,347 |  |
| Blue Planet Automation Software and Services | 10,530 |  |  | 4,365 |  |  | 37,977 |  |  | 16,068 |  |
| Total Software and Software-Related Services | 47,842 |  |  | 41,183 |  |  | 152,116 |  |  | 133,415 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 65,936 |  |  | 60,897 |  |  | 196,002 |  |  | 177,759 |  |
| Installation and Deployment | 39,802 |  |  | 31,262 |  |  | 111,746 |  |  | 89,487 |  |
| Consulting and Network Design | 10,958 |  |  | 8,024 |  |  | 30,671 |  |  | 29,103 |  |
| Total Global Services | 116,696 |  |  | 100,183 |  |  | 338,419 |  |  | 296,349 |  |
| Consolidated revenue | $ | 960,606 |  |  | $ | 818,817 |  |  | $ | 2,604,144 |  |  | $ | 2,194,930 |  |

[0000936395-19-000040:notes:180]
[same as prior period, unchanged from 0000936395-19-000021:notes:175]

[0000936395-19-000040:notes:181]
[same as prior period, unchanged from 0000936395-19-000021:notes:176]

[0000936395-19-000040:notes:182]
[same as prior period, unchanged from 0000936395-19-000021:notes:177]

[0000936395-19-000040:notes:183]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 230,610 |  |  | $ | 181,603 |  |  | $ | 542,391 |  |  | $ | 396,995 |  |
| Software and Software-Related Services | 6,029 |  |  | 9,305 |  |  | 30,982 |  |  | 41,216 |  |
| Global Services | 47,833 |  |  | 39,502 |  |  | 142,515 |  |  | 121,823 |  |
| Total segment profit | 284,472 |  |  | 230,410 |  |  | 715,888 |  |  | 560,034 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 104,230 |  |  | 95,395 |  |  | 305,845 |  |  | 281,269 |  |
| General and administrative | 42,695 |  |  | 38,212 |  |  | 124,092 |  |  | 115,594 |  |
| Amortization of intangible assets | 5,529 |  |  | 3,837 |  |  | 16,586 |  |  | 11,083 |  |
| Significant asset impairments and restructuring costs | 5,355 |  |  | 6,359 |  |  | 11,696 |  |  | 16,679 |  |
| Acquisition and integration costs | 1,362 |  |  | 1,333 |  |  | 4,105 |  |  | 1,333 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (8,354 | ) |  | (15,154 | ) |  | (23,257 | ) |  | (39,048 | ) |
| Less: Provision for income taxes | 30,198 |  |  | 19,280 |  |  | 57,204 |  |  | 503,695 |  |
| Consolidated net income (loss) | $ | 86,749 |  |  | $ | 50,840 |  |  | $ | 173,103 |  |  | $ | (408,667 | ) |

[0000936395-19-000040:notes:184]
[same as prior period, unchanged from 0000936395-19-000021:notes:179]

[0000936395-19-000040:notes:185]
Ciena’s revenue includes $592.2 million and $469.2 million of United States revenue for the third quarter of fiscal 2019 and 2018, respectively. Ciena’s revenue also includes $83.6 million of India revenue for the third quarter of fiscal 2018. For the nine months ended July 31, 2019 and 2018, United States revenue was $1.60 billion and $1.25 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-19-000040:notes:186]
[same as prior period, unchanged from 0000936395-19-000021:notes:181]

[0000936395-19-000040:notes:187]
|  | July 31, 2019 |  | October 31, 2018 |
| Canada | $ | 201,126 |  |  | $ | 198,028 |  |
| United States | 62,231 |  |  | 75,479 |  |
| Other International | 17,273 |  |  | 18,560 |  |
| Total | $ | 280,630 |  |  | $ | 292,067 |  |

[0000936395-19-000040:notes:188]
For the periods below, as applicable, AT&T, Verizon and a Web-scale provider were the only customers that accounted for at least 10% of Ciena’s revenue as follows (in thousands):

[0000936395-19-000040:notes:189]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| AT&T | n/a |  |  | $ | 87,389 |  |  | $ | 297,049 |  |  | $ | 263,453 |  |
| Verizon | 118,875 |  |  | 97,103 |  |  | 314,000 |  |  | 221,475 |  |
| Web-scale provider | 123,253 |  |  | 86,364 |  |  | 298,106 |  |  | n/a |  |
| Total | $ | 242,128 |  |  | $ | 270,856 |  |  | $ | 909,155 |  |  | $ | 484,928 |  |

[0000936395-19-000040:notes:190]
[same as prior period, unchanged from 0000936395-19-000021:notes:185]

[0000936395-19-000040:notes:191]
[same as prior period, unchanged from 0000936395-19-000021:notes:186]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-19-000040:notes:192]
COMMITMENTS AND CONTINGENCIES

[0000936395-19-000040:notes:193]
Canadian Grant

[0000936395-19-000040:notes:194]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.6 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2019, Ciena has recorded CAD$25.9 million (approximately $19.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$9.3 million (approximately $7.0 million) was recorded in the first nine months of fiscal 2019. As of July 31, 2019, amounts receivable from this grant were CAD$10.8 million (approximately $8.2 million).

[0000936395-19-000040:notes:195]
Tax Contingencies

[0000936395-19-000040:notes:196]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-19-000040:notes:197]
Litigation

[0000936395-19-000040:notes:198]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleged violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and sought unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement was subject to notice to class members and approval by the court. On August 8, 2019, the court approved the settlement and entered judgment in the case. The terms of the settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to Ciena’s financial results.

[0000936395-19-000040:notes:199]
Internal Investigation

[0000936395-19-000040:notes:200]
As first disclosed in Ciena’s Form 10-K for fiscal 2017, during that year one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act. In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (the “DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it declined to prosecute this matter and that its investigation into this matter is closed. On September 9, 2019, the SEC advised that it has concluded its investigation into this matter and that its staff does not intend to recommend any enforcement action by the SEC against Ciena.

[0000936395-19-000040:notes:201]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-19-000040:notes:202]
SUBSEQUENT EVENTS

[0000936395-19-000040:notes:203]
From the end of the third quarter of fiscal 2019 through September 6, 2019, Ciena repurchased an additional 417,819 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $41.38 per share, inclusive of repurchases pending settlement. As of September 6, 2019, Ciena has repurchased an aggregate of 3,299,383 shares and has an aggregate of $370.8 million of authorized funds remaining under its Stock Repurchase Program.
