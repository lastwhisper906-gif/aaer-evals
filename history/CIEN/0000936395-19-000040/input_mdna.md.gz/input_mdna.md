# CIEN MD&A — 0000936395-19-000040


## mdna

[0000936395-19-000040:mdna:1]
[same as prior period, unchanged from 0000936395-19-000021:mdna:1]

[0000936395-19-000040:mdna:2]
[same as prior period, unchanged from 0000936395-19-000021:mdna:2]

[0000936395-19-000040:mdna:3]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things: our competitive landscape; market conditions and growth opportunities; factors impacting our industry and markets; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and automation of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including information technology (IT) transitions or initiatives; the impact of the Tax Cuts and Jobs Act and changes in our effective tax rates; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-19-000040:mdna:4]
[same as prior period, unchanged from 0000936395-19-000021:mdna:4]

[0000936395-19-000040:mdna:5]
[same as prior period, unchanged from 0000936395-19-000021:mdna:5]

[0000936395-19-000040:mdna:6]
[same as prior period, unchanged from 0000936395-19-000021:mdna:6]

[0000936395-19-000040:mdna:7]
[same as prior period, unchanged from 0000936395-19-000021:mdna:7]

[0000936395-19-000040:mdna:8]
[same as prior period, unchanged from 0000936395-19-000021:mdna:8]

[0000936395-19-000040:mdna:9]
[same as prior period, unchanged from 0000936395-19-000021:mdna:9]

[0000936395-19-000040:mdna:10]
[same as prior period, unchanged from 0000936395-19-000021:mdna:10]

[0000936395-19-000040:mdna:11]
[same as prior period, unchanged from 0000936395-19-000021:mdna:11]

[0000936395-19-000040:mdna:12]
[same as prior period, unchanged from 0000936395-19-000021:mdna:12]

[0000936395-19-000040:mdna:13]
[same as prior period, unchanged from 0000936395-19-000021:mdna:13]

[0000936395-19-000040:mdna:14]
[same as prior period, unchanged from 0000936395-19-000021:mdna:14]

[0000936395-19-000040:mdna:15]
[same as prior period, unchanged from 0000936395-19-000021:mdna:15]

[0000936395-19-000040:mdna:16]
[same as prior period, unchanged from 0000936395-19-000021:mdna:16]

[0000936395-19-000040:mdna:17]
[same as prior period, unchanged from 0000936395-19-000021:mdna:17]

[0000936395-19-000040:mdna:18]
[same as prior period, unchanged from 0000936395-19-000021:mdna:18]

[0000936395-19-000040:mdna:19]
[same as prior period, unchanged from 0000936395-19-000021:mdna:19]

[0000936395-19-000040:mdna:20]
[same as prior period, unchanged from 0000936395-19-000021:mdna:20]

[0000936395-19-000040:mdna:21]
[same as prior period, unchanged from 0000936395-19-000021:mdna:21]

[0000936395-19-000040:mdna:22]
[same as prior period, unchanged from 0000936395-19-000021:mdna:22]

[0000936395-19-000040:mdna:23]
[same as prior period, unchanged from 0000936395-19-000021:mdna:23]

[0000936395-19-000040:mdna:24]
| • | our ability to grow and to maintain our new distribution relationships under which we will make available certain technology as a component; |

[0000936395-19-000040:mdna:25]
[same as prior period, unchanged from 0000936395-19-000021:mdna:25]

[0000936395-19-000040:mdna:26]
[same as prior period, unchanged from 0000936395-19-000021:mdna:26]

[0000936395-19-000040:mdna:27]
[same as prior period, unchanged from 0000936395-19-000021:mdna:27]

[0000936395-19-000040:mdna:28]
[same as prior period, unchanged from 0000936395-19-000021:mdna:28]

[0000936395-19-000040:mdna:29]
[same as prior period, unchanged from 0000936395-19-000021:mdna:29]

[0000936395-19-000040:mdna:30]
[same as prior period, unchanged from 0000936395-19-000021:mdna:30]

[0000936395-19-000040:mdna:31]
[same as prior period, unchanged from 0000936395-19-000021:mdna:31]

[0000936395-19-000040:mdna:32]
| • | our ability to commercialize and to grow our software business and address networking strategies including software-defined networking and network function virtualization; |

[0000936395-19-000040:mdna:33]
[same as prior period, unchanged from 0000936395-19-000021:mdna:33]

[0000936395-19-000040:mdna:34]
[same as prior period, unchanged from 0000936395-19-000021:mdna:34]

[0000936395-19-000040:mdna:35]
[same as prior period, unchanged from 0000936395-19-000021:mdna:35]

[0000936395-19-000040:mdna:36]
[same as prior period, unchanged from 0000936395-19-000021:mdna:36]

[0000936395-19-000040:mdna:37]
[same as prior period, unchanged from 0000936395-19-000021:mdna:37]

[0000936395-19-000040:mdna:38]
| • | adverse results in litigation matters. |

[0000936395-19-000040:mdna:39]
[same as prior period, unchanged from 0000936395-19-000021:mdna:39]

[0000936395-19-000040:mdna:40]
[same as prior period, unchanged from 0000936395-19-000021:mdna:40]

[0000936395-19-000040:mdna:41]
[same as prior period, unchanged from 0000936395-19-000021:mdna:41]

[0000936395-19-000040:mdna:42]
[same as prior period, unchanged from 0000936395-19-000021:mdna:42]

[0000936395-19-000040:mdna:43]
autonomous network infrastructure. To complement our hardware and software solutions, we offer a broad range of attached and software-related services that help our customers to design, optimize, integrate, deploy, manage and maintain their networks and associated operational environments. Through our complete portfolio of solutions, we enable our customers to transform their networks into dynamic, programmable environments driven by automation and analytics, which we refer to as the Adaptive Network. Our solutions for the Adaptive Network create business and operational value for our customers, enabling them to introduce new revenue-generating services, reduce costs and maximize the return on their network infrastructure investment.

[0000936395-19-000040:mdna:44]
Revenue and earnings growth, technology innovation and business diversification.

[0000936395-19-000040:mdna:45]
During the first nine months of fiscal 2019, our revenue and earnings growth accelerated as we benefited meaningfully from strong network operator demand for capacity, favorable industry and competitive dynamics, and the continued execution of our strategy. Our strategy has focused on innovation leadership, the diversification of our business and customer base, and market share capture. For the nine months ended July 31, 2019, compared to the nine months ended July 31, 2018, our revenue grew from $2.19 billion to $2.60 billion, or approximately 19%, and our income from operations grew from $134.1 million to $253.6 million, or approximately 89%. Our results can fluctuate from quarter to quarter and, given the outstanding performance of our business during the first nine months of fiscal 2019, we do not expect that these revenue and profit growth rates will be sustainable long-term.

[0000936395-19-000040:mdna:46]
We believe that we continue to benefit from our efforts to push the pace of innovation in our markets and provide market-leading offerings. Keeping pace with the market’s demands for technology innovation requires considerable research and development investment capacity. For example, during the first nine months of fiscal 2019, we invested $406.5 million in research and development activities, an increase of approximately 14% compared to the first nine months of fiscal 2018. We believe that our investment capacity and innovation execution are important competitive differentiators that have contributed to the growth of our business. We believe that remaining competitive in the geographies, markets, and customer segments in which we sell depends upon our continued investment in innovation and our ability to offer solutions that address evolving consumption models for networking solutions.

[0000936395-19-000040:mdna:47]
We continue to diversify our business and have benefited from revenue contributions across a diverse set of geographies, product solutions and customer segments. During the nine months ended July 31, 2019, we grew revenue in our North America, Europe, Middle East and Africa (“EMEA”) and Caribbean and Latin America (“CALA”) geographic regions and across each of our operating segments, with a diverse set of hardware, software and service offerings. We grew revenue with our largest service provider customers and we have benefited from a strong market position with leading Web-scale providers. We believe continued diversification of our business can help us to compete in a dynamic industry environment, continue to grow our business, and better withstand potential slowdowns in particular geographies, markets, customers or customer segments. For example, sales to Web-scale provider customers have been an increasingly important contributor to our overall growth and certain of these customers were among our largest customers by revenue for the nine months ended July 31, 2019. However, we expect that our revenue growth from these customers will moderate from the significant level achieved to date in fiscal 2019. As another example, after recent years of strong growth, revenue from our Asia Pacific and India (“APAC”) region decreased for the nine months ended July 31, 2019, primarily due to lower spending levels and resulting sales declines with service providers in India. However, the decrease in India was partially offset within APAC by higher sales in Japan, and the decrease in APAC was more than offset by sales increases in other geographies and customer segments.

[0000936395-19-000040:mdna:48]
[same as prior period, unchanged from 0000936395-19-000021:mdna:49]

[0000936395-19-000040:mdna:49]
[same as prior period, unchanged from 0000936395-19-000021:mdna:50]

[0000936395-19-000040:mdna:50]
[same as prior period, unchanged from 0000936395-19-000021:mdna:51]

[0000936395-19-000040:mdna:51]
[same as prior period, unchanged from 0000936395-19-000021:mdna:52]

[0000936395-19-000040:mdna:52]
[same as prior period, unchanged from 0000936395-19-000021:mdna:53]

[0000936395-19-000040:mdna:53]
Quarter ended July 31, 2019 compared to the quarter ended July 31, 2018

[0000936395-19-000040:mdna:54]
[same as prior period, unchanged from 0000936395-19-000021:mdna:55]

[0000936395-19-000040:mdna:55]
[same as prior period, unchanged from 0000936395-19-000021:mdna:56]

[0000936395-19-000040:mdna:56]
During the third quarter of fiscal 2019, approximately 15.6% of our revenue was non-U.S. Dollar-denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, Indian Rupees, Argentina Pesos, British Pounds and Mexican Pesos. During the third quarter of fiscal 2019, as compared to the third quarter of fiscal 2018, the U.S. dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced slightly by approximately $8.2 million, or 1.0%, as compared to the third quarter of fiscal 2018. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000040:mdna:57]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | 75.4 |  | $ | 592,892 |  |  | 72.5 |  | $ | 131,353 |  |  | 22.2 |  |
| Packet Networking | 71,823 |  |  | 7.5 |  | 84,559 |  |  | 10.3 |  | (12,736 | ) |  | (15.1 | ) |
| Total Networking Platforms | 796,068 |  |  | 82.9 |  | 677,451 |  |  | 82.8 |  | 118,617 |  |  | 17.5 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 37,312 |  |  | 3.9 |  | 36,818 |  |  | 4.5 |  | 494 |  |  | 1.3 |  |
| Blue Planet Automation Software and Services | 10,530 |  |  | 1.1 |  | 4,365 |  |  | 0.5 |  | 6,165 |  |  | 141.2 |  |
| Total Software and Software-Related Services | 47,842 |  |  | 5.0 |  | 41,183 |  |  | 5.0 |  | 6,659 |  |  | 16.2 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 65,936 |  |  | 6.9 |  | 60,897 |  |  | 7.4 |  | 5,039 |  |  | 8.3 |  |
| Installation and Deployment | 39,802 |  |  | 4.1 |  | 31,262 |  |  | 3.8 |  | 8,540 |  |  | 27.3 |  |
| Consulting and Network Design | 10,958 |  |  | 1.1 |  | 8,024 |  |  | 1.0 |  | 2,934 |  |  | 36.6 |  |
| Total Global Services | 116,696 |  |  | 12.1 |  | 100,183 |  |  | 12.2 |  | 16,513 |  |  | 16.5 |  |
| Consolidated revenue | $ | 960,606 |  |  | 100.0 |  | $ | 818,817 |  |  | 100.0 |  | $ | 141,789 |  |  | 17.3 |  |

[0000936395-19-000040:mdna:58]
[same as prior period, unchanged from 0000936395-19-000021:mdna:59]

[0000936395-19-000040:mdna:59]
[same as prior period, unchanged from 0000936395-19-000021:mdna:60]

[0000936395-19-000040:mdna:60]
[same as prior period, unchanged from 0000936395-19-000021:mdna:61]

[0000936395-19-000040:mdna:61]
| • | Networking Platforms segment revenue increased, reflecting a product line sales increase of $131.4 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $12.7 million of our Packet Networking products. |

[0000936395-19-000040:mdna:62]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $84.6 million of our Waveserver stackable interconnect system and $59.9 million of our 6500 Packet-Optical Platform. These increases were partially |

[0000936395-19-000040:mdna:63]
offset by a sales decrease of $11.3 million of our 5410/5430 Reconfigurable Switching Systems. Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers, which represent a growing portion of our business as we continue to diversify. The sales increase from our 6500 Packet-Optical Platform is primarily due to increased sales to communications service providers and cable and multiservice operators.

[0000936395-19-000040:mdna:64]
| ◦ | Packet Networking sales primarily reflect sales decreases of $15.2 million of our packet networking platform independent software and $9.8 million of our 3000 and 5000 families of service delivery and aggregation switches. The sales decreases were partially offset by $12.1 million in sales of our 6500 Packet Transport System. |

[0000936395-19-000040:mdna:65]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting a sales increase of $6.2 million of our Blue Planet Automation Software and Services. The increase in our Blue Planet Automation Software and Services includes sales of $2.4 million and $4.1 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. |

[0000936395-19-000040:mdna:66]
| • | Global Services segment revenue increased, reflecting sales increases of $8.5 million of our installation and deployment services, $5.0 million of our maintenance support and training services and $2.9 million of our network transformation services. |

[0000936395-19-000040:mdna:67]
Our operating segments engage in business and operations across four geographic regions: North America; EMEA; CALA and APAC. Results for North America include only activities in the U.S. and Canada. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The increase in our EMEA region for the fiscal quarter ended July 31, 2019 was primarily driven by increased sales in the United Kingdom. The increase in our CALA region for the fiscal quarter ended July 31, 2019 was primarily driven by increased sales in Brazil and Mexico. The decrease in our APAC region for the fiscal quarter ended July 31, 2019 was primarily driven by decreased sales in India after a particularly strong 2018. This decrease was partially offset by increased sales in Japan and continued execution of our strategy to capture new market share with communications service providers in the region. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000040:mdna:68]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| North America | $ | 617,000 |  |  | 64.2 |  | $ | 497,004 |  |  | 60.7 |  | $ | 119,996 |  |  | 24.1 |  |
| EMEA | 169,532 |  |  | 17.6 |  | 122,204 |  |  | 14.9 |  | 47,328 |  |  | 38.7 |  |
| CALA | 39,261 |  |  | 4.1 |  | 27,493 |  |  | 3.4 |  | 11,768 |  |  | 42.8 |  |
| APAC | 134,813 |  |  | 14.1 |  | 172,116 |  |  | 21.0 |  | (37,303 | ) |  | (21.7 | ) |
| Total | $ | 960,606 |  |  | 100.0 |  | $ | 818,817 |  |  | 100.0 |  | $ | 141,789 |  |  | 17.3 |  |

[0000936395-19-000040:mdna:69]
[same as prior period, unchanged from 0000936395-19-000021:mdna:70]

[0000936395-19-000040:mdna:70]
[same as prior period, unchanged from 0000936395-19-000021:mdna:71]

[0000936395-19-000040:mdna:71]
[same as prior period, unchanged from 0000936395-19-000021:mdna:72]

[0000936395-19-000040:mdna:72]
| • | North America revenue primarily reflects increases of $108.3 million within our Networking Platforms segment and $8.8 million within our Global Services segment. The increase within our Networking Platforms segment reflects a product line sales increase of $114.1 million of Converged Packet Optical products, primarily related to sales increases of $59.6 million of our 6500 Packet-Optical Platform and $57.2 million of our Waveserver stackable interconnect system. Our 6500 Packet-Optical Platform sales primarily reflect increased sales to communications service providers. Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers. |

[0000936395-19-000040:mdna:73]
| • | EMEA revenue primarily reflects an increase of $43.8 million within our Networking Platforms segment. The increase within our Networking Platforms segment reflects a product line sales increase of $43.3 million of Converged Packet Optical products, primarily related to sales increases of $23.4 million of our Waveserver stackable interconnect system to Web-scale providers and $22.0 million of our 6500 Packet-Optical Platform to communications service providers, submarine network operators and enterprise customers. |

[0000936395-19-000040:mdna:74]
| • | CALA revenue primarily reflects increases of $7.0 million within our Networking Platforms segment and $4.4 million within our Global Services segment. Networking Platforms segment sales largely reflect increased sales of our 6500 Packet-Optical Platform to communications service providers. |

[0000936395-19-000040:mdna:75]
[same as prior period, unchanged from 0000936395-19-000021:mdna:76]

[0000936395-19-000040:mdna:76]
| • | APAC revenue primarily reflects a decrease of $40.6 million within our Networking Platforms segment partially offset by an increase of $3.8 million within our Software and Software-Related Services segment. Networking Platforms segment revenue primarily reflects product line decreases of $31.5 million in Converged Packet Optical sales and $9.1 million in Packet Networking sales. The decrease in Converged Packet Optical sales is primarily due to a decrease of $24.6 million in sales of our 6500 Packet-Optical Platform to communications service providers in India. |

[0000936395-19-000040:mdna:77]
[same as prior period, unchanged from 0000936395-19-000021:mdna:79]

[0000936395-19-000040:mdna:78]
[same as prior period, unchanged from 0000936395-19-000021:mdna:80]

[0000936395-19-000040:mdna:79]
[same as prior period, unchanged from 0000936395-19-000021:mdna:81]

[0000936395-19-000040:mdna:80]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending upon our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price compression that we regularly encounter in our markets due to competitive pressures. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. When we have success in taking share and winning new business, it can result in additional pressure on gross margin from these pricing dynamics, particularly during the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment sales and installation services, with our intent to improve margin as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. Gross margin and revenue can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that may carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-19-000040:mdna:81]
[same as prior period, unchanged from 0000936395-19-000021:mdna:83]

[0000936395-19-000040:mdna:82]
[same as prior period, unchanged from 0000936395-19-000021:mdna:84]

[0000936395-19-000040:mdna:83]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 960,606 |  |  | 100.0 |  | $ | 818,817 |  |  | 100.0 |  | $ | 141,789 |  |  | 17.3 |
| Total cost of goods sold | 536,254 |  |  | 55.8 |  | 467,274 |  |  | 57.1 |  | 68,980 |  |  | 14.8 |
| Gross profit | $ | 424,352 |  |  | 44.2 |  | $ | 351,543 |  |  | 42.9 |  | $ | 72,809 |  |  | 20.7 |

[0000936395-19-000040:mdna:84]
[same as prior period, unchanged from 0000936395-19-000021:mdna:86]

[0000936395-19-000040:mdna:85]
[same as prior period, unchanged from 0000936395-19-000021:mdna:87]

[0000936395-19-000040:mdna:86]
[same as prior period, unchanged from 0000936395-19-000021:mdna:88]

[0000936395-19-000040:mdna:87]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 810,588 |  |  | 100.0 |  | $ | 691,758 |  |  | 100.0 |  | $ | 118,830 |  |  | 17.2 |
| Product cost of goods sold | 454,921 |  |  | 56.1 |  | 399,886 |  |  | 57.8 |  | 55,035 |  |  | 13.8 |
| Product gross profit | $ | 355,667 |  |  | 43.9 |  | $ | 291,872 |  |  | 42.2 |  | $ | 63,795 |  |  | 21.9 |

[0000936395-19-000040:mdna:88]
[same as prior period, unchanged from 0000936395-19-000021:mdna:90]

[0000936395-19-000040:mdna:89]
[same as prior period, unchanged from 0000936395-19-000021:mdna:91]

[0000936395-19-000040:mdna:90]
[same as prior period, unchanged from 0000936395-19-000021:mdna:92]

[0000936395-19-000040:mdna:91]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 150,018 |  |  | 100.0 |  | $ | 127,059 |  |  | 100.0 |  | $ | 22,959 |  |  | 18.1 |
| Service cost of goods sold | 81,333 |  |  | 54.2 |  | 67,388 |  |  | 53.0 |  | 13,945 |  |  | 20.7 |
| Service gross profit | $ | 68,685 |  |  | 45.8 |  | $ | 59,671 |  |  | 47.0 |  | $ | 9,014 |  |  | 15.1 |

[0000936395-19-000040:mdna:92]
[same as prior period, unchanged from 0000936395-19-000021:mdna:94]

[0000936395-19-000040:mdna:93]
[same as prior period, unchanged from 0000936395-19-000021:mdna:95]

[0000936395-19-000040:mdna:94]
[same as prior period, unchanged from 0000936395-19-000021:mdna:96]

[0000936395-19-000040:mdna:95]
| • | Gross profit as a percentage of revenue reflects improved product gross profit as described below. In recent periods, we have encountered fluctuations or reductions in our gross margin as a result of our strategy to leverage our technology leadership and to capture aggressively additional market share and displace competitors, with the intent to improve margin in the long term as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. In the fiscal quarter ended July 31, 2019, our gross margin benefited from the success of this ongoing strategy and the resulting favorable mix of customers, network deployments and capacity additions during the period. Continued implementation of this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, or result in an unfavorable mix of revenues from early stage deployments during a particular period, which can adversely impact gross margin. |

[0000936395-19-000040:mdna:96]
[same as prior period, unchanged from 0000936395-19-000021:mdna:98]

[0000936395-19-000040:mdna:97]
[same as prior period, unchanged from 0000936395-19-000021:mdna:168]

[0000936395-19-000040:mdna:98]
[same as prior period, unchanged from 0000936395-19-000021:mdna:100]

[0000936395-19-000040:mdna:99]
[same as prior period, unchanged from 0000936395-19-000021:mdna:101]

[0000936395-19-000040:mdna:100]
[same as prior period, unchanged from 0000936395-19-000021:mdna:102]

[0000936395-19-000040:mdna:101]
[same as prior period, unchanged from 0000936395-19-000021:mdna:103]

[0000936395-19-000040:mdna:102]
| • | General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services. |

[0000936395-19-000040:mdna:103]
[same as prior period, unchanged from 0000936395-19-000021:mdna:105]

[0000936395-19-000040:mdna:104]
| • | Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions and significant impairments of assets. |

[0000936395-19-000040:mdna:105]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of Packet Design and DonRiver, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition. |

[0000936395-19-000040:mdna:106]
During the third quarter of fiscal 2019, approximately 50.4% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees and Euros. During the third quarter of fiscal 2019 as compared to the third quarter of fiscal 2018, the U.S. Dollar generally strengthened against these currencies. Consequently, our operating expense reported in U.S. Dollars was reduced slightly by approximately $2.6 million, or 1.0%, as compared to the third quarter of fiscal 2018, due to the strengthening U.S. Dollar, net of hedging. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000040:mdna:107]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 139,880 |  |  | 14.6 |  | $ | 121,133 |  |  | 14.8 |  | $ | 18,747 |  |  | 15.5 |  |
| Selling and marketing | 104,230 |  |  | 10.9 |  | 95,395 |  |  | 11.7 |  | 8,835 |  |  | 9.3 |  |
| General and administrative | 42,695 |  |  | 4.4 |  | 38,212 |  |  | 4.7 |  | 4,483 |  |  | 11.7 |  |
| Amortization of intangible assets | 5,529 |  |  | 0.6 |  | 3,837 |  |  | 0.5 |  | 1,692 |  |  | 44.1 |  |
| Significant asset impairments and restructuring costs | 5,355 |  |  | 0.6 |  | 6,359 |  |  | 0.8 |  | (1,004 | ) |  | (15.8 | ) |
| Acquisition and integration costs | 1,362 |  |  | 0.1 |  | 1,333 |  |  | 0.2 |  | 29 |  |  | 2.2 |  |
| Total operating expenses | $ | 299,051 |  |  | 31.2 |  | $ | 266,269 |  |  | 32.7 |  | $ | 32,782 |  |  | 12.3 |  |

[0000936395-19-000040:mdna:108]
[same as prior period, unchanged from 0000936395-19-000021:mdna:110]

[0000936395-19-000040:mdna:109]
[same as prior period, unchanged from 0000936395-19-000021:mdna:111]

[0000936395-19-000040:mdna:110]
[same as prior period, unchanged from 0000936395-19-000021:mdna:112]

[0000936395-19-000040:mdna:111]
| • | Research and development expense benefited from $0.9 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $18.7 million. This increase primarily reflects increases of $13.5 million in employee and compensation costs, $3.3 million for facility and information technology costs and $3.1 million in professional services. |

[0000936395-19-000040:mdna:112]
| • | Selling and marketing expense benefited from $1.4 million as a result of foreign exchange rates primarily due to a stronger U.S. Dollar in relation to the Euro, Australian Dollar and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $8.8 million, primarily reflecting an increase in employee and compensation costs. |

[0000936395-19-000040:mdna:113]
| • | General and administrative expense increased by $4.5 million, primarily reflecting an increase in employee and compensation costs. |

[0000936395-19-000040:mdna:114]
[same as prior period, unchanged from 0000936395-19-000021:mdna:116]

[0000936395-19-000040:mdna:115]
[same as prior period, unchanged from 0000936395-19-000021:mdna:117]

[0000936395-19-000040:mdna:116]
[same as prior period, unchanged from 0000936395-19-000021:mdna:119]

[0000936395-19-000040:mdna:117]
[same as prior period, unchanged from 0000936395-19-000021:mdna:120]

[0000936395-19-000040:mdna:118]
[same as prior period, unchanged from 0000936395-19-000021:mdna:121]

[0000936395-19-000040:mdna:119]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 1,050 |  |  | 0.1 |  | $ | (1,543 | ) |  | (0.2 | ) |  | $ | 2,593 |  |  | (168.0 | ) |
| Interest expense | $ | 9,404 |  |  | 1.0 |  | $ | 13,611 |  |  | 1.7 |  |  | $ | (4,207 | ) |  | (30.9 | ) |
| Provision for income taxes | $ | 30,198 |  |  | 3.1 |  | $ | 19,280 |  |  | 2.4 |  |  | $ | 10,918 |  |  | 56.6 |  |

[0000936395-19-000040:mdna:120]
[same as prior period, unchanged from 0000936395-19-000021:mdna:123]

[0000936395-19-000040:mdna:121]
[same as prior period, unchanged from 0000936395-19-000021:mdna:124]

[0000936395-19-000040:mdna:122]
[same as prior period, unchanged from 0000936395-19-000021:mdna:125]

[0000936395-19-000040:mdna:123]
[same as prior period, unchanged from 0000936395-19-000021:mdna:126]

[0000936395-19-000040:mdna:124]
[same as prior period, unchanged from 0000936395-19-000021:mdna:127]

[0000936395-19-000040:mdna:125]
| • | Provision for income taxes increased, due to higher earnings for the third quarter of fiscal 2019. The effective tax rate for the third quarter of 2019 was lower compared to the third quarter of fiscal 2018, primarily due to a lower statutory federal income tax rate in 2019. |

[0000936395-19-000040:mdna:126]
Nine months ended July 31, 2019 compared to the nine months ended July 31, 2018

[0000936395-19-000040:mdna:127]
[same as prior period, unchanged from 0000936395-19-000021:mdna:130]

[0000936395-19-000040:mdna:128]
During the first nine months of fiscal 2019, approximately 17.4% of our revenue was non-U.S. Dollar-denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, Indian Rupees, Argentina Pesos, British Pounds and Mexican Pesos. During the first nine months of fiscal 2019, as compared to the first nine months of fiscal 2018, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced by approximately $37.4 million or 1.4%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000040:mdna:129]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | 72.8 |  | $ | 1,548,189 |  |  | 70.5 |  | $ | 348,891 |  |  | 22.5 |  |
| Packet Networking | 216,529 |  |  | 8.3 |  | 216,977 |  |  | 9.9 |  | (448 | ) |  | (0.2 | ) |
| Total Networking Platforms | 2,113,609 |  |  | 81.1 |  | 1,765,166 |  |  | 80.4 |  | 348,443 |  |  | 19.7 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 114,139 |  |  | 4.4 |  | 117,347 |  |  | 5.3 |  | (3,208 | ) |  | (2.7 | ) |
| Blue Planet Automation Software and Services | 37,977 |  |  | 1.5 |  | 16,068 |  |  | 0.7 |  | 21,909 |  |  | 136.4 |  |
| Total Software and Software-Related Services | 152,116 |  |  | 5.9 |  | 133,415 |  |  | 6.0 |  | 18,701 |  |  | 14.0 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 196,002 |  |  | 7.5 |  | 177,759 |  |  | 8.1 |  | 18,243 |  |  | 10.3 |  |
| Installation and Deployment | 111,746 |  |  | 4.3 |  | 89,487 |  |  | 4.1 |  | 22,259 |  |  | 24.9 |  |
| Consulting and Network Design | 30,671 |  |  | 1.2 |  | 29,103 |  |  | 1.4 |  | 1,568 |  |  | 5.4 |  |
| Total Global Services | 338,419 |  |  | 13.0 |  | 296,349 |  |  | 13.6 |  | 42,070 |  |  | 14.2 |  |
| Consolidated revenue | $ | 2,604,144 |  |  | 100.0 |  | $ | 2,194,930 |  |  | 100.0 |  | $ | 409,214 |  |  | 18.6 |  |

[0000936395-19-000040:mdna:130]
[same as prior period, unchanged from 0000936395-19-000021:mdna:133]

[0000936395-19-000040:mdna:131]
[same as prior period, unchanged from 0000936395-19-000021:mdna:134]

[0000936395-19-000040:mdna:132]
[same as prior period, unchanged from 0000936395-19-000021:mdna:135]

[0000936395-19-000040:mdna:133]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $348.9 million of our Converged Packet Optical products. |

[0000936395-19-000040:mdna:134]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $216.3 million of our 6500 Packet-Optical Platform and $192.7 million of our Waveserver stackable interconnect system. These increases were partially offset by a sales decrease of $50.9 million of our 5410/5430 Reconfigurable Switching Systems. The sales |

[0000936395-19-000040:mdna:135]
39

[0000936395-19-000040:mdna:136]
increase of our 6500 Packet-Optical Platform is primarily due to increased sales to communications service providers, including AT&T, submarine network operators and cable and multiservice operators. Waveserver stackable interconnect system sales primarily reflect increased sales to Web-scale providers, which represent a growing portion of our business as we continue to diversify.

[0000936395-19-000040:mdna:137]
| ◦ | Packet Networking sales primarily reflect $47.0 million in initial sales of our 6500 Packet Transport System to communications service providers which was slightly more than offset by sales decreases of $27.7 million of our 3000 and 5000 families of service delivery and aggregation switches and $15.1 million of our packet networking platform independent software. |

[0000936395-19-000040:mdna:138]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting a sales increase of $21.9 million of our Blue Planet Automation Software and Services, partially offset by a sales decrease of $3.2 million of our Platform Software and Services. The increase in our Blue Planet Automation Software and Services includes sales of $9.3 million and $11.0 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. |

[0000936395-19-000040:mdna:139]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $22.3 million of our deployment and installation services and $18.2 million of our maintenance support and training services and $1.6 million of our network transformation services. |

[0000936395-19-000040:mdna:140]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The increase in our EMEA region for the nine months ended July 31, 2019 was primarily driven by increased sales in the Netherlands, the United Kingdom and Germany. The increase in our CALA region for the nine months ended July 31, 2019 was primarily driven by increased sales in Brazil, Mexico and Chile. The decrease in our APAC region for the nine months ended July 31, 2019 was primarily driven by decreased sales in India and Australia, partially offset by increased sales in Japan. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000040:mdna:141]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,678,599 |  |  | 64.5 |  | $ | 1,331,148 |  |  | 60.6 |  | $ | 347,451 |  |  | 26.1 |  |
| EMEA | 413,715 |  |  | 15.9 |  | 341,785 |  |  | 15.6 |  | 71,930 |  |  | 21.0 |  |
| CALA | 109,635 |  |  | 4.2 |  | 87,136 |  |  | 4.0 |  | 22,499 |  |  | 25.8 |  |
| APAC | 402,195 |  |  | 15.4 |  | 434,861 |  |  | 19.8 |  | (32,666 | ) |  | (7.5 | ) |
| Total | $ | 2,604,144 |  |  | 100.0 |  | $ | 2,194,930 |  |  | 100.0 |  | $ | 409,214 |  |  | 18.6 |  |

[0000936395-19-000040:mdna:142]
[same as prior period, unchanged from 0000936395-19-000021:mdna:145]

[0000936395-19-000040:mdna:143]
[same as prior period, unchanged from 0000936395-19-000021:mdna:146]

[0000936395-19-000040:mdna:144]
[same as prior period, unchanged from 0000936395-19-000021:mdna:147]

[0000936395-19-000040:mdna:145]
| • | North America revenue primarily reflects increases of $325.6 million within our Networking Platforms segment and $20.4 million within our Global Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $291.7 million of Converged Packet Optical products and $33.9 million of Packet Networking products. Converged Packet Optical sales primarily reflect sales increases of $168.8 million of our 6500 Packet-Optical Platform and $132.6 million of our Waveserver stackable interconnect system. 6500 Packet-Optical Platform sales primarily reflect increased sales to communications service providers, including AT&T, and enterprise customers. Waveserver stackable interconnect system sales primarily reflect increased sales to Web-scale providers. |

[0000936395-19-000040:mdna:146]
| • | EMEA revenue primarily reflects increases of $58.0 million within our Networking Platforms segment, $10.2 million within our Global Services segment and $3.8 million within our Software and Software-Related Services segment. The increase within our Networking Platforms segment primarily reflects a product line sales increase of $55.3 million of Converged Packet Optical products. Converged Packet Optical sales primarily reflects sales increases of $46.5 million of our Waveserver stackable interconnect system to Web-scale providers and $18.1 million of our 6500 Packet-Optical Platform primarily reflecting increased sales to enterprise customers, communications services providers and Web-scale customers. |

[0000936395-19-000040:mdna:147]
| • | CALA revenue primarily reflects increases of $16.4 million within our Networking Platforms segment, $3.9 million within our Global Services segment and $2.2 million within our Software and Software-Related Services segment. |

[0000936395-19-000040:mdna:148]
| • | APAC revenue primarily reflects a decrease of $51.6 million within our Networking Platforms segment, partially offset by increases of $11.3 million within our Software and Software-Related Services and $7.7 million within our Global Services segment. The decrease within our Networking Platforms segment primarily reflects product line decreases of $36.9 million of Packet Networking products and $14.7 million of Converged Packet Optical products. Packet Networking sales primarily reflects sales decreases of $27.5 million of our 3000 and 5000 families of service delivery and aggregation switches and $8.2 million of our 8700 Packetwave Platform to a certain communications service provider in India. Converged Packet Optical sales primarily reflect a sales decrease of $39.3 million of our 5410/5430 Reconfigurable Switching Systems to communications service providers. This decrease was partially offset by sales increases of $17.0 million of our 6500 Packet-Optical Platform primarily to communications service providers and $8.4 million of our Waveserver stackable interconnect system to Web-scale customers. |

[0000936395-19-000040:mdna:149]
[same as prior period, unchanged from 0000936395-19-000021:mdna:152]

[0000936395-19-000040:mdna:150]
[same as prior period, unchanged from 0000936395-19-000021:mdna:153]

[0000936395-19-000040:mdna:151]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 2,604,144 |  |  | 100.0 |  | $ | 2,194,930 |  |  | 100.0 |  | $ | 409,214 |  |  | 18.6 |
| Total cost of goods sold | 1,481,774 |  |  | 56.9 |  | 1,278,315 |  |  | 58.2 |  | 203,459 |  |  | 15.9 |
| Gross profit | $ | 1,122,370 |  |  | 43.1 |  | $ | 916,615 |  |  | 41.8 |  | $ | 205,755 |  |  | 22.4 |

[0000936395-19-000040:mdna:152]
[same as prior period, unchanged from 0000936395-19-000021:mdna:155]

[0000936395-19-000040:mdna:153]
[same as prior period, unchanged from 0000936395-19-000021:mdna:156]

[0000936395-19-000040:mdna:154]
[same as prior period, unchanged from 0000936395-19-000021:mdna:157]

[0000936395-19-000040:mdna:155]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 2,163,808 |  |  | 100.0 |  | $ | 1,821,593 |  |  | 100.0 |  | $ | 342,215 |  |  | 18.8 |
| Product cost of goods sold | 1,246,413 |  |  | 57.6 |  | 1,085,574 |  |  | 59.6 |  | 160,839 |  |  | 14.8 |
| Product gross profit | $ | 917,395 |  |  | 42.4 |  | $ | 736,019 |  |  | 40.4 |  | $ | 181,376 |  |  | 24.6 |

[0000936395-19-000040:mdna:156]
[same as prior period, unchanged from 0000936395-19-000021:mdna:159]

[0000936395-19-000040:mdna:157]
[same as prior period, unchanged from 0000936395-19-000021:mdna:160]

[0000936395-19-000040:mdna:158]
[same as prior period, unchanged from 0000936395-19-000021:mdna:161]

[0000936395-19-000040:mdna:159]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 440,336 |  |  | 100.0 |  | $ | 373,337 |  |  | 100.0 |  | $ | 66,999 |  |  | 17.9 |
| Service cost of goods sold | 235,361 |  |  | 53.5 |  | 192,741 |  |  | 51.6 |  | 42,620 |  |  | 22.1 |
| Service gross profit | $ | 204,975 |  |  | 46.5 |  | $ | 180,596 |  |  | 48.4 |  | $ | 24,379 |  |  | 13.5 |

[0000936395-19-000040:mdna:160]
[same as prior period, unchanged from 0000936395-19-000021:mdna:163]

[0000936395-19-000040:mdna:161]
[same as prior period, unchanged from 0000936395-19-000021:mdna:164]

[0000936395-19-000040:mdna:162]
[same as prior period, unchanged from 0000936395-19-000021:mdna:165]

[0000936395-19-000040:mdna:163]
[same as prior period, unchanged from 0000936395-19-000021:mdna:166]

[0000936395-19-000040:mdna:164]
[same as prior period, unchanged from 0000936395-19-000021:mdna:167]

[0000936395-19-000040:mdna:165]
| • | Gross profit on services as a percentage of services revenue decreased, primarily as a result of lower margins on our Blue Planet Automation software services and the impact of early stages of international network deployments. |

[0000936395-19-000040:mdna:166]
[same as prior period, unchanged from 0000936395-19-000021:mdna:169]

[0000936395-19-000040:mdna:167]
During the first nine months of fiscal 2019, approximately 51.0% of our operating expense was non-U.S. Dollar-denominated, including Canadian Dollars, British Pounds, Indian Rupees and Euros. Consequently, our operating expense reported in U.S. Dollars was reduced by approximately $15.9 million, or 1.8%, during the first nine months of fiscal 2019 as compared to the first nine months of fiscal 2018, due to the strengthening U.S. Dollar, net of hedging. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000040:mdna:168]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 406,482 |  |  | 15.6 |  | $ | 356,581 |  |  | 16.2 |  | $ | 49,901 |  |  | 14.0 |  |
| Selling and marketing | 305,845 |  |  | 11.7 |  | 281,269 |  |  | 12.8 |  | 24,576 |  |  | 8.7 |  |
| General and administrative | 124,092 |  |  | 4.8 |  | 115,594 |  |  | 5.3 |  | 8,498 |  |  | 7.4 |  |
| Amortization of intangible assets | 16,586 |  |  | 0.6 |  | 11,083 |  |  | 0.5 |  | 5,503 |  |  | 49.7 |  |
| Significant asset impairments and restructuring costs | 11,696 |  |  | 0.4 |  | 16,679 |  |  | 0.8 |  | (4,983 | ) |  | (29.9 | ) |
| Acquisition and integration costs | 4,105 |  |  | 0.2 |  | 1,333 |  |  | 0.1 |  | 2,772 |  |  | 208.0 |  |
| Total operating expenses | $ | 868,806 |  |  | 33.3 |  | $ | 782,539 |  |  | 35.7 |  | $ | 86,267 |  |  | 11.0 |  |

[0000936395-19-000040:mdna:169]
[same as prior period, unchanged from 0000936395-19-000021:mdna:172]

[0000936395-19-000040:mdna:170]
[same as prior period, unchanged from 0000936395-19-000021:mdna:173]

[0000936395-19-000040:mdna:171]
[same as prior period, unchanged from 0000936395-19-000021:mdna:174]

[0000936395-19-000040:mdna:172]
| • | Research and development expense benefited from $8.0 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $49.9 million. This increase primarily reflects increases of $21.6 million in employee and compensation costs, $14.1 million in professional services, $4.9 million in facility and information technology costs, $4.6 million in prototype expense and $1.0 million in technology and related costs. This increase also reflects a reduced benefit of $3.5 million for the ENCQOR grant reimbursement. For more information on the ENCQOR grant, see Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-19-000040:mdna:173]
| • | Selling and marketing expense benefited from $6.3 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $24.6 million, primarily reflecting increases of $21.6 million in employee and compensation costs and $3.3 million in facilities and information technology costs. |

[0000936395-19-000040:mdna:174]
| • | General and administrative expense benefited from $1.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro, Brazilian Real, Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, general and administrative expenses increased by $8.5 million, primarily reflecting an increase of $8.0 million in employee and compensation costs. |

[0000936395-19-000040:mdna:175]
[same as prior period, unchanged from 0000936395-19-000021:mdna:179]

[0000936395-19-000040:mdna:176]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes and unfavorable lease commitments for a few of our facility locations in the United States and India where we have vacated unused space. |

[0000936395-19-000040:mdna:177]
[same as prior period, unchanged from 0000936395-19-000021:mdna:181]

[0000936395-19-000040:mdna:178]
[same as prior period, unchanged from 0000936395-19-000021:mdna:182]

[0000936395-19-000040:mdna:179]
[same as prior period, unchanged from 0000936395-19-000021:mdna:183]

[0000936395-19-000040:mdna:180]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 5,059 |  |  | 0.2 |  | $ | 1,328 |  |  | 0.1 |  | $ | 3,731 |  |  | 280.9 |  |
| Interest expense | $ | 28,316 |  |  | 1.1 |  | $ | 40,376 |  |  | 1.8 |  | $ | (12,060 | ) |  | (29.9 | ) |
| Provision for income taxes | $ | 57,204 |  |  | 2.2 |  | $ | 503,695 |  |  | 22.9 |  | $ | (446,491 | ) |  | (88.6 | ) |

[0000936395-19-000040:mdna:181]
[same as prior period, unchanged from 0000936395-19-000021:mdna:185]

[0000936395-19-000040:mdna:182]
[same as prior period, unchanged from 0000936395-19-000021:mdna:186]

[0000936395-19-000040:mdna:183]
[same as prior period, unchanged from 0000936395-19-000021:mdna:187]

[0000936395-19-000040:mdna:184]
| • | Interest and other income (loss), net primarily reflects a $2.0 million gain related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity and a $1.6 million gain in interest income due to higher interest rates on our investments during fiscal 2019. |

[0000936395-19-000040:mdna:185]
[same as prior period, unchanged from 0000936395-19-000021:mdna:189]

[0000936395-19-000040:mdna:186]
| • | Provision for income taxes decreased as the first nine months of fiscal 2018 reflects the impact of the Tax Act, including $431.3 million in expense for the remeasurement of our net deferred tax assets and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. |

[0000936395-19-000040:mdna:187]
[same as prior period, unchanged from 0000936395-19-000021:mdna:191]

[0000936395-19-000040:mdna:188]
[same as prior period, unchanged from 0000936395-19-000021:mdna:192]

[0000936395-19-000040:mdna:189]
|  | Quarter Ended July 31, |  |  |  |
|  | 2019 |  | 2018 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 230,610 |  |  | $ | 181,603 |  |  | $ | 49,007 |  |  | 27.0 |  |
| Software and Software-Related Services | $ | 6,029 |  |  | $ | 9,305 |  |  | $ | (3,276 | ) |  | (35.2 | ) |
| Global Services | $ | 47,833 |  |  | $ | 39,502 |  |  | $ | 8,331 |  |  | 21.1 |  |

[0000936395-19-000040:mdna:190]
[same as prior period, unchanged from 0000936395-19-000021:mdna:194]

[0000936395-19-000040:mdna:191]
[same as prior period, unchanged from 0000936395-19-000021:mdna:195]

[0000936395-19-000040:mdna:192]
[same as prior period, unchanged from 0000936395-19-000021:mdna:196]

[0000936395-19-000040:mdna:193]
[same as prior period, unchanged from 0000936395-19-000021:mdna:197]

[0000936395-19-000040:mdna:194]
[same as prior period, unchanged from 0000936395-19-000021:mdna:198]

[0000936395-19-000040:mdna:195]
|  | Nine Months Ended July 31, |  |  |  |
|  | 2019 |  | 2018 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 542,391 |  |  | $ | 396,995 |  |  | $ | 145,396 |  |  | 36.6 |  |
| Software and Software-Related Services | $ | 30,982 |  |  | $ | 41,216 |  |  | $ | (10,234 | ) |  | (24.8 | ) |
| Global Services | $ | 142,515 |  |  | $ | 121,823 |  |  | $ | 20,692 |  |  | 17.0 |  |

[0000936395-19-000040:mdna:196]
[same as prior period, unchanged from 0000936395-19-000021:mdna:200]

[0000936395-19-000040:mdna:197]
[same as prior period, unchanged from 0000936395-19-000021:mdna:201]

[0000936395-19-000040:mdna:198]
[same as prior period, unchanged from 0000936395-19-000021:mdna:202]

[0000936395-19-000040:mdna:199]
[same as prior period, unchanged from 0000936395-19-000021:mdna:203]

[0000936395-19-000040:mdna:200]
| • | Global Services segment profit increased, primarily due to higher sales volume as described above and improved gross margin. |

[0000936395-19-000040:mdna:201]
[same as prior period, unchanged from 0000936395-19-000021:mdna:205]

[0000936395-19-000040:mdna:202]
For the nine months ended July 31, 2019, we generated $173.1 million of cash from operating activities, as our net income (adjusted for non-cash charges) of $380.7 million exceeded our working capital requirements of $207.6 million. The increase in working capital was primarily driven by inventory increases of $115.4 million. For additional details on our cash provided by operating activities, see the discussion below entitled “Cash Provided By Operating Activities.”

[0000936395-19-000040:mdna:203]
Despite our cash generated from operations, cash, cash equivalents and investments decreased by $110.5 million during the first nine months of fiscal 2019. The decrease in cash primarily reflects (i) cash used for the payment of the debt conversion liability associated with our New Notes of $111.3 million on November 15, 2018, (ii) cash used to fund our investing activities for capital expenditures totaling $49.1 million, (iii) cash used for stock repurchase under our stock repurchase program of $110.5 million, (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $23.2 million and (v) cash used for payments on our term loan due September 28, 2025 (the “2025 Term Loan”) of $5.3 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $22.9 million in cash during the nine months ended July 31, 2019.

[0000936395-19-000040:mdna:204]
|  | July 31, 2019 |  | October 31, 2018 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 723,229 |  |  | $ | 745,423 |  |  | $ | (22,194 | ) |
| Short-term investments in marketable debt securities | 119,670 |  |  | 148,981 |  |  | (29,311 | ) |
| Long-term investments in marketable debt securities | — |  |  | 58,970 |  |  | (58,970 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 842,899 |  |  | $ | 953,374 |  |  | $ | (110,475 | ) |

[0000936395-19-000040:mdna:205]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of July 31, 2019 totaled $842.9 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 31, 2019, letters of credit totaling $75.0 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2019.

[0000936395-19-000040:mdna:206]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $73.3 million as of July 31, 2019.We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the

[0000936395-19-000040:mdna:207]
[same as prior period, unchanged from 0000936395-19-000021:mdna:211]

[0000936395-19-000040:mdna:208]
withholding taxes would be approximately $28.0 million.

[0000936395-19-000040:mdna:209]
[same as prior period, unchanged from 0000936395-19-000021:mdna:213]

[0000936395-19-000040:mdna:210]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and to reduce our debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-19-000040:mdna:211]
[same as prior period, unchanged from 0000936395-19-000021:mdna:215]

[0000936395-19-000040:mdna:212]
The following sections set forth the components of our $173.1 million of cash provided by operating activities during the first nine months of fiscal 2019:

[0000936395-19-000040:mdna:213]
[same as prior period, unchanged from 0000936395-19-000021:mdna:217]

[0000936395-19-000040:mdna:214]
[same as prior period, unchanged from 0000936395-19-000021:mdna:218]

[0000936395-19-000040:mdna:215]
|  | Nine months ended |
|  | July 31, 2019 |
| Net income | $ | 173,103 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 65,071 |  |
| Share-based compensation costs | 44,446 |  |
| Amortization of intangible assets | 26,610 |  |
| Deferred taxes | 35,949 |  |
| Provision for inventory excess and obsolescence | 18,833 |  |
| Provision for warranty | 15,933 |  |
| Other | 743 |  |
| Net income (adjusted for non-cash charges) | $ | 380,688 |  |

[0000936395-19-000040:mdna:216]
[same as prior period, unchanged from 0000936395-19-000021:mdna:220]

[0000936395-19-000040:mdna:217]
We used $207.6 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-19-000040:mdna:218]
|  | Nine months ended |
|  | July 31, 2019 |
| Cash used in accounts receivable | $ | (2,517 | ) |
| Cash used in inventories | (115,427 | ) |
| Cash used in prepaid expenses and other | (85,039 | ) |
| Cash used in accounts payable, accruals and other obligations | (9,005 | ) |
| Cash provided by deferred revenue | 4,427 |  |
| Total cash used for working capital | $ | (207,561 | ) |

[0000936395-19-000040:mdna:219]
[same as prior period, unchanged from 0000936395-19-000021:mdna:223]

[0000936395-19-000040:mdna:220]
| • | The $2.5 million of cash used by accounts receivable during the first nine months of fiscal 2019 reflects increased sales volume partially offset by increased cash collections; |

[0000936395-19-000040:mdna:221]
| • | The $115.4 million of cash used in inventory during the first nine months of fiscal 2019 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-19-000040:mdna:222]
| • | The $85.0 million of cash used in prepaid expense and other during the first nine months of fiscal 2019 primarily reflects increases in contract assets for unbilled accounts receivable due to changes in recognizing revenue for installation services and certain product sales and higher non-customer receivables; |

[0000936395-19-000040:mdna:223]
| • | The $9.0 million of cash used in accounts payable, accruals and other obligations during the first nine months of fiscal 2019 primarily reflects an employee payout of accrued leave in North America due to a new paid time off policy, partially offset by increased inventory purchases during fiscal 2019; and |

[0000936395-19-000040:mdna:224]
| • | The $4.4 million of cash provided by deferred revenue during the first nine months of fiscal 2019 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-19-000040:mdna:225]
Our days sales outstanding (“DSOs”) for the first nine months of fiscal 2019 were 91 days, and our inventory turns for the first nine months of fiscal 2019 were 4.7. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-19-000040:mdna:226]
[same as prior period, unchanged from 0000936395-19-000021:mdna:230]

[0000936395-19-000040:mdna:227]
[same as prior period, unchanged from 0000936395-19-000021:mdna:231]

[0000936395-19-000040:mdna:228]
|  | Nine months ended |
|  | July 31, 2019 |
| Term Loan due September 28, 2025 (1) | $ | 23,442 |  |
| Interest rate swaps(2) | 1,407 |  |
| ABL Credit Facility(3) | 1,234 |  |
| Capital leases | 3,838 |  |
| Cash paid during period | $ | 29,921 |  |

[0000936395-19-000040:mdna:229]
| (1) | Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. At the end of the third quarter of fiscal 2019, the interest rate on the 2025 Term Loan was 4.27%. |

[0000936395-19-000040:mdna:230]
| (2) | The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023. |

[0000936395-19-000040:mdna:231]
| (3) | During the first nine months of fiscal 2019, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.2 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility. |

[0000936395-19-000040:mdna:232]
[same as prior period, unchanged from 0000936395-19-000021:mdna:237]

[0000936395-19-000040:mdna:233]
[same as prior period, unchanged from 0000936395-19-000021:mdna:238]

[0000936395-19-000040:mdna:234]
[same as prior period, unchanged from 0000936395-19-000021:mdna:239]

[0000936395-19-000040:mdna:235]
[same as prior period, unchanged from 0000936395-19-000021:mdna:240]

[0000936395-19-000040:mdna:236]
[same as prior period, unchanged from 0000936395-19-000021:mdna:241]

[0000936395-19-000040:mdna:237]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-19-000040:mdna:238]
[same as prior period, unchanged from 0000936395-19-000021:mdna:243]

[0000936395-19-000040:mdna:239]
[same as prior period, unchanged from 0000936395-19-000021:mdna:244]

[0000936395-19-000040:mdna:240]
[same as prior period, unchanged from 0000936395-19-000021:mdna:245]

[0000936395-19-000040:mdna:241]
[same as prior period, unchanged from 0000936395-19-000021:mdna:246]

[0000936395-19-000040:mdna:242]
[same as prior period, unchanged from 0000936395-19-000021:mdna:247]
