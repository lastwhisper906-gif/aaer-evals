# CIEN MD&A — 0000936395-22-000053


## mdna

[0000936395-22-000053:mdna:1]
[same as prior period, unchanged from 0000936395-22-000045:mdna:1]

[0000936395-22-000053:mdna:2]
[same as prior period, unchanged from 0000936395-22-000045:mdna:2]

[0000936395-22-000053:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, operational efforts such as expanding manufacturing capacity and accumulating inventory and their expected impacts, business prospects and strategies and other “forward-looking” information. Forward-looking statements may appear throughout this report, including in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors.” In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” “prepare,” or “continue” or the negative of those words and other comparable words. You should be aware that the forward-looking statements contained in this report are based on our current views and assumptions, and are subject to known and unknown risks, uncertainties and other factors that may cause actual events or results to differ materially.

[0000936395-22-000053:mdna:4]
[same as prior period, unchanged from 0000936395-22-000045:mdna:4]

[0000936395-22-000053:mdna:5]
[same as prior period, unchanged from 0000936395-22-000045:mdna:5]

[0000936395-22-000053:mdna:6]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that enable the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and emerging network operators. Our portfolio is designed to enable what we refer to as the Adaptive Network™, our vision for a network end state that emphasizes a programmable and scalable network infrastructure, software control and automation capabilities, network analytics and intelligence, and related advanced services. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes a wide array of software solutions that deliver operations, administration, maintenance, and provisioning (OAM&P) functionality, as well as domain control, orchestration, operational support systems (OSS) and service assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through our Blue Planet® Software suite, we enable customers to accelerate the digital transformation of their networks through service lifecycle automation.

[0000936395-22-000053:mdna:7]
[same as prior period, unchanged from 0000936395-22-000045:mdna:7]

[0000936395-22-000053:mdna:8]
Since the second quarter of fiscal 2021, we have experienced unprecedented demand for our products and services. Our quarterly order volumes during this period have significantly exceeded our  revenue and historical order volumes, with some concentration of orders among certain existing Webscale and North America-based service provider customers. We believe that we are benefiting from certain shifts in business and consumer behaviors, in part accelerated by the COVID-19 pandemic, that represent positive, long-term trends for our business. These include 5G, enterprise and consumer cloud network adoption, increasing demands on the network edge, and network operator focus on resilience and automation. We believe some portion of these orders also reflects customer acceleration of future orders due to lengthened lead times or the implementation of security of supply strategies to address the supply constraints described below. As a result, our backlog has grown from $2.2 billion at the end of fiscal 2021 to $4.4 billion at the end of the third quarter of fiscal 2022. However, our order growth relative to revenue has begun to moderate from the first half of fiscal 2022 and we expect it to continue to moderate over time; and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to the demand environment.

[0000936395-22-000053:mdna:9]
[same as prior period, unchanged from 0000936395-22-000045:mdna:9]

[0000936395-22-000053:mdna:10]
In the face of extraordinary demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits and other electronic components used in most of our products, has experienced substantial constraint and disruption in recent periods. As a result, we have experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. Beginning in the second half of fiscal 2021, we started placing significant, advanced orders for supply of certain long lead time components to address our expected customer demand for fiscal 2022 and the then emerging supply chain challenges. Since that time, we have continued to extend the duration of our purchase commitments, or placed non-cancellable, advanced orders with or through suppliers, particularly for long lead time components. As of July 30, 2022 we had $2.1 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory.

[0000936395-22-000053:mdna:11]
During the third quarter of fiscal 2022, reliability of supply improved and the majority of our suppliers were able to deliver components by their promised, though in many cases, extended, lead times. However, we continued to experience substantial delays and lower-than-expected component deliveries from a small group of our suppliers of integrated circuit components that represent a small fraction of our overall materials but are essential for delivering finished products. Ongoing supply constraints and the unpredictable performance of our supply chain are impacting our ability to meet customer demand and our level of revenue and growth in fiscal 2022, in particular for our Converged Packet Optical products. At the same time, increased supply chain costs, including purchase price increases, supply premiums, expediting fees and freight and logistics, have impacted our gross margin and profitability in fiscal 2022. We expect these constrained supply conditions to increase our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner

[0000936395-22-000053:mdna:12]
consistent with prior periods. We believe these supply chain challenges and their adverse impact on our business, our revenue and our profitability will persist at least through the remainder of fiscal 2022.

[0000936395-22-000053:mdna:13]
To mitigate the impact of these supply conditions on our business and customers, in addition to placing advance orders for inventory, we have been expanding our manufacturing capacity and accumulating components that are in available supply, in some cases with expanded lead times. We believe that this approach positions us to produce finished goods more quickly when supply constraints ease for those components for which delivery continues to be delayed. As a result of this strategy, our inventory has increased from $374.3 million at the end of fiscal 2021 to $826.7 million at the end of the third quarter of fiscal 2022. We have also implemented additional mitigation strategies, including multi-sourcing activities, qualifying alternative parts, and product redesign, and expect, over time, to realize the benefits of these mitigation activities. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain and our mitigation activities.

[0000936395-22-000053:mdna:14]
[same as prior period, unchanged from 0000936395-22-000045:mdna:14]

[0000936395-22-000053:mdna:15]
COVID-19 Pandemic. The impact of the COVID-19 pandemic and countermeasures taken to contain its spread remain dynamic. We continue to monitor the situation and actively assess further implications for our business, supply chain, fulfillment operations and customer demand. For example, we reopened a significant number of our offices globally during fiscal 2022. We continue to take meaningful precautions in accordance with relevant guidelines to protect the health and safety of our employees. Variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. If the COVID-19 pandemic or its adverse effects, including the effects of government-mandated lockdowns in several cities in China during fiscal 2022, become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected. For additional information on the impact of COVID-19 upon our business, operations and financial results, and the steps that we have taken in response, see our 2021 Annual Report.

[0000936395-22-000053:mdna:16]
Russia and Ukraine Conflict. In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions, which could damage or disrupt international commerce and the global economy. We are complying with a broad range of United States and international sanctions and export control requirements imposed on Russia and, on March 7, 2022, we announced our decision to suspend our business operations in Russia immediately. Due to the limited amount of business that we have conducted in Russia historically, this decision has not materially impacted our results of operations for the third quarter of fiscal 2022 and we do not expect it to materially impact our results of operations going forward. See Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on the impact of suspending our business operations in Russia.

[0000936395-22-000053:mdna:17]
[same as prior period, unchanged from 0000936395-22-000045:mdna:17]

[0000936395-22-000053:mdna:18]
Stock Repurchase Program and Accelerated Share Repurchase Agreement. On December 9, 2021, we announced that our Board of Directors had authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety our previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement (the “ASR Agreement”) for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During the first nine months of fiscal 2022, we repurchased $242.0 million of our common stock under the stock repurchase program, and we had $508.0 million remaining under the current repurchase authorization as of July 30, 2022. The amount and timing of any further repurchases under our stock purchase program are subject to a variety of factors, including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 19 and 23 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on our stock repurchase program.

[0000936395-22-000053:mdna:19]
[same as prior period, unchanged from 0000936395-22-000045:mdna:20]

[0000936395-22-000053:mdna:20]
[same as prior period, unchanged from 0000936395-22-000045:mdna:21]

[0000936395-22-000053:mdna:21]
[same as prior period, unchanged from 0000936395-22-000045:mdna:22]

[0000936395-22-000053:mdna:22]
[same as prior period, unchanged from 0000936395-22-000045:mdna:23]

[0000936395-22-000053:mdna:23]
[same as prior period, unchanged from 0000936395-22-000045:mdna:24]

[0000936395-22-000053:mdna:24]
[same as prior period, unchanged from 0000936395-22-000045:mdna:25]

[0000936395-22-000053:mdna:25]
Approximately 13.2% and 14.0% of our revenue was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2022, respectively, primarily including sales in Euros, Canadian Dollars and British Pounds. During the third quarter of fiscal 2022, as compared to the third quarter of fiscal 2021, and during the first nine months of fiscal 2022, as compared to the first nine months of fiscal 2021, the U.S. Dollar primarily strengthened against these currencies. Consequently, our revenue for the third quarter and first nine months of fiscal 2022 reported in U.S. Dollars was adversely impacted by approximately $10.8 million, or 1.3%, and $19.3 million, or 0.7%, respectively.

[0000936395-22-000053:mdna:26]
[same as prior period, unchanged from 0000936395-22-000045:mdna:27]

[0000936395-22-000053:mdna:27]
[same as prior period, unchanged from 0000936395-22-000045:mdna:28]

[0000936395-22-000053:mdna:28]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | 712,906 |  |  |  |  | (20.9) | % |  | $ | 1,730,066 |  |  | $ | 1,798,888 |  |  |  |  | (3.8) | % |
| %** | 65.0 | % |  | 72.1 | % |  |  |  |  |  | 65.0 | % |  | 69.7 | % |  |  |  |  |
| Routing and Switching | 100,741 |  |  | 69,698 |  |  |  |  | 44.5 | % |  | 295,638 |  |  | 197,632 |  |  |  |  | 49.6 | % |
| %** | 11.6 | % |  | 7.1 | % |  |  |  |  |  | 11.1 | % |  | 7.7 | % |  |  |  |  |
| Total Networking Platforms | 664,578 |  |  | 782,604 |  |  |  |  | (15.1) | % |  | 2,025,704 |  |  | 1,996,520 |  |  |  |  | 1.5 | % |
| %** | 76.6 | % |  | 79.2 | % |  |  |  |  |  | 76.1 | % |  | 77.4 | % |  |  |  |  |
| Platform Software and Services | 63,483 |  |  | 56,945 |  |  |  |  | 11.5 | % |  | 205,557 |  |  | 163,472 |  |  |  |  | 25.7 | % |
| %** | 7.3 | % |  | 5.8 | % |  |  |  |  |  | 7.7 | % |  | 6.4 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 17,342 |  |  | 16,607 |  |  |  |  | 4.4 | % |  | 55,334 |  |  | 57,499 |  |  |  |  | (3.8) | % |
| %** | 2.0 | % |  | 1.7 | % |  |  |  |  |  | 2.1 | % |  | 2.2 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 72,760 |  |  | 74,006 |  |  |  |  | (1.7) | % |  | 219,270 |  |  | 212,054 |  |  |  |  | 3.4 | % |
| %** | 8.4 | % |  | 7.5 | % |  |  |  |  |  | 8.3 | % |  | 8.2 | % |  |  |  |  |
| Installation and Deployment | 38,704 |  |  | 46,653 |  |  |  |  | (17.0) | % |  | 120,504 |  |  | 124,263 |  |  |  |  | (3.0) | % |
| %** | 4.4 | % |  | 4.7 | % |  |  |  |  |  | 4.5 | % |  | 4.8 | % |  |  |  |  |
| Consulting and Network Design | 11,114 |  |  | 11,326 |  |  |  |  | (1.9) | % |  | 35,282 |  |  | 25,390 |  |  |  |  | 39.0 | % |
| %** | 1.3 | % |  | 1.1 | % |  |  |  |  |  | 1.3 | % |  | 1.0 | % |  |  |  |  |
| Total Global Services | 122,578 |  |  | 131,985 |  |  |  |  | (7.1) | % |  | 375,056 |  |  | 361,707 |  |  |  |  | 3.7 | % |
| %** | 14.1 | % |  | 13.3 | % |  |  |  |  |  | 14.1 | % |  | 14.0 | % |  |  |  |  |
| Total revenue | $ | 867,981 |  |  | $ | 988,141 |  |  |  |  | (12.2) | % |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |  |  |  | 3.2 | % |

[0000936395-22-000053:mdna:29]
[same as prior period, unchanged from 0000936395-22-000045:mdna:30]

[0000936395-22-000053:mdna:30]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:31]
[same as prior period, unchanged from 0000936395-22-000045:mdna:70]

[0000936395-22-000053:mdna:32]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:33]
•Networking Platforms segment revenue decreased by $118.0 million, reflecting product line sales decreases of $149.1 million of our Converged Packet Optical products, partially offset by product line sales increases of $31.0 million of our Routing and Switching products.

[0000936395-22-000053:mdna:34]
◦Converged Packet Optical sales decreased, primarily reflecting sales decreases of $151.8 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-scale providers, and $11.0 million of our 5400 family of Packet-Optical Platforms, primarily to communication service providers. These sales decreases were partially offset by a sales increase of $29.4 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers and communication service providers.

[0000936395-22-000053:mdna:35]
◦Routing and Switching sales increased, primarily reflecting sales of $24.1 million of our Virtualization Edge software, which was acquired in the acquisition of the Vyatta Software Technology (“Vyatta”) and its virtual routing and switching technology in the first quarter of fiscal 2022, and a sales increase of $13.2 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. The increase in Routing and Switching sales was partially offset by a sales decrease of $5.8 million of our 8700 Packetwave Platform, primarily to communication service providers.

[0000936395-22-000053:mdna:36]
•Platform Software and Services segment revenue increased by $6.5 million, reflecting sales increases of $8.7 million in software services, primarily to communication service providers, offset by a sales decrease of $2.2 million in sales of software platforms.

[0000936395-22-000053:mdna:37]
•Blue Planet Automation Software and Services segment revenue remained relatively unchanged.

[0000936395-22-000053:mdna:38]
•Global Services segment revenue decreased by $9.4 million, primarily reflecting sales decreases of $7.9 million of our installation and deployment services and $1.2 million of our maintenance support and training services.

[0000936395-22-000053:mdna:39]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:40]
•Networking Platforms segment revenue increased by $29.2 million, reflecting product line sales increases of $98.0 million of our Routing and Switching products, offset by product line sales decreases of $68.8 million of our Converged Packet Optical products.

[0000936395-22-000053:mdna:41]
◦Converged Packet Optical sales decreased, primarily reflecting sales decreases of $95.3 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-scale providers, $20.0 million of our 5400 family of Packet-Optical Platforms and $17.7 million of our Z-Series Packet-Optical Platform, both primarily to communication service providers. These sales decreases were partially offset by a sales increase of $70.7 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers and communication service providers.

[0000936395-22-000053:mdna:42]
◦Routing and Switching sales increased, primarily reflecting sales of $61.8 million of our Virtualization Edge software, and a sales increase of $49.8 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. The increase in Routing and Switching sales was partially offset by a sales decrease of $14.7 million of our 8700 Packetwave Platform, primarily to communication service providers.

[0000936395-22-000053:mdna:43]
•Platform Software and Services segment revenue increased by $42.1 million, reflecting increases of $29.2 million in software services and $12.9 million in sales of software platforms. The increase in our software services was primarily due to increased sales of subscription services. The software sales increase was primarily due to increased sales of our MCP software platform.

[0000936395-22-000053:mdna:44]
•Blue Planet Automation Software and Services segment revenue decreased by $2.2 million, reflecting a decrease of $4.5 million in sales of automation software platforms due to extended project completion timeframes, offset by a sales increase of $2.4 million in software-related services.

[0000936395-22-000053:mdna:45]
•Global Services segment revenue increased by $13.3 million, primarily reflecting sales increases of $9.9 million of our consulting and network design services and $7.2 million of our maintenance support and training, partially offset by a sales decrease of $3.8 million of our installation and deployment services.

[0000936395-22-000053:mdna:46]
[same as prior period, unchanged from 0000936395-22-000045:mdna:47]

[0000936395-22-000053:mdna:47]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The decrease in our Americas region revenue for the quarter ended July 30, 2022 was primarily driven by decreased sales in the United States and Canada.

[0000936395-22-000053:mdna:48]
The increase in our Americas region revenue for the nine months ended July 30, 2022 was primarily driven by increased sales in the United States, partially offset by decreased sales in Brazil. The increase in our APAC region revenue for the quarter ended July 30, 2022 was primarily driven by increased sales in India and Australia. The increase in our APAC region revenue for the nine months ended July 30, 2022 was primarily driven by increased sales in Australia and Singapore. The decrease in our EMEA region revenue for the quarter ended July 30, 2022 was primarily driven by decreased sales in the Netherlands and France. The decrease in our EMEA region revenue for the nine months ended July 30, 2022 was primarily driven by decreased sales in the Netherlands, France, Russia and Germany. Our Russia operations were suspended in March 2022.

[0000936395-22-000053:mdna:49]
[same as prior period, unchanged from 0000936395-22-000045:mdna:50]

[0000936395-22-000053:mdna:50]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Americas | $ | 617,366 |  |  | $ | 692,853 |  |  |  |  | (10.9) | % |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |  |  |  | 7.7 | % |
| %** | 71.1 | % |  | 70.1 | % |  |  |  |  |  | 71.9 | % |  | 68.9 | % |  |  |  |  |
| EMEA | 124,185 |  |  | 189,180 |  |  |  |  | (34.4) | % |  | 420,075 |  |  | 499,652 |  |  |  |  | (15.9) | % |
| %** | 14.3 | % |  | 19.2 | % |  |  |  |  |  | 15.8 | % |  | 19.4 | % |  |  |  |  |
| APAC | 126,430 |  |  | 106,108 |  |  |  |  | 19.2 | % |  | 328,226 |  |  | 302,607 |  |  |  |  | 8.5 | % |
| %** | 14.6 | % |  | 10.7 | % |  |  |  |  |  | 12.3 | % |  | 11.7 | % |  |  |  |  |
| Total | $ | 867,981 |  |  | $ | 988,141 |  |  |  |  | (12.2) | % |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |  |  |  | 3.2 | % |

[0000936395-22-000053:mdna:51]
[same as prior period, unchanged from 0000936395-22-000045:mdna:52]

[0000936395-22-000053:mdna:52]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:53]
**     Denotes % of total revenue

[0000936395-22-000053:mdna:54]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:55]
•Americas revenue decreased by $75.5 million, reflecting sales decreases of $80.5 million within our Networking Platforms segment and $1.8 million within our Global Services segment. These sale decreases were offset by sales increases of $5.2 million within our Platform Software and Services segment and $1.5 million within our Blue Planet Automation Software and Services segment. The decrease within our Networking Platforms segment reflects product line sales decreases of $111.8 million of our Converged Packet Optical products, partially offset by sales increases of $31.3 million of our Routing and Switching products. The decrease within our Converged Packet Optical product line was primarily related to a sales decrease of $129.2 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-Scale providers. This sales decrease was partially offset by a sales increase of $18.0 million of our Waveserver® products primarily to communication service providers. Routing and Switching product line sales reflect $24.1 million of our Virtualization Edge software and a sales increase of $12.9 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communication service providers.

[0000936395-22-000053:mdna:56]
•EMEA revenue decreased by $65.0 million, primarily reflecting sales decreases of $57.1 million within our Networking Platforms segment, $6.5 million within our Global Services segment and $1.7 million within our Blue Planet Automation Software and Services segment. The decrease within our Networking Platforms segment primarily reflects product line sales decreases of $56.7 million of our Converged Packet Optical products, primarily related to a sales decrease of $35.9 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-Scale providers and $20.5 million of our Waveserver® products primarily to Web-scale providers. Sales decreased by $2.2 million from customers in Russia.

[0000936395-22-000053:mdna:57]
•APAC revenue increased by $20.3 million, primarily reflecting sales increases of $19.5 million within our Networking Platforms segment and $1.1 million within our Platform Software and Services segment, partially offset by a sales decrease of $1.2 within our Global Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $19.4 million of Converged Packet Optical products, primarily reflecting sales increases of $13.2 million of our 6500 Packet-Optical Platform, primarily to customers in India.

[0000936395-22-000053:mdna:58]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:59]
•Americas revenue increased by $136.4 million, reflecting sales increases of $80.4 million within our Networking Platforms segment, $31.9 million within our Platform Software and Services segment, $19.6 million within our Global Services segment, and $4.5 million within our Blue Planet Automation Software and Services segment. Our

[0000936395-22-000053:mdna:60]
Networking Platforms segment revenue increase reflects product line sales increases of $102.2 million of Routing and Switching products, partially offset by product line sales decreases of $21.8 million of Converged Packet Optical products. Routing and Switching product line sales reflect $61.8 million of our Virtualization Edge software, and a sales increase of $51.0 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communication service providers. Our Converged Packet Optical revenue decrease primarily reflects sales decreases of $77.2 million of our 6500 Packet-Optical Platform, $17.6 million of our 5400 family of Packet-Optical Platforms and $16.5 million of our Z-Series Packet-Optical Platform, primarily to communication service providers. These sales decreases were partially offset by sales increases of $48.7 million of our Waveserver® products, primarily to communication service providers, and $40.0 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-Scale providers.

[0000936395-22-000053:mdna:61]
•EMEA revenue decreased by $79.6 million, reflecting sales decreases of $70.7 million within our Networking Platforms segment, $9.4 million within our Global Services segment and $5.8 million within our Blue Planet Automation Software and Services segment. These sales decreases were offset by a sales increase of $6.3 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects product line sales decreases of $72.4 million of Converged Packet Optical products, primarily reflecting sales decreases of $49.0 million of our Waveserver® products primarily to Web-scale providers and $37.4 million of our 6500 Packet-Optical Platform, primarily to communication service providers and Web-scale providers. Sales decreased by $8.9 million from customers in Russia.

[0000936395-22-000053:mdna:62]
•APAC revenue increased by $25.6 million, primarily reflecting sales increases of $19.5 million within our Networking Platforms segment, $3.9 million within our Platform Software and Services segment and $3.1 million within our Global Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $25.4 million of Converged Packet Optical products, primarily reflecting sales increases of $19.2 million of our 6500 Packet-Optical Platform, primarily to enterprise and government customers.

[0000936395-22-000053:mdna:63]
[same as prior period, unchanged from 0000936395-22-000045:mdna:64]

[0000936395-22-000053:mdna:64]
[same as prior period, unchanged from 0000936395-22-000045:mdna:65]

[0000936395-22-000053:mdna:65]
Canada Emergency Wage Subsidy (“CEWS”) benefits, recorded in the particular line item within cost of goods sold in our Condensed Consolidated Statement of Operations to which the grant activity relates, were $7.0 million in the first nine months of fiscal 2021, net of certain fees. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-22-000053:mdna:66]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Total revenue | $ | 867,981 |  |  | $ | 988,141 |  |  |  |  | (12.2) | % |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |  |  |  | 3.2 | % |
| Total cost of goods sold | 527,202 |  |  | 513,591 |  |  |  |  | 2.7 | % |  | 1,534,904 |  |  | 1,334,338 |  |  |  |  | 15.0 | % |
| Gross profit | $ | 340,779 |  |  | $ | 474,550 |  |  |  |  | (28.2) | % |  | $ | 1,126,747 |  |  | $ | 1,244,860 |  |  |  |  | (9.5) | % |
| %** | 39.3 | % |  | 48.0 | % |  |  |  |  |  | 42.3 | % |  | 48.3 | % |  |  |  |  |

[0000936395-22-000053:mdna:67]
[same as prior period, unchanged from 0000936395-22-000045:mdna:68]

[0000936395-22-000053:mdna:68]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:69]
**     Denotes % of total revenue

[0000936395-22-000053:mdna:70]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Product revenue | $ | 684,284 |  |  | $ | 804,414 |  |  |  |  | (14.9) | % |  | $ | 2,109,239 |  |  | $ | 2,071,677 |  |  |  |  | 1.8 | % |
| Product cost of goods sold | 434,756 |  |  | 420,236 |  |  |  |  | 3.5 | % |  | 1,259,378 |  |  | 1,074,935 |  |  |  |  | 17.2 | % |
| Product gross profit | $ | 249,528 |  |  | $ | 384,178 |  |  |  |  | (35.0) | % |  | $ | 849,861 |  |  | $ | 996,742 |  |  |  |  | (14.7) | % |
| %** | 36.5 | % |  | 47.8 | % |  |  |  |  |  | 40.3 | % |  | 48.1 | % |  |  |  |  |

[0000936395-22-000053:mdna:71]
[same as prior period, unchanged from 0000936395-22-000045:mdna:72]

[0000936395-22-000053:mdna:72]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:73]
[same as prior period, unchanged from 0000936395-22-000045:mdna:74]

[0000936395-22-000053:mdna:74]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Services revenue | $ | 183,697 |  |  | $ | 183,727 |  |  |  |  | — | % |  | $ | 552,412 |  |  | $ | 507,521 |  |  |  |  | 8.8 | % |
| Services cost of goods sold | 92,446 |  |  | 93,355 |  |  |  |  | (1.0) | % |  | 275,526 |  |  | 259,403 |  |  |  |  | 6.2 | % |
| Services gross profit | $ | 91,251 |  |  | $ | 90,372 |  |  |  |  | 1.0 | % |  | $ | 276,886 |  |  | $ | 248,118 |  |  |  |  | 11.6 | % |
| % ** | 49.7 | % |  | 49.2 | % |  |  |  |  |  | 50.1 | % |  | 48.9 | % |  |  |  |  |

[0000936395-22-000053:mdna:75]
[same as prior period, unchanged from 0000936395-22-000045:mdna:76]

[0000936395-22-000053:mdna:76]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:77]
[same as prior period, unchanged from 0000936395-22-000045:mdna:78]

[0000936395-22-000053:mdna:78]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:79]
•Gross profit decreased by $133.8 million. Gross margin decreased by 870 basis points, primarily due to increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix, partially offset by a larger percentage of higher margin services revenue. As described in “Overview” above, we expect the current constrained supply environment, including the current market shortage for semiconductor components, to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2022. We believe that these supply chain challenges and their adverse impact on our business and financial results will persist at least through the remainder of fiscal 2022.

[0000936395-22-000053:mdna:80]
•Gross profit on products decreased by $134.7 million. Product gross margin decreased by 1,130 basis points, primarily due to the increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix. The lower margin product mix during the third quarter of fiscal 2022 was due to substantial delays or lower-than-expected deliveries of components from a small group of our suppliers which impacted our ability to manufacture and deliver optical modems included in our higher margin channel cards.

[0000936395-22-000053:mdna:81]
•Gross profit on services remained relatively unchanged.

[0000936395-22-000053:mdna:82]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:83]
•Gross profit decreased by $118.1 million. Gross margin decreased by 600 basis points, primarily due to increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix, partially offset by a larger percentage of higher margin services revenue.

[0000936395-22-000053:mdna:84]
•Gross profit on products decreased by $146.9 million. Product gross margin decreased by 780 basis points, primarily due to increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix.

[0000936395-22-000053:mdna:85]
•Gross profit on services increased by $28.8 million. Services gross margin increased by 120 basis points, primarily due to higher revenues with relatively lower incremental costs on all services.

[0000936395-22-000053:mdna:86]
[same as prior period, unchanged from 0000936395-22-000045:mdna:87]

[0000936395-22-000053:mdna:87]
[same as prior period, unchanged from 0000936395-22-000045:mdna:88]

[0000936395-22-000053:mdna:88]
Approximately 51.0% of our operating expense was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2022, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the third quarter of fiscal 2022, as compared to the third quarter of fiscal 2021, and the first nine months of fiscal 2022, as compared to the first nine

[0000936395-22-000053:mdna:89]
months of fiscal 2021, the U.S. Dollar primarily strengthened against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $9.3 million, or 3.0%, and $14.7 million, or 1.5%, respectively.

[0000936395-22-000053:mdna:90]
[same as prior period, unchanged from 0000936395-22-000045:mdna:90]

[0000936395-22-000053:mdna:91]
In the first nine months of fiscal 2021, we recorded CEWS benefits of $34.3 million, net of certain fees, related to the particular line item within operating expense in our Condensed Consolidated Statement of Operations to which the grant activity related. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000053:mdna:92]
[same as prior period, unchanged from 0000936395-22-000045:mdna:92]

[0000936395-22-000053:mdna:93]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Research and development | $ | 150,025 |  |  | $ | 146,225 |  |  |  |  | 2.6 | % |  | $ | 457,758 |  |  | $ | 389,212 |  |  |  |  | 17.6 | % |
| %** | 17.3 | % |  | 14.8 | % |  |  |  |  |  | 17.2 | % |  | 15.1 | % |  |  |  |  |
| Selling and marketing | 105,880 |  |  | 114,924 |  |  |  |  | (7.9) | % |  | 344,700 |  |  | 322,589 |  |  |  |  | 6.9 | % |
| %** | 12.2 | % |  | 11.6 | % |  |  |  |  |  | 13.0 | % |  | 12.5 | % |  |  |  |  |
| General and administrative | 41,121 |  |  | 48,863 |  |  |  |  | (15.8) | % |  | 131,191 |  |  | 132,491 |  |  |  |  | (1.0) | % |
| %** | 4.7 | % |  | 4.9 | % |  |  |  |  |  | 4.9 | % |  | 5.1 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 7,692 |  |  | 9,789 |  |  |  |  | (21.4) | % |  | 20,203 |  |  | 23,865 |  |  |  |  | (15.3) | % |
| %** | 0.9 | % |  | 1.0 | % |  |  |  |  |  | 0.8 | % |  | 0.9 | % |  |  |  |  |
| Amortization of intangible assets | 8,919 |  |  | 5,967 |  |  |  |  | 49.5 | % |  | 26,757 |  |  | 17,896 |  |  |  |  | 49.5 | % |
| %** | 1.0 | % |  | 0.6 | % |  |  |  |  |  | 1.0 | % |  | 0.7 | % |  |  |  |  |
| Acquisition and integration costs | 35 |  |  | 259 |  |  |  |  | (86.5) | % |  | 598 |  |  | 860 |  |  |  |  | (30.5) | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 313,672 |  |  | $ | 326,027 |  |  |  |  | (3.8) | % |  | $ | 981,207 |  |  | $ | 886,913 |  |  |  |  | 10.6 | % |
| %** | 36.1 | % |  | 33.0 | % |  |  |  |  |  | 36.9 | % |  | 34.4 | % |  |  |  |  |

[0000936395-22-000053:mdna:94]
[same as prior period, unchanged from 0000936395-22-000045:mdna:94]

[0000936395-22-000053:mdna:95]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:96]
**     Denotes % of total revenue

[0000936395-22-000053:mdna:97]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:98]
•Research and development expense benefited from $5.6 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $3.8 million. This increase primarily reflects increases in professional services and prototype expense, partially offset by a decrease in employee-related compensation costs primarily related to lower costs associated with our annual cash incentive compensation plan. This increase also reflects the effect of a $2.3 million decrease in benefit from the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project grant reimbursement program.

[0000936395-22-000053:mdna:99]
•Selling and marketing expense benefited from $2.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense decreased by $9.0 million. This decrease primarily reflects a decrease in employee-related compensation costs related to sales commissions and lower costs associated with our annual cash incentive compensation plan, partially offset by an increase in travel and entertainment costs.

[0000936395-22-000053:mdna:100]
•General and administrative expense benefited from $0.8 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expense decreased by $7.7 million. This decrease primarily reflects a decrease in employee-related

[0000936395-22-000053:mdna:101]
35

[0000936395-22-000053:mdna:102]
compensation costs primarily related to lower costs associated with our annual cash incentive compensation plan, partially offset by increased professional services expense.

[0000936395-22-000053:mdna:103]
•Significant asset impairments and restructuring costs decreased by $2.1 million, reflecting reduced costs associated with actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-22-000053:mdna:104]
•Amortization of intangible assets increased by $3.0 million due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic, Inc. (“Xelic”) in the second quarter of fiscal 2022.

[0000936395-22-000053:mdna:105]
[same as prior period, unchanged from 0000936395-22-000045:mdna:103]

[0000936395-22-000053:mdna:106]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:107]
•Research and development expense benefited from $7.9 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $68.5 million. This increase primarily reflects the effect of a $29.5 million benefit received from the now-expired CEWS program recorded in the first nine months of fiscal 2021 and increases in employee headcount and related compensation costs, professional services, facilities and information technology costs and prototype expense, partially offset by lower costs associated with our annual cash incentive compensation plan.

[0000936395-22-000053:mdna:108]
•Selling and marketing expense benefited from $5.5 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $22.1 million. This increase primarily reflects an increase in employee headcount and compensation costs related to sales commission, travel and entertainment costs and the effect of a $2.6 million benefit received from the now-expired CEWS program recorded in the first nine months of fiscal 2021, partially offset by lower costs associated with our annual cash incentive compensation plan.

[0000936395-22-000053:mdna:109]
•General and administrative expense benefited from $1.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expense decreased by $1.3 million. This decrease primarily reflects decreases in employee-related compensation costs primarily related to lower costs associated with our annual cash incentive compensation plan and legal fees, offset by increased professional services.

[0000936395-22-000053:mdna:110]
•Significant asset impairments and restructuring costs decreased by $3.7 million, reflecting reduced costs associated with actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense, partially offset by a $4.1 million impairment charge due to our suspended operations in Russia.

[0000936395-22-000053:mdna:111]
•Amortization of intangible assets increased by $8.9 million due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic during the second quarter of fiscal 2022.

[0000936395-22-000053:mdna:112]
[same as prior period, unchanged from 0000936395-22-000045:mdna:111]

[0000936395-22-000053:mdna:113]
[same as prior period, unchanged from 0000936395-22-000045:mdna:112]

[0000936395-22-000053:mdna:114]
[same as prior period, unchanged from 0000936395-22-000045:mdna:113]

[0000936395-22-000053:mdna:115]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Interest and other income (loss), net | $ | 366 |  |  | $ | 795 |  |  |  |  | 54.0 | % |  | $ | 4,860 |  |  | $ | (1,600) |  |  |  |  | 403.8 | % |
| %** | — | % |  | 0.1 | % |  |  |  |  |  | 0.2 | % |  | (0.1) | % |  |  |  |  |
| Interest expense | $ | 12,642 |  |  | $ | 7,776 |  |  |  |  | 62.6 | % |  | $ | 33,275 |  |  | $ | 22,921 |  |  |  |  | 45.2 | % |
| %** | 1.5 | % |  | 0.8 | % |  |  |  |  |  | 1.3 | % |  | 0.9 | % |  |  |  |  |
| Provision (benefit) for income taxes | $ | 4,319 |  |  | $ | (96,690) |  |  |  |  | (104.5) | % |  | $ | 21,868 |  |  | $ | (63,271) |  |  |  |  | (134.6) | % |
| %** | 0.5 | % |  | (9.8) | % |  |  |  |  |  | 0.8 | % |  | (2.5) | % |  |  |  |  |

[0000936395-22-000053:mdna:116]
[same as prior period, unchanged from 0000936395-22-000045:mdna:115]

[0000936395-22-000053:mdna:117]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:118]
**     Denotes % of total revenue

[0000936395-22-000053:mdna:119]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:120]
•Interest and other income (loss), net primarily reflects the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by higher interest income.

[0000936395-22-000053:mdna:121]
•Interest expense increased primarily due to additional outstanding indebtedness, including our 4.00% senior notes due 2030 (the “2030 Notes”) issued in the first quarter of fiscal 2022.

[0000936395-22-000053:mdna:122]
•Provision (benefit) for income taxes increased by $101.0 million due to the tax benefit associated with recording a deferred tax asset in the third quarter of fiscal 2021.The effective tax rate for the third quarter of fiscal 2022 was higher than the effective tax rate for the third quarter of fiscal 2021, primarily due to the tax benefit associated with recording a deferred tax asset in the third quarter of fiscal 2021.

[0000936395-22-000053:mdna:123]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:124]
•Interest and other income (loss), net primarily reflects a favorable adjustment to the carrying value of a cost method equity investment, the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity and higher interest income.

[0000936395-22-000053:mdna:125]
[same as prior period, unchanged from 0000936395-22-000045:mdna:124]

[0000936395-22-000053:mdna:126]
•Provision (benefit) for income taxes increased by $85.1 million due to the tax benefit associated with recording a deferred tax asset in fiscal 2021. The effective tax rate for the first nine months of fiscal 2022 was higher than the effective tax rate for the first nine months of fiscal 2021, primarily due to the tax benefit associated with recording a deferred tax asset in fiscal 2021.

[0000936395-22-000053:mdna:127]
[same as prior period, unchanged from 0000936395-22-000045:mdna:126]

[0000936395-22-000053:mdna:128]
[same as prior period, unchanged from 0000936395-22-000045:mdna:127]

[0000936395-22-000053:mdna:129]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |  | July 30, 2022 |  | July 31, 2021 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 108,282 |  |  | $ | 244,535 |  |  |  |  | (55.7) | % |  | $ | 395,176 |  |  | $ | 612,378 |  |  |  |  | (35.5) | % |
| Platform Software and Services | $ | 39,646 |  |  | $ | 31,526 |  |  |  |  | 25.8 | % |  | $ | 132,698 |  |  | $ | 95,692 |  |  |  |  | 38.7 | % |
| Blue Planet Automation Software and Services | $ | (10,139) |  |  | $ | (3,243) |  |  |  |  | 212.6 | % |  | $ | (17,693) |  |  | $ | 11 |  |  |  |  | n/a |
| Global Services | $ | 52,965 |  |  | $ | 55,507 |  |  |  |  | (4.6) | % |  | $ | 158,808 |  |  | $ | 147,567 |  |  |  |  | 7.6 | % |

[0000936395-22-000053:mdna:130]
[same as prior period, unchanged from 0000936395-22-000045:mdna:129]

[0000936395-22-000053:mdna:131]
*    Denotes % change from fiscal 2021 to fiscal 2022

[0000936395-22-000053:mdna:132]
Segment profit (loss) includes CEWS benefits of $36.5 million in the first nine months of fiscal 2021, net of certain fees. For further discussion of benefits from the CEWS program, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000053:mdna:133]
Quarter ended July 30, 2022 as compared to the quarter ended July 31, 2021

[0000936395-22-000053:mdna:134]
•Networking Platforms segment profit decreased by $136.3 million, primarily due to lower sales volume and lower gross margin as described above, and higher research and development costs.

[0000936395-22-000053:mdna:135]
•Platform Software and Services segment profit increased by $8.1 million, primarily due to higher sales volume as described above.

[0000936395-22-000053:mdna:136]
•Blue Planet Automation Software and Services segment reflects lower gross margin on software-related services and higher research and development costs, partially offset by slightly higher sales volume.

[0000936395-22-000053:mdna:137]
•Global Services segment profit decreased by $2.5 million, primarily due to lower sales volume, offset by higher gross margin on services as described above.

[0000936395-22-000053:mdna:138]
Nine months ended July 30, 2022 as compared to the nine months ended July 31, 2021

[0000936395-22-000053:mdna:139]
•Networking Platforms segment profit decreased by $217.2 million, primarily due to lower gross margin as described above, and higher research and development costs, including the effect of a $30.4 million benefit received from the now-expired CEWS program in the first nine months of fiscal 2021, partially offset by higher sales volume.

[0000936395-22-000053:mdna:140]
•Platform Software and Services segment profit increased by $37.0 million, primarily due to higher sales volume as described above.

[0000936395-22-000053:mdna:141]
•Blue Planet Automation Software and Services segment reflects lower software sales volume, reduced gross margin on software-related services, and higher research and development costs including the effect of a $1.2 million benefit received from the now-expired CEWS program in the first nine months of fiscal 2021.

[0000936395-22-000053:mdna:142]
•Global Services segment profit increased by $11.2 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by the effect of a $2.3 million benefit received from the now-expired CEWS program in the first nine months of fiscal 2021.

[0000936395-22-000053:mdna:143]
[same as prior period, unchanged from 0000936395-22-000045:mdna:142]

[0000936395-22-000053:mdna:144]
Overview. For the nine months ended July 30, 2022, we used $153.2 million of cash in operating activities as our working capital requirements of $435.3 million exceeded our net income (adjusted for non-cash charges) of $282.1 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-22-000053:mdna:145]
Cash, cash equivalents and investments decreased by $414.8 million during the first nine months of fiscal 2022. In addition

[0000936395-22-000053:mdna:146]
to the cash used in operations, the decrease in cash also included the following items: (i) cash used to fund our investing activities for capital expenditures totaling $66.9 million; (ii) cash used for acquisition of businesses of $62.0 million; (iii) cash used for stock repurchases under our stock repurchase program of $487.8 million; (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $41.3 million; (v) purchase of a cost method equity investment of $8.0 million; and (vi) net decreases due to the impact of exchange rate changes on cash and cash equivalents of $12.8 million. Proceeds from the issuance of the 2030 Notes provided $394.9 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan provided $30.2 million in cash during the nine months ended July 30, 2022.

[0000936395-22-000053:mdna:147]
[same as prior period, unchanged from 0000936395-22-000045:mdna:145]

[0000936395-22-000053:mdna:148]
[same as prior period, unchanged from 0000936395-22-000045:mdna:146]

[0000936395-22-000053:mdna:149]
|  | July 30,2022 |  | October 30,2021 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 859,687 |  |  | $ | 1,422,546 |  |  | $ | (562,859) |  |
| Short-term investments in marketable debt securities | 321,823 |  |  | 181,483 |  |  | 140,340 |  |
| Long-term investments in marketable debt securities | 77,723 |  |  | 70,038 |  |  | 7,685 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,259,233 |  |  | $ | 1,674,067 |  |  | $ | (414,834) |  |

[0000936395-22-000053:mdna:150]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which, as of July 30, 2022 totaled $1.3 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 30, 2022, letters of credit totaling $84.3 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 30, 2022.

[0000936395-22-000053:mdna:151]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $324.8 million as of July 30, 2022. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical

[0000936395-22-000053:mdna:152]
foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $33.0 million.

[0000936395-22-000053:mdna:153]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During the first nine months of fiscal 2022, we repurchased an additional $242.0 million of our common stock under the stock repurchase program, and we had $508.0 million remaining under the current repurchase authorization as of July 30, 2022. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000053:mdna:154]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-22-000053:mdna:155]
Cash Used In Operating Activities

[0000936395-22-000053:mdna:156]
The following sections set forth the components of our $153.2 million of cash used in operating activities during the first nine months of fiscal 2022:

[0000936395-22-000053:mdna:157]
[same as prior period, unchanged from 0000936395-22-000045:mdna:155]

[0000936395-22-000053:mdna:158]
[same as prior period, unchanged from 0000936395-22-000045:mdna:156]

[0000936395-22-000053:mdna:159]
|  | Nine Months Ended |
|  | July 30, 2022 |
| Net income | $ | 95,257 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 68,280 |  |
| Share-based compensation expenses | 77,827 |  |
| Amortization of intangible assets | 36,521 |  |
| Deferred taxes | (19,824) |  |
| Provision for inventory excess and obsolescence | 12,038 |  |
| Provision for warranty | 12,416 |  |
| Other | (442) |  |
| Net income (adjusted for non-cash charges) | $ | 282,073 |  |

[0000936395-22-000053:mdna:160]
[same as prior period, unchanged from 0000936395-22-000045:mdna:158]

[0000936395-22-000053:mdna:161]
We used $435.3 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-22-000053:mdna:162]
|  | Nine Months Ended |
|  | July 30, 2022 |
| Cash provided by accounts receivable | $ | 74,478 |  |
| Cash used in inventories | (464,664) |  |
| Cash used in prepaid expenses and other | (39,805) |  |
| Cash used in accounts payable, accruals and other obligations | (37,587) |  |
| Cash provided by deferred revenue | 34,949 |  |
| Cash used in operating lease assets and liabilities, net | (2,693) |  |
| Total cash used for working capital | $ | (435,322) |  |

[0000936395-22-000053:mdna:163]
[same as prior period, unchanged from 0000936395-22-000045:mdna:161]

[0000936395-22-000053:mdna:164]
•The $74.5 million of cash provided by accounts receivable during the first nine months of fiscal 2022 reflects increased cash collections;

[0000936395-22-000053:mdna:165]
•The $464.7 million of cash used in inventories during the first nine months of fiscal 2022 primarily reflects increases in raw materials inventory related to the steps that we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-22-000053:mdna:166]
•The $39.8 million of cash used in prepaid expense and other during the first nine months of fiscal 2022 primarily reflects increases in contract assets and product demonstration equipment, partially offset by decreases in prepaid foreign currency forward contracts;

[0000936395-22-000053:mdna:167]
•The $37.6 million of cash used in accounts payable, accruals and other obligations during the first nine months of fiscal 2022 primarily reflects the payment to employees under our annual cash incentive compensation plans, partially offset by the timing of payments for inventory purchases;

[0000936395-22-000053:mdna:168]
•The $34.9 million of cash provided by deferred revenue during the first nine months of fiscal 2022 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-22-000053:mdna:169]
•The $2.7 million of cash used in operating lease assets and liabilities, net, during the first nine months of fiscal 2022 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-22-000053:mdna:170]
Our days sales outstanding (“DSOs”) decreased from 102 for first nine months of fiscal 2021 to 97 for the first nine months of fiscal 2022. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 3.9 for the first nine months of fiscal 2021 to 2.0 for the first nine months of fiscal 2022 due to the increases in inventory as described in “Overview” above.

[0000936395-22-000053:mdna:171]
[same as prior period, unchanged from 0000936395-22-000045:mdna:169]

[0000936395-22-000053:mdna:172]
[same as prior period, unchanged from 0000936395-22-000045:mdna:170]

[0000936395-22-000053:mdna:173]
|  | Nine Months Ended |
|  | July 30, 2022 |
| Term Loan due September 28, 2025 (the “2025 Term Loan”)(1) | $ | 13,079 |  |
| Senior Notes due January 31, 2030(2) | — |  |
| Interest rate swaps(3) | 6,441 |  |
| ABL Credit Facility(4) | 1,791 |  |
| Finance leases | 3,512 |  |
| Cash paid during period | $ | 24,823 |  |

[0000936395-22-000053:mdna:174]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the third quarter of fiscal 2022, the interest rate on the 2025 Term Loan was 3.88%.

[0000936395-22-000053:mdna:175]
[same as prior period, unchanged from 0000936395-22-000045:mdna:173]

[0000936395-22-000053:mdna:176]
[same as prior period, unchanged from 0000936395-22-000045:mdna:174]

[0000936395-22-000053:mdna:177]
(4) During the first nine months of fiscal 2022, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.8 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-22-000053:mdna:178]
[same as prior period, unchanged from 0000936395-22-000045:mdna:176]

[0000936395-22-000053:mdna:179]
[same as prior period, unchanged from 0000936395-22-000045:mdna:177]

[0000936395-22-000053:mdna:180]
Debt. As of July 30, 2022, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes total $128.6 million, with $16.6 million payable within 12 months. For additional information about the 2030 Notes, see Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-22-000053:mdna:181]
Purchase Order Obligations. Beginning in the second half of fiscal 2021, we started placing significant advanced orders for supply of certain long lead time components to address our expected strong customer demand for fiscal 2022 and the then-emerging supply chain challenges. As of July 30, 2022, we had $2.1 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory.

[0000936395-22-000053:mdna:182]
[same as prior period, unchanged from 0000936395-22-000045:mdna:180]

[0000936395-22-000053:mdna:183]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic and the armed conflict between Russia and Ukraine, and expectations as to their impacts on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-22-000053:mdna:184]
[same as prior period, unchanged from 0000936395-22-000045:mdna:182]

[0000936395-22-000053:mdna:185]
[same as prior period, unchanged from 0000936395-22-000045:mdna:183]

[0000936395-22-000053:mdna:186]
[same as prior period, unchanged from 0000936395-22-000045:mdna:184]
