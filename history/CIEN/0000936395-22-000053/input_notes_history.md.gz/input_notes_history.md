# CIEN note change history — 0000936395-22-000045 → 0000936395-22-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:1]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies
  (was, 2022-06-08, similarity 0.7473):
[0000936395-22-000045:note_history:1]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

- removed (2022-09-07):
[0000936395-22-000045:note_history:2]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena could have received up to an aggregate CAD$57.6 million (approximately $44.8 million) in reimbursement from the three Canadian government entities for eligible costs over the period from February 20, 2017 through March 31, 2022. Amounts received under the agreements were subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of April 30, 2022, Ciena has recorded CAD$57.6 million (approximately $44.8 million) in cumulative benefits as a reduction in research and development expense of which CAD$6.6 million ($5.2 million) was recorded in the first six months of fiscal 2022. As of April 30, 2022, amounts receivable from this grant were CAD$3.3 million ($2.6 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

- removed (2022-09-07):
[0000936395-22-000045:note_history:3]
Tax Contingencies


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1 above, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2021 Annual Report.
  (was, 2022-06-08, similarity 0.8195):
[0000936395-22-000045:note_history:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2021 Annual Report.

- changed (2022-09-07):
[0000936395-22-000053:note_history:5]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.
  (was, 2022-06-08, similarity 0.9988):
[0000936395-22-000045:note_history:5]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- changed (2022-09-07):
[0000936395-22-000053:note_history:6]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.
  (was, 2022-06-08, similarity 0.9991):
[0000936395-22-000045:note_history:6]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

- changed (2022-09-07):
[0000936395-22-000053:note_history:7]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract
  (was, 2022-06-08, similarity 0.7744):
[0000936395-22-000045:note_history:7]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London

- changed (2022-09-07):
[0000936395-22-000053:note_history:8]
modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.
  (was, 2022-06-08, similarity 0.8853):
[0000936395-22-000045:note_history:8]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:9]
|  |  | July 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,008) |  |  | $ | (1,887) |  |  | $ | 674,512 |  |  | $ | 677,285 |  |
  (was, 2022-06-08, similarity 0.7358):
[0000936395-22-000045:note_history:9]
|  |  | April 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,169) |  |  | $ | 394,831 |  |  |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.9 million as of July 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2022-06-08, similarity 0.987):
[0000936395-22-000045:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.0 million as of April 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2022-09-07):
[0000936395-22-000053:note_history:11]
As of July 30, 2022, the estimated fair value of the 2025 Term Loan was $674.1 million. The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-06-08, similarity 0.9608):
[0000936395-22-000045:note_history:11]
As of April 30, 2022, the estimated fair value of the 2025 Term Loan was $677.5 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2022-09-07):
[0000936395-22-000053:note_history:12]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a redemption price equal to 102% of the principal amount of the notes to be redeemed, plus any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.
  (was, 2022-06-08, similarity 0.687):
[0000936395-22-000045:note_history:12]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as

- added (2022-09-07):
[0000936395-22-000053:note_history:13]
|  |  | July 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,129) |  |  | $ | 394,871 |  |  |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:14]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.1 million as of July 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.4 million during the first nine months of fiscal 2022.
  (was, 2022-06-08, similarity 0.9404):
[0000936395-22-000045:note_history:14]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.2 million as of April 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first six months of fiscal 2022.

- changed (2022-09-07):
[0000936395-22-000053:note_history:15]
As of July 30, 2022, the estimated fair value of the 2030 Notes was $368.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2022-06-08, similarity 0.9853):
[0000936395-22-000045:note_history:15]
As of April 30, 2022, the estimated fair value of the 2030 Notes was $363.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2022-09-07):
[0000936395-22-000045:note_history:16]
|  |  | April 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,089) |  |  | $ | (2,037) |  |  | $ | 674,281 |  |  | $ | 677,285 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:17]
described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:18]
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):
  (was, 2022-06-08, similarity 0.8374):
[0000936395-22-000045:note_history:18]
As of the dates indicated, investments are comprised of the following (in thousands):

- added (2022-09-07):
[0000936395-22-000053:note_history:19]
|  | July 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 361,659 |  |  | $ | 11 |  |  | $ | (2,945) |  |  | $ | 358,725 |  |
| Corporate debt securities | 33,969 |  |  | 5 |  |  | (100) |  |  | 33,874 |  |
| Time deposits | 121,913 |  |  | 1 |  |  | (26) |  |  | 121,888 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |
| Included in cash equivalents | $ | 114,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,941 |  |
| Included in short-term investments | 322,820 |  |  | 14 |  |  | (1,011) |  |  | 321,823 |  |
| Included in long-term investments | 79,780 |  |  | 3 |  |  | (2,060) |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |

- added (2022-09-07):
[0000936395-22-000053:note_history:20]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:21]
|  | April 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 530,051 |  |  | $ | 1 |  |  | $ | (500) |  |  | $ | 529,552 |  |
| Included in long-term investments | 89,593 |  |  | — |  |  | (2,451) |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 1 |  |  | $ | (2,951) |  |  | $ | 616,694 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:22]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,488 |  |  | $ | 5 |  |  | $ | (10) |  |  | $ | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:23]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):
  (was, 2022-06-08, similarity 0.8259):
[0000936395-22-000045:note_history:23]
SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):

- added (2022-09-07):
[0000936395-22-000053:note_history:24]
|  | July 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 361,659 |  |  | $ | 11 |  |  | $ | (2,945) |  |  | $ | 358,725 |  |
| Corporate debt securities | 33,969 |  |  | 5 |  |  | (100) |  |  | 33,874 |  |
| Time deposits | 121,913 |  |  | 1 |  |  | (26) |  |  | 121,888 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |
| Included in cash equivalents | $ | 114,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,941 |  |
| Included in short-term investments | 322,820 |  |  | 14 |  |  | (1,011) |  |  | 321,823 |  |
| Included in long-term investments | 79,780 |  |  | 3 |  |  | (2,060) |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |

- added (2022-09-07):
[0000936395-22-000053:note_history:25]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:26]
The following table summarizes the final legal maturities of debt investments as of July 30, 2022 (in thousands):
  (was, 2022-06-08, similarity 0.9677):
[0000936395-22-000045:note_history:26]
The following table summarizes the final legal maturities of debt investments as of April 30, 2022 (in thousands):

- removed (2022-09-07):
[0000936395-22-000045:note_history:27]
|  | April 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 530,051 |  |  | $ | 1 |  |  | $ | (500) |  |  | $ | 529,552 |  |
| Included in long-term investments | 89,593 |  |  | — |  |  | (2,451) |  |  | 87,142 |  |
|  | $ | 619,644 |  |  | $ | 1 |  |  | $ | (2,951) |  |  | $ | 616,694 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:28]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,488 |  |  | $ | 5 |  |  | $ | (10) |  |  | $ | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2022-09-07):
[0000936395-22-000053:note_history:29]
|  |  | July 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,008) |  |  | $ | (1,887) |  |  | $ | 674,512 |  |  | $ | 677,285 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:30]
|  |  | April 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,089) |  |  | $ | (2,037) |  |  | $ | 674,281 |  |  | $ | 677,285 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:31]
|  |  | July 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,129) |  |  | $ | 394,871 |  |  |  |
  (was, 2022-06-08, similarity 0.9807):
[0000936395-22-000045:note_history:31]
|  |  | April 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,169) |  |  | $ | 394,831 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:32]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
  (was, 2022-06-08, similarity 0.9979):
[0000936395-22-000045:note_history:32]
|  | Quarter Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:33]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
  (was, 2022-06-08, similarity 0.9845):
[0000936395-22-000045:note_history:33]
|  | Six Months Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:34]
|  | Nine Months Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
  (was, 2022-06-08, similarity 0.9932):
[0000936395-22-000045:note_history:34]
|  | Six Months Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:35]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
  (was, 2022-06-08, similarity 0.9645):
[0000936395-22-000045:note_history:35]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | 773,728 |  |
| Services transferred over time | — |  |  | $ | 47,414 |  |  | $ | 12,845 |  |  | $ | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:36]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 617,366 |  |  | $ | 692,853 |  |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |
| EMEA |  | 124,185 |  |  | 189,180 |  |  | 420,075 |  |  | 499,652 |  |
| APAC |  | 126,430 |  |  | 106,108 |  |  | 328,226 |  |  | 302,607 |  |
| Total revenue by geographic distribution |  | $ | 867,981 |  |  | $ | 988,141 |  |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |
  (was, 2022-06-08, similarity 0.9262):
[0000936395-22-000045:note_history:36]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 700,840 |  |  | $ | 587,475 |  |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |
| EMEA |  | 145,106 |  |  | 155,054 |  |  | 295,891 |  |  | 310,472 |  |
| APAC |  | 103,281 |  |  | 91,398 |  |  | 201,795 |  |  | 196,499 |  |
| Total revenue by geographic distribution |  | $ | 949,227 |  |  | $ | 833,927 |  |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:37]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2022-06-08, similarity 0.8918):
[0000936395-22-000045:note_history:37]
For the periods below, the only customer that accounted for at least 10% of Ciena’s revenue was as follows (in thousands):

- added (2022-09-07):
[0000936395-22-000053:note_history:38]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Verizon | $ | 108,495 |  |  | $ | 131,892 |  |  | $ | 273,158 |  |  | n/a |
| AT&T | 100,293 |  |  | 119,199 |  |  | 314,358 |  |  | 313,140 |  |
| Web-scale provider | n/a |  | 119,728 |  |  | n/a |  | n/a |
| Total | $ | 208,788 |  |  | $ | 370,819 |  |  | $ | 587,516 |  |  | $ | 313,140 |  |

- added (2022-09-07):
[0000936395-22-000053:note_history:39]
_____________________________

- added (2022-09-07):
[0000936395-22-000053:note_history:40]
n/a    Denotes revenue representing less than 10% of total revenue for the periods presented

- removed (2022-09-07):
[0000936395-22-000045:note_history:41]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| AT&T | $ | 103,189 |  |  | 125,138 |  |  | 214,065 |  |  | 193,941 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:42]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
  (was, 2022-06-08, similarity 0.9979):
[0000936395-22-000045:note_history:42]
|  | Quarter Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:43]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
  (was, 2022-06-08, similarity 0.9845):
[0000936395-22-000045:note_history:43]
|  | Six Months Ended May 01, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:44]
|  | Nine Months Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
  (was, 2022-06-08, similarity 0.9932):
[0000936395-22-000045:note_history:44]
|  | Six Months Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:45]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
  (was, 2022-06-08, similarity 0.9645):
[0000936395-22-000045:note_history:45]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | 773,728 |  |
| Services transferred over time | — |  |  | $ | 47,414 |  |  | $ | 12,845 |  |  | $ | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:46]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 617,366 |  |  | $ | 692,853 |  |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |
| EMEA |  | 124,185 |  |  | 189,180 |  |  | 420,075 |  |  | 499,652 |  |
| APAC |  | 126,430 |  |  | 106,108 |  |  | 328,226 |  |  | 302,607 |  |
| Total revenue by geographic distribution |  | $ | 867,981 |  |  | $ | 988,141 |  |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |
  (was, 2022-06-08, similarity 0.9262):
[0000936395-22-000045:note_history:46]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 700,840 |  |  | $ | 587,475 |  |  | $ | 1,295,984 |  |  | $ | 1,084,086 |  |
| EMEA |  | 145,106 |  |  | 155,054 |  |  | 295,891 |  |  | 310,472 |  |
| APAC |  | 103,281 |  |  | 91,398 |  |  | 201,795 |  |  | 196,499 |  |
| Total revenue by geographic distribution |  | $ | 949,227 |  |  | $ | 833,927 |  |  | $ | 1,793,670 |  |  | $ | 1,591,057 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:47]
Ciena’s revenue includes $574.3 million and $623.9 million of United States revenue for the third quarter of fiscal 2022 and 2021, respectively. For the nine months ended July 30, 2022 and July 31, 2021, United States revenue was $1.8 billion and $1.6 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.
  (was, 2022-06-08, similarity 0.8869):
[0000936395-22-000045:note_history:47]
Ciena’s revenue includes $642.2 million and $518.6 million of United States revenue for the second quarter of fiscal 2022 and 2021, respectively. For the six months ended April 30, 2022 and May 1, 2021, United States revenue was $1.2 billion and $1.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- changed (2022-09-07):
[0000936395-22-000053:note_history:48]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2022-06-08, similarity 0.8918):
[0000936395-22-000045:note_history:48]
For the periods below, the only customer that accounted for at least 10% of Ciena’s revenue was as follows (in thousands):

- added (2022-09-07):
[0000936395-22-000053:note_history:49]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Verizon | $ | 108,495 |  |  | $ | 131,892 |  |  | $ | 273,158 |  |  | n/a |
| AT&T | 100,293 |  |  | 119,199 |  |  | 314,358 |  |  | 313,140 |  |
| Web-scale provider | n/a |  | 119,728 |  |  | n/a |  | n/a |
| Total | $ | 208,788 |  |  | $ | 370,819 |  |  | $ | 587,516 |  |  | $ | 313,140 |  |

- added (2022-09-07):
[0000936395-22-000053:note_history:50]
_____________________________

- added (2022-09-07):
[0000936395-22-000053:note_history:51]
n/a    Denotes revenue representing less than 10% of total revenue for the periods presented

- added (2022-09-07):
[0000936395-22-000053:note_history:52]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

- added (2022-09-07):
[0000936395-22-000053:note_history:53]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are

- changed (2022-09-07):
[0000936395-22-000053:note_history:54]
performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2022-06-08, similarity 0.6072):
[0000936395-22-000045:note_history:54]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2022-09-07):
[0000936395-22-000053:note_history:55]
|  |  | Balance at July 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 802,484 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 157,448 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 209,653 |  |  | $ | 175,464 |  |
  (was, 2022-06-08, similarity 0.9808):
[0000936395-22-000045:note_history:55]
|  |  | Balance at April 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 774,896 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 144,344 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 218,769 |  |  | $ | 175,464 |  |

- changed (2022-09-07):
[0000936395-22-000053:note_history:56]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $98.9 million and $94.7 million of revenue during the first nine months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 30, 2022 and July 31, 2021.
  (was, 2022-06-08, similarity 0.937):
[0000936395-22-000045:note_history:56]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $82.0 million and $78.0 million of revenue during the first six months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 30, 2022 and May 1, 2021.

- changed (2022-09-07):
[0000936395-22-000053:note_history:57]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.1 million and $27.6 million as of July 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $20.5 million and $16.8 million during the first nine months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.
  (was, 2022-06-08, similarity 0.9848):
[0000936395-22-000045:note_history:57]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $32.5 million and $27.6 million as of April 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $14.1 million and $10.7 million during the first six months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

- changed (2022-09-07):
[0000936395-22-000053:note_history:58]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 30, 2022, the aggregate amount of RPO was $2.9 billion. As of July 30, 2022, Ciena expects approximately 91% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2022-06-08, similarity 0.6015):
[0000936395-22-000045:note_history:58]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 30, 2022, the aggregate amount of RPO was $2.7 billion. As of April 30, 2022, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.

- removed (2022-09-07):
[0000936395-22-000045:note_history:59]
|  | Quarter Ended |  | Six Months Ended |
|  | April 30, |  | May 1, |  | April 30, |  | May 1, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| AT&T | $ | 103,189 |  |  | 125,138 |  |  | 214,065 |  |  | 193,941 |  |

- removed (2022-09-07):
[0000936395-22-000045:note_history:60]
AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-09-07):
[0000936395-22-000053:note_history:61]
From the end of the third quarter of fiscal 2022 through September 2, 2022, Ciena repurchased an additional 154,247 shares of its common stock, for an aggregate purchase price of $8.0 million at an average price of $51.91 per share, inclusive of repurchases pending settlement. As of September 2, 2022, Ciena has repurchased an aggregate of 8,433,957 shares and has $500.0 million of authorized funds remaining under its stock repurchase program.
  (was, 2022-06-08, similarity 0.9567):
[0000936395-22-000045:note_history:61]
From the end of the second quarter of fiscal 2022 through June 3, 2022, Ciena repurchased an additional 1,161,320 shares of its common stock, for an aggregate purchase price of $60.0 million at an average price of $51.67 per share, inclusive of repurchases pending settlement. As of June 3, 2022, Ciena has repurchased an aggregate of 6,246,078 shares and has $603.0 million of authorized funds remaining under its stock repurchase program.
