# CIEN notes — 0000936395-22-000053


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-22-000053:notes:1]
[same as prior period, unchanged from 0000936395-22-000045:notes:1]

[0000936395-22-000053:notes:2]
[same as prior period, unchanged from 0000936395-22-000045:notes:2]

[0000936395-22-000053:notes:3]
[same as prior period, unchanged from 0000936395-22-000045:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-22-000053:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1 above, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2021 Annual Report.

[0000936395-22-000053:notes:5]
[same as prior period, unchanged from 0000936395-22-000045:notes:5]

[0000936395-22-000053:notes:6]
In December 2019, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 was effective for Ciena beginning in the first quarter of fiscal 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000053:notes:7]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 was effective for annual periods beginning after December 15, 2021. Early adoption was permitted. Ciena adopted ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000053:notes:8]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract

[0000936395-22-000053:notes:9]
modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU No. 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000053:notes:10]
[same as prior period, unchanged from 0000936395-22-000045:notes:10]

[0000936395-22-000053:notes:11]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-22-000053:notes:12]
[same as prior period, unchanged from 0000936395-22-000045:notes:12]

[0000936395-22-000053:notes:13]
[same as prior period, unchanged from 0000936395-22-000045:notes:13]

[0000936395-22-000053:notes:14]
[same as prior period, unchanged from 0000936395-22-000045:notes:14]

[0000936395-22-000053:notes:15]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

[0000936395-22-000053:notes:16]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

[0000936395-22-000053:notes:17]
|  | Nine Months Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

[0000936395-22-000053:notes:18]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

[0000936395-22-000053:notes:19]
[same as prior period, unchanged from 0000936395-22-000045:notes:19]

[0000936395-22-000053:notes:20]
[same as prior period, unchanged from 0000936395-22-000045:notes:20]

[0000936395-22-000053:notes:21]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 617,366 |  |  | $ | 692,853 |  |  | $ | 1,913,350 |  |  | $ | 1,776,939 |  |
| EMEA |  | 124,185 |  |  | 189,180 |  |  | 420,075 |  |  | 499,652 |  |
| APAC |  | 126,430 |  |  | 106,108 |  |  | 328,226 |  |  | 302,607 |  |
| Total revenue by geographic distribution |  | $ | 867,981 |  |  | $ | 988,141 |  |  | $ | 2,661,651 |  |  | $ | 2,579,198 |  |

[0000936395-22-000053:notes:22]
Ciena’s revenue includes $574.3 million and $623.9 million of United States revenue for the third quarter of fiscal 2022 and 2021, respectively. For the nine months ended July 30, 2022 and July 31, 2021, United States revenue was $1.8 billion and $1.6 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-22-000053:notes:23]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-22-000053:notes:24]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Verizon | $ | 108,495 |  |  | $ | 131,892 |  |  | $ | 273,158 |  |  | n/a |
| AT&T | 100,293 |  |  | 119,199 |  |  | 314,358 |  |  | 313,140 |  |
| Web-scale provider | n/a |  | 119,728 |  |  | n/a |  | n/a |
| Total | $ | 208,788 |  |  | $ | 370,819 |  |  | $ | 587,516 |  |  | $ | 313,140 |  |

[0000936395-22-000053:notes:25]
_____________________________

[0000936395-22-000053:notes:26]
n/a    Denotes revenue representing less than 10% of total revenue for the periods presented

[0000936395-22-000053:notes:27]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-22-000053:notes:28]
[same as prior period, unchanged from 0000936395-22-000045:notes:26]

[0000936395-22-000053:notes:29]
[same as prior period, unchanged from 0000936395-22-000045:notes:27]

[0000936395-22-000053:notes:30]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta (as defined in Note 4 below) virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

[0000936395-22-000053:notes:31]
[same as prior period, unchanged from 0000936395-22-000045:notes:29]

[0000936395-22-000053:notes:32]
[same as prior period, unchanged from 0000936395-22-000045:notes:30]

[0000936395-22-000053:notes:33]
[same as prior period, unchanged from 0000936395-22-000045:notes:31]

[0000936395-22-000053:notes:34]
[same as prior period, unchanged from 0000936395-22-000045:notes:32]

[0000936395-22-000053:notes:35]
[same as prior period, unchanged from 0000936395-22-000045:notes:33]

[0000936395-22-000053:notes:36]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are

[0000936395-22-000053:notes:37]
performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-22-000053:notes:38]
[same as prior period, unchanged from 0000936395-22-000045:notes:35]

[0000936395-22-000053:notes:39]
[same as prior period, unchanged from 0000936395-22-000045:notes:36]

[0000936395-22-000053:notes:40]
|  |  | Balance at July 30, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 802,484 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 157,448 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 209,653 |  |  | $ | 175,464 |  |

[0000936395-22-000053:notes:41]
[same as prior period, unchanged from 0000936395-22-000045:notes:38]

[0000936395-22-000053:notes:42]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $98.9 million and $94.7 million of revenue during the first nine months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 30, 2022 and July 31, 2021.

[0000936395-22-000053:notes:43]
[same as prior period, unchanged from 0000936395-22-000045:notes:40]

[0000936395-22-000053:notes:44]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.1 million and $27.6 million as of July 30, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $20.5 million and $16.8 million during the first nine months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

[0000936395-22-000053:notes:45]
[same as prior period, unchanged from 0000936395-22-000045:notes:42]

[0000936395-22-000053:notes:46]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 30, 2022, the aggregate amount of RPO was $2.9 billion. As of July 30, 2022, Ciena expects approximately 91% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-22-000053:notes:47]
[same as prior period, unchanged from 0000936395-22-000045:notes:44]

[0000936395-22-000053:notes:48]
|  | July 30,2022 |  | October 30,2021 |
| Products | $ | 27,432 |  |  | $ | 12,859 |  |
| Services | 182,221 |  |  | 162,605 |  |
| Total deferred revenue | 209,653 |  |  | 175,464 |  |
| Less current portion | (147,808) |  |  | (118,007) |  |
| Long-term deferred revenue | $ | 61,845 |  |  | $ | 57,457 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-22-000053:notes:49]
[same as prior period, unchanged from 0000936395-22-000045:notes:46]

[0000936395-22-000053:notes:50]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology. AT&T is a customer of Ciena, see Note 3 above. On March 9, 2022, Ciena acquired Xelic, Inc., a provider and developer of field programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores. These businesses were acquired for an aggregate of approximately $64.3 million, of which $63.5 million was paid in cash and $0.8 million represents a future payable arrangement. These transactions have each been accounted for as the acquisition of a business.

[0000936395-22-000053:notes:51]
[same as prior period, unchanged from 0000936395-22-000045:notes:48]

[0000936395-22-000053:notes:52]
[same as prior period, unchanged from 0000936395-22-000045:notes:49]

[0000936395-22-000053:notes:53]
[same as prior period, unchanged from 0000936395-22-000045:notes:50]

[0000936395-22-000053:notes:54]
[same as prior period, unchanged from 0000936395-22-000045:notes:51]

[0000936395-22-000053:notes:55]
[same as prior period, unchanged from 0000936395-22-000045:notes:52]

[0000936395-22-000053:notes:56]
[same as prior period, unchanged from 0000936395-22-000045:notes:53]

[0000936395-22-000053:notes:57]
[same as prior period, unchanged from 0000936395-22-000045:notes:54]


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-22-000053:notes:58]
[same as prior period, unchanged from 0000936395-22-000045:notes:55]

[0000936395-22-000053:notes:59]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. During the nine months ended July 31, 2021, Ciena recorded a CAD$52.2 million ($41.3 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($35.2 million) related to employee wages during fiscal 2020.

[0000936395-22-000053:notes:60]
The following table summarizes CEWS for the periods indicated (in thousands, U.S. Dollar):

[0000936395-22-000053:notes:61]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Product | $ | — |  |  | $ | 94 |  |  | $ | — |  |  | $ | 4,283 |  |
| Service | — |  |  | 47 |  |  | — |  |  | 2,667 |  |
| CEWS benefit in cost of goods sold | — |  |  | 141 |  |  | — |  |  | 6,950 |  |
| Research and development | — |  |  | 596 |  |  | — |  |  | 29,519 |  |
| Sales and marketing | — |  |  | 53 |  |  | — |  |  | 2,604 |  |
| General and administrative | — |  |  | 46 |  |  | — |  |  | 2,207 |  |
| CEWS benefit in operating expense | — |  |  | 695 |  |  | — |  |  | 34,330 |  |
| Total CEWS benefit | $ | — |  |  | $ | 836 |  |  | $ | — |  |  | $ | 41,280 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-22-000053:notes:62]
[same as prior period, unchanged from 0000936395-22-000045:notes:59]

[0000936395-22-000053:notes:63]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the nine months ended July 30, 2022 (in thousands):

[0000936395-22-000053:notes:64]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 2,224 |  | (1) | 13,992 |  | (2) | 16,216 |  |
| Cash payments | (2,423) |  |  | (13,115) |  |  | (15,538) |  |
| Balance at July 30, 2022 | $ | 582 |  |  | $ | 877 |  |  | $ | 1,459 |  |
| Current restructuring liabilities | $ | 582 |  |  | $ | 877 |  |  | $ | 1,459 |  |

[0000936395-22-000053:notes:65]
(1) Reflects employee costs associated with workforce reductions during the nine months ended July 30, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000053:notes:66]
[same as prior period, unchanged from 0000936395-22-000045:notes:63]

[0000936395-22-000053:notes:67]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended July 31, 2021 (in thousands):

[0000936395-22-000053:notes:68]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 5,306 |  | (1) | 18,558 |  | (2) | 23,864 |  |
| Cash payments | (7,051) |  |  | (18,558) |  |  | (25,609) |  |
| Balance at July 31, 2021 | $ | 1,170 |  |  | $ | — |  |  | $ | 1,170 |  |
| Current restructuring liabilities | $ | 1,170 |  |  | $ | — |  |  | $ | 1,170 |  |

[0000936395-22-000053:notes:69]
(1) Reflects employee costs associated with workforce reductions during the nine months ended July 31, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000053:notes:70]
[same as prior period, unchanged from 0000936395-22-000045:notes:67]

[0000936395-22-000053:notes:71]
In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions. On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia immediately. As a result, Ciena recorded impairment charges of approximately $4.1 million of which $2.0 million was a provision for credit losses.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-22-000053:notes:72]
[same as prior period, unchanged from 0000936395-22-000045:notes:69]

[0000936395-22-000053:notes:73]
|  | Quarter Ended | Nine Months Ended |  |
|  | July 30 |  | July 31 | July 30 |  | July 31 |  |
|  | 2022 |  | 2021 | 2022 |  | 2021 |  |
| Interest income | $ | 2,774 |  |  | $ | 465 |  | $ | 4,962 |  |  | $ | 1,553 |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (985) |  |  | (4,414) |  | (2,911) |  |  | 5,295 |  |  |
| Foreign currency exchange gains (losses) | (788) |  |  | 4,959 |  | 2,711 |  |  | (8,534) |  |  |
| Unrealized gain on cost method equity investment | — |  |  | — |  | 4,120 |  |  | — |  |  |
| Other | (635) |  |  | (215) |  | (4,022) |  |  | 86 |  |  |
| Interest and other income (loss), net | $ | 366 |  |  | $ | 795 |  | $ | 4,860 |  |  | $ | (1,600) |  |  |

[0000936395-22-000053:notes:74]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $2.7 million in foreign currency exchange rate gains for the first nine months of fiscal 2022 and during the first nine months of fiscal 2021, Ciena recorded $8.5 million in foreign currency exchange rate losses, both as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first nine months of fiscal 2022, Ciena recorded losses of $2.9 million and during the first nine months of fiscal 2021, Ciena recorded gains of $5.3 million from non-hedge designated foreign currency forward contracts. During the first nine months of fiscal 2022, Ciena recorded an unrealized gain of $4.1 million on its cost method equity investment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-22-000053:notes:75]
INCOME TAXES
The effective tax rate for the quarter and nine months ended July 30, 2022 was higher than the effective tax rate for the quarter and nine months ended July 31, 2021, primarily due to the tax benefit associated with recording a deferred tax asset in the third quarter of fiscal 2021.

[0000936395-22-000053:notes:76]
To accommodate the requirements of a global business, Ciena is reorganizing its global supply chain and distribution structure, which has included a legal entity reorganization and related system upgrade. During the third quarter of fiscal 2021, Ciena completed an internal transfer of certain of its non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $124.2 million deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in Ciena’s effective tax rate for the quarter and nine months ended July 31, 2021, which had a significant, one-time impact on its net income for these periods.

[0000936395-22-000053:notes:77]
[same as prior period, unchanged from 0000936395-22-000045:notes:74]

[0000936395-22-000053:notes:78]
[same as prior period, unchanged from 0000936395-22-000045:notes:75]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-22-000053:notes:79]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-22-000053:notes:80]
|  | July 30, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 361,659 |  |  | $ | 11 |  |  | $ | (2,945) |  |  | $ | 358,725 |  |
| Corporate debt securities | 33,969 |  |  | 5 |  |  | (100) |  |  | 33,874 |  |
| Time deposits | 121,913 |  |  | 1 |  |  | (26) |  |  | 121,888 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |
| Included in cash equivalents | $ | 114,941 |  |  | $ | — |  |  | $ | — |  |  | $ | 114,941 |  |
| Included in short-term investments | 322,820 |  |  | 14 |  |  | (1,011) |  |  | 321,823 |  |
| Included in long-term investments | 79,780 |  |  | 3 |  |  | (2,060) |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 17 |  |  | $ | (3,071) |  |  | $ | 514,487 |  |

[0000936395-22-000053:notes:81]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |

[0000936395-22-000053:notes:82]
The following table summarizes the final legal maturities of debt investments as of July 30, 2022 (in thousands):

[0000936395-22-000053:notes:83]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 437,761 |  |  | $ | 436,764 |  |
| Due in 1-2 years | 79,780 |  |  | 77,723 |  |
|  | $ | 517,541 |  |  | $ | 514,487 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-22-000053:notes:84]
FAIR VALUE MEASUREMENTS    As of each date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-22-000053:notes:85]
|  | July 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 531,686 |  |  | $ | — |  |  | $ | — |  |  | $ | 531,686 |  |
| Bond mutual fund | 70,717 |  |  | — |  |  | — |  |  | 70,717 |  |
| Time deposits | 121,888 |  |  | — |  |  | — |  |  | 121,888 |  |
| Deferred compensation plan assets | 13,184 |  |  | — |  |  | — |  |  | 13,184 |  |
| U.S. government obligations | — |  |  | 358,725 |  |  | — |  |  | 358,725 |  |
| Corporate debt securities | — |  |  | 33,874 |  |  | — |  |  | 33,874 |  |
| Foreign currency forward contracts | — |  |  | 3,024 |  |  | — |  |  | 3,024 |  |
| Forward starting interest rate swaps | — |  |  | 759 |  |  | — |  |  | 759 |  |
| Total assets measured at fair value | $ | 737,475 |  |  | $ | 396,382 |  |  | $ | — |  |  | $ | 1,133,857 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,399 |  |  | $ | — |  |  | $ | 3,399 |  |
| Forward starting interest rate swaps | — |  |  | 4,337 |  |  | — |  |  | 4,337 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,736 |  |  | $ | — |  |  | $ | 7,736 |  |

[0000936395-22-000053:notes:86]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,120,851 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,120,851 |  |
| Bond mutual fund | 75,425 |  |  | — |  |  | — |  |  | 75,425 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
| Deferred compensation plan assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| U.S. government obligations | — |  |  | 251,521 |  |  | — |  |  | 251,521 |  |
| Foreign currency forward contracts | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Total assets measured at fair value | $ | 1,280,470 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,546,926 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Forward starting interest rate swaps | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000053:notes:87]
As of each date indicated, the assets and liabilities above are presented on Ciena’s Condensed Consolidated Balance Sheets as follows (in thousands):

[0000936395-22-000053:notes:88]
|  | July 30, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 717,344 |  |  | $ | — |  |  | $ | — |  |  | $ | 717,344 |  |
| Short-term investments | 6,947 |  |  | 314,876 |  |  | — |  |  | 321,823 |  |
| Prepaid expenses and other | — |  |  | 3,024 |  |  | — |  |  | 3,024 |  |
| Long-term investments | — |  |  | 77,723 |  |  | — |  |  | 77,723 |  |
| Other long-term assets | 13,184 |  |  | 759 |  |  | — |  |  | 13,943 |  |
| Total assets measured at fair value | $ | 737,475 |  |  | $ | 396,382 |  |  | $ | — |  |  | $ | 1,133,857 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 3,399 |  |  | $ | — |  |  | $ | 3,399 |  |
| Other long-term obligations | — |  |  | 4,337 |  |  | — |  |  | 4,337 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,736 |  |  | $ | — |  |  | $ | 7,736 |  |

[0000936395-22-000053:notes:89]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,267,502 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,267,502 |  |
| Short-term investments | — |  |  | 181,483 |  |  | — |  |  | 181,483 |  |
| Prepaid expenses and other | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Long-term investments | — |  |  | 70,038 |  |  | — |  |  | 70,038 |  |
| Other long-term assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| Total assets measured at fair value | $ | 1,280,470 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,546,926 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Other long-term obligations | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000053:notes:90]
[same as prior period, unchanged from 0000936395-22-000045:notes:87]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-22-000053:notes:91]
[same as prior period, unchanged from 0000936395-22-000045:notes:88]

[0000936395-22-000053:notes:92]
|  | July 30,2022 |  | October 30,2021 |
| Raw materials | $ | 621,849 |  |  | $ | 175,399 |  |
| Work-in-process | 19,462 |  |  | 10,260 |  |
| Finished goods | 187,008 |  |  | 180,800 |  |
| Deferred cost of goods sold | 33,800 |  |  | 44,765 |  |
| Gross inventories | 862,119 |  |  | 411,224 |  |
| Reserve for inventory excess and obsolescence | (35,446) |  |  | (36,959) |  |
| Inventories, net | $ | 826,673 |  |  | $ | 374,265 |  |

[0000936395-22-000053:notes:93]
Ciena has been expanding its manufacturing capacity and accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly when supply constraints ease for certain common components, including integrated circuit components, for which delivery continues to be delayed. The increase in raw materials inventory is related to these steps to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts. Ciena writes down its inventory for estimated obsolescence 
or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first nine months of fiscal 2022, Ciena recorded a provision for inventory excess and obsolescence of $12.0 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to the sale of previously reserved items and disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-22-000053:notes:94]
[same as prior period, unchanged from 0000936395-22-000045:notes:91]

[0000936395-22-000053:notes:95]
|  | July 30,2022 |  | October 30,2021 |
| Contract assets for unbilled accounts receivable, net | $ | 157,448 |  |  | $ | 101,355 |  |
| Prepaid VAT and other taxes | 71,140 |  |  | 77,388 |  |
| Prepaid expenses | 64,498 |  |  | 62,189 |  |
| Product demonstration equipment, net | 35,722 |  |  | 29,362 |  |
| Capitalized contract acquisition costs | 30,425 |  |  | 21,753 |  |
| Other non-trade receivables | 14,878 |  |  | 18,408 |  |
| Derivative assets | 3,024 |  |  | 14,935 |  |
| Deferred deployment expense | 574 |  |  | 264 |  |
|  | $ | 377,709 |  |  | $ | 325,654 |  |

[0000936395-22-000053:notes:96]
Depreciation of product demonstration equipment was $6.8 million during the first nine months of fiscal 2022 and $7.6 million during the first nine months of fiscal 2021.

[0000936395-22-000053:notes:97]
[same as prior period, unchanged from 0000936395-22-000045:notes:94]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-22-000053:notes:98]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-22-000053:notes:99]
|  | July 30, 2022 |  | October 30, 2021 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 428,218 |  |  | $ | (382,090) |  |  | $ | 46,128 |  |  | $ | 395,726 |  |  | $ | (359,828) |  |  | $ | 35,898 |  |
| Patents and licenses | 7,815 |  |  | (3,991) |  |  | 3,824 |  |  | 7,815 |  |  | (3,321) |  |  | 4,494 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 390,822 |  |  | (363,856) |  |  | 26,966 |  |  | 375,329 |  |  | (350,407) |  |  | 24,922 |  |
| Total intangible assets | $ | 826,855 |  |  | $ | (749,937) |  |  | $ | 76,918 |  |  | $ | 778,870 |  |  | $ | (713,556) |  |  | $ | 65,314 |  |

[0000936395-22-000053:notes:100]
The aggregate amortization expense of intangible assets was $36.5 million during the first nine months of fiscal 2022 and $27.3 million during the first nine months of fiscal 2021. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-22-000053:notes:101]
| Fiscal Year | Amount |  |
| 2022 (remaining three months) | $ | 7,757 |  |  |
| 2023 | 28,821 |  |  |
| 2024 | 19,187 |  |  |
| 2025 | 13,323 |  |  |
| 2026 | 7,105 |  |  |
| Thereafter | 725 |  |  |
|  | $ | 76,918 |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-22-000053:notes:102]
[same as prior period, unchanged from 0000936395-22-000045:notes:99]

[0000936395-22-000053:notes:103]
|  | July 30,2022 |  | October 30,2021 |
| Compensation, payroll related tax and benefits (1) | $ | 98,174 |  |  | $ | 201,119 |  |
| Warranty | 45,689 |  |  | 48,019 |  |
| Vacation | 27,721 |  |  | 31,200 |  |
| Interest payable | 9,386 |  |  | 598 |  |
| Income taxes payable | 4,830 |  |  | 13,577 |  |
| Finance lease liabilities | 3,923 |  |  | 3,620 |  |
| Foreign currency forward contracts | 3,399 |  |  | 716 |  |
| Other | 108,467 |  |  | 110,436 |  |
|  | $ | 301,589 |  |  | $ | 409,285 |  |

[0000936395-22-000053:notes:104]
(1) Reduction is primarily due to bonus payments to employees under Ciena’s 2021 annual cash incentive compensation plan in the first quarter of fiscal 2022, and a lower accrual rate related to Ciena’s 2022 annual cash incentive compensation plan.

[0000936395-22-000053:notes:105]
[same as prior period, unchanged from 0000936395-22-000045:notes:102]

[0000936395-22-000053:notes:106]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Nine Months Ended July 31, 2021 |  | $ | 49,868 |  |  |  |  | 12,726 |  |  | (14,455) |  |  | $ | 48,139 |  |
| Nine Months Ended July 30, 2022 |  | $ | 48,019 |  |  |  |  | 12,416 |  |  | (14,746) |  |  | $ | 45,689 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-22-000053:notes:107]
[same as prior period, unchanged from 0000936395-22-000045:notes:104]

[0000936395-22-000053:notes:108]
[same as prior period, unchanged from 0000936395-22-000045:notes:105]

[0000936395-22-000053:notes:109]
As of July 30, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability that is principally related to research and development activities. The notional amount of these contracts was approximately $238.8 million and $288.6 million as of July 30, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-22-000053:notes:110]
As of July 30, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $111.7 million and $296.1 million as of July 30, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-22-000053:notes:111]
[same as prior period, unchanged from 0000936395-22-000045:notes:108]

[0000936395-22-000053:notes:112]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of July 30, 2022 and October 30, 2021.

[0000936395-22-000053:notes:113]
In April 2022, Ciena entered into floating to fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the Secured Overnight Funding Rate (“SOFR”) for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350.0 million as of July 30, 2022. Ciena entered into the forward starting swaps to hedge its anticipated SOFR rate risk from the 2025 Term Loan because the LIBOR rate is expected to be discontinued in 2023.

[0000936395-22-000053:notes:114]
[same as prior period, unchanged from 0000936395-22-000045:notes:111]

[0000936395-22-000053:notes:115]
[same as prior period, unchanged from 0000936395-22-000045:notes:112]


## us-gaap:DebtDisclosureTextBlock

[0000936395-22-000053:notes:116]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-22-000053:notes:117]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-22-000053:notes:118]
The net carrying value of the 2025 Term Loan was comprised of the following for the periods indicated (in thousands):

[0000936395-22-000053:notes:119]
|  |  | July 30, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 677,407 |  |  | $ | (1,008) |  |  | $ | (1,887) |  |  | $ | 674,512 |  |  | $ | 677,285 |  |

[0000936395-22-000053:notes:120]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.9 million as of July 30, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-22-000053:notes:121]
As of July 30, 2022, the estimated fair value of the 2025 Term Loan was $674.1 million. The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-22-000053:notes:122]
2030 Notes

[0000936395-22-000053:notes:123]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-22-000053:notes:124]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”).

[0000936395-22-000053:notes:125]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. Ciena intends to use the net proceeds from the Offering for general corporate purposes.

[0000936395-22-000053:notes:126]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

[0000936395-22-000053:notes:127]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

[0000936395-22-000053:notes:128]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

[0000936395-22-000053:notes:129]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

[0000936395-22-000053:notes:130]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a redemption price equal to 102% of the principal amount of the notes to be redeemed, plus any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

[0000936395-22-000053:notes:131]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0000936395-22-000053:notes:132]
|  |  | July 30, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,129) |  |  | $ | 394,871 |  |  |  |

[0000936395-22-000053:notes:133]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.1 million as of July 30, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.4 million during the first nine months of fiscal 2022.

[0000936395-22-000053:notes:134]
As of July 30, 2022, the estimated fair value of the 2030 Notes was $368.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-22-000053:notes:135]
ACCUMULATED OTHER COMPREHENSIVE INCOMEThe following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended July 30, 2022 (in thousands):

[0000936395-22-000053:notes:136]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (2,184) |  |  | (5,207) |  |  | 2,786 |  |  | (22,783) |  |  | (27,388) |  |
| Amounts reclassified from AOCI | — |  |  | (1,569) |  |  | 6,639 |  |  | — |  |  | 5,070 |  |
| Balance at July 30, 2022 | $ | (2,348) |  |  | $ | (560) |  |  | $ | (2,754) |  |  | $ | (16,217) |  |  | $ | (21,879) |  |

[0000936395-22-000053:notes:137]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended July 31, 2021 (in thousands):

[0000936395-22-000053:notes:138]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications | (28) |  |  | 13,574 |  |  | (1,399) |  |  | 19,439 |  |  | 31,586 |  |
| Amounts reclassified from AOCI | — |  |  | (7,907) |  |  | 7,049 |  |  | — |  |  | (858) |  |
| Balance at July 31, 2021 | $ | 17 |  |  | $ | 5,448 |  |  | $ | (15,885) |  |  | $ | 5,790 |  |  | $ | (4,630) |  |

[0000936395-22-000053:notes:139]
[same as prior period, unchanged from 0000936395-22-000045:notes:137]


## us-gaap:EarningsPerShareTextBlock

[0000936395-22-000053:notes:140]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-22-000053:notes:141]
[same as prior period, unchanged from 0000936395-22-000045:notes:139]

[0000936395-22-000053:notes:142]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Net income | $ | 10,512 |  |  | $ | 238,232 |  |  | $ | 95,257 |  |  | $ | 396,697 |  |
| Basic weighted average shares outstanding | 149,862 |  |  | 155,271 |  |  | 152,083 |  |  | 155,277 |  |
| Effect of dilutive potential common shares | 601 |  |  | 1,473 |  |  | 1,126 |  |  | 1,465 |  |
| Diluted weighted average shares | 150,463 |  |  | 156,744 |  |  | 153,209 |  |  | 156,742 |  |
| Basic EPS | $ | 0.07 |  |  | $ | 1.53 |  |  | $ | 0.63 |  |  | $ | 2.55 |  |
| Diluted EPS | $ | 0.07 |  |  | $ | 1.52 |  |  | $ | 0.62 |  |  | $ | 2.53 |  |
| Antidilutive employee share-based awards, excluded | 1,640 |  |  | 131 |  |  | 1,264 |  |  | 99 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-22-000053:notes:143]
STOCKHOLDERS’ EQUITYStock Repurchase Program and Accelerated Share Repurchase Agreement
On December 9, 2021, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received approximately 3.6 million shares of its common stock from Goldman, calculated based on the average of the volume-weighted average prices of Ciena’s common stock of $69.78 for the period from December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt.

[0000936395-22-000053:notes:144]
During the first nine months of fiscal 2022, Ciena repurchased an additional 4.7 million shares of its common stock, for an aggregate purchase price of $242.0 million at an average price of $51.50 per share. As of July 30, 2022, Ciena has repurchased an aggregate of 8.3 million shares for an aggregate purchase price of $492.0 million at an average price of $59.42 per share and has an aggregate of $508.0 million of authorized funds remaining under its stock repurchase program. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-22-000053:notes:145]
[same as prior period, unchanged from 0000936395-22-000045:notes:144]

[0000936395-22-000053:notes:146]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $41.3 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2022 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-22-000053:notes:147]
SHARE-BASED COMPENSATION EXPENSE
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-22-000053:notes:148]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Products | $ | 1,002 |  |  | $ | 1,037 |  |  | $ | 2,960 |  |  | $ | 2,488 |  |
| Services | 1,940 |  |  | 1,315 |  |  | 5,467 |  |  | 3,941 |  |
| Share-based compensation expense included in cost of goods sold | 2,942 |  |  | 2,352 |  |  | 8,427 |  |  | 6,429 |  |
| Research and development | 8,233 |  |  | 5,541 |  |  | 23,372 |  |  | 16,179 |  |
| Selling and marketing | 8,075 |  |  | 6,534 |  |  | 23,196 |  |  | 18,960 |  |
| General and administrative | 7,579 |  |  | 8,237 |  |  | 22,825 |  |  | 21,338 |  |
| Share-based compensation expense included in operating expense | 23,887 |  |  | 20,312 |  |  | 69,393 |  |  | 56,477 |  |
| Share-based compensation expense capitalized in inventory, net | 28 |  |  | (193) |  |  | 7 |  |  | 64 |  |
| Total share-based compensation expense | $ | 26,857 |  |  | $ | 22,471 |  |  | $ | 77,827 |  |  | $ | 62,970 |  |

[0000936395-22-000053:notes:149]
As of July 30, 2022, total unrecognized share-based compensation expense was approximately $201.3 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.57 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-22-000053:notes:150]
[same as prior period, unchanged from 0000936395-22-000045:notes:149]

[0000936395-22-000053:notes:151]
[same as prior period, unchanged from 0000936395-22-000045:notes:150]

[0000936395-22-000053:notes:152]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 30, 2022, equipment, building, furniture and fixtures, net, totaled $281.7 million, and operating ROU assets totaled $45.5 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of July 30, 2022, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-22-000053:notes:153]
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 41,434 |  |  | $ | — |  |  | $ | 35,484 |  |  | $ | — |  |  | $ | 76,918 |  |
| Goodwill | $ | 83,738 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 328,978 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 45,853 |  |  | $ | 45,853 |  |

[0000936395-22-000053:notes:154]
[same as prior period, unchanged from 0000936395-22-000045:notes:153]

[0000936395-22-000053:notes:155]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income (loss), net; interest expense; and provision (benefit) for income taxes.

[0000936395-22-000053:notes:156]
[same as prior period, unchanged from 0000936395-22-000045:notes:155]

[0000936395-22-000053:notes:157]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 30 |  | July 31 |  | July 30 |  | July 31 |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 108,282 |  |  | $ | 244,535 |  |  | $ | 395,176 |  |  | $ | 612,378 |  |
| Platform Software and Services | 39,646 |  |  | 31,526 |  |  | 132,698 |  |  | 95,692 |  |
| Blue Planet Automation Software and Services | (10,139) |  |  | (3,243) |  |  | (17,693) |  |  | 11 |  |
| Global Services | 52,965 |  |  | 55,507 |  |  | 158,808 |  |  | 147,567 |  |
| Total segment profit | 190,754 |  |  | 328,325 |  |  | 668,989 |  |  | 855,648 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 105,880 |  |  | 114,924 |  |  | 344,700 |  |  | 322,589 |  |
| General and administrative | 41,121 |  |  | 48,863 |  |  | 131,191 |  |  | 132,491 |  |
| Significant asset impairments and restructuring costs | 7,692 |  |  | 9,789 |  |  | 20,203 |  |  | 23,865 |  |
| Amortization of intangible assets | 8,919 |  |  | 5,967 |  |  | 26,757 |  |  | 17,896 |  |
| Acquisition and integration costs | 35 |  |  | 259 |  |  | 598 |  |  | 860 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (12,276) |  |  | (6,981) |  |  | (28,415) |  |  | (24,521) |  |
| Less: Provision (benefit) for income taxes | 4,319 |  |  | (96,690) |  |  | 21,868 |  |  | (63,271) |  |
| Net income | $ | 10,512 |  |  | $ | 238,232 |  |  | $ | 95,257 |  |  | $ | 396,697 |  |

[0000936395-22-000053:notes:158]
[same as prior period, unchanged from 0000936395-22-000045:notes:157]

[0000936395-22-000053:notes:159]
[same as prior period, unchanged from 0000936395-22-000045:notes:158]

[0000936395-22-000053:notes:160]
|  | July 30,2022 |  | October 30,2021 |
| Canada | $ | 238,288 |  |  | $ | 240,968 |  |
| United States | 51,333 |  |  | 50,744 |  |
| Other International | 37,521 |  |  | 37,541 |  |
| Total | $ | 327,142 |  |  | $ | 329,253 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-22-000053:notes:161]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-22-000053:notes:162]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-22-000053:notes:163]
Litigation

[0000936395-22-000053:notes:164]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-22-000053:notes:165]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-22-000053:notes:166]
From the end of the third quarter of fiscal 2022 through September 2, 2022, Ciena repurchased an additional 154,247 shares of its common stock, for an aggregate purchase price of $8.0 million at an average price of $51.91 per share, inclusive of repurchases pending settlement. As of September 2, 2022, Ciena has repurchased an aggregate of 8,433,957 shares and has $500.0 million of authorized funds remaining under its stock repurchase program.
