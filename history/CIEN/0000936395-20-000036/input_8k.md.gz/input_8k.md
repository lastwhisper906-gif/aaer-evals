# CIEN 8-K — 0000936395-20-000033 filed 2020-09-03

## item codes, every 8-K on or before 2020-09-09

- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2020-09-09

- none on or before 2020-09-09

## item 2.02 — earnings release, exhibit 99.1

[0000936395-20-000033:8k_2_02:1]
EX-99.1
2
ex991-2020q3earningspr.htm
EX-99.1

[0000936395-20-000033:8k_2_02:2]
Document

[0000936395-20-000033:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-20-000033:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2020 Financial Results

[0000936395-20-000033:8k_2_02:5]
HANOVER, Md. - September 3, 2020 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal third quarter ended August 1, 2020.

[0000936395-20-000033:8k_2_02:6]
Q3 Revenue: $976.7 million, increasing 1.7% year over year

[0000936395-20-000033:8k_2_02:7]
Q3 Net Income per Share: $0.91 GAAP; $1.06 adjusted (non-GAAP), increasing 49% year over year

[0000936395-20-000033:8k_2_02:8]
"We delivered outstanding financial results in the third quarter, reflecting our continued innovation, market leadership and strong competitive position in an uncertain macro environment,“ said Gary Smith, President and CEO, Ciena. “Although COVID-related market dynamics have resulted in an orders slowdown and are likely to adversely impact our revenue for a few quarters, we are confident in our ability to continue executing on our strategy and expanding our market leadership."

[0000936395-20-000033:8k_2_02:9]
For the fiscal third quarter 2020, Ciena reported revenue of $976.7 million as compared to $960.6 million for the fiscal third quarter 2019.

[0000936395-20-000033:8k_2_02:10]
Ciena's GAAP net income for the fiscal third quarter 2020 was $142.3 million, or $0.91 per diluted common share, which compares to a GAAP net income of $86.7 million, or $0.55 per diluted common share, for the fiscal third quarter 2019.

[0000936395-20-000033:8k_2_02:11]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2020 was $166.4 million, or $1.06 per diluted common share, which compares to an adjusted (non-GAAP) net income of $112.3 million, or $0.71 per diluted common share, for the fiscal third quarter 2019.

[0000936395-20-000033:8k_2_02:12]
Fiscal Third Quarter 2020 Performance Summary

[0000936395-20-000033:8k_2_02:13]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-20-000033:8k_2_02:14]
|  |  | GAAP Results |  |  |  |  |
|  |  | Q3 |  | Q3 |  |  |
|  |  | FY 2020 |  | FY 2019 |  | Y-T-Y* |
| Revenue |  | $ | 976.7 |  |  | $ | 960.6 |  |  | 1.7 | % |
| Gross margin |  | 47.6 | % |  | 44.2 | % |  | 3.4 | % |
| Operating expense |  | $ | 276.6 |  |  | $ | 299.1 |  |  | (7.5) | % |
| Operating margin |  | 19.3 | % |  | 13.0 | % |  | 6.3 | % |

[0000936395-20-000033:8k_2_02:15]
|  |  | Non-GAAP Results |  |  |  |  |
|  |  | Q3 |  | Q3 |  |  |
|  |  | FY 2020 |  | FY 2019 |  | Y-T-Y* |
| Revenue |  | $ | 976.7 |  |  | $ | 960.6 |  |  | 1.7 | % |
| Adj. gross margin |  | 48.2 | % |  | 44.7 | % |  | 3.5 | % |
| Adj. operating expense |  | $ | 251.2 |  |  | $ | 273.2 |  |  | (8.1) | % |
| Adj. operating margin |  | 22.4 | % |  | 16.2 | % |  | 6.2 | % |
| Adj. EBITDA |  | $ | 241.1 |  |  | $ | 178.0 |  |  | 35.4 | % |

[0000936395-20-000033:8k_2_02:16]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-20-000033:8k_2_02:17]
|  |  | Revenue by Segment |  |  |  |  |  |  |
|  |  | Q3 FY 2020 |  |  |  | Q3 FY 2019 |  |  |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 722.5 |  |  | 74.0 |  |  | $ | 724.3 |  |  | 75.4 |  |
| Packet Networking |  | 79.8 |  |  | 8.1 |  |  | 71.8 |  |  | 7.5 |  |
| Total Networking Platforms |  | 802.3 |  |  | 82.1 |  |  | 796.1 |  |  | 82.9 |  |
| Platform Software and Services |  | 46.4 |  |  | 4.8 |  |  | 37.3 |  |  | 3.9 |  |
| Blue Planet Automation Software and Services |  | 11.3 |  |  | 1.1 |  |  | 10.5 |  |  | 1.1 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 69.1 |  |  | 7.1 |  |  | 65.9 |  |  | 6.9 |  |
| Installation and Deployment |  | 39.8 |  |  | 4.1 |  |  | 39.8 |  |  | 4.1 |  |
| Consulting and Network Design |  | 7.8 |  |  | 0.8 |  |  | 11.0 |  |  | 1.1 |  |
| Total Global Services |  | 116.7 |  |  | 12.0 |  |  | 116.7 |  |  | 12.1 |  |
| Total |  | $ | 976.7 |  |  | 100.0 |  |  | $ | 960.6 |  |  | 100.0 |  |

[0000936395-20-000033:8k_2_02:18]
**  Denotes %  of total revenue

[0000936395-20-000033:8k_2_02:19]
Additional Performance Metrics for Fiscal Third Quarter 2020

[0000936395-20-000033:8k_2_02:20]
|  |  | Revenue by Geographic Region |  |  |  |  |  |  |
|  |  | Q3 FY 2020 |  |  |  | Q3 FY 2019 |  |  |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 713.3 |  |  | 73.0 |  |  | $ | 656.3 |  |  | 68.3 |  |
| Europe, Middle East and Africa |  | 162.5 |  |  | 16.6 |  |  | 169.5 |  |  | 17.6 |  |
| Asia Pacific |  | 100.9 |  |  | 10.4 |  |  | 134.8 |  |  | 14.1 |  |
| Total |  | $ | 976.7 |  |  | 100.0 |  |  | $ | 960.6 |  |  | 100.0 |  |

[0000936395-20-000033:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-20-000033:8k_2_02:22]
•One 10%-plus customer represented a total of 12% of revenue

[0000936395-20-000033:8k_2_02:23]
•Cash and investments totaled $1,164.2 million

[0000936395-20-000033:8k_2_02:24]
•Cash flow from operations totaled $175.4 million

[0000936395-20-000033:8k_2_02:25]
•Average days' sales outstanding (DSOs) were 75

[0000936395-20-000033:8k_2_02:26]
•Accounts receivable balance was $715.2 million

[0000936395-20-000033:8k_2_02:27]
•Unbilled contract asset balance was $97.4 million

[0000936395-20-000033:8k_2_02:28]
•Inventories totaled $363.6 million, including:

[0000936395-20-000033:8k_2_02:29]
◦Raw materials: $133.6 million

[0000936395-20-000033:8k_2_02:30]
◦Work in process: $12.6 million

[0000936395-20-000033:8k_2_02:31]
◦Finished goods: $215.3 million

[0000936395-20-000033:8k_2_02:32]
◦Deferred cost of sales: $45.1 million

[0000936395-20-000033:8k_2_02:33]
◦Reserve for excess and obsolescence: $(43.0) million

[0000936395-20-000033:8k_2_02:34]
•Product inventory turns were 4.8

[0000936395-20-000033:8k_2_02:35]
•Headcount totaled 6,934

[0000936395-20-000033:8k_2_02:36]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2020 Results

[0000936395-20-000033:8k_2_02:37]
Today, Thursday, September 3, 2020, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website an accompanying investor presentation for its unaudited fiscal third quarter 2020 results.

[0000936395-20-000033:8k_2_02:38]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-20-000033:8k_2_02:39]
Notes to Investors

[0000936395-20-000033:8k_2_02:40]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered outstanding financial results in the third quarter, reflecting our continued innovation, market leadership and strong competitive position in an uncertain macro environment. Although COVID-related market dynamics have resulted in an orders slowdown and are likely to adversely impact our revenue for a few quarters, we are confident in our ability to continue executing on our strategy and expanding our market leadership."

[0000936395-20-000033:8k_2_02:41]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency

[0000936395-20-000033:8k_2_02:42]
exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies, including the COVID-19 pandemic; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise; and the other risk factors disclosed in its Annual Report on Form 10-K filed with the SEC on December 20, 2019 and included in its Quarterly Report on Form 10-Q for the current quarter. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-20-000033:8k_2_02:43]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-20-000033:8k_2_02:44]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-20-000033:8k_2_02:45]
CIENA CORPORATION

[0000936395-20-000033:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-20-000033:8k_2_02:47]
(in thousands, except per share data)

[0000936395-20-000033:8k_2_02:48]
(unaudited)

[0000936395-20-000033:8k_2_02:49]
|  | Quarter Ended |  |  |  | Nine Months Ended |  |  |
|  | August 1, |  | August 3, |  | August 1, |  | August 3, |
|  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 819,022 |  |  | $ | 810,588 |  |  | $ | 2,246,129 |  |  | $ | 2,163,808 |  |
| Services | 157,690 |  |  | 150,018 |  |  | 457,548 |  |  | 440,336 |  |
| Total revenue | 976,712 |  |  | 960,606 |  |  | 2,703,677 |  |  | 2,604,144 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 436,227 |  |  | 454,921 |  |  | 1,230,378 |  |  | 1,246,413 |  |
| Services | 75,804 |  |  | 81,333 |  |  | 224,757 |  |  | 235,361 |  |
| Total cost of goods sold | 512,031 |  |  | 536,254 |  |  | 1,455,135 |  |  | 1,481,774 |  |
| Gross profit | 464,681 |  |  | 424,352 |  |  | 1,248,542 |  |  | 1,122,370 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 130,221 |  |  | 139,880 |  |  | 392,651 |  |  | 406,482 |  |
| Selling and marketing | 94,763 |  |  | 104,230 |  |  | 303,043 |  |  | 305,845 |  |
| General and administrative | 41,635 |  |  | 42,695 |  |  | 126,133 |  |  | 124,092 |  |
| Amortization of intangible assets | 5,840 |  |  | 5,529 |  |  | 17,532 |  |  | 16,586 |  |
| Significant asset impairments and restructuring costs | 6,515 |  |  | 5,355 |  |  | 14,798 |  |  | 11,696 |  |
| Acquisition and integration costs (recoveries) | (2,329) |  |  | 1,362 |  |  | 904 |  |  | 4,105 |  |
| Total operating expenses | 276,645 |  |  | 299,051 |  |  | 855,061 |  |  | 868,806 |  |
| Income from operations | 188,036 |  |  | 125,301 |  |  | 393,481 |  |  | 253,564 |  |
| Interest and other income, net | 232 |  |  | 1,050 |  |  | 1,213 |  |  | 5,059 |  |
| Interest expense | (7,251) |  |  | (9,404) |  |  | (23,926) |  |  | (28,316) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (646) |  |  | — |  |
| Income before income taxes | 181,017 |  |  | 116,947 |  |  | 370,122 |  |  | 230,307 |  |
| Provision for income taxes | 38,750 |  |  | 30,198 |  |  | 73,872 |  |  | 57,204 |  |
| Net income | $ | 142,267 |  |  | $ | 86,749 |  |  | $ | 296,250 |  |  | $ | 173,103 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.92 |  |  | $ | 0.56 |  |  | $ | 1.92 |  |  | $ | 1.11 |  |
| Diluted net income per potential common share | $ | 0.91 |  |  | $ | 0.55 |  |  | $ | 1.90 |  |  | $ | 1.10 |  |
| Weighted average basic common shares outstanding | 154,184 |  |  | 155,488 |  |  | 154,136 |  |  | 156,013 |  |
| Weighted average dilutive potential common shares outstanding 1 | 156,318 |  |  | 157,455 |  |  | 155,741 |  |  | 157,949 |  |

[0000936395-20-000033:8k_2_02:50]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2020 includes 2.1 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:51]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2020 includes 1.6 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:52]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2019 includes 2.0 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:53]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:54]
CIENA CORPORATION

[0000936395-20-000033:8k_2_02:55]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-20-000033:8k_2_02:56]
(in thousands, except share data)

[0000936395-20-000033:8k_2_02:57]
(unaudited)

[0000936395-20-000033:8k_2_02:58]
|  | August 1,2020 |  | November 2,2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,093,749 |  |  | $ | 904,045 |  |
| Short-term investments | 70,404 |  |  | 109,940 |  |
| Accounts receivable, net | 715,195 |  |  | 724,854 |  |
| Inventories | 363,600 |  |  | 345,049 |  |
| Prepaid expenses and other | 324,935 |  |  | 297,914 |  |
| Total current assets | 2,567,883 |  |  | 2,381,802 |  |
| Long-term investments | — |  |  | 10,014 |  |
| Equipment, building, furniture and fixtures, net | 266,996 |  |  | 286,884 |  |
| Operating lease right-of-use assets | 48,573 |  |  | — |  |
| Goodwill | 310,772 |  |  | 297,937 |  |
| Other intangible assets, net | 106,182 |  |  | 112,781 |  |
| Deferred tax asset, net | 655,320 |  |  | 714,942 |  |
| Other long-term assets | 99,462 |  |  | 88,986 |  |
| Total assets | $ | 4,055,188 |  |  | $ | 3,893,346 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 297,163 |  |  | $ | 344,819 |  |
| Accrued liabilities and other short-term obligations | 301,030 |  |  | 382,740 |  |
| Deferred revenue | 95,951 |  |  | 111,381 |  |
| Operating lease liabilities | 19,417 |  |  | — |  |
| Current portion of long-term debt | 6,930 |  |  | 7,000 |  |
| Total current liabilities | 720,491 |  |  | 845,940 |  |
| Long-term deferred revenue | 40,919 |  |  | 45,492 |  |
| Other long-term obligations | 134,914 |  |  | 148,747 |  |
| Long-term operating lease liabilities | 52,141 |  |  | — |  |
| Long-term debt, net | 677,856 |  |  | 680,406 |  |
| Total liabilities | $ | 1,626,321 |  |  | $ | 1,720,585 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 154,318,197and 154,403,850 shares issued and outstanding | 1,543 |  |  | 1,544 |  |
| Additional paid-in capital | 6,815,676 |  |  | 6,837,714 |  |
| Accumulated other comprehensive loss | (40,189) |  |  | (22,084) |  |
| Accumulated deficit | (4,348,163) |  |  | (4,644,413) |  |
| Total stockholders’ equity | 2,428,867 |  |  | 2,172,761 |  |
| Total liabilities and stockholders’ equity | $ | 4,055,188 |  |  | $ | 3,893,346 |  |

[0000936395-20-000033:8k_2_02:59]
CIENA CORPORATION

[0000936395-20-000033:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-20-000033:8k_2_02:61]
(in thousands) (unaudited)

[0000936395-20-000033:8k_2_02:62]
|  | Nine Months Ended |  |  |
|  | August 1, |  | August 3, |
|  | 2020 |  | 2019 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 296,250 |  |  | $ | 173,103 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 70,370 |  |  | 65,071 |  |
| Share-based compensation costs | 50,838 |  |  | 44,446 |  |
| Amortization of intangible assets | 29,035 |  |  | 26,610 |  |
| Deferred taxes | 57,636 |  |  | 35,949 |  |
| Provision for inventory excess and obsolescence | 20,176 |  |  | 18,833 |  |
| Provision for warranty | 19,172 |  |  | 15,933 |  |
| Other | 15,085 |  |  | 743 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (6,688) |  |  | (2,517) |  |
| Inventories | (39,568) |  |  | (115,427) |  |
| Prepaid expenses and other | (52,945) |  |  | (85,039) |  |
| Operating lease right-of-use assets | 12,816 |  |  | — |  |
| Accounts payable, accruals and other obligations | (131,647) |  |  | (9,005) |  |
| Deferred revenue | (19,039) |  |  | 4,427 |  |
| Short and long-term operating lease liabilities | (15,132) |  |  | — |  |
| Net cash provided by operating activities | 306,359 |  |  | 173,127 |  |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (61,333) |  |  | (49,063) |  |
| Purchase of available for sale securities | (39,859) |  |  | (127,601) |  |
| Proceeds from maturities of available for sale securities | 90,000 |  |  | 120,000 |  |
| Proceeds from sales of available for sale securities | — |  |  | 98,263 |  |
| Settlement of foreign currency forward contracts, net | 3,067 |  |  | (3,155) |  |
| Acquisition of business, net of cash acquired | (28,300) |  |  | — |  |
| Purchase of equity investment | — |  |  | (2,667) |  |
| Net cash provided by (used in) investing activities | (36,425) |  |  | 35,777 |  |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (3,465) |  |  | (5,250) |  |
| Payment of debt issuance costs | (382) |  |  | — |  |
| Payment of finance lease obligations | (2,030) |  |  | (2,599) |  |
| Payment for debt conversion liability | — |  |  | (111,268) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (26,328) |  |  | (23,234) |  |
| Repurchases of common stock - repurchase program | (74,535) |  |  | (110,484) |  |
| Proceeds from issuance of common stock | 27,986 |  |  | 22,895 |  |
| Net cash used in financing activities | (78,754) |  |  | (229,940) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (1,526) |  |  | 392 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 189,654 |  |  | (20,644) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 904,161 |  |  | 745,434 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,093,815 |  |  | $ | 724,790 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 25,278 |  |  | $ | 29,921 |  |
| Cash paid during the period for income taxes, net | $ | 41,316 |  |  | $ | 21,573 |  |
| Operating lease payments | $ | 16,762 |  |  | $ | — |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,200 |  |  | $ | 4,328 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | — |  |  | $ | 1,441 |  |
| Conversion of debt conversion liability into 1,585,140 shares of common stock | $ | — |  |  | $ | 52,944 |  |
| Operating lease right-of-use assets subject to lease liability | $ | 11,404 |  |  | $ | — |  |

[0000936395-20-000033:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |  |  |
|  |  | Quarter Ended |  |  |
|  |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 464,681 |  |  | $ | 424,352 |  |
| Share-based compensation-products |  | 960 |  |  | 781 |  |
| Share-based compensation-services |  | 1,007 |  |  | 783 |  |
| Amortization of intangible assets |  | 3,834 |  |  | 3,303 |  |
| Total adjustments related to gross profit |  | 5,801 |  |  | 4,867 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 470,482 |  |  | $ | 429,219 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 48.2 | % |  | 44.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 276,645 |  |  | $ | 299,051 |  |
| Share-based compensation-research and development |  | 4,286 |  |  | 3,560 |  |
| Share-based compensation-sales and marketing |  | 5,180 |  |  | 4,192 |  |
| Share-based compensation-general and administrative |  | 5,940 |  |  | 5,813 |  |
| Amortization of intangible assets |  | 5,840 |  |  | 5,529 |  |
| Significant asset impairments and restructuring costs |  | 6,515 |  |  | 5,355 |  |
| Acquisition and integration costs (recoveries) |  | (2,329) |  |  | 1,362 |  |
| Total adjustments related to operating expense |  | 25,432 |  |  | 25,811 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 251,213 |  |  | $ | 273,240 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 188,036 |  |  | $ | 125,301 |  |
| Total adjustments related to gross profit |  | 5,801 |  |  | 4,867 |  |
| Total adjustments related to operating expense |  | 25,432 |  |  | 25,811 |  |
| Total adjustments related to income from operations |  | 31,233 |  |  | 30,678 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 219,269 |  |  | $ | 155,979 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 22.4 | % |  | 16.2 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 142,267 |  |  | $ | 86,749 |  |
| Exclude GAAP provision for income taxes |  | 38,750 |  |  | 30,198 |  |
| Income before income taxes |  | 181,017 |  |  | 116,947 |  |
| Total adjustments related to income from operations |  | 31,233 |  |  | 30,678 |  |
| Adjusted income before income taxes |  | 212,250 |  |  | 147,625 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 45,846 |  |  | 35,282 |  |
| Adjusted (non-GAAP) net income |  | $ | 166,404 |  |  | $ | 112,343 |  |
| Weighted average basic common shares outstanding |  | 154,184 |  | 155,488 |
| Weighted average dilutive potential common shares outstanding 1 |  | 156,318 |  | 157,455 |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.91 |  |  | $ | 0.55 |  |
| Adjusted (non-GAAP) diluted net income per common share |  | $ | 1.06 |  |  | $ | 0.71 |  |

[0000936395-20-000033:8k_2_02:64]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2020 includes 2.1 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:65]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2020 includes 1.6 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:66]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2019 includes 2.0 million shares underlying certain stock option and restricted stock unit awards.

[0000936395-20-000033:8k_2_02:67]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000033:8k_2_02:68]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |  |  |
|  |  | Quarter Ended |  |  |
|  |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 142,267 |  |  | $ | 86,749 |  |
| Add: Interest expense |  | 7,251 |  |  | 9,404 |  |
| Less: Interest and other income, net |  | 232 |  |  | 1,050 |  |
| Add: Provision for income taxes |  | 38,750 |  |  | 30,198 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 21,989 |  |  | 22,076 |  |
| Add: Amortization of intangible assets |  | 9,674 |  |  | 8,832 |  |
| EBITDA |  | $ | 219,699 |  |  | $ | 156,209 |  |
| Add: Share-based compensation cost |  | 17,259 |  |  | 15,084 |  |
| Add: Significant asset impairments and restructuring costs |  | 6,515 |  |  | 5,355 |  |
| Add: Acquisition and integration costs (recoveries) |  | (2,329) |  |  | 1,362 |  |
| Adjusted EBITDA |  | $ | 241,144 |  |  | $ | 178,010 |  |

[0000936395-20-000033:8k_2_02:69]
* * *

[0000936395-20-000033:8k_2_02:70]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-20-000033:8k_2_02:71]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-20-000033:8k_2_02:72]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-20-000033:8k_2_02:73]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities.

[0000936395-20-000033:8k_2_02:74]
•Acquisition and integration costs (recoveries) - consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of DonRiver and Centina, including costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities.

[0000936395-20-000033:8k_2_02:75]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 21.6% for the third fiscal quarter of 2020 and 23.9% for the third fiscal quarter of 2019. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
