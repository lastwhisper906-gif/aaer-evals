# CIEN MD&A — 0000936395-20-000036


## mdna

[0000936395-20-000036:mdna:1]
[same as prior period, unchanged from 0000936395-20-000028:mdna:1]

[0000936395-20-000036:mdna:2]
[same as prior period, unchanged from 0000936395-20-000028:mdna:2]

[0000936395-20-000036:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things: our competitive landscape; market conditions and growth opportunities; factors impacting our industry and markets; factors impacting the businesses of our customers and their network architectures; adoption of next-generation network technology and software programmability and automation of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including information technology (IT) transitions or initiatives; the impact of the Tax Cuts and Jobs Act and changes in our effective tax rates; market risks associated with financial instruments and foreign currency exchange rates; and future responses to and effects of the COVID-19 pandemic on our business, operations, liquidity and financial results. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-20-000036:mdna:4]
•our ability to execute our business and growth strategies;

[0000936395-20-000036:mdna:5]
•fluctuations in our revenue, gross margin and operating results and our financial results generally;

[0000936395-20-000036:mdna:6]
•the loss of our customers, including the loss of a single large customer, a significant reduction in one or more customers’ spending, or a material change in their networking or procurement strategies;

[0000936395-20-000036:mdna:7]
•the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our ability to attract and retain personnel, our business operations, liquidity and financial results;

[0000936395-20-000036:mdna:8]
•the competitive environment in which we operate;

[0000936395-20-000036:mdna:9]
•market acceptance of products and services currently under development and delays in product or software development;

[0000936395-20-000036:mdna:10]
•lengthy sales cycles and onerous contract terms with communications service providers, Web-scale providers and other large customers;

[0000936395-20-000036:mdna:11]
•product performance or security problems and undetected errors;

[0000936395-20-000036:mdna:12]
•our ability to continue to diversify our customer base beyond our traditional customers and to broaden the application for our solutions in communications networks;

[0000936395-20-000036:mdna:13]
•the level of growth in network traffic and bandwidth consumption and the corresponding level of investment in network infrastructures by network operators;

[0000936395-20-000036:mdna:14]
•the international scale of our operations;

[0000936395-20-000036:mdna:15]
•fluctuations in currency exchange rates;

[0000936395-20-000036:mdna:16]
•our ability to forecast accurately demand for our products for purposes of inventory purchase practices;

[0000936395-20-000036:mdna:17]
•the impact of pricing pressure and price compression that we regularly encounter in our markets;

[0000936395-20-000036:mdna:18]
•our ability to enforce our intellectual property rights, and costs we may incur in connection with any disputes over intellectual property rights;

[0000936395-20-000036:mdna:19]
•the continued availability, on commercially reasonable terms, of software and other technology under third-party licenses;

[0000936395-20-000036:mdna:20]
•the potential failure to maintain the security of confidential, proprietary or otherwise sensitive business information or systems or to protect against cyber attacks;

[0000936395-20-000036:mdna:21]
•the performance of our third-party contract manufacturers;

[0000936395-20-000036:mdna:22]
•changes or disruption in components or supplies provided by third parties, including sole and limited source suppliers;

[0000936395-20-000036:mdna:23]
•our ability to manage effectively our relationships with third-party service partners and distributors;

[0000936395-20-000036:mdna:24]
•unanticipated risks and additional obligations in connection with our resale of complementary products or technology of other companies;

[0000936395-20-000036:mdna:25]
•our ability to grow and to maintain our new distribution relationships under which we will make available certain technology as a component;

[0000936395-20-000036:mdna:26]
•our exposure to the credit risks of our customers and our ability to collect receivables;

[0000936395-20-000036:mdna:27]
•modification or disruption of our internal business processes and information systems;

[0000936395-20-000036:mdna:28]
•the effect of our outstanding indebtedness on our liquidity and business;

[0000936395-20-000036:mdna:29]
•fluctuations in our stock price and our ability to access the capital markets to raise capital;

[0000936395-20-000036:mdna:30]
•unanticipated expenses or disruptions to our operations caused by facilities transitions or restructuring activities;

[0000936395-20-000036:mdna:31]
•our ability to attract and retain experienced and qualified personnel;

[0000936395-20-000036:mdna:32]
•disruptions to our operations caused by strategic acquisitions and investments or the inability to achieve the expected benefits and synergies of newly-acquired businesses;

[0000936395-20-000036:mdna:33]
•our ability to commercialize and to grow our software business and address networking strategies including software-defined networking and network function virtualization;

[0000936395-20-000036:mdna:34]
•changes in, and the impact of, government regulations, including with respect to: the communications industry generally; the business of our customers; the use, import or export of products; and the environment, potential climate change, and other social initiatives;

[0000936395-20-000036:mdna:35]
•the impact of the Tax Cuts and Jobs Act, future legislation or executive action in the U.S. relating to tax policy, changes in tax regulations and related accounting, and changes in our effective tax rates;

[0000936395-20-000036:mdna:36]
•future legislation or executive action in the U.S. or foreign countries relating to trade regulations, including the imposition of tariffs and duties or efforts to withdraw from or materially modify international trade agreements;

[0000936395-20-000036:mdna:37]
•factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies, including the COVID-19 pandemic;

[0000936395-20-000036:mdna:38]
•the write-down of goodwill, long-lived assets, or our deferred tax assets;

[0000936395-20-000036:mdna:39]
•our ability to maintain effective internal controls over financial reporting and liabilities that result from the inability to comply with corporate governance requirements; and

[0000936395-20-000036:mdna:40]
•adverse results in litigation matters.

[0000936395-20-000036:mdna:41]
[same as prior period, unchanged from 0000936395-20-000028:mdna:43]

[0000936395-20-000036:mdna:42]
[same as prior period, unchanged from 0000936395-20-000028:mdna:44]

[0000936395-20-000036:mdna:43]
[same as prior period, unchanged from 0000936395-20-000028:mdna:45]

[0000936395-20-000036:mdna:44]
[same as prior period, unchanged from 0000936395-20-000028:mdna:35]

[0000936395-20-000036:mdna:45]
[same as prior period, unchanged from 0000936395-20-000028:mdna:46]

[0000936395-20-000036:mdna:46]
[same as prior period, unchanged from 0000936395-20-000028:mdna:47]

[0000936395-20-000036:mdna:47]
COVID-19 was declared a pandemic in March 2020 and continues to have a significant impact on the global economy, the industries and customers we serve and our operations. In response to the COVID-19 pandemic, we have prioritized the safety of our employees and business partners, while continuing to support the needs of our customers and communities during this unprecedented period.

[0000936395-20-000036:mdna:48]
Employees. We have implemented travel bans and restrictions, temporarily closed offices, and have required that the vast majority of our employees globally work from home on a regular basis. Given our long-standing practice of flexible working arrangements, our distributed workforce is accustomed to the digital platforms and virtual collaboration tools we use to maintain productivity and to remain in contact with one another and our business partners. For the small number of employees who need to be in offices, laboratory environments or at business partner sites to perform their roles, we are taking appropriate precautions to protect their health and safety. We have adopted new employee benefits and wellbeing initiatives to support our employees, including initiatives for those who are now working remotely. We also continue to hire and on-board new employees while operating primarily in a remote environment. We are proud of the way in which our employees have continued to productively execute on our innovation roadmap and operating goals, including achieving the commercial availability of our fifth-generation WaveLogic coherent modem technology. However, sustained limitations on the ability of our research and development employees to work in our facilities, including in Canada, India and the United States, as a result of restrictions imposed by governments, or us, could make it more difficult for them to collaborate as effectively, particularly in the development of new solutions.

[0000936395-20-000036:mdna:49]
Business & Operations. We have implemented business continuity plans designed to minimize potential business disruption from the COVID-19 pandemic and to protect our supply chain and customer fulfillment and support operations.

[0000936395-20-000036:mdna:50]
Demand for Products & Services. During the second quarter of fiscal 2020, we experienced higher than typical orders for our products and services among a concentrated set of larger customers with whom we had existing positions as a supplier. At that time, we believed that some portion of these orders likely reflected short-term purchasing behaviors based on customer-specific considerations in the face of the pandemic, including: customer concerns about future continued availability of supply; implementation of customer business continuity actions; our desire for increased visibility into expected demand; customer consumption of their existing inventory or spare equipment; additional network capacity requirements; acceleration of capital spending; and, possibly, increased bandwidth demands being placed on networks due to the pandemic. During the third quarter of fiscal 2020, our order volumes declined significantly from the previous quarter, particularly within our communications service provider and cable operator customers, in the face of continued economic uncertainty stemming from COVID-19. With respect to these customer segments in particular, we believe that this greater capital expenditure restraint stems from the deferral or re-prioritization of certain new network initiatives and continued uncertainty associated with the impact of the pandemic and economic uncertainty upon their enterprise business segments. As a result, our quarterly order volumes were meaningfully below revenue during the third quarter of fiscal 2020, challenging our visibility and the outlook for our orders and revenue in future periods. In the near-term, we expect this more cautious spending environment to continue into the fourth quarter of fiscal 2020 and, likely, periods thereafter in fiscal 2021. We expect these conditions to continue to adversely affect our order volumes and to adversely impact revenue in the short term, with revenue for our fourth fiscal quarter expected to decline meaningfully on a sequential and year-over-year basis. Over the longer term, we continue to believe that the unique and increased demands placed on network infrastructures as a result of the COVID-19 pandemic, and the related increase in remote working worldwide, have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation. We believe that we are well positioned competitively to capitalize on the opportunities that we expect to be presented by these dynamics.

[0000936395-20-000036:mdna:51]
Supply Chain. We rely on third-party manufacturing operations in Mexico, Thailand, the United States and Canada. We also rely on a global component supply network involving many vendors and countries throughout the world. During the second quarter of fiscal 2020, some of our component suppliers – particularly those with facilities in China and Malaysia – experienced challenges related to COVID-19 that resulted in temporary closures or reductions of supply capacity. Although in many cases we were able to overcome these conditions through execution of our

[0000936395-20-000036:mdna:52]
mitigation planning, supply chain disruptions negatively impacted our revenue for the second quarter of fiscal 2020. During the third quarter of fiscal 2020, we took a number of steps, some of which remain ongoing, including multi-sourcing and pre-ordering components and finished goods inventory, in an effort to reduce the impact of the adverse supply chain conditions that we experienced. As a result of these actions, and generally improved conditions with our suppliers or the geographies in which they operate, supply chain related challenges to our operations abated in the third quarter of fiscal 2020 and were not material to revenue. However, there can be no assurance that supply chain disruptions related to COVID-19 will not continue, or worsen, in the future.

[0000936395-20-000036:mdna:53]
Services and Customer Fulfillment. We have experienced some disruption in our ability to provide installation, professional and fulfillment services to customers due to site access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings, which adversely impacted revenue, particularly in the second quarter of fiscal 2020. These conditions have also made it more challenging to execute and adversely impacted the timing of customer plans to operationalize newer projects and recent customer design wins, primarily in international markets. We expect these conditions to persist in the short-term, adversely impacting our revenue and results of operations. We continue to take steps and work with customers to ensure their business needs are supported, while protecting the health and safety of our employees, customers and business partners. However, should restrictions or disruptions of transportation persist or worsen, such as through reduced availability of air transport, port closures, or increased border controls or closures, our business, operations and ability to meet customer demand could be materially adversely affected.

[0000936395-20-000036:mdna:54]
Sales & Marketing. The competitive nature of our business depends on our ability to conduct sales and marketing activities with our customers. For instance, in the past few years, our ability to be first to market with leading networking solutions, and to conduct sales and marketing activities around these new technology offerings, has had a significant impact on our revenue and growth. In the first half of fiscal 2020, we were the first to market with 800 gigabit technology with our fifth-generation WaveLogic® coherent modem technology. Restrictions on travel due to COVID-19 and limitations on interactions with customers, such as field and lab trials, have negatively impacted our ability to carry out certain sales and marketing activities, including our ability to secure new customers, to qualify and sell new products, and to grow sales with customers. This is particularly the case where we do not have longer-standing supply relationships, such as within international markets and for our Blue Planet Automation Software & Services segment and our Packet Networking product line.

[0000936395-20-000036:mdna:55]
Market Conditions. As a result of continued economic uncertainty stemming from the pandemic, during the third quarter of fiscal 2020 we experienced a significant reduction in our order volumes, as compared to our revenue, and a reduction in our short-term outlook for our orders and revenue. We believe that ongoing concerns relating to the pandemic, and its impact on the enterprise business segments of our communications service provider and cable operator customers, continue to adversely impact the velocity of business in general, with a particular impact on customer willingness and ability to initiate new network projects. For example, our service provider customers rely in part upon the sale of services to consumers and enterprises, including those in the retail, entertainment, and travel industries, which have been acutely impacted by the negative economic effects of the COVID-19 pandemic. Similarly, certain of our Web-scale customers have business models that heavily rely upon advertising revenue from enterprises, including those in industries acutely affected by the COVID-19 pandemic. We believe customers are exercising greater restraint in networking projects, including data centers, and are also more carefully prioritizing where and when to add network capacity. Delays in operationalizing new network projects that we anticipated occurring on their original timelines have also adversely affected our expectations for revenue in the future. Conversely, our recent gross margin performance has benefited from these dynamics, with a larger percentage of our revenue comprised of existing business, as compared to new design wins and early in life projects, which tend to have lower margins. As a result of these dynamics, we expect the growth rates in our addressable markets to slow and the overall market growth to be flat to down in 2020 as compared to 2019, which we expect to adversely impact our revenue in the near term. We expect these market dynamics, including constrained customer spending and the decreased velocity of new business execution, to persist through the fourth quarter of fiscal 2020 and, likely, periods thereafter in fiscal 2021.

[0000936395-20-000036:mdna:56]
Liquidity & Balance Sheet. As of the end of the third quarter of fiscal 2020, we had $1.2 billion in cash and short-term investments. We believe our strong liquidity and balance sheet position is an important competitive differentiator at this time. It enables us to continue to invest in innovation, ensure a strong inventory position to support customers and provide for working capital needs. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and may consider capital raising and other market opportunities that may be available to us. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020 we temporarily suspended purchases of our common stock under our stock repurchase program and have reallocated our investments principally to U.S. government-backed funds.

[0000936395-20-000036:mdna:57]
Community. Our global workforce has undertaken a range of volunteering and charitable actions to support our neighbors, communities and front-line health care workers during this challenging time. We have enhanced by three times our

[0000936395-20-000036:mdna:58]
31

[0000936395-20-000036:mdna:59]
corporate charitable matching program for employee donations and volunteering, and our employees have volunteered their time in important ways during this crisis. For example, we have donated personal protective equipment and have been 3-D printing and designing face shields and components for health care workers.

[0000936395-20-000036:mdna:60]
The COVID-19 pandemic and resulting countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic, and the duration and severity of its impact on our business and results of operations in future periods remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our operations, or in economic activity and demand generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-20-000036:mdna:61]
[same as prior period, unchanged from 0000936395-20-000028:mdna:58]

[0000936395-20-000036:mdna:62]
We have continued to use our significant research and development investment capacity to push the pace of innovation in our markets and provide offerings that promote our Adaptive Network vision through further advances in programmable hardware, analytics, and control and automation. In the third quarter of fiscal 2020, our fifth-generation WaveLogic coherent modem technology, which is capable of delivering 800 gigabits of capacity per second over a single wavelength, became widely commercially available on our Converged Packet Optical platforms.

[0000936395-20-000036:mdna:63]
[same as prior period, unchanged from 0000936395-20-000028:mdna:60]

[0000936395-20-000036:mdna:64]
Available Information. Our quarterly reports on Form 10-Q, annual reports on Form 10-K, current reports on Form 8-K, and any amendments thereto filed or furnished with the SEC are available through the SEC’s website at www.sec.gov and are available free of charge on our website as soon as reasonably practicable after we file or furnish these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Information on our website is not deemed to be incorporated by reference into this report. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-20-000036:mdna:65]
[same as prior period, unchanged from 0000936395-20-000028:mdna:63]

[0000936395-20-000036:mdna:66]
[same as prior period, unchanged from 0000936395-20-000028:mdna:64]

[0000936395-20-000036:mdna:67]
[same as prior period, unchanged from 0000936395-20-000028:mdna:65]

[0000936395-20-000036:mdna:68]
[same as prior period, unchanged from 0000936395-20-000028:mdna:66]

[0000936395-20-000036:mdna:69]
Quarter ended August 1, 2020 compared to the quarter ended August 3, 2019

[0000936395-20-000036:mdna:70]
[same as prior period, unchanged from 0000936395-20-000028:mdna:68]

[0000936395-20-000036:mdna:71]
During the third quarter of fiscal 2020, approximately 14.9% of our revenue was non-U.S. Dollar-denominated, primarily including sales in Euros, Canadian Dollars, Brazilian Reais, British Pounds, and Indian Rupees. During the third quarter of fiscal 2020, as compared to the third quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced slightly by approximately $7.5 million, or 0.8%, as compared to the third quarter of fiscal 2019. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:72]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | 74.0 |  |  | $ | 724,245 |  |  | 75.4 |  |  | $ | (1,733) |  |  | (0.2) |  |
| Packet Networking | 79,756 |  |  | 8.1 |  |  | 71,823 |  |  | 7.5 |  |  | 7,933 |  |  | 11.0 |  |
| Total Networking Platforms | 802,268 |  |  | 82.1 |  |  | 796,068 |  |  | 82.9 |  |  | 6,200 |  |  | 0.8 |  |
| Platform Software and Services | 46,422 |  |  | 4.8 |  |  | 37,312 |  |  | 3.9 |  |  | 9,110 |  |  | 24.4 |  |
| Blue Planet Automation Software and Services | 11,297 |  |  | 1.1 |  |  | 10,530 |  |  | 1.1 |  |  | 767 |  |  | 7.3 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 69,099 |  |  | 7.1 |  |  | 65,936 |  |  | 6.9 |  |  | 3,163 |  |  | 4.8 |  |
| Installation and Deployment | 39,798 |  |  | 4.1 |  |  | 39,802 |  |  | 4.1 |  |  | (4) |  |  | — |  |
| Consulting and Network Design | 7,828 |  |  | 0.8 |  |  | 10,958 |  |  | 1.1 |  |  | (3,130) |  |  | (28.6) |  |
| Total Global Services | 116,725 |  |  | 12.0 |  |  | 116,696 |  |  | 12.1 |  |  | 29 |  |  | — |  |
| Consolidated revenue | $ | 976,712 |  |  | 100.0 |  |  | $ | 960,606 |  |  | 100.0 |  |  | $ | 16,106 |  |  | 1.7 |  |

[0000936395-20-000036:mdna:73]
[same as prior period, unchanged from 0000936395-20-000028:mdna:72]

[0000936395-20-000036:mdna:74]
* Denotes % of total revenue

[0000936395-20-000036:mdna:75]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:76]
•Networking Platforms segment revenue increased, reflecting a product line sales increase of $7.9 million of our Packet Networking products, partially offset by a product line sales decrease of $1.7 million of our Converged Packet Optical products.

[0000936395-20-000036:mdna:77]
◦Packet Networking sales increased, primarily reflecting sales increases of $18.1 million of our 3000 and 5000 families of service delivery and aggregation switches to enterprise customers, cable and multiservice operators, and communications service providers. These sales increases were partially offset by a sales decrease of $9.9 million of our 6500 Packet Transport System (PTS) to communications service providers.

[0000936395-20-000036:mdna:78]
◦Converged Packet Optical sales decreased, primarily reflecting sales decreases of $34.5 million of our 6500 Packet-Optical Platform to communications service providers and Web-scale providers. This sales decrease was partially offset by a sales increase of $32.6 million of our Waveserver products primarily to communications service providers and Web-scale providers.

[0000936395-20-000036:mdna:79]
•Platform Software and Services segment revenue increased, reflecting increases of $5.0 million related to services and $4.1 million in software sales.

[0000936395-20-000036:mdna:80]
•Blue Planet Automation Software and Services segment revenue increased, reflecting an increase of $2.7 million in software services, partially offset by a decrease of $1.9 million of software platforms. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date.

[0000936395-20-000036:mdna:81]
•Global Services segment revenue slightly increased, primarily reflecting a sales increase of $3.2 million of our maintenance support and training, partially offset by a sales decrease of $3.1 million of our consulting and network design services, in part due to impacts of COVID-19 as described above.

[0000936395-20-000036:mdna:82]
Our operating segments engage in business and operations across three geographic regions: Americas; EMEA; and APAC. As discussed in Note 3, effective the beginning of fiscal 2020, our Global Sales and Marketing organization combined our previous North America and CALA regions into a new Americas sales region. The decrease in our EMEA region for the quarter ended August 1, 2020 was primarily driven by decreased sales in the United Kingdom. The decrease in our APAC region for the third quarter of fiscal 2020 was primarily driven by decreased sales in India and Japan. The following table reflects our

[0000936395-20-000036:mdna:83]
geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:84]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Americas | $ | 713,340 |  |  | 73.0 |  |  | $ | 656,261 |  |  | 68.3 |  |  | $ | 57,079 |  |  | 8.7 |  |
| EMEA | 162,465 |  |  | 16.6 |  |  | 169,532 |  |  | 17.6 |  |  | (7,067) |  |  | (4.2) |  |
| APAC | 100,907 |  |  | 10.4 |  |  | 134,813 |  |  | 14.1 |  |  | (33,906) |  |  | (25.2) |  |
| Total | $ | 976,712 |  |  | 100.0 |  |  | $ | 960,606 |  |  | 100.0 |  |  | $ | 16,106 |  |  | 1.7 |  |

[0000936395-20-000036:mdna:85]
[same as prior period, unchanged from 0000936395-20-000028:mdna:83]

[0000936395-20-000036:mdna:86]
* Denotes % of total revenue

[0000936395-20-000036:mdna:87]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:88]
•Americas revenue increased, primarily reflecting sales increases of $45.6 million within our Networking Platforms segment, $5.1 million within our Platform Software and Services segment and $6.4 million in our Global Services segment. The increase within our Networking Platforms segment reflects a product line sales increase of $40.2 million of Converged Packet Optical products, primarily related to sales increases of $31.0 million of our Waveserver products and $9.6 million of our 6500 Packet-Optical Platform. Our Waveserver sales increase primarily reflects increased sales to Web-scale customers and communications service providers. Our 6500 Packet-Optical Platform sales increase primarily reflects increased sales to cable and multiservice providers.

[0000936395-20-000036:mdna:89]
•EMEA revenue decreased, primarily reflecting decreases of $5.9 million within our Networking Platforms segment and $3.7 million within our Global Services segment, partially offset by an increase of $2.3 million in our Platform Software and Services segment. The revenue decrease within our Networking Platforms segment reflects a product line sales decrease of $9.7 million of Converged Packet Optical products, primarily related to sales decreases of $8.2 million of our 6500 Packet-Optical Platform and $1.3 million of our Waveserver products.

[0000936395-20-000036:mdna:90]
•APAC revenue decreased, primarily reflecting decreases of $33.5 million within our Networking Platforms segment and $2.7 million of our Global Services segment, partially offset by a sales increase of $1.8 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $35.9 million in sales of our 6500 Packet-Optical Platform primarily to communications service providers in India and Japan, partially offset by an increase of $2.9 million in sales of our Waveserver products, primarily to Web-scale providers.

[0000936395-20-000036:mdna:91]
[same as prior period, unchanged from 0000936395-20-000028:mdna:91]

[0000936395-20-000036:mdna:92]
[same as prior period, unchanged from 0000936395-20-000028:mdna:92]

[0000936395-20-000036:mdna:93]
[same as prior period, unchanged from 0000936395-20-000028:mdna:93]

[0000936395-20-000036:mdna:94]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics

[0000936395-20-000036:mdna:95]
sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-20-000036:mdna:96]
[same as prior period, unchanged from 0000936395-20-000028:mdna:95]

[0000936395-20-000036:mdna:97]
[same as prior period, unchanged from 0000936395-20-000028:mdna:96]

[0000936395-20-000036:mdna:98]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Total revenue | $ | 976,712 |  |  | 100.0 |  |  | $ | 960,606 |  |  | 100.0 |  |  | $ | 16,106 |  |  | 1.7 |  |
| Total cost of goods sold | 512,031 |  |  | 52.4 |  |  | 536,254 |  |  | 55.8 |  |  | (24,223) |  |  | (4.5) |  |
| Gross profit | $ | 464,681 |  |  | 47.6 |  |  | $ | 424,352 |  |  | 44.2 |  |  | $ | 40,329 |  |  | 9.5 |  |

[0000936395-20-000036:mdna:99]
[same as prior period, unchanged from 0000936395-20-000028:mdna:98]

[0000936395-20-000036:mdna:100]
* Denotes % of total revenue

[0000936395-20-000036:mdna:101]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:102]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Product revenue | $ | 819,022 |  |  | 100.0 |  |  | $ | 810,588 |  |  | 100.0 |  |  | $ | 8,434 |  |  | 1.0 |  |
| Product cost of goods sold | 436,227 |  |  | 53.3 |  |  | 454,921 |  |  | 56.1 |  |  | (18,694) |  |  | (4.1) |  |
| Product gross profit | $ | 382,795 |  |  | 46.7 |  |  | $ | 355,667 |  |  | 43.9 |  |  | $ | 27,128 |  |  | 7.6 |  |

[0000936395-20-000036:mdna:103]
[same as prior period, unchanged from 0000936395-20-000028:mdna:102]

[0000936395-20-000036:mdna:104]
* Denotes % of product revenue

[0000936395-20-000036:mdna:105]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:106]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Service revenue | $ | 157,690 |  |  | 100.0 |  |  | $ | 150,018 |  |  | 100.0 |  |  | $ | 7,672 |  |  | 5.1 |  |
| Service cost of goods sold | 75,804 |  |  | 48.1 |  |  | 81,333 |  |  | 54.2 |  |  | (5,529) |  |  | (6.8) |  |
| Service gross profit | $ | 81,886 |  |  | 51.9 |  |  | $ | 68,685 |  |  | 45.8 |  |  | $ | 13,201 |  |  | 19.2 |  |

[0000936395-20-000036:mdna:107]
[same as prior period, unchanged from 0000936395-20-000028:mdna:106]

[0000936395-20-000036:mdna:108]
* Denotes % of services revenue

[0000936395-20-000036:mdna:109]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:110]
•Gross profit as a percentage of revenue increased, as our gross margin benefited significantly from a favorable mix of customers and product lines that we believe to be a short-term effect due to COVID-19 related factors, and, to a lesser extent, continued improvement in our service margin. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, during the second and third quarters of fiscal 2020, a higher proportion of our revenue consisted of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, which tend to carry lower margins. We expect our gross margins to reduce from these elevated short-term levels as some of the pandemic’s impacts on new business lessen and our overall revenue resumes a more typical composition of revenue from existing and new business. A key part of our ongoing strategy is to leverage our technology leadership, displace competitors and capture additional market share. These efforts to expand our customer base or market share have in prior periods adversely affected our gross margin as a result of the more aggressive pricing, commercial concessions and other unfavorable terms often required to be successful within these competitive dynamics. Our mix of revenues from such new wins or early stage deployments can adversely

[0000936395-20-000036:mdna:111]
impact gross margins in a particular period. The longer term intent of this strategy is to continue to improve our margins over time, as we sell channel cards adding capacity or services to networks, maintenance services, and other higher margin products.

[0000936395-20-000036:mdna:112]
•Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and product lines, as described above, and continued product cost reductions, partially offset by market-based price compression we encountered during the period.

[0000936395-20-000036:mdna:113]
•Gross profit on services as a percentage of services revenue increased, primarily due to a higher concentration of revenue from maintenance service contracts with relatively low incremental costs, and fewer early stage network deployment activities due to the impact of COVID-19.

[0000936395-20-000036:mdna:114]
[same as prior period, unchanged from 0000936395-20-000028:mdna:112]

[0000936395-20-000036:mdna:115]
[same as prior period, unchanged from 0000936395-20-000028:mdna:113]

[0000936395-20-000036:mdna:116]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-20-000036:mdna:117]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-20-000036:mdna:118]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-20-000036:mdna:119]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-20-000036:mdna:120]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-20-000036:mdna:121]
•Acquisition and integration costs (recoveries) consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of DonRiver and Centina, including costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition.

[0000936395-20-000036:mdna:122]
During the third quarter of fiscal 2020, approximately 50.5% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, Indian Rupees and British Pounds. During the third quarter of fiscal 2020 as compared to the third quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our operating expense reported in U.S. Dollars was reduced slightly by approximately $3.6 million, or 1.3%, as compared to the third quarter of fiscal 2019, due to the strengthening U.S. Dollar, net of hedging. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:123]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Research and development | $ | 130,221 |  |  | 13.3 |  |  | $ | 139,880 |  |  | 14.6 |  |  | $ | (9,659) |  |  | (6.9) |  |
| Selling and marketing | 94,763 |  |  | 9.7 |  |  | 104,230 |  |  | 10.9 |  |  | (9,467) |  |  | (9.1) |  |
| General and administrative | 41,635 |  |  | 4.3 |  |  | 42,695 |  |  | 4.4 |  |  | (1,060) |  |  | (2.5) |  |
| Amortization of intangible assets | 5,840 |  |  | 0.6 |  |  | 5,529 |  |  | 0.6 |  |  | 311 |  |  | 5.6 |  |
| Significant asset impairments and restructuring costs | 6,515 |  |  | 0.7 |  |  | 5,355 |  |  | 0.6 |  |  | 1,160 |  |  | 21.7 |  |
| Acquisition and integration costs (recoveries) | (2,329) |  |  | (0.2) |  |  | 1,362 |  |  | 0.1 |  |  | (3,691) |  |  | (271.0) |  |
| Total operating expenses | $ | 276,645 |  |  | 28.4 |  |  | $ | 299,051 |  |  | 31.2 |  |  | $ | (22,406) |  |  | (7.5) |  |

[0000936395-20-000036:mdna:124]
[same as prior period, unchanged from 0000936395-20-000028:mdna:123]

[0000936395-20-000036:mdna:125]
* Denotes % of total revenue

[0000936395-20-000036:mdna:126]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:127]
•Research and development expense benefited from $2.2 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expense decreased by $9.7 million. This decrease primarily reflects decreases in employee and compensation costs, facility and information technology costs, and travel and entertainment costs due to COVID-19, partially offset by increases in professional services and technology and related costs.

[0000936395-20-000036:mdna:128]
•Selling and marketing expense benefited from $1.0 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Brazilian Reais, Indian Rupee, and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses decreased by $9.5 million. This decrease primarily reflects decreases in travel and entertainment costs due to restrictions on travel and limitations on our interactions with customers as a result of COVID-19.

[0000936395-20-000036:mdna:129]
•General and administrative expense decreased by $1.1 million. This decrease primarily reflects a decrease in employee and compensation costs, partially offset by an increase in bad debt expense.

[0000936395-20-000036:mdna:130]
•Amortization of intangible assets slightly increased due to additional intangibles acquired in connection with our acquisition of Centina in the first quarter of fiscal 2020.

[0000936395-20-000036:mdna:131]
•Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-20-000036:mdna:132]
•Acquisition and integration costs (recoveries) primarily reflect recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition.

[0000936395-20-000036:mdna:133]
[same as prior period, unchanged from 0000936395-20-000028:mdna:132]

[0000936395-20-000036:mdna:134]
[same as prior period, unchanged from 0000936395-20-000028:mdna:133]

[0000936395-20-000036:mdna:135]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Interest and other income, net | $ | 232 |  |  | 0.0 |  |  | $ | 1,050 |  |  | 0.1 |  |  | $ | (818) |  |  | (77.9) |  |
| Interest expense | $ | 7,251 |  |  | 0.7 |  |  | $ | 9,404 |  |  | 1.0 |  |  | $ | (2,153) |  |  | (22.9) |  |
| Provision for income taxes | $ | 38,750 |  |  | 4.0 |  |  | $ | 30,198 |  |  | 3.1 |  |  | $ | 8,552 |  |  | 28.3 |  |

[0000936395-20-000036:mdna:136]
[same as prior period, unchanged from 0000936395-20-000028:mdna:135]

[0000936395-20-000036:mdna:137]
* Denotes % of total revenue

[0000936395-20-000036:mdna:138]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:139]
•Interest and other income, net primarily reflects lower interest income due to reduced interest rates on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-20-000036:mdna:140]
•Interest expense decreased, primarily due to a reduction of LIBOR rates impacting our New 2025 Term Loan.

[0000936395-20-000036:mdna:141]
•Provision for income taxes increased, due to higher earnings for the third quarter of fiscal 2020. The effective tax rate for the third quarter of fiscal 2020 was lower compared to the third quarter of fiscal 2019, primarily due to reduced BEAT.

[0000936395-20-000036:mdna:142]
Nine months ended August 1, 2020 compared to the nine months ended August 3, 2019

[0000936395-20-000036:mdna:143]
[same as prior period, unchanged from 0000936395-20-000028:mdna:142]

[0000936395-20-000036:mdna:144]
During the first nine months of fiscal 2020, approximately 15.8% of our revenue was non-U.S. Dollar-denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, British Pounds, Indian Rupees and United Arab Emirates Dirham. During the first nine months of fiscal 2020, as compared to the first nine months of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced by approximately $13.5 million or 0.5%. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:145]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | 72.8 |  |  | $ | 1,897,080 |  |  | 72.8 |  |  | 71,275 |  |  | 3.8 |  |
| Packet Networking | 211,432 |  |  | 7.8 |  |  | 216,529 |  |  | 8.3 |  |  | (5,097) |  |  | (2.4) |  |
| Total Networking Platforms | 2,179,787 |  |  | 80.6 |  |  | 2,113,609 |  |  | 81.1 |  |  | 66,178 |  |  | 3.1 |  |
| Platform Software and Services | 143,295 |  |  | 5.3 |  |  | 114,139 |  |  | 4.4 |  |  | 29,156 |  |  | 25.5 |  |
| Blue Planet Automation Software and Services | 41,779 |  |  | 1.6 |  |  | 37,977 |  |  | 1.5 |  |  | 3,802 |  |  | 10.0 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 202,370 |  |  | 7.5 |  |  | 196,002 |  |  | 7.5 |  |  | 6,368 |  |  | 3.2 |  |
| Installation and Deployment | 108,994 |  |  | 4.0 |  |  | 111,746 |  |  | 4.3 |  |  | (2,752) |  |  | (2.5) |  |
| Consulting and Network Design | 27,452 |  |  | 1.0 |  |  | 30,671 |  |  | 1.2 |  |  | (3,219) |  |  | (10.5) |  |
| Total Global Services | 338,816 |  |  | 12.5 |  |  | 338,419 |  |  | 13.0 |  |  | 397 |  |  | 0.1 |  |
| Consolidated revenue | $ | 2,703,677 |  |  | 100.0 |  |  | $ | 2,604,144 |  |  | 100.0 |  |  | $ | 99,533 |  |  | 3.8 |  |

[0000936395-20-000036:mdna:146]
[same as prior period, unchanged from 0000936395-20-000028:mdna:145]

[0000936395-20-000036:mdna:147]
* Denotes % of total revenue

[0000936395-20-000036:mdna:148]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:149]
•Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $71.3 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $5.1 million of our Packet Networking products.

[0000936395-20-000036:mdna:150]
◦Converged Packet Optical sales increased, reflecting an increase of $39.4 million of our Waveserver products, which benefited from increased sales to cable and multiservice operators and communications service providers, partially offset by decreased sales to Web-scale providers, and a $24.5 million sales increase of our 5430 Reconfigurable Switching Systems to communications service providers.

[0000936395-20-000036:mdna:151]
◦Packet Networking sales decreased, primarily reflecting a sales decrease of $35.5 million of our 6500 Packet Transport System (PTS) to communications service providers. These sales decreases were partially offset by a sales increase of $32.4 million of our 3000 and 5000 families of service delivery and aggregation switches to enterprise customers and cable and multiservice operators.

[0000936395-20-000036:mdna:152]
•Platform Software and Services segment revenue increased, reflecting increases of $18.9 million in software sales and $10.3 million primarily related to services to communications service providers.

[0000936395-20-000036:mdna:153]
•Blue Planet Automation Software and Services segment revenue increased, reflecting an increase of $6.5 million in software services, partially offset by a decrease in software sales of $2.7 million. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date.

[0000936395-20-000036:mdna:154]
•Global Services segment revenue slightly increased, primarily reflecting a sales increase of $6.4 million of our maintenance support and training partially offset by sales decreases of $3.2 million of our consulting and network design services and $2.8 million of our installation and deployment services.

[0000936395-20-000036:mdna:155]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of Americas, can result in large variations in geographic revenue results in any particular quarter. The increase in our EMEA region for the nine months ended August 1, 2020 was primarily driven by increased sales in the Netherlands, the United Arab Emirates and France,

[0000936395-20-000036:mdna:156]
partially offset by decreased sales in the United Kingdom. The decrease in our APAC region for the nine months ended August 1, 2020 was primarily driven by decreased sales in India, Japan and South Korea, partially offset by increased sales in Singapore. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:157]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Americas | $ | 1,937,725 |  |  | 71.7 |  |  | $ | 1,788,234 |  |  | 68.7 |  |  | $ | 149,491 |  |  | 8.4 |  |
| EMEA | 433,861 |  |  | 16.0 |  |  | 413,715 |  |  | 15.9 |  |  | 20,146 |  |  | 4.9 |  |
| APAC | 332,091 |  |  | 12.3 |  |  | 402,195 |  |  | 15.4 |  |  | (70,104) |  |  | (17.4) |  |
| Total | $ | 2,703,677 |  |  | 100.0 |  |  | $ | 2,604,144 |  |  | 100.0 |  |  | $ | 99,533 |  |  | 3.8 |  |

[0000936395-20-000036:mdna:158]
[same as prior period, unchanged from 0000936395-20-000028:mdna:157]

[0000936395-20-000036:mdna:159]
* Denotes % of total revenue

[0000936395-20-000036:mdna:160]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:161]
•Americas revenue increased, primarily reflecting sales increases of $114.3 million within our Networking Platforms segment, $22.0 million within our Platform Software and Services segment and $16.9 million within our Global Services segment. These sales increases were partially offset by a sales decrease of $3.8 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $123.4 million of Converged Packet Optical products, partially offset by a decrease of $9.1 million of Packet Networking products. Our Converged Packet Optical revenue increase primarily reflects sales increases of $81.8 million of our 6500 Packet-Optical Platform, $20.5 million of our Waveserver products and $16.9 million of our 5430 Reconfigurable Switching Systems. Our 6500 Packet-Optical Platform revenue increase primarily reflects increased sales to cable and multiservice operators, government customers and communications service providers. Our Waveserver sales increase reflects increased sales to cable and multiservice operators and communications service providers, partially offset by a decrease in sales to Web-scale providers. Our 5430 Reconfigurable Switching Systems sales increase primarily reflect increased sales to communications service providers.

[0000936395-20-000036:mdna:162]
•EMEA revenue increased, primarily reflecting increases of $25.2 million within our Networking Platforms segment and $2.9 million within our Platform Software and Services segment, partially offset by a decrease of $8.9 million within our Global Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $20.5 million of Converged Packet Optical products, primarily related to sales increases of $9.5 million of our 6500 Packet-Optical Platform to Web-scale providers and communications service providers, $7.9 million of our 5430 Reconfigurable Switching Systems to communications service providers and $4.7 million of our Waveserver products to communications service providers.

[0000936395-20-000036:mdna:163]
•APAC revenue decreased, primarily reflecting decreases of $73.4 million within our Networking Platforms segment and $7.6 million of our Global Services segment. These decreases were partially offset by sales increases of $6.7 million within our Blue Planet Automation Software and Services segment and $4.2 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $87.2 million in sales of our 6500 Packet-Optical Platform to communications service providers in India and Japan, partially offset by an increase of $14.2 million in sales of our Waveserver products primarily to Web-scale providers.

[0000936395-20-000036:mdna:164]
[same as prior period, unchanged from 0000936395-20-000028:mdna:163]

[0000936395-20-000036:mdna:165]
[same as prior period, unchanged from 0000936395-20-000028:mdna:164]

[0000936395-20-000036:mdna:166]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Total revenue | $ | 2,703,677 |  |  | 100.0 |  |  | $ | 2,604,144 |  |  | 100.0 |  |  | $ | 99,533 |  |  | 3.8 |  |
| Total cost of goods sold | 1,455,135 |  |  | 53.8 |  |  | 1,481,774 |  |  | 56.9 |  |  | (26,639) |  |  | (1.8) |  |
| Gross profit | $ | 1,248,542 |  |  | 46.2 |  |  | $ | 1,122,370 |  |  | 43.1 |  |  | $ | 126,172 |  |  | 11.2 |  |

[0000936395-20-000036:mdna:167]
[same as prior period, unchanged from 0000936395-20-000028:mdna:166]

[0000936395-20-000036:mdna:168]
* Denotes % of total revenue

[0000936395-20-000036:mdna:169]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:170]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Product revenue | $ | 2,246,129 |  |  | 100.0 |  |  | $ | 2,163,808 |  |  | 100.0 |  |  | $ | 82,321 |  |  | 3.8 |  |
| Product cost of goods sold | 1,230,378 |  |  | 54.8 |  |  | 1,246,413 |  |  | 57.6 |  |  | (16,035) |  |  | (1.3) |  |
| Product gross profit | $ | 1,015,751 |  |  | 45.2 |  |  | $ | 917,395 |  |  | 42.4 |  |  | $ | 98,356 |  |  | 10.7 |  |

[0000936395-20-000036:mdna:171]
[same as prior period, unchanged from 0000936395-20-000028:mdna:170]

[0000936395-20-000036:mdna:172]
* Denotes % of product revenue

[0000936395-20-000036:mdna:173]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:174]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Service revenue | $ | 457,548 |  |  | 100.0 |  |  | $ | 440,336 |  |  | 100.0 |  |  | $ | 17,212 |  |  | 3.9 |  |
| Service cost of goods sold | 224,757 |  |  | 49.1 |  |  | 235,361 |  |  | 53.5 |  |  | (10,604) |  |  | (4.5) |  |
| Service gross profit | $ | 232,791 |  |  | 50.9 |  |  | $ | 204,975 |  |  | 46.5 |  |  | $ | 27,816 |  |  | 13.6 |  |

[0000936395-20-000036:mdna:175]
[same as prior period, unchanged from 0000936395-20-000028:mdna:174]

[0000936395-20-000036:mdna:176]
* Denotes % of services revenue

[0000936395-20-000036:mdna:177]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:178]
•Gross profit as a percentage of revenue increased, as our gross margin benefited significantly from a favorable mix of customers and product lines that we believe to be a short-term effect due to COVID-19 related factors, and, to a lesser extent, continued improvement in our service margin. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, during the second and third quarters of fiscal 2020, a higher proportion of our revenue consisted of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms.

[0000936395-20-000036:mdna:179]
•Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and product lines as described above, and product cost reductions, partially offset by market-based price compression we encountered during the period.

[0000936395-20-000036:mdna:180]
•Gross profit on services as a percentage of services revenue increased, due to a higher concentration of revenue from maintenance service contracts with relatively low incremental costs, and fewer early stage network deployment activities due to the impact of COVID-19.

[0000936395-20-000036:mdna:181]
[same as prior period, unchanged from 0000936395-20-000028:mdna:180]

[0000936395-20-000036:mdna:182]
During the first nine months of fiscal 2020, approximately 50.7% of our operating expense was non-U.S. Dollar-denominated, including Canadian Dollars, Indian Rupees, British Pounds, and Euros. Consequently, our operating expense reported in U.S. Dollars was reduced by approximately $7.3 million, or 0.9%, during the first nine months of fiscal 2020 as compared to the first nine months of fiscal 2019, due to the strengthening U.S. Dollar, net of hedging. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000036:mdna:183]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Research and development | $ | 392,651 |  |  | 14.5 |  |  | $ | 406,482 |  |  | 15.6 |  |  | $ | (13,831) |  |  | (3.4) |  |
| Selling and marketing | 303,043 |  |  | 11.2 |  |  | 305,845 |  |  | 11.7 |  |  | (2,802) |  |  | (0.9) |  |
| General and administrative | 126,133 |  |  | 4.7 |  |  | 124,092 |  |  | 4.8 |  |  | 2,041 |  |  | 1.6 |  |
| Amortization of intangible assets | 17,532 |  |  | 0.6 |  |  | 16,586 |  |  | 0.6 |  |  | 946 |  |  | 5.7 |  |
| Significant asset impairments and restructuring costs | 14,798 |  |  | 0.5 |  |  | 11,696 |  |  | 0.4 |  |  | 3,102 |  |  | 26.5 |  |
| Acquisition and integration costs (recoveries) | 904 |  |  | — |  |  | 4,105 |  |  | 0.2 |  |  | (3,201) |  |  | (78.0) |  |
| Total operating expenses | $ | 855,061 |  |  | 31.5 |  |  | $ | 868,806 |  |  | 33.3 |  |  | $ | (13,745) |  |  | (1.6) |  |

[0000936395-20-000036:mdna:184]
[same as prior period, unchanged from 0000936395-20-000028:mdna:183]

[0000936395-20-000036:mdna:185]
* Denotes % of total revenue

[0000936395-20-000036:mdna:186]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:187]
•Research and development expense benefited from $2.9 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses decreased by $13.8 million. This decrease primarily reflects decreases in employee and compensation costs, facility and information technology costs, professional services, and travel and entertainment costs as a result of COVID-19, partially offset by an increase of technology and related costs.

[0000936395-20-000036:mdna:188]
•Selling and marketing expense benefited from $3.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro, Brazilian Reais, Canadian Dollar and Australian Dollar. Including the effect of foreign exchange rates, net of hedging, sales and marketing expense decreased by $2.8 million. This decrease primarily reflects decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19 partially offset an increase in employee and compensation costs.

[0000936395-20-000036:mdna:189]
•General and administrative expense benefited from $1.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Indian Rupee and Brazilian Reais. Including the effect of foreign exchange rates, general and administrative expenses increased by $2.0 million. This increase primarily reflects an increase in bad debt expense, partially offset by decreases in employee and compensation costs and travel and entertainment costs.

[0000936395-20-000036:mdna:190]
•Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisition of Centina in the first quarter of fiscal 2020.

[0000936395-20-000036:mdna:191]
•Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-20-000036:mdna:192]
•Acquisition and integration costs (recoveries) reflect employment-related costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition and, legal, employee-related and other costs related to our acquisition of Centina in the first quarter of fiscal 2020.

[0000936395-20-000036:mdna:193]
[same as prior period, unchanged from 0000936395-20-000028:mdna:192]

[0000936395-20-000036:mdna:194]
[same as prior period, unchanged from 0000936395-20-000028:mdna:193]

[0000936395-20-000036:mdna:195]
|  | Nine Months Ended |  |  |  |  |  |  |  |  |  |  |
|  | August 1, 2020 |  | %* |  | August 3, 2019 |  | %* |  | Increase (decrease) |  | %** |
| Interest and other income, net | $ | 1,213 |  |  | — |  |  | $ | 5,059 |  |  | 0.2 |  |  | $ | (3,846) |  |  | (76.0) |  |
| Interest expense | $ | 23,926 |  |  | 0.9 |  |  | $ | 28,316 |  |  | 1.1 |  |  | $ | (4,390) |  |  | (15.5) |  |
| Loss on extinguishment and modification of debt | $ | 646 |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 646 |  |  | 100.0 |  |
| Provision for income taxes | $ | 73,872 |  |  | 2.7 |  |  | $ | 57,204 |  |  | 2.2 |  |  | $ | 16,668 |  |  | 29.1 |  |

[0000936395-20-000036:mdna:196]
[same as prior period, unchanged from 0000936395-20-000028:mdna:195]

[0000936395-20-000036:mdna:197]
* Denotes % of total revenue

[0000936395-20-000036:mdna:198]
** Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:199]
•Interest and other income, net primarily reflects lower interest income due to reduced interest rates on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-20-000036:mdna:200]
•Interest expense decreased, primarily due to a reduction of LIBOR rates impacting our 2025 Term Loan.

[0000936395-20-000036:mdna:201]
•Loss on extinguishment and modification of debt reflects the refinance of our Old 2025 Term Loan into our New 2025 Term Loan in the first quarter of fiscal 2020.

[0000936395-20-000036:mdna:202]
•Provision for income taxes increased, due to higher earnings for the first nine months of fiscal 2020. The effective tax rate for the first nine months of fiscal 2020 was lower compared to the first nine months of fiscal 2019, primarily due to reduced BEAT and the effect of the final regulations released on December 2, 2019.

[0000936395-20-000036:mdna:203]
[same as prior period, unchanged from 0000936395-20-000028:mdna:202]

[0000936395-20-000036:mdna:204]
[same as prior period, unchanged from 0000936395-20-000028:mdna:203]

[0000936395-20-000036:mdna:205]
|  | Quarter Ended |  |  |  |  |  |  |
|  | August 1, 2020 |  | August 3, 2019 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 262,801 |  |  | $ | 230,610 |  |  | $ | 32,191 |  |  | 14.0 |  |
| Platform Software and Services | $ | 24,299 |  |  | $ | 14,251 |  |  | $ | 10,048 |  |  | 70.5 |  |
| Blue Planet Automation Software and Services | $ | (5,316) |  |  | $ | (8,222) |  |  | $ | 2,906 |  |  | (35.3) |  |
| Global Services | $ | 52,676 |  |  | $ | 47,833 |  |  | $ | 4,843 |  |  | 10.1 |  |

[0000936395-20-000036:mdna:206]
[same as prior period, unchanged from 0000936395-20-000028:mdna:205]

[0000936395-20-000036:mdna:207]
* Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:208]
•Networking Platforms segment profit increased, primarily due to higher gross margin and higher sales volume as described above, and lower research and development costs.

[0000936395-20-000036:mdna:209]
•Platform Software and Services segment profit increased, primarily due to higher sales volume as described above.

[0000936395-20-000036:mdna:210]
•Blue Planet Automation Software and Services segment loss decreased, primarily due to improved gross margin, higher sales volume and lower research and development costs.

[0000936395-20-000036:mdna:211]
•Global Services segment profit increased, primarily due to improved gross margin, as described above.

[0000936395-20-000036:mdna:212]
|  | Nine Months Ended |  |  |  |  |  |  |
|  | August 1, 2020 |  | August 3, 2019 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 642,057 |  |  | $ | 542,391 |  |  | $ | 99,666 |  |  | 18.4 |  |
| Platform Software and Services | $ | 74,918 |  |  | $ | 47,192 |  |  | $ | 27,726 |  |  | 58.8 |  |
| Blue Planet Automation Software and Services | $ | (12,828) |  |  | $ | (16,210) |  |  | $ | 3,382 |  |  | (20.9) |  |
| Global Services | $ | 151,744 |  |  | $ | 142,515 |  |  | $ | 9,229 |  |  | 6.5 |  |

[0000936395-20-000036:mdna:213]
[same as prior period, unchanged from 0000936395-20-000028:mdna:212]

[0000936395-20-000036:mdna:214]
* Denotes % change from 2019 to 2020

[0000936395-20-000036:mdna:215]
•Networking Platforms segment profit increased, primarily due to higher sales volume and higher gross margin as described above and lower research and development costs.

[0000936395-20-000036:mdna:216]
•Platform Software and Services segment profit increased, primarily due to higher sales volume, as described above, and lower research and development costs, partially offset by reduced gross margin on software-related services.

[0000936395-20-000036:mdna:217]
•Blue Planet Automation Software and Services segment loss decreased, primarily due to higher gross margin on software-related services and higher sales volume, partially offset by higher research and development costs and lower gross margin on product sales.

[0000936395-20-000036:mdna:218]
•Global Services segment profit increased, primarily due to improved gross margin as described above.

[0000936395-20-000036:mdna:219]
[same as prior period, unchanged from 0000936395-20-000028:mdna:218]

[0000936395-20-000036:mdna:220]
Overview. For the nine months ended August 1, 2020, we generated $306.4 million of cash from operating activities, as our net income (adjusted for non-cash charges) of $558.6 million exceeded our working capital requirements of $252.2 million. For additional details on our cash provided by operating activities, see the discussion below entitled “Cash Provided By Operating Activities.”

[0000936395-20-000036:mdna:221]
Cash, cash equivalents and investments increased by $140.2 million during the first nine months of fiscal 2020. In addition to the cash from operating activities mentioned above, proceeds from the issuance of equity under our employee stock purchase plans provided $28.0 million in cash during the nine months ended August 1, 2020. Partially offsetting the increase in cash were the following items: (i) cash used to fund our investing activities for capital expenditures totaling $61.3 million; (ii) cash used for the acquisition of Centina of $28.3 million; (iii) cash used for stock repurchases under our stock repurchase program of $74.5 million; and (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $26.3 million.

[0000936395-20-000036:mdna:222]
|  | August 1,2020 |  | November 2,2019 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,093,749 |  |  | $ | 904,045 |  |  | $ | 189,704 |  |
| Short-term investments in marketable debt securities | 70,404 |  |  | 109,940 |  |  | (39,536) |  |
| Long-term investments in marketable debt securities | — |  |  | 10,014 |  |  | (10,014) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,164,153 |  |  | $ | 1,023,999 |  |  | $ | 140,154 |  |

[0000936395-20-000036:mdna:223]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of August 1, 2020 totaled $1,164.2 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of August 1, 2020, letters of credit totaling $78.6 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of August 1, 2020.

[0000936395-20-000036:mdna:224]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $96.4 million as of August 1, 2020. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $28.0 million.

[0000936395-20-000036:mdna:225]
Stock Repurchase Authorization. On December 13, 2018, we announced that the Board of Directors authorized a program to repurchase up to $500 million of its common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020, we temporarily suspended purchases of our common stock under this program. We repurchased $74.5 million under this program during the first nine months of fiscal 2020, and had $275.4 million remaining under the current authorization as of August 1, 2020. The reinstatement of the program and amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be reinstated, modified, suspended, or discontinued at any time.

[0000936395-20-000036:mdna:226]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-20-000036:mdna:227]
[same as prior period, unchanged from 0000936395-20-000028:mdna:226]

[0000936395-20-000036:mdna:228]
The following sections set forth the components of our $306.4 million of cash provided by operating activities during the first nine months of fiscal 2020:

[0000936395-20-000036:mdna:229]
[same as prior period, unchanged from 0000936395-20-000028:mdna:228]

[0000936395-20-000036:mdna:230]
[same as prior period, unchanged from 0000936395-20-000028:mdna:229]

[0000936395-20-000036:mdna:231]
|  | Nine Months Ended |
|  | August 1, 2020 |
| Net income | $ | 296,250 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 70,370 |  |
| Share-based compensation costs | 50,838 |  |
| Amortization of intangible assets | 29,035 |  |
| Deferred taxes | 57,636 |  |
| Provision for inventory excess and obsolescence | 20,176 |  |
| Provision for warranty | 19,172 |  |
| Other | 15,085 |  |
| Net income (adjusted for non-cash charges) | $ | 558,562 |  |

[0000936395-20-000036:mdna:232]
[same as prior period, unchanged from 0000936395-20-000028:mdna:231]

[0000936395-20-000036:mdna:233]
We used $252.2 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-20-000036:mdna:234]
|  | Nine Months Ended |
|  | August 1, 2020 |
| Cash used in accounts receivable | $ | (6,688) |  |
| Cash used in inventories | (39,568) |  |
| Cash used in prepaid expenses and other | (52,945) |  |
| Cash used in accounts payable, accruals and other obligations | (131,647) |  |
| Cash used in deferred revenue | (19,039) |  |
| Cash used in operating lease assets and liabilities, net | (2,316) |  |
| Total cash used for working capital | $ | (252,203) |  |

[0000936395-20-000036:mdna:235]
[same as prior period, unchanged from 0000936395-20-000028:mdna:234]

[0000936395-20-000036:mdna:236]
•The $6.7 million of cash used by accounts receivable during the first nine months of fiscal 2020 reflects increased sales volume, partially offset by increased cash collections;

[0000936395-20-000036:mdna:237]
•The $39.6 million of cash used in inventories during the first nine months of fiscal 2020 primarily reflects increases in finished goods to meet customer delivery schedules and related to some of the actions that we took during the second and third quarters of fiscal 2020 to mitigate the risk of adverse supply chain impact on our business and operations due to COVID-19 related disruptions;

[0000936395-20-000036:mdna:238]
•The $52.9 million of cash used in prepaid expense and other during the first nine months of fiscal 2020 primarily reflects increases in upfront future discounts paid to customers and higher non-customer receivables;

[0000936395-20-000036:mdna:239]
•The $131.6 million of cash used in accounts payable, accruals and other obligations during the first nine months of fiscal 2020 primarily reflects the timing of payments for bonuses to employees under our annual cash incentive compensation plan and inventory purchases;

[0000936395-20-000036:mdna:240]
•The $19.0 million of cash used in deferred revenue during the first nine months of fiscal 2020 represents a decrease in advanced payments received from customers prior to revenue recognition; and

[0000936395-20-000036:mdna:241]
•The $2.3 million of cash used in operating lease assets and liabilities, net, during the first nine months of fiscal 2020 represents cash paid for operating leases. For more details, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-20-000036:mdna:242]
Our days sales outstanding (“DSOs”) for the first nine months of fiscal 2020 were 81 days, and our inventory turns for the first nine months of fiscal 2020 were 4.5. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-20-000036:mdna:243]
[same as prior period, unchanged from 0000936395-20-000028:mdna:243]

[0000936395-20-000036:mdna:244]
[same as prior period, unchanged from 0000936395-20-000028:mdna:244]

[0000936395-20-000036:mdna:245]
|  | Nine Months Ended |
|  | August 1, 2020 |
| Term Loan due September 28, 2025 (Old) (1) | $ | 6,691 |  |
| Term Loan due September 28, 2025 (New) (2) | 8,926 |  |
| Interest rate swaps(3) | 4,762 |  |
| ABL Credit Facility(4) | 1,320 |  |
| Finance leases | 3,579 |  |
| Cash paid during period | $ | 25,278 |  |

[0000936395-20-000036:mdna:246]
[same as prior period, unchanged from 0000936395-20-000028:mdna:246]

[0000936395-20-000036:mdna:247]
(2) Interest on the New 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The New 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the third quarter of fiscal 2020, the interest rate on the New 2025 Term Loan was 1.94%.

[0000936395-20-000036:mdna:248]
[same as prior period, unchanged from 0000936395-20-000028:mdna:248]

[0000936395-20-000036:mdna:249]
(4) During the first nine months of fiscal 2020, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.3 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-20-000036:mdna:250]
[same as prior period, unchanged from 0000936395-20-000028:mdna:250]

[0000936395-20-000036:mdna:251]
[same as prior period, unchanged from 0000936395-20-000028:mdna:251]

[0000936395-20-000036:mdna:252]
[same as prior period, unchanged from 0000936395-20-000028:mdna:252]

[0000936395-20-000036:mdna:253]
[same as prior period, unchanged from 0000936395-20-000028:mdna:253]

[0000936395-20-000036:mdna:254]
[same as prior period, unchanged from 0000936395-20-000028:mdna:254]

[0000936395-20-000036:mdna:255]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of our estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-20-000036:mdna:256]
[same as prior period, unchanged from 0000936395-20-000028:mdna:256]

[0000936395-20-000036:mdna:257]
[same as prior period, unchanged from 0000936395-20-000028:mdna:257]

[0000936395-20-000036:mdna:258]
[same as prior period, unchanged from 0000936395-20-000028:mdna:258]

[0000936395-20-000036:mdna:259]
[same as prior period, unchanged from 0000936395-20-000028:mdna:259]

[0000936395-20-000036:mdna:260]
[same as prior period, unchanged from 0000936395-20-000028:mdna:260]
