# CIEN note change history — 0000936395-20-000028 → 0000936395-20-000036


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:1]
COMMITMENTS AND CONTINGENCIES
Canadian Grant
  (was, 2020-06-10, similarity 0.7945):
[0000936395-20-000028:note_history:1]
COMMITMENTS AND CONTINGENCIES

- changed (2020-09-09):
[0000936395-20-000036:note_history:2]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $42.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of August 1, 2020, Ciena has recorded CAD$37.0 million (approximately $27.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$8.1 million ($6.0 million) was recorded in the first nine months of fiscal 2020. As of August 1, 2020, amounts receivable from this grant were CAD$7.0 million ($5.2 million).
  (was, 2020-06-10, similarity 0.9696):
[0000936395-20-000028:note_history:2]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $40.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 2, 2020, Ciena has recorded CAD$34.5 million (approximately $24.5 million) in cumulative benefits as a reduction in research and development expense of which CAD$5.6 million ($4.2 million) was recorded in the first six months of fiscal 2020. As of May 2, 2020, amounts receivable from this grant were CAD$7.3 million ($5.2 million).

- removed (2020-09-09):
[0000936395-20-000028:note_history:3]
Canadian Grant


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:4]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions and estimates reflected the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. The actual results that Ciena experiences may differ materially from such inputs into Ciena’s critical and significant accounting estimates. As the duration and severity of the COVID-19 pandemic are unclear, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility as compared to prior periods. As events continue to evolve, Ciena’s estimates may change materially in future periods.
  (was, 2020-06-10, similarity 0.9572):
[0000936395-20-000028:note_history:4]
The preparation of financial statements and related disclosures in conformity with GAAP requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions and estimates reflected the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. The actual results that Ciena experiences may differ materially from such inputs into Ciena’s critical and significant accounting estimates. As the duration and severity of the COVID-19 pandemic are unclear, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility as compared to prior periods. As events continue to evolve, Ciena’s estimates may change materially in future periods.

- changed (2020-09-09):
[0000936395-20-000036:note_history:5]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2019 (the “2019 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years and quarterly periods ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its quarters ended on January 31, April 30, July 31 and October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. References to prior reported periods have been changed to reflect the actual period end dates of August 1, 2020, August 3, 2019, November 2, 2019 and November 3, 2018 for periods reported herein.
  (was, 2020-06-10, similarity 0.9739):
[0000936395-20-000028:note_history:5]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2019 (the “2019 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years and quarterly periods ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its quarters ended on January 31, April 30, July 31 and October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. References to prior reported periods have been changed to reflect the actual period end dates of May 2, 2020, May 4, 2019, November 2, 2019 and November 3, 2018 for periods reported herein.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:6]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification (“ASC”) 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 3, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment,
  (was, 2020-06-10, similarity 0.9196):
[0000936395-20-000028:note_history:6]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification ASC 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 3, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

- added (2020-09-09):
[0000936395-20-000036:note_history:7]
building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

- changed (2020-09-09):
[0000936395-20-000036:note_history:8]
Ciena adopted the guidance on a modified retrospective basis as of November 3, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient for disclosure, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient, Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities.
  (was, 2020-06-10, similarity 0.9834):
[0000936395-20-000028:note_history:8]
Ciena adopted the guidance on a modified retrospective basis as of November 3, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient for disclosure, Ciena has elected not to separate lease and non-lease components on operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass through operating expenses like common area maintenance and utilities.

- changed (2020-09-09):
[0000936395-20-000036:note_history:9]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.
  (was, 2020-06-10, similarity 0.9991):
[0000936395-20-000028:note_history:9]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

- changed (2020-09-09):
[0000936395-20-000036:note_history:10]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484) |  | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244) |  | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
  (was, 2020-06-10, similarity 0.9931):
[0000936395-20-000028:note_history:10]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:11]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to ROU assets.
  (was, 2020-06-10, similarity 0.9813):
[0000936395-20-000028:note_history:11]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets.

- changed (2020-09-09):
[0000936395-20-000036:note_history:12]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to ROU assets.
  (was, 2020-06-10, similarity 0.9767):
[0000936395-20-000028:note_history:12]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets.

- changed (2020-09-09):
[0000936395-20-000036:note_history:13]
In August 2018, the FASB issued Accounting Standards Update (“ASU”) No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.
  (was, 2020-06-10, similarity 0.9511):
[0000936395-20-000028:note_history:13]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

- changed (2020-09-09):
[0000936395-20-000036:note_history:14]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its Consolidated Financial Statements and related disclosures.
  (was, 2020-06-10, similarity 0.9763):
[0000936395-20-000028:note_history:14]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and related disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:15]
SHORT-TERM AND LONG-TERM DEBT 
New 2025 Term Loan
  (was, 2020-06-10, similarity 0.7838):
[0000936395-20-000028:note_history:15]
SHORT-TERM AND LONG-TERM DEBT

- changed (2020-09-09):
[0000936395-20-000036:note_history:16]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”) and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”).
  (was, 2020-06-10, similarity 0.9968):
[0000936395-20-000028:note_history:16]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”) and incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”).

- added (2020-09-09):
[0000936395-20-000036:note_history:17]
|  |  | August 1, 2020 |  |  |  |  |  |  |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 689,535 |  |  | $ | (1,659) |  |  | $ | (3,090) |  |  | $ | 684,786 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:18]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.1 million at August 1, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.
  (was, 2020-06-10, similarity 0.9605):
[0000936395-20-000028:note_history:18]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.2 million at May 2, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.3 million during the first six months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.

- changed (2020-09-09):
[0000936395-20-000036:note_history:19]
As of August 1, 2020, the estimated fair value of the New 2025 Term Loan was $685.2 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2020-06-10, similarity 0.986):
[0000936395-20-000028:note_history:19]
As of May 2, 2020, the estimated fair value of the New 2025 Term Loan was $677.4 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2020-09-09):
[0000936395-20-000028:note_history:20]
New 2025 Term Loan

- removed (2020-09-09):
[0000936395-20-000028:note_history:21]
|  |  | May 2, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 691,268 |  |  | $ | (1,742 | ) |  | $ | (3,240 | ) |  | $ | 686,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:22]
|  | August 1, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
|  | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
  (was, 2020-06-10, similarity 0.9517):
[0000936395-20-000028:note_history:22]
|  | May 2, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:23]
|  | November 2, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3) |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3) |  |  | $ | 119,954 |  |
  (was, 2020-06-10, similarity 0.9469):
[0000936395-20-000028:note_history:23]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:24]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2020-06-10, similarity 0.8213):
[0000936395-20-000028:note_history:24]
As of the dates indicated, investments are comprised of the following (in thousands):

- changed (2020-09-09):
[0000936395-20-000036:note_history:25]
|  | August 1, 2020 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
|  | $ | 70,093 |  |  | $ | 311 |  |  | $ | — |  |  | $ | 70,404 |  |
  (was, 2020-06-10, similarity 0.9517):
[0000936395-20-000028:note_history:25]
|  | May 2, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 626 |  |  | $ | — |  |  | $ | 100,742 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:26]
|  | November 2, 2019 |  |  |  |  |  |  |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3) |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3) |  |  | $ | 119,954 |  |
  (was, 2020-06-10, similarity 0.9469):
[0000936395-20-000028:note_history:26]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:27]
The following table summarizes the final legal maturities of debt investments at August 1, 2020 (in thousands):
  (was, 2020-06-10, similarity 0.9668):
[0000936395-20-000028:note_history:27]
The following table summarizes the final legal maturities of debt investments at May 2, 2020 (in thousands):

- changed (2020-09-09):
[0000936395-20-000036:note_history:28]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 70,093 |  |  | $ | 70,404 |  |
  (was, 2020-06-10, similarity 0.8713):
[0000936395-20-000028:note_history:28]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 100,116 |  |  | $ | 100,742 |  |
|  | $ | 100,116 |  |  | $ | 100,742 |  |

- removed (2020-09-09):
[0000936395-20-000028:note_history:29]
SHORT-TERM AND LONG-TERM INVESTMENTS


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2020-09-09):
[0000936395-20-000036:note_history:30]
|  |  | August 1, 2020 |  |  |  |  |  |  |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 689,535 |  |  | $ | (1,659) |  |  | $ | (3,090) |  |  | $ | 684,786 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- removed (2020-09-09):
[0000936395-20-000028:note_history:31]
|  |  | May 2, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 691,268 |  |  | $ | (1,742 | ) |  | $ | (3,240 | ) |  | $ | 686,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:32]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):
  (was, 2020-06-10, similarity 0.8469):
[0000936395-20-000028:note_history:32]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:

- changed (2020-09-09):
[0000936395-20-000036:note_history:33]
|  | Quarter Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Packet Networking | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
  (was, 2020-06-10, similarity 0.9859):
[0000936395-20-000028:note_history:33]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Packet Networking | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:34]
|  | Quarter Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 12,657 |  |  | $ | 1,941 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 24,655 |  |  | 8,589 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
  (was, 2020-06-10, similarity 0.9859):
[0000936395-20-000028:note_history:34]
|  | Quarter Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 11,101 |  |  | $ | 3,047 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 24,128 |  |  | 9,426 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:35]
|  | Nine Months Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Packet Networking | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
  (was, 2020-06-10, similarity 0.9829):
[0000936395-20-000028:note_history:35]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Packet Networking | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,518 |  |  | $ | 30,092 |  |  | $ | 8,482 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,518 |  |  | $ | 96,873 |  |  | $ | 30,483 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:36]
|  | Nine Months Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 39,801 |  |  | $ | 11,216 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Services transferred over time | — |  |  | 74,338 |  |  | 26,761 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
  (was, 2020-06-10, similarity 0.9829):
[0000936395-20-000028:note_history:36]
|  | Six Months Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 27,145 |  |  | $ | 9,275 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 49,682 |  |  | 18,172 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:37]
|  |  | Quarter Ended |  |  |  | Nine Months Ended |  |  |
|  |  | August 1, |  | August 3, |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 713,340 |  |  | $ | 656,261 |  |  | $ | 1,937,725 |  |  | 1,788,234 |  |
| EMEA |  | 162,465 |  |  | 169,532 |  |  | 433,861 |  |  | 413,715 |  |
| APAC |  | 100,907 |  |  | 134,813 |  |  | 332,091 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 976,712 |  |  | $ | 960,606 |  |  | $ | 2,703,677 |  |  | $ | 2,604,144 |  |
  (was, 2020-06-10, similarity 0.8842):
[0000936395-20-000028:note_history:37]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 650,381 |  |  | $ | 615,492 |  |  | $ | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |

- removed (2020-09-09):
[0000936395-20-000028:note_history:38]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-09-09):
[0000936395-20-000036:note_history:39]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):
  (was, 2020-06-10, similarity 0.8469):
[0000936395-20-000028:note_history:39]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:

- changed (2020-09-09):
[0000936395-20-000036:note_history:40]
|  | Quarter Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Packet Networking | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
  (was, 2020-06-10, similarity 0.9859):
[0000936395-20-000028:note_history:40]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Packet Networking | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:41]
|  | Quarter Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 12,657 |  |  | $ | 1,941 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 24,655 |  |  | 8,589 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 37,312 |  |  | $ | 10,530 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
  (was, 2020-06-10, similarity 0.9859):
[0000936395-20-000028:note_history:41]
|  | Quarter Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 623,838 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 623,838 |  |
| Packet Networking | 73,138 |  |  | — |  |  | — |  |  | — |  |  | 73,138 |  |
| Platform Software and Services | — |  |  | 35,229 |  |  | — |  |  | — |  |  | 35,229 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 12,473 |  |  | — |  |  | 12,473 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 68,788 |  |  | 68,788 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,322 |  |  | 41,322 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,223 |  |  | 10,223 |  |
| Total revenue by product line | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 696,976 |  |  | $ | 11,101 |  |  | $ | 3,047 |  |  | $ | 5,575 |  |  | $ | 716,699 |  |
| Services transferred over time | — |  |  | 24,128 |  |  | 9,426 |  |  | 114,758 |  |  | 148,312 |  |
| Total revenue by timing of revenue recognition | $ | 696,976 |  |  | $ | 35,229 |  |  | $ | 12,473 |  |  | $ | 120,333 |  |  | $ | 865,011 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:42]
|  | Nine Months Ended August 1, 2020 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Packet Networking | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
  (was, 2020-06-10, similarity 0.9829):
[0000936395-20-000028:note_history:42]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Packet Networking | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,518 |  |  | $ | 30,092 |  |  | $ | 8,482 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,518 |  |  | $ | 96,873 |  |  | $ | 30,483 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:43]
|  | Nine Months Ended August 3, 2019 |  |  |  |  |  |  |  |  |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 39,801 |  |  | $ | 11,216 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Services transferred over time | — |  |  | 74,338 |  |  | 26,761 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 114,139 |  |  | $ | 37,977 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
  (was, 2020-06-10, similarity 0.9829):
[0000936395-20-000028:note_history:43]
|  | Six Months Ended May 4, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,172,835 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,172,835 |  |
| Packet Networking | 144,707 |  |  | — |  |  | — |  |  | — |  |  | 144,707 |  |
| Platform Software and Services | — |  |  | 76,827 |  |  | — |  |  | — |  |  | 76,827 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,447 |  |  | — |  |  | 27,447 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 130,065 |  |  | 130,065 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 71,944 |  |  | 71,944 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,713 |  |  | 19,713 |  |
| Total revenue by product line | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,317,542 |  |  | $ | 27,145 |  |  | $ | 9,275 |  |  | $ | 9,141 |  |  | $ | 1,363,103 |  |
| Services transferred over time | — |  |  | 49,682 |  |  | 18,172 |  |  | 212,581 |  |  | 280,435 |  |
| Total revenue by timing of revenue recognition | $ | 1,317,542 |  |  | $ | 76,827 |  |  | $ | 27,447 |  |  | $ | 221,722 |  |  | $ | 1,643,538 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:44]
|  |  | Quarter Ended |  |  |  | Nine Months Ended |  |  |
|  |  | August 1, |  | August 3, |  | August 1, |  | August 3, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 713,340 |  |  | $ | 656,261 |  |  | $ | 1,937,725 |  |  | 1,788,234 |  |
| EMEA |  | 162,465 |  |  | 169,532 |  |  | 433,861 |  |  | 413,715 |  |
| APAC |  | 100,907 |  |  | 134,813 |  |  | 332,091 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 976,712 |  |  | $ | 960,606 |  |  | $ | 2,703,677 |  |  | $ | 2,604,144 |  |
  (was, 2020-06-10, similarity 0.8842):
[0000936395-20-000028:note_history:44]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 2, |  | May 4, |  | May 2, |  | May 4, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 650,381 |  |  | $ | 615,492 |  |  | $ | 1,224,385 |  |  | 1,131,973 |  |
| EMEA |  | 141,431 |  |  | 114,993 |  |  | 271,396 |  |  | 244,183 |  |
| APAC |  | 102,241 |  |  | 134,526 |  |  | 231,184 |  |  | 267,382 |  |
| Total revenue by geographic distribution |  | $ | 894,053 |  |  | $ | 865,011 |  |  | $ | 1,726,965 |  |  | $ | 1,643,538 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:45]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines.
  (was, 2020-06-10, similarity 0.9356):
[0000936395-20-000028:note_history:45]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:46]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system (“Waveserver”), the family of CoreDirector® Multiservice Optical Switches and the Optical Transport Network (OTN) configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform.
  (was, 2020-06-10, similarity 0.9465):
[0000936395-20-000028:note_history:46]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system (“Waveserver”), the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:47]
◦Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.
  (was, 2020-06-10, similarity 0.989):
[0000936395-20-000028:note_history:47]
| • | Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:48]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features
  (was, 2020-06-10, similarity 0.7851):
[0000936395-20-000028:note_history:48]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- added (2020-09-09):
[0000936395-20-000036:note_history:49]
embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- changed (2020-09-09):
[0000936395-20-000036:note_history:50]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2020-06-10, similarity 0.9964):
[0000936395-20-000028:note_history:50]
| • | Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:51]
•Blue Planet® Automation Software and Services is a comprehensive, open software suite, together with related services, that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management, unified assurance and analytics (UAA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2020-06-10, similarity 0.9968):
[0000936395-20-000028:note_history:51]
| • | Blue Planet® Automation Software and Services is a comprehensive, open software suite, together with related services, that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management, unified assurance and analytics (UAA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:52]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2020-06-10, similarity 0.9914):
[0000936395-20-000028:note_history:52]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service. |

- changed (2020-09-09):
[0000936395-20-000036:note_history:53]
|  |  | Balance at August 1, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 715,195 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 97,373 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 136,870 |  |  | $ | 156,873 |  |
  (was, 2020-06-10, similarity 0.8764):
[0000936395-20-000028:note_history:53]
|  |  | Balance at May 2, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 693,963 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 87,746 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 149,917 |  |  | $ | 156,873 |  |

- changed (2020-09-09):
[0000936395-20-000036:note_history:54]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $91.8 million and $77.4 million of revenue during the first nine months of fiscal 2020 and 2019 that was included in the deferred revenue balance at November 2, 2019 and November 3, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 1, 2020 and August 3, 2019.
  (was, 2020-06-10, similarity 0.925):
[0000936395-20-000028:note_history:54]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $76.5 million and $73.0 million of revenue during the first six months of fiscal 2020 and 2019 that was included in the deferred revenue balance at November 2, 2019 and November 3, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 2, 2020 and May 4, 2019.

- changed (2020-09-09):
[0000936395-20-000036:note_history:55]
Capitalized contract acquisition costs consist of deferred sales commissions, were $13.0 million and $15.7 million as of August 1, 2020 and November 2, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $16.2 million and $12.5 million during the first nine months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.
  (was, 2020-06-10, similarity 0.9756):
[0000936395-20-000028:note_history:55]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.3 million and $15.7 million as of May 2, 2020 and November 2, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $10.1 million and $8.4 million during the first six months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.

- changed (2020-09-09):
[0000936395-20-000036:note_history:56]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of August 1, 2020, the aggregate amount of RPO was $970.6 million. As of August 1, 2020, Ciena expects approximately 82% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2020-06-10, similarity 0.9648):
[0000936395-20-000028:note_history:56]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 2, 2020, the aggregate amount of RPO was $1.078 billion. As of May 2, 2020, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.
