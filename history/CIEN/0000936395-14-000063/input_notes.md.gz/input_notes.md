# CIEN notes — 0000936395-14-000063


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-14-000063:notes:1]
Ciena expenses all advertising costs as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-14-000063:notes:2]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-14-000063:notes:3]
COMMITMENTS AND CONTINGENCIES

[0000936395-14-000063:notes:4]
Ontario Grant

[0000936395-14-000063:notes:5]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of October 31, 2014, Ciena has recorded a CAD$23.1 million benefit to date, as a reduction in research and development expenses. As of October 31, 2014, the amount receivable from this grant was CAD$3.1 million.

[0000936395-14-000063:notes:6]
Foreign Tax Contingencies

[0000936395-14-000063:notes:7]
As of October 31, 2013 and October 31, 2014, Ciena had accrued liabilities of $0.4 million and $0.5 million, respectively, related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 related to income taxes. This contingency has been reported as a component of other long-term liabilities. During February 2014, Ciena received a final audit assessment notice from the India tax authorities with respect to this matter. Ciena has filed an appeal citing deficiencies in this assessment. Although Ciena estimates that it could be exposed to possible losses of up to $1.5 million, it has not accrued a liability of such amount as of October 31, 2014. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to this assessment. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-14-000063:notes:8]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-14-000063:notes:9]
Litigation

[0000936395-14-000063:notes:10]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-14-000063:notes:11]
In addition to the matter described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-14-000063:notes:12]
Operating Lease Commitments

[0000936395-14-000063:notes:13]
Ciena has certain minimum obligations under non-cancelable operating leases expiring on various dates through 2032 for equipment and facilities. During the fourth quarter of fiscal 2014, the Company entered into a lease relating to office space for its new research and development center in Ottawa, Canada, consisting of a rentable area of approximately 170,582 square feet. The future minimum rental commitments to be paid over the 18-year lease term are approximately $49.1 million. Future annual minimum operating lease commitments under non-cancelable operating leases at October 31, 2014 are as follows (in thousands):

[0000936395-14-000063:notes:14]
| Year ended October 31, |  |
| 2015 | $ | 33,527 |  |
| 2016 | 31,605 |  |
| 2017 | 28,232 |  |
| 2018 | 15,675 |  |
| 2019 | 12,668 |  |
| Thereafter | 83,191 |  |
| Total | $ | 204,898 |  |

[0000936395-14-000063:notes:15]
Rental expense for fiscal 2012, fiscal 2013 and fiscal 2014 was approximately $21.7 million, $26.0 million and $22.9 million, respectively. In addition, Ciena paid approximately $1.4 million, $1.6 million and $0.5 million during fiscal 2012, fiscal 2013 and fiscal 2014, respectively, related to rent costs for restructured facilities and unfavorable lease commitments, which were offset against Ciena’s restructuring liabilities and unfavorable lease obligations. The amount for operating lease commitments above does not include variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material impact on Ciena's financial condition, results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-14-000063:notes:16]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-14-000063:notes:17]
OTHER EMPLOYEE BENEFIT PLANS

[0000936395-14-000063:notes:18]
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$24,930 for 2014). This plan includes a required employer contribution of 1% for all participants and a 50% matching of participant contributions up to a total annual maximum of CAD$3,000 per employee. During fiscal 2012, 2013 and 2014, Ciena made matching contributions of approximately CAD$4.0 million, CAD$3.9 million and CAD$4.1 million, respectively.

[0000936395-14-000063:notes:19]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of pre-tax compensation, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2012, 2013 and 2014, Ciena made matching contributions of approximately $4.1 million, $4.0 million and $4.5 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-14-000063:notes:20]
ACCUMULATED OTHER COMPREHENSIVE INCOME

[0000936395-14-000063:notes:21]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss):

[0000936395-14-000063:notes:22]
|  |  | Unrealized |  | Unrealized |  | Cumulative Foreign |  |  |
|  |  | Gain/(Loss) on |  | Gain/(Loss) on |  | Currency Translation |  |  |
|  |  | Marketable Securities |  | Derivative Instruments |  | Adjustment |  | Total |
| Balance at October 31, 2011 |  | 210 |  |  | — |  |  | (179 | ) |  | 31 |  |
| Other comprehensive income(loss) before reclassifications |  | (166 | ) |  | 812 |  |  | (3,268 | ) |  | (2,622 | ) |
| Amounts reclassified from AOCI |  | — |  |  | (763 | ) |  | — |  |  | (763 | ) |
| Balance at October 31, 2012 |  | 44 |  |  | 49 |  |  | (3,447 | ) |  | (3,354 | ) |
| Other comprehensive income(loss) before reclassifications |  | (14 | ) |  | (1,431 | ) |  | (4,096 | ) |  | (5,541 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 1,121 |  |  | — |  |  | 1,121 |  |
| Balance at October 31, 2013 |  | 30 |  |  | (261 | ) |  | (7,543 | ) |  | (7,774 | ) |
| Other comprehensive income(loss) before reclassifications |  | 41 |  |  | (3,348 | ) |  | (4,940 | ) |  | (8,247 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 1,353 |  |  | — |  |  | 1,353 |  |
| Balance at October 31, 2014 |  | 71 |  |  | (2,256 | ) |  | (12,483 | ) |  | (14,668 | ) |

[0000936395-14-000063:notes:23]
All amounts reclassified from accumulated other comprehensive income were related to settlement (gains)/losses on foreign currency forward contracts designated as cash flow hedges. These reclassifications impacted "research and development" on the Consolidated Statements of Operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000936395-14-000063:notes:24]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-14-000063:notes:25]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-14-000063:notes:26]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-14-000063:notes:27]
|  | October 31, |
|  | 2013 |  | 2014 |
| Products | $ | 36,671 |  |  | $ | 50,457 |  |
| Services | 75,499 |  |  | 95,161 |  |
|  | 112,170 |  |  | 145,618 |  |
| Less current portion | (88,550 | ) |  | (104,688 | ) |
| Long-term deferred revenue | $ | 23,620 |  |  | $ | 40,930 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-14-000063:notes:28]
DERIVATIVE INSTRUMENTS

[0000936395-14-000063:notes:29]
Foreign Currency Derivatives

[0000936395-14-000063:notes:30]
As of October 31, 2014 and 2013, Ciena had forward contracts to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $51.5 million and $22.4 million as of October 31, 2014 and October 31, 2013, respectively. These foreign exchange contracts have maturities of 12 months or less. These derivative contracts have been designated as cash flow hedges.

[0000936395-14-000063:notes:31]
During fiscal 2014 and fiscal 2013, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount. During fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. The notional principal of these contracts was approximately $194.5 million and $29.5 million as of October 31, 2014 and October 31, 2013. These foreign exchange contracts have maturities of 12 months or less. These derivative contracts have not been designated as hedges.

[0000936395-14-000063:notes:32]
Interest Rate Derivatives

[0000936395-14-000063:notes:33]
During fiscal 2014, Ciena entered into interest rate cap arrangements to limit interest paid under the Term Loan to a maximum of 0.75% plus a spread of 300 basis points through July 2015. The total notional amount of interest rate caps currently outstanding as of October 31, 2014 is $249.4 million.

[0000936395-14-000063:notes:34]
Also in fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004%, for the period commencing on July 20, 2015 through July 19, 2018.  The total notional amount of these derivatives as of October 31, 2014 is $247.5 million.

[0000936395-14-000063:notes:35]
Ciena expects the variable rate payments to be received under the terms of the interest rate cap and the interest rate swap to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-14-000063:notes:36]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 3 and Note 5 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-14-000063:notes:37]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") include a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature is recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 3 below.

[0000936395-14-000063:notes:38]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-14-000063:notes:39]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.

[0000936395-14-000063:notes:40]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-14-000063:notes:41]
SHARE-BASED COMPENSATION EXPENSE

[0000936395-14-000063:notes:42]
Ciena grants equity awards under its 2008 Omnibus Incentive Plan and the Amended and Restated Employee Stock Purchase Plan (“ESPP”).

[0000936395-14-000063:notes:43]
2008 Plan

[0000936395-14-000063:notes:44]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. Pursuant to Board and stockholder approval, effective April 10, 2014, Ciena amended its 2008 Plan to increase the number of shares available for issuance by 6.6 million shares.  As of October 31, 2014, the total number of shares authorized for issuance under the 2008 Plan is 25.1 million and approximately 9.3 million shares remained available for issuance thereunder.

[0000936395-14-000063:notes:45]
Stock Options

[0000936395-14-000063:notes:46]
Outstanding stock option awards to employees are generally subject to service-based vesting restrictions and vest incrementally over a four-year period. As of October 31, 2014, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena's stock option activity for the periods indicated (shares in thousands):

[0000936395-14-000063:notes:47]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of October 31, 2011 | 3,690 |  |  | $ | 30.01 |  |
| Granted | — |  |  | — |  |
| Exercised | (56 | ) |  | 6.72 |  |
| Canceled | (427 | ) |  | 51.28 |  |
| Balance as of October 31, 2012 | 3,207 |  |  | 27.58 |  |
| Granted | — |  |  | — |  |
| Exercised | (246 | ) |  | 13.81 |  |
| Canceled | (859 | ) |  | 31.83 |  |
| Balance as of October 31, 2013 | 2,102 |  |  | 27.46 |  |
| Granted | — |  |  | — |  |
| Exercised | (162 | ) |  | 16.99 |  |
| Canceled | (652 | ) |  | 34.08 |  |
| Balance as of October 31, 2014 | 1,288 |  |  | $ | 25.43 |  |

[0000936395-14-000063:notes:48]
The total intrinsic value of options exercised during fiscal 2012, fiscal 2013 and fiscal 2014 was $0.5 million, $2.0 million and $1.0 million, respectively. There were no stock options granted by Ciena during fiscal 2012, fiscal 2013 or fiscal 2014.

[0000936395-14-000063:notes:49]
The following table summarizes information with respect to stock options outstanding at October 31, 2014, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2014 (shares and intrinsic value in thousands):

[0000936395-14-000063:notes:50]
|  |  |  |  |  |  | Vested Options at |
|  |  |  |  |  |  | October 31, 2014 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining | Weighted |  |  |
| Range of |  | of |  | Contractual | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 154 |  |  | 3.28 | $ | 8.03 |  |  | $ | 1,347 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 184 |  |  | 0.95 | 16.55 |  |  | 42 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 195 |  |  | 1.19 | 18.71 |  |  | — |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 284 |  |  | 2.34 | 27.31 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 32.55 |  |  | 109 |  |  | 2.68 | 29.96 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 248 |  |  | 3.05 | 35.24 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 47.32 |  |  | 114 |  |  | 2.78 | 44.33 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 47.32 |  |  | 1,288 |  |  | 2.29 | $ | 25.43 |  |  | $ | 1,389 |  |

[0000936395-14-000063:notes:51]
Assumptions for Option-Based Awards

[0000936395-14-000063:notes:52]
Ciena recognizes the fair value of service-based options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2012, fiscal 2013, or fiscal 2014.

[0000936395-14-000063:notes:53]
Restricted Stock Units

[0000936395-14-000063:notes:54]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-14-000063:notes:55]
The following table is a summary of Ciena's restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena's closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-14-000063:notes:56]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of October 31, 2011 | 4,298 |  |  | $ | 16.28 |  |  | $ | 59,399 |  |
| Granted | 2,433 |  |  |  |  |  |
| Vested | (1,912 | ) |  |  |  |  |
| Canceled or forfeited | (416 | ) |  |  |  |  |
| Balance as of October 31, 2012 | 4,403 |  |  | 14.16 |  |  | 56,267 |  |
| Granted | 2,508 |  |  |  |  |  |
| Vested | (1,920 | ) |  |  |  |  |
| Canceled or forfeited | (572 | ) |  |  |  |  |
| Balance as of October 31, 2013 | 4,419 |  |  | 15.33 |  |  | 102,745 |  |
| Granted | 1,912 |  |  |  |  |  |
| Vested | (2,165 | ) |  |  |  |  |
| Canceled or forfeited | (154 | ) |  |  |  |  |
| Balance as of October 31, 2014 | 4,012 |  |  | $ | 18.02 |  |  | $ | 67,241 |  |

[0000936395-14-000063:notes:57]
The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2012, fiscal 2013 and fiscal 2014 was $27.0 million, $37.3 million and $48.1 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2012, fiscal 2013 and fiscal 2014 was $11.28, $16.30 and $21.82, respectively.

[0000936395-14-000063:notes:58]
Assumptions for Restricted Stock Unit Awards

[0000936395-14-000063:notes:59]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized, net of estimated forfeitures, ratably over the vesting period on a straight-line basis.

[0000936395-14-000063:notes:60]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-14-000063:notes:61]
Because share-based compensation expense is recognized only for those awards that are ultimately expected to vest, the amount of share-based compensation expense recognized reflects a reduction for estimated forfeitures. Ciena estimates forfeitures at the time of grant and revises those estimates in subsequent periods based upon new or changed information.

[0000936395-14-000063:notes:62]
Amended and Restated Employee Stock Purchase Plan (ESPP)

[0000936395-14-000063:notes:63]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP's “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-14-000063:notes:64]
During fiscal 2012, fiscal 2013 and fiscal 2014, Ciena issued 1.2 million, 0.9 million and 0.9 million shares under the ESPP, respectively. At October 31, 2014, 6.8 million shares remained available for issuance under the ESPP.

[0000936395-14-000063:notes:65]
Share-Based Compensation Expense for Periods Reported

[0000936395-14-000063:notes:66]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-14-000063:notes:67]
|  | Year Ended October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Product costs | $ | 2,156 |  |  | $ | 2,522 |  |  | $ | 2,531 |  |
| Service costs | 1,462 |  |  | 1,771 |  |  | 2,216 |  |
| Share-based compensation expense included in cost of goods sold | 3,618 |  |  | 4,293 |  |  | 4,747 |  |
| Research and development | 8,567 |  |  | 8,214 |  |  | 9,682 |  |
| Sales and marketing | 11,558 |  |  | 13,290 |  |  | 14,958 |  |
| General and administrative | 8,698 |  |  | 12,055 |  |  | 13,568 |  |
| Share-based compensation expense included in operating expense | 28,823 |  |  | 33,559 |  |  | 38,208 |  |
| Share-based compensation expense capitalized in inventory, net | (47 | ) |  | (132 | ) |  | (25 | ) |
| Total share-based compensation | $ | 32,394 |  |  | $ | 37,720 |  |  | $ | 42,930 |  |

[0000936395-14-000063:notes:68]
As of October 31, 2014, total unrecognized compensation expense was $57.2 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-14-000063:notes:69]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement.


## us-gaap:EarningsPerShareTextBlock

[0000936395-14-000063:notes:70]
EARNINGS (LOSS) PER SHARE CALCULATION

[0000936395-14-000063:notes:71]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Since the numerator reflects net losses for the fiscal years indicated, both Basic EPS and Diluted EPS are computed using the weighted average number of common shares outstanding. If the numerator reflected net income, Diluted EPS would also include, to the extent the effect is not anti-dilutive, the following: (i) shares issuable upon vesting of restricted stock units, (ii) shares issuable under Ciena's employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method; and (iii) shares underlying Ciena's outstanding convertible notes.

[0000936395-14-000063:notes:72]
Numerator

[0000936395-14-000063:notes:73]
|  | Year Ended October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Net loss | $ | (144,021 | ) |  | $ | (85,431 | ) |  | $ | (40,637 | ) |

[0000936395-14-000063:notes:74]
Denominator

[0000936395-14-000063:notes:75]
|  | Year Ended October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Basic weighted average shares outstanding | 99,341 |  |  | 102,350 |  |  | 105,783 |  |
| Dilutive weighted average shares outstanding | 99,341 |  |  | 102,350 |  |  | 105,783 |  |

[0000936395-14-000063:notes:76]
EPS

[0000936395-14-000063:notes:77]
|  | Year Ended October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Basic EPS | $ | (1.45 | ) |  | $ | (0.83 | ) |  | $ | (0.38 | ) |
| Diluted EPS | $ | (1.45 | ) |  | $ | (0.83 | ) |  | $ | (0.38 | ) |

[0000936395-14-000063:notes:78]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-14-000063:notes:79]
|  | Year Ended October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Shares underlying stock options and restricted stock units | 5,726 |  |  | 3,890 |  |  | 3,176 |  |
| 0.25% Convertible Senior Notes due May 1, 2013 | 5,470 |  |  | 2,682 |  |  | — |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 18,395 |  |  | 10,541 |  |  | 9,198 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,355 |  |  | 17,355 |  |  | 17,355 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 7,855 |  |  | 9,198 |  |
| Total excluded due to anti-dilutive effect | 60,054 |  |  | 55,431 |  |  | 52,035 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-14-000063:notes:80]
As of the date indicated, the following tables summarizes the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-14-000063:notes:81]
|  | October 31, 2013 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 254,330 |  |  | $ | — |  |  | $ | — |  |  | $ | 254,330 |  |
| U.S. government obligations | — |  |  | 115,016 |  |  | — |  |  | 115,016 |  |
| Commercial paper | — |  |  | 44,991 |  |  | — |  |  | 44,991 |  |
| Embedded redemption feature | — |  |  | — |  |  | 2,740 |  |  | 2,740 |  |
| Total assets measured at fair value | $ | 254,330 |  |  | $ | 160,007 |  |  | $ | 2,740 |  |  | $ | 417,077 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 442 |  |  | $ | — |  |  | $ | 442 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 442 |  |  | $ | — |  |  | $ | 442 |  |

[0000936395-14-000063:notes:82]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 440,013 |  |  | $ | — |  |  | $ | — |  |  | $ | 440,013 |  |
| U.S. government obligations | — |  |  | 160,268 |  |  | — |  |  | 160,268 |  |
| Commercial paper | — |  |  | 89,989 |  |  | — |  |  | 89,989 |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,561 |  |  | $ | — |  |  | $ | 1,561 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Forward interest rate swap contract | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisUnobservableInputReconciliationTextBlock

[0000936395-14-000063:notes:83]
As of the dates indicated, the following table sets forth, in thousands, the reconciliation of changes in Level 3 assets recorded at fair value:

[0000936395-14-000063:notes:84]
|  | Level 3 |
| Balance at October 31, 2013 | $ | 2,740 |  |
| Issuances | — |  |
| Settlements | — |  |
| Changes in unrealized loss | (2,740 | ) |
| Transfers into Level 3 | — |  |
| Transfers out of Level 3 | — |  |
| Balance at October 31, 2014 | $ | — |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-14-000063:notes:85]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-14-000063:notes:86]
|  | October 31, 2013 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 252,241 |  |  | $ | 19,997 |  |  | $ | — |  |  | $ | 272,238 |  |
| Short-term investments | — |  |  | 124,979 |  |  | — |  |  | 124,979 |  |
| Prepaid expenses and other | 52 |  |  | — |  |  | — |  |  | 52 |  |
| Long-term investments | — |  |  | 15,031 |  |  | — |  |  | 15,031 |  |
| Other long-term assets | 2,037 |  |  | — |  |  | 2,740 |  |  | 4,777 |  |
| Total assets measured at fair value | $ | 254,330 |  |  | $ | 160,007 |  |  | $ | 2,740 |  |  | $ | 417,077 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 442 |  |  | $ | — |  |  | 442 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 442 |  |  | $ | — |  |  | $ | 442 |  |

[0000936395-14-000063:notes:87]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 440,013 |  |  | $ | 59,995 |  |  | $ | — |  |  | $ | 500,008 |  |
| Short-term investments | — |  |  | 140,205 |  |  | — |  |  | 140,205 |  |
| Prepaid expenses and other | — |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Long-term investments | — |  |  | 50,057 |  |  | — |  |  | 50,057 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Other long-term obligations | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-14-000063:notes:88]
FAIR VALUE MEASUREMENTS

[0000936395-14-000063:notes:89]
Ciena’s Level 3 assets that were included in other long-term assets reflect an embedded redemption feature contained within the 2015 Notes. The embedded redemption feature is bifurcated from the 2015 Notes using the “with-and-without” approach. As such, the total value of the embedded redemption feature is calculated as the difference between the value of the 2015 Notes (the “Hybrid Instrument”) and the value of an identical instrument without the embedded redemption feature (the “Host Instrument”). Both the Host Instrument and the Hybrid Instrument are valued using a modified binomial model. The modified binomial model utilizes a risk free interest rate, an implied volatility of Ciena’s stock, the recovery rates of bonds and the implied default intensity of the 2015 Notes. The value of this feature was immaterial at October 31, 2014.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-14-000063:notes:90]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 3 below.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-14-000063:notes:91]
Long-lived assets include: equipment, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-14-000063:notes:92]
INCOME TAXES

[0000936395-14-000063:notes:93]
For the periods indicated, the provision for income taxes consists of the following (in thousands):

[0000936395-14-000063:notes:94]
|  | October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Provision for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | — |  |  | $ | — |  |  | $ | — |  |
| State | 857 |  |  | 906 |  |  | 1,831 |  |
| Foreign | 8,465 |  |  | 4,334 |  |  | 12,133 |  |
| Total current | 9,322 |  |  | 5,240 |  |  | 13,964 |  |
| Deferred: |  |  |  |  |  |
| Federal | — |  |  | — |  |  | — |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | — |  |  | — |  |  | — |  |
| Total deferred | — |  |  | — |  |  | — |  |
| Provision for income taxes | $ | 9,322 |  |  | $ | 5,240 |  |  | $ | 13,964 |  |

[0000936395-14-000063:notes:95]
For the periods indicated, income (loss) before provision for income taxes consists of the following (in thousands):

[0000936395-14-000063:notes:96]
|  | October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| United States | $ | (151,958 | ) |  | $ | (59,594 | ) |  | $ | (42,742 | ) |
| Foreign | 17,259 |  |  | (20,597 | ) |  | 16,069 |  |
| Total | $ | (134,699 | ) |  | $ | (80,191 | ) |  | $ | (26,673 | ) |

[0000936395-14-000063:notes:97]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income or loss before income taxes by the U.S. federal statutory rate of 35% as follows:

[0000936395-14-000063:notes:98]
|  | October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| Provision at statutory rate | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State taxes | (0.64 | )% |  | (1.13 | )% |  | (6.87 | )% |
| Foreign taxes | (5.09 | )% |  | (12.70 | )% |  | (70.25 | )% |
| Research and development credit | 10.21 | % |  | 17.39 | % |  | 32.07 | % |
| Non-deductible loss on debt extinguishment | — | % |  | (11.21 | )% |  | — | % |
| Non-deductible compensation and other | (4.92 | )% |  | (8.78 | )% |  | (29.59 | )% |
| Valuation allowance | (41.48 | )% |  | (25.10 | )% |  | (12.71 | )% |
| Effective income tax rate | (6.92 | )% |  | (6.53 | )% |  | (52.35 | )% |

[0000936395-14-000063:notes:99]
The significant components of deferred tax assets and liabilities are as follows (in thousands):

[0000936395-14-000063:notes:100]
|  | October 31, |
|  | 2013 |  | 2014 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 44,515 |  |  | $ | 59,707 |  |
| Depreciation and amortization | 274,468 |  |  | 268,783 |  |
| NOL and credit carry forward | 1,159,494 |  |  | 1,155,389 |  |
| Other | 8,822 |  |  | 12,956 |  |
| Gross deferred tax assets | 1,487,299 |  |  | 1,496,835 |  |
| Valuation allowance | (1,487,299 | ) |  | (1,496,835 | ) |
| Net deferred tax asset | $ | — |  |  | $ | — |  |

[0000936395-14-000063:notes:101]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-14-000063:notes:102]
| Unrecognized tax benefits at October 31, 2011 | $ | 8,590 |  |
| Decrease related to positions taken in prior period | (12 | ) |
| Increase related to positions taken in current period | 2,866 |  |
| Reductions related to expiration of statute of limitations | (392 | ) |
| Unrecognized tax benefits at October 31, 2012 | 11,052 |  |
| Decrease related to positions taken in prior period | (3,925 | ) |
| Increase related to positions taken in current period | 2,146 |  |
| Reductions related to expiration of statute of limitations | (994 | ) |
| Unrecognized tax benefits at October 31, 2013 | 8,279 |  |
| Increase related to positions taken in prior period | 2,479 |  |
| Increase related to positions taken in current period | 5,241 |  |
| Reductions related to expiration of statute of limitations | (899 | ) |
| Unrecognized tax benefits at October 31, 2014 | $ | 15,100 |  |

[0000936395-14-000063:notes:103]
As of October 31, 2013 and 2014, Ciena had accrued $1.4 million and $3.4 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $0.3 million and $2.0 million were recorded to the provision for income taxes during fiscal 2012 and fiscal 2014 respectively, and no such charges or benefits were recorded for fiscal 2013. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-14-000063:notes:104]
During fiscal 2002, Ciena established a valuation allowance against its deferred tax assets. Ciena intends to maintain a valuation allowance until sufficient positive evidence exists to support a reversal. Any future release of the valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements. The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-14-000063:notes:105]
| Year ended |  | Balance at beginning |  |  |  |  |  | Balance at end |
| October 31, |  | of fiscal year |  | Additions |  | Deductions |  | of fiscal year |
| 2012 |  | $ | 1,467,411 |  |  | $ | 21,583 |  |  | $ | — |  |  | $ | 1,488,994 |  |
| 2013 |  | $ | 1,488,994 |  |  | $ | — |  |  | $ | 1,695 |  |  | $ | 1,487,299 |  |
| 2014 |  | $ | 1,487,299 |  |  | $ | 9,536 |  |  | $ | — |  |  | $ | 1,496,835 |  |

[0000936395-14-000063:notes:106]
As of October 31, 2014, Ciena had a $2.8 billion net operating loss carry forward and a $0.1 billion income tax credit carry forward which begin to expire in fiscal year 2018 and 2019, respectively. Ciena’s ability to use net operating losses and credit carry forwards is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0000936395-14-000063:notes:107]
The income tax provision does not reflect the tax savings resulting from deductions associated with Ciena’s equity compensation and the call spread option associated with Ciena’s convertible debt. The cumulative tax benefit through October 31, 2014 of approximately $81.0 million will be credited to additional paid-in capital when realized. For deductions associated with Ciena’s equity compensation, credits to paid-in capital will be recorded when those tax benefits are used to reduce taxes payable.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-14-000063:notes:108]
Ciena accounts for income taxes using an asset and liability approach that recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-14-000063:notes:109]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2009) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-14-000063:notes:110]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and any expansion requirements.

[0000936395-14-000063:notes:111]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-14-000063:notes:112]
INTANGIBLE ASSETS

[0000936395-14-000063:notes:113]
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-14-000063:notes:114]
|  | October 31, |
|  | 2013 |  | 2014 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (321,645 | ) |  | $ | 96,188 |  |  | $ | 417,833 |  |  | $ | (351,929 | ) |  | $ | 65,904 |  |
| Patents and licenses | 46,538 |  |  | (45,744 | ) |  | 794 |  |  | 46,538 |  |  | (45,908 | ) |  | 630 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (234,727 | ) |  | 88,846 |  |  | 323,573 |  |  | (261,430 | ) |  | 62,143 |  |
| Total intangible assets | $ | 787,944 |  |  | $ | (602,116 | ) |  | $ | 185,828 |  |  | $ | 787,944 |  |  | $ | (659,267 | ) |  | $ | 128,677 |  |

[0000936395-14-000063:notes:115]
The aggregate amortization expense of intangible assets was $74.5 million, $71.3 million and $57.2 million for fiscal 2012, fiscal 2013 and fiscal 2014, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-14-000063:notes:116]
| Year Ended October 31, |  |
| 2015 | $ | 52,879 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 136 |  |
| 2019 | — |  |
|  | $ | 128,677 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-14-000063:notes:117]
INVENTORIES

[0000936395-14-000063:notes:118]
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-14-000063:notes:119]
|  | October 31, |
|  | 2013 |  | 2014 |
| Raw materials | $ | 53,274 |  |  | $ | 64,853 |  |
| Work-in-process | 7,773 |  |  | 8,371 |  |
| Finished goods | 153,855 |  |  | 165,799 |  |
| Deferred cost of goods sold | 75,764 |  |  | 75,763 |  |
|  | 290,666 |  |  | 314,786 |  |
| Provision for excess and obsolescence | (41,563 | ) |  | (60,126 | ) |
|  | $ | 249,103 |  |  | $ | 254,660 |  |

[0000936395-14-000063:notes:120]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During fiscal 2013 and fiscal 2014, recorded provisions for inventory reserves were primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.

[0000936395-14-000063:notes:121]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-14-000063:notes:122]
|  |  | Balance at |  |  |  |  |  |  |
| Year ended |  | beginning of |  |  |  |  |  | Balance at |
| October 31, |  | fiscal year |  | Provisions |  | Disposals |  | end of fiscal year |
| 2012 |  | $ | 31,771 |  |  | $ | 23,438 |  |  | $ | 15,199 |  |  | $ | 40,010 |  |
| 2013 |  | $ | 40,010 |  |  | $ | 19,938 |  |  | $ | 18,385 |  |  | $ | 41,563 |  |
| 2014 |  | $ | 41,563 |  |  | $ | 32,332 |  |  | $ | 13,769 |  |  | $ | 60,126 |  |


## us-gaap:InventoryPolicyTextBlock

[0000936395-14-000063:notes:123]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-14-000063:notes:124]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions.


## us-gaap:InvestmentPolicyTextBlock

[0000936395-14-000063:notes:125]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-14-000063:notes:126]
The following table summarizes the legal maturities of debt investments at October 31, 2014:

[0000936395-14-000063:notes:127]
|  | October 31, 2014 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 140,176 |  |  | $ | 140,205 |  |
| Due in 1-2 years | 50,016 |  |  | 50,057 |  |
|  | $ | 190,192 |  |  | $ | 190,262 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-14-000063:notes:128]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-14-000063:notes:129]
As of October 31, 2013, investments are comprised of the following (in thousands):

[0000936395-14-000063:notes:130]
|  | October 31, 2013 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 99,974 |  |  | $ | 11 |  |  | $ | — |  |  | $ | 99,985 |  |
| Included in long-term investments | 14,996 |  |  | 35 |  |  | — |  |  | 15,031 |  |
|  | $ | 114,970 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 115,016 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,994 |  |
|  | $ | 24,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,994 |  |

[0000936395-14-000063:notes:131]
As of October 31, 2014, investments are comprised of the following (in thousands):

[0000936395-14-000063:notes:132]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-14-000063:notes:133]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-14-000063:notes:134]
ACCOUNTS RECEIVABLE

[0000936395-14-000063:notes:135]
As of October 31, 2013, two customers each accounted for greater than 10% of net accounts receivable, and in the aggregate accounted for 22.5% of net accounts receivable. As of October 31, 2014, there were no customers that accounted for greater than 10% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-14-000063:notes:136]
| Year ended |  | Balance at beginning |  |  |  | Net |  | Balance at end of |
| October 31, |  | of fiscal year |  | Provisions |  | Deductions |  | fiscal year |
| 2012 |  | $ | 701 |  |  | $ | 1,647 |  |  | $ | 848 |  |  | $ | 1,500 |  |
| 2013 |  | $ | 1,500 |  |  | $ | 2,339 |  |  | $ | 1,884 |  |  | $ | 1,955 |  |
| 2014 |  | $ | 1,955 |  |  | $ | 2,761 |  |  | $ | 2,633 |  |  | $ | 2,083 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-14-000063:notes:137]
In February 2013, the Financial Accounting Standards Board ("FASB") issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard update was effective for Ciena beginning in the first quarter of fiscal 2014. As a result of the application of this accounting standard update, Ciena has provided additional disclosures in Note 13 below.

[0000936395-14-000063:notes:138]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-14-000063:notes:139]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its Consolidated Financial Statements.

[0000936395-14-000063:notes:140]
In August 2014, FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate, at each annual or interim reporting period, whether there are conditions or events that exists that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued and provide related disclosures. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on the Ciena's Consolidated Financial Statements or disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-14-000063:notes:141]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES

[0000936395-14-000063:notes:142]
Description of Business

[0000936395-14-000063:notes:143]
Ciena Corporation (“Ciena” or the “Company”) is a network specialist focused on networking solutions that enable converged, next-generation architectures, optimized to handle the broad array of high-bandwidth communications services relied upon by business and consumer end users. Ciena provides equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks.

[0000936395-14-000063:notes:144]
Ciena’s Converged Packet Optical, Packet Networking, Optical Transport and Software products are used, individually or as part of an integrated, programmable solution, in networks operated by communications service providers, cable operators, Web-scale providers, governments, enterprises, research and education institutions, and other network operators across the globe. Ciena's products allow network operators to scale capacity, increase transmission speeds, allocate network traffic and deliver services to end users. Ciena's solutions also include network management and control software and network-level software applications that facilitate automation, software-defined programmability and efficient service delivery. To complement its hardware and software solutions, Ciena offers a broad range of network transformation solutions and related support services that help customers design, optimize, deploy, manage and maintain their network. Ciena’s principal executive offices are located at 7035 Ridge Road, Hanover, Maryland 21076.

[0000936395-14-000063:notes:145]
Principles of Consolidation

[0000936395-14-000063:notes:146]
Fiscal Year

[0000936395-14-000063:notes:147]
Ciena has a 52 or 53 week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 3, 2012,  November 2, 2013 and November 1, 2014 for the periods reported). Fiscal 2013 and fiscal 2014 each consisted of a 52-week fiscal year and fiscal 2012 consisted of a 53-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31.

[0000936395-14-000063:notes:148]
Use of Estimates

[0000936395-14-000063:notes:149]
The preparation of the financial statements and related disclosures in conformity with accounting principles generally

[0000936395-14-000063:notes:150]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-14-000063:notes:151]
Cash and Cash Equivalents

[0000936395-14-000063:notes:152]
Investments

[0000936395-14-000063:notes:153]
Inventories

[0000936395-14-000063:notes:154]
Segment Reporting

[0000936395-14-000063:notes:155]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit(loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services. See Note 20 below.

[0000936395-14-000063:notes:156]
Long-lived Assets

[0000936395-14-000063:notes:157]
Equipment, Furniture and Fixtures and Internal Use Software

[0000936395-14-000063:notes:158]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-14-000063:notes:159]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two to five years.

[0000936395-14-000063:notes:160]
Intangible Assets

[0000936395-14-000063:notes:161]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-14-000063:notes:162]
Maintenance Spares

[0000936395-14-000063:notes:163]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.

[0000936395-14-000063:notes:164]
Concentrations

[0000936395-14-000063:notes:165]
Substantially all of Ciena's cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena's cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-14-000063:notes:166]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 20 below.

[0000936395-14-000063:notes:167]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers and forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.

[0000936395-14-000063:notes:168]
Revenue Recognition

[0000936395-14-000063:notes:169]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-14-000063:notes:170]
Ciena applies the percentage-of-completion method to long-term arrangements where it is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the fiscal years ended October 31, 2012, October 31, 2013 and October 31, 2014 were 1.0%, 4.5% and 4.0%, respectively.

[0000936395-14-000063:notes:171]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-14-000063:notes:172]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-14-000063:notes:173]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-14-000063:notes:174]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-14-000063:notes:175]
Warranty Accruals

[0000936395-14-000063:notes:176]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based upon actual warranty cost experience, estimates of component failure rates and management's industry experience. Ciena's sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-14-000063:notes:177]
Accounts Receivable, Net

[0000936395-14-000063:notes:178]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from its customers. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.

[0000936395-14-000063:notes:179]
Research and Development

[0000936395-14-000063:notes:180]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, cost of prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

[0000936395-14-000063:notes:181]
Government Grants

[0000936395-14-000063:notes:182]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Consolidated Statement of Operations to which the grant activity relates. See Note 22 below.

[0000936395-14-000063:notes:183]
Advertising Costs

[0000936395-14-000063:notes:184]
Legal Costs

[0000936395-14-000063:notes:185]
Share-Based Compensation Expense

[0000936395-14-000063:notes:186]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for shared-based awards with only service-based vesting. See Note 19 below.

[0000936395-14-000063:notes:187]
Income Taxes

[0000936395-14-000063:notes:188]
Loss Contingencies

[0000936395-14-000063:notes:189]
Fair Value of Financial Instruments

[0000936395-14-000063:notes:190]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loan, see Note 14 below.

[0000936395-14-000063:notes:191]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-14-000063:notes:192]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

[0000936395-14-000063:notes:193]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0000936395-14-000063:notes:194]
| • | Level 3 inputs are unobservable inputs based on Ciena's assumptions used to measure assets and liabilities at fair value. |

[0000936395-14-000063:notes:195]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-14-000063:notes:196]
Restructuring

[0000936395-14-000063:notes:197]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 2 below.

[0000936395-14-000063:notes:198]
Foreign Currency

[0000936395-14-000063:notes:199]
Derivatives

[0000936395-14-000063:notes:200]
See Notes 5 and 12 below.

[0000936395-14-000063:notes:201]
Computation of Net Income (Loss) per Share

[0000936395-14-000063:notes:202]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 16 below.

[0000936395-14-000063:notes:203]
Software Development Costs

[0000936395-14-000063:notes:204]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-14-000063:notes:205]
Newly Issued Accounting Standards -Effective


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-14-000063:notes:206]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-14-000063:notes:207]
|  | October 31, |
|  | 2013 |  | 2014 |
| Income tax liability | $ | 9,083 |  |  | $ | 14,342 |  |
| Deferred tenant allowance | 11,775 |  |  | 10,839 |  |
| Straight-line rent | 4,127 |  |  | 5,174 |  |
| Capital lease obligations | 1,983 |  |  | 4,589 |  |
| Interest rate swap derivative | — |  |  | 2,083 |  |
| Other | 7,785 |  |  | 8,363 |  |
|  | $ | 34,753 |  |  | $ | 45,390 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-14-000063:notes:208]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-14-000063:notes:209]
The components of interest and other income (loss), net, were as follow (in thousands):

[0000936395-14-000063:notes:210]
|  |  | October 31, |
|  |  | 2012 |  | 2013 |  | 2014 |
| Interest income |  | 776 |  |  | 550 |  |  | 407 |  |
| Change in fair value of embedded derivative |  | (6,600 | ) |  | 2,950 |  |  | (2,740 | ) |
| Gain (loss) on non-hedge designated foreign currency forward contracts |  | — |  |  | 296 |  |  | (5,757 | ) |
| Foreign currency exchange losses |  | (7,758 | ) |  | (8,168 | ) |  | (15,663 | ) |
| Other |  | (1,618 | ) |  | (1,372 | ) |  | (1,509 | ) |
| Interest and other income (loss), net |  | (15,200 | ) |  | (5,744 | ) |  | (25,262 | ) |

[0000936395-14-000063:notes:211]
Ciena Corporation, as the U.S. parent entity, uses the U.S. dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2012, fiscal 2013 and fiscal 2014, Ciena recorded $7.8 million, $8.2 million and $15.7 million in foreign currency exchange losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net. During fiscal 2014, Ciena recorded losses of $5.8 million from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-14-000063:notes:212]
EQUIPMENT, FURNITURE AND FIXTURES

[0000936395-14-000063:notes:213]
As of the dates indicated, equipment, furniture and fixtures are comprised of the following (in thousands):

[0000936395-14-000063:notes:214]
|  | October 31, |
|  | 2013 |  | 2014 |
| Equipment, furniture and fixtures | $ | 364,574 |  |  | $ | 383,059 |  |
| Leasehold improvements | 46,247 |  |  | 46,354 |  |
|  | 410,821 |  |  | 429,413 |  |
| Accumulated depreciation and amortization | (291,092 | ) |  | (302,781 | ) |
|  | $ | 119,729 |  |  | $ | 126,632 |  |

[0000936395-14-000063:notes:215]
During fiscal 2012, fiscal 2013 and fiscal 2014, Ciena recorded depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements of $51.3 million, $48.3 million and $46.6 million, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-14-000063:notes:216]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net loss during the respective periods:

[0000936395-14-000063:notes:217]
|  | Fiscal Year |
|  | 2012 |  | 2013 |  | 2014 |
| Segment profit: |  |  |  |  |  |
| Converged Packet Optical | $ | 148,244 |  |  | $ | 242,335 |  |  | $ | 353,942 |  |
| Packet Networking | 1,713 |  |  | 22,740 |  |  | 19,467 |  |
| Optical Transport | 116,736 |  |  | 89,754 |  |  | 38,974 |  |
| Software and Services | 93,352 |  |  | 126,938 |  |  | 134,789 |  |
| Total segment profit | 360,045 |  |  | 481,767 |  |  | 547,172 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 266,338 |  |  | 304,170 |  |  | 328,325 |  |
| General and administrative | 114,002 |  |  | 122,432 |  |  | 126,824 |  |
| Amortization of intangible assets | 51,697 |  |  | 49,771 |  |  | 45,970 |  |
| Restructuring costs | 7,854 |  |  | 7,169 |  |  | 349 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest expense and other income (loss), net | (54,853 | ) |  | (49,786 | ) |  | (72,377 | ) |
| Loss on extinguishment of debt | — |  |  | (28,630 | ) |  | — |  |
| Less: Provision for income taxes | 9,322 |  |  | 5,240 |  |  | 13,964 |  |
| Consolidated net loss | $ | (144,021 | ) |  | $ | (85,431 | ) |  | $ | (40,637 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-14-000063:notes:218]
The table below (in thousands, except percentage data) sets forth Ciena’s segment revenue for the respective periods:

[0000936395-14-000063:notes:219]
|  | Fiscal Year |
|  | 2012 |  | 2013 |  | 2014 |
| Revenue: |  |  |  |  |  |
| Converged Packet Optical | $ | 951,245 |  |  | $ | 1,187,231 |  |  | $ | 1,455,501 |  |
| Packet Networking | 128,982 |  |  | 222,898 |  |  | 244,116 |  |
| Optical Transport | 353,620 |  |  | 233,821 |  |  | 127,215 |  |
| Software and Services | 400,076 |  |  | 438,596 |  |  | 461,457 |  |
| Consolidated revenue | $ | 1,833,923 |  |  | $ | 2,082,546 |  |  | $ | 2,288,289 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-14-000063:notes:220]
RESTRUCTURING COSTS

[0000936395-14-000063:notes:221]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the fiscal years indicated (in thousands):

[0000936395-14-000063:notes:222]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2011 | $ | 160 |  |  | $ | 3,293 |  |  | $ | 3,453 |  |
| Additional liability recorded | 5,484 |  | (a) | 2,370 |  | (a) | 7,854 |  |
| Cash payments | (4,195 | ) |  | (2,063 | ) |  | (6,258 | ) |
| Balance at October 31, 2012 | 1,449 |  |  | 3,600 |  |  | 5,049 |  |
| Additional liability recorded | 5,041 |  | (b) | 2,128 |  | (b) | 7,169 |  |
| Non-cash disposal | — |  |  | (747 | ) |  | (747 | ) |
| Cash payments | (6,410 | ) |  | (3,045 | ) |  | (9,455 | ) |
| Balance at October 31, 2013 | 80 |  |  | 1,936 |  |  | 2,016 |  |
| Additional liability recorded | 685 |  | (c) | 9 |  |  | 694 |  |
| Adjustment to previous estimates | — |  |  | (345 | ) |  | (345 | ) |
| Cash payments | (584 | ) |  | (466 | ) |  | (1,050 | ) |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Current restructuring liabilities | $ | 181 |  |  | $ | 498 |  |  | $ | 679 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 636 |  |  | $ | 636 |  |

[0000936395-14-000063:notes:223]
_________________________________

[0000936395-14-000063:notes:224]
| (a) | During fiscal 2012, Ciena recorded a charge of $5.5 million of severance and other employee-related costs associated with a workforce reduction of approximately 135 employees. Ciena also recorded charges of $2.4 million related to its consolidation of several facilities in the Linthicum, Maryland area. |

[0000936395-14-000063:notes:225]
| (b) | During fiscal 2013, Ciena recorded a charge of $5.0 million of severance and other employee-related costs associated with a workforce reduction of approximately 100 employees. Ciena also recorded charges of $2.1 million related to its consolidation of several facilities primarily in the Linthicum, Maryland area. |

[0000936395-14-000063:notes:226]
| (c) | During fiscal 2014, Ciena recorded a charge of $0.7 million of severance and other employee-related costs associated with a workforce reduction of approximately 25 employees. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-14-000063:notes:227]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-14-000063:notes:228]
|  | October 31, |
|  | 2013 |  | 2014 |
| Compensation, payroll related tax and benefits | 98,770 |  |  | 82,207 |  |
| Warranty | 56,303 |  |  | 55,997 |  |
| Vacation | 32,118 |  |  | 35,126 |  |
| Capital lease obligations | 3,079 |  |  | 7,788 |  |
| Interest payable | 6,186 |  |  | 6,409 |  |
| Other | 75,200 |  |  | 89,081 |  |
|  | $ | 271,656 |  |  | $ | 276,608 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-14-000063:notes:229]
The principal balance, unamortized discount and net carrying amount of the Term Loan was as follows as of October 31, 2014:

[0000936395-14-000063:notes:230]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 249,375 |  |  | $ | (1,173 | ) |  | $ | 248,202 |  |
|  |  | $ | 249,375 |  |  | $ | (1,173 | ) |  | $ | 248,202 |  |

[0000936395-14-000063:notes:231]
The following table sets forth, in thousands, the carrying value and the estimated current fair value of Ciena’s outstanding convertible notes:

[0000936395-14-000063:notes:232]
|  |  | October 31, 2014 |
| Description |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | 187,562 |  |  | 193,359 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 487,500 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 |  | 350,000 |  |  | 403,813 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) |  | 179,089 |  |  | 223,828 |  |
|  |  | $ | 1,216,651 |  |  | $ | 1,308,500 |  |

[0000936395-14-000063:notes:233]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |

[0000936395-14-000063:notes:234]
| (2) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |

[0000936395-14-000063:notes:235]
| (3) | Includes unamortized discount and accretion of principal. |

[0000936395-14-000063:notes:236]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-14-000063:notes:237]
|  |  | October 31, 2014 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 248,202 |  |  | $ | 247,193 |  |
|  |  | $ | 248,202 |  |  | $ | 247,193 |  |

[0000936395-14-000063:notes:238]
| (1) | Includes unamortized bond discount. |

[0000936395-14-000063:notes:239]
| (2) | The term loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving this security. |


## us-gaap:ScheduleOfDebtTableTextBlock

[0000936395-14-000063:notes:240]
The principal balance, unamortized discount and net carrying value of the liability and equity components of our 2020 notes were as follows as of October 31, 2014

[0000936395-14-000063:notes:241]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 193,987 |  |  | $ | (14,898 | ) |  | $ | 179,089 |  |  | $ | 43,131 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-14-000063:notes:242]
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-14-000063:notes:243]
|  | October 31, |
|  | 2013 |  | 2014 |
| Maintenance spares inventory, net | $ | 61,305 |  |  | $ | 54,101 |  |
| Deferred debt issuance costs, net | 15,677 |  |  | 15,160 |  |
| Restricted cash | 2,053 |  |  | 45 |  |
| Embedded redemption feature | 2,740 |  |  | — |  |
| Other | 4,605 |  |  | 4,770 |  |
|  | $ | 86,380 |  |  | $ | 74,076 |  |


## us-gaap:ScheduleOfOtherAssetsTableTextBlock

[0000936395-14-000063:notes:244]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-14-000063:notes:245]
|  | October 31, |
|  | 2013 |  | 2014 |
| Prepaid VAT and other taxes | $ | 101,072 |  |  | $ | 86,464 |  |
| Deferred deployment expense | 23,190 |  |  | 27,991 |  |
| Product demonstration equipment, net | 33,382 |  |  | 42,385 |  |
| Prepaid expenses | 16,963 |  |  | 23,539 |  |
| Other non-trade receivables | 12,048 |  |  | 10,683 |  |
| Derivative assets | — |  |  | 1,562 |  |
|  | $ | 186,655 |  |  | $ | 192,624 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-14-000063:notes:246]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-14-000063:notes:247]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2012 |  | $ | 47,282 |  |  | $ | 33,418 |  |  | $ | 25,568 |  |  | $ | 55,132 |  |
| 2013 |  | $ | 55,132 |  |  | $ | 24,558 |  |  | $ | 23,387 |  |  | $ | 56,303 |  |
| 2014 |  | $ | 56,303 |  |  | $ | 22,129 |  |  | $ | 22,435 |  |  | $ | 55,997 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-14-000063:notes:248]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-14-000063:notes:249]
|  | Fiscal Year |
|  | 2012 |  | 2013 |  | 2014 |
| AT&T | $ | 248,123 |  |  | $ | 373,617 |  |  | $ | 423,498 |  |

[0000936395-14-000063:notes:250]
The customer identified above purchased products and services from each of Ciena's operating segments.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-14-000063:notes:251]
For the periods below, Ciena's geographic distribution of equipment, furniture and fixtures, net, was as follows (in thousands):

[0000936395-14-000063:notes:252]
|  | October 31, |
|  | 2012 |  | 2013 |  | 2014 |
| United States | $ | 64,653 |  |  | $ | 64,132 |  |  | $ | 73,420 |  |
| Canada | 48,376 |  |  | 43,772 |  |  | 42,015 |  |
| Other International | 10,551 |  |  | 11,825 |  |  | 11,197 |  |
| Total | $ | 123,580 |  |  | $ | 119,729 |  |  | $ | 126,632 |  |

[0000936395-14-000063:notes:253]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-14-000063:notes:254]
|  | Fiscal Year |
|  | 2012 |  | 2013 |  | 2014 |
| United States | $ | 972,576 |  |  | $ | 1,217,462 |  |  | $ | 1,317,981 |  |
| International | 861,347 |  |  | 865,084 |  |  | 970,308 |  |
| Total | $ | 1,833,923 |  |  | $ | 2,082,546 |  |  | $ | 2,288,289 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-14-000063:notes:255]
SEGMENT AND ENTITY WIDE DISCLOSURES

[0000936395-14-000063:notes:256]
Ciena’s internal organizational structure and the management of its business are grouped into the following operating segments:

[0000936395-14-000063:notes:257]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:notes:258]
| • | Packet Networking — includes Ciena's 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes Ciena’s 8700 Packetwave Platform and Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:notes:259]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:notes:260]
| • | Software and Services — includes Ciena's Agility software portfolio, which includes a SDN multilayer WAN controller, NFV platform, and network level software applications for enabling on-demand, high-bandwidth WAN services delivered in an open network ecosystem. This segment also includes the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager and Optical Suite Release. This segment includes a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:notes:261]
Ciena's long-lived assets, including equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2014, equipment, furniture and fixtures totaling $126.6 million primarily supports asset groups within Ciena's Converged Packet Optical segment, Packet Networking segment, Software and Services segment and Ciena's unallocated selling and general and administrative activities. As of October 31, 2014, all of Ciena's finite-lived intangible assets totaling $128.7 million were assigned to asset groups within Ciena's Converged Packet Optical segment. As of October 31, 2014, all of the maintenance spares totaling $54.1 million were assigned to asset groups within Ciena's Software and Services segment.

[0000936395-14-000063:notes:262]
Segment Revenue

[0000936395-14-000063:notes:263]
Segment Profit

[0000936395-14-000063:notes:264]
Segment profit is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; restructuring costs; interest and other income (loss), net; interest expense; loss on extinguishment of debt and provisions for income taxes.

[0000936395-14-000063:notes:265]
Entity Wide Reporting

[0000936395-14-000063:notes:266]
The following table reflects Ciena’s geographic distribution of revenue based on the location of the purchaser, with any country accounting for at least 10% of total revenue in the period specifically identified. Revenue attributable to geographic regions outside of the United States is reflected as International revenue. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-14-000063:notes:267]
The following table reflects Ciena's geographic distribution of equipment, furniture and fixtures, net, with any country

[0000936395-14-000063:notes:268]
accounting for at least 10% of total equipment, furniture and fixtures, net, specifically identified. Equipment, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena's geographic distribution of equipment, furniture and fixtures, net, was as follows (in thousands):


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-14-000063:notes:269]
STOCKHOLDERS’ EQUITY

[0000936395-14-000063:notes:270]
Call Spread Options

[0000936395-14-000063:notes:271]
Ciena purchased a call spread option relating to the 0.875% convertible senior notes due June 15, 2017 for $42.5 million during the third quarter of fiscal 2007. The call spread option is designed to mitigate exposure to potential dilution from the conversion of the notes. The call spread option was purchased at the time of the notes offering from an affiliate of the underwriter. The cost of the call spread option was recorded as a reduction in paid-in capital.

[0000936395-14-000063:notes:272]
The call spread option is exercisable, upon maturity of the relevant issue of convertible note, for such number of shares of Ciena common stock issuable upon conversion of that series of notes in full. The call spread option has a “lower strike price” equal to the conversion price for the notes and a “higher strike price” that serves to cap the amount of dilution protection provided. At its election, Ciena can exercise the call spread option on a net cash basis or a net share basis. The value of the consideration of a net share settlement will be equal to the value upon a net cash settlement and can range from $0, if the market price per share of Ciena common stock upon exercise is equal to or below the lower strike price, or approximately $76.1 million, if the market price per share of Ciena common stock upon exercise is at or above the higher strike price. If the market price on the date of exercise is between the lower strike price and the higher strike price, in lieu of a net settlement, Ciena may elect to receive the full number of shares underlying the call spread option by paying the aggregate option exercise price, which is equal to the original principal outstanding on that series of notes. Should there be an early unwind of the call spread option, the amount of cash or shares to be received by Ciena will depend upon the existing overall market conditions, and on Ciena’s stock price, the volatility of Ciena’s stock and the remaining term of the call spread option. The number of shares subject to the call spread option, and the lower and higher strike prices, are subject to customary adjustments.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-14-000063:notes:273]
OTHER BALANCE SHEET DETAILS

[0000936395-14-000063:notes:274]
Deferred debt issuance costs are amortized using the straight line method which approximates the effect of the effective interest rate method through the maturity of the related debt. Amortization of debt issuance costs related to our convertible notes payable, term loan (described in Note 14 below) and our ABL Credit Facility (described in Note 15 below), which is included in interest expense, was $5.3 million, $5.4 million and $4.8 million for fiscal 2012, fiscal 2013 and fiscal 2014, respectively.

[0000936395-14-000063:notes:275]
The increase in fiscal 2012 warranty provision was driven primarily by sales that included longer-term support obligations and technical support requirements from additional geographies. The decreases in both fiscal 2013 and fiscal 2014 warranty provisions were primarily due to lower failure rates and reduced costs due to efficiencies.


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-14-000063:notes:276]
ABL CREDIT FACILITY

[0000936395-14-000063:notes:277]
During fiscal 2012, Ciena and certain of its subsidiaries entered into a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). On July 15, 2014, Ciena amended the ABL Credit Facility to, among other things:

[0000936395-14-000063:notes:278]
| • | increase the total committed amount from $150 million to $200 million; |

[0000936395-14-000063:notes:279]
| • | extend the maturity date from August 13, 2015 to December 31, 2016, and eliminate the maturity date acceleration to December 15, 2014 in the event that any of Ciena’s 4.00% senior convertible notes due March 15, 2015 are then outstanding; |

[0000936395-14-000063:notes:280]
| • | reduce the minimum aggregate amount of unrestricted cash and cash equivalents that Ciena is required to maintain at all times from $200 million to $150 million; |

[0000936395-14-000063:notes:281]
| • | reduce the interest rate on borrowings from LIBOR plus an applicable margin ranging from 200 basis points to 250 basis points, to an applicable margin ranging from 150 basis points to 200 basis points, with the actual margin based upon Ciena's utilization of the ABL Credit Facility; and |

[0000936395-14-000063:notes:282]
| • | amend the borrowing base to include, among other items, up to $50 million in eligible cash. |

[0000936395-14-000063:notes:283]
Ciena also amended the terms of the existing security and pledge agreements to provide the lenders with second-priority security interests in the Term Loan Priority Collateral, in addition to its existing first-priority security interests in current assets, consisting principally of accounts receivable, inventory, cash, and deposit and securities accounts (the "ABL Priority Collateral"). Except as amended, the remaining terms of the ABL Credit Facility, and related security and pledge agreements, remain in full force and effect.

[0000936395-14-000063:notes:284]
Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of October 31, 2014, letters of credit totaling $71.4 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2014.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-14-000063:notes:285]
PREPAID EXPENSES AND OTHER

[0000936395-14-000063:notes:286]
Depreciation of product demonstration equipment was $7.8 million, $7.4 million and $9.0 million for fiscal 2012, 2013 and 2014, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-14-000063:notes:287]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-14-000063:notes:288]
Term Loan

[0000936395-14-000063:notes:289]
On July 15, 2014, Ciena entered into a Credit Agreement (the “Term Loan Credit Agreement”) which provides for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”). Ciena received proceeds from the Term Loan, net of original issue discount and debt issuance costs, of approximately $246 million.

[0000936395-14-000063:notes:290]
The Term Loan bears interest at a rate equal to LIBOR (subject to a floor of 0.75%) plus an applicable margin of 3.00% and matures on July 15, 2019. The Term Loan Credit Agreement requires Ciena to make quarterly installment payments in aggregate amounts equal to 0.25% of the original principal amount of the Term Loan, with the balance of the Term Loan payable at maturity. The Term Loan Credit Agreement requires mandatory prepayments on the occurrence of certain customary events and, when the total secured net leverage ratio (as defined in the Term Loan Credit Agreement) is in excess of 2.50 to 1.00, the Term Loan Credit Agreement requires a mandatory prepayment of 50% of excess annual cash flow (as defined in the Term Loan Credit Agreement).

[0000936395-14-000063:notes:291]
The Term Loan Credit Agreement contains customary covenants that limit, absent lender approval, the ability of Ciena to, among other things, incur additional debt, create liens and encumbrances, pay cash dividends, enter into certain acquisition transactions or transactions with affiliates, merge, dissolve, repay certain indebtedness, change the nature of Ciena’s business, make investments or dispose of assets.

[0000936395-14-000063:notes:292]
The Term Loan Credit Agreement contains customary events of default including, among other things, failure to pay obligations when due, initiation of bankruptcy or insolvency proceedings, defaults on certain other indebtedness, change of control, incurrence of certain material judgments, violation of affirmative and negative covenants, and breaches of representations and warranties set forth in the Term Loan Credit Agreement. Upon an event of default, the administrative agent may, subject to various customary cure rights, require the immediate payment of all amounts outstanding and foreclose on collateral.

[0000936395-14-000063:notes:293]
In connection with Ciena entering into the Term Loan Credit Agreement, Ciena and certain of its subsidiaries entered into a guaranty, a security agreement and a pledge agreement, each on customary terms. The Term Loan is secured by (i) second-priority security interests in the ABL Priority Collateral (as defined in Note 15 below), and (ii) first-priority security interests in substantially all other tangible and intangible assets including equipment, intercompany notes, intellectual property and material owned real property (the "Term Loan Priority Collateral").

[0000936395-14-000063:notes:294]
Outstanding Convertible Notes Payable

[0000936395-14-000063:notes:295]
Ciena has four issuances of convertible notes payable outstanding. The notes are senior unsecured obligations of Ciena and rank equally with all of Ciena’s other existing and future senior unsecured debt. The indentures governing Ciena’s notes provide for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal or interest; breach of covenants or other agreements in the indenture; defaults in or failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing, the trustee or the holders of at least 25% in aggregate principal amount of the notes may declare the principal of, accrued interest on, and premium, if any, on all the notes immediately due and payable. Under the indentures, if Ciena undergoes a “fundamental change” (as that term is defined in the indenture governing the notes to include certain change in control transactions), holders of notes will have the right, subject to certain exemptions, to require Ciena to purchase for cash any or all of their notes at a price equal to the principal amount, plus accrued interest. If the holder elects to convert his or her notes in connection with a specified fundamental change Ciena will be required, in certain circumstances, to increase the applicable conversion rate, depending on the price paid per share for Ciena common stock and the effective date of the fundamental change transaction.

[0000936395-14-000063:notes:296]
4.0% Convertible Senior Notes, due March 15, 2015

[0000936395-14-000063:notes:297]
On March 15, 2010, Ciena completed a private placement of 4.0% convertible senior notes due March 15, 2015, in aggregate principal amount of $375.0 million. Interest is payable on the notes on March 15 and September 15 of each year, beginning on September 15, 2010.

[0000936395-14-000063:notes:298]
On December 27, 2012, Ciena issued $187.5 million in aggregate principal amount of 4.0% Convertible Senior Notes due 2020 (the “2020 Notes”) in separate private offerings in exchange for $187.5 million in aggregate principal amount of the then outstanding 2015 Notes (the “Exchange Transactions”). The Exchange Transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million, the write-off of unamortized debt issuance costs of $2.3 million, and settlement of $0.6 million relating to the redemption feature on the 2015 Notes accounted for as a separate embedded derivative. The 2020 Notes offered in the Exchange Transactions had a fair value of $213.6 million, which resulted in a loss on extinguishment of debt of $28.6 million in the first quarter of fiscal 2013. Ciena does not expect the Exchange Transactions to affect its taxes from continuing operations, as Ciena continues to provide a valuation allowance against its deferred tax assets.

[0000936395-14-000063:notes:299]
At the election of the holder, the notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 49.0557 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $20.38 per share. The notes may be redeemed by Ciena on or after March 15, 2013 if the closing sale price of Ciena’s common stock for at least 20 trading days in any 30 consecutive trading day period ending on the date one day prior to the date of the notice of redemption exceeds 150% of the conversion price. Ciena may redeem the notes, in whole or in part, at a redemption price in cash equal to the principal amount to be redeemed, plus accrued and unpaid interest, including any additional interest to, but excluding, the redemption date, plus a make-whole premium payment. The “make whole premium” payment will be made in cash and equal the present value of the remaining interest payments, to maturity, computed using a discount rate equal to 2.75%. The make-whole premium is paid to holders whether or not they convert the notes following Ciena’s issuance of a redemption notice. For accounting purposes, this redemption feature is an embedded derivative that is not clearly and closely related to the notes. Consequently, it was initially bifurcated from the indenture and separately recorded at its fair value as an asset with subsequent changes in fair value recorded through earnings. As of October 31, 2014, the fair value of the embedded redemption feature was $0.0 million. A reduction in the fair value of the embedded redemption feature in the amount of $2.7 million is reflected as interest and other income (loss), net in the Consolidated Statement of Operations during fiscal 2014.

[0000936395-14-000063:notes:300]
The net proceeds from the original offering of the notes were $364.3 million after deducting the placement agents’ fees and other fees and expenses. Ciena used $243.8 million of this amount to fund its payment election to replace its contractual obligation to issue convertible notes to Nortel as part of the aggregate purchase price for the acquisition of the MEN Business. The remaining proceeds were used to reduce the cash on hand required to fund the aggregate purchase price of the MEN Business.

[0000936395-14-000063:notes:301]
0.875% Convertible Senior Notes due June 15, 2017

[0000936395-14-000063:notes:302]
On June 11, 2007, Ciena completed a public offering of 0.875% convertible senior notes due June 15, 2017, in aggregate principal amount of $500.0 million. Interest is payable on June 15 and December 15 of each year, beginning on December 15, 2007.

[0000936395-14-000063:notes:303]
At the election of the holder, the notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 26.2154 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $38.15 per share. The notes are not redeemable by Ciena prior to maturity.

[0000936395-14-000063:notes:304]
Ciena used approximately $42.5 million of the net proceeds of this offering to purchase a call spread option on its common stock that is intended to limit exposure to potential dilution from conversion of the notes. See Note 17 below for a description of this call spread option.

[0000936395-14-000063:notes:305]
3.75% Convertible Senior Notes, due October 15, 2018

[0000936395-14-000063:notes:306]
On October 18, 2010, Ciena completed a private placement of 3.75% convertible senior notes due October 15, 2018, in aggregate principal amount of $350.0 million. Interest is payable on the notes on April 15 and October 15 of each year, beginning on April 15, 2011.

[0000936395-14-000063:notes:307]
At the election of the holder, the notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 49.5872 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $20.17 per share.

[0000936395-14-000063:notes:308]
The net proceeds from the offering were approximately $340.4 million after deducting the placement agents’ fees and other fees and expenses. Ciena used $76.1 million of the net proceeds to effect the repurchase of its 0.25% convertible senior notes due 2013, which matured during fiscal 2013.

[0000936395-14-000063:notes:309]
4.0% Convertible Senior Notes due December 15, 2020

[0000936395-14-000063:notes:310]
As described above, on December 27, 2012, Ciena issued $187.5 million in aggregate principal amount of 4.0% Convertible Senior Notes due December 15, 2020 (the “2020 Notes”) in separate private offerings in exchange for $187.5 million in aggregate principal amount of 2015 Notes above.

[0000936395-14-000063:notes:311]
The 2020 Notes are senior unsecured obligations and rank equally with all of Ciena's other existing and future senior unsecured debt. The 2020 Notes pay interest from the date of issuance at a rate of 4.0% per year. The interest is payable semi-annually on June 15 and December 15, commencing on June 15, 2013. The principal amount of the 2020 Notes will also accrete at a rate of 1.85% per year commencing December 27, 2012, compounding on a semi-annual basis. The accreted portion of the principal payable at maturity does not bear interest and is not convertible into shares of Ciena's common stock. The 2020 Notes will mature on December 15, 2020. Consequently, in the event the 2020 Notes are converted, the accreted liability will extinguish without payment.

[0000936395-14-000063:notes:312]
The 2020 Notes may be converted prior to maturity, at the option of the holder, into shares of Ciena's common stock at an initial conversion rate of 49.0557 shares of common stock per $1,000 in original principal amount, which is equal to an initial conversion price of $20.39 per share. In addition, Ciena may elect to convert the 2020 Notes, in whole or in part, at any time on or prior to December 15, 2020, if the daily volume weighted average price of the common stock equals or exceeds 130% of the conversion price then in effect for at least 20 trading days in any 30 consecutive trading day period. If Ciena elects to convert the 2020 Notes on or before maturity, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena's election. An aggregate of 9,197,944 shares of Ciena common stock issuable upon conversion of the 2020 Notes has been reserved for issuance.

[0000936395-14-000063:notes:313]
Upon certain fundamental changes, holders of the 2020 Notes have the option to require Ciena to purchase the 2020 Notes at a price equal to the accreted principal amount of the notes delivered for repurchase plus any accrued and unpaid interest on the original principal amount. Upon a holder's election to convert the 2020 Notes in connection with certain fundamental changes, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena's election.

[0000936395-14-000063:notes:314]
Accounting guidance issued by the FASB requires the issuer of convertible debt instruments with cash settlement features, including partial cash settlement, to account separately for the liability and equity components of the instrument. Under this guidance, the debt is recognized at the present value of its cash flows discounted using the issuer's nonconvertible debt borrowing rate at the time of issuance and the equity component is recognized as the difference between the proceeds from the issuance of the note and the fair value of the liability. The reduced carrying value on the convertible debt results in a debt discount that is accreted back to the convertible debt's principal amount through the recognition of non-cash interest expense over the expected life of the debt, which results in recognizing the interest expense on these borrowings at effective rates approximating what Ciena would have incurred had nonconvertible debt with otherwise similar terms been issued.

[0000936395-14-000063:notes:315]
Because the additional make-whole shares can be settled in cash or common stock at Ciena's option, the debt and equity components were accounted for separately. Ciena measured the fair value of the debt component of the 2020 Notes using an effective interest rate of 7.0%. As a result, Ciena attributed $170.4 million of the fair value of the 2020 Notes to the debt component. The debt component was netted against the face value of the 2020 Notes to determine the debt discount. The debt discount will be accreted over the period from the date of issuance to the contractual maturity date, resulting in the recognition of non-cash interest expense. In addition, Ciena recorded $43.1 million within additional paid-in capital representing the equity component of the 2020 Notes. There was no net tax expense recorded due to Ciena’s full valuation allowance against its deferred tax assets.

[0000936395-14-000063:notes:316]
The 2020 Notes were issued pursuant to an Indenture entered into as of December 27, 2012 (the “Indenture”) with The Bank of New York Mellon Trust Company, N.A., as trustee. The Indenture provides for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal (including accreted portion) or interest; breach of covenants or other agreements in the Indenture; defaults in failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing under the Indenture, the trustee or the holders of at least 25% in aggregate original principal amount of the 2020 Notes then outstanding may declare the principal (including accreted portion), premium, if any, and accrued interest on all the 2020 Notes immediately due and payable.
