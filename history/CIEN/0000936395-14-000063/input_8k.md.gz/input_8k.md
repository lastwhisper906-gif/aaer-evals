# CIEN 8-K — 0000936395-14-000058 filed 2014-12-11

## item codes, every 8-K on or before 2014-12-19

- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2014-12-19

- none on or before 2014-12-19

## item 2.02 — earnings release, exhibit 99.1

[0000936395-14-000058:8k_2_02:1]
EX-99.1
2
a201410kpressrelease.htm
EXHIBIT

[0000936395-14-000058:8k_2_02:2]
2014 8K Press Release

[0000936395-14-000058:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-14-000058:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2014 and Year-End Financial Results

[0000936395-14-000058:8k_2_02:5]
Delivers 10% annual revenue growth and 6.5% adjusted operating margin for the year

[0000936395-14-000058:8k_2_02:6]
HANOVER, Md. - December 11, 2014 - Ciena® Corporation (NYSE: CIEN), the network specialist, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2014.

[0000936395-14-000058:8k_2_02:7]
For the fiscal fourth quarter 2014, Ciena reported revenue of $591.0 million as compared to $583.4 million for the fiscal fourth quarter 2013. For fiscal year 2014, Ciena reported revenue of $2.3 billion, as compared to $2.1 billion for fiscal year 2013.

[0000936395-14-000058:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net loss for the fiscal fourth quarter 2014 was $(30.7) million, or $(0.29) per diluted common share, which compares to a GAAP net loss of $(9.8) million, or $(0.09) per diluted common share, for the fiscal fourth quarter 2013. For fiscal year 2014, Ciena had a GAAP net loss of $(40.6) million, or $(0.38) per diluted common share, which compares to a GAAP net loss of $(85.4) million or $(0.83) per diluted common share for fiscal year 2013.

[0000936395-14-000058:8k_2_02:9]
Ciena's adjusted (non-GAAP) net loss for the fiscal fourth quarter 2014 was $(8.2) million, or $(0.08) per diluted common share, which compares to an adjusted (non-GAAP) net income of $18.3 million, or $0.16 per diluted common share, for the fiscal fourth quarter 2013. For fiscal year 2014, Ciena's adjusted (non-GAAP) net income was $65.8 million, or $0.59 per diluted common share, as compared to an adjusted (non-GAAP) net income of $59.0 million, or $0.54 per diluted common share for fiscal year 2013.

[0000936395-14-000058:8k_2_02:10]
“We delivered strong revenue growth and improved profitability in fiscal 2014 as we benefited from a more diversified customer base and the strong alignment of our solutions with the increasing on-demand needs of our customers,” said Gary B. Smith, president and CEO of Ciena. “As we continue to expand Ciena’s role and reach, we are well positioned to drive continued growth and increased profitability in 2015.”

[0000936395-14-000058:8k_2_02:11]
Fiscal Fourth Quarter 2014 Performance Summary

[0000936395-14-000058:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarterly and year over year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendices A and B.

[0000936395-14-000058:8k_2_02:13]
|  |  | GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2014 |  | FY 2014 |  | FY 2013 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 591.0 |  |  | $ | 603.6 |  |  | $ | 583.4 |  |  | (2.1 | )% |  | 1.3 | % |
| Gross margin |  | 37.4 | % |  | 43.7 | % |  | 39.7 | % |  | (6.3 | )% |  | (2.3 | )% |
| Operating expense |  | $ | 222.7 |  |  | $ | 227.0 |  |  | $ | 232.1 |  |  | (1.9 | )% |  | (4.1 | )% |
| Operating margin |  | (0.3 | )% |  | 6.1 | % |  | (0.1 | )% |  | (6.4 | )% |  | (0.2 | )% |

[0000936395-14-000058:8k_2_02:14]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2014 |  | FY 2014 |  | FY 2013 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 591.0 |  |  | $ | 603.6 |  |  | $ | 583.4 |  |  | (2.1 | )% |  | 1.3 | % |
| Adj. gross margin |  | 37.9 | % |  | 44.3 | % |  | 40.8 | % |  | (6.4 | )% |  | (2.9 | )% |
| Adj. operating expense |  | $ | 203.7 |  |  | $ | 206.3 |  |  | $ | 210.5 |  |  | (1.3 | )% |  | (3.2 | )% |
| Adj. operating margin |  | 3.4 | % |  | 10.1 | % |  | 4.7 | % |  | (6.7 | )% |  | (1.3 | )% |

[0000936395-14-000058:8k_2_02:15]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q4 FY 2014 |  | Q3 FY 2014 |  | Q4 FY 2013 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 383.3 |  |  | 64.9 |  | $ | 382.0 |  |  | 63.3 |  | $ | 350.9 |  |  | 60.2 |
| Packet Networking |  | 56.4 |  |  | 9.5 |  | 69.5 |  |  | 11.5 |  | 61.2 |  |  | 10.5 |
| Optical Transport |  | 26.5 |  |  | 4.5 |  | 31.0 |  |  | 5.1 |  | 52.6 |  |  | 9.0 |
| Software and Services |  | 124.8 |  |  | 21.1 |  | 121.1 |  |  | 20.1 |  | 118.7 |  |  | 20.3 |
| Total |  | $ | 591.0 |  |  | 100.0 |  | $ | 603.6 |  |  | 100.0 |  | $ | 583.4 |  |  | 100.0 |

[0000936395-14-000058:8k_2_02:16]
| * Denotes % change, or in the case of margin, absolute change |  |  |  |  |  |  |

[0000936395-14-000058:8k_2_02:17]
Additional Performance Metrics for Fiscal Fourth Quarter 2014

[0000936395-14-000058:8k_2_02:18]
| • | Non-U.S. customers contributed 47.8% of total revenue |

[0000936395-14-000058:8k_2_02:19]
| • | One 10%-plus customer represented a total of 12.2% of revenue |

[0000936395-14-000058:8k_2_02:20]
| • | Cash and investments totaled $777.0 million |

[0000936395-14-000058:8k_2_02:21]
| • | Cash flow from operations totaled $73.8 million |

[0000936395-14-000058:8k_2_02:22]
| • | Average days' sales outstanding (DSOs) were 79 |

[0000936395-14-000058:8k_2_02:23]
| • | Accounts receivable balance was $519.0 million |

[0000936395-14-000058:8k_2_02:24]
| • | Inventories totaled $254.7 million, including: |

[0000936395-14-000058:8k_2_02:25]
| ◦ | Raw materials: $64.8 million |

[0000936395-14-000058:8k_2_02:26]
| ◦ | Work in process: $8.4 million |

[0000936395-14-000058:8k_2_02:27]
| ◦ | Finished goods: $165.8 million |

[0000936395-14-000058:8k_2_02:28]
| ◦ | Deferred cost of sales: $75.8 million |

[0000936395-14-000058:8k_2_02:29]
| ◦ | Reserve for excess and obsolescence: $(60.1) million |

[0000936395-14-000058:8k_2_02:30]
| • | Product inventory turns were 4.8 |

[0000936395-14-000058:8k_2_02:31]
| • | Headcount totaled 5,161 |

[0000936395-14-000058:8k_2_02:32]
Business Outlook for Fiscal First Quarter 2015

[0000936395-14-000058:8k_2_02:33]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-14-000058:8k_2_02:34]
Ciena expects financial performance for fiscal first quarter 2015 to include:

[0000936395-14-000058:8k_2_02:35]
| • | Revenue in the range of $540 to $570 million |

[0000936395-14-000058:8k_2_02:36]
| • | Adjusted (non-GAAP) gross margin percentage in the low 40s range |

[0000936395-14-000058:8k_2_02:37]
| • | Adjusted (non-GAAP) operating expense of approximately $210 million |

[0000936395-14-000058:8k_2_02:38]
Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2014 Results

[0000936395-14-000058:8k_2_02:39]
Ciena will host a discussion of its unaudited fiscal fourth quarter 2014 and year-end results with investors and financial analysts today, Thursday, December 11, 2014 at 8:30 a.m. (Eastern). The live broadcast of the discussion will be available via Ciena's homepage at http://www.ciena.com/. An archived version of the discussion will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at: www.ciena.com/investors.

[0000936395-14-000058:8k_2_02:40]
About Ciena

[0000936395-14-000058:8k_2_02:41]
Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-14-000058:8k_2_02:42]
Notes to Investors

[0000936395-14-000058:8k_2_02:43]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “We delivered strong revenue growth and improved profitability in fiscal 2014 as we benefited from a more diversified customer base and the strong alignment of our solutions with the increasing on-demand needs of our customers”; “As we continue to expand Ciena’s role and reach, we are well positioned to drive continued growth and increased profitability in 2015”; "Ciena expects financial performance for fiscal first quarter 2015 to include revenue in the range of $540 to $570 million, adjusted (non-GAAP) gross margin percentage in the low 40s range, adjusted (non-GAAP) operating expense of approximately $210 million."

[0000936395-14-000058:8k_2_02:44]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q filed with the Securities and Exchange

[0000936395-14-000058:8k_2_02:45]
Commission on September 10, 2014. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-14-000058:8k_2_02:46]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendixes A and B to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-14-000058:8k_2_02:47]
CIENA CORPORATION

[0000936395-14-000058:8k_2_02:48]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-14-000058:8k_2_02:49]
(in thousands, except per share data)

[0000936395-14-000058:8k_2_02:50]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2013 |  | 2014 |  | 2013 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 476,409 |  |  | $ | 476,175 |  |  | $ | 1,680,125 |  |  | $ | 1,865,826 |  |
| Services |  | 106,976 |  |  | 114,788 |  |  | 402,421 |  |  | 422,463 |  |
| Total revenue |  | 583,385 |  |  | 590,963 |  |  | 2,082,546 |  |  | 2,288,289 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 283,780 |  |  | 305,171 |  |  | 967,510 |  |  | 1,083,022 |  |
| Services |  | 67,959 |  |  | 64,955 |  |  | 249,861 |  |  | 256,915 |  |
| Total cost of goods sold |  | 351,739 |  |  | 370,126 |  |  | 1,217,371 |  |  | 1,339,937 |  |
| Gross profit |  | 231,646 |  |  | 220,837 |  |  | 865,175 |  |  | 948,352 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 100,427 |  |  | 98,506 |  |  | 383,408 |  |  | 401,180 |  |
| Selling and marketing |  | 87,494 |  |  | 84,396 |  |  | 304,170 |  |  | 328,325 |  |
| General and administrative |  | 31,275 |  |  | 28,560 |  |  | 122,432 |  |  | 126,824 |  |
| Amortization of intangible assets |  | 12,439 |  |  | 11,019 |  |  | 49,771 |  |  | 45,970 |  |
| Restructuring costs |  | 428 |  |  | 171 |  |  | 7,169 |  |  | 349 |  |
| Total operating expenses |  | 232,063 |  |  | 222,652 |  |  | 866,950 |  |  | 902,648 |  |
| Income (loss) from operations |  | (417 | ) |  | (1,815 | ) |  | (1,775 | ) |  | 45,704 |  |
| Interest and other income (loss), net |  | 276 |  |  | (11,031 | ) |  | (5,744 | ) |  | (25,262 | ) |
| Interest expense |  | (10,946 | ) |  | (13,559 | ) |  | (44,042 | ) |  | (47,115 | ) |
| Loss on extinguishment of debt |  | — |  |  | — |  |  | (28,630 | ) |  | — |  |
| Loss before income taxes |  | (11,087 | ) |  | (26,405 | ) |  | (80,191 | ) |  | (26,673 | ) |
| Provision (benefit) for income taxes |  | (1,290 | ) |  | 4,298 |  |  | 5,240 |  |  | 13,964 |  |
| Net loss |  | $ | (9,797 | ) |  | $ | (30,703 | ) |  | $ | (85,431 | ) |  | $ | (40,637 | ) |
| Net Loss per Common Share |  |  |  |  |  |  |  |  |
| Basic net loss per common share |  | $ | (0.09 | ) |  | $ | (0.29 | ) |  | $ | (0.83 | ) |  | $ | (0.38 | ) |
| Diluted net loss per potential common share |  | $ | (0.09 | ) |  | $ | (0.29 | ) |  | $ | (0.83 | ) |  | $ | (0.38 | ) |
| Weighted average basic common shares outstanding |  | 103,523 |  |  | 106,931 |  |  | 102,350 |  |  | 105,783 |  |
| Weighted average dilutive potential common shares outstanding |  | 103,523 |  |  | 106,931 |  |  | 102,350 |  |  | 105,783 |  |

[0000936395-14-000058:8k_2_02:51]
CIENA CORPORATION

[0000936395-14-000058:8k_2_02:52]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-14-000058:8k_2_02:53]
(in thousands, except share data)

[0000936395-14-000058:8k_2_02:54]
|  | October 31, |
|  | 2013 |  | 2014 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 346,487 |  |  | $ | 586,720 |  |
| Short-term investments | 124,979 |  |  | 140,205 |  |
| Accounts receivable, net | 488,578 |  |  | 518,981 |  |
| Inventories | 249,103 |  |  | 254,660 |  |
| Prepaid expenses and other | 186,655 |  |  | 192,624 |  |
| Total current assets | 1,395,802 |  |  | 1,693,190 |  |
| Long-term investments | 15,031 |  |  | 50,057 |  |
| Equipment, furniture and fixtures, net | 119,729 |  |  | 126,632 |  |
| Other intangible assets, net | 185,828 |  |  | 128,677 |  |
| Other long-term assets | 86,380 |  |  | 74,076 |  |
| Total assets | $ | 1,802,770 |  |  | $ | 2,072,632 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 254,849 |  |  | $ | 209,777 |  |
| Accrued liabilities and other short-term obligations | 271,656 |  |  | 276,608 |  |
| Deferred revenue | 88,550 |  |  | 104,688 |  |
| Current portion of long-term debt | — |  |  | 190,063 |  |
| Total current liabilities | 615,055 |  |  | 781,136 |  |
| Long-term deferred revenue | 23,620 |  |  | 40,930 |  |
| Other long-term obligations | 34,753 |  |  | 45,390 |  |
| Long-term debt, net | 1,212,019 |  |  | 1,274,791 |  |
| Total liabilities | 1,885,447 |  |  | 2,142,247 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 103,705,709 and 106,979,960 shares issued and outstanding | 1,037 |  |  | 1,070 |  |
| Additional paid-in capital | 5,893,880 |  |  | 5,954,440 |  |
| Accumulated other comprehensive loss | (7,774 | ) |  | (14,668 | ) |
| Accumulated deficit | (5,969,820 | ) |  | (6,010,457 | ) |
| Total stockholders’ equity (deficit) | (82,677 | ) |  | (69,615 | ) |
| Total liabilities and stockholders’ equity (deficit) | $ | 1,802,770 |  |  | $ | 2,072,632 |  |

[0000936395-14-000058:8k_2_02:55]
CIENA CORPORATION

[0000936395-14-000058:8k_2_02:56]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-14-000058:8k_2_02:57]
(in thousands)

[0000936395-14-000058:8k_2_02:58]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |
| Cash flows from operating activities: |  |  |  |
| Net loss | $ | (85,431 | ) |  | $ | (40,637 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Loss on extinguishment of debt | 28,630 |  |  | — |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 55,699 |  |  | 55,616 |  |
| Share-based compensation costs | 37,720 |  |  | 42,930 |  |
| Amortization of intangible assets | 71,308 |  |  | 57,151 |  |
| Provision for inventory excess and obsolescence | 19,938 |  |  | 32,332 |  |
| Provision for warranty | 24,558 |  |  | 22,129 |  |
| Other | 9,023 |  |  | 25,668 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (145,421 | ) |  | (33,164 | ) |
| Inventories | (8,943 | ) |  | (37,889 | ) |
| Prepaid expenses and other | (82,809 | ) |  | (7,931 | ) |
| Accounts payable, accruals and other obligations | 115,312 |  |  | (59,837 | ) |
| Deferred revenue | 5,094 |  |  | 33,448 |  |
| Net cash provided by operating activities | 44,678 |  |  | 89,816 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (43,814 | ) |  | (48,216 | ) |
| Restricted cash | 2,338 |  |  | 2,060 |  |
| Purchase of available for sale securities | (184,864 | ) |  | (245,196 | ) |
| Proceeds from maturities of available for sale securities | 95,000 |  |  | 195,000 |  |
| Settlement of foreign currency forward contracts, net | 479 |  |  | (10,041 | ) |
| Net cash used in investing activities | (130,861 | ) |  | (106,393 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | — |  |  | 248,750 |  |
| Payment of long-term debt | (216,210 | ) |  | (625 | ) |
| Payment of debt and equity issuance costs | (3,692 | ) |  | (4,227 | ) |
| Payment of capital lease obligations | (3,335 | ) |  | (3,034 | ) |
| Proceeds from issuance of common stock | 15,898 |  |  | 17,663 |  |
| Net cash provided by (used in) financing activities | (207,339 | ) |  | 258,527 |  |
| Effect of exchange rate changes on cash and cash equivalents | (2,435 | ) |  | (1,717 | ) |
| Net increase (decrease) in cash and cash equivalents | (295,957 | ) |  | 240,233 |  |
| Cash and cash equivalents at beginning of fiscal year | 642,444 |  |  | 346,487 |  |
| Cash and cash equivalents at end of fiscal year | $ | 346,487 |  |  | $ | 586,720 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 32,397 |  |  | $ | 36,276 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 10,679 |  |  | $ | 11,396 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 6,191 |  |  | $ | 4,961 |  |
| Fixed assets purchased under capital leases | $ | 2,538 |  |  | $ | 10,424 |  |

[0000936395-14-000058:8k_2_02:59]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements (unaudited) |
|  |  | Quarter Ended |
|  |  | October 31, |
|  |  | 2013 |  | 2014 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 231,646 |  |  | $ | 220,837 |  |
| Share-based compensation-products |  | 617 |  |  | 547 |  |
| Share-based compensation-services |  | 448 |  |  | 496 |  |
| Amortization of intangible assets |  | 5,384 |  |  | 2,201 |  |
| Total adjustments related to gross profit |  | 6,449 |  |  | 3,244 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 238,095 |  |  | $ | 224,081 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 40.8 | % |  | 37.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 232,063 |  |  | $ | 222,652 |  |
| Share-based compensation-research and development |  | 1,923 |  |  | 1,960 |  |
| Share-based compensation-sales and marketing |  | 3,603 |  |  | 2,759 |  |
| Share-based compensation-general and administrative |  | 3,157 |  |  | 3,025 |  |
| Amortization of intangible assets |  | 12,439 |  |  | 11,019 |  |
| Restructuring costs |  | 428 |  |  | 171 |  |
| Total adjustments related to operating expense |  | 21,550 |  |  | 18,934 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 210,513 |  |  | $ | 203,718 |  |
| Income (Loss) from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP loss from operations |  | $ | (417 | ) |  | $ | (1,815 | ) |
| Total adjustments related to gross profit |  | 6,449 |  |  | 3,244 |  |
| Total adjustments related to operating expense |  | 21,550 |  |  | 18,934 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 27,582 |  |  | 20,363 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 4.7 | % |  | 3.4 | % |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net loss |  | $ | (9,797 | ) |  | $ | (30,703 | ) |
| Total adjustments related to gross profit |  | 6,449 |  |  | 3,244 |  |
| Total adjustments related to operating expense |  | 21,550 |  |  | 18,934 |  |
| Non-cash interest expense |  | 284 |  |  | 351 |  |
| Change in fair value of embedded redemption feature |  | (230 | ) |  | — |  |
| Adjusted (non-GAAP) net income (loss) |  | $ | 18,256 |  |  | $ | (8,174 | ) |
| Weighted average basic common shares outstanding |  | 103,523 |  |  | 106,931 |  |
| Weighted average dilutive potential common shares outstanding1 |  | 119,401 |  |  | 106,931 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net loss per common share |  | $ | (0.09 | ) |  | $ | (0.29 | ) |
| Adjusted (non-GAAP) diluted net income (loss) per common share2 |  | $ | 0.16 |  |  | $ | (0.08 | ) |

[0000936395-14-000058:8k_2_02:60]
| APPENDIX B - Reconciliation of Adjusted (Non- GAAP) Annual Measurements (unaudited) |
|  |  | Year Ended |
|  |  | October 31, |
|  |  | 2013 |  | 2014 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 865,175 |  |  | $ | 948,352 |  |
| Share-based compensation-products |  | 2,522 |  |  | 2,531 |  |
| Share-based compensation-services |  | 1,771 |  |  | 2,216 |  |
| Amortization of intangible assets |  | 21,537 |  |  | 11,181 |  |
| Total adjustments related to gross profit |  | 25,830 |  |  | 15,928 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 891,005 |  |  | $ | 964,280 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 42.8 | % |  | 42.1 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 866,950 |  |  | $ | 902,648 |  |
| Share-based compensation-research and development |  | 8,214 |  |  | 9,682 |  |
| Share-based compensation-sales and marketing |  | 13,290 |  |  | 14,958 |  |
| Share-based compensation-general and administrative |  | 12,055 |  |  | 13,568 |  |
| Amortization of intangible assets |  | 49,771 |  |  | 45,970 |  |
| Restructuring costs |  | 7,169 |  |  | 349 |  |
| Settlement of patent litigation |  | 1,500 |  |  | 2,000 |  |
| Total adjustments related to operating expense |  | 91,999 |  |  | 86,527 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 774,951 |  |  | $ | 816,121 |  |
| Loss from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (1,775 | ) |  | $ | 45,704 |  |
| Total adjustments related to gross profit |  | 25,830 |  |  | 15,928 |  |
| Total adjustments related to operating expense |  | 91,999 |  |  | 86,527 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 116,054 |  |  | 148,159 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 5.6 | % |  | 6.5 | % |
| Loss Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net loss |  | $ | (85,431 | ) |  | $ | (40,637 | ) |
| Total adjustments related to gross profit |  | 25,830 |  |  | 15,928 |  |
| Total adjustments related to operating expense |  | 91,999 |  |  | 86,527 |  |
| Loss on extinguishment of debt |  | 28,630 |  |  | — |  |
| Non-cash interest expense |  | 898 |  |  | 1,273 |  |
| Change in fair value of embedded redemption feature |  | (2,950 | ) |  | 2,740 |  |
| Adjusted (non-GAAP) net income |  | $ | 58,976 |  |  | $ | 65,831 |  |
| Weighted average basic common shares outstanding |  | 102,350 |  |  | 105,783 |  |
| Weighted average dilutive potential common shares outstanding3 |  | 120,263 |  |  | 120,950 |  |
| Net Loss per Common Share |  |  |  |  |
| GAAP diluted net loss per common share |  | $ | (0.83 | ) |  | $ | (0.38 | ) |
| Adjusted (non-GAAP) diluted net income per common share4 |  | $ | 0.54 |  |  | $ | 0.59 |  |

[0000936395-14-000058:8k_2_02:61]
1.  Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2013 includes 2.8 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-14-000058:8k_2_02:62]
2. The calculation of Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2013 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-14-000058:8k_2_02:63]
3.  Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2013 includes 2.1 million shares underlying certain stock options and restricted stock units, 2.7 million shares underlying Ciena's 0.25% convertible senior notes due May 1, 2013 (which were paid at maturity during the second quarter of fiscal 2013) and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-14-000058:8k_2_02:64]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2014 includes 2.1 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-14-000058:8k_2_02:65]
4. The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2013 requires adding back interest expense of approximately $0.7 million associated with Ciena's 0.25% convertible senior notes due May 1, 2013 (which were paid during the second quarter of fiscal 2013) and approximately $5.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-14-000058:8k_2_02:66]
The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2014 requires adding back interest expense of approximately $5.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-14-000058:8k_2_02:67]
* * *

[0000936395-14-000058:8k_2_02:68]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-14-000058:8k_2_02:69]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-14-000058:8k_2_02:70]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over the expected useful life. |

[0000936395-14-000058:8k_2_02:71]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-14-000058:8k_2_02:72]
| • | Settlement of patent litigation - included in general and administrative expense is a $1.5 million patent litigation settlement during the third quarter of fiscal 2013 and a $2.0 million patent litigation settlement during the second quarter of fiscal 2014. |

[0000936395-14-000058:8k_2_02:73]
| • | Loss on extinguishment of debt - a non-cash loss, recorded in connection with convertible note exchange transactions completed during the first quarter of fiscal 2013, reflecting the fair value of Ciena's 4.0% senior convertible notes due December 15, 2020, as compared to the retirement of a portion of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |

[0000936395-14-000058:8k_2_02:74]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-14-000058:8k_2_02:75]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |
