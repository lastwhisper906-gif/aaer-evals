# CIEN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0000936395-14-000063:item_9a:1]
Item 9A.  Controls and Procedures

[0000936395-14-000063:item_9a:2]
Disclosure Controls and Procedures

[0000936395-14-000063:item_9a:3]
As of the end of the period covered by this report, we carried out an evaluation under the supervision and with the participation of management, including our Chief Executive Officer and Chief Financial Officer, of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended). Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0000936395-14-000063:item_9a:4]
Changes in Internal Control over Financial Reporting

[0000936395-14-000063:item_9a:5]
There was no change in Ciena’s internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended) during the most recently completed fiscal quarter that has materially affected, or is reasonably likely to materially affect, Ciena’s internal control over financial reporting.

[0000936395-14-000063:item_9a:6]
Report of Management on Internal Control Over Financial Reporting

[0000936395-14-000063:item_9a:7]
The management of Ciena Corporation is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934).

[0000936395-14-000063:item_9a:8]
The internal control over financial reporting at Ciena Corporation was designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America. Internal control over financial reporting includes those policies and procedures that:

[0000936395-14-000063:item_9a:9]
| • | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of Ciena Corporation; |

[0000936395-14-000063:item_9a:10]
| • | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with accounting principles generally accepted in the United States of America; |

[0000936395-14-000063:item_9a:11]
| • | provide reasonable assurance that receipts and expenditures of Ciena Corporation are being made only in accordance with authorization of management and directors of Ciena Corporation; and |

[0000936395-14-000063:item_9a:12]
| • | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of assets that could have a material effect on the consolidated financial statements. |

[0000936395-14-000063:item_9a:13]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements.

[0000936395-14-000063:item_9a:14]
Management of Ciena Corporation assessed the effectiveness of the company’s internal control over financial reporting as of October 31, 2014. Management based this assessment on criteria for effective internal control over financial reporting described in “Internal Control — Integrated Framework” issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, management determined that, as of October 31, 2014, Ciena Corporation maintained effective internal control over financial reporting. Management reviewed the results of its assessment with the Audit Committee of our Board of Directors.

[0000936395-14-000063:item_9a:15]
PricewaterhouseCoopers LLP, independent registered public accounting firm, who audited and reported on the consolidated financial statements of Ciena Corporation included in this annual report, has also audited the effectiveness of Ciena Corporation’s internal control over financial reporting as of October 31, 2014, as stated in its report appearing in Item 8 of Part II of this annual report.

[0000936395-14-000063:item_9a:16]
| /s/ Gary B. Smith |  | /s/ James E. Moylan, Jr. |  |
| Gary B. Smith |  | James E. Moylan, Jr. |  |
| President and Chief Executive Officer |  | Senior Vice President and Chief Financial Officer |  |
| December 19, 2014 |  | December 19, 2014 |  |
