# CIEN MD&A — 0000936395-14-000063


## mdna

[0000936395-14-000063:mdna:1]
Item 7.    Management's Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-14-000063:mdna:2]
Overview

[0000936395-14-000063:mdna:3]
We are a network specialist focused on communications networking solutions that enable converged, next-generation architectures, optimized to create and deliver the broad array of high-bandwidth services relied upon by business and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. These solutions enable network operators to adopt software-programmable network infrastructures that offer the on-demand experience required by end users of services and applications. At the same time, these solutions yield business and operational value for network operators.

[0000936395-14-000063:mdna:4]
Our Converged Packet Optical, Packet Networking, Optical Transport and Software products are used, individually or as part of an integrated solution, in networks operated by communications service providers, cable operators, Web-scale providers, governments, enterprises, research and education institutions and other network operators across the globe. Our products allow network operators to scale capacity, increase transmission speeds, allocate network traffic and adapt to changing end-user demands through rapid service creation and delivery. Our solutions also include network management and control software and network-level software applications that facilitate automation and efficient service delivery. To complement our hardware and software solutions, we offer a broad range of network transformation solutions and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-14-000063:mdna:5]
The rapid proliferation of communications services and devices, together with increased mobility and growth in cloud-based services, have fundamentally affected the demands placed upon communications networks and how they are designed. Network operators also face a rapidly changing business environment that includes a shifting competitive landscape and challenges to existing business models. Our OPn Architecture, and the increased network scalability, flexibility and programmability that it enables, is designed to meet these challenges. Our OPn network approach allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and network resources. This approach enables highly configurable infrastructures that can meet the "on-demand" requirements of end-users and the changing services they rely upon. By enhancing software programmability and control, enabling network functions virtually, and reducing required network elements, our OPn approach optimizes network infrastructures to connect content data centers, and users to such content. At the same time, our approach creates business and operational value for our customers by increasing scale at reduced cost and facilitating rapid introduction of new, revenue-generating service offerings. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the "Strategy" section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-14-000063:mdna:6]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-14-000063:mdna:7]
Market Opportunity

[0000936395-14-000063:mdna:8]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, technology convergence, increased mobility, and evolving cloud-based service

[0000936395-14-000063:mdna:9]
offerings and end-user demands. These conditions have created market opportunities and challenges that have impacted how networks are designed, as well as the competitive landscapes of network operators and the vendors that support them. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services. At the same time, network operators continue to seek to manage the costs of their network and to ensure a profitable business model. These dynamics are driving technology convergence of network features, functions and layers, virtualization of certain network functions, and the adoption of software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that these conditions will require vendors and network operators to leverage an open ecosystem of virtualized resources provided by a variety of third parties and will drive increased openness and interoperability of network infrastructures.

[0000936395-14-000063:mdna:10]
During fiscal 2014, we saw certain service provider customers increase efforts to constrain capital expenditure budgets, which adversely impacted certain segments of our market, including in the U.S. Notwithstanding these market dynamics, our strategy of focusing on certain higher growth segments of the network infrastructure market, combined with our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers, and additional service providers in geographies including Brazil and India, enabled us to continue to grow revenue in fiscal 2014. Our corporate strategy to capitalize on these market dynamics, promote operational efficiency and drive profitable growth of our business includes the initiatives set forth in the "Strategy" section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-14-000063:mdna:11]
Competitive Landscape

[0000936395-14-000063:mdna:12]
We continue to encounter a highly competitive and and fragmented marketplace. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approach. Our sales of Packet Networking solutions, including our 8700 Packetwave Platform, also face a highly competitive marketplace with additional competitors, including traditional IP router vendors. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-14-000063:mdna:13]
Within these competitive dynamics, maintaining incumbency with key customers domestically and abroad, and securing new opportunities with network operators often requires that we agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously and may in the future adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also elongate our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-14-000063:mdna:14]
Term Loan and Asset-Based Credit Facilities

[0000936395-14-000063:mdna:15]
During fiscal 2014, we entered into a credit agreement that provides for senior secured term loans in an aggregate principal amount of $250 million (the "Term Loan"). We expect to use the approximately $246 million in net proceeds to repay, in whole or part, the outstanding principal amount owing under our 4.00% senior convertible notes due March 15, 2015 ("2015 Notes") in the event the holders thereof do not elect to convert such notes into common stock prior to maturity. In the event the holders of such notes elect to convert their notes into common stock upon or prior to maturity, we may elect to repay the Term Loan, in whole or in part, or may utilize the net proceeds for other general corporate purposes, including the repayment or refinancing of other existing indebtedness. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this report for a summary of the material terms and conditions of the Term Loan and the related security documents.

[0000936395-14-000063:mdna:16]
During fiscal 2014, we also amended the terms of our existing senior secured asset-based revolving credit facility to, among other things, increase the total commitment under our ABL Credit Facility from $150 million to $200 million and to extend the maturity date from August 13, 2015 to December 31, 2016. See Note 15 to our Consolidated Financial Statements included in Item 8 of Part II of this report for a summary of the material terms and conditions of the amendment to this credit facility and the related security documents.

[0000936395-14-000063:mdna:17]
Financial Results for Fourth Quarter of Fiscal 2014

[0000936395-14-000063:mdna:18]
Revenue for the fourth quarter of fiscal 2014 was $591.0 million, representing a sequential decrease of 2.1% from $603.6 million in the third quarter of fiscal 2014. Revenue-related details reflecting sequential changes from the third quarter of fiscal 2014 include the following:

[0000936395-14-000063:mdna:19]
| • | Product revenue for the fourth quarter of fiscal 2014 decreased by $19.7 million, primarily reflecting decreases of $13.0 million in Packet Networking, $4.5 million in Optical Transport and $3.3 million in software in Software and Services. These decreases were partially offset by an increase of $1.2 million in Converged Packet Optical. Product revenue for Converged Packet Optical and Packet Networking were adversely impacted by a commercial arrangement with AT&T entered into in the fourth quarter of fiscal 2014 relating to our participation in AT&T's Domain 2.0 supplier program. The Domain 2.0 initiative is the next generation of AT&T's Supplier Domain Program, intended to enable AT&T to transition more quickly to next-generation, cloud-based architectures that embrace NFV and SDN, and accelerate their time to market with new products and services. |

[0000936395-14-000063:mdna:20]
| • | Service revenue for the fourth quarter of fiscal 2014 increased by $7.1 million. |

[0000936395-14-000063:mdna:21]
| • | Revenue from the United States for the fourth quarter of fiscal 2014 was $308.5 million, a decrease from $368.1 million in the third quarter of fiscal 2014. |

[0000936395-14-000063:mdna:22]
| • | International revenue for the fourth quarter of fiscal 2014 was $282.5 million, an increase from $235.5 million in the third quarter of fiscal 2014. |

[0000936395-14-000063:mdna:23]
| • | As a percentage of revenue, international revenue was 47.8% during the fourth quarter of fiscal 2014, an increase from 39.0% during the third quarter of fiscal 2014. |

[0000936395-14-000063:mdna:24]
| • | For the fourth quarter of fiscal 2014, one customer accounted for 12.2% of total revenue. This compared to one customer that accounted for 21.6% of total revenue in the third quarter of fiscal 2014. |

[0000936395-14-000063:mdna:25]
Gross margin for the fourth quarter of fiscal 2014 was 37.4%, a decrease from 43.7% in the third quarter of fiscal 2014. Gross margin for the fourth quarter of fiscal 2014 was adversely impacted by our commercial arrangement with AT&T, as described above, and revenue from multiple large international projects that are in the early stage of network deployment with higher related start-up costs that include a large concentration of lower margin "common" equipment and lower margin installation services.

[0000936395-14-000063:mdna:26]
Operating expense was $222.7 million for the fourth quarter of fiscal 2014, a decrease from $227.0 million in the third quarter of fiscal 2014. Fourth quarter operating expense reflects a decrease of $7.7 million in general and administrative expense. This decrease was partially offset by increases of $2.5 million in selling and marketing expense and $0.8 million in research and development expense.

[0000936395-14-000063:mdna:27]
Our lower revenue and gross margin resulted in a loss from operations of $1.8 million for the fourth quarter of fiscal 2014, as compared to $37.0 million of income from operations during the third quarter of fiscal 2014. Due primarily to the fluctuation in foreign currency exchange rates, net of hedging, we incurred losses in interest and other income, net of $10.7 million and $5.8 million during the fourth quarter of fiscal 2014 and the third quarter of fiscal 2014, respectively. Our net loss for the fourth quarter of fiscal 2014 was $30.7 million, or $0.29 per diluted common share. This compares to a net income of $16.2 million or $0.15 per diluted common share, for the third quarter of fiscal 2014.

[0000936395-14-000063:mdna:28]
We generated $73.8 million of cash from operations during the fourth quarter of fiscal 2014, consisting of $23.5 million provided by net losses adjusted for non-cash charges and $50.3 million provided by changes in working capital. This compares with $51.1 million in cash generated from operations during the third quarter of fiscal 2014, consisting of $80.9 million provided by net income adjusted for non-cash charges, offset by a $29.8 million use of cash related to changes in working capital.

[0000936395-14-000063:mdna:29]
As of October 31, 2014, we had $586.7 million in cash and cash equivalents, $140.2 million of short-term investments in U.S. treasury securities and commercial paper and $50.1 million of long-term investments in U.S. treasury securities. This compares to $532.9 million in cash and cash equivalents, $120.3 million of short-term investments in U.S. treasury securities and commercial paper, and $65.0 million of long-term investments in U.S. treasury securities at July 31, 2014 and $346.5 million in cash and cash equivalents, $125.0 million of short-term investments in U.S. treasury securities and commercial paper, and $15.0 million of long-term investments in U.S. treasury securities at October 31, 2013.

[0000936395-14-000063:mdna:30]
As of October 31, 2014, we had 5,161 employees, an increase from 5,136 as of July 31, 2014 and an increase from 4,754 and 4,481 at October 31, 2013 and 2012, respectively.

[0000936395-14-000063:mdna:31]
Consolidated Results of Operations

[0000936395-14-000063:mdna:32]
Operating Segments

[0000936395-14-000063:mdna:33]
Ciena’s internal organizational structure and the management of its business are grouped into the following operating segments each of which is more fully described in the "Products and Services" section of the description of our business in Item 1 of Part 1 of this annual report:

[0000936395-14-000063:mdna:34]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:mdna:35]
| • | Packet Networking — includes Ciena's 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes Ciena’s 8700 Packetwave Platform and Ciena's Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:mdna:36]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:mdna:37]
| • | Software and Services — includes Ciena's Agility software portfolio, which includes a SDN multilayer WAN controller, NFV platform, and network level software applications for enabling on-demand, high-bandwidth WAN services delivered in an open network ecosystem. This segment also includes the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager and Optical Suite Release. This segment includes a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-14-000063:mdna:38]
Fiscal 2013 compared to Fiscal 2014

[0000936395-14-000063:mdna:39]
Revenue

[0000936395-14-000063:mdna:40]
The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-14-000063:mdna:41]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,187,231 |  |  | 57.0 |  | $ | 1,455,501 |  |  | 63.6 |  | $ | 268,270 |  |  | 22.6 |  |
| Packet Networking | 222,898 |  |  | 10.7 |  | 244,116 |  |  | 10.7 |  | 21,218 |  |  | 9.5 |  |
| Optical Transport | 233,821 |  |  | 11.2 |  | 127,215 |  |  | 5.6 |  | (106,606 | ) |  | (45.6 | ) |
| Software and Services | 438,596 |  |  | 21.1 |  | 461,457 |  |  | 20.1 |  | 22,861 |  |  | 5.2 |  |
| Consolidated revenue | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |  |

[0000936395-14-000063:mdna:42]
_________________________________

[0000936395-14-000063:mdna:43]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:44]
| • | Converged Packet Optical revenue increased significantly, reflecting a $258.2 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider and Web-scale provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 reconfigurable switching system and the OTN configuration for the 5410 Reconfigurable Switching System increased by $25.6 million and $6.0 million respectively. These increases were partially offset by a $21.5 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-14-000063:mdna:45]
| • | Packet Networking revenue increased, reflecting a $30.4 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was largely driven by the expansion of Ethernet business services by AT&T, our largest service provider customer. Segment revenue also benefited from $1.7 million in initial sales of our 8700 Packetwave Platform. These increases were partially offset by decreases of $5.3 million in sales of our 5410 Service Aggregation Switch and $5.1 million in sales of our older, stand-alone broadband products. |

[0000936395-14-000063:mdna:46]
| • | Optical Transport revenue decreased, reflecting sales decreases of $46.6 million in other stand-alone transport products, $36.2 million of 5100/5200 Advanced Services Platform and $23.8 million in our 4200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000063:mdna:47]
| • | Software and Services revenue increased, reflecting increases of $10.4 million in maintenance and support services revenue, $8.4 million in installation and deployment services revenue, $2.8 million in software sales and $1.2 million in networking transformation consulting revenue. |

[0000936395-14-000063:mdna:48]
Revenue from sales to customers outside of the United States is reflected as International in the geographic distribution of revenue below. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-14-000063:mdna:49]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| United States | $ | 1,217,462 |  |  | 58.5 |  | $ | 1,317,981 |  |  | 57.6 |  | $ | 100,519 |  |  | 8.3 |
| International | 865,084 |  |  | 41.5 |  | 970,308 |  |  | 42.4 |  | 105,224 |  |  | 12.2 |
| Total | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |

[0000936395-14-000063:mdna:50]
_________________________________

[0000936395-14-000063:mdna:51]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:52]
| • | United States revenue reflects increases of $123.8 million in Converged Packet Optical sales, $20.3 million in Packet Networking sales and $20.7 million in Services and Software sales. In particular, during fiscal 2014, we benefited from the diversification of our customer base, including increased sales of our Converged Packet Optical products to Web-scale providers and data center operators, as these customers added capacity and adopted next-generation network architectures better able to handle multi-service traffic growth. We also increased sales of our Packet Networking and Converged Packet Optical products to AT&T in support of its Ethernet business services and increased demand for high-capacity, optical transport. These increases were partially offset by a $64.3 million decrease in Optical Transport sales as network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-14-000063:mdna:53]
| • | International revenue reflects increases of $144.5 million in Converged Packet Optical sales and $2.2 million in Software and Services revenue. We benefited from the diversification of our customer base including increased sales of our Converged Packet Optical products to service provider customers, submarine consortia and cable and |

[0000936395-14-000063:mdna:54]
39

[0000936395-14-000063:mdna:55]
multiservice operators. These increases were partially offset by decreases of $42.3 million in Optical Transport sales as network operators' transition toward next-generation converged network architectures as described above.

[0000936395-14-000063:mdna:56]
While we have benefited from the diversification of our business and customer base, our largest ten customers contributed 59.4% of fiscal 2013 revenue and 56.4% of fiscal 2014 revenue. A sizable portion of our revenue continues to come from sales to service provider customers. As a result, our financial results are significantly affected by and can fluctuate depending upon spending levels of our service provider customers, their end-user demand and the business opportunities and challenges they encounter. Sales to AT&T were $373.6 million, or 17.9% of total revenue, in fiscal 2013 and $423.5 million, or 18.5% of total revenue, in fiscal 2014. We did not have any other customers accounting for greater than 10% of our revenue in fiscal 2013 or fiscal 2014.

[0000936395-14-000063:mdna:57]
Cost of Goods Sold and Gross Profit

[0000936395-14-000063:mdna:58]
Product cost of goods sold consists primarily of amounts paid to third party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-14-000063:mdna:59]
Services cost of goods sold consists primarily of direct and third party costs, including employee-related costs, associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts.

[0000936395-14-000063:mdna:60]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. Gross margin can also be adversely affected by the level of pricing pressure and competition that we encounter in the market. We expect that gross margins will be subject to fluctuation based on our level of success in driving product cost reductions relative to the market-based price erosion we encounter. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites as part of our effort to optimize our operations. These market dynamics and factors may adversely affect our gross margin and results of operations in certain periods.

[0000936395-14-000063:mdna:61]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-14-000063:mdna:62]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-14-000063:mdna:63]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |
| Total cost of goods sold | 1,217,371 |  |  | 58.5 |  | 1,339,937 |  |  | 58.6 |  | 122,566 |  |  | 10.1 |
| Gross profit | $ | 865,175 |  |  | 41.5 |  | $ | 948,352 |  |  | 41.4 |  | $ | 83,177 |  |  | 9.6 |

[0000936395-14-000063:mdna:64]
_________________________________

[0000936395-14-000063:mdna:65]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:66]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 1,680,125 |  |  | 100.0 |  | $ | 1,865,826 |  |  | 100.0 |  | $ | 185,701 |  |  | 11.1 |
| Product cost of goods sold | 967,510 |  |  | 57.6 |  | 1,083,022 |  |  | 58.0 |  | 115,512 |  |  | 11.9 |
| Product gross profit | $ | 712,615 |  |  | 42.4 |  | $ | 782,804 |  |  | 42.0 |  | $ | 70,189 |  |  | 9.8 |

[0000936395-14-000063:mdna:67]
_________________________________

[0000936395-14-000063:mdna:68]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:69]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 402,421 |  |  | 100.0 |  | $ | 422,463 |  |  | 100.0 |  | $ | 20,042 |  |  | 5.0 |
| Service cost of goods sold | 249,861 |  |  | 62.1 |  | 256,915 |  |  | 60.8 |  | 7,054 |  |  | 2.8 |
| Service gross profit | $ | 152,560 |  |  | 37.9 |  | $ | 165,548 |  |  | 39.2 |  | $ | 12,988 |  |  | 8.5 |

[0000936395-14-000063:mdna:70]
_________________________________

[0000936395-14-000063:mdna:71]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:72]
| • | Gross profit as a percentage of revenue remained relatively unchanged. |

[0000936395-14-000063:mdna:73]
| • | Gross profit on products as a percentage of product revenue decreased slightly, due to lower margins on Packet Networking and Optical Transport products. The decline was largely offset by improved mix of higher-margin packet platforms with software content within our Converged Packet Optical segment, and greater leverage from efforts to streamline and optimize our supply chain activities. |

[0000936395-14-000063:mdna:74]
| • | Gross profit on services as a percentage of services revenue increased primarily due to increased maintenance and consulting services revenues and increased margin due to improved efficiencies for managed spares projects. |

[0000936395-14-000063:mdna:75]
Operating Expense

[0000936395-14-000063:mdna:76]
We expect operating expense to increase slightly in fiscal 2015 from the level reported for fiscal 2014 to support the growth of our business, to fund our research and development initiatives and to provide for investments in the re-engineering of company-wide enterprise resource planning platforms. Operating expense consists of the component elements described below.

[0000936395-14-000063:mdna:77]
Research and development expense primarily consists of salaries and related employee expense (including share-based  compensation expense), prototype costs relating to design, development, and testing of our products, depreciation expense and third party consulting costs.

[0000936395-14-000063:mdna:78]
Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense), and sales and marketing support expense, including travel, demonstration units, trade show expense and third party consulting costs.

[0000936395-14-000063:mdna:79]
General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense), and costs for third party consulting and other services.

[0000936395-14-000063:mdna:80]
Amortization of intangible assets primarily reflects the amortization of purchased technology and the value of customer relationships derived from our past acquisitions.

[0000936395-14-000063:mdna:81]
Restructuring costs primarily reflect actions Ciena has taken to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions.

[0000936395-14-000063:mdna:82]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-14-000063:mdna:83]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 383,408 |  |  | 18.4 |  | $ | 401,180 |  |  | 17.5 |  | $ | 17,772 |  |  | 4.6 |  |
| Selling and marketing | 304,170 |  |  | 14.6 |  | 328,325 |  |  | 14.3 |  | 24,155 |  |  | 7.9 |  |
| General and administrative | 122,432 |  |  | 5.9 |  | 126,824 |  |  | 5.5 |  | 4,392 |  |  | 3.6 |  |
| Amortization of intangible assets | 49,771 |  |  | 2.4 |  | 45,970 |  |  | 2.0 |  | (3,801 | ) |  | (7.6 | ) |
| Restructuring costs | 7,169 |  |  | 0.3 |  | 349 |  |  | — |  | (6,820 | ) |  | (95.1 | ) |
| Total operating expenses | $ | 866,950 |  |  | 41.6 |  | $ | 902,648 |  |  | 39.3 |  | $ | 35,698 |  |  | 4.1 |  |

[0000936395-14-000063:mdna:84]
_________________________________

[0000936395-14-000063:mdna:85]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:86]
| • | Research and development expense benefited by $15.4 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $17.8 million increase primarily reflects increases of $8.1 million in professional services expense, $6.9 million in employee compensation and related costs, $5.3 million in prototype expense, partially offset by a decrease of $2.6 million in technology and related costs. |

[0000936395-14-000063:mdna:87]
| • | Selling and marketing expense benefited by $1.9 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $24.2 million increase primarily reflects increases of $20.6 million in employee compensation and related costs, $3.3 million of travel and related costs and $1.2 million in facilities and information technology costs. These increases were partially offset by a decrease of $1.4 million in customer demonstration equipment. |

[0000936395-14-000063:mdna:88]
| • | General and administrative expense increased by $4.4 million, primarily reflecting an increase in legal fees and settlements and consulting services. |

[0000936395-14-000063:mdna:89]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-14-000063:mdna:90]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and restructuring activities to align our workforce and resources with market opportunities and research and development initiatives. Restructuring costs for fiscal 2013 also include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility. |

[0000936395-14-000063:mdna:91]
Other items

[0000936395-14-000063:mdna:92]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-14-000063:mdna:93]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (5,744 | ) |  | (0.3 | ) |  | $ | (25,262 | ) |  | (1.1 | ) |  | $ | (19,518 | ) |  | (339.8 | ) |
| Interest expense | $ | 44,042 |  |  | 2.1 |  |  | $ | 47,115 |  |  | 2.1 |  |  | $ | 3,073 |  |  | 7.0 |  |
| Loss on debt extinguishment | $ | (28,630 | ) |  | (1.4 | ) |  | $ | — |  |  | — |  |  | $ | 28,630 |  |  | (100.0 | ) |
| Provision for income taxes | $ | 5,240 |  |  | 0.3 |  |  | $ | 13,964 |  |  | 0.6 |  |  | $ | 8,724 |  |  | 166.5 |  |

[0000936395-14-000063:mdna:94]
_________________________________

[0000936395-14-000063:mdna:95]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:96]
| • | Interest and other income (loss), net reflects a $5.7 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 2015 Notes and a $13.5 million increase in losses related to foreign |

[0000936395-14-000063:mdna:97]
42

[0000936395-14-000063:mdna:98]
exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-14-000063:mdna:99]
| • | Interest expense increased primarily due to the Term Loan that was entered into in fiscal 2014, as described in "Overview" above. |

[0000936395-14-000063:mdna:100]
| • | Loss on extinguishment of debt for fiscal 2013 reflects a non-cash loss of $28.6 million relating to the exchange transactions during the first quarter of fiscal 2013. Upon issuance, the 4.0% convertible senior notes due December 15, 2020 (the "2020 Notes") were recorded at a fair value of $213.6 million. The exchange transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million and the write-off of unamortized debt issuance costs of $2.3 million and $0.6 million relating to the redemption feature on the 2015 Notes, which was accounted for as a separate embedded derivative. |

[0000936395-14-000063:mdna:101]
| • | Provision for income taxes increased primarily due to foreign and state tax expenses. |

[0000936395-14-000063:mdna:102]
Fiscal 2012 compared to Fiscal 2013

[0000936395-14-000063:mdna:103]
Revenue

[0000936395-14-000063:mdna:104]
The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-14-000063:mdna:105]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 951,245 |  |  | 51.9 |  | $ | 1,187,231 |  |  | 57.0 |  | $ | 235,986 |  |  | 24.8 |  |
| Packet Networking | 128,982 |  |  | 7.0 |  | 222,898 |  |  | 10.7 |  | 93,916 |  |  | 72.8 |  |
| Optical Transport | 353,620 |  |  | 19.3 |  | 233,821 |  |  | 11.2 |  | (119,799 | ) |  | (33.9 | ) |
| Software and Services | 400,076 |  |  | 21.8 |  | 438,596 |  |  | 21.1 |  | 38,520 |  |  | 9.6 |  |
| Consolidated revenue | $ | 1,833,923 |  |  | 100.0 |  | $ | 2,082,546 |  |  | 100.0 |  | $ | 248,623 |  |  | 13.6 |  |

[0000936395-14-000063:mdna:106]
_________________________________

[0000936395-14-000063:mdna:107]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:108]
| • | Converged Packet Optical revenue increased significantly, reflecting a $176.7 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 reconfigurable switching system and the OTN configuration for the 5410 Reconfigurable Switching System increased by $71.0 million and $10.3 million respectively. These increases were partially offset by a $22.0 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected annual revenue declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-14-000063:mdna:109]
| • | Packet Networking revenue increased, reflecting a $101.0 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was slightly offset by a $4.9 million decrease in sales of our 5410 Service Aggregation Switch and a $2.7 million decrease in sales of our older stand-alone broadband products. Segment revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service delivery and aggregation products in support of their related network initiatives. |

[0000936395-14-000063:mdna:110]
| • | Optical Transport revenue decreased, reflecting sales decreases of $55.0 million in our 4200 Advanced Services Platform, $42.6 million in other stand-alone transport products and $22.1 million in our 5100/5200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-14-000063:mdna:111]
| • | Software and Services revenue increased, reflecting sales increases of $15.0 million in software, $14.2 million in installation and deployment, $7.6 million in maintenance and support services and $1.7 million in network transformation consulting services. |

[0000936395-14-000063:mdna:112]
Revenue from sales to customers outside of the United States is reflected as International in the geographic distribution of revenue below. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-14-000063:mdna:113]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| United States | $ | 972,576 |  |  | 53.0 |  | $ | 1,217,462 |  |  | 58.5 |  | $ | 244,886 |  |  | 25.2 |
| International | 861,347 |  |  | 47.0 |  | 865,084 |  |  | 41.5 |  | 3,737 |  |  | 0.4 |
| Total | $ | 1,833,923 |  |  | 100.0 |  | $ | 2,082,546 |  |  | 100.0 |  | $ | 248,623 |  |  | 13.6 |

[0000936395-14-000063:mdna:114]
_________________________________

[0000936395-14-000063:mdna:115]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:116]
| • | United States revenue reflects increases of $152.0 million in Converged Packet Optical sales, $95.5 million in Packet Networking sales, and $28.2 million in Software and Services revenue. These increases were partially offset by a $30.9 million decrease in Optical Transport sales. Increased revenues reflect early adoption by network operators in the United States of converged network architectures that align well with our OPn Architecture and solutions offering. |

[0000936395-14-000063:mdna:117]
| • | International revenue reflects increases of $84.0 million in Converged Packet Optical sales and $10.3 million increase in Software and Services revenue. These increases were partially offset by decreases of $88.9 million in Optical Transport sales and $1.6 million in Packet Networking sales. |

[0000936395-14-000063:mdna:118]
Cost of Goods Sold and Gross Profit

[0000936395-14-000063:mdna:119]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-14-000063:mdna:120]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 1,833,923 |  |  | 100.0 |  | $ | 2,082,546 |  |  | 100.0 |  | $ | 248,623 |  |  | 13.6 |
| Total cost of goods sold | 1,109,699 |  |  | 60.5 |  | 1,217,371 |  |  | 58.5 |  | 107,672 |  |  | 9.7 |
| Gross profit | $ | 724,224 |  |  | 39.5 |  | $ | 865,175 |  |  | 41.5 |  | $ | 140,951 |  |  | 19.5 |

[0000936395-14-000063:mdna:121]
_________________________________

[0000936395-14-000063:mdna:122]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:123]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 1,454,991 |  |  | 100.0 |  | $ | 1,680,125 |  |  | 100.0 |  | $ | 225,134 |  |  | 15.5 |
| Product cost of goods sold | 868,805 |  |  | 59.7 |  | 967,510 |  |  | 57.6 |  | 98,705 |  |  | 11.4 |
| Product gross profit | $ | 586,186 |  |  | 40.3 |  | $ | 712,615 |  |  | 42.4 |  | $ | 126,429 |  |  | 21.6 |

[0000936395-14-000063:mdna:124]
_________________________________

[0000936395-14-000063:mdna:125]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:126]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 378,932 |  |  | 100.0 |  | $ | 402,421 |  |  | 100.0 |  | $ | 23,489 |  |  | 6.2 |
| Service cost of goods sold | 240,894 |  |  | 63.6 |  | 249,861 |  |  | 62.1 |  | 8,967 |  |  | 3.7 |
| Service gross profit | $ | 138,038 |  |  | 36.4 |  | $ | 152,560 |  |  | 37.9 |  | $ | 14,522 |  |  | 10.5 |

[0000936395-14-000063:mdna:127]
_________________________________

[0000936395-14-000063:mdna:128]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:129]
| • | Gross profit as a percentage of revenue increased as a result of the factors described below. |

[0000936395-14-000063:mdna:130]
| • | Gross profit on products as a percentage of product revenue increased primarily due to improved mix of higher-margin packet platforms with software content, including within our Packet Networking and Converged Packet Optical segments, higher sales of integrated network service management software, lower warranty costs, and greater leverage from efforts to streamline and optimize our supply chain activities. |

[0000936395-14-000063:mdna:131]
| • | Gross profit on services as a percentage of services revenue increased primarily due to improved margins on installation and deployment services due to improved operational efficiencies, and increased consulting service revenue from our Network Transformation Solutions offering. |

[0000936395-14-000063:mdna:132]
Operating expense

[0000936395-14-000063:mdna:133]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-14-000063:mdna:134]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 364,179 |  |  | 19.9 |  | $ | 383,408 |  |  | 18.4 |  | $ | 19,229 |  |  | 5.3 |  |
| Selling and marketing | 266,338 |  |  | 14.5 |  | 304,170 |  |  | 14.6 |  | 37,832 |  |  | 14.2 |  |
| General and administrative | 114,002 |  |  | 6.2 |  | 122,432 |  |  | 5.9 |  | 8,430 |  |  | 7.4 |  |
| Amortization of intangible assets | 51,697 |  |  | 2.8 |  | 49,771 |  |  | 2.4 |  | (1,926 | ) |  | (3.7 | ) |
| Restructuring costs | 7,854 |  |  | 0.4 |  | 7,169 |  |  | 0.3 |  | (685 | ) |  | (8.7 | ) |
| Total operating expenses | $ | 804,070 |  |  | 43.8 |  | $ | 866,950 |  |  | 41.6 |  | $ | 62,880 |  |  | 7.8 |  |

[0000936395-14-000063:mdna:135]
_________________________________

[0000936395-14-000063:mdna:136]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:137]
| • | Research and development expense benefited from $4.0 million as a result of foreign exchange rates, primarily due to the strengthening of the U.S. dollar in relation to the Canadian dollar and the Indian Rupee. The $19.2 million increase primarily reflects increases of $15.9 million in employee compensation and related costs, $7.5 million in prototype expense, $5.2 million in facilities and information systems expense and $2.1 million in technology-related purchases. The increase in employee compensation is primarily related to incentive-based compensation. These increases were partially offset by a $12.5 million decrease in professional services. |

[0000936395-14-000063:mdna:138]
| • | Selling and marketing expense increased by $37.8 million, primarily reflecting increases of $26.5 million in employee compensation and related costs, $6.8 million in facilities and information systems expense, $4.5 million of travel and related costs, $2.0 million in trade show and related expense and $1.1 million in professional services. A significant portion of our increased employee compensation and related costs reflect commissions-based compensation associated with strong order flows achieved during fiscal 2013. These increases were partially offset by decreases of $1.9 million of freight and logistic costs and $1.3 million for customer demonstration equipment. |

[0000936395-14-000063:mdna:139]
| • | General and administrative expense increased by $8.4 million primarily reflecting an increase of $10.8 million in employee compensation and related costs, partially offset by a $2.7 million decrease in facilities and information systems expense. The increase in employee compensation is primarily related to incentive-based compensation. |

[0000936395-14-000063:mdna:140]
45

[0000936395-14-000063:mdna:141]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-14-000063:mdna:142]
| • | Restructuring costs for fiscal 2012 and 2013 primarily reflect certain severance and related expense associated with headcount reductions and restructuring activities to align our workforce and resources with market opportunities and research and development initiatives. In addition, restructuring costs for fiscal 2012 and 2013 include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility. |

[0000936395-14-000063:mdna:143]
Other items

[0000936395-14-000063:mdna:144]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-14-000063:mdna:145]
|  | Fiscal Year |  |  |  |  |
|  | 2012 |  | %* |  | 2013 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (15,200 | ) |  | (0.8 | ) |  | $ | (5,744 | ) |  | (0.3 | ) |  | $ | 9,456 |  |  | 62.2 |  |
| Interest expense | $ | 39,653 |  |  | 2.2 |  |  | $ | 44,042 |  |  | 2.1 |  |  | $ | 4,389 |  |  | 11.1 |  |
| Loss on extinguishment of debt | $ | — |  |  | 0.0 |  |  | $ | (28,630 | ) |  | (1.4 | ) |  | $ | (28,630 | ) |  | (100.0 | ) |
| Provision for income taxes | $ | 9,322 |  |  | 0.5 |  |  | $ | 5,240 |  |  | 0.3 |  |  | $ | (4,082 | ) |  | (43.8 | ) |

[0000936395-14-000063:mdna:146]
_________________________________

[0000936395-14-000063:mdna:147]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:148]
| • | Interest and other income (loss), net in fiscal 2013, reflects a $3.0 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 2015 Notes. In fiscal 2012, interest and other income (loss), net reflected a $6.6 million non-cash loss related to the change in fair value of the embedded redemption feature. |

[0000936395-14-000063:mdna:149]
| • | Interest expense increased, reflecting increases of $3.0 million relating to our convertible note exchange transactions during the first quarter of fiscal 2013, and $2.1 million in expense relating to our asset-backed loan facility entered into during fiscal 2012. These increases were partially offset by a decrease of interest expense in fiscal 2013 of $0.6 million, principally due to the repayment of our 0.25% convertible senior notes at maturity in the second quarter of fiscal 2013. |

[0000936395-14-000063:mdna:150]
| • | Loss on extinguishment of debt reflects a non-cash loss of $28.6 million relating to the exchange transactions during the first quarter of fiscal 2013. Upon issuance, the 2020 Notes were recorded at a fair value of $213.6 million. The exchange transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million and the write-off of unamortized debt issuance costs of $2.3 million and $0.6 million relating to the redemption feature on the 2015 Notes accounted for as a separate embedded derivative. |

[0000936395-14-000063:mdna:151]
| • | Provision for income taxes for fiscal 2012 and fiscal 2013 are primarily related to foreign tax expense. The decrease in fiscal 2013 is largely attributable to the recognition of prior uncertain tax benefits. |

[0000936395-14-000063:mdna:152]
Segment Profit

[0000936395-14-000063:mdna:153]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-14-000063:mdna:154]
|  | Fiscal Year |  |  |
|  | 2013 |  | 2014 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 242,335 |  |  | $ | 353,942 |  |  | $ | 111,607 |  |  | 46.1 |  |
| Packet Networking | $ | 22,740 |  |  | $ | 19,467 |  |  | $ | (3,273 | ) |  | (14.4 | ) |
| Optical Transport | $ | 89,754 |  |  | $ | 38,974 |  |  | $ | (50,780 | ) |  | (56.6 | ) |
| Software and Services | $ | 126,938 |  |  | $ | 134,789 |  |  | $ | 7,851 |  |  | 6.2 |  |

[0000936395-14-000063:mdna:155]
_________________________________

[0000936395-14-000063:mdna:156]
| * | Denotes % change from 2013 to 2014 |

[0000936395-14-000063:mdna:157]
| • | Converged Packet Optical segment profit increased primarily due to increased sales volume and improved gross margin. The increased sales volume is largely driven by service provider and Web-scale provider demand for high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. The improved gross margin is primarily due to sales reflecting a greater mix of higher-margin packet platforms with software content within the segment. These increases were partially offset by increased research and development expense. |

[0000936395-14-000063:mdna:158]
| • | Packet Networking segment profit decreased due to lower margins on our 3000 and 5000 families of service delivery and aggregation switches, reflecting increased pricing pressure and competitive dynamics, and increased research and development expense. Decreased segment profit was partially offset by increased sales volume. |

[0000936395-14-000063:mdna:159]
| • | Optical Transport segment profit decreased primarily due to reduced sales volume and lower gross margin, partially offset by lower research and development expense. The decrease in gross margin is primarily due to an increase in obsolete and excess inventory expense for the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-14-000063:mdna:160]
| • | Software and Services segment profit increased slightly due to higher sales for software and consulting services and improved efficiencies for managed spares projects. These increases were partially offset by higher software research and development expense. |

[0000936395-14-000063:mdna:161]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-14-000063:mdna:162]
|  | Fiscal Year |  |  |
|  | 2012 |  | 2013 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 148,244 |  |  | $ | 242,335 |  |  | $ | 94,091 |  |  | 63.5 |  |
| Packet Networking | $ | 1,713 |  |  | $ | 22,740 |  |  | $ | 21,027 |  |  | 1,227.5 |  |
| Optical Transport | $ | 116,736 |  |  | $ | 89,754 |  |  | $ | (26,982 | ) |  | (23.1 | ) |
| Software and Services | $ | 93,352 |  |  | $ | 126,938 |  |  | $ | 33,586 |  |  | 36.0 |  |

[0000936395-14-000063:mdna:163]
_________________________________

[0000936395-14-000063:mdna:164]
| * | Denotes % change from 2012 to 2013 |

[0000936395-14-000063:mdna:165]
| • | Converged Packet Optical segment profit increased primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. The increased sales volume is largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures and improved gross margin due to a greater mix of higher-margin packet platforms with software content within the segment. |

[0000936395-14-000063:mdna:166]
| • | Packet Networking segment profit increased primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Packet Networking revenue benefited from the expansion of Ethernet business services by our North American service provider customers and sales of service |

[0000936395-14-000063:mdna:167]
47

[0000936395-14-000063:mdna:168]
delivery and aggregation products in support of their related network initiatives. Gross margin improved due to a greater mix of higher-margin packet platforms with software content within the segment.

[0000936395-14-000063:mdna:169]
| • | Optical Transport segment profit decreased primarily due to reduced sales volume, partially offset by improved gross margin and lower research and development expense. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-14-000063:mdna:170]
| • | Software and Services segment profit increased primarily due to increased sales volume and improved gross margin. The increased sales volume is primarily due to higher sales for our software products and installation services. The improved margins are primarily installation and deployment services margins due to improved operational efficiencies. |

[0000936395-14-000063:mdna:171]
Liquidity and Capital Resources

[0000936395-14-000063:mdna:172]
At October 31, 2014, our principal sources of liquidity were cash and cash equivalents and investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-14-000063:mdna:173]
|  | October 31, |  | Increase |
|  | 2013 |  | 2014 |  | (decrease) |
| Cash and cash equivalents | $ | 346,487 |  |  | $ | 586,720 |  |  | $ | 240,233 |  |
| Short-term investments in marketable debt securities | 124,979 |  |  | 140,205 |  |  | 15,226 |  |
| Long-term investments in marketable debt securities | 15,031 |  |  | 50,057 |  |  | 35,026 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 486,497 |  |  | $ | 776,982 |  |  | $ | 290,485 |  |

[0000936395-14-000063:mdna:174]
The change in total cash and cash equivalents and investments in marketable debt securities during fiscal 2014 was primarily related to the $246.0 million in net proceeds from our Term Loan as described in "Overview" above and the following:

[0000936395-14-000063:mdna:175]
| • | $89.8 million cash provided by operations, consisting of $195.2 million provided by net losses adjusted for non-cash charges offset by $105.4 million used in working capital; |

[0000936395-14-000063:mdna:176]
| • | $48.2 million used for purchases of equipment, furniture, fixtures and intellectual property; |

[0000936395-14-000063:mdna:177]
| • | $10.0 million used in settlement of foreign currency forward contracts, net; |

[0000936395-14-000063:mdna:178]
| • | $3.0 million used to pay capital lease obligations; and |

[0000936395-14-000063:mdna:179]
| • | $17.7 million from proceeds of stock issuances under our employee stock purchase plan and the exercise of stock options. |

[0000936395-14-000063:mdna:180]
As of October 31, 2014, letters of credit totaling $71.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2014. See "ABL Credit Facility" below for additional information.

[0000936395-14-000063:mdna:181]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, the repayment of our outstanding 4.0% convertible senior notes due March 15, 2015 and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-14-000063:mdna:182]
The following sections set forth the components of our $89.8 million of cash provided by operating activities for fiscal 2014:

[0000936395-14-000063:mdna:183]
Net loss adjusted for non-cash charges

[0000936395-14-000063:mdna:184]
The following tables set forth (in thousands) our net loss adjusted for non-cash charges during the period:

[0000936395-14-000063:mdna:185]
|  | Year ended |
|  | October 31, 2014 |
| Net loss | $ | (40,637 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 55,616 |  |
| Share-based compensation costs | 42,930 |  |
| Amortization of intangible assets | 57,151 |  |
| Provision for inventory excess and obsolescence | 32,332 |  |
| Provision for warranty | 22,129 |  |
| Other | 25,668 |  |
| Net losses adjusted for non-cash charges | $ | 195,189 |  |

[0000936395-14-000063:mdna:186]
Working Capital

[0000936395-14-000063:mdna:187]
Accounts Receivable, Net

[0000936395-14-000063:mdna:188]
Cash used in increases in accounts receivable during fiscal 2014, net of $2.8 million in provision for doubtful accounts, was $33.2 million. This reflects an increase in our revenue, partially offset by a decrease in days sales outstanding. Our days sales outstanding (DSOs) decreased from 84 days for fiscal 2013 to 82 days for fiscal 2014. The decrease in DSOs primarily reflects shorter customer payment terms.

[0000936395-14-000063:mdna:189]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2013 through the end of fiscal 2014:

[0000936395-14-000063:mdna:190]
|  | October 31, |  | Increase |
|  | 2013 |  | 2014 |  | (decrease) |
| Accounts receivable, net | $ | 488,578 |  |  | $ | 518,981 |  |  | $ | 30,403 |  |

[0000936395-14-000063:mdna:191]
Inventory

[0000936395-14-000063:mdna:192]
Cash used in increases in inventory during fiscal 2014 was $37.9 million. The increase in inventory reflects our decision to carry more finished goods inventory for our Converged Packet Optical products to reduce our lead times for shipments to customers. Our inventory turns increased from 3.9 turns during fiscal 2013 to 4.3 turns during fiscal 2014. Our inventory balance, as reported on our Consolidated Balance Sheet, increased by $5.6 million during fiscal 2014. This change reflects our $37.9 million cash usage for inventory, partially offset by a $32.3 million non-cash provision for excess and obsolescence. The following table sets forth changes (in thousands) to the components of our inventory from the end of fiscal 2013 through the end of fiscal 2014:

[0000936395-14-000063:mdna:193]
|  | October 31, |  | Increase |
|  | 2013 |  | 2014 |  | (decrease) |
| Raw materials | $ | 53,274 |  |  | $ | 64,853 |  |  | $ | 11,579 |  |
| Work-in-process | 7,773 |  |  | 8,371 |  |  | 598 |  |
| Finished goods | 153,855 |  |  | 165,799 |  |  | 11,944 |  |
| Deferred cost of goods sold | 75,764 |  |  | 75,763 |  |  | (1 | ) |
| Gross inventory | 290,666 |  |  | 314,786 |  |  | 24,120 |  |
| Provision for inventory excess and obsolescence | (41,563 | ) |  | (60,126 | ) |  | (18,563 | ) |
| Inventory | $ | 249,103 |  |  | $ | 254,660 |  |  | $ | 5,557 |  |

[0000936395-14-000063:mdna:194]
Prepaid expenses and other

[0000936395-14-000063:mdna:195]
Cash used in prepaid expense and other during fiscal 2014 was $7.9 million and primarily related to higher product demonstration equipment and deferred deployment expense.

[0000936395-14-000063:mdna:196]
Accounts payable, accruals and other obligations

[0000936395-14-000063:mdna:197]
Utilization of cash resources for accounts payable, accruals and other obligations during fiscal 2014 was $59.8 million. This amount reflects a $29.5 million decrease in our accounts payable, accruals and other obligations plus additional liabilities recorded for the following items: $22.1 million relating to warranties; $7.3 million for financing activities relating to unpaid capital leases; and $2.1 million related to our interest rate swap derivative. These items were partially offset by a decrease of $1.2 million for investing activities related to equipment purchases.

[0000936395-14-000063:mdna:198]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2013 through the end of fiscal 2014:

[0000936395-14-000063:mdna:199]
|  | October 31, |  | Increase |
|  | 2013 |  | 2014 |  | (decrease) |
| Accounts payable | $ | 254,849 |  |  | $ | 209,777 |  |  | $ | (45,072 | ) |
| Accrued liabilities and other short-term obligations | 271,656 |  |  | 276,608 |  |  | 4,952 |  |
| Other long-term obligations | 34,753 |  |  | 45,390 |  |  | 10,637 |  |
| Accounts payable, accruals and other obligations | $ | 561,258 |  |  | $ | 531,775 |  |  | $ | (29,483 | ) |

[0000936395-14-000063:mdna:200]
Interest Paid on Convertible Notes, ABL Credit Facility and Term Loan

[0000936395-14-000063:mdna:201]
Interest on our outstanding 4.0% convertible senior notes, due March 15, 2015, is payable on March 15 and September 15 of each year. We paid $7.5 million in interest on these convertible notes during fiscal 2014.

[0000936395-14-000063:mdna:202]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $4.4 million in interest on these convertible notes during fiscal 2014.

[0000936395-14-000063:mdna:203]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. We paid $13.1 million in interest on these convertible notes during fiscal 2014.

[0000936395-14-000063:mdna:204]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $7.5 million in interest on these convertible notes during fiscal 2014.

[0000936395-14-000063:mdna:205]
Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. We paid $2.6 million in interest on this term loan during fiscal 2014.

[0000936395-14-000063:mdna:206]
During fiscal 2014, we utilized the ABL Credit Facility to collateralize certain standby letters of credit. We paid $1.2 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility during fiscal 2014.

[0000936395-14-000063:mdna:207]
For additional information about our convertible notes and Term Loan, see Note 14 to our Consolidated Financial Statements included in in Item 8 of Part II of this report. For additional information about our ABL Credit Facility, see Note 15 to our Consolidated Financial Statements included in Item 8 of Part II of this report and "ABL Credit Facility" below.

[0000936395-14-000063:mdna:208]
Deferred revenue

[0000936395-14-000063:mdna:209]
Deferred revenue increased by $33.4 million during fiscal 2014. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2013 through the end of fiscal 2014:

[0000936395-14-000063:mdna:210]
|  | October 31, |  | Increase |
|  | 2013 |  | 2014 |  | (decrease) |
| Products | $ | 36,671 |  |  | $ | 50,457 |  |  | $ | 13,786 |  |
| Services | 75,499 |  |  | 95,161 |  |  | 19,662 |  |
| Total deferred revenue | $ | 112,170 |  |  | $ | 145,618 |  |  | $ | 33,448 |  |

[0000936395-14-000063:mdna:211]
ABL Credit Facility

[0000936395-14-000063:mdna:212]
During fiscal 2014, we amended our ABL Credit Facility to, among other things:

[0000936395-14-000063:mdna:213]
| • | increase the total committed amount from $150 million to $200 million; |

[0000936395-14-000063:mdna:214]
| • | extend the maturity date from August 13, 2015 to December 31, 2016 (and eliminate a December 15, 2014 maturity date acceleration feature); |

[0000936395-14-000063:mdna:215]
| • | reduce from $200 million to $150 million the minimum aggregate amount of unrestricted cash and cash equivalents that we are required to maintain at all times; |

[0000936395-14-000063:mdna:216]
| • | reduce the interest rate on borrowings from LIBOR plus an applicable margin ranging from 200 basis points to 250 basis points, to an applicable margin ranging from 150 basis points to 200 basis points, with the actual margin determined based on our utilization of the credit facility; and |

[0000936395-14-000063:mdna:217]
| • | amend the borrowing base to include, among other items, up to $50 million in eligible cash. |

[0000936395-14-000063:mdna:218]
We principally use the liquidity available under the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments.

[0000936395-14-000063:mdna:219]
Contractual Obligations

[0000936395-14-000063:mdna:220]
During fiscal 2014, we entered into a Term Loan Credit Agreement that provides for senior secured term loans in an aggregate principal amount of $250 million as described in "Overview" above. During the fourth quarter of fiscal 2014, we entered into a lease relating to office space for its new research and development center in Ottawa, Canada, consisting of a rentable area of approximately 170,582 square feet.The future minimum rental commitments to be paid over the 18-year lease term are approximately $49.1 million. The following is a summary of our future minimum payments under contractual obligations as of October 31, 2014 (in thousands):

[0000936395-14-000063:mdna:221]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due at maturity on convertible notes (1) | 1,254,627 |  |  | 187,500 |  |  | 500,000 |  |  | 350,000 |  |  | 217,127 |  |
| Principal due on term loan | 249,375 |  |  | 2,500 |  |  | 5,000 |  |  | 241,875 |  |  | — |  |
| Interest due on convertible notes | 118,125 |  |  | 28,750 |  |  | 50,000 |  |  | 28,125 |  |  | 11,250 |  |
| Interest due on term loan (2) | 44,045 |  |  | 9,449 |  |  | 18,640 |  |  | 15,956 |  |  | — |  |
| Operating leases (3) | 204,898 |  |  | 33,527 |  |  | 59,837 |  |  | 28,343 |  |  | 83,191 |  |
| Purchase obligations (4) | 197,753 |  |  | 197,753 |  |  |  |  |  |  |  |  |  |  |
| Capital lease | 13,020 |  |  | 8,312 |  |  | 4,708 |  |  | — |  |  | — |  |
| Other obligations | 7,002 |  |  | 3,814 |  |  | 3,188 |  |  | — |  |  | — |  |
| Total (5) | $ | 2,088,845 |  |  | $ | 471,605 |  |  | $ | 641,373 |  |  | $ | 664,299 |  |  | $ | 311,568 |  |

[0000936395-14-000063:mdna:222]
_________________________________

[0000936395-14-000063:mdna:223]
| (1) | Includes the accretion of the principal amount on the 2020 Notes payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-14-000063:mdna:224]
| (2) | Interest on the term loan is variable and was calculated using the rate in effect on the balance sheet date. |

[0000936395-14-000063:mdna:225]
| (3) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-14-000063:mdna:226]
| (4) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-14-000063:mdna:227]
| (5) | As of October 31, 2014, we also had approximately $14.4 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-14-000063:mdna:228]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2014 (in thousands):

[0000936395-14-000063:mdna:229]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years | Thereafter |
| Standby letters of credit | $ | 71,449 |  |  | $ | 34,409 |  |  | $ | 21,883 |  |  | $ | 3,711 |  | $ | 11,446 |  |

[0000936395-14-000063:mdna:230]
Off-Balance Sheet Arrangements

[0000936395-14-000063:mdna:231]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-14-000063:mdna:232]
Critical Accounting Policies and Estimates

[0000936395-14-000063:mdna:233]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-14-000063:mdna:234]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-14-000063:mdna:235]
Revenue Recognition

[0000936395-14-000063:mdna:236]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-14-000063:mdna:237]
We apply the percentage-of-completion method to long-term arrangements where it is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are

[0000936395-14-000063:mdna:238]
recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the fiscal years ended October 31, 2012, October 31, 2013 and October 31, 2014 were 1.0%, 4.5% and 4.0%, respectively.

[0000936395-14-000063:mdna:239]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-14-000063:mdna:240]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-14-000063:mdna:241]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-14-000063:mdna:242]
VSOE, when determinable, is established based on our pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. We have generally been unable to establish TPE of selling price because our go-to-market strategy differs from that of others in our markets, and the extent of customization and differentiated features and functions varies among comparable products or services from our peers. We determine BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-14-000063:mdna:243]
Our total deferred revenue for products was $36.7 million and $50.5 million as of October 31, 2013 and October 31, 2014, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $75.5 million and $95.2 million as of October 31, 2013 and October 31, 2014, respectively.

[0000936395-14-000063:mdna:244]
Share-Based Compensation

[0000936395-14-000063:mdna:245]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-14-000063:mdna:246]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 19 to our Consolidated Financial Statements in Item 8 of Part II of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2014, total unrecognized compensation expense was $57.2 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.

[0000936395-14-000063:mdna:247]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had

[0000936395-14-000063:mdna:248]
recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-14-000063:mdna:249]
Reserve for Inventory Obsolescence

[0000936395-14-000063:mdna:250]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $19.9 million and $32.3 million in fiscal 2013 and 2014, respectively. The charges in fiscal 2013 and fiscal 2014 primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. Our inventory net of allowance for excess and obsolescence was $249.1 million and $254.7 million as of October 31, 2013 and October 31, 2014, respectively.

[0000936395-14-000063:mdna:251]
Allowance for Doubtful Accounts Receivable

[0000936395-14-000063:mdna:252]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $488.6 million and $519.0 million as of October 31, 2013 and October 31, 2014, respectively. Our allowance for doubtful accounts was $2.0 million and $2.1 million as of October 31, 2013 and October 31, 2014, respectively.

[0000936395-14-000063:mdna:253]
Long-lived Assets

[0000936395-14-000063:mdna:254]
Our long-lived assets include: equipment, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2013 and October 31, 2014 these assets totaled $366.9 million and $309.4 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-14-000063:mdna:255]
Deferred Tax Valuation Allowance

[0000936395-14-000063:mdna:256]
As of October 31, 2014, we have recorded a valuation allowance offsetting all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods,

[0000936395-14-000063:mdna:257]
our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-14-000063:mdna:258]
Warranty

[0000936395-14-000063:mdna:259]
Our liability for product warranties, included in other accrued liabilities, was $56.3 million and $56.0 million as of October 31, 2013 and October 31, 2014, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $24.6 million and $22.1 million for fiscal 2013 and 2014, respectively. See Note 11 to the Consolidated Financial Statements included in Item 8 of Part II of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-14-000063:mdna:260]
Effects of Recent Accounting Pronouncements

[0000936395-14-000063:mdna:261]
See Note 1 to our Consolidated Financial Statements in Item 8 of Part II of this report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-14-000063:mdna:262]
Unaudited Quarterly Results of Operations

[0000936395-14-000063:mdna:263]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2014. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-14-000063:mdna:264]
|  | Jan. 31, |  | Apr. 30, |  | Jul. 31, |  | Oct. 31, |  | Jan. 31, |  | Apr. 30, |  | Jul. 31, |  | Oct. 31, |
|  | 2013 |  | 2013 |  | 2013 |  | 2013 |  | 2014 |  | 2014 |  | 2014 |  | 2014 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 353,057 |  |  | $ | 413,217 |  |  | $ | 437,442 |  |  | $ | 476,409 |  |  | $ | 432,941 |  |  | $ | 460,821 |  |  | $ | 495,889 |  |  | $ | 476,175 |  |
| Services | 100,036 |  |  | 94,495 |  |  | 100,914 |  |  | 106,976 |  |  | 100,762 |  |  | 99,240 |  |  | 107,673 |  |  | 114,788 |  |
| Total Revenue | 453,093 |  |  | 507,712 |  |  | 538,356 |  |  | 583,385 |  |  | 533,703 |  |  | 560,061 |  |  | 603,562 |  |  | 590,963 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 196,521 |  |  | 239,441 |  |  | 247,768 |  |  | 283,780 |  |  | 245,216 |  |  | 257,632 |  |  | 275,003 |  |  | 305,171 |  |
| Services | 60,777 |  |  | 58,758 |  |  | 62,367 |  |  | 67,959 |  |  | 62,636 |  |  | 64,738 |  |  | 64,586 |  |  | 64,955 |  |
| Total costs of goods sold | 257,298 |  |  | 298,199 |  |  | 310,135 |  |  | 351,739 |  |  | 307,852 |  |  | 322,370 |  |  | 339,589 |  |  | 370,126 |  |
| Gross profit | 195,795 |  |  | 209,513 |  |  | 228,221 |  |  | 231,646 |  |  | 225,851 |  |  | 237,691 |  |  | 263,973 |  |  | 220,837 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 89,125 |  |  | 100,787 |  |  | 93,069 |  |  | 100,427 |  |  | 101,497 |  |  | 103,492 |  |  | 97,685 |  |  | 98,506 |  |
| Selling and marketing | 66,588 |  |  | 74,475 |  |  | 75,613 |  |  | 87,494 |  |  | 78,348 |  |  | 83,662 |  |  | 81,919 |  |  | 84,396 |  |
| General and administrative | 28,208 |  |  | 30,883 |  |  | 32,066 |  |  | 31,275 |  |  | 30,097 |  |  | 31,882 |  |  | 36,285 |  |  | 28,560 |  |
| Amortization of intangible assets | 12,453 |  |  | 12,439 |  |  | 12,440 |  |  | 12,439 |  |  | 12,439 |  |  | 11,493 |  |  | 11,019 |  |  | 11,019 |  |
| Restructuring costs | 5,030 |  |  | 1,509 |  |  | 202 |  |  | 428 |  |  | 115 |  |  | — |  |  | 63 |  |  | 171 |  |
| Total operating expenses | 201,404 |  |  | 220,093 |  |  | 213,390 |  |  | 232,063 |  |  | 222,496 |  |  | 230,529 |  |  | 226,971 |  |  | 222,652 |  |
| Income (loss) from operations | (5,609 | ) |  | (10,580 | ) |  | 14,831 |  |  | (417 | ) |  | 3,355 |  |  | 7,162 |  |  | 37,002 |  |  | (1,815 | ) |
| Interest and other income (loss), net | (137 | ) |  | (2,716 | ) |  | (3,167 | ) |  | 276 |  |  | (5,998 | ) |  | (1,905 | ) |  | (6,328 | ) |  | (11,031 | ) |
| Interest expense | (10,732 | ) |  | (11,392 | ) |  | (10,972 | ) |  | (10,946 | ) |  | (11,028 | ) |  | (11,020 | ) |  | (11,508 | ) |  | (13,559 | ) |
| Loss on extinguishment of debt | (28,630 | ) |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income (loss) before income taxes | (45,108 | ) |  | (24,688 | ) |  | 692 |  |  | (11,087 | ) |  | (13,671 | ) |  | (5,763 | ) |  | 19,166 |  |  | (26,405 | ) |
| Provision (benefit from) for income tax | 2,216 |  |  | 2,391 |  |  | 1,923 |  |  | (1,290 | ) |  | 2,265 |  |  | 4,395 |  |  | 3,006 |  |  | 4,298 |  |
| Net income (loss) | $ | (47,324 | ) |  | $ | (27,079 | ) |  | $ | (1,231 | ) |  | $ | (9,797 | ) |  | $ | (15,936 | ) |  | $ | (10,158 | ) |  | $ | 16,160 |  |  | $ | (30,703 | ) |
| Basic net income (loss) per common share | $ | (0.47 | ) |  | $ | (0.27 | ) |  | $ | (0.01 | ) |  | $ | (0.09 | ) |  | $ | (0.15 | ) |  | $ | (0.10 | ) |  | $ | 0.15 |  |  | $ | (0.29 | ) |
| Diluted net income (loss) per potential common share | $ | (0.47 | ) |  | $ | (0.27 | ) |  | $ | (0.01 | ) |  | $ | (0.09 | ) |  | $ | (0.15 | ) |  | $ | (0.10 | ) |  | $ | 0.15 |  |  | $ | (0.29 | ) |
| Weighted average basic common shares outstanding | 101,204 |  |  | 101,913 |  |  | 102,713 |  |  | 103,523 |  |  | 104,501 |  |  | 105,451 |  |  | 106,236 |  |  | 106,931 |  |
| Weighted average dilutive potential common shares outstanding | 101,204 |  |  | 101,913 |  |  | 102,713 |  |  | 103,523 |  |  | 104,501 |  |  | 105,451 |  |  | 120,809 |  |  | 106,931 |  |

[0000936395-14-000063:mdna:265]
56
