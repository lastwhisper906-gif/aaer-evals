# CIEN note change history — 0000936395-16-000083 → 0000936395-16-000104


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:1]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss.  In response, plaintiffs filed a motion for leave to amend their complaint. The defendants opposed the motion and it is set for hearing on June 14, 2016.
  (was, 2016-03-09, similarity 0.9338):
[0000936395-16-000083:note_history:1]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss. A briefing schedule for these motions has been set, with briefing to be completed in March 2016.

- changed (2016-06-08):
[0000936395-16-000104:note_history:2]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015.  On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court.  Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2016-03-09, similarity 0.8926):
[0000936395-16-000083:note_history:2]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:3]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $10.4 million for the six-month period ending April 30, 2015.
  (was, 2016-03-09, similarity 0.987):
[0000936395-16-000083:note_history:3]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement sub totals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $0.1 million for the three month period ending January 31, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:4]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.
  (was, 2016-03-09, similarity 0.9987):
[0000936395-16-000083:note_history:4]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

- changed (2016-06-08):
[0000936395-16-000104:note_history:5]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.
  (was, 2016-03-09, similarity 0.9927):
[0000936395-16-000083:note_history:5]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2016-06-08):
[0000936395-16-000104:note_history:6]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.
  (was, 2016-03-09, similarity 0.9864):
[0000936395-16-000083:note_history:6]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

- changed (2016-06-08):
[0000936395-16-000104:note_history:7]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.
  (was, 2016-03-09, similarity 0.9451):
[0000936395-16-000083:note_history:7]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period.

- changed (2016-06-08):
[0000936395-16-000104:note_history:8]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015 and fiscal 2016, Ciena gained access to portions of an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 11 below.
  (was, 2016-03-09, similarity 0.9424):
[0000936395-16-000083:note_history:8]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

- added (2016-06-08):
[0000936395-16-000104:note_history:9]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, the full value of the asset will be charged to expense.

- changed (2016-06-08):
[0000936395-16-000104:note_history:10]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2016 and April 30, 2015 was 0.4% and 1.7%, respectively.
  (was, 2016-03-09, similarity 0.9688):
[0000936395-16-000083:note_history:10]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the three months ended January 31, 2015 and January 31, 2016 was 1.0% and 0.6%, respectively.

- changed (2016-06-08):
[0000936395-16-000104:note_history:11]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third party services, depreciation, facility costs and information technology.
  (was, 2016-03-09, similarity 0.9855):
[0000936395-16-000083:note_history:11]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, cost of prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

- changed (2016-06-08):
[0000936395-16-000104:note_history:12]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 20 below.
  (was, 2016-03-09, similarity 0.9963):
[0000936395-16-000083:note_history:12]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 19 below.

- changed (2016-06-08):
[0000936395-16-000104:note_history:13]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.
  (was, 2016-03-09, similarity 0.9908):
[0000936395-16-000083:note_history:13]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and any expansion requirements.

- changed (2016-06-08):
[0000936395-16-000104:note_history:14]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loans, see Note 17 below.
  (was, 2016-03-09, similarity 0.9984):
[0000936395-16-000083:note_history:14]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and Term Loan, see Note 16 below.

- changed (2016-06-08):
[0000936395-16-000104:note_history:15]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.
  (was, 2016-03-09, similarity 0.9988):
[0000936395-16-000083:note_history:15]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

- changed (2016-06-08):
[0000936395-16-000104:note_history:16]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. Ciena also has interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.
  (was, 2016-03-09, similarity 0.9768):
[0000936395-16-000083:note_history:16]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

- changed (2016-06-08):
[0000936395-16-000104:note_history:17]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.
  (was, 2016-03-09, similarity 0.8964):
[0000936395-16-000083:note_history:17]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect that the impact of adopting this guidance will be material to its Consolidated Financial Statements or disclosures.

- changed (2016-06-08):
[0000936395-16-000104:note_history:18]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2016-03-09, similarity 0.8994):
[0000936395-16-000083:note_history:18]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020, and, at that time, Ciena will adopt the new standard using a modified retrospective approach. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- added (2016-06-08):
[0000936395-16-000104:note_history:19]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:20]
Term Loan due 2021
  (was, 2016-03-09, similarity 0.75):
[0000936395-16-000083:note_history:20]
Term Loan

- added (2016-06-08):
[0000936395-16-000104:note_history:21]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the "Term Loan Credit Agreement"), dated July 15, 2014. The Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% senior convertible notes due June 15, 2017.

- added (2016-06-08):
[0000936395-16-000104:note_history:22]
The 2021 Term Loan will, among other things:

- added (2016-06-08):
[0000936395-16-000104:note_history:23]
| • | mature on April 25, 2021; |

- added (2016-06-08):
[0000936395-16-000104:note_history:24]
| • | amortize in equal quarterly installments in aggregate amounts of $0.6 million (equal to 0.25% of the original principal amount), with the balance payable at maturity; |

- added (2016-06-08):
[0000936395-16-000104:note_history:25]
| • | be subject to mandatory prepayment on the same basis as Ciena’s existing 2019 Term Loan under the Term Loan Credit Agreement; |

- added (2016-06-08):
[0000936395-16-000104:note_history:26]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus a margin ranging from 3.25% to 3.50%, or (b) a base rate (subject to a floor of 1.75%) plus a margin ranging from 2.25% to 2.50%, in each case, with the actual margin determined according to Ciena’s total net leverage ratio; |

- added (2016-06-08):
[0000936395-16-000104:note_history:27]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2021 Term Loan with proceeds of certain indebtedness prior to October 25, 2016 shall require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and |

- added (2016-06-08):
[0000936395-16-000104:note_history:28]
| • | except as described above or otherwise set forth in the Incremental Term Loan Credit Agreement, have identical terms as the existing 2019 Term Loan under the Term Loan Credit Agreement. |

- added (2016-06-08):
[0000936395-16-000104:note_history:29]
Except as amended by the Incremental Term Loan Credit Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

- changed (2016-06-08):
[0000936395-16-000104:note_history:30]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of April 30, 2016 (in thousands):
  (was, 2016-03-09, similarity 0.6424):
[0000936395-16-000083:note_history:30]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of January 31, 2016:

- changed (2016-06-08):
[0000936395-16-000104:note_history:31]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 250,000 |  |  | $ | 1,247 |  |  | $ | 248,753 |  |
  (was, 2016-03-09, similarity 0.6418):
[0000936395-16-000083:note_history:31]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,248 |  |  | $ | 245,019 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:32]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):
  (was, 2016-03-09, similarity 0.8571):
[0000936395-16-000083:note_history:32]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

- added (2016-06-08):
[0000936395-16-000104:note_history:33]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,753 |  |  | $ | 250,938 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:34]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2016-03-09, similarity 0.992):
[0000936395-16-000083:note_history:34]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2016-06-08):
[0000936395-16-000104:note_history:35]
Term Loan due 2019

- changed (2016-06-08):
[0000936395-16-000104:note_history:36]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):
  (was, 2016-03-09, similarity 0.9635):
[0000936395-16-000083:note_history:36]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):

- added (2016-06-08):
[0000936395-16-000104:note_history:37]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

- added (2016-06-08):
[0000936395-16-000104:note_history:38]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,696 |  |  | $ | 245,011 |  |

- added (2016-06-08):
[0000936395-16-000104:note_history:39]
| (1) | Includes unamortized bond discount. |

- added (2016-06-08):
[0000936395-16-000104:note_history:40]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- changed (2016-06-08):
[0000936395-16-000104:note_history:41]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for a cash purchase price slightly below par.
  (was, 2016-03-09, similarity 0.87):
[0000936395-16-000083:note_history:41]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the 0.875% Convertible Senior Notes due June 15,2017, for cash slightly below par.

- added (2016-06-08):
[0000936395-16-000104:note_history:42]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of April 30, 2016:

- added (2016-06-08):
[0000936395-16-000104:note_history:43]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 479,985 |  |  | $ | 471,585 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 395,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 186,954 |  |  | 224,766 |  |
|  |  | $ | 1,016,939 |  |  | $ | 1,091,414 |  |

- removed (2016-06-08):
[0000936395-16-000083:note_history:44]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 479,985 |  |  | 471,285 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 401,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 185,583 |  |  | 225,938 |  |
|  |  | $ | 1,015,568 |  |  | $ | 1,098,411 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:45]
|  | April 30, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 190,123 |  |  | $ | 87 |  |  | (28 | ) |  | $ | 190,182 |  |
| Included in long-term investments | 125,091 |  |  | 157 |  |  | (15 | ) |  | 125,233 |  |
|  | $ | 315,214 |  |  | $ | 244 |  |  | $ | (43 | ) |  | $ | 315,415 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 4,997 |  |  | — |  |  | — |  |  | $ | 4,997 |  |
|  | $ | 4,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,997 |  |
  (was, 2016-03-09, similarity 0.9887):
[0000936395-16-000083:note_history:45]
|  | January 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 180,087 |  |  | $ | 30 |  |  | (83 | ) |  | $ | 180,034 |  |
| Included in long-term investments | 125,041 |  |  | 117 |  |  | (98 | ) |  | 125,060 |  |
|  | $ | 305,128 |  |  | $ | 147 |  |  | $ | (181 | ) |  | $ | 305,094 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,976 |  |  | — |  |  | — |  |  | $ | 29,976 |  |
|  | $ | 29,976 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,976 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:46]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,989 |  |  | — |  |  | — |  |  | $ | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |
  (was, 2016-03-09, similarity 0.9925):
[0000936395-16-000083:note_history:46]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 24,989 |  |  | — |  |  | — |  |  | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:47]
The following table summarizes the final legal maturities of debt investments at April 30, 2016 (in thousands):
  (was, 2016-03-09, similarity 0.9626):
[0000936395-16-000083:note_history:47]
The following table summarizes the final legal maturities of debt investments at January 31, 2016 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:48]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of April 30, 2016 (in thousands):
  (was, 2016-03-09, similarity 0.9627):
[0000936395-16-000083:note_history:48]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):

- changed (2016-06-08):
[0000936395-16-000104:note_history:49]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 250,000 |  |  | $ | 1,247 |  |  | $ | 248,753 |  |
  (was, 2016-03-09, similarity 0.6418):
[0000936395-16-000083:note_history:49]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,248 |  |  | $ | 245,019 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:50]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):
  (was, 2016-03-09, similarity 0.8571):
[0000936395-16-000083:note_history:50]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

- added (2016-06-08):
[0000936395-16-000104:note_history:51]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,753 |  |  | $ | 250,938 |  |

- changed (2016-06-08):
[0000936395-16-000104:note_history:52]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2016-03-09, similarity 0.992):
[0000936395-16-000083:note_history:52]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2016-06-08):
[0000936395-16-000104:note_history:53]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):

- added (2016-06-08):
[0000936395-16-000104:note_history:54]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

- added (2016-06-08):
[0000936395-16-000104:note_history:55]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,696 |  |  | $ | 245,011 |  |

- added (2016-06-08):
[0000936395-16-000104:note_history:56]
| (1) | Includes unamortized bond discount. |

- added (2016-06-08):
[0000936395-16-000104:note_history:57]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2016-06-08):
[0000936395-16-000104:note_history:58]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 479,985 |  |  | $ | 471,585 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 395,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 186,954 |  |  | 224,766 |  |
|  |  | $ | 1,016,939 |  |  | $ | 1,091,414 |  |

- removed (2016-06-08):
[0000936395-16-000083:note_history:59]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 479,985 |  |  | 471,285 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 401,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 185,583 |  |  | 225,938 |  |
|  |  | $ | 1,015,568 |  |  | $ | 1,098,411 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:60]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of April 30, 2016:
  (was, 2016-03-09, similarity 0.9795):
[0000936395-16-000083:note_history:60]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of January 31, 2016:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-06-08):
[0000936395-16-000104:note_history:61]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2016 and April 30, 2015 was 0.4% and 1.7%, respectively.
  (was, 2016-03-09, similarity 0.9688):
[0000936395-16-000083:note_history:61]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the three months ended January 31, 2015 and January 31, 2016 was 1.0% and 0.6%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2016-06-08):
[0000936395-16-000083:note_history:62]
SUBSEQUENT EVENTS

- removed (2016-06-08):
[0000936395-16-000083:note_history:63]
On January 19, 2016, a wholly-owned subsidiary of Ciena Corporation entered into a definitive agreement with TeraXion, Inc. and its wholly-owned subsidiary to acquire certain high-speed photonics components (HSPC) assets for approximately $32 million in cash. The asset purchase includes, among other things, TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as certain underlying intellectual property. Ciena completed its acquisition of these assets on February 1, 2016.
