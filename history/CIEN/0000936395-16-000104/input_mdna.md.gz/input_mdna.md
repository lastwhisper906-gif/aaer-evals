# CIEN MD&A — 0000936395-16-000104


## mdna

[0000936395-16-000104:mdna:1]
[same as prior period, unchanged from 0000936395-16-000083:mdna:1]

[0000936395-16-000104:mdna:2]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” "projects," "targets," or  “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, adoption of next-generation network technology and software programmability and control of networks; our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; our corporate strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; our acquisition of Cyan, Inc. and its impact on our business and results of operations; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including real estate and IT transitions or initiatives; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-16-000104:mdna:3]
[same as prior period, unchanged from 0000936395-16-000083:mdna:3]

[0000936395-16-000104:mdna:4]
[same as prior period, unchanged from 0000936395-16-000083:mdna:4]

[0000936395-16-000104:mdna:5]
[same as prior period, unchanged from 0000936395-16-000083:mdna:5]

[0000936395-16-000104:mdna:6]
| • | the competitive environment in which we operate and the impact of pricing pressure and recurring market-based price erosion that we regularly encounter; |

[0000936395-16-000104:mdna:7]
[same as prior period, unchanged from 0000936395-16-000083:mdna:7]

[0000936395-16-000104:mdna:8]
[same as prior period, unchanged from 0000936395-16-000083:mdna:8]

[0000936395-16-000104:mdna:9]
[same as prior period, unchanged from 0000936395-16-000083:mdna:9]

[0000936395-16-000104:mdna:10]
[same as prior period, unchanged from 0000936395-16-000083:mdna:10]

[0000936395-16-000104:mdna:11]
| • | the level of growth in network traffic and bandwidth consumption and corresponding level of investment in network infrastructures by network operators; |

[0000936395-16-000104:mdna:12]
[same as prior period, unchanged from 0000936395-16-000083:mdna:11]

[0000936395-16-000104:mdna:13]
| • | our ability to forecast accurately demand for our products for purposes of inventory purchase practices; |

[0000936395-16-000104:mdna:14]
[same as prior period, unchanged from 0000936395-16-000083:mdna:13]

[0000936395-16-000104:mdna:15]
[same as prior period, unchanged from 0000936395-16-000083:mdna:14]

[0000936395-16-000104:mdna:16]
[same as prior period, unchanged from 0000936395-16-000083:mdna:15]

[0000936395-16-000104:mdna:17]
[same as prior period, unchanged from 0000936395-16-000083:mdna:16]

[0000936395-16-000104:mdna:18]
[same as prior period, unchanged from 0000936395-16-000083:mdna:17]

[0000936395-16-000104:mdna:19]
[same as prior period, unchanged from 0000936395-16-000083:mdna:18]

[0000936395-16-000104:mdna:20]
[same as prior period, unchanged from 0000936395-16-000083:mdna:19]

[0000936395-16-000104:mdna:21]
[same as prior period, unchanged from 0000936395-16-000083:mdna:20]

[0000936395-16-000104:mdna:22]
[same as prior period, unchanged from 0000936395-16-000083:mdna:21]

[0000936395-16-000104:mdna:23]
[same as prior period, unchanged from 0000936395-16-000083:mdna:22]

[0000936395-16-000104:mdna:24]
[same as prior period, unchanged from 0000936395-16-000083:mdna:23]

[0000936395-16-000104:mdna:25]
[same as prior period, unchanged from 0000936395-16-000083:mdna:24]

[0000936395-16-000104:mdna:26]
[same as prior period, unchanged from 0000936395-16-000083:mdna:25]

[0000936395-16-000104:mdna:27]
[same as prior period, unchanged from 0000936395-16-000083:mdna:26]

[0000936395-16-000104:mdna:28]
| • | our ability to grow our software business and address networking strategies including software-defined networking and network function virtualization; |

[0000936395-16-000104:mdna:29]
[same as prior period, unchanged from 0000936395-16-000083:mdna:28]

[0000936395-16-000104:mdna:30]
[same as prior period, unchanged from 0000936395-16-000083:mdna:29]

[0000936395-16-000104:mdna:31]
[same as prior period, unchanged from 0000936395-16-000083:mdna:30]

[0000936395-16-000104:mdna:32]
| • | adverse results in litigation matters. |

[0000936395-16-000104:mdna:33]
[same as prior period, unchanged from 0000936395-16-000083:mdna:32]

[0000936395-16-000104:mdna:34]
We are a network specialist focused on providing solutions that enable a wide range of network operators to adopt next-generation communication architectures. We have optimized our business and solutions to enable network operators to create and deliver a broad array of high-bandwidth services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. In addition to our high-capacity hardware platforms, we offer network management and control software platforms that help network operators simplify and automate their networks and virtualize certain network functions. Our solutions are designed to enable network operators to adopt open, multi-vendor, software-programmable network infrastructures that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to introduce new, revenue-generating services and to reduce network complexity and expense.

[0000936395-16-000104:mdna:35]
[same as prior period, unchanged from 0000936395-16-000083:mdna:34]

[0000936395-16-000104:mdna:36]
The rapid proliferation of communications services and devices, together with increased mobility and growth in video, cloud-based services and data center interconnection, have fundamentally affected the bandwidth and service demands placed upon communications networks. As the capacity of their network infrastructures is pressured, many network operators also face a rapidly changing business environment and shifting competitive landscape. Newer market entrants, such as cloud service and over-the-top content providers, are challenging certain traditional business models. Our OPn Architecture, which enables increased network scalability, flexibility and programmability, is designed to meet these challenges. It allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and other network resources. This approach enables highly configurable network infrastructures that can meet the “on-demand” service requirements of both our customers and their end-users. By enhancing software-based management and control,

[0000936395-16-000104:mdna:37]
[same as prior period, unchanged from 0000936395-16-000083:mdna:66]

[0000936395-16-000104:mdna:38]
enabling network functions to be provided virtually, and reducing required network elements, our OPn approach optimizes network infrastructures. At the same time, it increases network scale at reduced cost and simplifies the management, deployment and orchestration of multi-vendor hardware and software elements. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the “Strategy” section below.

[0000936395-16-000104:mdna:39]
[same as prior period, unchanged from 0000936395-16-000083:mdna:38]

[0000936395-16-000104:mdna:40]
[same as prior period, unchanged from 0000936395-16-000083:mdna:39]

[0000936395-16-000104:mdna:41]
[same as prior period, unchanged from 0000936395-16-000083:mdna:40]

[0000936395-16-000104:mdna:42]
[same as prior period, unchanged from 0000936395-16-000083:mdna:41]

[0000936395-16-000104:mdna:43]
[same as prior period, unchanged from 0000936395-16-000083:mdna:42]

[0000936395-16-000104:mdna:44]
We compete in markets that are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and intense selling efforts to displace incumbent vendors and to capture market share. The markets for our solutions are both highly competitive and fragmented. For example, our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approaches. We expect the competitive landscape in which we operate to remain challenging and dynamic, particularly as we continue to broaden our business. As we have expanded our solutions offerings, including with Packet Networking solutions, such as our 8700 Packetwave Platform, and data center interconnect (DCI) solutions, such as our Waveserver DCI platform, our soutions have become increasingly competive with those of other networking solution suppliers — including IP router vendors, data center switch providers, and other suppliers or integrators — whose technology is geared toward different network applications, layers or functions than our traditional competitors. In addition, as we seek customer adoption of our Blue Planet software platform, and network operator demands for software programmability, management and control increase, we expect to compete more directly with software vendors and information technology vendors or integrators of these solutions. We may also face competition from companies, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware, particularly where a customer's network strategy seeks to emphasize deployment of those product offerings.

[0000936395-16-000104:mdna:45]
Against both this competitive landscape and market-based price erosion for our products, we expect that in order to achieve sustained revenue growth we will be required to increase our volume of shipments and continue to introduce new technology solutions that address bandwidth consumption and evolving service demands. Further, in order to maintain incumbency with key customers and to secure new opportunities with a diverse set of network operators, we are often required to agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously and may in the future adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also lengthen our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-16-000104:mdna:46]
[same as prior period, unchanged from 0000936395-16-000083:mdna:45]

[0000936395-16-000104:mdna:47]
Our corporate strategy to capitalize on the market dynamics described above, promote operational efficiency and drive the profitable growth of our business includes the following initiatives:

[0000936395-16-000104:mdna:48]
Promote our OPn Architecture. We intend to promote our OPn Architecture as the preferred approach for network operators to transition to next-generation networks and address the industry dynamics described above. Our OPn Architecture enables a programmable infrastructure that brings together the reliability and capacity of optical networking technologies with the flexibility and economics of packet networking technologies. Our OPn Architecture leverages this convergence to enable network operators to scale their networks efficiently and cost-effectively, while applying advanced software-based network management and control for enhanced programmability. The software-driven aspects of this architecture become increasingly important as we expect network operators increasingly to seek to utilize an open ecosystem that enables multi-vendor and multi-domain network management and virtualized resources required for next-generation network architectures. We see opportunities to drive the evolution of network infrastructures by offering a portfolio of solutions, including our Blue Planet software platform, that can accelerate the realization of our OPn Architecture.

[0000936395-16-000104:mdna:49]
Extend Technology Leaderships and Expand Application of Our Solutions. Our product development strategy is focused on maintaining our technology leadership and expanding our role in customer networks to support service delivery and additional network applications. Our research and development efforts seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce terabit per second and greater transmission speeds. We are also focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnectivity and WAN applications. Separately, we are increasing the scale, density and capability of our packet offerings, reducing power and space requirements, and enabling NFV capabilities for applications in metro networks, user aggregation and data center connectivity. We are also focused on increasing software programmability of networks and enabling network operators to automate and accelerate the creation and delivery of new, cloud-based services. These efforts include investments in our Blue Planet software platform — which is designed to automate, orchestrate, and manage physical network resources and virtualized services across data centers and the WAN — and its integration across our portfolio and with additional third party network resources.

[0000936395-16-000104:mdna:50]
Expand our Role and Reach through Go-to-Market Model. To address the industry dynamics described above, we believe that it is important to secure customer relationships with a diverse set of traditional communications service providers and Web-scale providers, as we expect that their purchasing and network decisions will become increasingly interdependent. As such, our go-to-market model is focused on driving sales growth by diversifying our business with existing customers and penetrating additional customer segments and international markets.

[0000936395-16-000104:mdna:51]
Our sales and marketing efforts seek to promote increased sales to existing customers, particularly through opportunities that expand our role or the application of our solutions within their network and business. We are pursuing opportunities to increase adoption of our packet access and aggregation solutions, and to secure market share of our Blue Planet software platform, including within our existing customer base. We are also focused on opportunities to support metro aggregation, data center interconnectivity, managed services offerings, cloud-based services, submarine networks, business Ethernet services and mobile backhaul. We intend to leverage our existing customer relationships to increase sales and promote the adoption of our solutions as our customers scale and evolve their networks.

[0000936395-16-000104:mdna:52]
We also intend to target important growth markets, including key customer market segments and geographies. Our go-to-market strategy is focused on further penetrating Internet content providers, data center operators and other emerging network operators that form the “Web-scale” marketplace. We intend to use our direct and indirect sales channels to target and expand our sales with several other market verticals, including cable and multiservice operators, submarine network operators, enterprise customers and in the government, research and education (R&E) markets. We are also focused on securing additional communications service provider customers outside of North America, including in high-growth geographies such as Brazil and India. We believe that this is an important part of our strategy and necessary for continued revenue growth. To leverage the geographic reach of our direct sales resources and expand sales into key geographies, we have pursued channel and distribution opportunities, including our strategic relationship with Ericsson, that enable sales through third parties, including service providers, systems integrators and value-added resellers.

[0000936395-16-000104:mdna:53]
Optimize Business to Yield Operating Leverage. We are actively pursuing initiatives to improve our operating margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and supply procurement initiatives to ensure that our product cost model remains ahead of the market-based price erosion that we regularly

[0000936395-16-000104:mdna:54]
encounter. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs, reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-16-000104:mdna:55]
Purchase of High-Speed Photonic Component Assets of TeraXion, Inc.

[0000936395-16-000104:mdna:56]
On January 19, 2016, Ciena Canada, Inc., a wholly-owned subsidiary of Ciena Corporation, entered into a definitive agreement with TeraXion, Inc. ("TeraXion") and its wholly-owned subsidiary to acquire certain high-speed photonics components ("HSPC") assets for approximately $32 million in cash. The assets purchased include, among other things, TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as certain underlying intellectual property, that support development of our WaveLogic coherent optical chipsets. This transaction has been accounted for as an acquisition of a business. As a result of this transaction, we also gained key research and development personnel in Ottawa and Quebec City, Canada. We believe that this acquisition affords us greater control over important component technologies used in our business and provides us opportunities to accelerate further development of our coherent packet-optical solutions. We completed our acquisition of these assets on February 1, 2016, and the acquisition of these assets and related expense are reflected in our financial results for the second fiscal quarter of 2016.

[0000936395-16-000104:mdna:57]
Term Loan due April 25, 2021

[0000936395-16-000104:mdna:58]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the "Term Loan Credit Agreement"), dated July 15, 2014. As more fully described in Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, the Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million maturing on April 25, 2021 (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under our 0.875% senior convertible notes due June 15, 2017.

[0000936395-16-000104:mdna:59]
[same as prior period, unchanged from 0000936395-16-000083:mdna:54]

[0000936395-16-000104:mdna:60]
Revenue for the second quarter of fiscal 2016 was $640.7 million, representing a sequential increase of 11.8% from $573.1 million in the first quarter of fiscal 2016, during which we typically experience seasonal reductions in revenue. Revenue for the second and first quarters of fiscal 2016 includes $24.8 million and $40.3 million, respectively, from products and services relating to the business of Cyan, Inc. ("Cyan"), which we acquired on August 3, 2015. Revenue-related details reflecting sequential changes from the first quarter of fiscal 2016 include:

[0000936395-16-000104:mdna:61]
| • | Product revenue for the second quarter of fiscal 2016 increased by $66.4 million, primarily reflecting revenue increases within our Networking Platforms segment, with product line increases of $46.0 million in Converged Packet Optical and $20.4 million in Packet Networking. |

[0000936395-16-000104:mdna:62]
| • | Service revenue for the second quarter of fiscal 2016 increased by $1.2 million. |

[0000936395-16-000104:mdna:63]
| • | North America revenue for the second quarter of fiscal 2016 was $395.5 million, an increase from $392.7 million in the first quarter of fiscal 2016. This primarily reflects a revenue increase of $5.2 million within our Software and Software-Related Services segment, partially offset by a decrease of $2.1 million within our Global Services segment. North America revenue within our Networking Platforms segment remained relatively flat, with a product line increase of $16.3 million in Packet Networking offset by product line decreases of $14.4 million in Converged Packet Optical and $2.2 million in Optical Transport. |

[0000936395-16-000104:mdna:64]
| • | Europe, Middle East and Africa ("EMEA") revenue for the second quarter of fiscal 2016 was $96.2 million, an increase from $80.7 million in the first quarter of fiscal 2016. This primarily reflects an $11.5 million increase within our Networking Platforms segment, with a product line increase of $14.5 million in Converged Packet Optical, partially offset by product line decreases of $1.6 million in Optical Transport and $1.4 million in Packet Networking. EMEA revenue also reflects a revenue increase of $3.6 million within our Global Services segment. |

[0000936395-16-000104:mdna:65]
| • | Caribbean and Latin America ("CALA") revenue for the second quarter of fiscal 2016 was $57.9 million, an increase from $43.8 million in the first quarter of fiscal 2016. This primarily reflects a product line increase of $14.4 million in Converged Packet Optical, within our Networking Platforms segment. |

[0000936395-16-000104:mdna:66]
| • | Asia Pacific ("APAC") revenue for the second quarter of fiscal 2016 was $91.1 million, an increase from $55.9 million in the first quarter of fiscal 2016. This primarily reflects a $37.1 million increase within our Networking Platforms segment, with product line increases of $31.5 million in Converged Packet Optical and $5.3 million in Packet Networking. This increase was partially offset by a revenue decrease of $1.2 million within our Global Services segment. |

[0000936395-16-000104:mdna:67]
| • | For the second quarter and first quarter of fiscal 2016, AT&T accounted for 18.1% and 22.1% of total revenue, respectively. |

[0000936395-16-000104:mdna:68]
Gross margin for the second quarter of fiscal 2016 was 44.2%, a slight increase from 43.9% in the first quarter of fiscal 2016. The improved gross margin for the second quarter of fiscal 2016 was primarily due to a favorable product mix and product cost reductions, partially offset by an increased provision for excess and obsolete inventory expense and lower services margin.

[0000936395-16-000104:mdna:69]
Operating expense was $254.9 million for the second quarter of fiscal 2016, an increase from $240.2 million in the first quarter of fiscal 2016. Second quarter fiscal 2016 operating expense primarily reflects increases of $6.6 million in research and development expense, $4.2 million in selling and marketing expense and $4.1 million in general and administrative expense. Operating expenses reflect $2.8 million of costs associated with our acquisition of TeraXion, including $1.8 million in research and development expense and $1.0 million in acquisition and integration costs.

[0000936395-16-000104:mdna:70]
Income from operations for the second quarter of fiscal 2016 was $28.2 million, compared to income from operations of $11.2 million during the first quarter of fiscal 2016. Our net income for the second quarter of fiscal 2016 was $14.0 million, or $0.10 per diluted common share, compared to a net loss of $11.5 million or $0.08 per diluted common share, for the first quarter of fiscal 2016.

[0000936395-16-000104:mdna:71]
We generated cash from operations of $60.7 million during the second quarter of fiscal 2016, compared to $15.0 million of cash generated from operations during the first quarter of fiscal 2016. Reflecting the addition of the net proceeds of our 2021 Term Loan, as of April 30, 2016, we had $922.0 million in cash and cash equivalents, $195.2 million of short-term investments in U.S. treasury securities and commercial paper and $125.2 million of long-term investments in U.S. treasury securities. This compares to $660.3 million in cash and cash equivalents, $210.0 million of short-term investments in U.S. treasury securities and commercial paper and $125.1 million of long-term investments in U.S. treasury securities, at January 31, 2016.

[0000936395-16-000104:mdna:72]
As of April 30, 2016, we had 5,418 employees which was an increase from 5,345 at October 31, 2015 and an increase from 5,108 at April 30, 2015.

[0000936395-16-000104:mdna:73]
40

[0000936395-16-000104:mdna:74]
[same as prior period, unchanged from 0000936395-16-000083:mdna:69]

[0000936395-16-000104:mdna:75]
[same as prior period, unchanged from 0000936395-16-000083:mdna:70]

[0000936395-16-000104:mdna:76]
During the first quarter of fiscal 2016, in connection with the creation of a new Chief Operating Officer organization, Ciena reorganized its internal organizational structure, the management of its business, and the reporting of its operating segments. This resulted in three new operating segments: Networking Platforms, Software and Software-Related Services, and Global Services. Ciena’s previous Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form the Networking Platforms segment under a single operating segment manager. Ciena's previous Software and Services operating segment was reorganized into two separate operating segments: (i) Software and Software-Related Services, and (ii) Global Services. Ciena's segment revenue and segment profit for fiscal 2015 have been restated to reflect the new operating segments adopted in fiscal 2016. See Note 21 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-16-000104:mdna:77]
Quarter ended April 30, 2015 compared to the quarter ended April 30, 2016

[0000936395-16-000104:mdna:78]
[same as prior period, unchanged from 0000936395-16-000083:mdna:73]

[0000936395-16-000104:mdna:79]
Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. In recent periods, certain of our service provider customers, including several of our larger customers in North America and EMEA, have taken steps to constrain their capital expenditure budgets. As a result of this measured spending environment, some of our market segments have been adversely impacted and we have experienced lower spending levels on networking equipment from these customers as compared to prior periods. Partly as a result of these dynamics, our sales in EMEA during the first six months of fiscal 2016 declined 17.0% as compared to the first six months of fiscal 2015. We expect our total revenue during fiscal 2016 will be adversely affected by anticipated sales declines in EMEA during fiscal 2016 as compared to fiscal 2015.

[0000936395-16-000104:mdna:80]
As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as "book to revenue") has increased as compared to our historical periods. Due to the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, our increased reliance on book to revenue may increase the likelihood of fluctuations in our results.

[0000936395-16-000104:mdna:81]
We also expect that our total revenue in fiscal 2016 will be adversely impacted by the recent strengthening of the U.S. Dollar, particularly against the Canadian Dollar, Euro and Brazilian Real. During the second quarter of fiscal 2016, as compared to the second quarter of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar, Euro and Brazilian Real, in which we have our most significant foreign currency revenue exposure. Our total revenue reported in U.S. dollars during the second quarter of fiscal 2016 was slightly impacted by approximately $5.7 million or 0.9% as compared to the second quarter of fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000104:mdna:82]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 435,173 |  |  | 67.9 |  | $ | 432,911 |  |  | 69.6 |  | $ | 2,262 |  |  | 0.5 |  |
| Packet Networking | 68,582 |  |  | 10.7 |  | 53,288 |  |  | 8.6 |  | 15,294 |  |  | 28.7 |  |
| Optical Transport | 8,451 |  |  | 1.3 |  | 16,454 |  |  | 2.7 |  | (8,003 | ) |  | (48.6 | ) |
| Total Networking Platforms | 512,206 |  |  | 79.9 |  | 502,653 |  |  | 80.9 |  | 9,553 |  |  | 1.9 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 11,772 |  |  | 1.9 |  | 9,227 |  |  | 1.5 |  | 2,545 |  |  | 27.6 |  |
| Software-Related Services | 18,701 |  |  | 2.9 |  | 14,686 |  |  | 2.4 |  | 4,015 |  |  | 27.3 |  |
| Total Software and Software-Related Services | 30,473 |  |  | 4.8 |  | 23,913 |  |  | 3.9 |  | 6,560 |  |  | 27.4 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 57,069 |  |  | 8.9 |  | 53,085 |  |  | 8.5 |  | 3,984 |  |  | 7.5 |  |
| Installation and Deployment | 30,232 |  |  | 4.7 |  | 30,703 |  |  | 4.9 |  | (471 | ) |  | (1.5 | ) |
| Consulting and Network Design | 10,737 |  |  | 1.7 |  | 11,248 |  |  | 1.8 |  | (511 | ) |  | (4.5 | ) |
| Total Global Services | 98,038 |  |  | 15.3 |  | 95,036 |  |  | 15.2 |  | 3,002 |  |  | 3.2 |  |
| Consolidated revenue | $ | 640,717 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 19,115 |  |  | 3.1 |  |

[0000936395-16-000104:mdna:83]
[same as prior period, unchanged from 0000936395-16-000083:mdna:77]

[0000936395-16-000104:mdna:84]
[same as prior period, unchanged from 0000936395-16-000083:mdna:78]

[0000936395-16-000104:mdna:85]
[same as prior period, unchanged from 0000936395-16-000083:mdna:79]

[0000936395-16-000104:mdna:86]
| • | Networking Platforms segment revenue increased, primarily reflecting increases of $15.3 million in sales of our Packet Networking products and $2.3 million in sales of our Converged Packet Optical products, partially offset by a decrease of $8.0 million in sales of our Optical Transport products. |

[0000936395-16-000104:mdna:87]
| ◦ | Converged Packet Optical sales reflect the addition of $20.0 million in sales relating to the Z-Series Packet-Optical Platform acquired from Cyan. Converged Packet Optical sales also reflects an increase of $13.0 million in sales of our 5430 Reconfigurable Switching System. These increases within our Converged Packet Optical product line were partially offset by decreases of $23.1 million in sales of our 6500 Packet-Optical Platform, $4.9 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $2.9 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-16-000104:mdna:88]
| ◦ | Packet Networking sales reflect increases of $9.9 million in sales of our 3000 family of service delivery switches and service aggregation switches and $6.2 million in sales of our 8700 Packetwave Platform. |

[0000936395-16-000104:mdna:89]
| ◦ | Optical Transport sales, which have continued to experience expected sales declines, reflect network operators' transition from this product line toward next-generation converged network solutions. As a result, our Optical Transport products have either been previously discontinued or are expected to be discontinued during fiscal 2016. |

[0000936395-16-000104:mdna:90]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting increases of $4.0 million in software-related services sales and $2.5 million in sales of our software platforms. The increase in software-related services sales is primarily due to increased sales of software subscription services. The increase in software platform sales reflects $2.3 million in initial sales of our Blue Planet network virtualization, service orchestration and network management software platform. Segment revenue also includes $0.6 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-16-000104:mdna:91]
| • | Global Services segment revenue increased, primarily reflecting an increase of $4.0 million in sales of maintenance support services. Segment revenue includes $4.2 million in services revenue related to the Cyan acquisition. |

[0000936395-16-000104:mdna:92]
42

[0000936395-16-000104:mdna:93]
[same as prior period, unchanged from 0000936395-16-000083:mdna:86]

[0000936395-16-000104:mdna:94]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 395,505 |  |  | 61.7 |  | $ | 397,181 |  |  | 63.9 |  | $ | (1,676 | ) |  | (0.4 | ) |
| EMEA | 96,175 |  |  | 15.0 |  | 102,194 |  |  | 16.4 |  | (6,019 | ) |  | (5.9 | ) |
| CALA | 57,896 |  |  | 9.0 |  | 47,891 |  |  | 7.7 |  | 10,005 |  |  | 20.9 |  |
| APAC | 91,141 |  |  | 14.3 |  | 74,336 |  |  | 12.0 |  | 16,805 |  |  | 22.6 |  |
| Total | $ | 640,717 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 19,115 |  |  | 3.1 |  |

[0000936395-16-000104:mdna:95]
[same as prior period, unchanged from 0000936395-16-000083:mdna:89]

[0000936395-16-000104:mdna:96]
[same as prior period, unchanged from 0000936395-16-000083:mdna:90]

[0000936395-16-000104:mdna:97]
[same as prior period, unchanged from 0000936395-16-000083:mdna:91]

[0000936395-16-000104:mdna:98]
| • | North America revenue primarily reflects decreases of $13.8 million within our Networking Platforms segment, partially offset by increases of $7.0 million within our Software and Software-Related Services segment and $5.2 million within our Global Services segment. The revenue decrease within our Networking Platforms segment primarily reflects decreases of $17.7 million of Converged Packet Optical sales and $4.1 million in Optical Transport sales, partially offset by an increase of $8.0 million of Packet Networking sales. Converged Packet Optical sales reflect a decrease of $31.8 million in sales of our 6500 Packet-Optical Platform, which reflects decreased sales to cable and multiservice operators and communication service providers, partially offset by increased sales to enterprise customers, submarine network operators and government customers. Converged Packet Optical sales also reflect $17.8 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000104:mdna:99]
| • | EMEA revenue primarily reflects a decrease of $10.2 million within our Networking Platform segment, partially offset by revenue increases of $2.5 million within our Global Services segment and $1.7 million within our Software and Software-Related Services segment. Networking Platform segment revenue reflects a product line decrease of $7.8 million in Converged Packet Optical sales, primarily for the 6500 Packet-Optical Platform and the OTN configuration for the 5410 Reconfigurable Switching System. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000104:mdna:100]
| • | CALA revenue primarily reflects an increase of $10.6 million within our Networking Platform segment. CALA revenue benefited from increased sales to submarine network operators, cable and multiservice operators, Web-scale providers and to AT&T in Mexico, partially offset by lower sales to other service providers, primarily in Brazil. |

[0000936395-16-000104:mdna:101]
| • | APAC revenue primarily reflects an increase of $23.0 million within our Networking Platform segment, partially offset by decreases of $4.5 million within our Global Services segment and $1.7 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to enterprise customers and submarine network operators and sales through our strategic relationship with Ericsson, partially offset by lower sales to service providers. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-16-000104:mdna:102]
[same as prior period, unchanged from 0000936395-16-000083:mdna:96]

[0000936395-16-000104:mdna:103]
[same as prior period, unchanged from 0000936395-16-000083:mdna:97]

[0000936395-16-000104:mdna:104]
Services cost of goods sold consists primarily of direct and third party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third party contractor-related costs.

[0000936395-16-000104:mdna:105]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography, and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin products including channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. We regularly encounter pricing pressure and market-based price erosion that can impact our results of operations, and we expect that our gross margins will be subject to fluctuation and significantly dependent upon on our level of success in driving product cost reductions relative to the price reductions that we encounter. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods.

[0000936395-16-000104:mdna:106]
[same as prior period, unchanged from 0000936395-16-000083:mdna:101]

[0000936395-16-000104:mdna:107]
[same as prior period, unchanged from 0000936395-16-000083:mdna:102]

[0000936395-16-000104:mdna:108]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 640,717 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 19,115 |  |  | 3.1 |
| Total cost of goods sold | 357,624 |  |  | 55.8 |  | 349,191 |  |  | 56.2 |  | 8,433 |  |  | 2.4 |
| Gross profit | $ | 283,093 |  |  | 44.2 |  | $ | 272,411 |  |  | 43.8 |  | $ | 10,682 |  |  | 3.9 |

[0000936395-16-000104:mdna:109]
[same as prior period, unchanged from 0000936395-16-000083:mdna:104]

[0000936395-16-000104:mdna:110]
[same as prior period, unchanged from 0000936395-16-000083:mdna:105]

[0000936395-16-000104:mdna:111]
[same as prior period, unchanged from 0000936395-16-000083:mdna:106]

[0000936395-16-000104:mdna:112]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 523,978 |  |  | 100.0 |  | $ | 511,880 |  |  | 100.0 |  | $ | 12,098 |  |  | 2.4 |
| Product cost of goods sold | 291,778 |  |  | 55.7 |  | 286,898 |  |  | 56.0 |  | 4,880 |  |  | 1.7 |
| Product gross profit | $ | 232,200 |  |  | 44.3 |  | $ | 224,982 |  |  | 44.0 |  | $ | 7,218 |  |  | 3.2 |

[0000936395-16-000104:mdna:113]
[same as prior period, unchanged from 0000936395-16-000083:mdna:108]

[0000936395-16-000104:mdna:114]
[same as prior period, unchanged from 0000936395-16-000083:mdna:109]

[0000936395-16-000104:mdna:115]
[same as prior period, unchanged from 0000936395-16-000083:mdna:110]

[0000936395-16-000104:mdna:116]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 116,739 |  |  | 100.0 |  | $ | 109,722 |  |  | 100.0 |  | $ | 7,017 |  |  | 6.4 |
| Service cost of goods sold | 65,846 |  |  | 56.4 |  | 62,293 |  |  | 56.8 |  | 3,553 |  |  | 5.7 |
| Service gross profit | $ | 50,893 |  |  | 43.6 |  | $ | 47,429 |  |  | 43.2 |  | $ | 3,464 |  |  | 7.3 |

[0000936395-16-000104:mdna:117]
[same as prior period, unchanged from 0000936395-16-000083:mdna:112]

[0000936395-16-000104:mdna:118]
[same as prior period, unchanged from 0000936395-16-000083:mdna:113]

[0000936395-16-000104:mdna:119]
[same as prior period, unchanged from 0000936395-16-000083:mdna:114]

[0000936395-16-000104:mdna:120]
| • | Gross profit as a percentage of revenue increased as a result of the following factors: |

[0000936395-16-000104:mdna:121]
| • | Gross profit on products as a percentage of product revenue increased, as a result of product cost reductions, improved manufacturing efficiencies and higher software revenue, partially offset by the impact of market-based price erosion and an increased provision for excess and obsolete inventory expense. |

[0000936395-16-000104:mdna:122]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased sales of higher margin software subscription services and improved efficiencies for maintenance and support services. |

[0000936395-16-000104:mdna:123]
[same as prior period, unchanged from 0000936395-16-000083:mdna:118]

[0000936395-16-000104:mdna:124]
We expect operating expense to increase in fiscal 2016 from the level reported for fiscal 2015, in part due to the additional personnel and operations related to our acquisition of Cyan during the fourth quarter of fiscal 2015 and our acquisition of the HSPC assets of TeraXion on February 1, 2016. We also expect operating expense to increase in order to fund our research and development initiatives, to provide for investments in the re-engineering of company-wide enterprise resource planning platforms, and to fund the transition of key facilities. In particular, the development of our new facilities and the transition of our operations in Ottawa, Canada and Gurgaon, India will require significant effort, time and cost.

[0000936395-16-000104:mdna:125]
[same as prior period, unchanged from 0000936395-16-000083:mdna:120]

[0000936395-16-000104:mdna:126]
[same as prior period, unchanged from 0000936395-16-000083:mdna:121]

[0000936395-16-000104:mdna:127]
[same as prior period, unchanged from 0000936395-16-000083:mdna:122]

[0000936395-16-000104:mdna:128]
[same as prior period, unchanged from 0000936395-16-000083:mdna:123]

[0000936395-16-000104:mdna:129]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition of Cyan on August 3, 2015 and our acquisition of the HSPC assets from TeraXion and its wholly-owned subsidiary on February 1, 2016.

[0000936395-16-000104:mdna:130]
[same as prior period, unchanged from 0000936395-16-000083:mdna:125]

[0000936395-16-000104:mdna:131]
Restructuring costs primarily reflect actions Ciena has taken to better align our workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions.

[0000936395-16-000104:mdna:132]
[same as prior period, unchanged from 0000936395-16-000083:mdna:127]

[0000936395-16-000104:mdna:133]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 114,603 |  |  | 17.9 |  | $ | 105,202 |  |  | 16.9 |  |  | $ | 9,401 |  |  | 8.9 |  |
| Selling and marketing | 86,668 |  |  | 13.5 |  | 82,471 |  |  | 13.3 |  |  | 4,197 |  |  | 5.1 |  |
| General and administrative | 35,203 |  |  | 5.5 |  | 30,302 |  |  | 4.9 |  |  | 4,901 |  |  | 16.2 |  |
| Acquisition and integration costs | 2,285 |  |  | 0.4 |  | 1,020 |  |  | 0.2 |  |  | 1,265 |  |  | 124.0 |  |
| Amortization of intangible assets | 15,566 |  |  | 2.4 |  | 11,019 |  |  | 1.8 |  |  | 4,547 |  |  | 41.3 |  |
| Restructuring costs | 535 |  |  | 0.1 |  | (17 | ) |  | — |  |  | 552 |  |  | (3,247.1 | ) |
| Total operating expenses | $ | 254,860 |  |  | 39.8 |  | $ | 229,997 |  |  | 37.1 |  |  | $ | 24,863 |  |  | 10.8 |  |

[0000936395-16-000104:mdna:134]
[same as prior period, unchanged from 0000936395-16-000083:mdna:129]

[0000936395-16-000104:mdna:135]
[same as prior period, unchanged from 0000936395-16-000083:mdna:130]

[0000936395-16-000104:mdna:136]
[same as prior period, unchanged from 0000936395-16-000083:mdna:131]

[0000936395-16-000104:mdna:137]
| • | Research and development expense benefited from $4.3 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $9.4 million. This change reflects increases of $6.1 million in employee and compensation costs, $2.2 million in facilities and information technology costs, $1.3 million in depreciation expense and $1.0 million in professional services. These increases were partially offset by a decrease of $1.9 million in prototype expense. |

[0000936395-16-000104:mdna:138]
| • | Selling and marketing expense increased by $4.2 million, primarily reflecting increases of $3.9 million in employee and compensation costs and $1.0 million in facilities and information technology costs, partially offset by a decrease of $1.0 million in trade show and related costs. |

[0000936395-16-000104:mdna:139]
| • | General and administrative expense increased by $4.9 million, primarily reflecting increases of $3.0 million in employee and compensation costs and $1.2 million for legal settlements related to certain patent litigation. |

[0000936395-16-000104:mdna:140]
| • | Acquisition and integration costs reflects expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000104:mdna:141]
| • | Amortization of intangible assets increased due to expense related to acquired intangible assets from our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000104:mdna:142]
[same as prior period, unchanged from 0000936395-16-000083:mdna:138]

[0000936395-16-000104:mdna:143]
[same as prior period, unchanged from 0000936395-16-000083:mdna:139]

[0000936395-16-000104:mdna:144]
[same as prior period, unchanged from 0000936395-16-000083:mdna:140]

[0000936395-16-000104:mdna:145]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 967 |  |  | 0.2 |  | $ | (5,549 | ) |  | (0.9 | ) |  | $ | 6,516 |  |  | 117.4 |  |
| Interest expense | $ | 12,608 |  |  | 2.0 |  | $ | 12,947 |  |  | 2.1 |  |  | $ | (339 | ) |  | (2.6 | ) |
| Provision for income taxes | $ | 2,595 |  |  | 0.4 |  | $ | 3,265 |  |  | 0.5 |  |  | $ | (670 | ) |  | (20.5 | ) |

[0000936395-16-000104:mdna:146]
[same as prior period, unchanged from 0000936395-16-000083:mdna:142]

[0000936395-16-000104:mdna:147]
[same as prior period, unchanged from 0000936395-16-000083:mdna:143]

[0000936395-16-000104:mdna:148]
[same as prior period, unchanged from 0000936395-16-000083:mdna:144]

[0000936395-16-000104:mdna:149]
| • | Interest and other income (loss), net reflects the improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-16-000104:mdna:150]
| • | Interest expense remained relatively unchanged. |

[0000936395-16-000104:mdna:151]
| • | Provision for income taxes decreased primarily due to foreign tax expense. |

[0000936395-16-000104:mdna:152]
Six months ended April 30, 2015 compared to the six months ended April 30, 2016

[0000936395-16-000104:mdna:153]
Revenue

[0000936395-16-000104:mdna:154]
During the first six months of fiscal 2016, as compared to the first six months of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar, Euro, and Brazilian Real in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars was adversely impacted by approximately $16.1 million or 1.3% as compared to the first six months of fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000104:mdna:155]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 824,341 |  |  | 67.9 |  | $ | 769,471 |  |  | 66.9 |  | $ | 54,870 |  |  | 7.1 |  |
| Packet Networking | 116,779 |  |  | 9.6 |  | 108,271 |  |  | 9.4 |  | 8,508 |  |  | 7.9 |  |
| Optical Transport | 20,596 |  |  | 1.7 |  | 38,793 |  |  | 3.4 |  | (18,197 | ) |  | (46.9 | ) |
| Total Networking Platforms | 961,716 |  |  | 79.2 |  | 916,535 |  |  | 79.7 |  | 45,181 |  |  | 4.9 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 19,851 |  |  | 1.6 |  | 17,660 |  |  | 1.5 |  | 2,191 |  |  | 12.4 |  |
| Software-Related Services | 36,048 |  |  | 3.0 |  | 29,781 |  |  | 2.6 |  | 6,267 |  |  | 21.0 |  |
| Total Software and Software-Related Services | 55,899 |  |  | 4.6 |  | 47,441 |  |  | 4.1 |  | 8,458 |  |  | 17.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 113,127 |  |  | 9.4 |  | 106,986 |  |  | 9.3 |  | 6,141 |  |  | 5.7 |  |
| Installation and Deployment | 61,072 |  |  | 5.0 |  | 56,884 |  |  | 4.9 |  | 4,188 |  |  | 7.4 |  |
| Consulting and Network Design | 22,018 |  |  | 1.8 |  | 22,918 |  |  | 2.0 |  | (900 | ) |  | (3.9 | ) |
| Total Global Services | 196,217 |  |  | 16.2 |  | 186,788 |  |  | 16.2 |  | 9,429 |  |  | 5.0 |  |
| Consolidated revenue | $ | 1,213,832 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 63,068 |  |  | 5.5 |  |

[0000936395-16-000104:mdna:156]
_____________________________

[0000936395-16-000104:mdna:157]
*    Denotes % of total revenue

[0000936395-16-000104:mdna:158]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:159]
| • | Networking Platforms segment revenue increased, primarily reflecting increases of $54.9 million in sales of our Converged Packet Optical products and $8.5 million of Packet Networking products, partially offset by a decrease of $18.2 million in sales of our Optical Transport products. |

[0000936395-16-000104:mdna:160]
| ◦ | Converged Packet Optical sales reflect an increase of $12.3 million of our 6500 Packet-Optical Platform, primarily due to increased sales to enterprise customers, AT&T, government customers and sales through our strategic relationship with Ericsson. These increases were partially offset by decreases in sales of our 6500 Packet-Optical Platform to Web-scale and other service providers, cable and multiservice operators and submarine network operators. Increased sales from Converged Packet Optical also reflects the addition of $54.1 million in sales relating to the Z-Series Packet-Optical Platform acquired from Cyan. These increases within our Converged Packet Optical product line were partially offset by decreases of $7.7 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $3.2 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-16-000104:mdna:161]
| ◦ | Packet Networking sales reflect increases of $7.6 million in sales of our 8700 Packetwave Platform and $2.7 million in sales of our 3000 family of service delivery switches, partially offset by a decrease of $1.3 million in sales of our 5410 Service Aggregation Switch. |

[0000936395-16-000104:mdna:162]
47

[0000936395-16-000104:mdna:163]
| ◦ | Optical Transport sales, which generally have experienced continued declines, reflect network operators' transition from this product line toward next-generation converged network solutions. As a result, our Optical Transport products have either been previously discontinued or are expected to be discontinued during fiscal 2016. |

[0000936395-16-000104:mdna:164]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting increases of $6.3 million in software-related services sales and $2.2 million in sales of our software platforms. The increase in software-related services sales is primarily due to increased sales of software subscription services. The increase in software platform sales reflects $2.4 million in initial sales of our Blue Planet network virtualization, service orchestration and network management software platform. Segment revenue also includes $0.8 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-16-000104:mdna:165]
| • | Global Services segment revenue increased, primarily reflecting increases of $6.1 million in sales of our maintenance and support services and $4.2 million in sales of our installation and deployment services. Global Services segment revenue includes $10.2 million of services revenue acquired from Cyan. |

[0000936395-16-000104:mdna:166]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-16-000104:mdna:167]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 788,209 |  |  | 64.9 |  | $ | 728,716 |  |  | 63.3 |  | $ | 59,493 |  |  | 8.2 |  |
| EMEA | 176,897 |  |  | 14.6 |  | 213,200 |  |  | 18.5 |  | (36,303 | ) |  | (17.0 | ) |
| CALA | 101,706 |  |  | 8.4 |  | 90,633 |  |  | 7.9 |  | 11,073 |  |  | 12.2 |  |
| APAC | 147,020 |  |  | 12.1 |  | 118,215 |  |  | 10.3 |  | 28,805 |  |  | 24.4 |  |
| Total | $ | 1,213,832 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 63,068 |  |  | 5.5 |  |

[0000936395-16-000104:mdna:168]
[same as prior period, unchanged from 0000936395-16-000083:mdna:151]

[0000936395-16-000104:mdna:169]
*    Denotes % of total revenue

[0000936395-16-000104:mdna:170]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:171]
| • | North America revenue primarily reflects increases of $42.9 million within our Networking Platforms segment, $8.4 million within our Global Services segment, and $8.2 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of $52.6 million of Converged Packet Optical sales, partially offset by decreases of $7.7 million in Optical Transport sales and $2.0 million of Packet Networking sales. Converged Packet Optical sales reflect increases of $12.4 million in sales of our 6500 Packet-Optical Platform, which reflects increased sales to communication service providers, enterprise customers, government customers and network submarine operators, slightly offset by reduced sales to cable and multiservice operators and Web-scale providers. Converged Packet Optical sales also include $46.2 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000104:mdna:172]
| • | EMEA revenue primarily reflects a decrease of $39.2 million within our Networking Platform segment. Networking Platform segment revenue reflects a product line decrease of $34.0 million in Converged Packet Optical sales, primarily for the 6500 Packet-Optical Platform. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000104:mdna:173]
| • | CALA revenue primarily reflects an increase of $12.0 million within our Networking Platform segment. CALA revenue benefited from increased sales to to AT&T in Mexico, submarine network operators, cable and multiservice operators and Web-scale providers, partially offset by lower sales to other service providers, primarily in Brazil. |

[0000936395-16-000104:mdna:174]
| • | APAC revenue primarily reflects an increase of $29.5 million within our Networking Platform segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to certain communications service provider and enterprise customers, submarine network operators and sales through our strategic partnership with Ericsson. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-16-000104:mdna:175]
Cost of Goods Sold and Gross Profit

[0000936395-16-000104:mdna:176]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-16-000104:mdna:177]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,213,832 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 63,068 |  |  | 5.5 |
| Total cost of goods sold | 679,289 |  |  | 56.0 |  | 648,058 |  |  | 56.3 |  | 31,231 |  |  | 4.8 |
| Gross profit | $ | 534,543 |  |  | 44.0 |  | $ | 502,706 |  |  | 43.7 |  | $ | 31,837 |  |  | 6.3 |

[0000936395-16-000104:mdna:178]
[same as prior period, unchanged from 0000936395-16-000083:mdna:192]

[0000936395-16-000104:mdna:179]
*    Denotes % of total revenue

[0000936395-16-000104:mdna:180]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:181]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 981,567 |  |  | 100.0 |  | $ | 934,195 |  |  | 100.0 |  | $ | 47,372 |  |  | 5.1 |
| Product cost of goods sold | 552,260 |  |  | 56.3 |  | 523,446 |  |  | 56.0 |  | 28,814 |  |  | 5.5 |
| Product gross profit | $ | 429,307 |  |  | 43.7 |  | $ | 410,749 |  |  | 44.0 |  | $ | 18,558 |  |  | 4.5 |

[0000936395-16-000104:mdna:182]
_____________________________________

[0000936395-16-000104:mdna:183]
*    Denotes % of product revenue

[0000936395-16-000104:mdna:184]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:185]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 232,265 |  |  | 100.0 |  | $ | 216,569 |  |  | 100.0 |  | $ | 15,696 |  |  | 7.2 |
| Service cost of goods sold | 127,029 |  |  | 54.7 |  | 124,612 |  |  | 57.5 |  | 2,417 |  |  | 1.9 |
| Service gross profit | $ | 105,236 |  |  | 45.3 |  | $ | 91,957 |  |  | 42.5 |  | $ | 13,279 |  |  | 14.4 |

[0000936395-16-000104:mdna:186]
_____________________________________

[0000936395-16-000104:mdna:187]
*    Denotes % of services revenue

[0000936395-16-000104:mdna:188]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:189]
| • | Gross profit as a percentage of revenue increased as a result of the following factors: |

[0000936395-16-000104:mdna:190]
| • | Gross profit on products as a percentage of product revenue decreased as a result of market-based price erosion and an increased provision for excess and obsolete inventory expense partially offset by product cost reductions, higher software revenue and improved manufacturing efficiencies. |

[0000936395-16-000104:mdna:191]
| • | Gross profit on services as a percentage of services revenue increased primarily due to increased sales of higher margin software subscription services and reduced repair costs to support maintenance service contracts. |

[0000936395-16-000104:mdna:192]
Operating Expense

[0000936395-16-000104:mdna:193]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-16-000104:mdna:194]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 222,649 |  |  | 18.3 |  | $ | 205,963 |  |  | 17.9 |  | $ | 16,686 |  |  | 8.1 |  |
| Selling and marketing | 169,146 |  |  | 13.9 |  | 159,183 |  |  | 13.8 |  | 9,963 |  |  | 6.3 |  |
| General and administrative | 66,345 |  |  | 5.5 |  | 59,855 |  |  | 5.2 |  | 6,490 |  |  | 10.8 |  |
| Acquisition and integration costs | 3,584 |  |  | 0.3 |  | 1,020 |  |  | 0.1 |  | 2,564 |  |  | 251.4 |  |
| Amortization of intangible assets | 32,428 |  |  | 2.7 |  | 22,038 |  |  | 1.9 |  | 10,390 |  |  | 47.1 |  |
| Restructuring costs | 919 |  |  | 0.1 |  | 8,068 |  |  | 0.7 |  | (7,149 | ) |  | (88.6 | ) |
| Total operating expenses | $ | 495,071 |  |  | 40.8 |  | $ | 456,127 |  |  | 39.6 |  | $ | 38,944 |  |  | 8.5 |  |

[0000936395-16-000104:mdna:195]
_____________________________________

[0000936395-16-000104:mdna:196]
*    Denotes % of total revenue

[0000936395-16-000104:mdna:197]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:198]
| • | Research and development expense benefited $13.6 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $16.7 million. This change reflects increases of $10.8 million in employee and compensation costs, $4.2 million in facilities and information technology costs, $1.9 million in professional services and $1.7 million in depreciation expense. Research and development expense for fiscal 2016 also reflects a $1.7 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario, due to the maximum funding limit being met in the second quarter of fiscal 2015. These increases were partially offset by a decrease of $4.4 million in prototype expense. |

[0000936395-16-000104:mdna:199]
| • | Selling and marketing expense benefited $4.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro, Canadian Dollar and Brazilian Real. Including the effect of foreign exchange rates, selling and marketing expense increased by $10.0 million, primarily reflecting increases of $7.6 million in employee and compensation costs, $2.1 million in professional services, $1.4 million in facilities and information technology costs and $1.0 million in travel and related costs. These increases were partially offset by a decrease of $1.7 million in trade shows and related costs. |

[0000936395-16-000104:mdna:200]
| • | General and administrative expense benefited $1.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Brazilian Real, Canadian Dollar and Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $6.5 million, primarily due to increased employee and compensation costs of $5.3 million and $1.2 million for legal settlements related to certain patent litigations. |

[0000936395-16-000104:mdna:201]
| • | Acquisition and integration costs reflects expense for financial, legal and accounting advisors, and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000104:mdna:202]
| • | Amortization of intangible assets increased due to expense related to acquired intangible assets from our acquisition of Cyan during fiscal 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000104:mdna:203]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities |

[0000936395-16-000104:mdna:204]
Other items

[0000936395-16-000104:mdna:205]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-16-000104:mdna:206]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (7,809 | ) |  | (0.6 | ) |  | $ | (13,782 | ) |  | (1.2 | ) |  | $ | 5,973 |  |  | 43.3 |  |
| Interest expense | $ | 25,318 |  |  | 2.1 |  |  | $ | 26,608 |  |  | 2.3 |  |  | $ | (1,290 | ) |  | (4.8 | ) |
| Provision for income taxes | $ | 3,894 |  |  | 0.3 |  |  | $ | 4,315 |  |  | 0.4 |  |  | $ | (421 | ) |  | (9.8 | ) |

[0000936395-16-000104:mdna:207]
_____________________________________

[0000936395-16-000104:mdna:208]
*    Denotes % of total revenue

[0000936395-16-000104:mdna:209]
**    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:210]
| • | Interest and other income (loss), net reflects the improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-16-000104:mdna:211]
[same as prior period, unchanged from 0000936395-16-000083:mdna:146]

[0000936395-16-000104:mdna:212]
| • | Provision for income taxes decreased primarily due to foreign tax expense. |

[0000936395-16-000104:mdna:213]
[same as prior period, unchanged from 0000936395-16-000083:mdna:148]

[0000936395-16-000104:mdna:214]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-16-000104:mdna:215]
|  | Quarter Ended April 30, |  |  |  |
|  | 2016 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 132,606 |  |  | $ | 131,252 |  |  | $ | 1,354 |  |  | 1.0 |  |
| Software and Software-Related Services | $ | 192 |  |  | $ | 806 |  |  | $ | (614 | ) |  | (76.2 | ) |
| Global Services | $ | 35,692 |  |  | $ | 35,151 |  |  | $ | 541 |  |  | 1.5 |  |

[0000936395-16-000104:mdna:216]
_____________________________________

[0000936395-16-000104:mdna:217]
[same as prior period, unchanged from 0000936395-16-000083:mdna:152]

[0000936395-16-000104:mdna:218]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin partially offset by higher research and development costs. The improved gross margin was the result of product cost reductions and improved manufacturing efficiencies partially offset by market-based price erosion and an increased provision for excess and obsolete inventory expense. |

[0000936395-16-000104:mdna:219]
| • | Software and Software-Related Services segment profit decreased, primarily due to higher research and development costs and lower gross margin from increased amortization of intangibles expense, partially offset by higher sales volume. Higher research and development costs reflect the addition of expenses relating to the development of our Blue Planet software platform. |

[0000936395-16-000104:mdna:220]
| • | Global Services segment profit increased, primarily due to higher sales volume, as described above, partially offset by reduced gross margin. |

[0000936395-16-000104:mdna:221]
[same as prior period, unchanged from 0000936395-16-000083:mdna:149]

[0000936395-16-000104:mdna:222]
|  | Six Months Ended April 30, |  |  |  |  |
|  | 2016 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 239,588 |  |  | $ | 226,326 |  |  | $ | 13,262 |  |  | 5.9 |  |
| Software and Software-Related Services | $ | (3,382 | ) |  | $ | 3,394 |  |  | $ | (6,776 | ) |  | (199.6 | ) |
| Global Services | $ | 75,688 |  |  | $ | 67,023 |  |  | $ | 8,665 |  |  | 12.9 |  |

[0000936395-16-000104:mdna:223]
_____________________________________

[0000936395-16-000104:mdna:224]
*    Denotes % change from 2015 to 2016

[0000936395-16-000104:mdna:225]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume as described above. The increased sales volume was partially offset by higher research and development costs and reduced gross margin. The reduced gross margin was the result of market-based price erosion and an increased provision for excess and obsolete inventory expense partially offset by product cost reductions and improved manufacturing efficiencies. |

[0000936395-16-000104:mdna:226]
| • | Software and Software-Related Services segment loss primarily reflects higher research and development costs and reduced gross margin from increased amortization of intangibles expense, partially offset by higher sales volume. Higher research and development costs reflect the addition of expenses relating to the development of our Blue Planet software platform. |

[0000936395-16-000104:mdna:227]
| • | Global Services segment profit increased, primarily due to higher sales volume and improved gross margin. The improved gross margin reflects lower costs for maintenance, support, installation and deployment services. |

[0000936395-16-000104:mdna:228]
[same as prior period, unchanged from 0000936395-16-000083:mdna:157]

[0000936395-16-000104:mdna:229]
At April 30, 2016, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-16-000104:mdna:230]
|  | April 30, 2016 |  | October 31, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 922,033 |  |  | $ | 790,971 |  |  | $ | 131,062 |  |
| Short-term investments in marketable debt securities | 195,179 |  |  | 135,107 |  |  | 60,072 |  |
| Long-term investments in marketable debt securities | 125,233 |  |  | 95,105 |  |  | 30,128 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,242,445 |  |  | $ | 1,021,183 |  |  | $ | 221,262 |  |

[0000936395-16-000104:mdna:231]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $44.6 million as of April 30, 2016. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which  we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-16-000104:mdna:232]
As more fully described in Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, during the second quarter of fiscal 2016 we entered into an Incremental Term Loan Credit Agreement that provides for a new tranche of senior secured term loans under the Credit Agreement dated July 15, 2014 in an aggregate principal amount of $250 million maturing on April 25, 2021. The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% Senior Convertible Notes due June 15, 2017.

[0000936395-16-000104:mdna:233]
The change in total cash and cash equivalents and investments in marketable debt securities during the first six months of fiscal 2016 was also related to the following:

[0000936395-16-000104:mdna:234]
| • | $75.7 million cash generated from operations, consisting of $140.6 million provided by net income (adjusted for non-cash charges) offset by $64.9 million used in working capital; |

[0000936395-16-000104:mdna:235]
| • | $53.1 million used for purchases of equipment, furniture and fixtures and intellectual property; |

[0000936395-16-000104:mdna:236]
| • | $4.8 million used for settlement of foreign currency forward contracts, net; |

[0000936395-16-000104:mdna:237]
| • | $3.8 million used to pay capital lease obligations; |

[0000936395-16-000104:mdna:238]
| • | $32.0 million used for the purchase price to acquire the HSPC assets of TeraXion; |

[0000936395-16-000104:mdna:239]
| • | $15.3 million used for repayment of long-term debt; |

[0000936395-16-000104:mdna:240]
| • | $10.0 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; |

[0000936395-16-000104:mdna:241]
| • | $1.1 million used for payment of debt issuance costs, other than costs associated with the 2021 Term Loan; and |

[0000936395-16-000104:mdna:242]
| • | $0.6 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-16-000104:mdna:243]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the "ABL Credit Facility") providing for a total commitment of $250 million with a maturity date of December 31, 2020. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of April 30, 2016, letters of credit totaling $66.7 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2016.

[0000936395-16-000104:mdna:244]
52

[0000936395-16-000104:mdna:245]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-16-000104:mdna:246]
The following sections set forth the components of our $75.7 million of cash generated from operating activities during the first six months of fiscal 2016:

[0000936395-16-000104:mdna:247]
Net income (adjusted for non-cash charges)

[0000936395-16-000104:mdna:248]
The following table sets forth our net income (adjusted for non-cash charges) during the period (in thousands):

[0000936395-16-000104:mdna:249]
|  | Six months ended |
|  | April 30, 2016 |
| Net income | $ | 2,451 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 30,237 |  |
| Share-based compensation costs | 29,210 |  |
| Amortization of intangible assets | 40,488 |  |
| Provision for inventory excess and obsolescence | 20,104 |  |
| Provision for warranty | 9,563 |  |
| Other | 8,578 |  |
| Net income (adjusted for non-cash charges) | $ | 140,631 |  |

[0000936395-16-000104:mdna:250]
[same as prior period, unchanged from 0000936395-16-000083:mdna:175]

[0000936395-16-000104:mdna:251]
We used $64.9 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-16-000104:mdna:252]
|  | Six months ended |
|  | April 30, 2016 |
| Cash used in accounts receivable | $ | (4,865 | ) |
| Cash used in inventories | (19,022 | ) |
| Cash used in prepaid expenses and other | (7,670 | ) |
| Cash used in accounts payable, accruals and other obligations | (29,400 | ) |
| Cash used in deferred revenue | (3,992 | ) |
| Total cash used for working capital | $ | (64,949 | ) |

[0000936395-16-000104:mdna:253]
As compared to the end of fiscal 2015:

[0000936395-16-000104:mdna:254]
| • | The $4.9 million of cash used by accounts receivable during the first six months of fiscal 2016 reflects higher proportional sales volume at the end of the second quarter of fiscal 2016; |

[0000936395-16-000104:mdna:255]
| • | The $19.0 million of cash used in inventory during the first six months of fiscal 2016 primarily reflects increases in deferred costs of goods sold; |

[0000936395-16-000104:mdna:256]
| • | Cash used in prepaid expense and other during the first six months of fiscal 2016 was $7.7 million, primarily reflecting higher prepaid value added taxes and product demonstration equipment; |

[0000936395-16-000104:mdna:257]
| • | The $29.4 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2016 reflects, among other things, the annual payment under our cash incentive compensation plan to employees; and |

[0000936395-16-000104:mdna:258]
| • | The $4.0 million of cash used in deferred revenue during the first six months of fiscal 2016 represents an increase in the recognition of revenue for which we received advanced payments from customers. |

[0000936395-16-000104:mdna:259]
Our days sales outstanding (DSOs) for the first six months of fiscal 2016 were 82 days and our inventory turns for the first six months of fiscal 2016 were 5.8.

[0000936395-16-000104:mdna:260]
[same as prior period, unchanged from 0000936395-16-000083:mdna:179]

[0000936395-16-000104:mdna:261]
The following tables set forth the cash paid for interest during the period (in thousands):

[0000936395-16-000104:mdna:262]
|  | Six months ended |
|  | April 30, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 2,162 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | 6,562 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 3,750 |  |
| Term Loan due July 15, 2019(4) | 4,676 |  |
| Term Loan due April 25, 2021(5) | — |  |
| Interest rate swaps(6) | 1,572 |  |
| ABL Credit Facility(7) | 898 |  |
| Cash paid during period | $ | 19,620 |  |

[0000936395-16-000104:mdna:263]
| (1) | Interest on our outstanding 0.875% Convertible Senior Notes, due June 15, 2017, is payable on June 15 and December 15 of each year. |

[0000936395-16-000104:mdna:264]
| (2) | Interest on our outstanding 3.75% Convertible Senior Notes, due October, 2018, is payable on April 15 and October 15 of each year. |

[0000936395-16-000104:mdna:265]
| (3) | Interest on our outstanding 4.0% Convertible Senior Notes, due December 15, 2020, is payable on June 15 and December 15 of each year. |

[0000936395-16-000104:mdna:266]
| (4) | Interest on our outstanding 2019 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bears interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. During the first six months of fiscal 2016, the interest rate on the 2019 Term Loan was 3.75%. |

[0000936395-16-000104:mdna:267]
| (5) | No interest was paid on our outstanding 2021 Term Loan. Interest is payable periodically based on the underlying market index rate selected for borrowing. From April 25, 2016 through May 5, 2016, the interest rate in effect on our 2021 Term Loan was 6.0%, which was a base rate borrowing. After this initial period, the 2021 Term Loan bears interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. |

[0000936395-16-000104:mdna:268]
| (6) | Payments on our interest rate swaps are variable and effectively fix the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018. |

[0000936395-16-000104:mdna:269]
| (7) | During the first six months of fiscal 2016, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.9 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-16-000104:mdna:270]
For additional information about our convertible notes and term loans, ABL Credit Facility and interest rate swaps, see Notes 15, 17 and 18 to our Condensed Consolidated Financial Statements included in in Item 1 of Part I of this report.

[0000936395-16-000104:mdna:271]
[same as prior period, unchanged from 0000936395-16-000083:mdna:189]

[0000936395-16-000104:mdna:272]
The following is a summary of our future minimum payments under contractual obligations as of April 30, 2016 (in thousands):

[0000936395-16-000104:mdna:273]
54

[0000936395-16-000104:mdna:274]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,047,112 |  |  | $ | — |  |  | $ | 829,985 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on term loans | 495,625 |  |  | 5,000 |  |  | 10,000 |  |  | 480,625 |  |  | — |  |
| Interest due on convertible notes | 76,875 |  |  | 25,000 |  |  | 36,875 |  |  | 15,000 |  |  | — |  |
| Interest due on term loans (2) | 82,528 |  |  | 20,010 |  |  | 39,615 |  |  | 22,903 |  |  | — |  |
| Payments due under interest rate swaps (2) | 13,074 |  |  | 4,404 |  |  | 6,914 |  |  | 1,756 |  |  | — |  |
| Operating leases (3) | 138,210 |  |  | 34,880 |  |  | 39,955 |  |  | 21,219 |  |  | 42,156 |  |
| Purchase obligations (4) | 216,484 |  |  | 216,484 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 4,937 |  |  | 2,778 |  |  | 1,730 |  |  | 429 |  |  | — |  |
| Capital leases— buildings (5) | 132,214 |  |  | 2,242 |  |  | 13,544 |  |  | 15,627 |  |  | 100,801 |  |
| Other obligations | 1,585 |  |  | 1,085 |  |  | 382 |  |  | 118 |  |  | — |  |
| Total (6) | $ | 2,208,644 |  |  | $ | 311,883 |  |  | $ | 979,000 |  |  | $ | 774,804 |  |  | $ | 142,957 |  |

[0000936395-16-000104:mdna:275]
_____________________________________

[0000936395-16-000104:mdna:276]
| (1) | Includes the accretion of the principal amount on our outstanding 4.0% Convertible Senior Notes, due December 15, 2020 payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-16-000104:mdna:277]
| (2) | Interest on the term loans and payments due under the interest rate swaps are variable and were calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 15 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-16-000104:mdna:278]
[same as prior period, unchanged from 0000936395-16-000083:mdna:195]

[0000936395-16-000104:mdna:279]
[same as prior period, unchanged from 0000936395-16-000083:mdna:196]

[0000936395-16-000104:mdna:280]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the excepted commencement of the lease term. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-16-000104:mdna:281]
| (6) | As of April 30, 2016, we also had approximately $12.2 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-16-000104:mdna:282]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of April 30, 2016 (in thousands):

[0000936395-16-000104:mdna:283]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 69,203 |  |  | $ | 34,017 |  |  | $ | 14,973 |  |  | $ | 9,368 |  |  | $ | 10,845 |  |

[0000936395-16-000104:mdna:284]
[same as prior period, unchanged from 0000936395-16-000083:mdna:202]

[0000936395-16-000104:mdna:285]
[same as prior period, unchanged from 0000936395-16-000083:mdna:203]

[0000936395-16-000104:mdna:286]
[same as prior period, unchanged from 0000936395-16-000083:mdna:204]

[0000936395-16-000104:mdna:287]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their

[0000936395-16-000104:mdna:288]
nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-16-000104:mdna:289]
[same as prior period, unchanged from 0000936395-16-000083:mdna:206]

[0000936395-16-000104:mdna:290]
[same as prior period, unchanged from 0000936395-16-000083:mdna:207]

[0000936395-16-000104:mdna:291]
[same as prior period, unchanged from 0000936395-16-000083:mdna:208]

[0000936395-16-000104:mdna:292]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the first six months ended April 30, 2016 and April 30, 2015 were 0.4% and 1.7%, respectively.

[0000936395-16-000104:mdna:293]
[same as prior period, unchanged from 0000936395-16-000083:mdna:210]

[0000936395-16-000104:mdna:294]
[same as prior period, unchanged from 0000936395-16-000083:mdna:211]

[0000936395-16-000104:mdna:295]
[same as prior period, unchanged from 0000936395-16-000083:mdna:212]

[0000936395-16-000104:mdna:296]
[same as prior period, unchanged from 0000936395-16-000083:mdna:213]

[0000936395-16-000104:mdna:297]
Our total deferred revenue for products was $49.2 million and $66.5 million as of April 30, 2016 and October 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be

[0000936395-16-000104:mdna:298]
performed. Our total deferred revenue for services was $137.8 million and $122.5 million as of April 30, 2016 and October 31, 2015, respectively.

[0000936395-16-000104:mdna:299]
[same as prior period, unchanged from 0000936395-16-000083:mdna:215]

[0000936395-16-000104:mdna:300]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-16-000104:mdna:301]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 20 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of April 30, 2016, total unrecognized compensation expense was $85.1 million: (i) $1.2 million, which related to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years; and (ii) $83.9 million which related to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-16-000104:mdna:302]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-16-000104:mdna:303]
[same as prior period, unchanged from 0000936395-16-000083:mdna:220]

[0000936395-16-000104:mdna:304]
[same as prior period, unchanged from 0000936395-16-000083:mdna:221]

[0000936395-16-000104:mdna:305]
For fiscal 2016, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2016. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2016 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $29.5 million of expense in the first six months of fiscal 2016 associated with our cash incentive bonus plan for fiscal 2016.

[0000936395-16-000104:mdna:306]
[same as prior period, unchanged from 0000936395-16-000083:mdna:223]

[0000936395-16-000104:mdna:307]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $20.1 million and $10.8 million in the first six months of fiscal 2016 and 2015, respectively. The charges in fiscal 2016 primarily were related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Our inventory net of allowance for excess and obsolescence was $190.9 million and $191.2 million as of April 30, 2016 and October 31, 2015, respectively.

[0000936395-16-000104:mdna:308]
[same as prior period, unchanged from 0000936395-16-000083:mdna:225]

[0000936395-16-000104:mdna:309]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $555.1 million and $550.8 million as of April 30, 2016 and October 31, 2015, respectively. Our allowance for doubtful accounts was $3.4 million and $3.0 million as of April 30, 2016 and October 31, 2015, respectively.

[0000936395-16-000104:mdna:310]
[same as prior period, unchanged from 0000936395-16-000083:mdna:227]

[0000936395-16-000104:mdna:311]
Ciena's goodwill was generated from the acquisition of Cyan during fiscal 2015 and the acquisition of the HSPC assets from TeraXion during the second quarter of fiscal 2016, and is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-16-000104:mdna:312]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of the end of second quarter of fiscal 2015, there was no goodwill balance. At the end of second quarter of fiscal 2016, the goodwill balance was $267.7 million.

[0000936395-16-000104:mdna:313]
[same as prior period, unchanged from 0000936395-16-000083:mdna:230]

[0000936395-16-000104:mdna:314]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets, in-process research and development and maintenance spares. As of April 30, 2016 and October 31, 2015, these assets totaled $488.0 million and $449.9 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-16-000104:mdna:315]
[same as prior period, unchanged from 0000936395-16-000083:mdna:232]

[0000936395-16-000104:mdna:316]
As of April 30, 2016, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-16-000104:mdna:317]
[same as prior period, unchanged from 0000936395-16-000083:mdna:234]

[0000936395-16-000104:mdna:318]
Our liability for product warranties, included in other accrued liabilities, was $56.0 million and $56.7 million as of April 30, 2016 and October 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $9.6 million and $7.7 million for the first six months of fiscal 2016 and 2015, respectively. See Note 14 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
