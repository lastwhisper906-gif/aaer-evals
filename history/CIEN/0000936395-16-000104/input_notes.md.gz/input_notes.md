# CIEN notes — 0000936395-16-000104


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-16-000104:notes:1]
ABL CREDIT FACILITY

[0000936395-16-000104:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-16-000104:notes:3]
On January 8, 2016, Ciena amended the ABL Credit Facility to, among other things:

[0000936395-16-000104:notes:4]
| • | increase the total commitment from $200 million to $250 million, of which $200 million is available for issuances of letters of credit; |

[0000936395-16-000104:notes:5]
| • | extend the maturity date from December 31, 2016 to December 31, 2020, provided an earlier maturity date would apply in the event that Ciena and its subsidiaries are unable to satisfy a minimum liquidity test 90 days prior to the maturity date of any debt equal to $100 million or greater; |

[0000936395-16-000104:notes:6]
| • | reduce the minimum aggregate amount of unrestricted cash and cash equivalents that Ciena and its domestic subsidiaries are required to maintain at all times from $150 million to $100 million; and |

[0000936395-16-000104:notes:7]
| • | reduce the interest rate by 0.25% on borrowings to either (a) LIBOR plus a margin ranging from 1.25% to 1.75% (instead of the previous 1.50% to 2.0%) or (b) a base rate plus a margin ranging from 0.25% to 0.75% (instead of the previous 0.50% to 1.0%), in each case with the actual margin determined according to the Ciena’s utilization of the facility. |

[0000936395-16-000104:notes:8]
As of April 30, 2016, letters of credit totaling $66.7 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2016.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-16-000104:notes:9]
[same as prior period, unchanged from 0000936395-16-000083:notes:9]

[0000936395-16-000104:notes:10]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 21 below.

[0000936395-16-000104:notes:11]
[same as prior period, unchanged from 0000936395-16-000083:notes:11]


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-16-000104:notes:12]
[same as prior period, unchanged from 0000936395-16-000083:notes:12]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-16-000104:notes:13]
[same as prior period, unchanged from 0000936395-16-000083:notes:13]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-16-000104:notes:14]
[same as prior period, unchanged from 0000936395-16-000083:notes:14]

[0000936395-16-000104:notes:15]
[same as prior period, unchanged from 0000936395-16-000083:notes:15]

[0000936395-16-000104:notes:16]
|  | April 30, 2016 |  | October 31, 2015 |
| Prepaid VAT and other taxes | $ | 85,479 |  |  | $ | 74,754 |  |
| Product demonstration equipment, net | 49,626 |  |  | 41,611 |  |
| Deferred deployment expense | 23,834 |  |  | 26,193 |  |
| Prepaid expenses | 25,749 |  |  | 25,074 |  |
| Financing receivable | 20,016 |  |  | 19,869 |  |
| Other non-trade receivables | 9,043 |  |  | 8,588 |  |
| Derivative assets | 1,173 |  |  | 89 |  |
|  | $ | 214,920 |  |  | $ | 196,178 |  |

[0000936395-16-000104:notes:17]
Depreciation of product demonstration equipment was $5.2 million and $4.8 million for the first six months of fiscal 2016 and 2015, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-16-000104:notes:18]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-16-000104:notes:19]
Term Loan due 2021

[0000936395-16-000104:notes:20]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the "Term Loan Credit Agreement"), dated July 15, 2014. The Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% senior convertible notes due June 15, 2017.

[0000936395-16-000104:notes:21]
The 2021 Term Loan will, among other things:

[0000936395-16-000104:notes:22]
| • | mature on April 25, 2021; |

[0000936395-16-000104:notes:23]
| • | amortize in equal quarterly installments in aggregate amounts of $0.6 million (equal to 0.25% of the original principal amount), with the balance payable at maturity; |

[0000936395-16-000104:notes:24]
| • | be subject to mandatory prepayment on the same basis as Ciena’s existing 2019 Term Loan under the Term Loan Credit Agreement; |

[0000936395-16-000104:notes:25]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus a margin ranging from 3.25% to 3.50%, or (b) a base rate (subject to a floor of 1.75%) plus a margin ranging from 2.25% to 2.50%, in each case, with the actual margin determined according to Ciena’s total net leverage ratio; |

[0000936395-16-000104:notes:26]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2021 Term Loan with proceeds of certain indebtedness prior to October 25, 2016 shall require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and |

[0000936395-16-000104:notes:27]
| • | except as described above or otherwise set forth in the Incremental Term Loan Credit Agreement, have identical terms as the existing 2019 Term Loan under the Term Loan Credit Agreement. |

[0000936395-16-000104:notes:28]
Except as amended by the Incremental Term Loan Credit Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-16-000104:notes:29]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of April 30, 2016 (in thousands):

[0000936395-16-000104:notes:30]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 250,000 |  |  | $ | 1,247 |  |  | $ | 248,753 |  |

[0000936395-16-000104:notes:31]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):

[0000936395-16-000104:notes:32]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,753 |  |  | $ | 250,938 |  |

[0000936395-16-000104:notes:33]
| (1) | Includes unamortized bond discount. |

[0000936395-16-000104:notes:34]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000104:notes:35]
Term Loan due 2019

[0000936395-16-000104:notes:36]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):

[0000936395-16-000104:notes:37]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 245,625 |  |  | $ | 929 |  |  | $ | 244,696 |  |

[0000936395-16-000104:notes:38]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

[0000936395-16-000104:notes:39]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,696 |  |  | $ | 245,011 |  |

[0000936395-16-000104:notes:40]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000104:notes:41]
Outstanding Convertible Notes Payable

[0000936395-16-000104:notes:42]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for a cash purchase price slightly below par.

[0000936395-16-000104:notes:43]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of April 30, 2016:

[0000936395-16-000104:notes:44]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 199,400 |  |  | $ | 12,446 |  |  | $ | 186,954 |  |  | $ | 43,131 |  |

[0000936395-16-000104:notes:45]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes:

[0000936395-16-000104:notes:46]
|  |  | April 30, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 479,985 |  |  | $ | 471,585 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 395,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 186,954 |  |  | 224,766 |  |
|  |  | $ | 1,016,939 |  |  | $ | 1,091,414 |  |

[0000936395-16-000104:notes:47]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000104:notes:48]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-16-000104:notes:49]
[same as prior period, unchanged from 0000936395-16-000083:notes:34]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-16-000104:notes:50]
BUSINESS COMBINATIONS

[0000936395-16-000104:notes:51]
On February 1, 2016, Ciena, through a Canadian subsidiary, acquired certain high-speed photonics components ("HSPC") assets of TeraXion Inc. ("TeraXion") and its wholly-owned subsidiary for approximately $32 million in cash. The assets purchased include TeraXion’s high-speed indium phosphide and silicon photonics technologies as well as the underlying intellectual property. These technologies support development of Ciena's WaveLogic coherent optical chipsets. This transaction has been accounted for as the acquisition of a business.

[0000936395-16-000104:notes:52]
The following table summarizes the final purchase price allocation related to the acquisition of the HSPC assets based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-16-000104:notes:53]
|  | Amount |
| Inventory | $ | 119 |  |
| Fixed assets | 1,381 |  |
| Developed technology | 16,468 |  |
| In-process technology | 3,949 |  |
| Goodwill | 10,083 |  |
| Total purchase consideration | $ | 32,000 |  |

[0000936395-16-000104:notes:54]
Developed technology represents purchased technology that had reached technological feasibility and for which TeraXion had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-16-000104:notes:55]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-16-000104:notes:56]
The goodwill generated from the acquisition of the HSPC assets was primarily related to expected synergies and has been allocated to the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-16-000104:notes:57]
Pro forma disclosures have not been included due to immateriality.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-16-000104:notes:58]
[same as prior period, unchanged from 0000936395-16-000083:notes:35]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-16-000104:notes:59]
COMMITMENTS AND CONTINGENCIES

[0000936395-16-000104:notes:60]
Foreign Tax Contingencies

[0000936395-16-000104:notes:61]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-16-000104:notes:62]
Litigation

[0000936395-16-000104:notes:63]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:

[0000936395-16-000104:notes:64]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

[0000936395-16-000104:notes:65]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

[0000936395-16-000104:notes:66]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

[0000936395-16-000104:notes:67]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

[0000936395-16-000104:notes:68]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

[0000936395-16-000104:notes:69]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss.  In response, plaintiffs filed a motion for leave to amend their complaint. The defendants opposed the motion and it is set for hearing on June 14, 2016.

[0000936395-16-000104:notes:70]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015.  On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court.  Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-16-000104:notes:71]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-16-000104:notes:72]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-16-000104:notes:73]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-16-000104:notes:74]
[same as prior period, unchanged from 0000936395-16-000083:notes:51]

[0000936395-16-000104:notes:75]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the six months ending April 30, 2016:

[0000936395-16-000104:notes:76]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 256 |  |  | 760 |  |  | (1,478 | ) |  | 4,693 |  |  | 4,231 |  |
| Amounts reclassified from AOCI | — |  |  | 704 |  |  | 1,572 |  |  | — |  |  | 2,276 |  |
| Balance at April 30, 2016 | $ | 178 |  |  | $ | 1,196 |  |  | $ | (5,428 | ) |  | $ | (11,565 | ) |  | $ | (15,619 | ) |

[0000936395-16-000104:notes:77]
The following table summarizes the changes in AOCI for the six months ending April 30, 2015:

[0000936395-16-000104:notes:78]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income (loss) before reclassifications | (24 | ) |  | (4,233 | ) |  | (2,218 | ) |  | (3,411 | ) |  | (9,886 | ) |
| Amounts reclassified from AOCI | — |  |  | 2,761 |  |  | — |  |  | — |  |  | 2,761 |  |
| Balance at April 30, 2015 | $ | 47 |  |  | $ | (1,645 | ) |  | $ | (4,301 | ) |  | $ | (15,894 | ) |  | $ | (21,793 | ) |

[0000936395-16-000104:notes:79]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development on the Condensed Consolidated Statements of Operations. All amounts reclassified from accumulated other comprehensive income related to settlement (gains) losses on forward starting interest swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-16-000104:notes:80]
[same as prior period, unchanged from 0000936395-16-000083:notes:57]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-16-000104:notes:81]
[same as prior period, unchanged from 0000936395-16-000083:notes:58]

[0000936395-16-000104:notes:82]
|  | April 30, 2016 |  | October 31, 2015 |
| Products | $ | 49,191 |  |  | $ | 66,527 |  |
| Services | 137,841 |  |  | 122,546 |  |
|  | 187,032 |  |  | 189,073 |  |
| Less current portion | (116,799 | ) |  | (126,111 | ) |
| Long-term deferred revenue | $ | 70,233 |  |  | $ | 62,962 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-16-000104:notes:83]
[same as prior period, unchanged from 0000936395-16-000083:notes:60]

[0000936395-16-000104:notes:84]
[same as prior period, unchanged from 0000936395-16-000083:notes:61]

[0000936395-16-000104:notes:85]
As of April 30, 2016 and October 31, 2015, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $32.4 million and $68.1 million as of April 30, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-16-000104:notes:86]
During the first six months of fiscal 2016 and fiscal 2015, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $112.5 million and $146.5 million as of April 30, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-16-000104:notes:87]
[same as prior period, unchanged from 0000936395-16-000083:notes:64]

[0000936395-16-000104:notes:88]
During fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swaps") that fix the interest rate under the 2019 Term Loan (as defined in Note 17) at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of April 30, 2016 and October 31, 2015 was $245.6 million and $246.9 million, respectively.

[0000936395-16-000104:notes:89]
In May 2016, Ciena entered into interest rate swaps that fix the total interest rate under the 2021 Term Loan (as defined in Note 17) at 4.62% to 4.87%, depending on the applicable margin, for the period commencing on June 20, 2016 through June 22, 2020.

[0000936395-16-000104:notes:90]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the 2019 Term Loan and 2021 Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-16-000104:notes:91]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 5 and Note 7 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-16-000104:notes:92]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. Ciena also has interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-16-000104:notes:93]
[same as prior period, unchanged from 0000936395-16-000083:notes:69]

[0000936395-16-000104:notes:94]
[same as prior period, unchanged from 0000936395-16-000083:notes:70]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-16-000104:notes:95]
[same as prior period, unchanged from 0000936395-16-000083:notes:71]

[0000936395-16-000104:notes:96]
[same as prior period, unchanged from 0000936395-16-000083:notes:72]

[0000936395-16-000104:notes:97]
[same as prior period, unchanged from 0000936395-16-000083:notes:73]

[0000936395-16-000104:notes:98]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of April 30, 2016, approximately 3.9 million shares remained available for issuance under the 2008 Plan.

[0000936395-16-000104:notes:99]
[same as prior period, unchanged from 0000936395-16-000083:notes:75]

[0000936395-16-000104:notes:100]
[same as prior period, unchanged from 0000936395-16-000083:notes:76]

[0000936395-16-000104:notes:101]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2015 | 2,293 |  |  | $ | 24.45 |  |
| Exercised | (234 | ) |  | 9.73 |  |
| Canceled | (276 | ) |  | 39.06 |  |
| Balance at April 30, 2016 | 1,783 |  |  | $ | 24.13 |  |

[0000936395-16-000104:notes:102]
The total intrinsic value of options exercised during the first six months of fiscal 2016 and fiscal 2015 was $2.5 million and $0.8 million, respectively. Ciena did not grant any stock options during the first six months of fiscal 2016 or fiscal 2015.

[0000936395-16-000104:notes:103]
The following table summarizes information with respect to stock options outstanding at April 30, 2016, based on Ciena’s closing stock price on the last trading day of Ciena’s second fiscal quarter of 2016 (shares and intrinsic value in thousands):

[0000936395-16-000104:notes:104]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | April 30, 2016 |  | April 30, 2016 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.05 |  |  | — |  |  | $ | 11.16 |  |  | 297 |  |  | 2.95 |  | $ | 6.88 |  |  | $ | 2,958 |  |  | 295 |  |  | 2.91 |  | $ | 6.86 |  |  | $ | 2,947 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 483 |  |  | 5.54 |  | 13.49 |  |  | 1,615 |  |  | 438 |  |  | 5.39 |  | 13.38 |  |  | 1,514 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.52 |  |  | 410 |  |  | 1.72 |  | 26.60 |  |  | — |  |  | 386 |  |  | 1.32 |  | 27.08 |  |  | — |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 339 |  |  | 2.93 |  | 35.14 |  |  | — |  |  | 321 |  |  | 2.72 |  | 35.12 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 254 |  |  | 5.31 |  | 45.82 |  |  | — |  |  | 204 |  |  | 4.87 |  | 45.84 |  |  | — |  |
| $ | 0.05 |  |  | — |  |  | $ | 55.63 |  |  | 1,783 |  |  | 3.70 |  | $ | 24.13 |  |  | $ | 4,573 |  |  | 1,644 |  |  | 3.40 |  | $ | 23.70 |  |  | $ | 4,461 |  |

[0000936395-16-000104:notes:105]
[same as prior period, unchanged from 0000936395-16-000083:notes:81]

[0000936395-16-000104:notes:106]
[same as prior period, unchanged from 0000936395-16-000083:notes:82]

[0000936395-16-000104:notes:107]
[same as prior period, unchanged from 0000936395-16-000083:notes:83]

[0000936395-16-000104:notes:108]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2008 Plan permits the Company to grant service-based stock awards with shorter vesting periods to certain recipients, including non-employee directors and Ciena's Executive Chairman. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-16-000104:notes:109]
[same as prior period, unchanged from 0000936395-16-000083:notes:85]

[0000936395-16-000104:notes:110]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2015 | 4,886 |  |  | $ | 20.02 |  |  | $ | 117,951 |  |
| Granted | 2,055 |  |  |  |  |  |
| Vested | (1,686 | ) |  |  |  |  |
| Canceled or forfeited | (253 | ) |  |  |  |  |
| Balance at April 30, 2016 | 5,002 |  |  | $ | 19.91 |  |  | $ | 84,182 |  |

[0000936395-16-000104:notes:111]
The total fair value of restricted stock units that vested and were converted into common stock during the first six months of fiscal 2016 and fiscal 2015 was $33.0 million and $23.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first six months of fiscal 2016 and fiscal 2015 was $19.73 and $18.68 respectively.

[0000936395-16-000104:notes:112]
[same as prior period, unchanged from 0000936395-16-000083:notes:88]

[0000936395-16-000104:notes:113]
[same as prior period, unchanged from 0000936395-16-000083:notes:89]

[0000936395-16-000104:notes:114]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-16-000104:notes:115]
[same as prior period, unchanged from 0000936395-16-000083:notes:91]

[0000936395-16-000104:notes:116]
[same as prior period, unchanged from 0000936395-16-000083:notes:92]

[0000936395-16-000104:notes:117]
[same as prior period, unchanged from 0000936395-16-000083:notes:93]

[0000936395-16-000104:notes:118]
During the first six months of fiscal 2016, Ciena issued 0.5 million shares under the ESPP. At April 30, 2016, 6.5 million shares remained available for issuance under the ESPP.

[0000936395-16-000104:notes:119]
[same as prior period, unchanged from 0000936395-16-000083:notes:95]

[0000936395-16-000104:notes:120]
[same as prior period, unchanged from 0000936395-16-000083:notes:96]

[0000936395-16-000104:notes:121]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Product costs | $ | 629 |  |  | $ | 653 |  |  | $ | 1,200 |  |  | $ | 1,140 |  |
| Service costs | 693 |  |  | 574 |  |  | 1,285 |  |  | 1,093 |  |
| Share-based compensation expense included in cost of sales | 1,322 |  |  | 1,227 |  |  | 2,485 |  |  | 2,233 |  |
| Research and development | 3,791 |  |  | 2,534 |  |  | 7,219 |  |  | 4,701 |  |
| Sales and marketing | 3,923 |  |  | 3,841 |  |  | 8,658 |  |  | 7,500 |  |
| General and administrative | 4,968 |  |  | 3,723 |  |  | 10,097 |  |  | 7,642 |  |
| Acquisition and integration costs | 697 |  |  | — |  |  | 714 |  |  | — |  |
| Share-based compensation expense included in operating expense | 13,379 |  |  | 10,098 |  |  | 26,688 |  |  | 19,843 |  |
| Share-based compensation expense capitalized in inventory, net | 32 |  |  | 4 |  |  | 37 |  |  | 60 |  |
| Total share-based compensation | $ | 14,733 |  |  | $ | 11,329 |  |  | $ | 29,210 |  |  | $ | 22,136 |  |

[0000936395-16-000104:notes:122]
As of April 30, 2016, total unrecognized share-based compensation expense related was approximately $85.1 million: (i) $1.2 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years, and (ii) $83.9 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-16-000104:notes:123]
[same as prior period, unchanged from 0000936395-16-000083:notes:99]


## us-gaap:EarningsPerShareTextBlock

[0000936395-16-000104:notes:124]
[same as prior period, unchanged from 0000936395-16-000083:notes:100]

[0000936395-16-000104:notes:125]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income per common share (“Basic EPS”) and the diluted net income per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, and (iv) shares underlying Ciena’s outstanding convertible notes.

[0000936395-16-000104:notes:126]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income | $ | 13,997 |  |  | $ | 20,653 |  |  | $ | 2,451 |  |  | $ | 1,874 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | — |  |  | 1,387 |  |  | — |  |  | — |  |
| Net income used to calculate Diluted EPS | $ | 13,997 |  |  | $ | 22,040 |  |  | $ | 2,451 |  |  | $ | 1,874 |  |

[0000936395-16-000104:notes:127]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Basic weighted average shares outstanding | 137,950 |  |  | 113,555 |  |  | 137,313 |  |  | 110,578 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 939 |  |  | 1,354 |  |  | 1,380 |  |  | 1,184 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | — |  |  | 13,108 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 138,889 |  |  | 128,017 |  |  | 138,693 |  |  | 111,762 |  |

[0000936395-16-000104:notes:128]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Basic EPS | $ | 0.10 |  |  | $ | 0.18 |  |  | $ | 0.02 |  |  | $ | 0.02 |  |
| Diluted EPS | $ | 0.10 |  |  | $ | 0.17 |  |  | $ | 0.02 |  |  | $ | 0.02 |  |

[0000936395-16-000104:notes:129]
[same as prior period, unchanged from 0000936395-16-000083:notes:105]

[0000936395-16-000104:notes:130]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Shares underlying stock options and restricted stock units | 2,439 |  |  | 961 |  |  | 2,092 |  |  | 1,923 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | — |  |  | 4,346 |  |  | — |  |  | 6,772 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 12,583 |  |  | — |  |  | 12,748 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 41,576 |  |  | 31,861 |  |  | 41,394 |  |  | 48,357 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-16-000104:notes:131]
[same as prior period, unchanged from 0000936395-16-000083:notes:107]

[0000936395-16-000104:notes:132]
|  | April 30, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 749,856 |  |  | $ | — |  |  | $ | — |  |  | $ | 749,856 |  |
| U.S. government obligations | — |  |  | 315,415 |  |  | — |  |  | 315,415 |  |
| Commercial paper | — |  |  | 69,969 |  |  | — |  |  | 69,969 |  |
| Foreign currency forward contracts | — |  |  | 1,173 |  |  | — |  |  | 1,173 |  |
| Total assets measured at fair value | $ | 749,856 |  |  | $ | 386,557 |  |  | $ | — |  |  | $ | 1,136,413 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 548 |  |  | $ | — |  |  | $ | 548 |  |
| Forward starting interest rate swap | — |  |  | 5,428 |  |  | — |  |  | 5,428 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,976 |  |  | $ | — |  |  | $ | 5,976 |  |

[0000936395-16-000104:notes:133]
[same as prior period, unchanged from 0000936395-16-000083:notes:109]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-16-000104:notes:134]
[same as prior period, unchanged from 0000936395-16-000083:notes:110]

[0000936395-16-000104:notes:135]
|  | April 30, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 749,856 |  |  | $ | 64,972 |  |  | $ | — |  |  | $ | 814,828 |  |
| Short-term investments | — |  |  | 195,179 |  |  | — |  |  | 195,179 |  |
| Prepaid expenses and other | — |  |  | 1,173 |  |  | — |  |  | 1,173 |  |
| Long-term investments | — |  |  | 125,233 |  |  | — |  |  | 125,233 |  |
| Total assets measured at fair value | $ | 749,856 |  |  | $ | 386,557 |  |  | $ | — |  |  | $ | 1,136,413 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 548 |  |  | $ | — |  |  | $ | 548 |  |
| Other long-term obligations | — |  |  | 5,428 |  |  | — |  |  | 5,428 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,976 |  |  | $ | — |  |  | $ | 5,976 |  |

[0000936395-16-000104:notes:136]
[same as prior period, unchanged from 0000936395-16-000083:notes:112]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-16-000104:notes:137]
[same as prior period, unchanged from 0000936395-16-000083:notes:113]

[0000936395-16-000104:notes:138]
[same as prior period, unchanged from 0000936395-16-000083:notes:114]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-16-000104:notes:139]
[same as prior period, unchanged from 0000936395-16-000083:notes:115]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-16-000104:notes:140]
[same as prior period, unchanged from 0000936395-16-000083:notes:116]

[0000936395-16-000104:notes:141]
Ciena's goodwill was generated from the acquisition of Cyan, Inc. ("Cyan") during fiscal 2015 and the acquisition of the HSPC assets of TeraXion during the second quarter of fiscal 2016, and is primarily related to expected synergies. The following table presents the goodwill allocated to Ciena's reportable segments as of the dates indicated (in thousands):

[0000936395-16-000104:notes:142]
|  |  | Balance at October 31, 2015 |  | Acquisitions |  | Impairments |  | Translation(1) |  | Balance at April 30, 2016 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 55,006 |  |  | 10,083 |  |  | — |  |  | 1,164 |  |  | 66,253 |  |
| Total |  | $ | 256,434 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 1,164 |  |  | $ | 267,681 |  |

[0000936395-16-000104:notes:143]
(1) Represents translation on goodwill related to the acquisition of the HSPC assets by Ciena's Canadian subsidiary.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-16-000104:notes:144]
[same as prior period, unchanged from 0000936395-16-000083:notes:119]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-16-000104:notes:145]
[same as prior period, unchanged from 0000936395-16-000083:notes:120]

[0000936395-16-000104:notes:146]
[same as prior period, unchanged from 0000936395-16-000083:notes:121]

[0000936395-16-000104:notes:147]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.

[0000936395-16-000104:notes:148]
[same as prior period, unchanged from 0000936395-16-000083:notes:123]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-16-000104:notes:149]
[same as prior period, unchanged from 0000936395-16-000083:notes:124]

[0000936395-16-000104:notes:150]
[same as prior period, unchanged from 0000936395-16-000083:notes:125]

[0000936395-16-000104:notes:151]
|  | April 30, 2016 |  | October 31, 2015 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 348,584 |  |  | $ | (226,517 | ) |  | $ | 122,067 |  |  | $ | 506,647 |  |  | $ | (382,130 | ) |  | $ | 124,517 |  |
| In-process research and development | 4,405 |  |  | — |  |  | 4,405 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 6,565 |  |  | (6,182 | ) |  | 383 |  |  | 46,538 |  |  | (46,072 | ) |  | 466 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 358,648 |  |  | (300,583 | ) |  | 58,065 |  |  | 388,621 |  |  | (310,931 | ) |  | 77,690 |  |
| Total other intangible assets | $ | 718,202 |  |  | $ | (533,282 | ) |  | $ | 184,920 |  |  | $ | 941,806 |  |  | $ | (739,133 | ) |  | $ | 202,673 |  |

[0000936395-16-000104:notes:152]
In the second quarter of fiscal 2016, certain fully amortized intangible assets of approximately $246.4 million have been eliminated from gross intangible assets and accumulated amortization during the period, with no corresponding impact to the income statement. These assets were primarily technology for products no longer being sold by Ciena. The aggregate amortization expense of intangible assets was $40.5 million and $26.4 million for the first six months of fiscal 2016 and 2015, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-16-000104:notes:153]
| Period ended October 31, |  |  |
| 2016 (remaining six months) | $ | 37,853 |  |  |
| 2017 | 45,447 |  |  |
| 2018 | 22,766 |  |  |
| 2019 | 22,219 |  |  |
| 2020 | 21,192 |  |  |
| Thereafter | 31,038 |  |  |
|  | $ | 180,515 |  | (1) |

[0000936395-16-000104:notes:154]
(1)   Does not include amortization of in-process research and development, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-16-000104:notes:155]
[same as prior period, unchanged from 0000936395-16-000083:notes:129]

[0000936395-16-000104:notes:156]
[same as prior period, unchanged from 0000936395-16-000083:notes:130]

[0000936395-16-000104:notes:157]
|  | April 30, 2016 |  | October 31, 2015 |
| Raw materials | $ | 50,612 |  |  | $ | 53,082 |  |
| Work-in-process | 12,910 |  |  | 9,120 |  |
| Finished goods | 120,356 |  |  | 125,966 |  |
| Deferred cost of goods sold | 70,403 |  |  | 55,995 |  |
|  | 254,281 |  |  | 244,163 |  |
| Provision for excess and obsolescence | (63,420 | ) |  | (53,001 | ) |
|  | $ | 190,861 |  |  | $ | 191,162 |  |

[0000936395-16-000104:notes:158]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2016, Ciena recorded a provision for excess and obsolescence of $20.1 million, primarily related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-16-000104:notes:159]
[same as prior period, unchanged from 0000936395-16-000083:notes:133]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-16-000104:notes:160]
[same as prior period, unchanged from 0000936395-16-000083:notes:134]

[0000936395-16-000104:notes:161]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-16-000104:notes:162]
The following table summarizes the final legal maturities of debt investments at April 30, 2016 (in thousands):

[0000936395-16-000104:notes:163]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 195,120 |  |  | $ | 195,179 |  |
| Due in 1-2 years | 125,091 |  |  | 125,233 |  |
|  | $ | 320,211 |  |  | $ | 320,412 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-16-000104:notes:164]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-16-000104:notes:165]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-16-000104:notes:166]
|  | April 30, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 190,123 |  |  | $ | 87 |  |  | (28 | ) |  | $ | 190,182 |  |
| Included in long-term investments | 125,091 |  |  | 157 |  |  | (15 | ) |  | 125,233 |  |
|  | $ | 315,214 |  |  | $ | 244 |  |  | $ | (43 | ) |  | $ | 315,415 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 4,997 |  |  | — |  |  | — |  |  | $ | 4,997 |  |
|  | $ | 4,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,997 |  |

[0000936395-16-000104:notes:167]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,989 |  |  | — |  |  | — |  |  | $ | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-16-000104:notes:168]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-16-000104:notes:169]
[same as prior period, unchanged from 0000936395-16-000083:notes:143]

[0000936395-16-000104:notes:170]
As of April 30, 2016 and October 31, 2015, one customer accounted for 11.2% and 10.4% of Ciena's net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $3.4 million and $3.0 million as of April 30, 2016 and October 31, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-16-000104:notes:171]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-16-000104:notes:172]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.

[0000936395-16-000104:notes:173]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-16-000104:notes:174]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-16-000104:notes:175]
[same as prior period, unchanged from 0000936395-16-000083:notes:148]

[0000936395-16-000104:notes:176]
[same as prior period, unchanged from 0000936395-16-000083:notes:149]

[0000936395-16-000104:notes:177]
[same as prior period, unchanged from 0000936395-16-000083:notes:150]

[0000936395-16-000104:notes:178]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $10.4 million for the six-month period ending April 30, 2015.


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-16-000104:notes:179]
[same as prior period, unchanged from 0000936395-16-000083:notes:152]

[0000936395-16-000104:notes:180]
|  | April 30, 2016 |  | October 31, 2015 |
| Construction liability | $ | 42,337 |  |  | $ | 18,663 |  |
| Capital lease obligations | 25,070 |  |  | 13,794 |  |
| Income tax liability | 12,244 |  |  | 13,308 |  |
| Deferred tenant allowance | 9,553 |  |  | 9,807 |  |
| Straight-line rent | 6,749 |  |  | 6,237 |  |
| Forward starting interest rate swap | 5,428 |  |  | 5,522 |  |
| Other | 5,436 |  |  | 5,209 |  |
|  | $ | 106,817 |  |  | $ | 72,540 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-16-000104:notes:181]
[same as prior period, unchanged from 0000936395-16-000083:notes:154]

[0000936395-16-000104:notes:182]
[same as prior period, unchanged from 0000936395-16-000083:notes:155]

[0000936395-16-000104:notes:183]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Interest income | $ | 982 |  |  | $ | 246 |  |  | $ | 1,668 |  |  | $ | 465 |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts | (10,600 | ) |  | 14,351 |  |  | (15,213 | ) |  | 10,002 |  |
| Foreign currency exchange gain (loss) | 10,506 |  |  | (18,832 | ) |  | 6,130 |  |  | (22,485 | ) |
| Other | 79 |  |  | (1,314 | ) |  | (394 | ) |  | (1,764 | ) |
| Interest and other income (loss), net | $ | 967 |  |  | $ | (5,549 | ) |  | $ | (7,809 | ) |  | $ | (13,782 | ) |

[0000936395-16-000104:notes:184]
Ciena Corporation, as the U.S. parent entity, uses the U.S. dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first six months of fiscal 2016 and the first six months of fiscal 2015, Ciena recorded $6.1 million of foreign currency exchange rate gains and $22.5 million in foreign currency exchange rate losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first six months of fiscal 2016 and fiscal 2015, Ciena recorded losses of $15.2 million and gains of $10.0 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-16-000104:notes:185]
[same as prior period, unchanged from 0000936395-16-000083:notes:158]

[0000936395-16-000104:notes:186]
[same as prior period, unchanged from 0000936395-16-000083:notes:159]

[0000936395-16-000104:notes:187]
|  | April 30, 2016 |  | October 31, 2015 |
| Equipment, furniture and fixtures | $ | 428,985 |  |  | $ | 404,935 |  |
| Building subject to capital lease | 24,042 |  |  | 13,459 |  |
| Construction in progress subject to build-to-suit lease | 42,337 |  |  | 18,663 |  |
| Leasehold improvements | 58,963 |  |  | 49,196 |  |
|  | 554,327 |  |  | 486,253 |  |
| Accumulated depreciation and amortization | (305,678 | ) |  | (294,280 | ) |
|  | $ | 248,649 |  |  | $ | 191,973 |  |

[0000936395-16-000104:notes:188]
During fiscal 2014, Ciena entered into a lease agreement to lease an office building located in Ottawa, Canada. During fiscal 2015 and fiscal 2016, Ciena gained access to portions of the building and recorded the corresponding capital lease asset and liability.

[0000936395-16-000104:notes:189]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease, two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of April 30, 2016, there were $42.3 million in costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful life or the lease term.

[0000936395-16-000104:notes:190]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $24.8 million and $22.5 million for the first six months of fiscal 2016 and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-16-000104:notes:191]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015 and fiscal 2016, Ciena gained access to portions of an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 11 below.

[0000936395-16-000104:notes:192]
[same as prior period, unchanged from 0000936395-16-000083:notes:165]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-16-000104:notes:193]
[same as prior period, unchanged from 0000936395-16-000083:notes:166]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-16-000104:notes:194]
The table below (in thousands) sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income during the respective periods indicated:

[0000936395-16-000104:notes:195]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 132,606 |  |  | $ | 131,252 |  |  | $ | 239,588 |  |  | $ | 226,326 |  |
| Software and Software-Related Services | 192 |  |  | 806 |  |  | (3,382 | ) |  | 3,394 |  |
| Global Services | 35,692 |  |  | 35,151 |  |  | 75,688 |  |  | 67,023 |  |
| Total segment profit | 168,490 |  |  | 167,209 |  |  | 311,894 |  |  | 296,743 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 86,668 |  |  | 82,471 |  |  | 169,146 |  |  | 159,183 |  |
| General and administrative | 35,203 |  |  | 30,302 |  |  | 66,345 |  |  | 59,855 |  |
| Acquisition and integration costs | 2,285 |  |  | 1,020 |  |  | 3,584 |  |  | 1,020 |  |
| Amortization of intangible assets | 15,566 |  |  | 11,019 |  |  | 32,428 |  |  | 22,038 |  |
| Restructuring costs | 535 |  |  | (17 | ) |  | 919 |  |  | 8,068 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (11,641 | ) |  | (18,496 | ) |  | (33,127 | ) |  | (40,390 | ) |
| Less: Provision for income taxes | 2,595 |  |  | 3,265 |  |  | 3,894 |  |  | 4,315 |  |
| Consolidated net income | $ | 13,997 |  |  | $ | 20,653 |  |  | $ | 2,451 |  |  | $ | 1,874 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-16-000104:notes:196]
[same as prior period, unchanged from 0000936395-16-000083:notes:169]

[0000936395-16-000104:notes:197]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 435,173 |  |  | $ | 432,911 |  |  | $ | 824,341 |  |  | $ | 769,471 |  |
| Packet Networking | 68,582 |  |  | 53,288 |  |  | 116,779 |  |  | 108,271 |  |
| Optical Transport | 8,451 |  |  | 16,454 |  |  | 20,596 |  |  | 38,793 |  |
| Total Networking Platforms | 512,206 |  |  | 502,653 |  |  | 961,716 |  |  | 916,535 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 11,772 |  |  | 9,227 |  |  | 19,851 |  |  | 17,660 |  |
| Software-Related Services | 18,701 |  |  | 14,686 |  |  | 36,048 |  |  | 29,781 |  |
| Total Software and Software-Related Services | 30,473 |  |  | 23,913 |  |  | 55,899 |  |  | 47,441 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 57,069 |  |  | 53,085 |  |  | 113,127 |  |  | 106,986 |  |
| Installation and Deployment | 30,232 |  |  | 30,703 |  |  | 61,072 |  |  | 56,884 |  |
| Consulting and Network Design | 10,737 |  |  | 11,248 |  |  | 22,018 |  |  | 22,918 |  |
| Total Global Services | 98,038 |  |  | 95,036 |  |  | 196,217 |  |  | 186,788 |  |
| Consolidated revenue | $ | 640,717 |  |  | $ | 621,602 |  |  | $ | 1,213,832 |  |  | $ | 1,150,764 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-16-000104:notes:198]
[same as prior period, unchanged from 0000936395-16-000083:notes:171]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-16-000104:notes:199]
[same as prior period, unchanged from 0000936395-16-000083:notes:172]

[0000936395-16-000104:notes:200]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2016 (in thousands):

[0000936395-16-000104:notes:201]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 929 |  |  | — |  |  | 929 |  |
| Adjustments to previous estimates | — |  |  | (10 | ) |  | (10 | ) |
| Cash payments | (823 | ) |  | (203 | ) |  | (1,026 | ) |
| Balance at April 30, 2016 | $ | 697 |  |  | $ | 475 |  |  | $ | 1,172 |  |
| Current restructuring liabilities | $ | 697 |  |  | $ | 309 |  |  | $ | 1,006 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 166 |  |  | $ | 166 |  |

[0000936395-16-000104:notes:202]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2015 (in thousands):

[0000936395-16-000104:notes:203]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,068 |  | (a) | — |  |  | 8,068 |  |
| Cash payments | (7,518 | ) |  | (260 | ) |  | (7,778 | ) |
| Balance at April 30, 2015 | $ | 731 |  |  | $ | 874 |  |  | $ | 1,605 |  |
| Current restructuring liabilities | $ | 731 |  |  | $ | 391 |  |  | $ | 1,122 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 483 |  |  | $ | 483 |  |

[0000936395-16-000104:notes:204]
[same as prior period, unchanged from 0000936395-16-000083:notes:177]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-16-000104:notes:205]
[same as prior period, unchanged from 0000936395-16-000083:notes:178]

[0000936395-16-000104:notes:206]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2016 and April 30, 2015 was 0.4% and 1.7%, respectively.

[0000936395-16-000104:notes:207]
[same as prior period, unchanged from 0000936395-16-000083:notes:180]

[0000936395-16-000104:notes:208]
[same as prior period, unchanged from 0000936395-16-000083:notes:181]

[0000936395-16-000104:notes:209]
[same as prior period, unchanged from 0000936395-16-000083:notes:182]

[0000936395-16-000104:notes:210]
[same as prior period, unchanged from 0000936395-16-000083:notes:183]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-16-000104:notes:211]
[same as prior period, unchanged from 0000936395-16-000083:notes:184]

[0000936395-16-000104:notes:212]
|  | April 30, 2016 |  | October 31, 2015 |
| Compensation, payroll related tax and benefits | $ | 75,444 |  |  | $ | 109,466 |  |
| Warranty | 56,021 |  |  | 56,654 |  |
| Vacation | 38,285 |  |  | 34,189 |  |
| Capital lease obligations | 3,135 |  |  | 4,923 |  |
| Interest payable | 5,265 |  |  | 5,389 |  |
| Other | 104,946 |  |  | 105,662 |  |
|  | $ | 283,096 |  |  | $ | 316,283 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-16-000104:notes:213]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of April 30, 2016 (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-16-000104:notes:214]
The following is a schedule by fiscal year of future minimum lease payments under capital leases and the present value of minimum lease payments as of April 30, 2016 (in thousands):

[0000936395-16-000104:notes:215]
| Period ended October 31, |  |
| 2016 (remaining six months) | $ | 3,196 |  |
| 2017 | 3,446 |  |
| 2018 | 3,108 |  |
| 2019 | 2,896 |  |
| 2020 | 2,550 |  |
| Thereafter | 32,002 |  |
| Net minimum capital lease payments | 47,198 |  |
| Less: Amount representing interest | (18,993 | ) |
| Present value of minimum lease payments | 28,205 |  |
| Less: Current portion of present value of minimum lease payments | (3,135 | ) |
| Long-term portion of present value of minimum lease payments | $ | 25,070 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-16-000104:notes:216]
[same as prior period, unchanged from 0000936395-16-000083:notes:189]

[0000936395-16-000104:notes:217]
|  | April 30, 2016 |  | October 31, 2015 |
| Maintenance spares, net | $ | 54,441 |  |  | $ | 55,259 |  |
| Deferred debt issuance costs, net | 12,608 |  |  | 10,820 |  |
| Financing receivable | — |  |  | 10,107 |  |
| Other | 10,002 |  |  | 8,470 |  |
|  | $ | 77,051 |  |  | $ | 84,656 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-16-000104:notes:218]
[same as prior period, unchanged from 0000936395-16-000083:notes:191]

[0000936395-16-000104:notes:219]
| Six months ended |  | Beginning |  |  |  |  |  | Ending |
| April 30, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2015 |  | $ | 55,997 |  |  | 7,658 |  |  | (9,696 | ) |  | $ | 53,959 |  |
| 2016 |  | $ | 56,654 |  |  | 9,563 |  |  | (10,196 | ) |  | $ | 56,021 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-16-000104:notes:220]
[same as prior period, unchanged from 0000936395-16-000083:notes:193]

[0000936395-16-000104:notes:221]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America | $ | 395,505 |  |  | $ | 397,181 |  |  | $ | 788,209 |  |  | $ | 728,716 |  |
| EMEA | 96,175 |  |  | 102,194 |  |  | 176,897 |  |  | 213,200 |  |
| CALA | 57,896 |  |  | 47,891 |  |  | 101,706 |  |  | 90,633 |  |
| APAC | 91,141 |  |  | 74,336 |  |  | 147,020 |  |  | 118,215 |  |
| Total | $ | 640,717 |  |  | $ | 621,602 |  |  | $ | 1,213,832 |  |  | $ | 1,150,764 |  |

[0000936395-16-000104:notes:222]
[same as prior period, unchanged from 0000936395-16-000083:notes:195]

[0000936395-16-000104:notes:223]
|  | April 30, 2016 |  | October 31, 2015 |
| United States | $ | 97,327 |  |  | $ | 96,292 |  |
| Canada | 140,056 |  |  | 84,318 |  |
| Other International | 11,266 |  |  | 11,363 |  |
| Total | $ | 248,649 |  |  | $ | 191,973 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-16-000104:notes:224]
[same as prior period, unchanged from 0000936395-16-000083:notes:197]

[0000936395-16-000104:notes:225]
[same as prior period, unchanged from 0000936395-16-000083:notes:198]

[0000936395-16-000104:notes:226]
During the first quarter of fiscal 2016, in connection with the creation of a new Chief Operating Officer organization, Ciena reorganized its internal organizational structure, the management of its business, and the reporting of its operating segments. This resulted in three new operating segments: Networking Platforms, Software and Software-Related Services, and Global Services. Ciena’s previous Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form the Networking Platforms segment under a single operating segment manager. Ciena's previous Software and Services operating segment was reorganized into two separate operating segments: (i) Software and Software-Related Services, and (ii) Global Services. Ciena's segment revenue and segment profit for fiscal 2015 have been restated to reflect the new operating segments adopted in fiscal 2016. The following describes each of the newly reorganized operating segments:

[0000936395-16-000104:notes:227]
[same as prior period, unchanged from 0000936395-16-000083:notes:200]

[0000936395-16-000104:notes:228]
[same as prior period, unchanged from 0000936395-16-000083:notes:201]

[0000936395-16-000104:notes:229]
[same as prior period, unchanged from 0000936395-16-000083:notes:202]

[0000936395-16-000104:notes:230]
| ◦ | Optical Transport — includes the 4200 Advanced Services Platform, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. Ciena's Optical Transport products have either been previously discontinued, or are expected to be discontinued during fiscal 2016, reflecting network operators' transition toward next-generation converged network architectures. |

[0000936395-16-000104:notes:231]
[same as prior period, unchanged from 0000936395-16-000083:notes:204]

[0000936395-16-000104:notes:232]
[same as prior period, unchanged from 0000936395-16-000083:notes:205]

[0000936395-16-000104:notes:233]
[same as prior period, unchanged from 0000936395-16-000083:notes:206]

[0000936395-16-000104:notes:234]
[same as prior period, unchanged from 0000936395-16-000083:notes:207]

[0000936395-16-000104:notes:235]
[same as prior period, unchanged from 0000936395-16-000083:notes:208]

[0000936395-16-000104:notes:236]
[same as prior period, unchanged from 0000936395-16-000083:notes:209]

[0000936395-16-000104:notes:237]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2016, equipment, building, furniture and fixtures, net totaling $248.6 million primarily supported asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supported Ciena's unallocated selling and general and administrative activities. As of April 30, 2016, $100.7 million of Ciena's intangible assets, net were assigned to Ciena's Networking Platforms segment and $84.2 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of April 30, 2016, all of the maintenance spares, net, totaling $54.4 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-16-000104:notes:238]
[same as prior period, unchanged from 0000936395-16-000083:notes:211]

[0000936395-16-000104:notes:239]
[same as prior period, unchanged from 0000936395-16-000083:notes:212]

[0000936395-16-000104:notes:240]
[same as prior period, unchanged from 0000936395-16-000083:notes:213]

[0000936395-16-000104:notes:241]
[same as prior period, unchanged from 0000936395-16-000083:notes:214]

[0000936395-16-000104:notes:242]
[same as prior period, unchanged from 0000936395-16-000083:notes:215]

[0000936395-16-000104:notes:243]
North America includes $367.1 million and $367.6 million of United States revenue for fiscal quarters ended April 30, 2016 and 2015, respectively. For the six months ended April 30, 2016 and 2015, United States revenue was $732.3 million and $665.3 million, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-16-000104:notes:244]
[same as prior period, unchanged from 0000936395-16-000083:notes:217]

[0000936395-16-000104:notes:245]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal quarters ended April 30, 2016 and 2015 with  total revenue of $116.0 million and $117.4 million, respectively. AT&T also accounted for greater than 10% of Ciena's revenue for the six months ended April 30, 2016 and 2015 with total revenue of $242.6 million and $234.0 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-16-000104:notes:246]
[same as prior period, unchanged from 0000936395-16-000083:notes:219]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-16-000104:notes:247]
[same as prior period, unchanged from 0000936395-16-000083:notes:220]

[0000936395-16-000104:notes:248]
[same as prior period, unchanged from 0000936395-16-000083:notes:221]

[0000936395-16-000104:notes:249]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-16-000104:notes:250]
[same as prior period, unchanged from 0000936395-16-000083:notes:223]

[0000936395-16-000104:notes:251]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-16-000104:notes:252]
[same as prior period, unchanged from 0000936395-16-000083:notes:225]

[0000936395-16-000104:notes:253]
[same as prior period, unchanged from 0000936395-16-000083:notes:226]

[0000936395-16-000104:notes:254]
[same as prior period, unchanged from 0000936395-16-000083:notes:227]

[0000936395-16-000104:notes:255]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. As of the first quarter of fiscal 2016, Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 21 below.

[0000936395-16-000104:notes:256]
[same as prior period, unchanged from 0000936395-16-000083:notes:229]

[0000936395-16-000104:notes:257]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-16-000104:notes:258]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-16-000104:notes:259]
[same as prior period, unchanged from 0000936395-16-000083:notes:232]

[0000936395-16-000104:notes:260]
[same as prior period, unchanged from 0000936395-16-000083:notes:233]

[0000936395-16-000104:notes:261]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 11 and 14 below.

[0000936395-16-000104:notes:262]
[same as prior period, unchanged from 0000936395-16-000083:notes:235]

[0000936395-16-000104:notes:263]
[same as prior period, unchanged from 0000936395-16-000083:notes:236]

[0000936395-16-000104:notes:264]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, the full value of the asset will be charged to expense.

[0000936395-16-000104:notes:265]
[same as prior period, unchanged from 0000936395-16-000083:notes:237]

[0000936395-16-000104:notes:266]
[same as prior period, unchanged from 0000936395-16-000083:notes:238]

[0000936395-16-000104:notes:267]
[same as prior period, unchanged from 0000936395-16-000083:notes:239]

[0000936395-16-000104:notes:268]
[same as prior period, unchanged from 0000936395-16-000083:notes:240]

[0000936395-16-000104:notes:269]
[same as prior period, unchanged from 0000936395-16-000083:notes:241]

[0000936395-16-000104:notes:270]
[same as prior period, unchanged from 0000936395-16-000083:notes:242]

[0000936395-16-000104:notes:271]
[same as prior period, unchanged from 0000936395-16-000083:notes:243]

[0000936395-16-000104:notes:272]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

[0000936395-16-000104:notes:273]
[same as prior period, unchanged from 0000936395-16-000083:notes:245]

[0000936395-16-000104:notes:274]
[same as prior period, unchanged from 0000936395-16-000083:notes:246]

[0000936395-16-000104:notes:275]
[same as prior period, unchanged from 0000936395-16-000083:notes:247]

[0000936395-16-000104:notes:276]
[same as prior period, unchanged from 0000936395-16-000083:notes:248]

[0000936395-16-000104:notes:277]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 20 below.

[0000936395-16-000104:notes:278]
[same as prior period, unchanged from 0000936395-16-000083:notes:250]

[0000936395-16-000104:notes:279]
Loss Contingencies

[0000936395-16-000104:notes:280]
[same as prior period, unchanged from 0000936395-16-000083:notes:252]

[0000936395-16-000104:notes:281]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loans, see Note 17 below.

[0000936395-16-000104:notes:282]
[same as prior period, unchanged from 0000936395-16-000083:notes:254]

[0000936395-16-000104:notes:283]
[same as prior period, unchanged from 0000936395-16-000083:notes:255]

[0000936395-16-000104:notes:284]
[same as prior period, unchanged from 0000936395-16-000083:notes:256]

[0000936395-16-000104:notes:285]
[same as prior period, unchanged from 0000936395-16-000083:notes:257]

[0000936395-16-000104:notes:286]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-16-000104:notes:287]
[same as prior period, unchanged from 0000936395-16-000083:notes:259]

[0000936395-16-000104:notes:288]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 4 below.

[0000936395-16-000104:notes:289]
[same as prior period, unchanged from 0000936395-16-000083:notes:261]

[0000936395-16-000104:notes:290]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 5 below.

[0000936395-16-000104:notes:291]
[same as prior period, unchanged from 0000936395-16-000083:notes:263]

[0000936395-16-000104:notes:292]
See Notes 7 and 15 below.

[0000936395-16-000104:notes:293]
[same as prior period, unchanged from 0000936395-16-000083:notes:265]

[0000936395-16-000104:notes:294]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 19 below.

[0000936395-16-000104:notes:295]
[same as prior period, unchanged from 0000936395-16-000083:notes:267]

[0000936395-16-000104:notes:296]
[same as prior period, unchanged from 0000936395-16-000083:notes:268]

[0000936395-16-000104:notes:297]
[same as prior period, unchanged from 0000936395-16-000083:notes:269]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-16-000104:notes:298]
[same as prior period, unchanged from 0000936395-16-000083:notes:272]

[0000936395-16-000104:notes:299]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 17 below), term loans (described in Note 17 below) and ABL Credit Facility (described in Note 18 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $2.1 million and $2.5 million during the first six months of fiscal 2016 and 2015, respectively.

[0000936395-16-000104:notes:300]
[same as prior period, unchanged from 0000936395-16-000083:notes:274]
