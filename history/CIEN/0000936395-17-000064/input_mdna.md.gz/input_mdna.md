# CIEN MD&A — 0000936395-17-000064


## mdna

[0000936395-17-000064:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-17-000064:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-17-000064:mdna:3]
Overview

[0000936395-17-000064:mdna:4]
We are a network strategy and technology company, providing solutions that enable a wide range of network operators to deploy and manage next-generation communication architectures that deliver a broad array of services. We provide network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data, and voice traffic on communications networks. Our high-capacity hardware and network management and control software solutions enable open, programmable networks that enhance automation, reduce network complexity and support changing service requirements. Our solutions create business and operational value for our customers by enabling them to introduce new revenue-generating services and reduce network costs.

[0000936395-17-000064:mdna:5]
Our solutions include a diverse set of Networking Platform products, which are used by a broad range of network operator customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which can be applied from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware systems and components, we offer network management and domain control software platforms, along with advanced applications software, designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of services that help our customers design, optimize, integrate, deploy, manage and maintain their networks.

[0000936395-17-000064:mdna:6]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC’s website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-17-000064:mdna:7]
Market Opportunity

[0000936395-17-000064:mdna:8]
The markets in which we sell our communications networking solutions have seen significant changes in recent years, including rapid growth in bandwidth demand, proliferation of cloud-based services and heightened end-user service demands. We have also seen the impact of Web-scale network operators and their services on service provider architectures. These conditions have placed significant demands on networks, challenged the business models of network operators, and altered the overall competitive landscape of network operators. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services, while managing the costs of their networks and seeking to ensure a profitable business model.  We believe that these dynamics, and the need to adapt to rapidly changing business and network demands, will cause network operators to leverage increased software-based network control and programmability, and that network operators will adopt or evolve their infrastructures to be more open, programmable and automated.

[0000936395-17-000064:mdna:9]
While drivers of bandwidth growth and network evolution remain strong, our customers are under constant pressure to constrain their capital expenditure budgets and cannot grow their network spending at the rate of bandwidth growth.  As a result, as we innovate and introduce new and more robust solutions that increase capacity or features, there is a market expectation of solutions that are more cost-effective than existing or competing solutions. The combination of this regular technology-driven price compression in our industry and ongoing customer efforts to manage network costs can impact growth rates in our markets, and requires that we increase our volume of product shipments to grow revenue. During fiscal 2017, we saw slower market growth rates in a number of our geographies. Notwithstanding these market dynamics, we grew annual revenue and benefited meaningfully from our continued efforts to diversify our business and to take market share from competitors. Specifically, we continued to diversify our customer base to include additional customer segments, such as Web-scale providers and data center operators and enterprise customers, which contributed to our growth in North America during fiscal 2017. We also benefited from geographic diversification and growth of our business in Asia-Pacific during fiscal 2017,

[0000936395-17-000064:mdna:10]
including sales to additional service provider customers in India. We believe that continued diversification of our business and share capture are important parts of our strategy and necessary for continued revenue growth.

[0000936395-17-000064:mdna:11]
Our strategy to capitalize on these market dynamics and drive the profitable growth of our business includes the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-17-000064:mdna:12]
Competitive Landscape

[0000936395-17-000064:mdna:13]
The markets in which we compete are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to gain or retain market share. The markets for our solutions are both highly competitive and fragmented, as we regularly compete with number of large, multi-national vendors with greater financial, operational and marketing resources, and significantly broader product offerings. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, higher-capacity, higher-speed network solutions with improved reach, spectral efficiency, automation, power consumption and cost per bit. We expect competition in our industry to continue to broaden and to remain challenging and dynamic. As we expand our Packet Networking solutions and our Waveserver DCI platform, our solutions have become increasingly competitive with IP router vendors, data center switch providers, and other IT suppliers or integrators. Similarly, as we seek increased customer adoption of our Blue Planet software platform, we expect to compete more directly with additional software vendors and information technology vendors or integrators of these solutions.

[0000936395-17-000064:mdna:14]
Network operators are pursuing a variety of “consumption models,” or approaches to the design and procurement of their network infrastructure. While broader adoption of procurement models that emphasize disaggregation of hardware and software remains uncertain, we expect that a diversity of consumption models will require us and other system vendors to broaden our existing offering and commercial models over time. We may face competition from component vendors, including those in our supply chain, that develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware. Further, some of our competitors, both large and small, are not vertically integrated in their packet optical supply chain, and sell solutions that rely upon third-party coherent modem technology from merchant modem providers. We may compete with these providers as we pursue merchant modem sales opportunities. We have entered into global distribution relationships to sell our WaveLogic coherent optical technology into this market through Lumentum, NeoPhotonics and Oclaro. Each has the unrestricted ability to sell such optical modules to end users, including our customers, our competitors, and other vendors or network operators that plan to build or use “white box” hardware. Accordingly, we may ultimately compete with these partners in the marketplace. In connection with consumption models involving greater disaggregation, the continued use of such third-party modem technology and/or the availability of such technology in the market may increase overall pricing pressure in this space and may negatively impact our ability to derive higher gross margins for Converged Packet Optical solutions.

[0000936395-17-000064:mdna:15]
See the “Industry Background” and “Competition” sections of the description of our business in Item 1 of Part 1 of this annual report for more information related to the competitive landscape of our markets.

[0000936395-17-000064:mdna:16]
Balance Sheet Initiatives

[0000936395-17-000064:mdna:17]
Share Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions.

[0000936395-17-000064:mdna:18]
Exchange Offer for 2018 Convertible Notes to Add Cash Settlement Conversion Options. On August 2, 2017, we completed an offer to exchange our currently outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount. The New Notes give us the option, at our election, to settle conversions of the New Notes for cash, shares of our common stock, or a combination of cash and shares. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash. Accordingly, we used the treasury stock method for the New Notes in our diluted earnings per share calculation starting in the fourth quarter of fiscal 2017. Following settlement of the exchange offer, approximately $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of New Notes were outstanding. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our outstanding convertible notes.

[0000936395-17-000064:mdna:19]
Repurchase and Repayment at Maturity of 0.875% Convertible Senior Notes due June 15, 2017. During fiscal 2017, we repurchased $46.3 million of the outstanding aggregate principal amount of our 0.875% Convertible Senior Notes due June 15, 2017 (the “2017 Notes”) in private transactions. We repaid in cash the remaining $185.3 million in aggregate principal amount outstanding of the 2017 Notes at maturity on June 15, 2017.

[0000936395-17-000064:mdna:20]
Term Loan Refinancing. On January 30, 2017, we refinanced our existing term loans in the aggregate principal amount of $250 million, maturing on July 15, 2019 (the "2019 Term Loan") and $250 million, maturing on April 25, 2021 (the "2021 Term Loan") into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). The remaining balances under the 2019 Term Loan and 2021 Term Loan were refinanced and replaced by the 2022 Term Loan and the aggregate amount of borrowing was reduced. This arrangement was accounted for as a modification of debt. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to our term loan refinancing.

[0000936395-17-000064:mdna:21]
Reversal of Deferred Tax Asset Valuation Allowance

[0000936395-17-000064:mdna:22]
Our fourth quarter of fiscal 2017 and fiscal 2017 results of operations reflect a non-cash $1.1 billion deferred tax asset valuation allowance reversal. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information relating to this reversal. The value of the deferred tax assets on our balance sheet as of October 31, 2017 would decrease significantly if the U.S. corporate income tax rate is reduced, as proposed in tax reform legislation recently passed by both houses of the U.S. Congress on December 20, 2017. Consequently, if the President signs this proposed legislation into law as expected, we expect that our results of operations for the first quarter of fiscal 2018 would be materially adversely affected by a non-cash charge to reflect the reduction in value of these assets.

[0000936395-17-000064:mdna:23]
Financial Results for Fourth Quarter of Fiscal 2017 and Sequential Comparison

[0000936395-17-000064:mdna:24]
Revenue for the fourth quarter of fiscal 2017 was $744.4 million, representing a sequential increase of 2.2% from $728.7 million in the third quarter of fiscal 2017. Revenue-related details reflecting sequential changes from the third quarter of fiscal 2017 include the following:

[0000936395-17-000064:mdna:25]
| • | Product revenue for the fourth quarter of fiscal 2017 increased by $5.5 million, primarily reflecting an increase of $6.6 million in Networking Platforms partially offset by a decrease of $1.1 million in software platforms within our Software-Related Services segment. |

[0000936395-17-000064:mdna:26]
| • | Services revenue for the fourth quarter of fiscal 2017 increased by $10.2 million. |

[0000936395-17-000064:mdna:27]
| • | North America revenue for the fourth quarter of fiscal 2017 was $440.5 million, a decrease from $465.2 million in the third quarter of fiscal 2017. This primarily reflects decreases of $27.4 million in Networking Platforms and $1.0 million in Software and Software-Related Services. These decreases were partially offset by an increase of $3.7 million in Global Services. |

[0000936395-17-000064:mdna:28]
| • | Europe, Middle East and Africa ("EMEA") revenue for the fourth quarter of fiscal 2017 was $110.7 million, an increase from $96.1 million in the third quarter of fiscal 2017. This primarily reflects increases of $8.5 million in Networking Platforms and $6.5 million in Global Services. |

[0000936395-17-000064:mdna:29]
| • | Caribbean and Latin America (“CALA”) revenue for the fourth quarter of fiscal 2017 was $43.5 million, a decrease from $51.7 million in the third quarter of fiscal 2017, primarily reflecting a decrease of $9.0 million in Networking Platforms. |

[0000936395-17-000064:mdna:30]
| • | Asia Pacific (“APAC”) revenue for the fourth quarter of fiscal 2017 was $149.7 million, an increase from $115.7 million in the third quarter of fiscal 2017. This reflects an increase of $34.5 million in Networking Platforms partially offset by a decrease of $1.2 million in Global Services. |

[0000936395-17-000064:mdna:31]
| • | For the fourth quarter fiscal 2017, AT&T accounted for 16.7% and Verizon accounted for 11.0% of total revenue. AT&T accounted for 16.6% and Verizon accounted for 11.4% of total revenue for the third quarter of fiscal 2017. |

[0000936395-17-000064:mdna:32]
Gross margin for the fourth quarter of fiscal 2017 was 43.7%, a decrease from 45.0% in the third quarter of fiscal 2017. The reduced gross margin was primarily due to aggressive efforts to take market share from competitors and secure new customers and the effects of the early stages of these deployments. Our gross margin can fluctuate, particularly when viewed on a quarterly basis, as a result of a number of factors, including the additional costs we incur associated with the early stages of new network deployments that typically include a higher concentration of lower margin “common” equipment sales. Part of our strategy for fiscal 2018 is to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Accordingly, we may encounter fluctuations or reductions in quarterly gross margin during this period.

[0000936395-17-000064:mdna:33]
Operating expense was $269.9 million for the fourth quarter of fiscal 2017, a $23.8 million increase from $246.1 million in the third quarter of fiscal 2017. This reflects increases of $9.1 million in selling and marketing expense, primarily due to increased incentive sales compensation and $1.4 million in research and development expenses. Operating expense also reflects a $13.7 million significant asset impairment related to a trade receivable for a single customer in the APAC region. No revenue was recognized from this customer in the fourth quarter of fiscal 2017 and $4.8 million of the impairment was related to revenue recorded during the first nine months of fiscal 2017.

[0000936395-17-000064:mdna:34]
Income from operations for the fourth quarter of fiscal 2017 was $55.8 million, as compared to $82.0 million during the third quarter of fiscal 2017. Our net income for the fourth quarter of fiscal 2017 was $1.2 billion, or $7.32 per diluted common share which reflects a tax benefit of $1.1 billion related to the reversal of a deferred tax asset valuation allowance. This compares to a net income of $60.0 million or $0.39 per diluted common share, for the third quarter of fiscal 2017.

[0000936395-17-000064:mdna:35]
We generated $138.5 million of cash from operations during the fourth quarter of fiscal 2017. This compares with $50.6 million in cash generated from operations during the third quarter of fiscal 2017. As of October 31, 2017, we had $640.5 million in cash and cash equivalents, $279.1 million of short-term investments in U.S. treasury securities and commercial paper and $49.8 million of long-term investments in U.S. treasury securities. This compares to $559.5 million in cash and cash equivalents, $234.7 million of short-term investments in U.S. treasury securities and commercial paper, and $59.9 million of long-term investments in U.S. treasury securities at July 31, 2017.

[0000936395-17-000064:mdna:36]
As of October 31, 2017, we had 5,737 employees, a decrease from 5,780 as of July 31, 2017 and an increase from 5,555 and 5,345 at October 31, 2016 and 2015, respectively.

[0000936395-17-000064:mdna:37]
42

[0000936395-17-000064:mdna:38]
Consolidated Results of Operations

[0000936395-17-000064:mdna:39]
Operating Segments

[0000936395-17-000064:mdna:40]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-17-000064:mdna:41]
Fiscal 2017 compared to Fiscal 2016

[0000936395-17-000064:mdna:42]
Revenue

[0000936395-17-000064:mdna:43]
During fiscal 2017, approximately 17.4% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Brazilian Reais, British Pounds, and Japanese Yen. During fiscal 2017 as compared to fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars was slightly reduced by approximately $4.9 million, or 0.2%, as compared to fiscal 2016 due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000064:mdna:44]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,926,087 |  |  | 68.7 |  | $ | 1,779,932 |  |  | 68.5 |  | $ | 146,155 |  |  | 8.2 |  |
| Packet Networking | 313,089 |  |  | 11.2 |  | 252,862 |  |  | 9.7 |  | 60,227 |  |  | 23.8 |  |
| Optical Transport | 13,534 |  |  | 0.5 |  | 35,989 |  |  | 1.4 |  | (22,455 | ) |  | (62.4 | ) |
| Total Networking Platforms | 2,252,710 |  |  | 80.4 |  | 2,068,783 |  |  | 79.6 |  | 183,927 |  |  | 8.9 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 65,871 |  |  | 2.4 |  | 48,689 |  |  | 1.9 |  | 17,182 |  |  | 35.3 |  |
| Software-Related Services | 95,248 |  |  | 3.4 |  | 76,380 |  |  | 2.9 |  | 18,868 |  |  | 24.7 |  |
| Total Software and Software-Related Services | 161,119 |  |  | 5.8 |  | 125,069 |  |  | 4.8 |  | 36,050 |  |  | 28.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 227,400 |  |  | 8.1 |  | 228,982 |  |  | 8.8 |  | (1,582 | ) |  | (0.7 | ) |
| Installation and Deployment | 117,524 |  |  | 4.2 |  | 130,916 |  |  | 5.0 |  | (13,392 | ) |  | (10.2 | ) |
| Consulting and Network Design | 42,934 |  |  | 1.5 |  | 46,823 |  |  | 1.8 |  | (3,889 | ) |  | (8.3 | ) |
| Total Global Services | 387,858 |  |  | 13.8 |  | 406,721 |  |  | 15.6 |  | (18,863 | ) |  | (4.6 | ) |
| Consolidated revenue | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |  |

[0000936395-17-000064:mdna:45]
_________________________________

[0000936395-17-000064:mdna:46]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:47]
| • | Networking Platforms revenue increased, primarily reflecting product line sales increases of $146.2 million of our Converged Packet Optical products and $60.2 million of our Packet Networking products, partially offset by a product line sales decrease of $22.5 million in our Optical Transport products. |

[0000936395-17-000064:mdna:48]
| ◦ | Converged Packet Optical sales primarily reflect increases of $100.8 million of our Waveserver stackable interconnect system, $61.5 million of our 6500 Packet-Optical Platform, $34.2 million of our 5430 Reconfigurable Switching System and $6.8 million of our OTN configuration for the 5410 Reconfigurable |

[0000936395-17-000064:mdna:49]
Switching System. These increases were partially offset by sales decreases of $49.9 million of our Z-Series Packet-Optical Platform and $7.4 million of our CoreDirector® Multiservice Optical Switches.

[0000936395-17-000064:mdna:50]
| ◦ | Packet Networking sales primarily reflect increases of $38.7 million of our 3000 and 5000 families of service delivery and aggregation switches, $11.9 million in initial sales of packet networking platform independent software and $10.2 million of our 8700 Packetwave Platform. |

[0000936395-17-000064:mdna:51]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. Accordingly, commencing in fiscal 2018, sales of Optical Transport will be reflected within the Converged Packet Optical product line of our Networking Platforms segment. |

[0000936395-17-000064:mdna:52]
| • | Software and Software-Related Services revenue increased, primarily reflecting sales increases of $19.0 million in software-related services and $17.2 million of our software platforms. The increase in software-related services is primarily due to sales increases of $12.5 million of software subscription services, $4.2 million of services supporting our Blue Planet software platform and advance software applications and $1.5 million of software-enabled services. The increase in software platform sales primarily reflects increases of $9.0 million in sales of our Blue Planet software platform and advanced software applications and $6.5 million in sales of our OneControl Unified Management System. |

[0000936395-17-000064:mdna:53]
| • | Global Services revenue decreased, primarily reflecting sales decreases of $13.4 million of our installation and deployment services, $3.9 million of our consulting and network design services and $1.6 million of our maintenance support and training services. These sales decreases were primarily due to reduced activity in the North America and CALA regions as described below. |

[0000936395-17-000064:mdna:54]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional  service provider customers outside of North America, including in high-growth geographies such as India. We believe that this is an important part of our strategy, and that it is required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-17-000064:mdna:55]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,736,047 |  |  | 62.0 |  | $ | 1,689,263 |  |  | 65.0 |  | $ | 46,784 |  |  | 2.8 |  |
| EMEA | 404,099 |  |  | 14.4 |  | 393,705 |  |  | 15.1 |  | 10,394 |  |  | 2.6 |  |
| CALA | 164,308 |  |  | 5.9 |  | 195,085 |  |  | 7.5 |  | (30,777 | ) |  | (15.8 | ) |
| APAC | 497,233 |  |  | 17.7 |  | 322,520 |  |  | 12.4 |  | 174,713 |  |  | 54.2 |  |
| Total | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |  |

[0000936395-17-000064:mdna:56]
_________________________________

[0000936395-17-000064:mdna:57]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:58]
| • | North America revenue primarily reflects increases of $34.7 million within our Networking Platforms segment and $25.7 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $13.6 million within our Global Services segment. |

[0000936395-17-000064:mdna:59]
| ◦ | Networking Platforms revenue primarily reflects product line increases of $29.0 million of Packet Networking sales and $11.5 million of Converged Packet Optical sales, partially offset by a product line decrease of $5.7 million in Optical Transport sales. |

[0000936395-17-000064:mdna:60]
44

[0000936395-17-000064:mdna:61]
| ▪ | The revenue increase within Converged Packet Optical sales primarily reflects increases of $85.7 million in sales of our Waveserver stackable interconnect system, partially offset by decreases in sales of $48.2 million of our Z-Series Packet-Optical Platform, $14.8 million of our 6500 Packet-Optical Platform and $13.3 million of our 5430 Reconfigurable Switching System. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. |

[0000936395-17-000064:mdna:62]
| ▪ | The revenue increase within Packet Networking primarily reflects increases of $15.5 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $11.9 million of packet networking platform independent software. Packet Networking sales have traditionally been concentrated, with significant sales to AT&T. However, during fiscal 2017, a significant portion of the growth benefited from sales to other network operators. |

[0000936395-17-000064:mdna:63]
| ◦ | Software and Software-Related Services revenue primarily reflects sales increases of $10.7 million of our software subscription services, $5.3 million of our OneControl Unified Management System, $5.2 million of our Blue Planet software platform and $2.8 million of services supporting our Blue Planet software platform and advance software applications. |

[0000936395-17-000064:mdna:64]
| ◦ | Global Services revenue primarily reflects decreases of $9.0 million for installation and deployment activities and $5.0 million in maintenance support and training. Installation and deployment activities were impacted by the contribution of sales of our Waveserver stackable interconnect system, which does not typically include installation services. |

[0000936395-17-000064:mdna:65]
| • | EMEA revenue primarily reflects increases of $5.4 million within our Networking Platforms segment and $5.4 million within our Software and Software-Related Services segment. |

[0000936395-17-000064:mdna:66]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $9.7 million in Converged Packet Optical sales and $3.7 million in Packet Networking sales. These increases were partially offset by a decrease of $8.0 million in Optical Transport sales. The increase in Converged Packet Optical sales primarily reflects an increase of $10.8 million in sales from our Waveserver stackable interconnect system. |

[0000936395-17-000064:mdna:67]
| • | CALA revenue primarily reflects decreases of $22.1 million within our Networking Platforms segment and $8.9 million within our Global Services segment. The decrease in CALA revenue primarily relates to decreased sales to certain communications service providers in Brazil and to AT&T in Mexico. |

[0000936395-17-000064:mdna:68]
| ◦ | Networking Platforms segment revenue primarily reflects product line decreases of $20.4 million of Converged Packet Optical sales and $5.4 million in Optical Transport sales partially offset by a product line increase of $3.7 million of Packet Networking sales. The decrease in Converged Packet Optical sales primarily reflects $15.8 million in sales of our 5430 Reconfigurable Switching System and $3.4 million in sales of our 6500 Packet-Optical Platform. |

[0000936395-17-000064:mdna:69]
| ◦ | Global Services segment revenue primarily reflects reduced installation and deployment activities which reflect the decrease in sales of our Networking Platforms products as described above. |

[0000936395-17-000064:mdna:70]
| • | APAC revenue primarily reflects increases of $165.9 million within our Networking Platforms segment, $4.9 million within our Software and Software-Related Services segment and $3.9 million within our Global Services segment. Revenue contribution from India, which increased by $115.5 million in fiscal 2017, was a significant driver of our annual revenue growth. |

[0000936395-17-000064:mdna:71]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $145.4 million of Converged Packet Optical sales and $23.9 million of Packet Networking sales, partially offset by a product line decrease of $3.4 million in Optical Transport sales. |

[0000936395-17-000064:mdna:72]
| ▪ | Converged Packet Optical revenue primarily reflects an increase of $79.5 million in sales of our 6500 Packet-Optical Platform primarily due to increases in sales through our strategic relationship with Ericsson in Australia, sales to Reliance Jio Infocomm in India and sales to service providers in Japan. The revenue increase within Converged Packet Optical also reflects an increase of $64.3 million of our 5430 Reconfigurable Switching System sales primarily due to increased sales to Reliance Jio Infocomm in India. |

[0000936395-17-000064:mdna:73]
| ▪ | Packet Networking revenue primarily reflects increases of $15.9 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $8.0 million in sales of our 8700 Packetwave Platform primarily to certain communication service providers in India. |

[0000936395-17-000064:mdna:74]
45

[0000936395-17-000064:mdna:75]
In fiscal 2017 and fiscal 2016, our top ten customers contributed 55.6% and 51.1% of revenue, respectively. A sizable portion of our revenue continues to be derived from sales to large service provider customers. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting their businesses. Our reliance upon a relatively small number of customers also increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending upon sales volumes and purchasing priorities with these large customers.

[0000936395-17-000064:mdna:76]
Sales to AT&T were $448.9 million, or 16.0% of total revenue in fiscal 2017, and $479.1 million, or 18.4% of total revenue in fiscal 2016. Verizon accounted for $288.0 million or 10.3% of total revenue for fiscal 2017. Some customers, including AT&T, are pursuing network strategies that seek to utilize enhanced software programmability, management and control of networks and to deploy off-the-shelf or commoditized hardware technology, referred to as “white box” hardware, in lieu of existing solutions. These strategies may present challenges and opportunities for our business, particularly where we are an incumbent equipment vendor. No other customer accounted for greater than 10% of our revenue in fiscal 2017 or fiscal 2016.

[0000936395-17-000064:mdna:77]
As our business has diversified, we have taken a number of steps to increase the velocity of our business and improve our operating efficiency, including through inventory management and lead time reduction. As a result, the percentage of quarterly product revenue that we generate from customer orders placed during that particular quarter has increased meaningfully, as compared to our historical periods. Our increased reliance upon orders placed during a particular quarter may make it harder to predict our revenue and results of operations, and may further increase the likelihood of fluctuations in our results.

[0000936395-17-000064:mdna:78]
Cost of Goods Sold and Gross Profit

[0000936395-17-000064:mdna:79]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-17-000064:mdna:80]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-17-000064:mdna:81]
Our gross profit as a percentage of revenue, or “gross margin,” has remained relatively consistent in recent fiscal years. However, gross margin, particularly when viewed on a quarterly basis, can fluctuate due to a number of factors. Our gross margin remains highly dependent upon on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms and to secure business with new and existing customers we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Our success in taking share and winning new business can result in additional costs associated with the early stages of network deployments, including an increased concentration of lower margin “common” equipment sales and installation services, as compared to higher margin products including channel cards, software services and maintenance services. Gross margin can be impacted by technology-based price compression and the introduction  or substitution of new platforms for existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations and our revenue concentration within a particular segment, product line, geography, or customer.

[0000936395-17-000064:mdna:82]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-17-000064:mdna:83]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-17-000064:mdna:84]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,801,687 |  |  | 100.0 |  | $ | 2,600,573 |  |  | 100.0 |  | $ | 201,114 |  |  | 7.7 |
| Total cost of goods sold | 1,555,901 |  |  | 55.5 |  | 1,438,997 |  |  | 55.3 |  | 116,904 |  |  | 8.1 |
| Gross profit | $ | 1,245,786 |  |  | 44.5 |  | $ | 1,161,576 |  |  | 44.7 |  | $ | 84,210 |  |  | 7.2 |

[0000936395-17-000064:mdna:85]
_________________________________

[0000936395-17-000064:mdna:86]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:87]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,318,581 |  |  | 100.0 |  | $ | 2,117,472 |  |  | 100.0 |  | $ | 201,109 |  |  | 9.5 |
| Product cost of goods sold | 1,308,295 |  |  | 56.4 |  | 1,176,304 |  |  | 55.6 |  | 131,991 |  |  | 11.2 |
| Product gross profit | $ | 1,010,286 |  |  | 43.6 |  | $ | 941,168 |  |  | 44.4 |  | $ | 69,118 |  |  | 7.3 |

[0000936395-17-000064:mdna:88]
_________________________________

[0000936395-17-000064:mdna:89]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:90]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 483,106 |  |  | 100.0 |  | $ | 483,101 |  |  | 100.0 |  | $ | 5 |  |  | — |  |
| Service cost of goods sold | 247,606 |  |  | 51.3 |  | 262,693 |  |  | 54.4 |  | (15,087 | ) |  | (5.7 | ) |
| Service gross profit | $ | 235,500 |  |  | 48.7 |  | $ | 220,408 |  |  | 45.6 |  | $ | 15,092 |  |  | 6.8 |  |

[0000936395-17-000064:mdna:91]
_________________________________

[0000936395-17-000064:mdna:92]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:93]
| • | Gross profit as a percentage of revenue, or gross margin reflects improved services gross profit partially offset by reduced product gross profit. |

[0000936395-17-000064:mdna:94]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, decreased primarily as a result of market-based price erosion partially offset by product cost reductions and increased software platform sales. |

[0000936395-17-000064:mdna:95]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, increased, primarily due to increased sales of higher margin software subscription services and decreased sales of lower margin installation and deployment services. |

[0000936395-17-000064:mdna:96]
Operating Expense

[0000936395-17-000064:mdna:97]
Operating expense increased in fiscal 2017 from the level reported for fiscal 2016 primarily due to increased research and development initiatives, investments in information technology related to the re-engineering of company-wide enterprise resource planning platforms, and the transition costs of key facilities. In particular, the development of our new facilities and the transition of our operations in Ottawa, Canada required significant effort, time and cost. For additional information regarding this lease and the facility transitions, see Item 2 of Part I of this annual report.

[0000936395-17-000064:mdna:98]
Operating expense consists of the component elements described below.

[0000936395-17-000064:mdna:99]
Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, and testing of our products, depreciation expense and third-party consulting costs.

[0000936395-17-000064:mdna:100]
Selling and marketing expense primarily consists of salaries, incentive-based sales commissions and related employee expense (including share-based compensation expense), and sales and marketing support expense, including travel, demonstration units, trade show expense and third-party consulting costs.

[0000936395-17-000064:mdna:101]
General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense), and costs for third-party consulting and other services.

[0000936395-17-000064:mdna:102]
Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-17-000064:mdna:103]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition activity.

[0000936395-17-000064:mdna:104]
Significant asset impairments and restructuring costs primarily reflect actions we have taken to better align our workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions and significant impairment of assets.

[0000936395-17-000064:mdna:105]
During fiscal 2017, approximately 51.8% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, British Pounds, Euros, Indian Rupees and Brazilian Reais. During fiscal 2017 as compared to fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars was slightly reduced by approximately $2.1 million, or 0.2%, as compared to fiscal 2016 due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-17-000064:mdna:106]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 475,329 |  |  | 17.0 |  | $ | 451,794 |  |  | 17.4 |  | $ | 23,535 |  |  | 5.2 |  |
| Selling and marketing | 356,169 |  |  | 12.7 |  | 349,731 |  |  | 13.4 |  | 6,438 |  |  | 1.8 |  |
| General and administrative | 142,604 |  |  | 5.1 |  | 132,828 |  |  | 5.1 |  | 9,776 |  |  | 7.4 |  |
| Amortization of intangible assets | 33,029 |  |  | 1.2 |  | 61,508 |  |  | 2.4 |  | (28,479 | ) |  | (46.3 | ) |
| Acquisition and integration costs | — |  |  | — |  | 4,613 |  |  | 0.2 |  | (4,613 | ) |  | (100.0 | ) |
| Significant asset impairments and restructuring costs | 23,933 |  |  | 0.9 |  | 4,933 |  |  | 0.2 |  | 19,000 |  |  | 385.2 |  |
| Total operating expenses | $ | 1,031,064 |  |  | 36.9 |  | $ | 1,005,407 |  |  | 38.7 |  | $ | 25,657 |  |  | 2.6 |  |

[0000936395-17-000064:mdna:107]
_________________________________

[0000936395-17-000064:mdna:108]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:109]
| • | Research and development expense was adversely affected by $2.0 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $23.5 million. This increase primarily reflects increases of $17.6 million in employee and compensation costs and $9.5 million in facilities and information technology costs largely due to the facilities transitions described above. These increases were partially offset by decreases of $2.9 million in professional services and $1.1 million in prototype expense. |

[0000936395-17-000064:mdna:110]
| • | Selling and marketing expense increased by $6.4 million, primarily reflecting increases of $1.5 million in facilities and information technology costs, $1.5 million in technology and related costs, $1.4 million in employee and compensation costs and $1.1 million in travel and related costs. |

[0000936395-17-000064:mdna:111]
| • | General and administrative expense increased by $9.8 million, primarily reflecting increases of $4.5 million for employee and compensation costs, $2.9 million for professional services and legal fees and $1.2 million for facilities and information technology costs. |

[0000936395-17-000064:mdna:112]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-17-000064:mdna:113]
| • | Acquisition and integration costs incurred during fiscal 2016 reflects expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain high-speed photonics components (“HSPC”) assets of TeraXion, Inc. (“Teraxion”) and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-17-000064:mdna:114]
| • | Significant asset impairments and restructuring costs during fiscal 2017 primarily reflects a $13.7 million asset impairment related to a trade receivable for a single customer in the APAC region, $5.9 million for workforce reductions and $4.4 million for unfavorable lease commitments and relocation costs incurred in connection with our research and development center facility transitions in Ottawa, Canada. For more information about the significant asset impairment related to a trade receivable, see “Overview” above. For more information on our workforce reductions, see Note 3 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report for more information. For more information on our research and development facility transition, see Item 2 of Part I and Note 3 to our Consolidated Financial Statements included in in Item 8 of Part II of this annual report. |

[0000936395-17-000064:mdna:115]
Other items

[0000936395-17-000064:mdna:116]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-17-000064:mdna:117]
|  | Fiscal Year |  |  |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,744 | ) |  | (0.1 | ) |  | $ | (12,795 | ) |  | (0.5 | ) |  | $ | 10,051 |  |  | 78.6 |  |
| Interest expense | $ | 55,852 |  |  | 2.0 |  |  | $ | 56,656 |  |  | 2.2 |  |  | $ | (804 | ) |  | (1.4 | ) |
| Provision (benefit) for income taxes | $ | (1,105,827 | ) |  | (39.5 | ) |  | $ | 14,134 |  |  | 0.5 |  |  | $ | (1,119,961 | ) |  | (7,923.9 | ) |

[0000936395-17-000064:mdna:118]
_________________________________

[0000936395-17-000064:mdna:119]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:120]
| • | Interest and other income (loss), net primarily reflects $11.9 million of improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by $3.6 million in debt modification expenses related to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017 and the exchange offer of our New Notes in the fourth quarter of fiscal 2017. For additional information about our term loans and convertible senior notes, see Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report. |

[0000936395-17-000064:mdna:121]
| • | Interest expense decreased slightly, primarily due to a reduction in our aggregate outstanding debt due to the refinancing of our term loans during the second quarter of fiscal 2017 and the maturity of the 2017 Notes on June 15, 2017. This decrease was offset by higher interest expense related to our new facilities in Ottawa, Canada which are subject to capital lease accounting treatment. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our debt and see Note 10 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding our buildings subject to capital leases. |

[0000936395-17-000064:mdna:122]
| • | Provision (benefit) for income taxes decreased primarily due to a reversal of a deferred tax asset valuation allowance. See Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-17-000064:mdna:123]
Fiscal 2016 compared to Fiscal 2015

[0000936395-17-000064:mdna:124]
Revenue

[0000936395-17-000064:mdna:125]
Our total revenue in fiscal 2016 was slightly impacted by the strengthening of the U.S. Dollar. During fiscal 2016, as compared to fiscal 2015, the U.S. Dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Brazilian Reais, in which we have our most significant foreign currency revenue exposure. As a result, our total revenue reported in U.S. Dollars during fiscal 2016 was adversely impacted by approximately $16.7 million or 0.6% as compared to

[0000936395-17-000064:mdna:126]
fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000064:mdna:127]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,779,932 |  |  | 68.5 |  | $ | 1,661,702 |  |  | 67.9 |  | $ | 118,230 |  |  | 7.1 |  |
| Packet Networking | 252,862 |  |  | 9.7 |  | 229,223 |  |  | 9.4 |  | 23,639 |  |  | 10.3 |  |
| Optical Transport | 35,989 |  |  | 1.4 |  | 73,004 |  |  | 3.0 |  | (37,015 | ) |  | (50.7 | ) |
| Total Networking Platforms | 2,068,783 |  |  | 79.6 |  | 1,963,929 |  |  | 80.3 |  | 104,854 |  |  | 5.3 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 48,689 |  |  | 1.9 |  | 38,466 |  |  | 1.6 |  | 10,223 |  |  | 26.6 |  |
| Software-Related Services | 76,380 |  |  | 2.9 |  | 61,821 |  |  | 2.5 |  | 14,559 |  |  | 23.6 |  |
| Total Software and Software-Related Services | 125,069 |  |  | 4.8 |  | 100,287 |  |  | 4.1 |  | 24,782 |  |  | 24.7 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 228,982 |  |  | 8.8 |  | 224,079 |  |  | 9.2 |  | 4,903 |  |  | 2.2 |  |
| Installation and Deployment | 130,916 |  |  | 5.0 |  | 115,531 |  |  | 4.7 |  | 15,385 |  |  | 13.3 |  |
| Consulting and Network Design | 46,823 |  |  | 1.8 |  | 41,843 |  |  | 1.7 |  | 4,980 |  |  | 11.9 |  |
| Total Global Services | 406,721 |  |  | 15.6 |  | 381,453 |  |  | 15.6 |  | 25,268 |  |  | 6.6 |  |
| Consolidated revenue | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |  |

[0000936395-17-000064:mdna:128]
_________________________________

[0000936395-17-000064:mdna:129]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:130]
| • | Networking Platforms revenue increased, primarily reflecting product line sales increases of $118.2 million of our Converged Packet Optical products and $23.6 million of our Packet Networking products, partially offset by a decrease of $37.0 million in sales of our Optical Transport products. |

[0000936395-17-000064:mdna:131]
| ◦ | Converged Packet Optical sales primarily reflect increases of $107.7 million of our 6500 Packet-Optical Platform, $33.7 million in sales relating to the Z-Series Packet-Optical Platform, acquired from Cyan in the fourth quarter of fiscal 2015, and $8.2 million in sales of our Waveserver stackable data center interconnect system. Increased 6500 Packet-Optical Platform revenue reflects increased sales to a diverse set of customers including communications service providers, Web-scale providers and enterprise customers, partially offset by a decrease in sales to AT&T. These increases were also partially offset by decreases of $23.7 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $7.9 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-17-000064:mdna:132]
| ◦ | Packet Networking sales reflect increases of $16.2 million in sales of our 3000 and 5000 family of service delivery and aggregation switches and $9.3 million in sales of our 8700 Packetwave Platform, partially offset by a decrease of $1.4 million in sales of Ethernet packet configuration for our 5410 Service Aggregation Switch. |

[0000936395-17-000064:mdna:133]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-17-000064:mdna:134]
50

[0000936395-17-000064:mdna:135]
| • | Software and Software-Related Services revenue increased, primarily reflecting increases of $14.6 million in software-related services sales and $10.2 million in sales of our software platforms. The increase in software-related services revenue primarily reflects increased sales of software subscription services. The increase in software platform revenue reflects $6.7 million in initial sales of our Blue Planet software platform and advanced software applications and a $1.4 million increase in sales of our OneControl Unified Management System. Segment revenue also includes $2.1 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-17-000064:mdna:136]
| • | Global Services revenue increased, primarily reflecting increases of $15.4 million in sales of our installation and deployment services, $5.0 million in sales of our consulting and network design services and $4.9 million in sales of our maintenance and support services. Global Services segment revenue includes $16.1 million and $3.4 million of services revenue acquired from Cyan for fiscal 2016 and fiscal 2015, respectively. |

[0000936395-17-000064:mdna:137]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-17-000064:mdna:138]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,689,263 |  |  | 65.0 |  | $ | 1,598,328 |  |  | 65.4 |  | $ | 90,935 |  |  | 5.7 |  |
| EMEA | 393,705 |  |  | 15.1 |  | 400,294 |  |  | 16.4 |  | (6,589 | ) |  | (1.6 | ) |
| CALA | 195,085 |  |  | 7.5 |  | 201,499 |  |  | 8.2 |  | (6,414 | ) |  | (3.2 | ) |
| APAC | 322,520 |  |  | 12.4 |  | 245,548 |  |  | 10.0 |  | 76,972 |  |  | 31.3 |  |
| Total | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |  |

[0000936395-17-000064:mdna:139]
_________________________________

[0000936395-17-000064:mdna:140]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:141]
| • | North America revenue primarily reflects increases of $54.8 million within our Networking Platforms segment, $22.8 million within our Software and Software-Related Services segment and $13.3 million within our Global Services segment. Increased Networking Platforms segment revenue primarily reflects product line increases of $63.1 million of Converged Packet Optical sales and $11.0 million of Packet Networking sales, partially offset by a decrease of $19.3 million in Optical Transport sales. Converged Packet Optical sales reflect a $42.3 million increase in sales of our 6500 Packet-Optical Platform, reflecting increased sales to a diverse set of customers including communications service providers, Web-scale providers and enterprise customers, partially offset by a decrease in sales to AT&T and cable and multiservice operators. Converged Packet Optical sales also reflect an increase of $24.6 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-17-000064:mdna:142]
| • | EMEA revenue primarily reflects a decrease of $9.6 million within our Networking Platforms segment, partially offset by an increase of $3.8 million within our Global Services segment. Networking Platforms segment revenue reflects product line decreases of $10.8 million in Optical Transport sales and $1.6 million in Converged Packet Optical sales, partially offset by a product line increase of $2.8 million in Packet Networking sales. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. |

[0000936395-17-000064:mdna:143]
| • | CALA revenue primarily reflects a decrease of $11.1 million within our Networking Platforms segment, partially offset by an increase of $4.5 million within our Global Services segment. CALA revenue reflects decreased sales to certain communication service providers, primarily in Brazil, partially offset by increased sales to AT&T in Mexico. |

[0000936395-17-000064:mdna:144]
| • | APAC revenue reflects increases of $70.8 million within our Networking Platforms segment, $3.6 million within our Global Services segment and $2.5 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to certain communications service providers, particularly in India, enterprise customers, submarine network operators and sales through our strategic partnership with Ericsson. |

[0000936395-17-000064:mdna:145]
Cost of Goods Sold and Gross Profit

[0000936395-17-000064:mdna:146]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-17-000064:mdna:147]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,600,573 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 154,904 |  |  | 6.3 |
| Total cost of goods sold | 1,438,997 |  |  | 55.3 |  | 1,370,106 |  |  | 56.0 |  | 68,891 |  |  | 5.0 |
| Gross profit | $ | 1,161,576 |  |  | 44.7 |  | $ | 1,075,563 |  |  | 44.0 |  | $ | 86,013 |  |  | 8.0 |

[0000936395-17-000064:mdna:148]
_________________________________

[0000936395-17-000064:mdna:149]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:150]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,117,472 |  |  | 100.0 |  | $ | 2,002,395 |  |  | 100.0 |  | $ | 115,077 |  |  | 5.7 |
| Product cost of goods sold | 1,176,304 |  |  | 55.6 |  | 1,120,373 |  |  | 56.0 |  | 55,931 |  |  | 5.0 |
| Product gross profit | $ | 941,168 |  |  | 44.4 |  | $ | 882,022 |  |  | 44.0 |  | $ | 59,146 |  |  | 6.7 |

[0000936395-17-000064:mdna:151]
_________________________________

[0000936395-17-000064:mdna:152]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:153]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 483,101 |  |  | 100.0 |  | $ | 443,274 |  |  | 100.0 |  | $ | 39,827 |  |  | 9.0 |
| Service cost of goods sold | 262,693 |  |  | 54.4 |  | 249,733 |  |  | 56.3 |  | 12,960 |  |  | 5.2 |
| Service gross profit | $ | 220,408 |  |  | 45.6 |  | $ | 193,541 |  |  | 43.7 |  | $ | 26,867 |  |  | 13.9 |

[0000936395-17-000064:mdna:154]
_________________________________

[0000936395-17-000064:mdna:155]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:156]
| • | Gross profit as a percentage of revenue, or gross margin, increased as a result of the factors described below. |

[0000936395-17-000064:mdna:157]
| • | Gross profit on products as a percentage of product revenue, or product gross margin, increased as a result of our success in driving product cost reductions as compared to the market-based price erosion we encountered during the period, and increased software revenue. |

[0000936395-17-000064:mdna:158]
| • | Gross profit on services as a percentage of services revenue, or services gross margin, increased, primarily due to increased sales of higher margin software subscription services, reduced repair costs to support maintenance service contracts and increased sales and improved margins on consulting services. |

[0000936395-17-000064:mdna:159]
Operating expense

[0000936395-17-000064:mdna:160]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-17-000064:mdna:161]
52

[0000936395-17-000064:mdna:162]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 451,794 |  |  | 17.4 |  | $ | 414,201 |  |  | 16.9 |  | $ | 37,593 |  |  | 9.1 |  |
| Selling and marketing | 349,731 |  |  | 13.4 |  | 333,836 |  |  | 13.7 |  | 15,895 |  |  | 4.8 |  |
| General and administrative | 132,828 |  |  | 5.1 |  | 123,402 |  |  | 5.0 |  | 9,426 |  |  | 7.6 |  |
| Amortization of intangible assets | 61,508 |  | 2.4 |  | 2.4 |  | 69,511 |  |  | 2.8 |  | (8,003 | ) |  | (11.5 | ) |
| Acquisition and integration costs | 4,613 |  |  | 0.2 |  | 25,539 |  |  | 1.0 |  | (20,926 | ) |  | (81.9 | ) |
| Significant asset impairments and restructuring costs | 4,933 |  |  | 0.2 |  | 8,626 |  |  | 0.4 |  | (3,693 | ) |  | (42.8 | ) |
| Total operating expenses | $ | 1,005,407 |  |  | 38.7 |  | $ | 975,115 |  |  | 39.8 |  | $ | 30,292 |  |  | 3.1 |  |

[0000936395-17-000064:mdna:163]
_________________________________

[0000936395-17-000064:mdna:164]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:165]
| • | Research and development expense benefited by $16.4 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $37.6 million, primarily reflecting increases of $16.7 million in employee compensation and related costs, $11.0 million in facilities and information systems expense, $7.4 million in professional services and $4.0 million in depreciation expense. These increases were partially offset by a decrease of $4.8 million in prototype expense. |

[0000936395-17-000064:mdna:166]
| • | Selling and marketing expense benefited by $4.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expenses increased by $15.9 million, primarily reflecting increases of $7.2 million in employee compensation and related costs, $3.6 million in facilities and information systems expense, $3.5 million in professional services and $1.5 million in travel and related costs. These increases were partially offset by a decrease of $1.8 million in trade show and related costs. |

[0000936395-17-000064:mdna:167]
| • | General and administrative expense benefited by $1.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Brazilian Real. Including the effect of foreign exchange rates, general and administrative expense increased by $9.4 million, primarily reflecting increases of $5.0 million in employee compensation and related costs, $2.3 million in facilities and information systems expense and $1.6 million in professional services. |

[0000936395-17-000064:mdna:168]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-17-000064:mdna:169]
| • | Acquisition and integration costs reflect expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-17-000064:mdna:170]
| • | Significant asset impairments and restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-17-000064:mdna:171]
Other items

[0000936395-17-000064:mdna:172]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-17-000064:mdna:173]
|  | Fiscal Year |  |  |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (12,795 | ) |  | (0.5 | ) |  | $ | (25,505 | ) |  | (1.0 | ) |  | $ | 12,710 |  |  | 49.8 |  |
| Interest expense | $ | 56,656 |  |  | 2.2 |  |  | $ | 51,179 |  |  | 2.1 |  |  | $ | 5,477 |  |  | 10.7 |  |
| Provision for income taxes | $ | 14,134 |  |  | 0.5 |  |  | $ | 12,097 |  |  | 0.5 |  |  | $ | 2,037 |  |  | 16.8 |  |

[0000936395-17-000064:mdna:174]
_________________________________

[0000936395-17-000064:mdna:175]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:176]
| • | Interest and other income (loss), net reflects a beneficial impact, as compared to the prior period, of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. Interest and other income (loss), net also reflects an increase in investment interest income. |

[0000936395-17-000064:mdna:177]
| • | Interest expense increased, primarily due to additional outstanding indebtedness, including our $250 million 2021 Term Loan that was entered into in the second quarter of fiscal 2016, as compared to fiscal 2015. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information. |

[0000936395-17-000064:mdna:178]
| • | Provision for income taxes increased primarily due to state taxes. |

[0000936395-17-000064:mdna:179]
Segment Profit

[0000936395-17-000064:mdna:180]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-17-000064:mdna:181]
|  | Fiscal Year |  |  |
|  | 2017 |  | 2016 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 578,039 |  |  | $ | 544,744 |  |  | $ | 33,295 |  |  | 6.1 |
| Software and Software-Related Services | $ | 32,536 |  |  | $ | 7,123 |  |  | $ | 25,413 |  |  | 356.8 |
| Global Services | $ | 159,882 |  |  | $ | 157,915 |  |  | $ | 1,967 |  |  | 1.2 |

[0000936395-17-000064:mdna:182]
_________________________________

[0000936395-17-000064:mdna:183]
| * | Denotes % change from 2016 to 2017 |

[0000936395-17-000064:mdna:184]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, slightly offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs in connection with our research and development center facility transitions in Ottawa, Canada. |

[0000936395-17-000064:mdna:185]
| • | Software and Software-Related Services segment profit increased, reflects higher sales volume, as described above, and improved gross margin, partially offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our Blue Planet software platform. |

[0000936395-17-000064:mdna:186]
| • | Global Services segment profit increased, primarily due to improved gross margin, as described above, partially offset by lower sales volume. |

[0000936395-17-000064:mdna:187]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-17-000064:mdna:188]
54

[0000936395-17-000064:mdna:189]
|  | Fiscal Year |  |  |
|  | 2016 |  | 2015 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 544,744 |  |  | $ | 515,550 |  |  | $ | 29,194 |  |  | 5.7 |
| Software and Software-Related Services | $ | 7,123 |  |  | $ | 4,174 |  |  | $ | 2,949 |  |  | 70.7 |
| Global Services | $ | 157,915 |  |  | $ | 141,638 |  |  | $ | 16,277 |  |  | 11.5 |

[0000936395-17-000064:mdna:190]
_________________________________

[0000936395-17-000064:mdna:191]
| * | Denotes % change from 2015 to 2016 |

[0000936395-17-000064:mdna:192]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin, partially offset by higher research and development costs. The improved gross margin was the result of product cost reductions, including on our WaveLogic coherent optical processor for 100G and 200G optical transport, partially offset by market-based price erosion. |

[0000936395-17-000064:mdna:193]
| • | Software and Software-Related Services segment profit increased primarily reflecting higher sales volume, partially offset by higher research and development costs and reduced gross margin from increased amortization of intangibles expense. Higher research and development costs reflect the addition of expenses relating to the development of our Blue Planet software platform. |

[0000936395-17-000064:mdna:194]
| • | Global Services segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin. The improved gross margin was the result of improved efficiencies for consulting and network design services. |

[0000936395-17-000064:mdna:195]
Liquidity and Capital Resources

[0000936395-17-000064:mdna:196]
Overview. For the fiscal year ended October 31, 2017, we generated $234.9 million in cash to fund our operating needs, as our net income (adjusted for non-cash charges) of $390.6 million exceeded our working capital requirements of $155.7 million. Our net income (adjusted for non-cash charges) reflects a non-cash tax benefit of $1.1 billion related to a reversal of a deferred tax asset valuation allowance. For additional details on this reversal, see Note 20 to our Consolidated Financial Statements included in Item 8 of Part II of this report. For additional details of our cash from operations, see the discussion below entitled “Cash from Operations.”

[0000936395-17-000064:mdna:197]
Total cash, cash equivalents and investments decreased by $173.6 million during fiscal 2017. This decrease principally reflects the use of cash to:

[0000936395-17-000064:mdna:198]
•fund the repurchase of $46.3 million in aggregate principal amount outstanding of the 2017 notes;

[0000936395-17-000064:mdna:199]
•repay at maturity the remaining $185.3 million in aggregate principal amount outstanding of the 2017 Notes; and

[0000936395-17-000064:mdna:200]
| • | reduce the principal balance of our outstanding Term Loans by $93.6 million in connection with the refinancing and consolidation of our 2019 and 2021Term Loans into a new 2022 Term Loan. |

[0000936395-17-000064:mdna:201]
See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions. The decrease also reflects cash used in investing activities for capital expenditures totaling $94.6 million, and our settlement of certain foreign currency forward contracts of $2.8 million and cash used in financing activities for capital lease obligations totaling $3.6 million and payments on our term loans of $2.0 million. Proceeds from the issuance of equity under our employee stock purchase plans provided approximately $20.4 million in cash during the period. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-17-000064:mdna:202]
|  | October 31, |  | Increase |
|  | 2017 |  | 2016 |  | (decrease) |
| Cash and cash equivalents | $ | 640,513 |  |  | $ | 777,615 |  |  | $ | (137,102 | ) |
| Short-term investments in marketable debt securities | 279,133 |  |  | 275,248 |  |  | 3,885 |  |
| Long-term investments in marketable debt securities | 49,783 |  |  | 90,172 |  |  | (40,389 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 969,429 |  |  | $ | 1,143,035 |  |  | $ | (173,606 | ) |

[0000936395-17-000064:mdna:203]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash and investments, which as of October 31, 2017 totaled $1.0 billion, as well as our ABL credit facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 31, 2017, letters of credit totaling $69.6 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2017.

[0000936395-17-000064:mdna:204]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $41.6 million as of October 31, 2017. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-17-000064:mdna:205]
Intent to Cash Settle New 2018 Convertible Notes. As more fully described in Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report, following the settlement of an exchange offer on August 2, 2017, approximately $288.7 million in aggregate principal amount at maturity of Original Notes were exchanged for New Notes, which provide us with the option, at our election, to settle conversions for cash, shares of our common stock, or a combination of cash and shares. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash.

[0000936395-17-000064:mdna:206]
Share Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions.

[0000936395-17-000064:mdna:207]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase or refinance our outstanding convertible notes. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations, including the settlement of the principal amount of the New Notes in cash, through at least the next 12 months.

[0000936395-17-000064:mdna:208]
Cash from Operations

[0000936395-17-000064:mdna:209]
The following sections set forth the components of our $234.9 million of cash provided by operating activities for fiscal 2017:

[0000936395-17-000064:mdna:210]
Net income adjusted for non-cash charges

[0000936395-17-000064:mdna:211]
The following tables set forth (in thousands) our net income adjusted for non-cash charges during fiscal 2017:

[0000936395-17-000064:mdna:212]
|  | Year ended |
|  | October 31, 2017 |
| Net income | $ | 1,261,953 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 77,189 |  |
| Share-based compensation costs | 48,360 |  |
| Amortization of intangible assets | 45,713 |  |
| Deferred taxes | (1,126,732 | ) |
| Provision for doubtful accounts | 18,221 |  |
| Provision for inventory excess and obsolescence | 35,459 |  |
| Provision for warranty | 7,965 |  |
| Other | 22,417 |  |
| Net income adjusted for non-cash charges | $ | 390,545 |  |

[0000936395-17-000064:mdna:213]
Working Capital

[0000936395-17-000064:mdna:214]
Our working capital used $155.7 million of cash during fiscal 2017. The following tables set forth (in thousands) the major components of the reduction in working capital:

[0000936395-17-000064:mdna:215]
|  | Year ended |
|  | October 31, 2017 |
| Cash used in accounts receivable | $ | (66,123 | ) |
| Cash used in inventories | (91,567 | ) |
| Cash used in prepaid expenses and other | (33,834 | ) |
| Cash provided by accounts payable, accruals and other obligations | 33,897 |  |
| Cash used in deferred revenue | 1,964 |  |
| Cash used in working capital | $ | (155,663 | ) |

[0000936395-17-000064:mdna:216]
As compared to the end of fiscal 2016:

[0000936395-17-000064:mdna:217]
| • | The $66.1 million of cash used in accounts receivable during fiscal 2017 reflects higher sales volume in the fourth quarter of fiscal 2017 as compared to fiscal 2016; |

[0000936395-17-000064:mdna:218]
| • | The $91.6 million in cash used in inventory during fiscal 2017 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-17-000064:mdna:219]
| • | Cash used in prepaid expenses and other during fiscal 2017 was $33.8 million, primarily reflecting higher prepaid value added taxes and higher deferred deployment expense; |

[0000936395-17-000064:mdna:220]
| • | The $33.9 million of cash provided by accounts payable, accruals and other obligations during fiscal 2017 reflects increased inventory purchases at the end of fiscal 2017; and |

[0000936395-17-000064:mdna:221]
| • | The $2.0 million of cash provided by deferred revenue represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-17-000064:mdna:222]
Our days sales outstanding (DSOs) remained unchanged at 80 days for fiscal 2017 as compared to fiscal 2016. Our inventory turns decreased from 5.6 turns during fiscal 2016 to 4.9 turns during fiscal 2017.

[0000936395-17-000064:mdna:223]
Cash paid for interest

[0000936395-17-000064:mdna:224]
The following tables set forth (in thousands) our interest paid during fiscal 2017:

[0000936395-17-000064:mdna:225]
|  | Year ended |
|  | October 31, 2017 |
| 0.875% Convertible Senior Notes, due June 15, 2017(1) | $ | 1,824 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | 13,125 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 7,500 |  |
| Term Loan due July 15, 2019(4) | 2,599 |  |
| Term Loan due April 25, 2021(5) | 2,997 |  |
| Term Loan due January 30, 2022 (6) | 10,381 |  |
| Interest rate swaps(7) | 3,243 |  |
| ABL Credit Facility(8) | 1,636 |  |
| Capital leases | 3,930 |  |
| Total | $ | 47,235 |  |

[0000936395-17-000064:mdna:226]
| (1) | The final interest payment owing on our 0.875% Convertible Senior Notes, due June 15, 2017 was paid during the third quarter of fiscal 2017. |

[0000936395-17-000064:mdna:227]
| (2) | Interest on our outstanding 3.75% Convertible Senior Notes, due October 15, 2018, is payable on April 15 and October 15 of each year. |

[0000936395-17-000064:mdna:228]
| (3) | Interest on our outstanding 4.0% Convertible Senior Notes, due December 15, 2020, is payable on June 15 and December 15 of each year. |

[0000936395-17-000064:mdna:229]
| (4) | Interest on the 2019 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bore interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. On the first day of our second quarter of fiscal 2017, we refinanced and replaced this term loan with the 2022 Term Loan. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information. |

[0000936395-17-000064:mdna:230]
| (5) | Interest on the 2021 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2021 Term Loan bore interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. On the first day of our second quarter of fiscal 2017, we refinanced and replaced this term loan with the 2022 Term Loan. See Note 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information. |

[0000936395-17-000064:mdna:231]
| (6) | Interest on the 2022 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of fiscal 2017, the interest rate on the 2022 Term Loan was 3.74%. |

[0000936395-17-000064:mdna:232]
| (7) | Prior to the term loan refinancing, payments on our interest rate swaps were variable and effectively fixed the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. In connection with the refinancing of the 2019 and 2021 Term Loans into the 2022 Term Loan, in order to align our interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, we reduced the total outstanding value of our interest rate swaps and also entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during the periods described above will be 4.25%, 4.25% and 4.75%, respectively. |

[0000936395-17-000064:mdna:233]
| (8) | During fiscal 2017, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.6 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-17-000064:mdna:234]
For additional information about our convertible notes, term loans (including the refinancing of our 2019 and 2021 Term Loans into the 2022 Term Loan), ABL Credit Facility and interest rate swaps see Notes 14, 16 and 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-17-000064:mdna:235]
Contractual Obligations

[0000936395-17-000064:mdna:236]
The following is a summary of our future minimum payments under contractual obligations as of October 31, 2017 (in thousands):

[0000936395-17-000064:mdna:237]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 567,127 |  |  | $ | 350,000 |  |  | $ | — |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on Term Loan due January 30, 2022 (2) | 398,000 |  |  | 4,000 |  |  | 8,000 |  |  | 8,000 |  |  | 378,000 |  |
| Interest due on convertible notes | 39,375 |  |  | 20,625 |  |  | 15,000 |  |  | 3,750 |  |  | — |  |
| Interest due on Term Loan due January 30, 2022 (2) | 63,164 |  |  | 15,081 |  |  | 29,502 |  |  | 18,581 |  |  | — |  |
| Payments due under interest rate swaps (2) | 6,457 |  |  | 1,927 |  |  | 3,759 |  |  | 771 |  |  | — |  |
| Operating leases (3) | 116,306 |  |  | 25,339 |  |  | 33,100 |  |  | 23,279 |  |  | 34,588 |  |
| Purchase obligations (4) | 223,263 |  |  | 223,263 |  |  | — |  |  | — |  |  | — |  |
| Capital leases - equipment | 3,133 |  |  | 1,709 |  |  | 1,424 |  |  | — |  |  | — |  |
| Capital leases - buildings (5) | 124,009 |  |  | 7,542 |  |  | 15,250 |  |  | 15,805 |  |  | 85,412 |  |
| Other obligations | 1,860 |  |  | 1,025 |  |  | 835 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,542,694 |  |  | $ | 650,511 |  |  | $ | 106,870 |  |  | $ | 287,313 |  |  | $ | 498,000 |  |

[0000936395-17-000064:mdna:238]
_________________________________

[0000936395-17-000064:mdna:239]
58

[0000936395-17-000064:mdna:240]
| (1) | Includes the accretion of the principal amount on the 4% Senior Convertible Notes, due December 15, 2020, payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-17-000064:mdna:241]
| (2) | Interest on the 2022 Term Loan and payments due under the interest rate swaps is variable and calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 14 and 16 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report. |

[0000936395-17-000064:mdna:242]
| (3) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-17-000064:mdna:243]
| (4) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-17-000064:mdna:244]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-17-000064:mdna:245]
| (6) | As of October 31, 2017, we also had $15.4 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-17-000064:mdna:246]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2017 (in thousands):

[0000936395-17-000064:mdna:247]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 73,318 |  |  | $ | 35,747 |  |  | $ | 17,797 |  |  | $ | 12,900 |  |  | $ | 6,874 |  |

[0000936395-17-000064:mdna:248]
Off-Balance Sheet Arrangements

[0000936395-17-000064:mdna:249]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-17-000064:mdna:250]
Critical Accounting Policies and Estimates

[0000936395-17-000064:mdna:251]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-17-000064:mdna:252]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-17-000064:mdna:253]
Revenue Recognition

[0000936395-17-000064:mdna:254]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the

[0000936395-17-000064:mdna:255]
transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-17-000064:mdna:256]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-17-000064:mdna:257]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-17-000064:mdna:258]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third-party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-17-000064:mdna:259]
VSOE, when determinable, is established based on our pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. We have generally been unable to establish TPE of selling price because our go-to-market strategy differs from that of others in our markets, and the extent of customization and differentiated features and functions varies among comparable products or services from our peers. We determine BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-17-000064:mdna:260]
Our total deferred revenue for products was $49.1 million and $45.2 million as of October 31, 2017 and October 31, 2016, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $135.9 million and $137.7 million as of October 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000064:mdna:261]
Business Combinations

[0000936395-17-000064:mdna:262]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates. During fiscal 2015, we completed the Cyan acquisition for a purchase price of $335.7 million. During fiscal 2016, we completed the acquisition of TeraXion’s HSPC assets for a purchase price of $32.0 million. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-17-000064:mdna:263]
Share-Based Compensation

[0000936395-17-000064:mdna:264]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting.

[0000936395-17-000064:mdna:265]
We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-17-000064:mdna:266]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 21 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2017, total unrecognized compensation expense was $69.9 million, which consists of (i) $0.1 million that relates to unvested stock options and is expected to be recognized over a weighted-average period of 0.9 years and (ii) $69.8 million that relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.

[0000936395-17-000064:mdna:267]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

[0000936395-17-000064:mdna:268]
Reserve for Inventory Obsolescence

[0000936395-17-000064:mdna:269]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-17-000064:mdna:270]
We have experienced write downs due to changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. We recorded charges for excess and obsolete inventory of $35.5 million, $33.7 million and $26.8 million in fiscal 2017, 2016 and 2015, respectively. Our inventory net of allowance for excess and obsolescence was $267.1 million and $211.3 million as of October 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000064:mdna:271]
Allowance for Doubtful Accounts Receivable

[0000936395-17-000064:mdna:272]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations.

[0000936395-17-000064:mdna:273]
During fiscal 2017, Ciena’s allowance for doubtful accounts included a provision for a significant asset impairment of $13.7 million for a trade receivable related to a single customer in the APAC region. Our accounts receivable, net of allowance for doubtful accounts, was $622.2 million and $576.2 million as of October 31, 2017 and October 31, 2016, respectively. Our allowance for doubtful accounts was $17.6 million and $4.0 million as of October 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000064:mdna:274]
Goodwill

[0000936395-17-000064:mdna:275]
Our goodwill was generated from the acquisition of Cyan during fiscal 2015 and the acquisition of the HSPC assets from TeraXion during fiscal 2016, and is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-17-000064:mdna:276]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, which we adopted in the first quarter in fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 31, 2017 and October 31, 2016, the goodwill balance was $267.5 million and $267.0 million, respectively. There were no goodwill impairments resulting from fiscal 2017 and 2016 impairment tests and no reporting unit was determined to be at risk of failing step one of the goodwill impairment test. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-17-000064:mdna:277]
Long-lived Assets

[0000936395-17-000064:mdna:278]
Our long-lived assets include equipment, building, furniture and fixtures, finite-lived intangible assets, in-process research and development, and maintenance spares. As of October 31, 2017 and October 31, 2016 these assets totaled $456.3 million and $484.7 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-17-000064:mdna:279]
Deferred Tax Assets

[0000936395-17-000064:mdna:280]
Pursuant to Accounting Standards Codification (“ASC”) Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-17-000064:mdna:281]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence existed to support reversal of all or a portion of the valuation allowance. During the fourth quarter of fiscal 2017, this analysis consisted of the evaluation of all available positive and negative evidence, including our improved profitability in fiscal 2016 (which resulted in us having three years of cumulative income on our U.S. business in the second half of fiscal 2016) and our fiscal 2017 results of operations. We also considered third-party estimates of market growth and our internal projections of future profitability as indicated in our annual update to our operating plan for fiscal 2018 and our long-term strategic forecast which were completed during the fourth quarter of fiscal 2017. We also considered our strong performance against our annual operating plans in recent years and our ability to utilize tax planning strategies. Based on this analysis, we concluded that it was more likely than not that the majority of our U.S. deferred tax assets will be realized, and we therefore reversed most of the valuation allowance against those deferred assets. This reversal resulted in a one-time, non-cash income tax benefit of $1.125 billion and a $26.0 million adjustment to additional paid-in capital. The valuation allowance balance at October 31, 2017 was $185.9 million and the corresponding net deferred tax asset was $1.155 billion. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net

[0000936395-17-000064:mdna:282]
deferred tax asset may be subject to change in the future, depending upon our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For example, the value of the deferred tax assets on our balance sheet as of October 31, 2017 would decrease significantly if the U.S. corporate income tax rate is reduced, as proposed in tax reform legislation recently passed by both houses of the U.S. Congress on December 20, 2017. Consequently, if the President signs this proposed legislation into law as expected, we expect that our results of operations for the first quarter of fiscal 2018 would be materially adversely affected by a non-cash charge to reflect the reduction in value of these assets. For further discussion, see Note 20 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-17-000064:mdna:283]
Warranty

[0000936395-17-000064:mdna:284]
Our liability for product warranties, included in other accrued liabilities, was $42.5 million and $52.3 million as of October 31, 2017 and October 31, 2016, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties, net of adjustments for previous years provisions, was $8.0 million, $15.5 million and $17.9 million for fiscal 2017, 2016 and 2015 respectively. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. As a result of actual failure rates lower than expected, we have reduced current year provisions for warranty due to these adjustments. These adjustments for previous years provisions had the effect of reducing warranty provisions by $9.7 million, $5.3 million and $6.5 million for fiscal 2017, 2016 and 2015 respectively. See Note 13 to the Consolidated Financial Statements included in Item 8 of Part II of this annual report. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-17-000064:mdna:285]
Effects of Recent Accounting Pronouncements

[0000936395-17-000064:mdna:286]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-17-000064:mdna:287]
Unaudited Quarterly Results of Operations

[0000936395-17-000064:mdna:288]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2017. Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as “book to revenue”) has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-17-000064:mdna:289]
|  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |
|  | 2017 |  | 2017 |  | 2017 |  | 2017 |  | 2016 |  | 2016 |  | 2016 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 616,216 |  |  | $ | 610,742 |  |  | $ | 584,630 |  |  | $ | 506,993 |  |  | $ | 582,455 |  |  | $ | 553,450 |  |  | $ | 523,978 |  |  | $ | 457,589 |  |
| Services | 128,233 |  |  | 117,977 |  |  | 122,392 |  |  | 114,504 |  |  | 133,736 |  |  | 117,100 |  |  | 116,739 |  |  | 115,526 |  |
| Total Revenue | 744,449 |  |  | 728,719 |  |  | 707,022 |  |  | 621,497 |  |  | 716,191 |  |  | 670,550 |  |  | 640,717 |  |  | 573,115 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 352,992 |  |  | 341,197 |  |  | 327,295 |  |  | 286,811 |  |  | 324,663 |  |  | 299,381 |  |  | 291,778 |  |  | 260,482 |  |
| Services | 65,772 |  |  | 59,446 |  |  | 61,487 |  |  | 60,901 |  |  | 72,980 |  |  | 62,684 |  |  | 65,846 |  |  | 61,183 |  |
| Total costs of goods sold | 418,764 |  |  | 400,643 |  |  | 388,782 |  |  | 347,712 |  |  | 397,643 |  |  | 362,065 |  |  | 357,624 |  |  | 321,665 |  |
| Gross profit | 325,685 |  |  | 328,076 |  |  | 318,240 |  |  | 273,785 |  |  | 318,548 |  |  | 308,485 |  |  | 283,093 |  |  | 251,450 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 119,108 |  |  | 117,729 |  |  | 121,623 |  |  | 116,869 |  |  | 112,448 |  |  | 116,697 |  |  | 114,603 |  |  | 108,046 |  |
| Selling and marketing | 95,877 |  |  | 86,739 |  |  | 88,551 |  |  | 85,002 |  |  | 96,853 |  |  | 83,732 |  |  | 86,668 |  |  | 82,478 |  |
| General and administrative | 36,181 |  |  | 35,569 |  |  | 34,990 |  |  | 35,864 |  |  | 32,147 |  |  | 34,336 |  |  | 35,203 |  |  | 31,142 |  |
| Amortization of intangible assets | 3,661 |  |  | 3,837 |  |  | 10,980 |  |  | 14,551 |  |  | 14,551 |  |  | 14,529 |  |  | 15,566 |  |  | 16,862 |  |
| Acquisition and integration costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,029 |  |  | 2,285 |  |  | 1,299 |  |
| Significant asset impairments and restructuring costs | 15,059 |  |  | 2,203 |  |  | 4,276 |  |  | 2,395 |  |  | 2,876 |  |  | 1,138 |  |  | 535 |  |  | 384 |  |
| Total operating expenses | 269,886 |  |  | 246,077 |  |  | 260,420 |  |  | 254,681 |  |  | 258,875 |  |  | 251,461 |  |  | 254,860 |  |  | 240,211 |  |
| Income from operations | 55,799 |  |  | 81,999 |  |  | 57,820 |  |  | 19,104 |  |  | 59,673 |  |  | 57,024 |  |  | 28,233 |  |  | 11,239 |  |
| Interest and other income (loss), net | 652 |  |  | (848 | ) |  | (2,918 | ) |  | 370 |  |  | (1,339 | ) |  | (3,647 | ) |  | 967 |  |  | (8,776 | ) |
| Interest expense | (13,926 | ) |  | (13,415 | ) |  | (13,308 | ) |  | (15,203 | ) |  | (15,371 | ) |  | (15,967 | ) |  | (12,608 | ) |  | (12,710 | ) |
| Income (loss) before income taxes | 42,525 |  |  | 67,736 |  |  | 41,594 |  |  | 4,271 |  |  | 42,963 |  |  | 37,410 |  |  | 16,592 |  |  | (10,247 | ) |
| Provision (benefit) for income tax | (1,117,531 | ) |  | 7,726 |  |  | 3,568 |  |  | 410 |  |  | 6,376 |  |  | 3,864 |  |  | 2,595 |  |  | 1,299 |  |
| Net income (loss) | $ | 1,160,056 |  |  | $ | 60,010 |  |  | $ | 38,026 |  |  | $ | 3,861 |  |  | $ | 36,587 |  |  | $ | 33,546 |  |  | $ | 13,997 |  |  | $ | (11,546 | ) |
| Basic net income (loss) per common share | $ | 8.11 |  |  | $ | 0.42 |  |  | $ | 0.27 |  |  | $ | 0.03 |  |  | $ | 0.26 |  |  | $ | 0.24 |  |  | $ | 0.10 |  |  | $ | (0.08 | ) |
| Diluted net income (loss) per potential common share | $ | 7.32 |  |  | $ | 0.39 |  |  | $ | 0.25 |  |  | $ | 0.03 |  |  | $ | 0.25 |  |  | $ | 0.23 |  |  | $ | 0.10 |  |  | $ | (0.08 | ) |
| Weighted average basic common shares outstanding | 143,097 |  |  | 142,464 |  |  | 141,743 |  |  | 140,682 |  |  | 139,741 |  |  | 138,881 |  |  | 137,950 |  |  | 136,675 |  |
| Weighted average diluted potential common shares outstanding | 158,791 |  |  | 172,112 |  |  | 165,273 |  |  | 142,184 |  |  | 165,298 |  |  | 169,349 |  |  | 138,889 |  |  | 136,675 |  |

[0000936395-17-000064:mdna:290]
64
