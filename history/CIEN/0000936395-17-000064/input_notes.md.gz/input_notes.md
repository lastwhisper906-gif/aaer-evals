# CIEN notes — 0000936395-17-000064


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-17-000064:notes:1]
ABL CREDIT FACILITY

[0000936395-17-000064:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-17-000064:notes:3]
As of October 31, 2017, letters of credit totaling $69.6 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2017.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-17-000064:notes:4]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-17-000064:notes:5]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 22 below.

[0000936395-17-000064:notes:6]
Additionally, Ciena’s access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-17-000064:notes:7]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-17-000064:notes:8]
PREPAID EXPENSES AND OTHER

[0000936395-17-000064:notes:9]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-17-000064:notes:10]
|  | October 31, |
|  | 2017 |  | 2016 |
| Prepaid VAT and other taxes | $ | 91,647 |  |  | $ | 77,474 |  |
| Product demonstration equipment, net | 40,713 |  |  | 42,259 |  |
| Deferred deployment expense | 26,934 |  |  | 19,138 |  |
| Prepaid expenses | 26,114 |  |  | 25,659 |  |
| Financing receivable | 2,049 |  |  | 3,740 |  |
| Other non-trade receivables | 9,655 |  |  | 4,398 |  |
| Derivative assets | 227 |  |  | 175 |  |
|  | $ | 197,339 |  |  | $ | 172,843 |  |

[0000936395-17-000064:notes:11]
Depreciation of product demonstration equipment was $10.0 million, $10.7 million and $9.8 million for fiscal 2017, 2016 and 2015, respectively.


## cien:ScheduleOfInventoryValuationReservesTableTextBlock

[0000936395-17-000064:notes:12]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-17-000064:notes:13]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Disposals |  | Balance |
| 2015 |  | $ | 60,126 |  |  | $ | 26,846 |  |  | $ | 33,971 |  |  | $ | 53,001 |  |
| 2016 |  | $ | 53,001 |  |  | $ | 33,713 |  |  | $ | 24,211 |  |  | $ | 62,503 |  |
| 2017 |  | $ | 62,503 |  |  | $ | 35,459 |  |  | $ | 46,756 |  |  | $ | 51,206 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-17-000064:notes:14]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-17-000064:notes:15]
Outstanding Term Loan Payable

[0000936395-17-000064:notes:16]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000064:notes:17]
|  |  | October 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 392,972 |  |  | — |  |
|  |  | $ | 392,972 |  |  | $ | 486,303 |  |

[0000936395-17-000064:notes:18]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 1 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.1 million at October 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.9 million, $1.1 million and $0.8 during fiscal 2017, fiscal 2016 and fiscal 2015, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.

[0000936395-17-000064:notes:19]
2022 Term Loan

[0000936395-17-000064:notes:20]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1.0 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed. The aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, were included in the carrying value of the 2022 Term Loan.

[0000936395-17-000064:notes:21]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2022 Term Loan will, among other things:

[0000936395-17-000064:notes:22]
| • | be subject to mandatory prepayment on the same basis as under the Term Loan Credit Agreement; |

[0000936395-17-000064:notes:23]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

[0000936395-17-000064:notes:24]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment. |

[0000936395-17-000064:notes:25]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-17-000064:notes:26]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of October 31, 2017 (in thousands):

[0000936395-17-000064:notes:27]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 398,000 |  |  | $ | (1,923 | ) |  | $ | (3,105 | ) |  | $ | 392,972 |  |

[0000936395-17-000064:notes:28]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

[0000936395-17-000064:notes:29]
|  |  | October 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,972 |  | — |  | $ | 398,995 |  |

[0000936395-17-000064:notes:30]
| (1) | Includes unamortized debt discount and debt issuance costs. |

[0000936395-17-000064:notes:31]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-17-000064:notes:32]
Prior Term Loans

[0000936395-17-000064:notes:33]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000064:notes:34]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000064:notes:35]
Outstanding Convertible Notes Payable

[0000936395-17-000064:notes:36]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000064:notes:37]
|  |  | October 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | 61,071 |  |  | 347,630 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,221 |  |  | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 194,717 |  |  | 188,509 |  |
|  |  | $ | 543,009 |  |  | $ | 767,379 |  |

[0000936395-17-000064:notes:38]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 1 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.1 million at October 31, 2017 and $4.0 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable.The amortization of deferred debt issuance costs for these convertible notes are included in interest expense, and were $1.8 million, $2.7 million and $3.2 million during fiscal 2017, fiscal 2016 and fiscal 2015, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.

[0000936395-17-000064:notes:39]
Ciena has three issuances of convertible notes payable outstanding. The notes are senior unsecured obligations of Ciena and rank equally with all of Ciena’s other existing and future senior unsecured debt. The indentures governing Ciena’s notes provide for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal or interest; breach of covenants or other agreements in the indenture; defaults in or failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing, the trustee or the holders of at least 25% in aggregate principal amount of the notes may declare the principal of, accrued interest on, and premium, if any, on all the notes immediately due and payable. Under the indentures, if Ciena undergoes a “fundamental change” (as that term is defined in the indenture governing the notes to include certain change in control transactions), holders of notes will have the right, subject to certain exemptions, to require Ciena to purchase for cash any or all of their notes at a price equal to the principal amount, plus accrued interest. If the holder elects to convert his or her notes in connection with a specified fundamental change Ciena will be required, in certain circumstances, to increase the applicable conversion rate, depending on the price paid per share for Ciena common stock and the effective date of the fundamental change.

[0000936395-17-000064:notes:40]
0.875% Convertible Senior Notes due June 15, 2017

[0000936395-17-000064:notes:41]
On June 11, 2007, Ciena completed a public offering of 0.875% Convertible Senior Notes due June 15, 2017 (the “2017 Notes”), in aggregate principal amount of $500.0 million. Interest was payable on June 15 and December 15 of each year, beginning on December 15, 2007.

[0000936395-17-000064:notes:42]
At the election of the holder, the 2017 Notes could be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 26.2154 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $38.15 per share. The 2017 Notes were not redeemable by Ciena prior to maturity.

[0000936395-17-000064:notes:43]
Ciena used approximately $42.5 million of the net proceeds of this offering to purchase a call spread option on its common stock that intended to limit exposure to potential dilution from conversion of the 2017 Notes. See Note 19 below for a description of this call spread option.

[0000936395-17-000064:notes:44]
During fiscal 2016 and fiscal 2017, Ciena entered into certain private transactions to repurchase $262.5 million and $46.3 million of the 2017 Notes, respectively, in cash for purchase prices slightly below par. On July 15, 2017, the outstanding  0.875% Convertible Senior Notes matured and Ciena repaid the approximately $185.3 million in aggregate principal amount outstanding, together with approximately $0.8 million in accrued interest through the date of maturity.

[0000936395-17-000064:notes:45]
3.75% Convertible Senior Notes, due October 15, 2018

[0000936395-17-000064:notes:46]
On October 18, 2010, Ciena completed a private placement of 3.75% Convertible Senior Notes due October 15, 2018 (the “Original Notes”), in aggregate principal amount of $350.0 million. Interest is payable on the Original Notes on April 15 and October 15 of each year, beginning on April 15, 2011.

[0000936395-17-000064:notes:47]
At the election of the holder, the Original Notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 49.5872 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $20.17 per share. The net proceeds from the offering were approximately $340.4 million after deducting the placement agents’ fees and other fees and expenses.

[0000936395-17-000064:notes:48]
On August 2, 2017, Ciena completed its offer to exchange its outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount, or $0.7 million. Following settlement of the exchange, $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding. Interest is payable on the New Notes on April 15 and October 15 of each year, beginning October 15, 2017.

[0000936395-17-000064:notes:49]
The New Notes give Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares equal to the aggregate amount due upon conversion. It is Ciena’s intent to settle the principal amount of the New Notes in cash upon any conversion. As a result, only the amounts payable in excess of the principal amounts upon conversion of the New Notes are considered diluted earnings per share under the treasury stock method. Except with respect to the additional cash settlement options upon conversion, the New Notes were issued on substantially the same terms as the Original Notes including the holder conversion option and interest payment dates described above. Since the calculated fair value of the liability component was greater than the fair value of the New Notes, there was no impact to equity for the New Notes. This arrangement was accounted for as a modification of debt and, as such, $0.7 million of debt issuance costs associated with the New Notes was expensed, and the aggregate balance of $1.2 million of debt issuance costs for the Old Notes and approximately $0.7 million of original discount from the New Notes were included in the carrying value of the New Notes.

[0000936395-17-000064:notes:50]
4.0% Convertible Senior Notes due December 15, 2020

[0000936395-17-000064:notes:51]
On December 27, 2012, Ciena issued $187.5 million in aggregate principal amount of 4.0% Convertible Senior Notes due December 15, 2020 (the “2020 Notes”) in separate private offerings in exchange for $187.5 million in aggregate principal amount of 2015 Notes above.

[0000936395-17-000064:notes:52]
The 2020 Notes are senior unsecured obligations and rank equally with all of Ciena’s other existing and future senior unsecured debt. The 2020 Notes pay interest from the date of issuance at a rate of 4.0% per year. The interest is payable semi-annually on June 15 and December 15, commencing on June 15, 2013. The principal amount of the 2020 Notes will also accrete at a rate of 1.85% per year commencing December 27, 2012, compounding on a semi-annual basis. The accreted portion of the principal payable at maturity does not bear interest and is not convertible into shares of Ciena’s common stock. The 2020 Notes will mature on December 15, 2020. Consequently, in the event the 2020 Notes are converted, the accreted liability will extinguish without payment.

[0000936395-17-000064:notes:53]
The 2020 Notes may be converted prior to maturity, at the option of the holder, into shares of Ciena’s common stock at an initial conversion rate of 49.0557 shares of common stock per $1,000 in original principal amount, which is equal to an initial conversion price of $20.39 per share. In addition, Ciena may elect to convert the 2020 Notes, in whole or in part, at any time on or prior to December 15, 2020, if the daily volume weighted average price of the common stock equals or exceeds 130% of the conversion price then in effect for at least 20 trading days in any 30 consecutive trading day period. If Ciena elects to convert the 2020 Notes on or before maturity, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena’s election. An aggregate of 9,197,944 shares of Ciena common stock issuable upon conversion of the 2020 Notes has been reserved for issuance.

[0000936395-17-000064:notes:54]
Upon certain fundamental changes, holders of the 2020 Notes have the option to require Ciena to purchase the 2020 Notes at a price equal to the accreted principal amount of the notes delivered for repurchase plus any accrued and unpaid interest on the original principal amount. Upon a holder’s election to convert the 2020 Notes in connection with certain fundamental changes, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena’s election.

[0000936395-17-000064:notes:55]
Accounting guidance issued by the FASB requires the issuer of convertible debt instruments with cash settlement features, including partial cash settlement, to account separately for the liability and equity components of the instrument. Under this guidance, the debt is recognized at the present value of its cash flows discounted using the issuer’s nonconvertible debt borrowing rate at the time of issuance, and the equity component is recognized as the difference between the proceeds from the issuance of the note and the fair value of the liability. The reduced carrying value on the convertible debt results in a debt discount that is accreted back to the convertible debt’s principal amount through the recognition of non-cash interest expense over the expected life of the debt, which results in recognizing the interest expense on these borrowings at effective rates approximating what Ciena would have incurred had nonconvertible debt with otherwise similar terms been issued.

[0000936395-17-000064:notes:56]
Because the additional make-whole shares can be settled in cash or common stock at Ciena’s option, the debt and equity components were accounted for separately. Ciena measured the fair value of the debt component of the 2020 Notes using an effective interest rate of 7.0%. As a result, Ciena attributed $170.4 million of the fair value of the 2020 Notes to the debt component. The debt component was netted against the face value of the 2020 Notes to determine the debt discount. The debt discount will be accreted over the period from the date of issuance to the contractual maturity date, resulting in the recognition of non-cash interest expense. In addition, Ciena recorded $43.1 million within additional paid-in capital representing the equity component of the 2020 Notes. There was no net tax expense recorded at that time due to Ciena’s full valuation allowance against its deferred tax assets.

[0000936395-17-000064:notes:57]
The 2020 Notes were issued pursuant to an Indenture entered into as of December 27, 2012 (the “Indenture”) with The Bank of New York Mellon Trust Company, N.A., as trustee. The Indenture provides for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal (including accreted portion) or interest; breach of covenants or other agreements in the Indenture; defaults in failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing under the Indenture, the trustee or the holders of at least 25% in aggregate original principal amount of the 2020 Notes then outstanding may declare the principal (including accreted portion), premium, if any, and accrued interest on all the 2020 Notes immediately due and payable.

[0000936395-17-000064:notes:58]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of October 31, 2017:

[0000936395-17-000064:notes:59]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| Original 3.75% Convertible Senior Notes, due October 15, 2018 | $ | 61,270 |  |  | $ | — |  |  | $ | (199 | ) |  | $ | 61,071 |  |  | $ | — |  |
| New 3.75% Convertible Senior Notes, due October 15, 2018 | $ | 288,730 |  |  | $ | (574 | ) |  | $ | (935 | ) |  | $ | 287,221 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 204,963 |  |  | $ | (9,289 | ) |  | $ | (957 | ) |  | $ | 194,717 |  |  | $ | 43,131 |  |

[0000936395-17-000064:notes:60]
The following table sets forth, in thousands, the carrying value and the estimated current fair value of Ciena’s outstanding convertible notes:

[0000936395-17-000064:notes:61]
|  |  | October 31, 2017 |
| Description |  | Carrying Value |  | Fair Value(1) |
| Original 3.75% Convertible Senior Notes, due October 15, 2018 |  | $ | 61,071 |  |  | $ | 71,900 |  |
| New 3.75% Convertible Senior Notes, due October 15, 2018(2) |  | 287,221 |  |  | 338,825 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) |  | 194,717 |  |  | 244,406 |  |
|  |  | $ | 543,009 |  |  | $ | 655,131 |  |

[0000936395-17-000064:notes:62]
_________________________________

[0000936395-17-000064:notes:63]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |

[0000936395-17-000064:notes:64]
| (2) | Includes unamortized discount. |

[0000936395-17-000064:notes:65]
| (3) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-17-000064:notes:66]
Ciena expenses all advertising costs as incurred.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000936395-17-000064:notes:67]
These unaudited pro forma amounts (in thousands) do not purport to be indicative of the results that would have actually been obtained if the acquisition occurred as of the beginning of the periods presented, or that may be obtained in the future.

[0000936395-17-000064:notes:68]
|  | Year Ended October 31, |
|  | 2015 |
| Pro forma revenue | $ | 2,565,081 |  |
| Pro forma net income | $ | 16,286 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-17-000064:notes:69]
BUSINESS COMBINATIONS

[0000936395-17-000064:notes:70]
Cyan Acquisition

[0000936395-17-000064:notes:71]
On August 3, 2015, Ciena acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at the closing of the transaction, each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all the then-outstanding Cyan unvested restricted stock unit awards and stock options and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

[0000936395-17-000064:notes:72]
Upon the closing of the acquisition, Ciena assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the “2019 Notes”). Under the terms of the indenture governing the 2019 Notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of 2019 Notes surrendered for conversion. Subsequently, during the fourth quarter of fiscal 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes surrendered their 2019 Notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, Ciena issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

[0000936395-17-000064:notes:73]
During fiscal 2015, Ciena incurred approximately $25.5 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs, including payments to certain former Cyan executives, and approximately $7.6 million of non-cash share-based compensation expense.

[0000936395-17-000064:notes:74]
The following table summarizes the purchase price for the acquisition (in thousands):

[0000936395-17-000064:notes:75]
|  | Amount |
| Cash | $ | 33,621 |  |
| Value of common stock issued | 270,113 |  |
| Fair value of vested stock awards | 32,001 |  |
| Total purchase price | $ | 335,735 |  |

[0000936395-17-000064:notes:76]
The fair value of Ciena’s common stock issued in the acquisition was based on Ciena’s opening stock price on August 3, 2015, the closing date. The fair value of replacement vested stock options was determined using the Black-Scholes option-pricing model.

[0000936395-17-000064:notes:77]
The following table summarizes the final allocation related to Cyan based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-17-000064:notes:78]
|  | Amount |
| Cash and cash equivalents | $ | 60,831 |  |
| Restricted cash | 10,001 |  |
| Accounts receivable | 23,891 |  |
| Inventory | 12,849 |  |
| Prepaid expenses and other | 3,502 |  |
| Equipment, furniture and fixtures | 7,962 |  |
| Goodwill | 256,434 |  |
| Customer relationships | 36,323 |  |
| Trademarks | 3,432 |  |
| Developed technology | 88,814 |  |
| Order backlog | 25,293 |  |
| Other long-term assets | 789 |  |
| Accounts payable | (30,856 | ) |
| Accrued liabilities | (15,887 | ) |
| Deferred revenue | (16,643 | ) |
| Long-term debt | (48,836 | ) |
| Additional paid-in capital related to equity component of long-term debt | (82,164 | ) |
| Total purchase consideration | $ | 335,735 |  |

[0000936395-17-000064:notes:79]
Under purchase accounting rules, Ciena valued the acquired finished goods inventory to fair value, which is defined as the estimated selling price less the sum of (a) costs of disposal, and (b) a reasonable profit allowance for Ciena’s selling effort. This valuation resulted in an increase in inventory carrying value of approximately $3.1 million for marketable inventory.

[0000936395-17-000064:notes:80]
Customer relationships and contracts represent agreements with existing Cyan customers and have estimated useful lives of 4 years to 7 years. The majority of the order backlog, which is amortized over the fulfillment period, was fulfilled during the  fourth quarter of fiscal 2015.

[0000936395-17-000064:notes:81]
Developed technology represents purchased technology that had reached technological feasibility and for which Cyan had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful lives of 5 years to 7 years.

[0000936395-17-000064:notes:82]
The goodwill generated from the acquisition of Cyan was primarily related to expected synergies. The amount of goodwill allocated to the Networking Platforms segment and to the Software and Software-Related Services segment was $55.0 million and $201.4 million, respectively. The goodwill is not deductible for income tax purposes.

[0000936395-17-000064:notes:83]
The following unaudited pro forma financial information summarizes the results of operations for the periods indicated as if Ciena’s acquisition of Cyan had been completed as of the beginning of the earliest period. Revenue attributable to Cyan from the August 3, 2015 acquisition date through the end of Ciena’s fiscal 2015 was $84.4 million. As Ciena has begun to integrate the combined operations, eliminating overlapping processes and expenses and integrating its products and sales efforts with those of Cyan, it is impractical to determine the earnings specific to Cyan since the acquisition date. These unaudited pro forma amounts (in thousands) do not purport to be indicative of the results that would have actually been obtained if the acquisition occurred as of the beginning of the periods presented, or that may be obtained in the future.

[0000936395-17-000064:notes:84]
The pro forma earnings were adjusted to exclude $25.5 million in acquisition-related costs and $3.1 million of nonrecurring expense related to the fair value adjustment to acquisition-date inventory incurred in fiscal 2015.

[0000936395-17-000064:notes:85]
Additionally, pro forma earnings were adjusted to (i) exclude the mark to market changes in the fair value of Cyan’s warrants, as they were automatically exercised on a cashless basis immediately prior to the effective time of the merger and (ii) exclude the fair value of bifurcated conversion features in Cyan’s convertible notes, as these features were no longer bifurcated upon the consummation of the merger. The total amount of these adjustments was $60.6 million for fiscal 2015.

[0000936395-17-000064:notes:86]
TeraXion HSPC Asset Acquisition

[0000936395-17-000064:notes:87]
On February 1, 2016, Ciena, through a Canadian subsidiary, acquired certain high-speed photonics components (“HSPC”) assets of TeraXion Inc. (“TeraXion”) and its wholly-owned subsidiary for approximately $32 million in cash. The assets purchased include TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as the underlying intellectual property. These technologies support the development of Ciena’s WaveLogic coherent optical chipsets. This transaction has been accounted for as the acquisition of a business.

[0000936395-17-000064:notes:88]
The following table summarizes the final purchase price allocation related to the acquisition of the HSPC assets based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-17-000064:notes:89]
|  | Amount |
| Inventory | $ | 119 |  |
| Fixed assets | 1,381 |  |
| Developed technology | 16,468 |  |
| In-process technology | 3,949 |  |
| Goodwill | 10,083 |  |
| Total purchase consideration | $ | 32,000 |  |

[0000936395-17-000064:notes:90]
Developed technology represents purchased technology that had reached technological feasibility and for which TeraXion had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-17-000064:notes:91]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-17-000064:notes:92]
The goodwill generated from the acquisition of the HSPC assets was primarily related to expected synergies and has been allocated to the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-17-000064:notes:93]
Pro forma disclosures have not been included due to immateriality.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-17-000064:notes:94]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-17-000064:notes:95]
COMMITMENTS AND CONTINGENCIES

[0000936395-17-000064:notes:96]
Foreign Tax Contingencies

[0000936395-17-000064:notes:97]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-17-000064:notes:98]
Litigation

[0000936395-17-000064:notes:99]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, which petition was granted on June 27, 2017. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Oral argument was heard by the Supreme Court on this matter on November 28, 2017. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-17-000064:notes:100]
Internal Investigations

[0000936395-17-000064:notes:101]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the Securities and Exchange Commission (“SEC”) and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of the Board, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

[0000936395-17-000064:notes:102]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-17-000064:notes:103]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on our results of operations, financial position or cash flows.

[0000936395-17-000064:notes:104]
Lease Commitments

[0000936395-17-000064:notes:105]
Ciena has certain minimum obligations under non-cancelable leases expiring on various dates through 2032 for equipment and facilities. The following table summarizes our future annual minimum lease commitments under non-cancelable leases that are not recorded on the balance sheet as of October 31, 2017 (in thousands):

[0000936395-17-000064:notes:106]
|  |  | 2018 |  | 2019 |  | 2020 |  | 2021 |  | 2022 |  | Thereafter |  | Total |
| Operating leases |  | $ | 25,339 |  |  | $ | 18,483 |  |  | $ | 14,617 |  |  | $ | 12,584 |  |  | $ | 10,695 |  |  | $ | 34,588 |  |  | $ | 116,306 |  |

[0000936395-17-000064:notes:107]
Rental expense for fiscal 2017, fiscal 2016 and fiscal 2015 was approximately $30.9 million, $26.6 million and $25.7 million, respectively. In addition, Ciena paid approximately $2.7 million, $0.8 million and $0.8 million during fiscal 2017, fiscal 2016 and fiscal 2015, respectively, related to rent costs for restructured facilities and unfavorable lease commitments, which were offset against Ciena’s restructuring liabilities and unfavorable lease obligations. The amount for operating lease commitments above does not include variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material impact on Ciena’s financial condition, results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-17-000064:notes:108]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-17-000064:notes:109]
OTHER EMPLOYEE BENEFIT PLANS

[0000936395-17-000064:notes:110]
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$26,010 for 2017). This plan includes a required employer contribution of 1% for all participants and a 50% matching of participant contributions up to a total annual maximum of CAD$3,000 per employee. During fiscal 2017, 2016 and 2015, Ciena made matching contributions of approximately CAD$4.7 million, CAD$4.5 million and CAD$4.3 million, respectively.

[0000936395-17-000064:notes:111]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of pre-tax compensation, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2017, 2016 and 2015, Ciena made matching contributions of approximately $5.7 million, $5.4 million and $4.7 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-17-000064:notes:112]
ACCUMULATED OTHER COMPREHENSIVE INCOME

[0000936395-17-000064:notes:113]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”):

[0000936395-17-000064:notes:114]
|  |  | Unrealized Gain/(Loss) on Available-for-Sale Securities |  | Unrealized Gain/(Loss) on Foreign Currency Forward Contracts |  | Unrealized Gain/(Loss) on Forward Starting Interest Rate Swaps |  | Cumulative Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2014 |  | $ | 71 |  |  | $ | (173 | ) |  | $ | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive loss before reclassifications |  | (149 | ) |  | (5,547 | ) |  | (4,232 | ) |  | (3,775 | ) |  | (13,703 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 5,452 |  |  | 793 |  |  | — |  |  | 6,245 |  |
| Balance at October 31, 2015 |  | (78 | ) |  | (268 | ) |  | (5,522 | ) |  | (16,258 | ) |  | (22,126 | ) |
| Other comprehensive gain/(loss) before reclassifications |  | 217 |  |  | (1,453 | ) |  | (4,101 | ) |  | (1,152 | ) |  | (6,489 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 630 |  |  | 3,656 |  |  | — |  |  | 4,286 |  |
| Balance at October 31, 2016 |  | 139 |  |  | (1,091 | ) |  | (5,967 | ) |  | (17,410 | ) |  | (24,329 | ) |
| Other comprehensive gain/(loss) before reclassifications |  | (590 | ) |  | 1,290 |  |  | 3,669 |  |  | 8,012 |  |  | 12,381 |  |
| Amounts reclassified from AOCI |  | — |  |  | (1,585 | ) |  | 2,516 |  |  | — |  |  | 931 |  |
| Balance at October 31, 2017 |  | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |

[0000936395-17-000064:notes:115]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense or sales and marketing expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000936395-17-000064:notes:116]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-17-000064:notes:117]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-17-000064:notes:118]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-17-000064:notes:119]
|  | October 31, |
|  | 2017 |  | 2016 |
| Products | $ | 49,135 |  |  | $ | 45,216 |  |
| Services | 135,872 |  |  | 137,647 |  |
|  | 185,007 |  |  | 182,863 |  |
| Less current portion | (102,418 | ) |  | (109,009 | ) |
| Long-term deferred revenue | $ | 82,589 |  |  | $ | 73,854 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-17-000064:notes:120]
DERIVATIVE INSTRUMENTS

[0000936395-17-000064:notes:121]
Foreign Currency Derivatives

[0000936395-17-000064:notes:122]
As of October 31, 2017 and 2016, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, and its British Pound denominated expense, which principally relates to sales and marketing activities. The notional amount of these contracts was approximately $86.1 million and $107.6 million as of October 31, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-17-000064:notes:123]
During fiscal 2017 and fiscal 2016, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $83.4 million and $59.6 million as of October 31, 2017 and October 31, 2016. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-17-000064:notes:124]
Interest Rate Derivatives

[0000936395-17-000064:notes:125]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). During the second quarter of fiscal 2017, Ciena refinanced its existing 2019 and 2021 Term Loans into a new 2022 Term Loan, thereby reducing the aggregate outstanding principal to $400 million and extending the maturity to January 2022 (see Note 16 below). In order to align its interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, Ciena also reduced the total outstanding value of its interest rate swaps, as described below, and entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020, and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25%, 4.25% and 4.75%, respectively. The total notional amount of these interest rate swaps in effect as of October 31, 2017 was $389.6 million.

[0000936395-17-000064:notes:126]
During fiscal 2014, Ciena entered into interest rate swaps that fixed the interest rate under the 2019 Term Loan (as defined in Note 16) at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of October 31, 2016 was $244.4 million. In May 2016, Ciena entered into interest rate swaps that fixed the total interest rate under the 2021 Term Loan (as defined in Note 16) at 4.62% to 4.87%, depending on the applicable margin, for the period commencing on June 20, 2016 through June 22, 2020. The total notional amount of these derivatives as of October 31, 2016 was $248.8 million.

[0000936395-17-000064:notes:127]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loans. These derivative contracts have been designated as cash flow hedges.

[0000936395-17-000064:notes:128]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 4 and Note 6 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-17-000064:notes:129]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. Ciena also has interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-17-000064:notes:130]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-17-000064:notes:131]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-17-000064:notes:132]
SHARE-BASED COMPENSATION EXPENSE

[0000936395-17-000064:notes:133]
Ciena has outstanding equity awards issued under its 2008 Omnibus Incentive Plan, as well as certain legacy equity plans, equity plans assumed as a result of previous acquisitions, and its 2017 Omnibus Incentive Plan (the "2017 Plan"), which was approved by Ciena's stockholders on March 23, 2017. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under its Amended and Restated 2003 Employee Stock Purchase Plan (the "ESPP"). Each of the 2017 Plan and the ESPP are described below.

[0000936395-17-000064:notes:134]
2017 Plan

[0000936395-17-000064:notes:135]
The 2017 Plan has a ten year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-17-000064:notes:136]
The 2017 Plan authorizes and reserves 8.9 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena's prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 31, 2017, the total number of shares authorized for issuance under the 2017 Plan is 8.9 million and approximately 10.2 million shares remained available for issuance thereunder.

[0000936395-17-000064:notes:137]
Stock Options

[0000936395-17-000064:notes:138]
Outstanding stock option awards to employees are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-17-000064:notes:139]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of October 31, 2016 | 1,387 |  |  | $ | 26.90 |  |
| Granted | — |  |  | — |  |
| Exercised | (224 | ) |  | 10.76 |  |
| Canceled | (288 | ) |  | 29.44 |  |
| Balance as of October 31, 2017 | 875 |  |  | $ | 30.19 |  |

[0000936395-17-000064:notes:140]
The total intrinsic value of options exercised during fiscal 2017, fiscal 2016 and fiscal 2015 was $3.1 million, $5.7 million and $11.8 million, respectively. There were no stock options granted by Ciena during fiscal 2017, fiscal 2016 or fiscal 2015. The weighted average fair value of each stock option granted by Ciena in exchange for Cyan awards was $13.04 in fiscal 2015.

[0000936395-17-000064:notes:141]
The following table summarizes information with respect to stock options outstanding at October 31, 2017, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2017 (shares and intrinsic value in thousands):

[0000936395-17-000064:notes:142]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | October 31, 2017 |  | October 31, 2017 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) | Price |  | Value |
| $ | 1.88 |  |  | — |  |  | $ | 11.16 |  |  | 65 |  |  | 2.59 |  | $ | 8.66 |  |  | $ | 801 |  |  | 65 |  |  | 2.54 | $ | 8.64 |  |  | $ | 794 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 176 |  |  | 4.61 |  | 13.43 |  |  | 1,321 |  |  | 172 |  |  | 4.55 | 13.40 |  |  | 1,293 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.46 |  |  | 127 |  |  | 1.56 |  | 25.91 |  |  | 73 |  |  | 121 |  |  | 1.32 | 26.20 |  |  | 60 |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 291 |  |  | 1.53 |  | 35.08 |  |  | — |  |  | 290 |  |  | 1.53 | 35.08 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 216 |  |  | 3.76 |  | 46.30 |  |  | — |  |  | 216 |  |  | 3.76 | 46.30 |  |  | — |  |
| $ | 1.88 |  |  | — |  |  | $ | 55.63 |  |  | 875 |  |  | 2.78 |  | $ | 30.19 |  |  | $ | 2,195 |  |  | 864 |  |  | 2.73 | $ | 30.35 |  |  | $ | 2,147 |  |

[0000936395-17-000064:notes:143]
Assumptions for Option-Based Awards

[0000936395-17-000064:notes:144]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2017, fiscal 2016 or fiscal 2015. Ciena used the following assumptions for option-based awards issued in exchange for Cyan options in fiscal 2015:

[0000936395-17-000064:notes:145]
| Expected volatility | 35.87 | % |
| Risk-free interest rate | 1.26 | % |
| Expected term (years) | 0.72-6.88 |  |
| Expected dividend yield | 0.0 | % |

[0000936395-17-000064:notes:146]
Restricted Stock Units

[0000936395-17-000064:notes:147]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-17-000064:notes:148]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-17-000064:notes:149]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of October 31, 2016 | 4,280 |  |  | $ | 19.96 |  |  | $ | 83,511 |  |
| Granted | 2,489 |  |  |  |  |  |
| Vested | (2,057 | ) |  |  |  |  |
| Canceled or forfeited | (569 | ) |  |  |  |  |
| Balance as of October 31, 2017 | 4,143 |  |  | $ | 21.46 |  |  | $ | 86,721 |  |

[0000936395-17-000064:notes:150]
The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2017, fiscal 2016 and fiscal 2015 was $49.5 million, $50.3 million and $50.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2017, fiscal 2016 and fiscal 2015 was $23.29, $19.81 and $19.41, respectively. The weighted average fair value of each restricted stock unit granted by Ciena in exchange for Cyan awards was $25.39.

[0000936395-17-000064:notes:151]
Assumptions for Restricted Stock Unit Awards

[0000936395-17-000064:notes:152]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized, net of estimated forfeitures, ratably over the vesting period on a straight-line basis.

[0000936395-17-000064:notes:153]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena’s determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-17-000064:notes:154]
Because share-based compensation expense is recognized only for those awards that are ultimately expected to vest, the amount of share-based compensation expense recognized reflects a reduction for estimated forfeitures. Ciena estimates forfeitures at the time of grant and revises those estimates in subsequent periods based upon new or changed information.

[0000936395-17-000064:notes:155]
Amended and Restated Employee Stock Purchase Plan (ESPP)

[0000936395-17-000064:notes:156]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP’s “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-17-000064:notes:157]
During fiscal 2017, fiscal 2016 and fiscal 2015, Ciena issued 1.0 million, 1.1 million and 1.0 million shares under the ESPP, respectively. At October 31, 2017, 5.5 million shares remained available for issuance under the ESPP.

[0000936395-17-000064:notes:158]
Share-Based Compensation Expense for Periods Reported

[0000936395-17-000064:notes:159]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-17-000064:notes:160]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Product costs | $ | 2,672 |  |  | $ | 2,457 |  |  | $ | 2,400 |  |
| Service costs | 2,487 |  |  | 2,479 |  |  | 2,156 |  |
| Share-based compensation expense included in cost of goods sold | 5,159 |  |  | 4,936 |  |  | 4,556 |  |
| Research and development | 12,957 |  |  | 13,870 |  |  | 10,665 |  |
| Sales and marketing | 12,846 |  |  | 15,138 |  |  | 15,539 |  |
| General and administrative | 17,321 |  |  | 17,342 |  |  | 17,018 |  |
| Acquisition and integration costs | — |  |  | 714 |  |  | 7,588 |  |
| Share-based compensation expense included in operating expense | 43,124 |  |  | 47,064 |  |  | 50,810 |  |
| Share-based compensation expense capitalized in inventory, net | 77 |  |  | (7 | ) |  | (26 | ) |
| Total share-based compensation | $ | 48,360 |  |  | $ | 51,993 |  |  | $ | 55,340 |  |

[0000936395-17-000064:notes:161]
As of October 31, 2017, total unrecognized share-based compensation expense was $69.9 million: (i) $0.1 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 0.9 years; and (ii) $69.8 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-17-000064:notes:162]
Ciena calculates basic earnings per share (“EPS”) by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 18 below.


## us-gaap:EarningsPerShareTextBlock

[0000936395-17-000064:notes:163]
EARNINGS (LOSS) PER SHARE CALCULATION

[0000936395-17-000064:notes:164]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, (iv) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the treasury stock method (New Notes), and (v) shares underlying Ciena’s outstanding convertible notes for which Ciena uses the if-converted method.

[0000936395-17-000064:notes:165]
Numerator

[0000936395-17-000064:notes:166]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Net income | $ | 1,261,953 |  |  | $ | 72,584 |  |  | $ | 11,667 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | 853 |  |  | 4,801 |  |  | — |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original Notes) | 7,224 |  |  | — |  |  | — |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | 8,691 |  |  | — |  |  | — |  |
| Net income used to calculate Diluted EPS | $ | 1,278,721 |  |  | $ | 77,385 |  |  | $ | 11,667 |  |

[0000936395-17-000064:notes:167]
Denominator

[0000936395-17-000064:notes:168]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Basic weighted average shares outstanding | 141,997 |  |  | 138,312 |  |  | 118,416 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | 1,354 |  |  | 1,311 |  |  | 1,685 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) (1) | 404 |  |  | — |  |  | — |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | 3,032 |  |  | 11,081 |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original Notes) | 13,934 |  |  | — |  |  | — |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | 9,198 |  |  | — |  |  | — |  |
| Diluted weighted average shares outstanding | 169,919 |  |  | 150,704 |  |  | 120,101 |  |

[0000936395-17-000064:notes:169]
| (1) | Since Ciena expects to settle the principal amount of the outstanding 3.75% Convertible Senior Notes due 2018 (New Notes) in cash, Ciena uses the treasury stock method for calculating any potential dilutive effect of the conversion spread on diluted net income per share, if applicable. The conversion spread on 14.3 million shares that were converted to the New Notes will have a dilutive impact on diluted net income per share of common stock when the average market price of the Ciena common stock for a given period exceeds the conversion price of $20.17 per share for the New Notes. During the fourth quarter of fiscal 2017, the average market price of the common stock was $22.74 which was above $20.17, as such, the New Notes are dilutive by the conversion spread, or 0.4 million shares. |

[0000936395-17-000064:notes:170]
EPS

[0000936395-17-000064:notes:171]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Basic EPS | $ | 8.89 |  |  | $ | 0.52 |  |  | $ | 0.10 |  |
| Diluted EPS | $ | 7.53 |  |  | $ | 0.51 |  |  | $ | 0.10 |  |

[0000936395-17-000064:notes:172]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-17-000064:notes:173]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Shares underlying stock options and restricted stock units | 958 |  |  | 1,882 |  |  | 1,562 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | — |  |  | — |  |  | 3,386 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | — |  |  | 13,080 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original Notes) | — |  |  | 17,355 |  |  | 17,355 |  |
| 8.0% Cyan Convertible Senior Notes due 2019 | — |  |  | — |  |  | 187 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 9,198 |  |  | 9,198 |  |
| Total excluded due to anti-dilutive effect | 958 |  |  | 28,435 |  |  | 44,768 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-17-000064:notes:174]
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-17-000064:notes:175]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 511,355 |  |  | $ | — |  |  | $ | — |  |  | $ | 511,355 |  |
| U.S. government obligations | — |  |  | 298,976 |  |  | — |  |  | 298,976 |  |
| Commercial paper | — |  |  | 89,865 |  |  | — |  |  | 89,865 |  |
| Foreign currency forward contracts | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Forward starting interest rate swaps | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |

[0000936395-17-000064:notes:176]
|  | October 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 625,277 |  |  | $ | — |  |  | $ | — |  |  | $ | 625,277 |  |
| U.S. government obligations | — |  |  | 350,431 |  |  | — |  |  | 350,431 |  |
| Commercial paper | — |  |  | 69,959 |  |  | — |  |  | 69,959 |  |
| Foreign currency forward contracts | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Total assets measured at fair value | $ | 625,277 |  |  | $ | 420,565 |  |  | $ | — |  |  | $ | 1,045,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,396 |  |  | $ | — |  |  | $ | 1,396 |  |
| Forward starting interest rate swap | — |  |  | 5,967 |  |  | — |  |  | 5,967 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,363 |  |  | $ | — |  |  | $ | 7,363 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-17-000064:notes:177]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-17-000064:notes:178]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 511,355 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 571,280 |  |
| Short-term investments | — |  |  | 279,133 |  |  | — |  |  | 279,133 |  |
| Prepaid expenses and other | — |  |  | 227 |  |  | — |  |  | 227 |  |
| Long-term investments | — |  |  | 49,783 |  |  | — |  |  | 49,783 |  |
| Other long-term assets | — |  |  | 218 |  |  | — |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | — |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | — |  |  | $ | 2,129 |  |

[0000936395-17-000064:notes:179]
|  | October 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 625,277 |  |  | $ | 54,970 |  |  | $ | — |  |  | $ | 680,247 |  |
| Short-term investments | — |  |  | 275,248 |  |  | — |  |  | 275,248 |  |
| Prepaid expenses and other | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Long-term investments | — |  |  | 90,172 |  |  | — |  |  | 90,172 |  |
| Total assets measured at fair value | $ | 625,277 |  |  | $ | 420,565 |  |  | $ | — |  |  | $ | 1,045,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,396 |  |  | $ | — |  |  | $ | 1,396 |  |
| Other long-term obligations | — |  |  | 5,967 |  |  | — |  |  | 5,967 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,363 |  |  | $ | — |  |  | $ | 7,363 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-17-000064:notes:180]
FAIR VALUE MEASUREMENTS

[0000936395-17-000064:notes:181]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-17-000064:notes:182]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-17-000064:notes:183]
GOODWILL

[0000936395-17-000064:notes:184]
Ciena's goodwill was generated from its acquisition of Cyan during fiscal 2015 and its acquisition of the HSPC assets of TeraXion during fiscal 2016, and it is primarily related to expected synergies. The following table presents the goodwill allocated to Ciena's reportable segments as of the dates indicated (in thousands):

[0000936395-17-000064:notes:185]
|  | Balance at October 31, 2016 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at October 31, 2017 |
| Software and Software-Related Services | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms | 65,546 |  |  | — |  |  | — |  |  | 484 |  |  | 66,030 |  |
| Total | $ | 266,974 |  |  | $ | — |  |  | $ | — |  |  | $ | 484 |  |  | $ | 267,458 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-17-000064:notes:186]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-17-000064:notes:187]
INCOME TAXES

[0000936395-17-000064:notes:188]
For the periods indicated, the provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-17-000064:notes:189]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Provision (benefit) for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | — |  |  | $ | — |  |  | $ | — |  |
| State | 6,342 |  |  | 5,281 |  |  | 1,435 |  |
| Foreign | 14,563 |  |  | 9,969 |  |  | 10,662 |  |
| Total current | 20,905 |  |  | 15,250 |  |  | 12,097 |  |
| Deferred: |  |  |  |  |  |
| Federal | (1,047,699 | ) | (1) | — |  |  | — |  |
| State | (77,429 | ) | (1) | — |  |  | — |  |
| Foreign | (1,604 | ) |  | (1,116 | ) |  | — |  |
| Total deferred | (1,126,732 | ) |  | (1,116 | ) |  | — |  |
| Provision (benefit) for income taxes | $ | (1,105,827 | ) |  | $ | 14,134 |  |  | $ | 12,097 |  |

[0000936395-17-000064:notes:190]
(1)  The income tax benefit for 2017 includes the reversal of a significant portion of the valuation allowance on

[0000936395-17-000064:notes:191]
Ciena’s deferred tax assets in the U.S. See further discussion below.

[0000936395-17-000064:notes:192]
For the periods indicated, income before provision for income taxes consists of the following (in thousands):

[0000936395-17-000064:notes:193]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| United States | $ | 114,242 |  |  | $ | 58,237 |  |  | $ | (1,029 | ) |
| Foreign | 41,884 |  |  | 28,481 |  |  | 24,793 |  |
| Total | $ | 156,126 |  |  | $ | 86,718 |  |  | $ | 23,764 |  |

[0000936395-17-000064:notes:194]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent upon the mix of earnings and tax rates in our foreign jurisdictions.

[0000936395-17-000064:notes:195]
For the periods indicated, the tax provision (benefit) reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 35% as follows:

[0000936395-17-000064:notes:196]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Provision at statutory rate | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State taxes | 2.29 | % |  | 4.00 | % |  | 6.04 | % |
| Foreign taxes | (0.35 | )% |  | 3.11 | % |  | 28.98 | % |
| Research and development credit | (15.38 | )% |  | (22.61 | )% |  | (25.55 | )% |
| Non-deductible compensation and other | 10.12 | % |  | 4.13 | % |  | 30.16 | % |
| Valuation allowance | (739.97 | )% |  | (7.33 | )% |  | (23.73 | )% |
| Effective income tax rate | (708.29 | )% |  | 16.30 | % |  | 50.90 | % |

[0000936395-17-000064:notes:197]
As a result of prospective application of Accounting Standards Update No. 2015-17, Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes, Ciena offset all deferred tax liabilities and assets, as well as any related valuation allowance, and is presenting them as a single non-current amount as of October 31, 2017 and 2016.

[0000936395-17-000064:notes:198]
The significant components of deferred tax assets and liabilities are as follows (in thousands):

[0000936395-17-000064:notes:199]
|  | October 31, |
|  | 2017 |  | 2016 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 56,597 |  |  | $ | 59,791 |  |
| Depreciation and amortization | 451,385 |  |  | 298,497 |  |
| NOL and credit carry forward | 803,622 |  |  | 1,109,304 |  |
| Other | 29,398 |  |  | 23,304 |  |
| Gross deferred tax assets | 1,341,002 |  |  | 1,490,896 |  |
| Valuation allowance | (185,898 | ) |  | (1,489,780 | ) |
| Deferred tax asset, net of valuation allowance | $ | 1,155,104 |  |  | $ | 1,116 |  |

[0000936395-17-000064:notes:200]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-17-000064:notes:201]
|  | Amount |
| Unrecognized tax benefits at October 31, 2014 | $ | 15,100 |  |
| Increase related to positions taken in prior period | 3,658 |  |
| Increase related to positions taken in current period | 9,138 |  |
| Reductions related to expiration of statute of limitations | (360 | ) |
| Unrecognized tax benefits at October 31, 2015 | 27,536 |  |
| Increase related to positions taken in prior period | 2,187 |  |
| Increase related to positions taken in current period | 2,654 |  |
| Reductions related to expiration of statute of limitations | (1,709 | ) |
| Unrecognized tax benefits at October 31, 2016 | 30,668 |  |
| Increase related to positions taken in prior period | 122 |  |
| Increase related to positions taken in current period | 111,412 |  |
| Reductions related to expiration of statute of limitations | (620 | ) |
| Unrecognized tax benefits at October 31, 2017 | $ | 141,582 |  |

[0000936395-17-000064:notes:202]
As of October 31, 2017 and 2016, Ciena had accrued $4.0 million and $4.6 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $1.2 million and $0.9 million were recorded to the provision for income taxes during fiscal 2016 and fiscal 2015, respectively. During fiscal 2017, Ciena recorded a net benefit for interest and penalties in its provision for income taxes of $0.6 million, primarily as a result of recognizing a portion of previously unrecognized tax benefits. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-17-000064:notes:203]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2017, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized totaled approximately $384 million. If these earnings were distributed to the U.S. in the form of dividends, or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, Ciena would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable. Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-17-000064:notes:204]
Since 2002, Ciena has maintained a valuation allowance against its net U.S. deferred tax assets. On a quarterly basis, Ciena evaluates all available positive and negative evidence to determine if a valuation allowance is required. Improved profitability led to Ciena’s U.S. business having cumulative income over a three-year period towards the end of fiscal 2016 for the first time since the valuation allowance was established. However, at that time, Ciena determined that a valuation allowance was still necessary, due to, among other things, the relatively low level of cumulative pre-tax income during this period and Ciena’s history of operating losses. In the fourth quarter of fiscal 2017, based on the sustained and increasing earnings of Ciena’s U.S. business throughout 2017, Ciena’s future projections of profitability and a positive industry outlook, Ciena has concluded that it is more likely than not that Ciena will realize the benefit of most of its U.S. deferred tax assets and accordingly has reversed a majority of the valuation allowance that was recorded against its net U.S. deferred tax assets. This reversal resulted in a one-time, non-cash income tax benefit of $1.125 billion recorded in Ciena’s Consolidated Statement of Operations and a $26.0 million adjustment to Additional Paid-in-Capital in the Consolidated Statement of Changes in Stockholders’ Equity related to certain previously settled call spread options. As of October 31, 2017, Ciena continues to maintain a valuation allowance against net deferred tax assets of $185.9 million primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use. Approximately $38.0 million of the retained valuation allowance relates to deductions for stock compensation which Ciena anticipates will be released through retained earnings in the first quarter of fiscal 2018 upon the adoption of ASU 2016-09.

[0000936395-17-000064:notes:205]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-17-000064:notes:206]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Additions |  | Deductions |  | Balance |
| 2015 |  | $ | 1,496,835 |  |  | $ | — |  |  | $ | 1,163 |  |  | $ | 1,495,672 |  |
| 2016 |  | $ | 1,495,672 |  |  | $ | — |  |  | $ | 5,892 |  |  | $ | 1,489,780 |  |
| 2017 |  | $ | 1,489,780 |  |  | $ | — |  |  | $ | 1,303,882 |  |  | $ | 185,898 |  |

[0000936395-17-000064:notes:207]
As of October 31, 2017, Ciena had a $1.65 billion net operating loss carry forward and a $0.1 billion income tax credit carry forward which begin to expire in fiscal year 2019 and 2017, respectively. Ciena’s ability to use net operating losses and credit carry forwards is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0000936395-17-000064:notes:208]
Currently, the recognition of windfall tax benefits from stock-based compensation deducted on the tax return is prohibited until realized through a reduction of income tax payable. In fiscal 2018, Ciena will adopt ASU 2016-09, Improvements to Employee Share-Based Payment Accounting. At that time, the cumulative tax benefits totaling approximately $62 million will be recorded in beginning retained earnings effective November 1, 2017.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-17-000064:notes:209]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-17-000064:notes:210]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 and 2014 through 2016 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2014), United Kingdom (2014), Canada (2011), India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-17-000064:notes:211]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.

[0000936395-17-000064:notes:212]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena’s net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena’s net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-17-000064:notes:213]
INTANGIBLE ASSETS

[0000936395-17-000064:notes:214]
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-17-000064:notes:215]
|  | October 31, |
|  | 2017 |  | 2016 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 341,255 |  |  | $ | (266,693 | ) |  | $ | 74,562 |  |  | $ | 347,727 |  |  | $ | (248,128 | ) |  | $ | 99,599 |  |
| In-process research and development | 671 |  |  | — |  |  | 671 |  |  | 4,200 |  |  | — |  |  | 4,200 |  |
| Patents and licenses | 7,165 |  |  | (6,535 | ) |  | 630 |  |  | 7,165 |  |  | (6,285 | ) |  | 880 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 334,642 |  |  | (309,508 | ) |  | 25,134 |  |  | 358,647 |  |  | (316,615 | ) |  | 42,032 |  |
| Total intangible assets | $ | 683,733 |  |  | $ | (582,736 | ) |  | $ | 100,997 |  |  | $ | 717,739 |  |  | $ | (571,028 | ) |  | $ | 146,711 |  |

[0000936395-17-000064:notes:216]
During the third quarter of fiscal 2017 and the second quarter of fiscal 2016, certain fully amortized intangible assets of approximately $34.0 million and $246.4 million, respectively, were eliminated from gross intangible assets and accumulated amortization during the period, with no corresponding impact to the income statement. These assets were primarily technology for products no longer being sold by Ciena.

[0000936395-17-000064:notes:217]
As the result of the acquisition of the high-speed photonics components assets from TeraXion and its wholly-owned subsidiary on February 1, 2016, Ciena had recorded in-process research and development projects acquired as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the assets. In the third quarter of fiscal 2017, Ciena placed into service $3.5 million of developed technology, which will be amortized over the expected economic life of five years.

[0000936395-17-000064:notes:218]
The aggregate amortization expense of intangible assets was $45.7 million, $78.3 million and $79.9 million for fiscal 2017, fiscal 2016 and fiscal 2015, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-17-000064:notes:219]
| Year Ended October 31, |  |  |
| 2018 | $ | 23,386 |  |  |
| 2019 | 22,839 |  |  |
| 2020 | 21,812 |  |  |
| 2021 | 18,878 |  |  |
| 2022 | 13,347 |  |  |
| Thereafter | 64 |  |  |
|  | $ | 100,326 |  | (1) |

[0000936395-17-000064:notes:220]
(1) Does not include amortization of in-process research and development, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-17-000064:notes:221]
INVENTORIES

[0000936395-17-000064:notes:222]
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-17-000064:notes:223]
|  | October 31, |
|  | 2017 |  | 2016 |
| Raw materials | $ | 52,898 |  |  | $ | 44,644 |  |
| Work-in-process | 18,623 |  |  | 12,852 |  |
| Finished goods | 185,488 |  |  | 156,402 |  |
| Deferred cost of goods sold | 61,340 |  |  | 59,856 |  |
|  | 318,349 |  |  | 273,754 |  |
| Provision for excess and obsolescence | (51,206 | ) |  | (62,503 | ) |
|  | $ | 267,143 |  |  | $ | 211,251 |  |

[0000936395-17-000064:notes:224]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During fiscal 2017, Ciena recorded a provision for excess and obsolescence of $35.5 million, primarily related to a decrease in the forecasted demand for certain Converged Packet Optical products. During fiscal 2016, Ciena recorded a provision for excess and obsolescence of $33.7 million, primarily related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. During fiscal 2015, Ciena recorded a provision for excess and obsolescence of $26.8 million, primarily related to the discontinuance of certain parts and components used in the manufacture of its Converged Packet Optical products and a decrease in the forecasted demand for both its legacy, stand-alone WDM and SONET/SDH-based transport platforms and its 5410 Service Aggregation Switch.  Deductions from the provision for excess and obsolete inventory relate to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-17-000064:notes:225]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-17-000064:notes:226]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions.


## us-gaap:InvestmentPolicyTextBlock

[0000936395-17-000064:notes:227]
Ciena’s investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-17-000064:notes:228]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-17-000064:notes:229]
The following table summarizes the legal maturities of debt investments at October 31, 2017:

[0000936395-17-000064:notes:230]
|  | October 31, 2017 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 279,437 |  |  | $ | 279,133 |  |
| Due in 1-2 years | 49,910 |  |  | 49,783 |  |
|  | $ | 329,347 |  |  | $ | 328,916 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-17-000064:notes:231]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-17-000064:notes:232]
As of October 31, 2017, investments are comprised of the following (in thousands):

[0000936395-17-000064:notes:233]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |

[0000936395-17-000064:notes:234]
As of October 31, 2016, investments are comprised of the following (in thousands):

[0000936395-17-000064:notes:235]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-17-000064:notes:236]
Ciena expenses legal costs associated with litigation as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-17-000064:notes:237]
ACCOUNTS RECEIVABLE

[0000936395-17-000064:notes:238]
As of October 31, 2017, two customers accounted for 23.0% of net accounts receivable. As of October 31, 2016, one customer accounted for 10.4% of net accounts receivable. Prior to fiscal 2017, Ciena has not historically experienced a significant amount of bad debt expense. During fiscal 2017, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $13.7 million for a trade receivable related to a single customer in the APAC region. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-17-000064:notes:239]
| Year ended |  | Beginning |  |  |  | Net |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Deductions |  | Balance |
| 2015 |  | $ | 2,083 |  |  | $ | 1,576 |  |  | $ | 696 |  |  | $ | 2,963 |  |
| 2016 |  | $ | 2,963 |  |  | $ | 1,701 |  |  | $ | 701 |  |  | $ | 3,963 |  |
| 2017 |  | $ | 3,963 |  |  | $ | 18,221 |  |  | $ | 4,604 |  |  | $ | 17,580 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-17-000064:notes:240]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and to continue to present such capitalized costs in other long-term assets.

[0000936395-17-000064:notes:241]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

[0000936395-17-000064:notes:242]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-17-000064:notes:243]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) ("ASU 2014-09"), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

[0000936395-17-000064:notes:244]
For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require that it determine the stand alone selling price for each of the software and software-related deliverables at the contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-17-000064:notes:245]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-17-000064:notes:246]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-17-000064:notes:247]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000064:notes:248]
In February 2016, the FASB issued ASU No. 2016-02, Leases ("ASU 2016-02"), which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000064:notes:249]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Currently, the recognition of windfall tax benefits from stock-based compensation deducted on the tax return is prohibited until realized through a reduction of income tax payable. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, or approximately $62 million, along with any related valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, with the prior periods adjusted accordingly, as a result of the adoption. Finally, Ciena will elect to recognize forfeitures when they occur, rather than estimate the impact of forfeitures when the award is granted. Accordingly Ciena will account for this change through a cumulative effect adjustment recorded to opening retained earnings in the period of adoption.

[0000936395-17-000064:notes:250]
In January 2017, the FASB issued ASU No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.

[0000936395-17-000064:notes:251]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. ASU 2017-12 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is evaluating the effect of the update on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-17-000064:notes:252]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES

[0000936395-17-000064:notes:253]
Description of Business

[0000936395-17-000064:notes:254]
Ciena Corporation (“Ciena” or the “Company”) is a network strategy and technology company, providing solutions that enable a wide range of network operators to deploy and manage next-generation communication architectures that deliver a broad array of services. Ciena provides network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data, and voice traffic on communications networks. Ciena’s high-capacity hardware and network management and control software solutions enable open, programmable networks that enhance automation, reduce network complexity and support changing service requirements. Ciena’s solutions create business and operational value for its customers by enabling them to introduce new revenue-generating services and reduce network costs.

[0000936395-17-000064:notes:255]
Ciena’s solutions include a diverse set of Networking Platform products, which are used by a broad range of network operator customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which can be applied from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to its portfolio of high-capacity hardware systems and components, Ciena offers network management and domain control software platforms, along with advanced applications software, designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement its hardware and software solutions, Ciena offers a broad range of services that help our customers design, optimize, integrate, deploy, manage and maintain their networks.

[0000936395-17-000064:notes:256]
Basis of Presentation

[0000936395-17-000064:notes:257]
Ciena has a 52 or 53 week fiscal year, which ends on the Saturday nearest to the last day of October in each year (October 28, 2017, October 29, 2016 and October 31, 2015 for the periods reported). Fiscal 2017, fiscal 2016 and fiscal 2015 each consisted of a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31.

[0000936395-17-000064:notes:258]
Business Combinations

[0000936395-17-000064:notes:259]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-17-000064:notes:260]
Use of Estimates

[0000936395-17-000064:notes:261]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-17-000064:notes:262]
Cash and Cash Equivalents

[0000936395-17-000064:notes:263]
Investments

[0000936395-17-000064:notes:264]
Inventories

[0000936395-17-000064:notes:265]
Segment Reporting

[0000936395-17-000064:notes:266]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 22 below.

[0000936395-17-000064:notes:267]
Goodwill

[0000936395-17-000064:notes:268]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-17-000064:notes:269]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill.  If this test indicates that the fair value is less than the carrying value, then step two as amended by Financial Accounting Standards Board ("FASB") Accounting Standards Update ("ASU") No.2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-17-000064:notes:270]
Long-lived Assets

[0000936395-17-000064:notes:271]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-17-000064:notes:272]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-17-000064:notes:273]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 13 below.

[0000936395-17-000064:notes:274]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two to five years.

[0000936395-17-000064:notes:275]
Intangible Assets

[0000936395-17-000064:notes:276]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-17-000064:notes:277]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, and if the asset developed has no alternative use, the full value of the asset will be charged to expense.

[0000936395-17-000064:notes:278]
Maintenance Spares

[0000936395-17-000064:notes:279]
Concentrations

[0000936395-17-000064:notes:280]
Revenue Recognition

[0000936395-17-000064:notes:281]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-17-000064:notes:282]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-17-000064:notes:283]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-17-000064:notes:284]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third-party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-17-000064:notes:285]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-17-000064:notes:286]
Warranty Accruals

[0000936395-17-000064:notes:287]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based upon actual warranty cost experience, estimates of component failure rates and management's industry experience. Ciena's sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-17-000064:notes:288]
Accounts Receivable, Net

[0000936395-17-000064:notes:289]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer,  which could negatively affect its results of operations.

[0000936395-17-000064:notes:290]
Research and Development

[0000936395-17-000064:notes:291]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-17-000064:notes:292]
Advertising Costs

[0000936395-17-000064:notes:293]
Legal Costs

[0000936395-17-000064:notes:294]
Share-Based Compensation Expense

[0000936395-17-000064:notes:295]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 21 below.

[0000936395-17-000064:notes:296]
Income Taxes

[0000936395-17-000064:notes:297]
Loss Contingencies

[0000936395-17-000064:notes:298]
Fair Value of Financial Instruments

[0000936395-17-000064:notes:299]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loans, see Note 16 below.

[0000936395-17-000064:notes:300]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-17-000064:notes:301]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

[0000936395-17-000064:notes:302]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0000936395-17-000064:notes:303]
| • | Level 3 inputs are unobservable inputs based on Ciena's assumptions used to measure assets and liabilities at fair value. |

[0000936395-17-000064:notes:304]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-17-000064:notes:305]
Restructuring

[0000936395-17-000064:notes:306]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-17-000064:notes:307]
Foreign Currency

[0000936395-17-000064:notes:308]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 4 below.

[0000936395-17-000064:notes:309]
Derivatives

[0000936395-17-000064:notes:310]
See Notes 6 and 14 below.

[0000936395-17-000064:notes:311]
Computation of Net Income (Loss) per Share

[0000936395-17-000064:notes:312]
Software Development Costs

[0000936395-17-000064:notes:313]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-17-000064:notes:314]
Newly Issued Accounting Standards - Effective


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-17-000064:notes:315]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-17-000064:notes:316]
|  | October 31, |
|  | 2017 |  | 2016 |
| Capital lease obligations | 73,407 |  |  | 24,298 |  |
| Income tax liability | 15,445 |  |  | 14,122 |  |
| Deferred tenant allowance | 8,162 |  |  | 9,164 |  |
| Straight-line rent | 7,267 |  |  | 6,406 |  |
| Forward starting interest rate swaps | — |  |  | 5,967 |  |
| Construction liability | — |  |  | 57,602 |  |
| Other | 7,068 |  |  | 6,835 |  |
|  | $ | 111,349 |  |  | $ | 124,394 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-17-000064:notes:317]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-17-000064:notes:318]
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-17-000064:notes:319]
|  |  | Year Ended October 31, |
|  |  | 2017 |  | 2016 |  | 2015 |
| Interest income |  | $ | 6,579 |  |  | $ | 4,058 |  |  | $ | 1,178 |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts |  | (1,198 | ) |  | (23,355 | ) |  | 23,243 |  |
| Foreign currency exchange gains (losses) |  | (4,376 | ) |  | 5,870 |  |  | (47,607 | ) |
| Modification of debt |  | (3,616 | ) |  | — |  |  | — |  |
| Other |  | (133 | ) |  | 632 |  |  | (2,319 | ) |
| Interest and other income (loss), net |  | $ | (2,744 | ) |  | $ | (12,795 | ) |  | $ | (25,505 | ) |

[0000936395-17-000064:notes:320]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2017 and fiscal 2015, Ciena recorded $4.4 million and $47.6 million, respectively, in exchange rate losses, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net. In fiscal 2016, Ciena recorded $5.9 million in foreign currency exchange gains. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net. During fiscal 2017 and fiscal 2016, Ciena recorded losses of $1.2 million and $23.4 million, respectively, from non-hedge designated foreign currency forward contracts. During fiscal 2015, Ciena recorded gains of $23.2 million from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-17-000064:notes:321]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES

[0000936395-17-000064:notes:322]
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-17-000064:notes:323]
|  | October 31, |
|  | 2017 |  | 2016 |
| Equipment, furniture and fixtures | $ | 486,451 |  |  | $ | 451,029 |  |
| Building subject to capital lease | 76,702 |  |  | 22,529 |  |
| Construction in progress, subject to build-to-suit lease | — |  |  | 57,602 |  |
| Leasehold improvements | 87,763 |  |  | 60,011 |  |
|  | 650,916 |  |  | 591,171 |  |
| Accumulated depreciation and amortization | (342,451 | ) |  | (302,765 | ) |
|  | $ | 308,465 |  |  | $ | 288,406 |  |

[0000936395-17-000064:notes:324]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord constructed, and Ciena subsequently leased, two new office buildings at its new Ottawa, Canada campus. The landlord constructed the buildings and contributed up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena was responsible for any additional construction costs. As of May 1, 2017, occupancy for both of the office buildings was complete. As such, Ciena recorded capital leases of $50.4 million for these buildings, which will be depreciated over the lease term and removed the build-to-suit construction in progress asset and the corresponding long-term liability.

[0000936395-17-000064:notes:325]
During fiscal 2017, fiscal 2016 and fiscal 2015, Ciena recorded depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements of $67.2 million, $52.7 million and $46.1 million, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-17-000064:notes:326]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income during the respective periods indicated:

[0000936395-17-000064:notes:327]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Segment profit: |  |  |  |  |  |
| Networking Platforms | $ | 578,039 |  |  | $ | 544,744 |  |  | $ | 515,550 |  |
| Software and Software-Related Services | 32,536 |  |  | 7,123 |  |  | 4,174 |  |
| Global Services | 159,882 |  |  | 157,915 |  |  | 141,638 |  |
| Total segment profit | 770,457 |  |  | 709,782 |  |  | 661,362 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 356,169 |  |  | 349,731 |  |  | 333,836 |  |
| General and administrative | 142,604 |  |  | 132,828 |  |  | 123,402 |  |
| Amortization of intangible assets | 33,029 |  |  | 61,508 |  |  | 69,511 |  |
| Acquisition and integration costs | — |  |  | 4,613 |  |  | 25,539 |  |
| Significant asset impairments and restructuring costs | 23,933 |  |  | 4,933 |  |  | 8,626 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest expense and other income (loss), net | (58,596 | ) |  | (69,451 | ) |  | (76,684 | ) |
| Less: Provision (benefit) for income taxes | (1,105,827 | ) |  | 14,134 |  |  | 12,097 |  |
| Consolidated net income | $ | 1,261,953 |  |  | $ | 72,584 |  |  | $ | 11,667 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-17-000064:notes:328]
The table below (in thousands, except percentage data) sets forth Ciena’s segment revenue for the respective periods indicated:

[0000936395-17-000064:notes:329]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |
| Converged Packet Optical | $ | 1,926,087 |  |  | $ | 1,779,932 |  |  | $ | 1,661,702 |  |
| Packet Networking | 313,089 |  |  | 252,862 |  |  | 229,223 |  |
| Optical Transport | 13,534 |  |  | 35,989 |  |  | 73,004 |  |
| Total Networking Platforms | 2,252,710 |  |  | 2,068,783 |  |  | 1,963,929 |  |
| Software and Software-Related Services |  |  |  |  |  |
| Software Platforms | 65,871 |  |  | 48,689 |  |  | 38,466 |  |
| Software-Related Services | 95,248 |  |  | 76,380 |  |  | 61,821 |  |
| Total Software and Software-Related Services | 161,119 |  |  | 125,069 |  |  | 100,287 |  |
| Global Services |  |  |  |  |  |
| Maintenance Support and Training | 227,400 |  |  | 228,982 |  |  | 224,079 |  |
| Installation and Deployment | 117,524 |  |  | 130,916 |  |  | 115,531 |  |
| Consulting and Network Design | 42,934 |  |  | 46,823 |  |  | 41,843 |  |
| Total Global Services | 387,858 |  |  | 406,721 |  |  | 381,453 |  |
| Consolidated revenue | $ | 2,801,687 |  |  | $ | 2,600,573 |  |  | $ | 2,445,669 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-17-000064:notes:330]
RESTRUCTURING COSTS

[0000936395-17-000064:notes:331]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the fiscal years indicated (in thousands):

[0000936395-17-000064:notes:332]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,631 |  | (1) | (5 | ) |  | 8,626 |  |
| Cash payments | (8,221 | ) |  | (441 | ) |  | (8,662 | ) |
| Balance at October 31, 2015 | 591 |  |  | 688 |  |  | 1,279 |  |
| Additional liability recorded | 2,844 |  | (2) | 2,089 |  |  | 4,933 |  |
| Cash payments | (2,567 | ) |  | (807 | ) |  | (3,374 | ) |
| Balance at October 31, 2016 | 868 |  |  | 1,970 |  |  | 2,838 |  |
| Additional liability recorded | 5,883 |  | (3) | 5,432 |  | (4) | 11,315 |  |
| Adjustment to previous estimates | — |  |  | (1,048 | ) |  | (1,048 | ) |
| Cash payments | (5,460 | ) |  | (4,706 | ) |  | (10,166 | ) |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Current restructuring liabilities | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-17-000064:notes:333]
| (1) | During fiscal 2015, Ciena recorded a charge of $8.6 million of severance and other employee-related costs associated with a workforce reduction of approximately 125 employees. |

[0000936395-17-000064:notes:334]
| (2) | During fiscal 2016, Ciena recorded a charge of $2.8 million of severance and other employee-related costs associated with a workforce reduction of approximately 75 employees. |

[0000936395-17-000064:notes:335]
| (3) | During fiscal 2017, Ciena recorded a charge of $5.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 100 employees. |

[0000936395-17-000064:notes:336]
| (4) | Reflects unfavorable lease commitments and relocation costs incurred in connection with our research and development center facility transitions in Ottawa, Canada |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-17-000064:notes:337]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-17-000064:notes:338]
|  | October 31, |
|  | 2017 |  | 2016 |
| Compensation, payroll related tax and benefits | $ | 113,272 |  |  | $ | 106,687 |  |
| Warranty | 42,456 |  |  | 52,324 |  |
| Vacation | 39,778 |  |  | 36,112 |  |
| Capital lease obligations | 3,772 |  |  | 2,321 |  |
| Interest payable | 3,612 |  |  | 4,649 |  |
| Other | 120,044 |  |  | 108,260 |  |
|  | $ | 322,934 |  |  | $ | 310,353 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-17-000064:notes:339]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of October 31, 2017 (in thousands):

[0000936395-17-000064:notes:340]
| Year Ending October 31, | Amount |
| 2018 | $ | 9,251 |  |
| 2019 | 8,828 |  |
| 2020 | 7,846 |  |
| 2021 | 7,742 |  |
| 2022 | 8,064 |  |
| Thereafter | 85,405 |  |
| Net minimum capital lease payments | 127,136 |  |
| Less: Amount representing interest | (49,957 | ) |
| Present value of minimum lease payments | 77,179 |  |
| Less: Current portion of present value of minimum lease payments | (3,772 | ) |
| Long-term portion of present value of minimum lease payments | $ | 73,407 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-17-000064:notes:341]
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-17-000064:notes:342]
|  | October 31, |
|  | 2017 |  | 2016 |
| Maintenance spares inventory, net | $ | 46,872 |  |  | $ | 49,535 |  |
| Minority equity investments | 6,000 |  |  | 6,000 |  |
| Deferred debt issuance costs, net (1) | 1,041 |  |  | 1,363 |  |
| Financing receivable | 1,052 |  |  | 1,870 |  |
| Forward starting interest rate swaps | 219 |  |  | — |  |
| Other | 8,409 |  |  | 8,236 |  |
|  | $ | 63,593 |  |  | $ | 67,004 |  |

[0000936395-17-000064:notes:343]
(1) As described in Note 1 above, in connection with Ciena's adoption of ASU 2015-03 during the first quarter of fiscal 2017, deferred debt issuance costs associated with its convertible notes and term loans were retrospectively reclassified from other long-term assets to current portion of long-term debt and long-term debt, net on the Consolidated Balance Sheets. The remaining deferred debt issuance costs reflected relate to Ciena's ABL Credit Facility (described in Note 17 below). The amortization of deferred debt issuance costs for Ciena's ABL Credit Facility is included in interest expense, and was $0.3 million, $0.4 million and $0.7 million for fiscal 2017, fiscal 2016 and fiscal 2015, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-17-000064:notes:344]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-17-000064:notes:345]
| Year ended |  | Beginning |  |  |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Acquired |  | Current Year Provisions (1) |  | Settlements |  | Balance |
| 2015 |  | $ | 55,997 |  |  | $ | 2,996 |  |  | $ | 17,881 |  |  | $ | 20,220 |  |  | $ | 56,654 |  |
| 2016 |  | $ | 56,654 |  |  | $ | — |  |  | $ | 15,483 |  |  | $ | 19,813 |  |  | $ | 52,324 |  |
| 2017 |  | $ | 52,324 |  |  | $ | — |  |  | $ | 7,965 |  |  | $ | 17,833 |  |  | $ | 42,456 |  |

[0000936395-17-000064:notes:346]
(1) As a result of actual failure rates lower than expected, we adjusted our current year provisions for warranty. These adjustments for previous years provisions had the effect of reducing warranty provisions by $9.7 million, $5.3 million and $6.5 million for fiscal 2017, 2016 and 2015 respectively.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-17-000064:notes:347]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-17-000064:notes:348]
|  | October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| AT&T | $ | 448,943 |  |  | $ | 479,077 |  |  | $ | 487,831 |  |
| Verizon | 288,048 |  |  | n/a |  |  | n/a |  |
| Total | $ | 736,991 |  |  | $ | 479,077 |  |  | $ | 487,831 |  |

[0000936395-17-000064:notes:349]
________________________________

[0000936395-17-000064:notes:350]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-17-000064:notes:351]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-17-000064:notes:352]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |  | 2015 |
| North America | $ | 1,736,047 |  |  | $ | 1,689,263 |  |  | $ | 1,598,328 |  |
| EMEA | 404,099 |  |  | 393,705 |  |  | 400,294 |  |
| CALA | 164,308 |  |  | 195,085 |  |  | 201,499 |  |
| APAC | 497,233 |  |  | 322,520 |  |  | 245,548 |  |
| Total | $ | 2,801,687 |  |  | $ | 2,600,573 |  |  | $ | 2,445,669 |  |

[0000936395-17-000064:notes:353]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-17-000064:notes:354]
|  | October 31, |
|  | 2017 |  | 2016 |
| Canada | $ | 203,491 |  |  | $ | 173,885 |  |
| United States | 90,482 |  |  | 103,018 |  |
| Other International | 14,492 |  |  | 11,503 |  |
| Total | $ | 308,465 |  |  | $ | 288,406 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-17-000064:notes:355]
SEGMENT AND ENTITY WIDE DISCLOSURES

[0000936395-17-000064:notes:356]
Ciena’s internal organizational structure and the management of its business are grouped into the following operating segments:

[0000936395-17-000064:notes:357]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical, Packet Networking and Optical Transport product lines. |

[0000936395-17-000064:notes:358]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include the Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-17-000064:notes:359]
| ◦ | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. |

[0000936395-17-000064:notes:360]
| ◦ | Optical Transport — includes the 4200 Advanced Services Platform, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. As of the end of fiscal 2017, the Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures and stackable interconnect platforms addressed by solutions within our Converged Packet Optical product line. Accordingly, commencing in fiscal 2018, sales of Optical Transport will be reflected within the Converged Packet Optical product line of our Networking Platforms segment. |

[0000936395-17-000064:notes:361]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations.

[0000936395-17-000064:notes:362]
Software and Software-Related Services reflects sales of Ciena’s network virtualization, management, control and orchestration software solutions and software-related services, including subscription, installation, support, and consulting services.

[0000936395-17-000064:notes:363]
| ◦ | This segment includes Ciena’s element and network management solutions and planning tools, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks adoption of its Blue Planet software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other element and network management solutions. |

[0000936395-17-000064:notes:364]
| ◦ | This segment includes Ciena’s Blue Planet network virtualization, service orchestration and network management software platform. Ciena's Blue Planet platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), and Ciena's manage, control and plan (MCP) solution, SDN Multilayer Controller and V-WAN application. |

[0000936395-17-000064:notes:365]
Revenue from the software platforms portion of this segment is included in product revenue on the Consolidated Statement of Operations. Revenue from software-related services is included in services revenue on the Consolidated Statement of Operations.

[0000936395-17-000064:notes:366]
| • | Global Services reflects sales of a broad range of Ciena’s services for consulting and network design, installation and deployment, maintenance support and training activities. Revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-17-000064:notes:367]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets, and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2017, equipment, building, furniture and fixtures totaling $308.5 million primarily supports asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and Ciena’s unallocated selling and general and administrative activities. As of October 31, 2017, $37.9 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Networking Platforms segment and $63.1 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Software and Software-Related Services. As of October 31, 2017, all of the maintenance spares totaling $46.9 million were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-17-000064:notes:368]
Segment Revenue

[0000936395-17-000064:notes:369]
Segment Profit

[0000936395-17-000064:notes:370]
Segment profit is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; acquisition and integration costs; amortization of intangible assets; significant asset impairments and restructuring costs; interest and other income (loss), net; interest expense; and provision (benefit) for income taxes.

[0000936395-17-000064:notes:371]
Entity Wide Reporting

[0000936395-17-000064:notes:372]
Ciena’s operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia-Pacific (“APAC”); and Caribbean and Latin America (“CALA”). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-17-000064:notes:373]
North America includes $1.63 billion, $1.58 billion and $1.48 billion of United States revenue for fiscal years ended October 31, 2017, 2016 and 2015, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-17-000064:notes:374]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-17-000064:notes:375]
While we have benefited from the diversification of our business and customer base, our ten largest customers contributed 55.6% of fiscal 2017 revenue, 51.1% of fiscal 2016 revenue and 52.5% of fiscal 2015 revenue.

[0000936395-17-000064:notes:376]
Both customers purchased products and services from each of Ciena's operating segments.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-17-000064:notes:377]
STOCKHOLDERS’ EQUITY

[0000936395-17-000064:notes:378]
Call Spread Option

[0000936395-17-000064:notes:379]
Ciena purchased a call spread option relating to the 2017 Notes for $42.5 million during the third quarter of fiscal 2007. The call spread option was designed to mitigate exposure to potential dilution from the conversion of the notes. The call spread option was purchased at the time of the notes offering from an affiliate of the underwriter. The cost of the call spread option was recorded as a reduction in paid-in capital. On June 15, 2017, the outstanding 0.875% Convertible Senior Notes matured and Ciena repaid the approximately $185.3 million in aggregate principal amount outstanding, together with approximately $0.8 million in accrued interest through the date of maturity. At this time, the call spread option relating to the 2017 Notes expired.


## us-gaap:SubsequentEventsTextBlock

[0000936395-17-000064:notes:380]
SUBSEQUENT EVENT

[0000936395-17-000064:notes:381]
On December 7, 2017, Ciena announced that its Board of Directors authorized a program to repurchase up to $300 million of Ciena’s common stock through the end of fiscal 2020. Ciena may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-17-000064:notes:382]
OTHER BALANCE SHEET DETAILS

[0000936395-17-000064:notes:383]
The decreases in the current year warranty provisions and the recording of adjustments on prior year provisions during fiscal 2017, fiscal 2016 and fiscal 2015 were primarily due to lower failure rates than previously estimated, as mentioned above, and reduced costs due to efficiencies.

[0000936395-17-000064:notes:384]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner during the construction period for accounting purposes. As of May 1, 2017, occupancy of both office buildings was complete. As such, Ciena recorded capital leases for these buildings, which will be depreciated over the lease terms, and removed the build-to-suit construction in progress asset and the corresponding long-term liability. See Note 10 for more details regarding this arrangement.
