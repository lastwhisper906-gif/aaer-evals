# CIEN 8-K — 0000936395-17-000057 filed 2017-12-07

## item codes, every 8-K on or before 2017-12-22

- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2017-12-22

- none on or before 2017-12-22

## item 2.02 — earnings release, exhibit 99.1

[0000936395-17-000057:8k_2_02:1]
EX-99.1
2
exhibit9912017q4pressrelea.htm
EXHIBIT 99.1

[0000936395-17-000057:8k_2_02:2]
Exhibit

[0000936395-17-000057:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-17-000057:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2017 and Year-End Financial Results

[0000936395-17-000057:8k_2_02:5]
HANOVER, Md. - December 7, 2017 - Ciena® Corporation (NYSE: CIEN), a network strategy and technology company, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2017.

[0000936395-17-000057:8k_2_02:6]
“Our fourth quarter and fiscal 2017 results reinforce our continued ability to adapt to changing market conditions by growing revenue and expanding profitability as we outperform the industry,” said Gary B. Smith, president and CEO, Ciena. “We are confident that our long-term strategy to scale and diversify our existing business and to expand our addressable market will enable us to continue to grow and generate cash.”

[0000936395-17-000057:8k_2_02:7]
For the fiscal fourth quarter 2017, Ciena reported revenue of $744.4 million as compared to $716.2 million for the fiscal fourth quarter 2016. For fiscal year 2017, Ciena reported revenue of $2.80 billion, as compared to $2.60 billion for fiscal year 2016.

[0000936395-17-000057:8k_2_02:8]
Ciena's fiscal fourth quarter and fiscal year 2017 results reflect a tax benefit of $1.13 billion related to the reversal of a deferred tax asset valuation allowance. As a result, on the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal fourth quarter 2017 was $1.16 billion, or $7.32 per diluted common share, which compares to a GAAP net income of $36.6 million, or $0.25 per diluted common share, for the fiscal fourth quarter 2016. For fiscal year 2017, Ciena had a GAAP net income of $1.26 billion, or $7.53 per diluted common share, which compares to a GAAP net income of $72.6 million or $0.51 per diluted common share for fiscal year 2016.

[0000936395-17-000057:8k_2_02:9]
Consistent with Ciena's historical non-GAAP presentation ("Prior Method"), Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2017 was $68.8 million, or $0.46 per diluted common share, which compares to an adjusted (non-GAAP) net income of $69.4 million, or $0.44 per diluted common share, for the fiscal fourth quarter 2016. For fiscal year 2017, Ciena's adjusted (non-GAAP) net income was $260.5 million, or $1.68 per diluted common share, as compared to an adjusted (non-GAAP) net income of $214.6 million, or $1.38 per diluted common share for fiscal year 2016.

[0000936395-17-000057:8k_2_02:10]
Beginning this quarter, Ciena is changing how it calculates its adjusted (non-GAAP) provision for income taxes in accordance with the SEC's interpretive guidance on non-GAAP financial measures. In order to assist investors in understanding the change, Ciena is providing its calculations of adjusted (non-GAAP) net income under its "Prior Method" and the "New Method" in Appendix B. Under the "New Method," the Non-GAAP tax provision consists of current and deferred income tax expense commensurate with the level of adjusted (non-GAAP) income before income taxes using a current blended U.S. and foreign statutory tax rate (which was 36.5%). Under the "Prior Method," the Non-GAAP tax provision consisted of current and deferred income tax expense, primarily related to

[0000936395-17-000057:8k_2_02:11]
foreign income tax, which is paid using cash. This change in calculation methodology will not affect Ciena's adjusted (non-GAAP) income before income taxes, actual cash tax payments, or cash flows, but will result in significantly higher non-GAAP provisions for income taxes than our "Prior Method" presentation. However, Ciena does not expect to pay substantial cash taxes for the foreseeable future primarily due to its deferred tax asset balance. As of October 31, 2017, Ciena has deferred tax assets, net, of approximately $1.16 billion and, consequently, over the near term Ciena's cash taxes will continue to be primarily driven by the tax expense of its foreign subsidiaries, which amounts have not historically been significant.

[0000936395-17-000057:8k_2_02:12]
Ciena's adjusted "New Method" (non-GAAP) net income for the fiscal fourth quarter 2017 was $48.5 million, or $0.32 per diluted common share, which compares to an adjusted (non-GAAP) net income of $48.1 million, or $0.30 per diluted common share, for the fiscal fourth quarter 2016. For fiscal year 2017, Ciena's adjusted (non-GAAP) net income was $177.7 million, or $1.14 per diluted common share, as compared to an adjusted (non-GAAP) net income of $145.3 million or $0.93 per diluted common share for fiscal year 2016.

[0000936395-17-000057:8k_2_02:13]
Authorization of Share Repurchase Program

[0000936395-17-000057:8k_2_02:14]
In a separate press release today, Ciena announced that its Board of Directors has authorized a program to repurchase up to $300 million of the company’s common stock through the end of fiscal 2020.

[0000936395-17-000057:8k_2_02:15]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2017 Results

[0000936395-17-000057:8k_2_02:16]
Today, Thursday, December 7, 2017, in conjunction with the issuance of this press release, Ciena has posted to the quarterly results page of the Investors section of www.ciena.com an audio recording of management commentary that provides greater context for Ciena's performance to date and its strategy, as well as certain long-term financial targets. Ciena has also posted a transcript of the recording and a related investor presentation to this page. Consistent with past practice, Ciena’s management will host a discussion with investors and financial analysts of its unaudited fiscal fourth quarter 2017 results and fiscal first quarter 2018 outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com. An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website at www.ciena.com/investors.

[0000936395-17-000057:8k_2_02:17]
Fiscal Fourth Quarter 2017 Performance Summary

[0000936395-17-000057:8k_2_02:18]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarterly and year over year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A and B to this release.

[0000936395-17-000057:8k_2_02:19]
|  |  | GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 744.4 |  |  | $ | 728.7 |  |  | $ | 716.2 |  |  | 2.2 | % |  | 3.9 | % |
| Gross margin |  | 43.7 | % |  | 45.0 | % |  | 44.5 | % |  | (1.3 | )% |  | (0.8 | )% |
| Operating expense |  | $ | 269.9 |  |  | $ | 246.1 |  |  | $ | 258.9 |  |  | 9.7 | % |  | 4.2 | % |
| Operating margin |  | 7.5 | % |  | 11.3 | % |  | 8.3 | % |  | (3.8 | )% |  | (0.8 | )% |

[0000936395-17-000057:8k_2_02:20]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 744.4 |  |  | $ | 728.7 |  |  | $ | 716.2 |  |  | 2.2 | % |  | 3.9 | % |
| Adj. gross margin |  | 44.2 | % |  | 45.5 | % |  | 45.2 | % |  | (1.3 | )% |  | (1.0 | )% |
| Adj. operating expense |  | $ | 240.9 |  |  | $ | 229.3 |  |  | $ | 232.4 |  |  | 5.1 | % |  | 3.7 | % |
| Adj. operating margin |  | 11.9 | % |  | 14.1 | % |  | 12.8 | % |  | (2.2 | )% |  | (0.9 | )% |

[0000936395-17-000057:8k_2_02:21]
* Denotes % change, or in the case of margin, absolute change

[0000936395-17-000057:8k_2_02:22]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q4 FY 2017 |  | Q3 FY 2017 |  | Q4 FY 2016 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 504.7 |  |  | 67.8 |  | $ | 506.5 |  |  | 69.5 |  | $ | 488.0 |  |  | 68.1 |
| Packet Networking |  | 92.5 |  |  | 12.5 |  | 82.1 |  |  | 11.3 |  | 72.4 |  |  | 10.1 |
| Optical Transport |  | 1.7 |  |  | 0.2 |  | 3.7 |  |  | 0.5 |  | 5.8 |  |  | 0.8 |
| Total Networking Platforms |  | 598.9 |  |  | 80.5 |  | 592.3 |  |  | 81.3 |  | 566.2 |  |  | 79.0 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms |  | 17.3 |  |  | 2.3 |  | 18.4 |  |  | 2.5 |  | 16.3 |  |  | 2.3 |
| Software-Related Services |  | 24.5 |  |  | 3.3 |  | 23.9 |  |  | 3.3 |  | 21.3 |  |  | 3.0 |
| Total Software and Software-Related Services |  | 41.8 |  |  | 5.6 |  | 42.3 |  |  | 5.8 |  | 37.6 |  |  | 5.3 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 56.2 |  |  | 7.5 |  | 57.9 |  |  | 7.9 |  | 59.8 |  |  | 8.3 |
| Installation and Deployment |  | 33.5 |  |  | 4.5 |  | 27.4 |  |  | 3.8 |  | 38.6 |  |  | 5.4 |
| Consulting and Network Design |  | 14.0 |  |  | 1.9 |  | 8.8 |  |  | 1.2 |  | 14.0 |  |  | 2.0 |
| Total Global Services |  | 103.7 |  |  | 13.9 |  | 94.1 |  |  | 12.9 |  | 112.4 |  |  | 15.7 |
| Total |  | $ | 744.4 |  |  | 100.0 |  | $ | 728.7 |  |  | 100.0 |  | $ | 716.2 |  |  | 100.0 |

[0000936395-17-000057:8k_2_02:23]
Additional Performance Metrics for Fiscal Fourth Quarter 2017

[0000936395-17-000057:8k_2_02:24]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q4 FY 2017 |  | Q3 FY 2017 |  | Q4 FY 2016 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 440.5 |  |  | 59.2 |  | $ | 465.2 |  |  | 63.8 |  | $ | 463.1 |  |  | 64.7 |
| Europe, Middle East and Africa |  | 110.7 |  |  | 14.9 |  | 96.1 |  |  | 13.2 |  | 112.5 |  |  | 15.7 |
| Caribbean and Latin America |  | 43.5 |  |  | 5.8 |  | 51.7 |  |  | 7.1 |  | 46.8 |  |  | 6.5 |
| Asia Pacific |  | 149.7 |  |  | 20.1 |  | 115.7 |  |  | 15.9 |  | 93.8 |  |  | 13.1 |
| Total |  | $ | 744.4 |  |  | 100.0 |  | $ | 728.7 |  |  | 100.0 |  | $ | 716.2 |  |  | 100.0 |

[0000936395-17-000057:8k_2_02:25]
| • | U.S. customers contributed 56% of total revenue |

[0000936395-17-000057:8k_2_02:26]
| • | Two 10%-plus customers represented a total of 27.6% of revenue |

[0000936395-17-000057:8k_2_02:27]
| • | Cash and investments totaled $969.4 million |

[0000936395-17-000057:8k_2_02:28]
| • | Cash flow from operations totaled $138.5 million |

[0000936395-17-000057:8k_2_02:29]
| • | Average days' sales outstanding (DSOs) were 75 |

[0000936395-17-000057:8k_2_02:30]
| • | Accounts receivable balance was $622.2 million |

[0000936395-17-000057:8k_2_02:31]
| • | Inventories totaled $267.1 million, including: |

[0000936395-17-000057:8k_2_02:32]
| ◦ | Raw materials: $52.9 million |

[0000936395-17-000057:8k_2_02:33]
| ◦ | Work in process: $18.6 million |

[0000936395-17-000057:8k_2_02:34]
| ◦ | Finished goods: $185.5 million |

[0000936395-17-000057:8k_2_02:35]
| ◦ | Deferred cost of sales: $61.3 million |

[0000936395-17-000057:8k_2_02:36]
| ◦ | Reserve for excess and obsolescence: $(51.2) million |

[0000936395-17-000057:8k_2_02:37]
| • | Product inventory turns were 5.3 |

[0000936395-17-000057:8k_2_02:38]
| • | Headcount totaled 5,737 |

[0000936395-17-000057:8k_2_02:39]
Notes to Investors

[0000936395-17-000057:8k_2_02:40]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our fourth quarter and fiscal 2017 results reinforce our continued ability to adapt to changing market conditions by growing revenue and expanding profitability as we outperform the industry." and "We are confident that our long-term strategy to scale and diversify our existing business and to expand our addressable market will enable us to continue to grow and generate cash."

[0000936395-17-000057:8k_2_02:41]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Quarterly Report on Form 10-Q filed with the Securities and Exchange Commission (SEC) on September 6, 2017 and Ciena's Annual Report on Form 10-K to be

[0000936395-17-000057:8k_2_02:42]
filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-17-000057:8k_2_02:43]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, and measure of net income and net income per share, in each case, under our "Prior Method" and "New Method" as described above. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. Under the "Prior Method" of calculating adjusted (non-GAAP) net income and net income per share, the Non-GAAP tax provision consists of current and deferred income tax expense, primarily related to foreign income tax, which is paid using cash. Under the "New Method"  of calculating adjusted (non-GAAP) net income and net income per share, the Non-GAAP tax provision consists of current and deferred income tax expense commensurate with the level of adjusted (non-GAAP) income before income taxes using a current blended U.S. and foreign statutory tax rate (which was 36.5%). As such, the tax provision in our adjusted (non-GAAP) net income is presented as a separate and comparative reconciling item. To the extent not previously disclosed in a prior Ciena financial results press release, the Appendix A and B to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-17-000057:8k_2_02:44]
About Ciena.  Ciena (NYSE: CIEN) is a network strategy and technology company. We translate best-in-class technology into value through a high-touch, consultative business model - with a relentless drive to create exceptional experiences measured by outcomes. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-17-000057:8k_2_02:45]
CIENA CORPORATION

[0000936395-17-000057:8k_2_02:46]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-17-000057:8k_2_02:47]
(in thousands, except per share data)

[0000936395-17-000057:8k_2_02:48]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | 616,216 |  |  | 582,455 |  |  | 2,318,581 |  |  | 2,117,472 |  |
| Services |  | 128,233 |  |  | 133,736 |  |  | 483,106 |  |  | 483,101 |  |
| Total revenue |  | 744,449 |  |  | 716,191 |  |  | 2,801,687 |  |  | 2,600,573 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 352,992 |  |  | 324,663 |  |  | 1,308,295 |  |  | 1,176,304 |  |
| Services |  | 65,772 |  |  | 72,980 |  |  | 247,606 |  |  | 262,693 |  |
| Total cost of goods sold |  | 418,764 |  |  | 397,643 |  |  | 1,555,901 |  |  | 1,438,997 |  |
| Gross profit |  | 325,685 |  |  | 318,548 |  |  | 1,245,786 |  |  | 1,161,576 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 119,108 |  |  | 112,448 |  |  | 475,329 |  |  | 451,794 |  |
| Selling and marketing |  | 95,877 |  |  | 96,853 |  |  | 356,169 |  |  | 349,731 |  |
| General and administrative |  | 36,181 |  |  | 32,147 |  |  | 142,604 |  |  | 132,828 |  |
| Amortization of intangible assets |  | 3,661 |  |  | 14,551 |  |  | 33,029 |  |  | 61,508 |  |
| Acquisition and integration costs |  | — |  |  | — |  |  | — |  |  | 4,613 |  |
| Significant asset impairments and restructuring costs |  | 15,059 |  |  | 2,876 |  |  | 23,933 |  |  | 4,933 |  |
| Total operating expenses |  | 269,886 |  |  | 258,875 |  |  | 1,031,064 |  |  | 1,005,407 |  |
| Income from operations |  | 55,799 |  |  | 59,673 |  |  | 214,722 |  |  | 156,169 |  |
| Interest and other income (loss), net |  | 652 |  |  | (1,339 | ) |  | (2,744 | ) |  | (12,795 | ) |
| Interest expense |  | (13,926 | ) |  | (15,371 | ) |  | (55,852 | ) |  | (56,656 | ) |
| Income before income taxes |  | 42,525 |  |  | 42,963 |  |  | 156,126 |  |  | 86,718 |  |
| Provision (benefit) for income taxes |  | (1,117,531 | ) |  | 6,376 |  |  | (1,105,827 | ) |  | 14,134 |  |
| Net income |  | $ | 1,160,056 |  |  | $ | 36,587 |  |  | $ | 1,261,953 |  |  | $ | 72,584 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| Basic net income per common share |  | $ | 8.11 |  |  | $ | 0.26 |  |  | $ | 8.89 |  |  | $ | 0.52 |  |
| Diluted net income per potential common share1 |  | $ | 7.32 |  |  | $ | 0.25 |  |  | $ | 7.53 |  |  | $ | 0.51 |  |
| Weighted average basic common shares outstanding |  | 143,097 |  |  | 139,741 |  |  | 141,997 |  |  | 138,312 |  |
| Weighted average diluted potential common shares outstanding 2 |  | 158,791 |  |  | 165,298 |  |  | 169,919 |  |  | 150,704 |  |

[0000936395-17-000057:8k_2_02:49]
1.  The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2017 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $2.3 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-17-000057:8k_2_02:50]
The calculation of GAAP diluted net income per common share for fiscal 2017 requires adding back interest expense of approximately $0.9 million associated with Ciena's 0.875% convertible senior notes which were paid at maturity during the third quarter of fiscal 2017, approximately $7.2 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $8.7 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-17-000057:8k_2_02:51]
The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2016 requires adding back interest expense of approximately $0.7 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, and approximately $3.6 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-17-000057:8k_2_02:52]
The calculation of GAAP diluted net income per common share for fiscal 2016 requires adding back interest expense of approximately $4.8 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-17-000057:8k_2_02:53]
2. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2017 includes 1.2 million shares underlying certain stock options and restricted stock units, 1.6 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.7 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million share underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:54]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units, 0.4 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.0 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 13.9 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million share underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:55]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2016 includes 1.6 million shares underlying certain stock options and restricted stock units, 6.6 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 and 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018.

[0000936395-17-000057:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2016 includes 1.3 million shares underlying certain stock options and restricted stock units and 11.1 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017.

[0000936395-17-000057:8k_2_02:57]
CIENA CORPORATION

[0000936395-17-000057:8k_2_02:58]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-17-000057:8k_2_02:59]
(in thousands, except share data)

[0000936395-17-000057:8k_2_02:60]
|  | October 31, |
|  | 2017 |  | 2016 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 640,513 |  |  | $ | 777,615 |  |
| Short-term investments | 279,133 |  |  | 275,248 |  |
| Accounts receivable, net | 622,183 |  |  | 576,235 |  |
| Inventories | 267,143 |  |  | 211,251 |  |
| Prepaid expenses and other | 197,339 |  |  | 172,843 |  |
| Total current assets | 2,006,311 |  |  | 2,013,192 |  |
| Long-term investments | 49,783 |  |  | 90,172 |  |
| Equipment, building, furniture and fixtures, net | 308,465 |  |  | 288,406 |  |
| Goodwill | 267,458 |  |  | 266,974 |  |
| Other intangible assets, net | 100,997 |  |  | 146,711 |  |
| Deferred tax asset, net | 1,155,104 |  |  | 1,116 |  |
| Other long-term assets | 63,593 |  |  | 67,004 |  |
| Total assets | $ | 3,951,711 |  |  | $ | 2,873,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 260,098 |  |  | $ | 235,942 |  |
| Accrued liabilities and other short-term obligations | 322,934 |  |  | 310,353 |  |
| Deferred revenue | 102,418 |  |  | 109,009 |  |
| Current portion of long-term debt | 352,293 |  |  | 236,241 |  |
| Total current liabilities | 1,037,743 |  |  | 891,545 |  |
| Long-term deferred revenue | 82,589 |  |  | 73,854 |  |
| Other long-term obligations | 111,349 |  |  | 124,394 |  |
| Long-term debt, net | 583,688 |  |  | 1,017,441 |  |
| Total liabilities | $ | 1,815,369 |  |  | $ | 2,107,234 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 143,043,227 and 139,767,627 shares issued and outstanding | 1,430 |  |  | 1,398 |  |
| Additional paid-in capital | 6,810,182 |  |  | 6,715,478 |  |
| Accumulated other comprehensive loss | (11,017 | ) |  | (24,329 | ) |
| Accumulated deficit | (4,664,253 | ) |  | (5,926,206 | ) |
| Total stockholders’ equity | 2,136,342 |  |  | 766,341 |  |
| Total liabilities and stockholders’ equity | $ | 3,951,711 |  |  | $ | 2,873,575 |  |

[0000936395-17-000057:8k_2_02:61]
CIENA CORPORATION

[0000936395-17-000057:8k_2_02:62]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-17-000057:8k_2_02:63]
(in thousands)

[0000936395-17-000057:8k_2_02:64]
|  | Year Ended October 31, |
|  | 2017 |  | 2016 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 1,261,953 |  |  | $ | 72,584 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 77,189 |  |  | 63,394 |  |
| Share-based compensation costs | 48,360 |  |  | 51,993 |  |
| Amortization of intangible assets | 45,713 |  |  | 78,298 |  |
| Deferred taxes | (1,126,732 | ) |  | (1,116 | ) |
| Provision for doubtful accounts | 18,221 |  |  | 1,701 |  |
| Provision for inventory excess and obsolescence | 35,459 |  |  | 33,713 |  |
| Provision for warranty | 7,965 |  |  | 15,483 |  |
| Other | 22,417 |  |  | 24,929 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (66,123 | ) |  | (26,074 | ) |
| Inventories | (91,567 | ) |  | (53,000 | ) |
| Prepaid expenses and other | (33,834 | ) |  | 30,047 |  |
| Accounts payable, accruals and other obligations | 33,897 |  |  | 7,153 |  |
| Deferred revenue | 1,964 |  |  | (9,585 | ) |
| Net cash provided by operating activities | 234,882 |  |  | 289,520 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (94,600 | ) |  | (107,185 | ) |
| Restricted cash | (54 | ) |  | 11 |  |
| Purchase of available for sale securities | (299,038 | ) |  | (365,191 | ) |
| Proceeds from maturities of available for sale securities | 335,075 |  |  | 230,612 |  |
| Settlement of foreign currency forward contracts, net | (2,810 | ) |  | (18,506 | ) |
| Purchase of cost method investment | — |  |  | (4,000 | ) |
| Acquisition of business, net of cash acquired | — |  |  | (32,000 | ) |
| Net cash used in investing activities | (61,427 | ) |  | (296,259 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | — |  |  | 248,750 |  |
| Payment of long-term debt | (233,554 | ) |  | (266,116 | ) |
| Payment for modification of term loans | (93,625 | ) |  | — |  |
| Payment of debt and equity issuance costs | (722 | ) |  | (3,987 | ) |
| Payment of capital lease obligations | (3,562 | ) |  | (5,966 | ) |
| Proceeds from issuance of common stock | 20,412 |  |  | 23,091 |  |
| Net cash used in financing activities | (311,051 | ) |  | (4,228 | ) |
| Effect of exchange rate changes on cash and cash equivalents | 494 |  |  | (2,389 | ) |
| Net decrease in cash and cash equivalents | (137,102 | ) |  | (13,356 | ) |
| Cash and cash equivalents at beginning of fiscal year | 777,615 |  |  | 790,971 |  |
| Cash and cash equivalents at end of fiscal year | $ | 640,513 |  |  | $ | 777,615 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 47,235 |  |  | $ | 46,897 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 33,166 |  |  | $ | 15,268 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 6,214 |  |  | $ | 15,030 |  |
| Equipment acquired under capital leases | $ | — |  |  | $ | 5,322 |  |
| Building subject to capital lease | $ | 50,370 |  |  | $ | 8,993 |  |
| Construction in progress subject to build-to-suit lease | $ | — |  |  | $ | 39,914 |  |

[0000936395-17-000057:8k_2_02:65]
| APPENDIX A- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 325,685 |  |  | $ | 318,548 |  |  | $ | 1,245,786 |  |  | $ | 1,161,576 |  |
| Share-based compensation-products |  | 694 |  |  | 612 |  |  | 2,672 |  |  | 2,457 |  |
| Share-based compensation-services |  | 561 |  |  | 557 |  |  | 2,487 |  |  | 2,479 |  |
| Amortization of intangible assets |  | 2,332 |  |  | 4,320 |  |  | 12,685 |  |  | 16,401 |  |
| Total adjustments related to gross profit |  | 3,587 |  |  | 5,489 |  |  | 17,844 |  |  | 21,337 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 329,272 |  |  | $ | 324,037 |  |  | $ | 1,263,630 |  |  | $ | 1,182,913 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 44.2 | % |  | 45.2 | % |  | 45.1 | % |  | 45.5 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 269,886 |  |  | $ | 258,875 |  |  | $ | 1,031,064 |  |  | $ | 1,005,407 |  |
| Share-based compensation-research and development |  | 2,956 |  |  | 3,172 |  |  | 12,957 |  |  | 13,870 |  |
| Share-based compensation-sales and marketing |  | 3,218 |  |  | 2,890 |  |  | 12,846 |  |  | 15,138 |  |
| Share-based compensation-general and administrative |  | 4,130 |  |  | 2,961 |  |  | 17,321 |  |  | 17,342 |  |
| Share-based compensation-acquisition related |  | — |  |  | — |  |  | — |  |  | 714 |  |
| Amortization of intangible assets |  | 3,661 |  |  | 14,551 |  |  | 33,029 |  |  | 61,508 |  |
| Acquisition and integration costs, excluding share-based compensation |  | — |  |  | — |  |  | — |  |  | 3,899 |  |
| Significant asset impairments and restructuring costs |  | 15,059 |  |  | 2,876 |  |  | 23,933 |  |  | 4,933 |  |
| Settlement of patent litigation |  | — |  |  | — |  |  | — |  |  | 1,200 |  |
| Total adjustments related to operating expense |  | $ | 29,024 |  |  | $ | 26,450 |  |  | $ | 100,086 |  |  | $ | 118,604 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 240,862 |  |  | $ | 232,425 |  |  | $ | 930,978 |  |  | $ | 886,803 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 55,799 |  |  | $ | 59,673 |  |  | $ | 214,722 |  |  | $ | 156,169 |  |
| Total adjustments related to gross profit |  | 3,587 |  |  | 5,489 |  |  | 17,844 |  |  | 21,337 |  |
| Total adjustments related to operating expense |  | 29,024 |  |  | 26,450 |  |  | 100,086 |  |  | 118,604 |  |
| Total adjustments related to income from operations |  | 32,611 |  |  | 31,939 |  |  | 117,930 |  |  | 139,941 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 88,410 |  |  | $ | 91,612 |  |  | $ | 332,652 |  |  | $ | 296,110 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 11.9 | % |  | 12.8 | % |  | 11.9 | % |  | 11.4 | % |

[0000936395-17-000057:8k_2_02:66]
| APPENDIX B- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | (New Method) |  | (Prior Method) |
|  |  | Quarter Ended |  | Year Ended |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |  | October 31, |  | October 31, |
|  |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 1,160,056 |  |  | $ | 36,587 |  |  | $ | 1,261,953 |  |  | $ | 72,584 |  |  | $ | 1,160,056 |  |  | $ | 36,587 |  |  | $ | 1,261,953 |  |  | $ | 72,584 |  |
| Exclude GAAP provision (benefit) for income taxes |  | (1,117,531 | ) |  | 6,376 |  |  | (1,105,827 | ) |  | 14,134 |  |  | (1,117,531 | ) |  | 6,376 |  |  | (1,105,827 | ) |  | 14,134 |  |
| Income before income taxes |  | 42,525 |  |  | 42,963 |  |  | 156,126 |  |  | 86,718 |  |  | 42,525 |  |  | 42,963 |  |  | 156,126 |  |  | 86,718 |  |
| Total adjustments related to income from operations |  | 32,611 |  |  | 31,939 |  |  | 117,930 |  |  | 139,941 |  |  | 32,611 |  |  | 31,939 |  |  | 117,930 |  |  | 139,941 |  |
| Loss on extinguishment of debt |  | — |  |  | 376 |  |  | 41 |  |  | 226 |  |  | — |  |  | 376 |  |  | 41 |  |  | 226 |  |
| Non-cash interest expense |  | 525 |  |  | 500 |  |  | 2,099 |  |  | 1,881 |  |  | 525 |  |  | 500 |  |  | 2,099 |  |  | 1,881 |  |
| Modification of debt |  | 692 |  |  | — |  |  | 3,616 |  |  | — |  |  | 692 |  |  | — |  |  | 3,616 |  |  | — |  |
| Adjusted income before income taxes |  | 76,353 |  |  | 75,778 |  |  | 279,812 |  |  | 228,766 |  |  | 76,353 |  |  | 75,778 |  |  | 279,812 |  |  | 228,766 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 27,869 |  |  | 27,659 |  |  | 102,131 |  |  | 83,500 |  |  | 7,597 |  |  | 6,376 |  |  | 19,301 |  |  | 14,134 |  |
| Adjusted (non-GAAP) net income |  | $ | 48,484 |  |  | $ | 48,119 |  |  | $ | 177,681 |  |  | $ | 145,266 |  |  | $ | 68,756 |  |  | $ | 69,402 |  |  | $ | 260,511 |  |  | $ | 214,632 |  |
| Weighted average basic common shares outstanding |  | 143,097 |  |  | 139,741 |  |  | 141,997 |  |  | 138,312 |  |  | 143,097 |  |  | 139,741 |  |  | 141,997 |  |  | 138,312 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 158,791 |  |  | 174,496 |  |  | 169,919 |  |  | 177,258 |  |  | 158,791 |  |  | 174,496 |  |  | 169,919 |  |  | 177,258 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 7.32 |  |  | $ | 0.25 |  |  | $ | 7.53 |  |  | $ | 0.51 |  |  | $ | 7.32 |  |  | $ | 0.25 |  |  | $ | 7.53 |  |  | $ | 0.51 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.32 |  |  | $ | 0.30 |  |  | $ | 1.14 |  |  | $ | 0.93 |  |  | $ | 0.46 |  |  | $ | 0.44 |  |  | $ | 1.68 |  |  | $ | 1.38 |  |

[0000936395-17-000057:8k_2_02:67]
1.  Weighted average dilutive potential common shares outstanding used in calculating New Method and Prior Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2017 includes 1.2 million shares underlying certain stock options and restricted stock units, 1.6 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.7 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:68]
Weighted average dilutive potential common shares outstanding used in calculating New Method and Prior Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2016 includes 1.6 million shares underlying certain stock options and restricted stock units, 6.6 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:69]
Weighted average dilutive potential common shares outstanding used in calculating New Method and Prior Method adjusted (non-GAAP) diluted net income per common share for fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units, 0.4 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.0 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 13.9 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million share underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:70]
Weighted average dilutive potential common shares outstanding used in calculating New Method and Prior Method adjusted (non-GAAP) diluted net income per common share for fiscal 2016 includes 1.3 million shares underlying certain stock options and restricted stock units, 11.1 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million share underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000057:8k_2_02:71]
2.  The calculation of New Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2017 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $1.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the New Method adjusted (non-GAAP) net income in order to derive the numerator for the New Method adjusted earnings per common share calculation.

[0000936395-17-000057:8k_2_02:72]
The calculation of Prior Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2017 requires adding back interest expense of approximately $0.6 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $3.1 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Prior Method adjusted (non-GAAP) net income in order to derive the numerator for the Prior Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:73]
The calculation of New Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2016 requires adding back interest expense of approximately $0.5 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $2.3 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $1.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the New Method adjusted (non-GAAP) net income in order to derive the numerator for the New Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:74]
The calculation of Prior Method adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2016 requires adding back interest expense of approximately $0.7 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $3.6 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $2.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Prior Method adjusted (non-GAAP) net income in order to derive the numerator for the Prior Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:75]
The calculation of New Method adjusted (non-GAAP) diluted net income per common share for fiscal 2017 requires adding back interest expense of  approximately $0.9 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $7.2 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $7.4 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the New Method  adjusted (non-GAAP) net income in order to derive the numerator for the New Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:76]
The calculation of Prior Method adjusted (non-GAAP) diluted net income per common share for fiscal 2017 requires adding back interest expense of  approximately $1.3 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $11.4 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $11.6 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Prior Method adjusted (non-GAAP) net income in order to derive the numerator for the Prior Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:77]
The calculation of New Method adjusted (non-GAAP) diluted net income per common share for fiscal 2016 requires adding back interest expense of approximately $3.0 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $9.1 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $7.2 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the New Method adjusted (non-GAAP) net income in order to derive the numerator for the New Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:78]
The calculation of Prior Method adjusted (non-GAAP) diluted net income per common share for fiscal 2016 requires adding back interest expense of  approximately $4.8 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $14.3 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $11.4 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Prior Method adjusted (non-GAAP) net income in order to derive the numerator for the Prior Method adjusted (non-GAAP) earnings per common share calculation.

[0000936395-17-000057:8k_2_02:79]
* * *

[0000936395-17-000057:8k_2_02:80]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-17-000057:8k_2_02:81]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-17-000057:8k_2_02:82]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our recent acquisitions of Cyan and TeraXion. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-17-000057:8k_2_02:83]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over the expected useful life. |

[0000936395-17-000057:8k_2_02:84]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and a significant asset impairment for a trade receivable for a customer in the Asia Pacific region. |

[0000936395-17-000057:8k_2_02:85]
| • | Settlement of patent litigation - included in general and administrative expense is a $1.2 million patent litigation settlement during the second quarter of fiscal 2016. |

[0000936395-17-000057:8k_2_02:86]
| • | Loss on extinguishment of debt - losses related to certain private repurchase transactions during fiscal 2016 and 2017 of Ciena's then outstanding 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-17-000057:8k_2_02:87]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-17-000057:8k_2_02:88]
| • | Modification of debt - costs incurred as a result of the modification of debt to refinance then existing term loans and an exchange offer for Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018. |

[0000936395-17-000057:8k_2_02:89]
| • | Non-GAAP tax provision - Beginning this quarter, Ciena is changing how it calculates its adjusted (non-GAAP) provision for income taxes in accordance with the SEC guidance on non-GAAP financial measures. Under the "New Method," the Non-GAAP tax provision consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes using a current blended U.S. and foreign statutory tax rate (which was 36.5%). This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. Under the "Prior Method," the Non-GAAP tax provision consists of current and deferred income tax expense, and primarily related to foreign income tax, which is paid using cash. This change in calculation methodology will not affect Ciena's adjusted income before income taxes, actual cash tax payments, or cash flows, but will result in significantly higher non-GAAP provisions for income taxes compared to our "Prior Method" Non-GAAP presentation. Ciena, however, does not expect to pay substantial cash taxes for the foreseeable future primarily due to Ciena's deferred tax asset balance. Ciena's foreign and domestic income tax expense which will be paid using cash was $7.6 million and $6.4 million for the fourth quarter of fiscal 2017 and 2016, respectively, and $19.3 million and $14.1 million for the fiscal 2017 and 2016, respectively. As of October 31, 2017, Ciena has deferred tax assets, net of approximately $1.16 billion, and consequently, over the near term, Ciena's cash taxes will continue to be primarily related to the tax expense of Ciena's foreign subsidiaries, which amounts have not historically been significant. |
