# CIEN MD&A — 0000936395-15-000062


## mdna

[0000936395-15-000062:mdna:1]
Item 7.    Management's Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-15-000062:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-15-000062:mdna:3]
Overview

[0000936395-15-000062:mdna:4]
We are a network specialist focused on providing communications networking solutions that enable a wide range of network operators to adopt next-generation architectures. We have optimized our business and solutions to enable network operators to create and deliver the broad array of high-bandwidth services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. In addition to our high-capacity hardware platforms, we offer network management and control software platforms that help network operators simplify and automate their networks and virtualize certain network functions. Our solutions are designed to enable network operators to adopt open, multi-vendor, software-programmable network infrastructures that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to introduce new, revenue-generating services and to reduce network complexity and expense.

[0000936395-15-000062:mdna:5]
Our Converged Packet Optical, Packet Networking and Optical Transport products are used, individually or as part of an integrated solution, by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other network operators across the globe. Our products, which support applications from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Our software solutions are oriented around our Blue Planet software platform, a modular, network virtualization, service orchestration and network management software platform designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of network transformation and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-15-000062:mdna:6]
The rapid proliferation of communications services and devices, together with increased mobility, growth in video, cloud-based services and data center interconnection, have fundamentally affected the bandwidth and service demands placed upon communications networks. As the capacity of their network infrastructures are pressured, many network operators also face a rapidly changing business environment and shifting competitive landscape. Newer market entrants, such as cloud service and over-the-top content providers, are challenging certain traditional business models. Our OPn Architecture, which enables increased network scalability, flexibility and programmability, is designed to meet these challenges. It allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and other network resources. This approach enables highly configurable network infrastructures that can meet the “on-demand” service requirements of both our customers and their end-users. By enhancing software-based management and control, enabling network functions to be provided virtually, and reducing required network elements, our OPn approach optimizes network infrastructures. At the same time, it increases network scale at reduced cost and simplifies the management, deployment and orchestration of multi-vendor hardware and software elements. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the “Strategy” section of the description of our business in Item 1 of Part I of this report.

[0000936395-15-000062:mdna:7]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-15-000062:mdna:8]
Acquisition of Cyan, Inc.

[0000936395-15-000062:mdna:9]
On August 3, 2015, we acquired Cyan, Inc. (“Cyan”), a leading provider of software-defined networking (SDN), network function virtualization (NFV) and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all then-outstanding Cyan stock options and unvested

[0000936395-15-000062:mdna:10]
restricted stock unit awards and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock. See Note 2 to our Consolidated Financial Statements included in in Item 8 of Part II of this report for more information relating to this transaction.

[0000936395-15-000062:mdna:11]
Our acquisition of Cyan is intended to advance a strategy that started with the introduction of our OPn Architecture and was extended with the launch of our Agility software division in fiscal 2014. We believe that Cyan's best-in-class Blue Planet software solutions portfolio will significantly strengthen our software offering. Complementing Ciena's network control and application software technologies, Cyan adds multi-vendor network virtualization, service orchestration and next-generation network management software. The Blue Planet portfolio offers a carrier-grade, multi-vendor SDN and NFV platform designed to automate, orchestrate, and manage the lifecycle of virtualized services across data centers and the wide area network (WAN). Further strengthening our leadership in packet-optical hardware products, Cyan brings a metro packet-optical business with a complementary base of key customers for its family of Z-Series high-capacity, multi-layer switching and transport platforms. We believe that this strategic acquisition will accelerate our availability to offer a complete, on-demand solution for virtualized networks and services in an open ecosystem, and will increase our opportunity to play a leading role in the transformation of the network from the delivery of capacity to the creation of service capability on-demand.

[0000936395-15-000062:mdna:12]
In connection with our acquisition of Cyan, during the fourth quarter of fiscal 2015, we unified the software resources and activities of both companies under a single brand and comprehensive set of resources known as the "Blue Planet" division. This division, which includes Ciena's former Agility division, is focused on providing next-generation, multi-vendor network virtualization, service orchestration and management solutions. For fiscal 2015, revenue from Cyan's packet-optical solutions is included in our Converged Packet Optical operating segment and revenue from its Blue Planet software solutions is included in our Software and Services operating segment. See Note 24 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to our operating segments for fiscal 2016.

[0000936395-15-000062:mdna:13]
During fiscal 2015, we incurred approximately $25.5 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other  employment-related costs, including payments to certain former Cyan executives and approximately $7.6 million of non-cash share-based compensation expense. We also expect our future financial results to be impacted, in a number of ways, as a result of the purchase accounting for the Cyan transaction. We recorded finite-lived intangible assets such as developed technology, customer relationships, trademarks, and trade names, the amortization of which will increase our expense during the useful life of these assets.

[0000936395-15-000062:mdna:14]
Market Opportunity

[0000936395-15-000062:mdna:15]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, increased mobility, and evolving cloud-based service offerings and end-user service demands. These conditions have placed significant demands on network infrastructures. They have also created market opportunities and challenged the business models and competitive landscapes of network operators, and the vendors that support them. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services. At the same time, network operators continue to seek to manage the costs of their networks and to ensure a profitable business model. These dynamics are driving technology convergence of network features, functions and layers, virtualization of certain network functions, and solutions that leverage increased software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that these conditions will require network operators and vendors alike to utilize an ecosystem of physical and virtual network resources provided by a variety of third parties, driving increased openness and interoperability of network infrastructures.

[0000936395-15-000062:mdna:16]
During fiscal 2015, we saw certain of our service provider customers increase efforts to constrain capital expenditure budgets, which adversely impacted certain segments of our market, including in the U.S. Notwithstanding these market dynamics, which together with certain customer-specific factors affecting spending, impacted our markets, our revenue increased during fiscal 2015. Increased revenue benefited from our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers, cable and multiservice operators, and additional service providers in geographies including Brazil and India, and our strategy of focusing on certain higher growth segments of the network infrastructure market, including Webscale providers. Our fiscal 2015 revenue also benefited from the addition of revenue from our acquisition of Cyan during the fourth quarter of fiscal 2015. Our corporate strategy to capitalize on these market dynamics, promote operational efficiency and drive profitable growth of our business includes the initiatives set forth in the "Strategy" section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-15-000062:mdna:17]
Competitive Landscape

[0000936395-15-000062:mdna:18]
The markets in which we compete are characterized by rapidly advancing technologies, introduction of new networking solutions and intense selling efforts to displace incumbent vendors and to capture market share. We continue to encounter a highly competitive and fragmented marketplace for our solutions. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approach. We expect the competitive landscape in which we operate to continue to broaden and to remain challenging and dynamic. As we expand our solutions offering, including our sales of Packet Networking solutions such as our 8700 Packetwave Platform, and our Waveserver data center interconnect (DCI) platform, we expect that our business will overlap more directly with additional networking solution suppliers, including IP router vendors, data center switch providers and other suppliers or integrators of networking technology traditionally geared toward different network applications, layers or functions. In addition, as we seek adoption of our Blue Planet software platform, and network operator demands for software programmability, management and control increase, we expect increasingly to compete with software vendors, information technology vendors or integrators of these solutions to promote our network architectural approach. We may also face increased competition from companies, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware, particularly where our customer's network strategies seek to emphasize deployment of those product offerings.

[0000936395-15-000062:mdna:19]
Against the backdrop of these competitive dynamics, maintaining incumbency with key customers  around the globe, and securing new opportunities with a diverse set of network operators, often requires that we agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously and may in the future adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also lengthen our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-15-000062:mdna:20]
Convertible Notes Indebtedness

[0000936395-15-000062:mdna:21]
Maturity of 4.0% Convertible Senior Notes due 2015. On March 15, 2015, our outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture governing the 2015 Notes, together with certain private exchange transactions conducted by us prior to maturity, approximately $180.6 million in aggregate principal amount of the 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of the 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, we issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. We repaid in cash approximately $6.9 million in aggregate principal amount of the 2015 Notes at maturity.

[0000936395-15-000062:mdna:22]
Assumption and Conversion of Cyan Convertible Notes. Upon the closing of our acquisition of Cyan, we assumed its $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of the 2019 Notes. During the fourth quarter of fiscal 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes surrendered their notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, during the fourth quarter of fiscal 2015, we issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

[0000936395-15-000062:mdna:23]
See Note 15 to our Consolidated Financial Statements included in in Item 8 of Part II of this report for more information relating to our outstanding convertible notes.

[0000936395-15-000062:mdna:24]
Financial Results for Fourth Quarter of Fiscal 2015

[0000936395-15-000062:mdna:25]
Revenue for the fourth quarter of fiscal 2015 was $692.0 million, representing a sequential increase of 14.8% from $602.9 million in the third quarter of fiscal 2015. Fourth quarter revenue includes $84.4 million from products and services relating to the Cyan business acquired on August 3, 2015. Revenue-related details reflecting sequential changes from the third quarter of fiscal 2015 include the following:

[0000936395-15-000062:mdna:26]
| • | Product revenue for the fourth quarter of fiscal 2015 increased by $80.4 million, primarily reflecting increases of $76.3 million in Converged Packet Optical and $6.5 million in Packet Networking. These increases were partially offset by a decrease of $1.7 million in software. Increased Converged Packet Optical revenue reflects $81.0 million |

[0000936395-15-000062:mdna:27]
relating to the Z-Series Packet-Optical Platform acquired from Cyan. Sales of this platform primarily benefited from significantly increased sales to Windstream Corporation, which has been participating in certain U.S. government-supported funding programs at levels that we do not expect to recur. Accordingly, we expect quarterly revenue for this product during fiscal 2016 to decrease considerably from the level attained in the fourth quarter.

[0000936395-15-000062:mdna:28]
| • | Service revenue for the fourth quarter of fiscal 2015 increased by $8.7 million, inclusive of $3.4 million from the acquired Cyan business. |

[0000936395-15-000062:mdna:29]
| • | Revenue from North America for the fourth quarter of fiscal 2015 was $480.0 million, an increase from $389.6 million in the third quarter of fiscal 2015. This primarily reflects increases of $75.7 million in Converged Packet Optical, $7.6 million in Packet Networking, and $6.8 million in Software and Services. |

[0000936395-15-000062:mdna:30]
| • | Europe, Middle East and Africa ("EMEA") revenue for the fourth quarter of fiscal 2015 was $94.0 million, a slight increase from $93.2 million in the third quarter of fiscal 2015. This primarily reflects an increase of $2.3 million in Converged Packet Optical, partially offset by a decrease of $1.0 million in Software and Services. |

[0000936395-15-000062:mdna:31]
| • | Caribbean and Latin America ("CALA") revenue for the fourth quarter of fiscal 2015 was $45.7 million, a decrease from $65.1 million in the third quarter of fiscal 2015. This primarily reflects a decrease of $21.4 million in Converged Packet Optical offset by an increase of $2.5 million in Software and Services. |

[0000936395-15-000062:mdna:32]
| • | Asia Pacific ("APAC") revenue for the fourth quarter of fiscal 2015 was $72.3 million, an increase from $55.0 million in the third quarter of fiscal 2015. This primarily reflects an increase of $19.7 million in Converged Packet Optical, partially offset by a decrease of $1.5 million in Software and Services. |

[0000936395-15-000062:mdna:33]
| • | For the fourth quarter of fiscal 2015, AT&T and Windstream Corporation accounted for 19.1% and 10.5%, respectively, of total revenue. For the third quarter of fiscal 2015, AT&T accounted for 20.2% of total revenue and no other customer accounted for 10% or more of revenue. |

[0000936395-15-000062:mdna:34]
Gross margin for the fourth quarter of fiscal 2015 was 43.8%, a decrease from 44.8% in the third quarter of fiscal 2015. Gross margin for the fourth quarter of fiscal 2015 was adversely affected by the strong sales volume of lower margin Z-Series Packet-Optical Platform and the impact of certain items relating to the purchase accounting for the Cyan acquisition that increased costs of goods sold during the quarter. These items included the revaluation of the acquired Cyan inventory and increased expense for amortization of acquired intangible assets.

[0000936395-15-000062:mdna:35]
Operating expense was $293.6 million for the fourth quarter of fiscal 2015, a $68.2 million increase from $225.4 million in the third quarter of fiscal 2015. This increase principally reflects $60.2 million of operating expense resulting from the Cyan acquisition, including $25.4 million related to amortization of acquired intangible assets, $19.6 million in acquisition and integration costs, $8.2 million in research and development expense, and $7.0 million in selling and marketing expense. The remaining operating expense increase of $8.0 million primarily reflects increases of $4.4 million in selling and marketing expense, due to incentive compensation, and $4.1 million in general and administrative expense, primarily due to increased performance-based stock compensation expense.

[0000936395-15-000062:mdna:36]
Reflecting the increases in operating expense above, income from operations for the fourth quarter of fiscal 2015 was $9.4 million, as compared to $44.5 million during the third quarter of fiscal 2015. Due primarily to the fluctuation in foreign currency exchange rates, net of hedging, we incurred losses in interest and other income, net of $6.2 million and $5.5 million during the fourth quarter of fiscal 2015 and the third quarter of fiscal 2015, respectively. Our net loss for the fourth quarter of fiscal 2015 was $13.8 million, or $0.10 per diluted common share. This compares to a net income of $23.6 million or $0.19 per diluted common share, for the third quarter of fiscal 2015.

[0000936395-15-000062:mdna:37]
We generated $84.6 million of cash from operations during the fourth quarter of fiscal 2015. This compares with $117.5 million in cash generated from operations during the third quarter of fiscal 2015. As of October 31, 2015, we had $791.0 million in cash and cash equivalents, $135.1 million of short-term investments in U.S. treasury securities and commercial paper and $95.1 million of long-term investments in U.S. treasury securities. This compares to $697.1 million in cash and cash equivalents, $160.1 million of short-term investments in U.S. treasury securities and commercial paper, and $70.2 million of long-term investments in U.S. treasury securities at July 31, 2015.

[0000936395-15-000062:mdna:38]
As of October 31, 2015, we had 5,345 employees, an increase from 5,196 as of July 31, 2015 and an increase from 5,161 and 4,754 at October 31, 2014 and 2013, respectively.

[0000936395-15-000062:mdna:39]
Consolidated Results of Operations

[0000936395-15-000062:mdna:40]
Operating Segments

[0000936395-15-000062:mdna:41]
For the periods covered by this report, Ciena’s internal organizational structure and the management of its business were grouped into the following operating segments, each of which is more fully described in the "Products and Services" section of the description of our business in Item 1 of Part I of this annual report:

[0000936395-15-000062:mdna:42]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature our WaveLogic coherent optical processors. Products also include Waveserver, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. Revenue from sales of the Z-Series Packet-Optical Platform acquired from Cyan is included in our Converged Packet Optical segment. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:mdna:43]
| • | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes the 8700 Packetwave Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:mdna:44]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:mdna:45]
| • | Software and Services — includes the sale of network management solutions, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. This segment includes sales of Ciena's Blue Planet software platform, a modular network virtualization, service orchestration and network management software solution, and Ciena's SDN Multilayer WAN Controller and its related applications. This segment includes a broad range of services for consulting and network design, installation and deployment, software subscription, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:mdna:46]
Fiscal 2014 compared to Fiscal 2015

[0000936395-15-000062:mdna:47]
Revenue

[0000936395-15-000062:mdna:48]
During fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and the Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars during fiscal 2015 was adversely impacted by approximately $48.4 million, or 1.9%, as compared to fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000062:mdna:49]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,455,501 |  |  | 63.6 |  | $ | 1,661,702 |  |  | 67.9 |  | $ | 206,201 |  |  | 14.2 |  |
| Packet Networking | 244,116 |  |  | 10.7 |  | 229,223 |  |  | 9.4 |  | (14,893 | ) |  | (6.1 | ) |
| Optical Transport | 127,215 |  |  | 5.6 |  | 73,004 |  |  | 3.0 |  | (54,211 | ) |  | (42.6 | ) |
| Software and Services | 461,457 |  |  | 20.1 |  | 481,740 |  |  | 19.7 |  | 20,283 |  |  | 4.4 |  |
| Consolidated revenue | $ | 2,288,289 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |  |

[0000936395-15-000062:mdna:50]
_________________________________

[0000936395-15-000062:mdna:51]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:52]
| • | Converged Packet Optical revenue increased, reflecting a $139.7 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures, and a $19.1 million increase in sales of the OTN configuration for the 5410 Reconfigurable Switching System. Increased revenue also reflects the addition of $81.0 million relating to the Z-Series Packet-Optical Platform acquired from Cyan. These increases were partially offset by decreases of $16.8 million in sales of our CoreDirector® Multiservice Optical Switches and $16.8 million in sales of our 5430 Reconfigurable Switching System. The strong performance of this segment, particularly as compared to the expected and continued revenue declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000062:mdna:53]
| • | Packet Networking revenue decreased, reflecting decreases of $15.8 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $2.6 million in sales of our legacy broadband products. These decreases were offset by a $3.8 million increase in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014. |

[0000936395-15-000062:mdna:54]
| • | Optical Transport revenue decreased, reflecting decreases of $20.5 million in sales of our 4200 Advanced Services Platform, $16.9 million in sales of our 5100/5200 Advanced Services Platform and $16.8 million in sales of our other stand-alone transport products. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years. We expect this trend to continue, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000062:mdna:55]
| • | Software and Services revenue increased, reflecting increases of $18.8 million in maintenance and support services sales and $3.1 million in installation and deployment services sales partially offset by a decrease of $1.1 million in network transformation consulting sales. |

[0000936395-15-000062:mdna:56]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to secure additional communications service provider customers outside of North America, including in high-growth geographies such as Brazil and India. We believe that this is an important part of our strategy and required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly from quarter to quarter. Among other things, the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-15-000062:mdna:57]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,477,329 |  |  | 64.6 |  | $ | 1,598,328 |  |  | 65.4 |  | $ | 120,999 |  |  | 8.2 |  |
| EMEA | 417,399 |  |  | 18.2 |  | 400,294 |  |  | 16.4 |  | (17,105 | ) |  | (4.1 | ) |
| CALA | 212,018 |  |  | 9.3 |  | 201,499 |  |  | 8.2 |  | (10,519 | ) |  | (5.0 | ) |
| APAC | 181,543 |  |  | 7.9 |  | 245,548 |  |  | 10.0 |  | 64,005 |  |  | 35.3 |  |
| Total | $ | 2,288,289 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |  |

[0000936395-15-000062:mdna:58]
_________________________________

[0000936395-15-000062:mdna:59]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:60]
47

[0000936395-15-000062:mdna:61]
| • | North America revenue includes sales to AT&T for fiscal 2014 and fiscal 2015 of $423.5 million and $487.8 million, respectively. Revenues reflect increases of $184.0 million in Converged Packet Optical sales and $6.2 million in Software and Services sales, partially offset by decreases of $38.2 million in Optical Transport sales and $31.0 million in sales of Packet Networking. Converged Packet Optical sales principally reflect a $106.8 million increase in sales of our 6500 Packet-Optical Platform on increased sales to AT&T, cable and multiservice operators and Web-scale providers, and a $76.3 million increase due to sales of our Z-Series Packet-Optical Platform acquired from Cyan during the fourth quarter. |

[0000936395-15-000062:mdna:62]
| • | EMEA revenue reflects decreases of $13.2 million in Optical Transport sales and $6.5 million in Software and Services sales. These decreases were partially offset by an increase of $2.2 million in sales of Converged Packet Optical sales. |

[0000936395-15-000062:mdna:63]
| • | CALA revenue reflects a $20.6 million decrease in Converged Packet Optical sales. This decrease was partially offset by an increase of $9.7 million in Software and Services sales. Converged Packet Optical sales reflect a $41.3 million decrease in sales of our 5430 Reconfigurable Switching System, partially offset primarily by a $15.5 million increase in sales of our 6500 Packet-Optical Platform primarily to certain communications service providers. Software and Services sales reflect increases of $5.7 million in installation and deployment services sales and $2.3 million of network transformation consulting sales. |

[0000936395-15-000062:mdna:64]
| • | APAC revenue reflects increases of $40.6 million in Converged Packet Optical sales, $16.0 million in Packet Networking sales and $10.8 million in Software and Services sales. These increases were partially offset by a decrease of $3.4 million in sales of Optical Transport. Converged Packet Optical sales reflect increases of $18.7 million of sales of our 6500 Packet-Optical Platform, $18.6 million of sales of our 5430 Reconfigurable Switching System, principally to communication service providers and submarine network operators, and $1.3 million of the Cyan acquired Z-Series Packet-Optical Platform. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers, sales through our strategic relationship with Ericsson and sales to submarine network providers. |

[0000936395-15-000062:mdna:65]
While we have benefited from the diversification of our business and customer base, our largest ten customers contributed 56.4% of fiscal 2014 revenue and 52.5% of fiscal 2015 revenue. A sizable portion of our revenue continues to be derived from sales to service provider customers. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting their businesses.  Our reliance upon a relatively small number of customers also increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations and our results of operations can fluctuate quarterly depending upon sales volumes and purchasing priorities with these large customers.

[0000936395-15-000062:mdna:66]
Sales to AT&T were $423.5 million, or 18.5% of total revenue, in fiscal 2014 and $487.8 million, or 19.9% of total revenue, in fiscal 2015. During fiscal 2015, AT&T and other service provider customers announced initiatives to reduce capital expenditures in future periods, including on network infrastructure, and there can be no assurance that we will be able to maintain the sales levels we achieved during fiscal 2015. Moreover, AT&T and other customers, including service providers, are pursuing network strategies that seek to utilize enhanced software programmability, management and control of networks and to deploy off-the-shelf or commoditized hardware technology, referred to as "white box" hardware, in lieu of existing solutions. These strategies may present challenges and opportunities for our business, particularly where we are an incumbent equipment vendor. We did not have any other customers accounting for greater than 10% of our revenue in fiscal 2014 or fiscal 2015.

[0000936395-15-000062:mdna:67]
As our business has diversified, we have taken a number of steps to increase the velocity of our business and improve our operating efficiency, including through inventory management and lead time reduction. As a result, the percentage of product revenue that we generate from customer orders placed during that particular quarter has increased meaningfully, as compared to  our historical periods. Our increased reliance upon orders placed during a particular quarter may make it harder to predict our revenue and results of operations, and may further increase the likelihood of fluctuations in our results.

[0000936395-15-000062:mdna:68]
Cost of Goods Sold and Gross Profit

[0000936395-15-000062:mdna:69]
Product cost of goods sold consists primarily of amounts paid to third party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-15-000062:mdna:70]
Services cost of goods sold consists primarily of direct and third party costs, including employee-related costs, associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts.

[0000936395-15-000062:mdna:71]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin products including channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. We regularly encounter market-based price erosion, and we expect that our gross margins will be subject to fluctuation and significantly dependent upon on our level of success in driving product cost reductions relative to the price reductions that we encounter. Accordingly, gross margin can be adversely affected by the level of pricing pressure and competition that we encounter in the market. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods.

[0000936395-15-000062:mdna:72]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-15-000062:mdna:73]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-15-000062:mdna:74]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,288,289 |  |  | 100.0 |  | $ | 2,445,669 |  |  | 100.0 |  | $ | 157,380 |  |  | 6.9 |
| Total cost of goods sold | 1,339,937 |  |  | 58.6 |  | 1,370,106 |  |  | 56.0 |  | 30,169 |  |  | 2.3 |
| Gross profit | $ | 948,352 |  |  | 41.4 |  | $ | 1,075,563 |  |  | 44.0 |  | $ | 127,211 |  |  | 13.4 |

[0000936395-15-000062:mdna:75]
_________________________________

[0000936395-15-000062:mdna:76]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:77]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 1,865,826 |  |  | 100.0 |  | $ | 2,002,395 |  |  | 100.0 |  | $ | 136,569 |  |  | 7.3 |
| Product cost of goods sold | 1,083,022 |  |  | 58.0 |  | 1,120,373 |  |  | 56.0 |  | 37,351 |  |  | 3.4 |
| Product gross profit | $ | 782,804 |  |  | 42.0 |  | $ | 882,022 |  |  | 44.0 |  | $ | 99,218 |  |  | 12.7 |

[0000936395-15-000062:mdna:78]
_________________________________

[0000936395-15-000062:mdna:79]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:80]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 422,463 |  |  | 100.0 |  | $ | 443,274 |  |  | 100.0 |  | $ | 20,811 |  |  | 4.9 |  |
| Service cost of goods sold | 256,915 |  |  | 60.8 |  | 249,733 |  |  | 56.3 |  | (7,182 | ) |  | (2.8 | ) |
| Service gross profit | $ | 165,548 |  |  | 39.2 |  | $ | 193,541 |  |  | 43.7 |  | $ | 27,993 |  |  | 16.9 |  |

[0000936395-15-000062:mdna:81]
_________________________________

[0000936395-15-000062:mdna:82]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:83]
| • | Gross profit as a percentage of revenue increased as a result of the factors described below. |

[0000936395-15-000062:mdna:84]
| • | Gross profit on products as a percentage of product revenue increased as a result of our relative success in driving product cost reductions and realizing improved manufacturing efficiencies as compared to the market-based price erosion we encountered during the period. |

[0000936395-15-000062:mdna:85]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased sales of higher margin software subscription services and reduced repair costs to support maintenance service contracts. |

[0000936395-15-000062:mdna:86]
Operating Expense

[0000936395-15-000062:mdna:87]
We expect operating expense to increase in fiscal 2016 from the level reported for fiscal 2015, in part relating to the acquisition of the Cyan business during the fourth quarter of fiscal 2015 and the addition of its personnel and operations. We also expect operating expense to increase in order to fund our research and development initiatives, to provide for investments in the re-engineering of company-wide enterprise resource planning platforms, and to fund the transition of key facilities. In particular, the development of our new facilities and the transition of our operations in Ottawa will require significant effort, time and cost in advance of the expiration of the lease for our Lab 10 facility. For additional information regarding this lease and the facility transition, see Item 2 of Part I of this annual report.

[0000936395-15-000062:mdna:88]
Operating expense consists of the component elements described below.

[0000936395-15-000062:mdna:89]
Research and development expense primarily consists of salaries and related employee expense (including share-based  compensation expense), prototype costs relating to design, development, and testing of our products, depreciation expense and third party consulting costs.

[0000936395-15-000062:mdna:90]
Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense), and sales and marketing support expense, including travel, demonstration units, trade show expense and third party consulting costs.

[0000936395-15-000062:mdna:91]
General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense), and costs for third party consulting and other services.

[0000936395-15-000062:mdna:92]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our recent acquisition of Cyan.

[0000936395-15-000062:mdna:93]
Amortization of intangible assets primarily reflects the amortization of purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-15-000062:mdna:94]
Restructuring costs primarily reflect actions Ciena has taken to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions.

[0000936395-15-000062:mdna:95]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-15-000062:mdna:96]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 401,180 |  |  | 17.5 |  | $ | 414,201 |  |  | 16.9 |  | $ | 13,021 |  |  | 3.2 |  |
| Selling and marketing | 328,325 |  |  | 14.3 |  | 333,836 |  |  | 13.7 |  | 5,511 |  |  | 1.7 |  |
| General and administrative | 126,824 |  |  | 5.5 |  | 123,402 |  |  | 5.0 |  | (3,422 | ) |  | (2.7 | ) |
| Amortization of intangible assets | 45,970 |  |  | 2.0 |  | 69,511 |  |  | 2.8 |  | 23,541 |  |  | 51.2 |  |
| Acquisition and integration costs | — |  |  | — |  | 25,539 |  |  | 1.0 |  | 25,539 |  |  | — |  |
| Restructuring costs | 349 |  |  | — |  | 8,626 |  |  | 0.4 |  | 8,277 |  |  | 2,371.6 |  |
| Total operating expenses | $ | 902,648 |  |  | 39.3 |  | $ | 975,115 |  |  | 39.8 |  | $ | 72,467 |  |  | 8.0 |  |

[0000936395-15-000062:mdna:97]
_________________________________

[0000936395-15-000062:mdna:98]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:99]
| • | Research and development expense benefited by $28.0 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian dollar. Including the effect of foreign exchange rates, research and development expenses increased by $13.0 million, primarily reflecting increases of $8.6 million in facilities and information systems expense, $6.3 million in employee compensation and related costs, $1.2 million in technology and related expense and $1.1 million in depreciation expense. These increases were partially offset by decreases of $7.0 million in professional services and $2.3 million in prototype expense. Research and development expense also reflects a $4.5 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario as the maximum funding limit under this grant was met in the second quarter of fiscal 2015. |

[0000936395-15-000062:mdna:100]
| • | Selling and marketing expense benefited by $16.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expenses increased by $5.5 million, primarily reflecting increases of $10.4 million in employee compensation and related costs and $1.2 million in customer demonstration equipment. These increases were partially offset by decreases of $2.2 million in trade show and related costs, $2.2 million in travel and related costs and $1.5 million in professional services. |

[0000936395-15-000062:mdna:101]
| • | General and administrative expense benefited by $4.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense decreased by $3.4 million, reflecting an $8.5 million decrease in legal fees, primarily due to certain patent litigation costs incurred during fiscal 2014. This decrease was partially offset by increases of $4.5 million in employee compensation and related costs and $1.0 million in facilities and information systems expense. |

[0000936395-15-000062:mdna:102]
| • | Acquisition and integration costs increased, reflecting financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our acquisition of Cyan during fiscal 2015. |

[0000936395-15-000062:mdna:103]
| • | Amortization of intangible assets increased due to expense related to acquired intangible assets from our acquisition of Cyan during the fourth quarter of fiscal 2015. |

[0000936395-15-000062:mdna:104]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. During fiscal 2015, we incurred approximately $8.6 million in restructuring costs, primarily reflecting a global workforce reduction of approximately 125 employees in the first quarter of fiscal 2015 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-15-000062:mdna:105]
Other items

[0000936395-15-000062:mdna:106]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-15-000062:mdna:107]
51

[0000936395-15-000062:mdna:108]
|  | Fiscal Year |  |  |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (25,262 | ) |  | (1.1 | ) |  | $ | (25,505 | ) |  | (1.0 | ) |  | $ | (243 | ) |  | (1.0 | ) |
| Interest expense | $ | 47,115 |  |  | 2.1 |  |  | $ | 51,179 |  |  | 2.1 |  |  | $ | 4,064 |  |  | 8.6 |  |
| Provision for income taxes | $ | 13,964 |  |  | 0.6 |  |  | $ | 12,097 |  |  | 0.5 |  |  | $ | (1,867 | ) |  | (13.4 | ) |

[0000936395-15-000062:mdna:109]
_________________________________

[0000936395-15-000062:mdna:110]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:111]
| • | Interest and other income (loss), net reflects a $2.9 million increase in losses related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, offset by a $2.7 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 2015 Notes, which matured during the second quarter of fiscal 2015. |

[0000936395-15-000062:mdna:112]
| • | Interest expense increased, primarily due to a higher level of outstanding debt in fiscal 2015 as compared to fiscal 2014. See Note 15 to our Consolidated Financial Statements included in in Item 8 of Part II of this report for more information. |

[0000936395-15-000062:mdna:113]
| • | Provision for income taxes decreased primarily due to foreign and state taxes. |

[0000936395-15-000062:mdna:114]
Fiscal 2013 compared to Fiscal 2014

[0000936395-15-000062:mdna:115]
Revenue

[0000936395-15-000062:mdna:116]
The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000062:mdna:117]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,187,231 |  |  | 57.0 |  | $ | 1,455,501 |  |  | 63.6 |  | $ | 268,270 |  |  | 22.6 |  |
| Packet Networking | 222,898 |  |  | 10.7 |  | 244,116 |  |  | 10.7 |  | 21,218 |  |  | 9.5 |  |
| Optical Transport | 233,821 |  |  | 11.2 |  | 127,215 |  |  | 5.6 |  | (106,606 | ) |  | (45.6 | ) |
| Software and Services | 438,596 |  |  | 21.1 |  | 461,457 |  |  | 20.1 |  | 22,861 |  |  | 5.2 |  |
| Consolidated revenue | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |  |

[0000936395-15-000062:mdna:118]
_________________________________

[0000936395-15-000062:mdna:119]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:120]
| • | Converged Packet Optical revenue increased significantly, reflecting a $258.2 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider and Web-scale provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of our 5430 reconfigurable switching system and the OTN configuration for the 5410 Reconfigurable Switching System increased by $25.6 million and $6.0 million respectively. These increases were partially offset by a $21.5 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the expected declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000062:mdna:121]
| • | Packet Networking revenue increased, reflecting a $30.4 million increase in sales of our 3000 and 5000 families of service delivery and aggregation switches. This increase was largely driven by the expansion of Ethernet business services by AT&T, our largest service provider customer. Segment revenue also benefited from $1.7 million in initial sales of our 8700 Packetwave Platform. These increases were partially offset by decreases of $5.3 million in sales of our 5410 Service Aggregation Switch and $5.1 million in sales of our older, stand-alone broadband products. |

[0000936395-15-000062:mdna:122]
| • | Optical Transport revenue decreased, reflecting sales decreases of $46.6 million in other stand-alone transport products, $36.2 million of 5100/5200 Advanced Services Platform and $23.8 million in our 4200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-15-000062:mdna:123]
| • | Software and Services revenue increased, reflecting increases of $10.4 million in maintenance and support services revenue, $8.4 million in installation and deployment services revenue, $2.8 million in software sales and $1.2 million in networking transformation consulting revenue. |

[0000936395-15-000062:mdna:124]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-15-000062:mdna:125]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 1,360,169 |  |  | 65.3 |  | $ | 1,477,329 |  |  | 64.6 |  | $ | 117,160 |  |  | 8.6 |
| EMEA | 376,405 |  |  | 18.1 |  | 417,399 |  |  | 18.2 |  | 40,994 |  |  | 10.9 |
| CALA | 174,360 |  |  | 8.4 |  | 212,018 |  |  | 9.3 |  | 37,658 |  |  | 21.6 |
| APAC | 171,612 |  |  | 8.2 |  | 181,543 |  |  | 7.9 |  | 9,931 |  |  | 5.8 |
| Total | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |

[0000936395-15-000062:mdna:126]
_________________________________

[0000936395-15-000062:mdna:127]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:128]
| • | North America revenue includes sales to AT&T for fiscal 2013 and fiscal 2014 of $373.6 million and $423.5 million, respectively. Revenues reflect increases of $145.6 million in Converged Packet Optical sales, $21.4 million in Software and Services sales and $20.2 million in sales of Packet Networking. These increases were partially offset by a decrease of $70.1 million in Optical Transport sales. |

[0000936395-15-000062:mdna:129]
| • | EMEA revenue reflects increases of $58.4 million in Converged Packet Optical sales, $5.4 million in Software and Services Sales and $2.3 million in Packet Networking sales. These increases were partially offset by a decrease of $25.0 million in Optical Transport sales. |

[0000936395-15-000062:mdna:130]
| • | CALA revenue reflects increases of $41.3 million in Converged Packet Optical sales and $2.5 million in Software and Services sales. These increases was partially offset by a decrease of $6.1 million in Optical Transport sales. |

[0000936395-15-000062:mdna:131]
| • | APAC revenue reflects an increase of $23.0 million in Converged Packet Optical sales. This increase was partially offset by decreases of $6.5 million in Software and Services sales, $5.3 million in Optical Transport sales and $1.3 million in Packet Networking sales. Software and Services sales reflect decreases of $3.4 million in maintenance and support services sales, $1.2 million in installation and deployment services sales and $1.0 million in software sales. Maintenance and support services sales reflect decreases in sales to certain service providers. Installation and deployment services sales reflect a decrease in sales to submarine network operators. |

[0000936395-15-000062:mdna:132]
Cost of Goods Sold and Gross Profit

[0000936395-15-000062:mdna:133]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-15-000062:mdna:134]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 2,082,546 |  |  | 100.0 |  | $ | 2,288,289 |  |  | 100.0 |  | $ | 205,743 |  |  | 9.9 |
| Total cost of goods sold | 1,217,371 |  |  | 58.5 |  | 1,339,937 |  |  | 58.6 |  | 122,566 |  |  | 10.1 |
| Gross profit | $ | 865,175 |  |  | 41.5 |  | $ | 948,352 |  |  | 41.4 |  | $ | 83,177 |  |  | 9.6 |

[0000936395-15-000062:mdna:135]
_________________________________

[0000936395-15-000062:mdna:136]
53

[0000936395-15-000062:mdna:137]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:138]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 1,680,125 |  |  | 100.0 |  | $ | 1,865,826 |  |  | 100.0 |  | $ | 185,701 |  |  | 11.1 |
| Product cost of goods sold | 967,510 |  |  | 57.6 |  | 1,083,022 |  |  | 58.0 |  | 115,512 |  |  | 11.9 |
| Product gross profit | $ | 712,615 |  |  | 42.4 |  | $ | 782,804 |  |  | 42.0 |  | $ | 70,189 |  |  | 9.8 |

[0000936395-15-000062:mdna:139]
_________________________________

[0000936395-15-000062:mdna:140]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:141]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 402,421 |  |  | 100.0 |  | $ | 422,463 |  |  | 100.0 |  | $ | 20,042 |  |  | 5.0 |
| Service cost of goods sold | 249,861 |  |  | 62.1 |  | 256,915 |  |  | 60.8 |  | 7,054 |  |  | 2.8 |
| Service gross profit | $ | 152,560 |  |  | 37.9 |  | $ | 165,548 |  |  | 39.2 |  | $ | 12,988 |  |  | 8.5 |

[0000936395-15-000062:mdna:142]
_________________________________

[0000936395-15-000062:mdna:143]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:144]
| • | Gross profit as a percentage of revenue remained relatively unchanged. |

[0000936395-15-000062:mdna:145]
| • | Gross profit on products as a percentage of product revenue decreased slightly, due to lower margins on Packet Networking and Optical Transport products. The decline was largely offset by improved mix of higher-margin packet platforms with software content within our Converged Packet Optical segment, and greater leverage from efforts to streamline and optimize our supply chain activities. |

[0000936395-15-000062:mdna:146]
| • | Gross profit on services as a percentage of services revenue increased primarily due to increased maintenance and consulting services revenues and increased margin due to improved efficiencies for managed spares projects. |

[0000936395-15-000062:mdna:147]
Operating expense

[0000936395-15-000062:mdna:148]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-15-000062:mdna:149]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 383,408 |  |  | 18.4 |  | $ | 401,180 |  |  | 17.5 |  | $ | 17,772 |  |  | 4.6 |  |
| Selling and marketing | 304,170 |  |  | 14.6 |  | 328,325 |  |  | 14.3 |  | 24,155 |  |  | 7.9 |  |
| General and administrative | 122,432 |  |  | 5.9 |  | 126,824 |  |  | 5.5 |  | 4,392 |  |  | 3.6 |  |
| Amortization of intangible assets | 49,771 |  |  | 2.4 |  | 45,970 |  |  | 2.0 |  | (3,801 | ) |  | (7.6 | ) |
| Restructuring costs | 7,169 |  |  | 0.3 |  | 349 |  |  | — |  | (6,820 | ) |  | (95.1 | ) |
| Total operating expenses | $ | 866,950 |  |  | 41.6 |  | $ | 902,648 |  |  | 39.3 |  | $ | 35,698 |  |  | 4.1 |  |

[0000936395-15-000062:mdna:150]
_________________________________

[0000936395-15-000062:mdna:151]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:152]
| • | Research and development expense benefited by $15.4 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $17.8 million increase primarily reflects increases of $8.1 million in professional services expense, $6.9 million in employee compensation and related costs, $5.3 million in prototype expense, partially offset by a decrease of $2.6 million in technology and related costs. |

[0000936395-15-000062:mdna:153]
| • | Selling and marketing expense benefited by $1.9 million as a result of foreign exchange rates, primarily due to strengthening of the U.S. dollar in relation to the Canadian Dollar. The $24.2 million increase primarily reflects increases of $20.6 million in employee compensation and related costs, $3.3 million of travel and related costs and $1.2 million in facilities and information technology costs. These increases were partially offset by a decrease of $1.4 million in customer demonstration equipment. |

[0000936395-15-000062:mdna:154]
| • | General and administrative expense increased by $4.4 million, primarily reflecting an increase in legal fees and settlements and consulting services. |

[0000936395-15-000062:mdna:155]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-15-000062:mdna:156]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and restructuring activities to align our workforce and resources with market opportunities and research and development initiatives. Restructuring costs for fiscal 2013 also include the consolidation of certain facilities located within Maryland associated with the transition of our headquarters facility. |

[0000936395-15-000062:mdna:157]
Other items

[0000936395-15-000062:mdna:158]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-15-000062:mdna:159]
|  | Fiscal Year |  |  |  |  |
|  | 2013 |  | %* |  | 2014 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (5,744 | ) |  | (0.3 | ) |  | $ | (25,262 | ) |  | (1.1 | ) |  | $ | (19,518 | ) |  | (339.8 | ) |
| Interest expense | $ | 44,042 |  |  | 2.1 |  |  | $ | 47,115 |  |  | 2.1 |  |  | $ | 3,073 |  |  | 7.0 |  |
| Loss on extinguishment of debt | $ | (28,630 | ) |  | (1.4 | ) |  | $ | — |  |  | — |  |  | $ | 28,630 |  |  | (100.0 | ) |
| Provision for income taxes | $ | 5,240 |  |  | 0.3 |  |  | $ | 13,964 |  |  | 0.6 |  |  | $ | 8,724 |  |  | 166.5 |  |

[0000936395-15-000062:mdna:160]
_________________________________

[0000936395-15-000062:mdna:161]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:162]
| • | Interest and other income (loss), net reflects a $5.7 million non-cash loss related to the change in fair value of the embedded redemption feature associated with our 2015 Notes and a $13.5 million increase in losses related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-15-000062:mdna:163]
| • | Interest expense increased, primarily due to a higher level of outstanding debt in fiscal 2014 as compared to fiscal 2013. See Note 15 to our Consolidated Financial Statements included in in Item 8 of Part II of this report for more information. |

[0000936395-15-000062:mdna:164]
| • | Loss on extinguishment of debt for fiscal 2013 reflects a non-cash loss of $28.6 million relating to the exchange transactions during the first quarter of fiscal 2013. Upon issuance, the 4.0% convertible senior notes due December 15, 2020 (the "2020 Notes") were recorded at a fair value of $213.6 million. The exchange transactions resulted in the retirement of outstanding 2015 Notes with a carrying value of $187.9 million and the write-off of unamortized debt issuance costs of $2.3 million and $0.6 million relating to the redemption feature on the 2015 Notes, which was accounted for as a separate embedded derivative. |

[0000936395-15-000062:mdna:165]
| • | Provision for income taxes increased primarily due to foreign and state tax expenses. |

[0000936395-15-000062:mdna:166]
Segment Profit

[0000936395-15-000062:mdna:167]
55

[0000936395-15-000062:mdna:168]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-15-000062:mdna:169]
|  | Fiscal Year |  |  |
|  | 2014 |  | 2015 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 353,942 |  |  | $ | 471,484 |  |  | $ | 117,542 |  |  | 33.2 |  |
| Packet Networking | $ | 19,467 |  |  | $ | 28,136 |  |  | $ | 8,669 |  |  | 44.5 |  |
| Optical Transport | $ | 38,974 |  |  | $ | 15,930 |  |  | $ | (23,044 | ) |  | (59.1 | ) |
| Software and Services | $ | 134,789 |  |  | $ | 145,812 |  |  | $ | 11,023 |  |  | 8.2 |  |

[0000936395-15-000062:mdna:170]
_________________________________

[0000936395-15-000062:mdna:171]
| * | Denotes % change from 2014 to 2015 |

[0000936395-15-000062:mdna:172]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-15-000062:mdna:173]
| • | Packet Networking segment profit increased due to lower research and development costs and improved gross margin partially offset by lower sales volume. |

[0000936395-15-000062:mdna:174]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and decreased gross margin. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000062:mdna:175]
| • | Software and Services segment profit increased, primarily due to increases in sales of maintenance and support services, installation and deployment services, software subscription services and increased margin due to lower repair costs to support maintenance service contracts. These increases were partially offset by increased software research and development costs. |

[0000936395-15-000062:mdna:176]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-15-000062:mdna:177]
|  | Fiscal Year |  |  |
|  | 2013 |  | 2014 |  | Increase(decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 242,335 |  |  | $ | 353,942 |  |  | $ | 111,607 |  |  | 46.1 |  |
| Packet Networking | $ | 22,740 |  |  | $ | 19,467 |  |  | $ | (3,273 | ) |  | (14.4 | ) |
| Optical Transport | $ | 89,754 |  |  | $ | 38,974 |  |  | $ | (50,780 | ) |  | (56.6 | ) |
| Software and Services | $ | 126,938 |  |  | $ | 134,789 |  |  | $ | 7,851 |  |  | 6.2 |  |

[0000936395-15-000062:mdna:178]
_________________________________

[0000936395-15-000062:mdna:179]
| * | Denotes % change from 2013 to 2014 |

[0000936395-15-000062:mdna:180]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin. The increased sales volume is largely driven by service provider and Web-scale provider demand for high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. The improved gross margin is primarily due to sales reflecting a greater mix of higher-margin packet platforms with software content within the segment. These increases were partially offset by increased research and development expense. |

[0000936395-15-000062:mdna:181]
| • | Packet Networking segment profit decreased due to lower margins on our 3000 and 5000 families of service delivery and aggregation switches, reflecting increased pricing pressure and competitive dynamics, and increased research and development expense. Decreased segment profit was partially offset by increased sales volume. |

[0000936395-15-000062:mdna:182]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and lower gross margin, partially offset by lower research and development expense. The decrease in gross margin is primarily due to an increase in obsolete and excess inventory expense for the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000062:mdna:183]
| • | Software and Services segment profit increased slightly, due to higher sales for software and consulting services and improved efficiencies for managed spares projects. These increases were partially offset by higher software research and development expense. |

[0000936395-15-000062:mdna:184]
Liquidity and Capital Resources

[0000936395-15-000062:mdna:185]
At October 31, 2015, our principal sources of liquidity were cash and cash equivalents and investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-15-000062:mdna:186]
|  | October 31, |  | Increase |
|  | 2014 |  | 2015 |  | (decrease) |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 790,971 |  |  | $ | 204,251 |  |
| Short-term investments in marketable debt securities | 140,205 |  |  | 135,107 |  |  | (5,098 | ) |
| Long-term investments in marketable debt securities | 50,057 |  |  | 95,105 |  |  | 45,048 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 776,982 |  |  | $ | 1,021,183 |  |  | $ | 244,201 |  |

[0000936395-15-000062:mdna:187]
The change in total cash and cash equivalents and investments in marketable debt securities during fiscal 2015 was primarily related to the following:

[0000936395-15-000062:mdna:188]
| • | $262.1 million cash provided by operations, consisting of $274.9 million provided by net income adjusted for non-cash charges offset by $12.8 million used in working capital; |

[0000936395-15-000062:mdna:189]
| • | $62.1 million used for purchases of equipment, furniture, fixtures and intellectual property; |

[0000936395-15-000062:mdna:190]
| • | $24.1 million provided by the settlement of foreign currency forward contracts, net; |

[0000936395-15-000062:mdna:191]
| • | $8.0 million used to pay capital lease obligations; |

[0000936395-15-000062:mdna:192]
| • | $2.0 million used for the purchase of a cost method investment; |

[0000936395-15-000062:mdna:193]
| • | $37.2 million from the acquisition of Cyan, net of cash acquired; |

[0000936395-15-000062:mdna:194]
| • | $29.9 million used for the repayment of long-term debt; |

[0000936395-15-000062:mdna:195]
| • | $30.3 million from proceeds of stock issuances under our employee stock purchase plan and the exercise of stock options; and |

[0000936395-15-000062:mdna:196]
| • | $6.7 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-15-000062:mdna:197]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200.0 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of October 31, 2015, letters of credit totaling $63.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2015. Ciena and certain of its subsidiaries are also parties to a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. For additional information about our Term Loan and ABL Credit Facility, see Note 15 and Note 16, respectively, to our Consolidated Financial Statements included in in Item 8 of Part II of this report.

[0000936395-15-000062:mdna:198]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-15-000062:mdna:199]
The following sections set forth the components of our $262.1 million of cash provided by operating activities for fiscal 2015:

[0000936395-15-000062:mdna:200]
Net income adjusted for non-cash charges

[0000936395-15-000062:mdna:201]
The following tables set forth (in thousands) our net income adjusted for non-cash charges during fiscal 2015:

[0000936395-15-000062:mdna:202]
|  | Year ended |
|  | October 31, 2015 |
| Net income | $ | 11,667 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 55,901 |  |
| Share-based compensation costs | 55,340 |  |
| Amortization of intangible assets | 79,866 |  |
| Provision for inventory excess and obsolescence | 26,846 |  |
| Provision for warranty | 17,881 |  |
| Other | 27,373 |  |
| Net income adjusted for non-cash charges | $ | 274,874 |  |

[0000936395-15-000062:mdna:203]
Working Capital

[0000936395-15-000062:mdna:204]
Our working capital used $12.8 million of cash during fiscal 2015. The following tables set forth (in thousands) the major components of the reduction in working capital:

[0000936395-15-000062:mdna:205]
|  | Year ended |
|  | October 31, 2015 |
| Cash used in accounts receivable | $ | (37,297 | ) |
| Cash provided by inventories | 46,898 |  |
| Cash used in prepaid expenses and other | (46,383 | ) |
| Cash used in accounts payable, accruals and other obligations | (10,505 | ) |
| Cash provided by deferred revenue | 34,525 |  |
| Cash provided by a reduction in working capital | $ | (12,762 | ) |

[0000936395-15-000062:mdna:206]
The $37.3 million of cash used in accounts receivable during fiscal 2015 reflects the higher sales volume in the fourth quarter of fiscal 2015 compared to the fourth quarter of fiscal 2014. Our days sales outstanding (DSOs) remained relatively flat from 82 days for fiscal 2014 to 81 days for fiscal 2015. The $46.9 million in cash generated from reductions in inventory during fiscal 2015 reflects, in part, certain supply chain initiatives to improve manufacturing efficiencies and inventory management and the reduction of deferred costs of sales. The reduction of the deferred costs of sales relates to the completion of certain submarine network projects. As a result, our inventory turns increased from 4.3 turns during fiscal 2014 to 5.9 turns during fiscal 2015. Cash used in prepaid expense and other during fiscal 2015 was $46.4 million, primarily reflecting a $30.0 million financing receivable with an 18-month term. The $10.5 million of cash used in accounts payable, accruals and other obligations during fiscal 2015 reflects shorter vendor payment cycles. The $34.5 million of cash provided by deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition.

[0000936395-15-000062:mdna:207]
Cash paid for interest

[0000936395-15-000062:mdna:208]
The $274.9 million of cash provided by our net income adjusted for non-cash charges during fiscal 2015 reflects interest payments by Ciena of $40.8 million. The following tables set forth (in thousands) our interest paid during fiscal 2015:

[0000936395-15-000062:mdna:209]
|  | Year ended |
|  | October 31, 2015 |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) | $ | 3,750 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 (2) | 4,375 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (3) | 13,125 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(4) | 7,500 |  |
| Term Loan Payable due July 15, 2019 (5) | 9,475 |  |
| Interest rate swap (6) | 793 |  |
| ABL Credit Facility (7) | 1,754 |  |
| Cash paid during the fiscal year for interest | $ | 40,772 |  |

[0000936395-15-000062:mdna:210]
| (1) | The final interest payment owing on our 4.0% convertible senior notes, due March 15, 2015, was paid during the second fiscal quarter of 2015. |

[0000936395-15-000062:mdna:211]
| (2) | Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. |

[0000936395-15-000062:mdna:212]
| (3) | Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. |

[0000936395-15-000062:mdna:213]
| (4) | Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. |

[0000936395-15-000062:mdna:214]
| (5) | Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. The Term Loan bears interest at LIBOR plus a spread of 300 basis points subject to a minimum LIBOR rate of 0.75%. During fiscal 2015, the interest rate on our Term Loan was 3.75%. |

[0000936395-15-000062:mdna:215]
| (6) | Payments on our interest rate swap arrangement are variable and effectively fix the total interest rate under the Term Loan at 5.004% from July 20, 2015 through July 19, 2018. |

[0000936395-15-000062:mdna:216]
| (7) | During fiscal 2015, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.8 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-15-000062:mdna:217]
For additional information about our convertible notes,Term Loan, ABL Credit Facility and interest rate swap see Note 15 and 16 to our Consolidated Financial Statements included in Item 8 of Part II of this report and Item 7A of Part II of this report.

[0000936395-15-000062:mdna:218]
Contractual Obligations

[0000936395-15-000062:mdna:219]
On October 23, 2014, Ciena Canada, Inc., a subsidiary of Ciena, entered into a lease agreement to lease an office building located at 5050 Innovation Drive, Ottawa, Canada. On April 15, 2015, Ciena Canada, Inc. entered into a work letter and a lease agreement related to the construction and lease of two new office buildings consisting of a rentable area of approximately 254,318 square feet that will be built adjacent to the premises subject to the October 2014 lease. These facilities are expected to be part of a future campus that will replace Ciena’s largest facility and a key research and development center located in the Lab 10 building on the former Nortel Carling Campus in Ottawa, Canada. With respect to the lease entered into in the second quarter of fiscal 2015, the future minimum rental commitments to be paid over the 15-year lease term are approximately CAD$112.9 million. The following is a summary of our future minimum payments under contractual obligations as of October 31, 2015 (in thousands):

[0000936395-15-000062:mdna:220]
59

[0000936395-15-000062:mdna:221]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,061,291 |  |  | $ | — |  |  | $ | 844,164 |  |  | $ | — |  |  | $ | 217,127 |  |
| Principal due on Term Loan | 246,875 |  |  | 2,500 |  |  | 5,000 |  |  | 239,375 |  |  | — |  |
| Interest due on convertible notes | 89,375 |  |  | 25,000 |  |  | 45,625 |  |  | 15,000 |  |  | 3,750 |  |
| Interest due on Term Loan (2) | 34,619 |  |  | 9,354 |  |  | 18,474 |  |  | 6,791 |  |  | — |  |
| Payments due under interest rate swap (2) | 8,525 |  |  | 3,136 |  |  | 5,389 |  |  | — |  |  | — |  |
| Operating leases (3) | 149,754 |  |  | 32,480 |  |  | 48,840 |  |  | 21,985 |  |  | 46,449 |  |
| Purchase obligations (4) | 204,075 |  |  | 204,075 |  |  | — |  |  | — |  |  | — |  |
| Capital leases - equipment | 5,101 |  |  | 4,764 |  |  | 337 |  |  | — |  |  | — |  |
| Capital leases - buildings (5) | 127,826 |  |  | 1,938 |  |  | 10,396 |  |  | 14,909 |  |  | 100,583 |  |
| Other obligations | 3,184 |  |  | 2,944 |  |  | 240 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,930,625 |  |  | $ | 286,191 |  |  | $ | 978,465 |  |  | $ | 298,060 |  |  | $ | 367,909 |  |

[0000936395-15-000062:mdna:222]
_________________________________

[0000936395-15-000062:mdna:223]
| (1) | Includes the accretion of the principal amount on the 2020 Notes payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-15-000062:mdna:224]
| (2) | Interest on the Term Loan and payments under the interest rate swap are variable and were calculated using the rate in effect on the balance sheet date. For additional information about our Term Loan and the interest rate swap, see Note 15 to our Consolidated Financial Statements included in in Item 8 of Part II of this report and Item 7A of Part II of this report. |

[0000936395-15-000062:mdna:225]
| (3) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-15-000062:mdna:226]
| (4) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-15-000062:mdna:227]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the excepted commencement of the lease term. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-15-000062:mdna:228]
| (6) | As of October 31, 2015, we also had approximately $13.3 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-15-000062:mdna:229]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2015 (in thousands):

[0000936395-15-000062:mdna:230]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 65,886 |  |  | $ | 31,606 |  |  | $ | 15,299 |  |  | $ | 6,008 |  |  | $ | 12,973 |  |

[0000936395-15-000062:mdna:231]
Off-Balance Sheet Arrangements

[0000936395-15-000062:mdna:232]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-15-000062:mdna:233]
Critical Accounting Policies and Estimates

[0000936395-15-000062:mdna:234]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their

[0000936395-15-000062:mdna:235]
nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-15-000062:mdna:236]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-15-000062:mdna:237]
Revenue Recognition

[0000936395-15-000062:mdna:238]
We recognize revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. We assess whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are to be performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-15-000062:mdna:239]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the fiscal years ended October 31, 2013, October 31, 2014 and October 31, 2015 were 4.5%, 4.0% and 1.8%, respectively.

[0000936395-15-000062:mdna:240]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance

[0000936395-15-000062:mdna:241]
We limit the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-15-000062:mdna:242]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. We determine the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, we use vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, we use our best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-15-000062:mdna:243]
VSOE, when determinable, is established based on our pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, we require that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. We have generally been unable to establish TPE of selling price because our go-to-market strategy differs from that of others in our markets, and the extent of customization and differentiated features and functions varies among comparable products or services from our peers. We determine BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-15-000062:mdna:244]
Our total deferred revenue for products was $50.5 million and $66.5 million as of October 31, 2014 and October 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be

[0000936395-15-000062:mdna:245]
performed. Our total deferred revenue for services was $95.2 million and $122.5 million as of October 31, 2014 and October 31, 2015, respectively.

[0000936395-15-000062:mdna:246]
Business Combinations

[0000936395-15-000062:mdna:247]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates. During fiscal 2015, we completed the Cyan acquisition for a purchase price of $335.7 million. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-15-000062:mdna:248]
Share-Based Compensation

[0000936395-15-000062:mdna:249]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-15-000062:mdna:250]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 20 to our Consolidated Financial Statements in Item 8 of Part II of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2015, total unrecognized compensation expense was $78.7 million: (i) $2.8 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.6 years; and (ii) $75.9 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-15-000062:mdna:251]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-15-000062:mdna:252]
Reserve for Inventory Obsolescence

[0000936395-15-000062:mdna:253]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $32.3 million and $26.8 million in fiscal 2014 and 2015, respectively. The charges in fiscal 2014 were primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport, including our Corestream® Agility Optical Transport platform, and Converged Packet Optical products. The charges in fiscal 2015 were primarily related to the discontinuance of certain parts and components used in the manufacture of our Converged Packet Optical products and a decrease in the forecasted demand for both our legacy, stand-alone WDM and SONET/SDH-based transport platforms and our 5410 Service Aggregation Switch. Our inventory net of allowance for excess and obsolescence was $254.7 million and $191.2 million as of October 31, 2014 and October 31, 2015, respectively.

[0000936395-15-000062:mdna:254]
Allowance for Doubtful Accounts Receivable

[0000936395-15-000062:mdna:255]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be

[0000936395-15-000062:mdna:256]
required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $519.0 million and $550.8 million as of October 31, 2014 and October 31, 2015, respectively. Our allowance for doubtful accounts was $2.1 million and $3.0 million as of October 31, 2014 and October 31, 2015, respectively.

[0000936395-15-000062:mdna:257]
Goodwill

[0000936395-15-000062:mdna:258]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-15-000062:mdna:259]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of the end of fiscal 2014, there was no goodwill balance. At the end of fiscal 2015, the goodwill balance was $256.4 million as a result of our acquisition of Cyan. See Note 2 to the Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-15-000062:mdna:260]
Long-lived Assets

[0000936395-15-000062:mdna:261]
Our long-lived assets include: equipment; building; furniture and fixtures; finite-lived intangible assets and maintenance spares. As of October 31, 2014 and October 31, 2015 these assets totaled $309.4 million and $449.9 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-15-000062:mdna:262]
Deferred Tax Valuation Allowance

[0000936395-15-000062:mdna:263]
63

[0000936395-15-000062:mdna:264]
As of October 31, 2015, we have recorded a valuation allowance offsetting all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-15-000062:mdna:265]
Warranty

[0000936395-15-000062:mdna:266]
Our liability for product warranties, included in other accrued liabilities, was $56.0 million and $56.7 million as of October 31, 2014 and October 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $22.1 million and $17.9 million for fiscal 2014 and 2015, respectively. See Note 12 to the Consolidated Financial Statements included in Item 8 of Part II of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-15-000062:mdna:267]
Effects of Recent Accounting Pronouncements

[0000936395-15-000062:mdna:268]
See Note 1 to our Consolidated Financial Statements in Item 8 of Part II of this report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-15-000062:mdna:269]
Unaudited Quarterly Results of Operations

[0000936395-15-000062:mdna:270]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2015. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-15-000062:mdna:271]
|  | Jan. 31, |  | Apr. 30, |  | Jul. 31, |  | Oct. 31, |  | Jan. 31, |  | Apr. 30, |  | Jul. 31, |  | Oct. 31, |
|  | 2014 |  | 2014 |  | 2014 |  | 2014 |  | 2015 |  | 2015 |  | 2015 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 432,941 |  |  | $ | 460,821 |  |  | $ | 495,889 |  |  | $ | 476,175 |  |  | $ | 422,315 |  |  | $ | 511,880 |  |  | $ | 493,919 |  |  | $ | 574,281 |  |
| Services | 100,762 |  |  | 99,240 |  |  | 107,673 |  |  | 114,788 |  |  | 106,847 |  |  | 109,722 |  |  | 109,013 |  |  | 117,692 |  |
| Total Revenue | 533,703 |  |  | 560,061 |  |  | 603,562 |  |  | 590,963 |  |  | 529,162 |  |  | 621,602 |  |  | 602,932 |  |  | 691,973 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 245,216 |  |  | 257,632 |  |  | 275,003 |  |  | 305,171 |  |  | 236,548 |  |  | 286,898 |  |  | 273,837 |  |  | 323,090 |  |
| Services | 62,636 |  |  | 64,738 |  |  | 64,586 |  |  | 64,955 |  |  | 62,319 |  |  | 62,293 |  |  | 59,226 |  |  | 65,895 |  |
| Total costs of goods sold | 307,852 |  |  | 322,370 |  |  | 339,589 |  |  | 370,126 |  |  | 298,867 |  |  | 349,191 |  |  | 333,063 |  |  | 388,985 |  |
| Gross profit | 225,851 |  |  | 237,691 |  |  | 263,973 |  |  | 220,837 |  |  | 230,295 |  |  | 272,411 |  |  | 269,869 |  |  | 302,988 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 101,497 |  |  | 103,492 |  |  | 97,685 |  |  | 98,506 |  |  | 100,761 |  |  | 105,202 |  |  | 100,379 |  |  | 107,859 |  |
| Selling and marketing | 78,348 |  |  | 83,662 |  |  | 81,919 |  |  | 84,396 |  |  | 76,712 |  |  | 82,471 |  |  | 81,650 |  |  | 93,003 |  |
| General and administrative | 30,097 |  |  | 31,882 |  |  | 36,285 |  |  | 28,560 |  |  | 29,553 |  |  | 30,302 |  |  | 29,743 |  |  | 33,804 |  |
| Amortization of intangible assets | 12,439 |  |  | 11,493 |  |  | 11,019 |  |  | 11,019 |  |  | 11,019 |  |  | 11,019 |  |  | 11,019 |  |  | 36,454 |  |
| Acquisition and integration costs | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 1,020 |  |  | 2,435 |  |  | 22,084 |  |
| Restructuring costs | 115 |  |  | — |  |  | 63 |  |  | 171 |  |  | 8,085 |  |  | (17 | ) |  | 192 |  |  | 366 |  |
| Total operating expenses | 222,496 |  |  | 230,529 |  |  | 226,971 |  |  | 222,652 |  |  | 226,130 |  |  | 229,997 |  |  | 225,418 |  |  | 293,570 |  |
| Income (loss) from operations | 3,355 |  |  | 7,162 |  |  | 37,002 |  |  | (1,815 | ) |  | 4,165 |  |  | 42,414 |  |  | 44,451 |  |  | 9,418 |  |
| Interest and other income (loss), net | (5,998 | ) |  | (1,905 | ) |  | (6,328 | ) |  | (11,031 | ) |  | (8,233 | ) |  | (5,549 | ) |  | (5,491 | ) |  | (6,232 | ) |
| Interest expense | (11,028 | ) |  | (11,020 | ) |  | (11,508 | ) |  | (13,559 | ) |  | (13,661 | ) |  | (12,947 | ) |  | (11,883 | ) |  | (12,688 | ) |
| Income (loss) before income taxes | (13,671 | ) |  | (5,763 | ) |  | 19,166 |  |  | (26,405 | ) |  | (17,729 | ) |  | 23,918 |  |  | 27,077 |  |  | (9,502 | ) |
| Provision for income tax | 2,265 |  |  | 4,395 |  |  | 3,006 |  |  | 4,298 |  |  | 1,050 |  |  | 3,265 |  |  | 3,452 |  |  | 4,330 |  |
| Net income (loss) | $ | (15,936 | ) |  | $ | (10,158 | ) |  | $ | 16,160 |  |  | $ | (30,703 | ) |  | $ | (18,779 | ) |  | $ | 20,653 |  |  | $ | 23,625 |  |  | $ | (13,832 | ) |
| Basic net income (loss) per common share | $ | (0.15 | ) |  | $ | (0.10 | ) |  | $ | 0.15 |  |  | $ | (0.29 | ) |  | $ | (0.17 | ) |  | $ | 0.18 |  |  | $ | 0.20 |  |  | $ | (0.10 | ) |
| Diluted net income (loss) per potential common share | $ | (0.15 | ) |  | $ | (0.10 | ) |  | $ | 0.15 |  |  | $ | (0.29 | ) |  | $ | (0.17 | ) |  | $ | 0.17 |  |  | $ | 0.19 |  |  | $ | (0.10 | ) |
| Weighted average basic common shares outstanding | 104,501 |  |  | 105,451 |  |  | 106,236 |  |  | 106,931 |  |  | 107,773 |  |  | 113,555 |  |  | 118,413 |  |  | 134,097 |  |
| Weighted average diluted potential common shares outstanding | 104,501 |  |  | 105,451 |  |  | 120,809 |  |  | 106,931 |  |  | 107,773 |  |  | 128,017 |  |  | 133,233 |  |  | 134,097 |  |

[0000936395-15-000062:mdna:272]
65
