# CIEN 8-K — 0000936395-15-000058 filed 2015-12-10

## item codes, every 8-K on or before 2015-12-21

- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2015-12-21

- none on or before 2015-12-21

## item 2.02 — earnings release, exhibit 99.1

[0000936395-15-000058:8k_2_02:1]
EX-99.1
2
a20158kpressrelease.htm
EXHIBIT 99.1

[0000936395-15-000058:8k_2_02:2]
Exhibit

[0000936395-15-000058:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-15-000058:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2015 and Year-End Financial Results

[0000936395-15-000058:8k_2_02:5]
Delivers 11% adjusted operating margin and $1.31 adjusted EPS for the year

[0000936395-15-000058:8k_2_02:6]
HANOVER, Md. - December 10, 2015 - Ciena® Corporation (NYSE: CIEN), the network specialist, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2015.

[0000936395-15-000058:8k_2_02:7]
For the fiscal fourth quarter 2015, Ciena reported revenue of $692.0 million as compared to $591.0 million for the fiscal fourth quarter 2014. For fiscal year 2015, Ciena reported revenue of $2.4 billion, as compared to $2.3 billion for fiscal year 2014.

[0000936395-15-000058:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net loss for the fiscal fourth quarter 2015 was $(13.8) million, or $(0.10) per diluted common share, which compares to a GAAP net loss of $(30.7) million, or $(0.29) per diluted common share, for the fiscal fourth quarter 2014. For fiscal year 2015, Ciena had a GAAP net income of $11.7 million, or $0.10 per diluted common share, which compares to a GAAP net loss of $(40.6) million or $(0.38) per diluted common share for fiscal year 2014.

[0000936395-15-000058:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2015 was $67.3 million, or $0.42 per diluted common share, which compares to an adjusted (non-GAAP) net loss of $(8.2) million, or $(0.08) per diluted common share, for the fiscal fourth quarter 2014. For fiscal year 2015, Ciena's adjusted (non-GAAP) net income was $179.0 million, or $1.31 per diluted common share, as compared to an adjusted (non-GAAP) net income of $65.8 million, or $0.59 per diluted common share for fiscal year 2014.

[0000936395-15-000058:8k_2_02:10]
"Our strong financial performance in fiscal 2015 included substantial increases in gross and operating margin as well as meaningful cash generation, which enabled us to exceed the longer-term financial milestones that we established several years ago,” said Gary Smith, president and CEO, Ciena. “We believe that our proven ability to drive operating leverage from the business, when combined with strong market drivers from the next phase of network transformation, positions us well to deliver continued growth and profitability in fiscal 2016 and beyond.”

[0000936395-15-000058:8k_2_02:11]
Fiscal Fourth Quarter 2015 Performance Summary

[0000936395-15-000058:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarterly and year over year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendices A and B.

[0000936395-15-000058:8k_2_02:13]
|  |  | GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 692.0 |  |  | $ | 602.9 |  |  | $ | 591.0 |  |  | 14.8 | % |  | 17.1 | % |
| Gross margin |  | 43.8 | % |  | 44.8 | % |  | 37.4 | % |  | (1.0 | )% |  | 6.4 | % |
| Operating expense |  | $ | 293.6 |  |  | $ | 225.4 |  |  | $ | 222.7 |  |  | 30.3 | % |  | 31.8 | % |
| Operating margin |  | 1.4 | % |  | 7.4 | % |  | (0.3 | )% |  | (6.0 | )% |  | 1.7 | % |

[0000936395-15-000058:8k_2_02:14]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q4 |  | Q3 |  | Q4 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 692.0 |  |  | $ | 602.9 |  |  | $ | 591.0 |  |  | 14.8 | % |  | 17.1 | % |
| Adj. gross margin |  | 44.9 | % |  | 45.3 | % |  | 37.9 | % |  | (0.4 | )% |  | 7.0 | % |
| Adj. operating expense |  | $ | 220.5 |  |  | $ | 202.1 |  |  | $ | 203.7 |  |  | 9.1 | % |  | 8.2 | % |
| Adj. operating margin |  | 13.0 | % |  | 11.8 | % |  | 3.4 | % |  | 1.2 | % |  | 9.6 | % |

[0000936395-15-000058:8k_2_02:15]
* Denotes % change, or in the case of margin, absolute change

[0000936395-15-000058:8k_2_02:16]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q4 FY 2015 |  | Q3 FY 2015 |  | Q4 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 484.3 |  |  | 70.0 |  | $ | 408.0 |  |  | 67.7 |  | $ | 383.3 |  |  | 64.9 |
| Packet Networking |  | 63.8 |  |  | 9.2 |  | 57.2 |  |  | 9.5 |  | 56.4 |  |  | 9.5 |
| Optical Transport |  | 16.7 |  |  | 2.4 |  | 17.5 |  |  | 2.9 |  | 26.5 |  |  | 4.5 |
| Software and Services |  | 127.2 |  |  | 18.4 |  | 120.2 |  |  | 19.9 |  | 124.8 |  |  | 21.1 |
| Total |  | $ | 692.0 |  |  | 100.0 |  | $ | 602.9 |  |  | 100.0 |  | $ | 591.0 |  |  | 100.0 |

[0000936395-15-000058:8k_2_02:17]
Additional Performance Metrics for Fiscal Fourth Quarter 2015

[0000936395-15-000058:8k_2_02:18]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q4 FY 2015 |  | Q3 FY 2015 |  | Q4 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 480.0 |  |  | 69.4 |  | $ | 389.6 |  |  | 64.6 |  | $ | 340.5 |  |  | 57.6 |
| Europe, Middle East and Africa |  | 94.0 |  |  | 13.6 |  | 93.2 |  |  | 15.5 |  | 133.7 |  |  | 22.6 |
| Caribbean and Latin America |  | 45.7 |  |  | 6.6 |  | 65.1 |  |  | 10.8 |  | 51.8 |  |  | 8.8 |
| Asia Pacific |  | 72.3 |  |  | 10.4 |  | 55.0 |  |  | 9.1 |  | 65.0 |  |  | 11.0 |
| Total |  | $ | 692.0 |  |  | 100.0 |  | $ | 602.9 |  |  | 100.0 |  | $ | 591.0 |  |  | 100.0 |

[0000936395-15-000058:8k_2_02:19]
| • | Non-U.S. customers contributed 34.5% of total revenue |

[0000936395-15-000058:8k_2_02:20]
| • | Two 10%-plus customer represented a total of 29.6% of revenue |

[0000936395-15-000058:8k_2_02:21]
| • | $84.4 million in revenue from the acquired Cyan business, principally relating to Z-Series Packet-Optical Platform |

[0000936395-15-000058:8k_2_02:22]
| • | Cash and investments totaled $1,021.2 million |

[0000936395-15-000058:8k_2_02:23]
| • | Cash flow from operations totaled $84.6 million |

[0000936395-15-000058:8k_2_02:24]
| • | Average days' sales outstanding (DSOs) were 72 |

[0000936395-15-000058:8k_2_02:25]
| • | Accounts receivable balance was $550.8 million |

[0000936395-15-000058:8k_2_02:26]
| • | Inventories totaled $191.2 million, including: |

[0000936395-15-000058:8k_2_02:27]
| ◦ | Raw materials: $53.1 million |

[0000936395-15-000058:8k_2_02:28]
| ◦ | Work in process: $9.1 million |

[0000936395-15-000058:8k_2_02:29]
| ◦ | Finished goods: $126.0 million |

[0000936395-15-000058:8k_2_02:30]
| ◦ | Deferred cost of sales: $56.0 million |

[0000936395-15-000058:8k_2_02:31]
| ◦ | Reserve for excess and obsolescence: $(53.0) million |

[0000936395-15-000058:8k_2_02:32]
| • | Product inventory turns were 6.8 |

[0000936395-15-000058:8k_2_02:33]
| • | Headcount totaled 5,345 |

[0000936395-15-000058:8k_2_02:34]
Business Outlook for Fiscal First Quarter 2016

[0000936395-15-000058:8k_2_02:35]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-15-000058:8k_2_02:36]
Ciena expects financial performance for fiscal first quarter 2016 to include:

[0000936395-15-000058:8k_2_02:37]
| • | Revenue in the range of $555 million to $590 million |

[0000936395-15-000058:8k_2_02:38]
| • | Adjusted (non-GAAP) gross margin of approximately 44 percent |

[0000936395-15-000058:8k_2_02:39]
| • | Adjusted (non-GAAP) operating expense of approximately $220 million |

[0000936395-15-000058:8k_2_02:40]
Ciena expects financial performance for fiscal year 2016 to include:

[0000936395-15-000058:8k_2_02:41]
| • | Revenue growth in the range of 8 to 9 percent |

[0000936395-15-000058:8k_2_02:42]
| • | Adjusted (non-GAAP) gross margin in the mid-40s percent range |

[0000936395-15-000058:8k_2_02:43]
| • | Adjusted (non-GAAP) operating expense of approximately $225 million per quarter |

[0000936395-15-000058:8k_2_02:44]
| • | Adjusted (non-GAAP) operating margin in the range of 11 to 12 percent |

[0000936395-15-000058:8k_2_02:45]
Live Web Broadcast

[0000936395-15-000058:8k_2_02:46]
Ciena will host a conference call today, Thursday, December 10, 2015 at 8:30 a.m. (Eastern), with investors and financial analysts to discuss its unaudited fiscal fourth quarter 2015 and year-end results, as well as to provide a new next-stage financial milestone for the company.

[0000936395-15-000058:8k_2_02:47]
The live broadcast of the discussion can be accessed via Ciena's homepage at http://www.ciena.com/, and an archived version will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors.

[0000936395-15-000058:8k_2_02:48]
About Ciena

[0000936395-15-000058:8k_2_02:49]
Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings,

[0000936395-15-000058:8k_2_02:50]
recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-15-000058:8k_2_02:51]
Notes to Investors

[0000936395-15-000058:8k_2_02:52]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “Our strong financial performance in fiscal 2015 included substantial increases in gross and operating margin as well as meaningful cash generation, which enabled us to exceed the longer-term financial milestones that we established several years ago”; “We believe that our proven ability to drive operating leverage from the business, when combined with strong market drivers from the next phase of network transformation, positions us well to deliver continued growth and profitability in fiscal 2016 and beyond"; "Ciena expects financial performance for fiscal first quarter 2016 to include revenue in the range of $555 million to $590 million, adjusted (non-GAAP) gross margin of approximately 44 percent, adjusted (non-GAAP) operating expense of approximately $220 million"; "Ciena expects financial performance for fiscal year 2016 to include revenue growth in the range of 8 to 9 percent, adjusted (non-GAAP) gross margin in the mid-40s percent range; adjusted (non-GAAP) operating expense of approximately $225 million per quarter, adjusted (non-GAAP) operating margin in the range of 11 to 12 percent."

[0000936395-15-000058:8k_2_02:53]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q filed with the Securities and Exchange Commission on September 9, 2015. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-15-000058:8k_2_02:54]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendixes A and B to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-15-000058:8k_2_02:55]
CIENA CORPORATION

[0000936395-15-000058:8k_2_02:56]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-15-000058:8k_2_02:57]
(in thousands, except per share data)

[0000936395-15-000058:8k_2_02:58]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 476,175 |  |  | $ | 574,281 |  |  | $ | 1,865,826 |  |  | $ | 2,002,395 |  |
| Services |  | 114,788 |  |  | 117,692 |  |  | 422,463 |  |  | 443,274 |  |
| Total revenue |  | 590,963 |  |  | 691,973 |  |  | 2,288,289 |  |  | 2,445,669 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 305,171 |  |  | 323,090 |  |  | 1,083,022 |  |  | 1,120,373 |  |
| Services |  | 64,955 |  |  | 65,895 |  |  | 256,915 |  |  | 249,733 |  |
| Total cost of goods sold |  | 370,126 |  |  | 388,985 |  |  | 1,339,937 |  |  | 1,370,106 |  |
| Gross profit |  | 220,837 |  |  | 302,988 |  |  | 948,352 |  |  | 1,075,563 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 98,506 |  |  | 107,859 |  |  | 401,180 |  |  | 414,201 |  |
| Selling and marketing |  | 84,396 |  |  | 93,003 |  |  | 328,325 |  |  | 333,836 |  |
| General and administrative |  | 28,560 |  |  | 33,804 |  |  | 126,824 |  |  | 123,402 |  |
| Amortization of intangible assets |  | 11,019 |  |  | 36,454 |  |  | 45,970 |  |  | 69,511 |  |
| Acquisition and integration costs |  | — |  |  | 22,084 |  |  | — |  |  | 25,539 |  |
| Restructuring costs |  | 171 |  |  | 366 |  |  | 349 |  |  | 8,626 |  |
| Total operating expenses |  | 222,652 |  |  | 293,570 |  |  | 902,648 |  |  | 975,115 |  |
| Income (loss) from operations |  | (1,815 | ) |  | 9,418 |  |  | 45,704 |  |  | 100,448 |  |
| Interest and other income (loss), net |  | (11,031 | ) |  | (6,232 | ) |  | (25,262 | ) |  | (25,505 | ) |
| Interest expense |  | (13,559 | ) |  | (12,688 | ) |  | (47,115 | ) |  | (51,179 | ) |
| Income (loss) before income taxes |  | (26,405 | ) |  | (9,502 | ) |  | (26,673 | ) |  | 23,764 |  |
| Provision (benefit) for income taxes |  | 4,298 |  |  | 4,330 |  |  | 13,964 |  |  | 12,097 |  |
| Net income (loss) |  | $ | (30,703 | ) |  | $ | (13,832 | ) |  | $ | (40,637 | ) |  | $ | 11,667 |  |
| Net Income (loss) per Common Share |  |  |  |  |  |  |  |  |
| Basic net income (loss) per common share |  | $ | (0.29 | ) |  | $ | (0.10 | ) |  | $ | (0.38 | ) |  | $ | 0.10 |  |
| Diluted net income (loss) per potential common share |  | $ | (0.29 | ) |  | $ | (0.10 | ) |  | $ | (0.38 | ) |  | $ | 0.10 |  |
| Weighted average basic common shares outstanding |  | 106,931 |  |  | 134,097 |  |  | 105,783 |  |  | 118,416 |  |
| Weighted average diluted potential common shares outstanding 1 |  | 106,931 |  |  | 134,097 |  |  | 105,783 |  |  | 120,101 |  |

[0000936395-15-000058:8k_2_02:59]
1.  Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units.

[0000936395-15-000058:8k_2_02:60]
CIENA CORPORATION

[0000936395-15-000058:8k_2_02:61]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-15-000058:8k_2_02:62]
(in thousands, except share data)

[0000936395-15-000058:8k_2_02:63]
|  | October 31, |
|  | 2014 |  | 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 790,971 |  |
| Short-term investments | 140,205 |  |  | 135,107 |  |
| Accounts receivable, net | 518,981 |  |  | 550,792 |  |
| Inventories | 254,660 |  |  | 191,162 |  |
| Prepaid expenses and other | 192,624 |  |  | 196,178 |  |
| Total current assets | 1,693,190 |  |  | 1,864,210 |  |
| Long-term investments | 50,057 |  |  | 95,105 |  |
| Equipment, building, furniture and fixtures, net | 126,632 |  |  | 191,973 |  |
| Goodwill, net | — |  |  | 256,434 |  |
| Other intangible assets, net | 128,677 |  |  | 202,673 |  |
| Other long-term assets | 74,076 |  |  | 84,656 |  |
| Total assets | $ | 2,072,632 |  |  | $ | 2,695,051 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 209,777 |  |  | $ | 222,140 |  |
| Accrued liabilities and other short-term obligations | 276,608 |  |  | 316,283 |  |
| Deferred revenue | 104,688 |  |  | 126,111 |  |
| Current portion of long-term debt | 190,063 |  |  | 2,500 |  |
| Total current liabilities | 781,136 |  |  | 667,034 |  |
| Long-term deferred revenue | 40,930 |  |  | 62,962 |  |
| Other long-term obligations | 45,390 |  |  | 72,540 |  |
| Long-term debt, net | 1,274,791 |  |  | 1,271,639 |  |
| Total liabilities | 2,142,247 |  |  | 2,074,175 |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 106,979,960 and 135,612,217 shares issued and outstanding | 1,070 |  |  | 1,356 |  |
| Additional paid-in capital | 5,954,440 |  |  | 6,640,436 |  |
| Accumulated other comprehensive loss | (14,668 | ) |  | (22,126 | ) |
| Accumulated deficit | (6,010,457 | ) |  | (5,998,790 | ) |
| Total stockholders’ equity (deficit) | (69,615 | ) |  | 620,876 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 2,072,632 |  |  | $ | 2,695,051 |  |

[0000936395-15-000058:8k_2_02:64]
CIENA CORPORATION

[0000936395-15-000058:8k_2_02:65]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-15-000058:8k_2_02:66]
(in thousands)

[0000936395-15-000058:8k_2_02:67]
|  | Year Ended October 31, |
|  | 2014 |  | 2015 |
| Cash flows from operating activities: |  |  |  |
| Net income (loss) | $ | (40,637 | ) |  | $ | 11,667 |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 55,616 |  |  | 55,901 |  |
| Share-based compensation costs | 42,930 |  |  | 55,340 |  |
| Amortization of intangible assets | 57,151 |  |  | 79,866 |  |
| Provision for inventory excess and obsolescence | 32,332 |  |  | 26,846 |  |
| Provision for warranty | 22,129 |  |  | 17,881 |  |
| Other | 25,668 |  |  | (1,023 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (33,164 | ) |  | (9,496 | ) |
| Inventories | (37,889 | ) |  | 49,501 |  |
| Prepaid expenses and other | (7,931 | ) |  | (21,988 | ) |
| Accounts payable, accruals and other obligations | (59,837 | ) |  | (29,195 | ) |
| Deferred revenue | 33,448 |  |  | 26,812 |  |
| Net cash provided by operating activities | 89,816 |  |  | 262,112 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (48,216 | ) |  | (62,109 | ) |
| Restricted cash | 2,060 |  |  | (40 | ) |
| Purchase of available for sale securities | (245,196 | ) |  | (245,323 | ) |
| Proceeds from maturities of available for sale securities | 195,000 |  |  | 205,000 |  |
| Settlement of foreign currency forward contracts, net | (10,041 | ) |  | 24,133 |  |
| Purchase of cost method investment | — |  |  | (2,000 | ) |
| Acquisition of business, net of cash acquired | — |  |  | 37,212 |  |
| Net cash used in investing activities | (106,393 | ) |  | (43,127 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | 248,750 |  |  | — |  |
| Payment of long-term debt | (625 | ) |  | (29,867 | ) |
| Payment of debt and equity issuance costs | (4,227 | ) |  | (421 | ) |
| Payment of capital lease obligations | (3,034 | ) |  | (8,038 | ) |
| Proceeds from issuance of common stock | 17,663 |  |  | 30,275 |  |
| Net cash provided by (used in) financing activities | 258,527 |  |  | (8,051 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (1,717 | ) |  | (6,683 | ) |
| Net increase in cash and cash equivalents | 240,233 |  |  | 204,251 |  |
| Cash and cash equivalents at beginning of fiscal year | 346,487 |  |  | 586,720 |  |
| Cash and cash equivalents at end of fiscal year | $ | 586,720 |  |  | $ | 790,971 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 36,276 |  |  | $ | 40,772 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 11,396 |  |  | $ | 10,668 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,961 |  |  | $ | 20,922 |  |
| Equipment acquired under capital leases | $ | 10,424 |  |  | $ | 464 |  |
| Building subject to capital lease | $ | — |  |  | $ | 14,939 |  |
| Construction in progress subject to build-to-suit lease | $ | — |  |  | $ | 18,663 |  |
| Non-cash financing activities |  |  |  |
| Conversion of 4.0% convertible senior notes, due March 15, 2015 into 8,898,387 shares of common stock | $ | — |  |  | $ | 180,645 |  |
| Conversion of 8.0% convertible senior notes, due December 15, 2019, assumed from the Cyan acquisition, into 4,589,626 shares of common stock | $ | — |  |  | $ | 117,140 |  |
| Fair value of shares issued related to acquisition of business | $ | — |  |  | $ | 302,114 |  |

[0000936395-15-000058:8k_2_02:68]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements (unaudited) |
|  |  | Quarter Ended |
|  |  | October 31, |
|  |  | 2014 |  | 2015 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 220,837 |  |  | $ | 302,988 |  |
| Share-based compensation-products |  | 547 |  |  | 589 |  |
| Share-based compensation-services |  | 496 |  |  | 573 |  |
| Amortization of intangible assets |  | 2,201 |  |  | 3,438 |  |
| Fair value adjustment of acquired inventory |  | — |  |  | 3,069 |  |
| Total adjustments related to gross profit |  | 3,244 |  |  | 7,669 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 224,081 |  |  | $ | 310,657 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 37.9 | % |  | 44.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 222,652 |  |  | $ | 293,570 |  |
| Share-based compensation-research and development |  | 1,960 |  |  | 3,850 |  |
| Share-based compensation-sales and marketing |  | 2,759 |  |  | 4,468 |  |
| Share-based compensation-general and administrative |  | 3,025 |  |  | 5,860 |  |
| Share-based compensation-acquisition and integration |  | — |  |  | 7,588 |  |
| Amortization of intangible assets |  | 11,019 |  |  | 36,454 |  |
| Acquisition and integration costs, excluding share-based compensation |  | — |  |  | 14,496 |  |
| Restructuring costs |  | 171 |  |  | 366 |  |
| Total adjustments related to operating expense |  | 18,934 |  |  | 73,082 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 203,718 |  |  | $ | 220,488 |  |
| Income (Loss) from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income (loss) from operations |  | $ | (1,815 | ) |  | $ | 9,418 |  |
| Total adjustments related to gross profit |  | 3,244 |  |  | 7,669 |  |
| Total adjustments related to operating expense |  | 18,934 |  |  | 73,082 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 20,363 |  |  | 90,169 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 3.4 | % |  | 13.0 | % |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net loss |  | $ | (30,703 | ) |  | $ | (13,832 | ) |
| Total adjustments related to gross profit |  | 3,244 |  |  | 7,669 |  |
| Total adjustments related to operating expense |  | 18,934 |  |  | 73,082 |  |
| Non-cash interest expense |  | 351 |  |  | 362 |  |
| Adjusted (non-GAAP) net income (loss) |  | $ | (8,174 | ) |  | $ | 67,281 |  |
| Weighted average basic common shares outstanding |  | 106,931 |  |  | 134,097 |  |
| Weighted average dilutive potential common shares outstanding1 |  | 106,931 |  |  | 177,054 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net loss per common share |  | $ | (0.29 | ) |  | $ | (0.10 | ) |
| Adjusted (non-GAAP) diluted net income (loss) per common share2 |  | $ | (0.08 | ) |  | $ | 0.42 |  |

[0000936395-15-000058:8k_2_02:69]
| APPENDIX B - Reconciliation of Adjusted (Non- GAAP) Annual Measurements (unaudited) |
|  |  | Year Ended |
|  |  | October 31, |
|  |  | 2014 |  | 2015 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 948,352 |  |  | $ | 1,075,563 |  |
| Share-based compensation-products |  | 2,531 |  |  | 2,400 |  |
| Share-based compensation-services |  | 2,216 |  |  | 2,156 |  |
| Amortization of intangible assets |  | 11,181 |  |  | 10,039 |  |
| Fair value adjustment of acquired inventory |  | — |  |  | 3,069 |  |
| Total adjustments related to gross profit |  | 15,928 |  |  | 17,664 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 964,280 |  |  | $ | 1,093,227 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 42.1 | % |  | 44.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 902,648 |  |  | $ | 975,115 |  |
| Share-based compensation-research and development |  | 9,682 |  |  | 10,665 |  |
| Share-based compensation-sales and marketing |  | 14,958 |  |  | 15,539 |  |
| Share-based compensation-general and administrative |  | 13,568 |  |  | 17,018 |  |
| Share-based compensation-acquisition and integration |  | — |  |  | 7,588 |  |
| Amortization of intangible assets |  | 45,970 |  |  | 69,511 |  |
| Acquisition and integration costs, excluding share-based compensation |  | — |  |  | 17,951 |  |
| Restructuring costs |  | 349 |  |  | 8,626 |  |
| Settlement of patent litigation |  | 2,000 |  |  | 500 |  |
| Total adjustments related to operating expense |  | 86,527 |  |  | 147,398 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 816,121 |  |  | $ | 827,717 |  |
| Income (Loss) from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 45,704 |  |  | $ | 100,448 |  |
| Total adjustments related to gross profit |  | 15,928 |  |  | 17,664 |  |
| Total adjustments related to operating expense |  | 86,527 |  |  | 147,398 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 148,159 |  |  | 265,510 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 6.5 | % |  | 10.9 | % |
| Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income (loss) |  | $ | (40,637 | ) |  | $ | 11,667 |  |
| Total adjustments related to gross profit |  | 15,928 |  |  | 17,664 |  |
| Total adjustments related to operating expense |  | 86,527 |  |  | 147,398 |  |
| Non-cash expense associated with the conversion of convertible notes |  | — |  |  | 768 |  |
| Non-cash interest expense |  | 1,273 |  |  | 1,491 |  |
| Change in fair value of embedded redemption feature |  | 2,740 |  |  | — |  |
| Adjusted (non-GAAP) net income |  | $ | 65,831 |  |  | $ | 178,988 |  |
| Weighted average basic common shares outstanding |  | 105,783 |  |  | 118,416 |  |
| Weighted average dilutive potential common shares outstanding3 |  | 120,950 |  |  | 163,308 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | (0.38 | ) |  | $ | 0.10 |  |
| Adjusted (non-GAAP) diluted net income per common share4 |  | $ | 0.59 |  |  | $ | 1.31 |  |

[0000936395-15-000058:8k_2_02:70]
1.  Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2015 includes 2.7 million shares underlying certain stock options and restricted stock units, 13.0 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018, 0.7 million shares underlying the 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-15-000058:8k_2_02:71]
2. The calculation of Adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018, approximately $0.1 million associated with Ciena's 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000058:8k_2_02:72]
3.  Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2014 includes 2.1 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-15-000058:8k_2_02:73]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units, 3.4 million shares underlying Ciena's 4.0% convertible senior notes (which were paid at maturity during the second quarter of fiscal 2015), 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018, 0.2 million shares underlying Ciena's 8.0% convertible senior notes assumed from the Cyan acquisition, due December 15, 2019, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-15-000058:8k_2_02:74]
4. The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2014 requires adding back interest expense of approximately $5.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000058:8k_2_02:75]
The calculation of Adjusted (non-GAAP) diluted net income per common share for fiscal 2015 requires adding back interest expense of approximately $3.2 million approximately associated with Ciena's 4.0% convertible senior notes (which were paid at maturity during the second quarter of fiscal 2015), approximately $5.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $14.3 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018, approximately $0.1 million associated with Ciena's 8.0% convertible senior notes, due December 15, 2019 assumed from the Cyan acquisition and approximately $11.4 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000058:8k_2_02:76]
* * *

[0000936395-15-000058:8k_2_02:77]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-15-000058:8k_2_02:78]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-15-000058:8k_2_02:79]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs related to our recent acquisition of Cyan. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-15-000058:8k_2_02:80]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over the expected useful life. |

[0000936395-15-000058:8k_2_02:81]
| • | Fair value adjustment of acquired inventory - an infrequent charge required by acquisition accounting rules resulting from the required revaluation of inventory acquired from Cyan to estimated fair value. This revaluation resulted in a net increase in inventory carrying value and an increase in cost of goods sold for the periods indicated. |

[0000936395-15-000058:8k_2_02:82]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-15-000058:8k_2_02:83]
| • | Settlement of patent litigation - included in general and administrative expense is a $2.0 million patent litigation settlement during the second quarter of fiscal 2014 and a $0.5 million patent litigation settlement during the third quarter of fiscal 2015. |

[0000936395-15-000058:8k_2_02:84]
| • | Non-cash expense associated with the conversion of convertible notes - a non-cash expense related to certain private exchange offers conducted with several holders of Ciena's 4.0% senior convertible notes due March 15, 2015 prior to maturity of such notes |

[0000936395-15-000058:8k_2_02:85]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-15-000058:8k_2_02:86]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015, which were paid at maturity during the second quarter of fiscal 2015. |
