# CIEN notes — 0000936395-15-000062


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-15-000062:notes:1]
ABL CREDIT FACILITY

[0000936395-15-000062:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of October 31, 2015, letters of credit totaling $63.4 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2015.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-15-000062:notes:3]
Substantially all of Ciena's cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena's cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-15-000062:notes:4]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 21 below.

[0000936395-15-000062:notes:5]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-15-000062:notes:6]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Consolidated Statement of Operations to which the grant activity relates.


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-15-000062:notes:7]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-15-000062:notes:8]
PREPAID EXPENSES AND OTHER

[0000936395-15-000062:notes:9]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-15-000062:notes:10]
|  | October 31, |
|  | 2014 |  | 2015 |
| Prepaid VAT and other taxes | $ | 86,464 |  |  | $ | 74,754 |  |
| Product demonstration equipment, net | 42,385 |  |  | 41,611 |  |
| Deferred deployment expense | 27,991 |  |  | 26,193 |  |
| Prepaid expenses | 23,539 |  |  | 25,074 |  |
| Financing receivable | — |  |  | 19,869 |  |
| Other non-trade receivables | 10,683 |  |  | 8,588 |  |
| Derivative assets | 1,562 |  |  | 89 |  |
|  | $ | 192,624 |  |  | $ | 196,178 |  |

[0000936395-15-000062:notes:11]
Depreciation of product demonstration equipment was $7.4 million, $9.0 million and $9.8 million for fiscal 2013, 2014 and 2015, respectively.


## cien:ScheduleOfInventoryValuationReservesTableTextBlock

[0000936395-15-000062:notes:12]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-15-000062:notes:13]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Disposals |  | Balance |
| 2013 |  | $ | 40,010 |  |  | $ | 19,938 |  |  | $ | 18,385 |  |  | $ | 41,563 |  |
| 2014 |  | $ | 41,563 |  |  | $ | 32,332 |  |  | $ | 13,769 |  |  | $ | 60,126 |  |
| 2015 |  | $ | 60,126 |  |  | $ | 26,846 |  |  | $ | 33,971 |  |  | $ | 53,001 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-15-000062:notes:14]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-15-000062:notes:15]
Term Loan

[0000936395-15-000062:notes:16]
On July 15, 2014, Ciena entered into a Credit Agreement providing for a senior secured term loan in an aggregate principal amount of $250 million (the “Term Loan”), which bears interest at a rate equal to LIBOR (subject to a floor of 0.75%) plus an applicable margin of 3.00%, and matures on July 15, 2019. The Term Loan Credit Agreement requires Ciena to make quarterly installment payments in aggregate amounts equal to 0.25% of the original principal amount of the Term Loan, or approximately $0.6 million, with the balance of the Term Loan payable at maturity. The Term Loan Credit Agreement requires mandatory prepayments on the occurrence of certain customary events and, when the total secured net leverage ratio (as defined in the Term Loan Credit Agreement) is in excess of 2.50 to 1.00, the Term Loan Credit Agreement requires a mandatory prepayment of 50% of excess annual cash flow (as defined in the Term Loan Credit Agreement).

[0000936395-15-000062:notes:17]
The Term Loan Credit Agreement contains customary covenants that limit, absent lender approval, the ability of Ciena to, among other things, incur additional debt, create liens and encumbrances, pay cash dividends, enter into certain acquisition transactions or transactions with affiliates, merge, dissolve, repay certain indebtedness, change the nature of Ciena’s business, make investments or dispose of assets.

[0000936395-15-000062:notes:18]
The Term Loan Credit Agreement contains customary events of default including, among other things, failure to pay obligations when due, initiation of bankruptcy or insolvency proceedings, defaults on certain other indebtedness, change of control, incurrence of certain material judgments, violation of affirmative and negative covenants, and breaches of representations and warranties set forth in the Term Loan Credit Agreement. Upon an event of default, the administrative agent may, subject to various customary cure rights, require the immediate payment of all amounts outstanding and foreclose on collateral.

[0000936395-15-000062:notes:19]
In connection with Ciena entering into the Term Loan Credit Agreement, Ciena and certain of its subsidiaries entered into a guaranty, a security agreement and a pledge agreement, each on customary terms. The Term Loan is secured by (i) second-priority security interests in the ABL Priority Collateral (as defined in Note 16 below), and (ii) first-priority security interests in substantially all other tangible and intangible assets including equipment, intercompany notes, intellectual property and material owned real property (the "Term Loan Priority Collateral").

[0000936395-15-000062:notes:20]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of October 31, 2015 (in thousands):

[0000936395-15-000062:notes:21]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 246,875 |  |  | $ | (1,076 | ) |  | $ | 245,799 |  |

[0000936395-15-000062:notes:22]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-15-000062:notes:23]
|  |  | October 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,799 |  |  | $ | 247,184 |  |

[0000936395-15-000062:notes:24]
| (1) | Includes unamortized bond discount. |

[0000936395-15-000062:notes:25]
| (2) | The Term Loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving this security. |

[0000936395-15-000062:notes:26]
Outstanding Convertible Notes Payable

[0000936395-15-000062:notes:27]
Ciena has three issuances of convertible notes payable outstanding. The notes are senior unsecured obligations of Ciena and rank equally with all of Ciena’s other existing and future senior unsecured debt. The indentures governing Ciena’s notes provide for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal or interest; breach of covenants or other agreements in the indenture; defaults in or failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing, the trustee or the holders of at least 25% in aggregate principal amount of the notes may declare the principal of, accrued interest on, and premium, if any, on all the notes immediately due and payable. Under the indentures, if Ciena undergoes a “fundamental change” (as that term is defined in the indenture governing the notes to include certain change in control transactions), holders of notes will have the right, subject to certain exemptions, to require Ciena to purchase for cash any or all of their notes at a price equal to the principal amount, plus accrued interest. If the holder elects to convert his or her notes in connection with a specified fundamental change Ciena will be required, in certain circumstances, to increase the applicable conversion rate, depending on the price paid per share for Ciena common stock and the effective date of the fundamental change transaction.

[0000936395-15-000062:notes:28]
4.0% Convertible Senior Notes, due March 15, 2015

[0000936395-15-000062:notes:29]
On March 15, 2015, Ciena's outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture, together with certain private exchange transactions conducted by Ciena prior to maturity, approximately $180.6 million in aggregate principal amount of 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, Ciena issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. Ciena repaid in cash approximately $6.9 million in aggregate principal amount of 2015 Notes at maturity.

[0000936395-15-000062:notes:30]
0.875% Convertible Senior Notes due June 15, 2017

[0000936395-15-000062:notes:31]
On June 11, 2007, Ciena completed a public offering of 0.875% convertible senior notes due June 15, 2017, in aggregate principal amount of $500.0 million. Interest is payable on June 15 and December 15 of each year, beginning on December 15, 2007.

[0000936395-15-000062:notes:32]
At the election of the holder, the notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 26.2154 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $38.15 per share. The notes are not redeemable by Ciena prior to maturity.

[0000936395-15-000062:notes:33]
Ciena used approximately $42.5 million of the net proceeds of this offering to purchase a call spread option on its common stock that is intended to limit exposure to potential dilution from conversion of the notes. See Note 18 below for a description of this call spread option.

[0000936395-15-000062:notes:34]
During the fourth quarter of fiscal 2015, Ciena entered into certain private exchange transactions to repurchase $5.9 million of the notes for cash slightly below par.

[0000936395-15-000062:notes:35]
3.75% Convertible Senior Notes, due October 15, 2018

[0000936395-15-000062:notes:36]
On October 18, 2010, Ciena completed a private placement of 3.75% convertible senior notes due October 15, 2018, in aggregate principal amount of $350.0 million. Interest is payable on the notes on April 15 and October 15 of each year, beginning on April 15, 2011.

[0000936395-15-000062:notes:37]
At the election of the holder, the notes may be converted prior to maturity into shares of Ciena common stock at the initial conversion rate of 49.5872 shares per $1,000 in principal amount, which is equivalent to an initial conversion price of approximately $20.17 per share.

[0000936395-15-000062:notes:38]
The net proceeds from the offering were approximately $340.4 million after deducting the placement agents’ fees and other fees and expenses. Ciena used $76.1 million of the net proceeds to effect the repurchase of its 0.25% convertible senior notes due 2013, which matured during fiscal 2013.

[0000936395-15-000062:notes:39]
4.0% Convertible Senior Notes due December 15, 2020

[0000936395-15-000062:notes:40]
On December 27, 2012, Ciena issued $187.5 million in aggregate principal amount of 4.0% Convertible Senior Notes due December 15, 2020 (the “2020 Notes”) in separate private offerings in exchange for $187.5 million in aggregate principal amount of 2015 Notes above.

[0000936395-15-000062:notes:41]
The 2020 Notes are senior unsecured obligations and rank equally with all of Ciena's other existing and future senior unsecured debt. The 2020 Notes pay interest from the date of issuance at a rate of 4.0% per year. The interest is payable semi-annually on June 15 and December 15, commencing on June 15, 2013. The principal amount of the 2020 Notes will also accrete at a rate of 1.85% per year commencing December 27, 2012, compounding on a semi-annual basis. The accreted portion of the principal payable at maturity does not bear interest and is not convertible into shares of Ciena's common stock. The 2020 Notes will mature on December 15, 2020. Consequently, in the event the 2020 Notes are converted, the accreted liability will extinguish without payment.

[0000936395-15-000062:notes:42]
The 2020 Notes may be converted prior to maturity, at the option of the holder, into shares of Ciena's common stock at an initial conversion rate of 49.0557 shares of common stock per $1,000 in original principal amount, which is equal to an initial conversion price of $20.39 per share. In addition, Ciena may elect to convert the 2020 Notes, in whole or in part, at any time on or prior to December 15, 2020, if the daily volume weighted average price of the common stock equals or exceeds 130% of the conversion price then in effect for at least 20 trading days in any 30 consecutive trading day period. If Ciena elects to convert the 2020 Notes on or before maturity, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena's election. An aggregate of 9,197,944 shares of Ciena common stock issuable upon conversion of the 2020 Notes has been reserved for issuance.

[0000936395-15-000062:notes:43]
Upon certain fundamental changes, holders of the 2020 Notes have the option to require Ciena to purchase the 2020 Notes at a price equal to the accreted principal amount of the notes delivered for repurchase plus any accrued and unpaid interest on the original principal amount. Upon a holder's election to convert the 2020 Notes in connection with certain fundamental changes, the conversion rate will be adjusted to include an amount of additional shares, determined by reference to a make-whole table, payable in Ciena common stock, or its cash equivalent, at Ciena's election.

[0000936395-15-000062:notes:44]
Accounting guidance issued by the FASB requires the issuer of convertible debt instruments with cash settlement features, including partial cash settlement, to account separately for the liability and equity components of the instrument. Under this guidance, the debt is recognized at the present value of its cash flows discounted using the issuer's nonconvertible debt borrowing rate at the time of issuance and the equity component is recognized as the difference between the proceeds from the issuance of the note and the fair value of the liability. The reduced carrying value on the convertible debt results in a debt discount that is accreted back to the convertible debt's principal amount through the recognition of non-cash interest expense over the expected life of the debt, which results in recognizing the interest expense on these borrowings at effective rates approximating what Ciena would have incurred had nonconvertible debt with otherwise similar terms been issued.

[0000936395-15-000062:notes:45]
Because the additional make-whole shares can be settled in cash or common stock at Ciena's option, the debt and equity components were accounted for separately. Ciena measured the fair value of the debt component of the 2020 Notes using an effective interest rate of 7.0%. As a result, Ciena attributed $170.4 million of the fair value of the 2020 Notes to the debt component. The debt component was netted against the face value of the 2020 Notes to determine the debt discount. The debt discount will be accreted over the period from the date of issuance to the contractual maturity date, resulting in the recognition of non-cash interest expense. In addition, Ciena recorded $43.1 million within additional paid-in capital representing the equity component of the 2020 Notes. There was no net tax expense recorded due to Ciena’s full valuation allowance against its deferred tax assets.

[0000936395-15-000062:notes:46]
The 2020 Notes were issued pursuant to an Indenture entered into as of December 27, 2012 (the “Indenture”) with The Bank of New York Mellon Trust Company, N.A., as trustee. The Indenture provides for customary events of default which include (subject in certain cases to customary grace and cure periods), among others, the following: nonpayment of principal (including accreted portion) or interest; breach of covenants or other agreements in the Indenture; defaults in failure to pay certain other indebtedness; and certain events of bankruptcy or insolvency. Generally, if an event of default occurs and is continuing under the Indenture, the trustee or the holders of at least 25% in aggregate original principal amount of the 2020 Notes then outstanding may declare the principal (including accreted portion), premium, if any, and accrued interest on all the 2020 Notes immediately due and payable.

[0000936395-15-000062:notes:47]
The principal balance, unamortized discount and net carrying value of the liability and equity components of our 2020 notes were as follows as of October 31, 2015

[0000936395-15-000062:notes:48]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 197,582 |  |  | $ | (13,347 | ) |  | $ | 184,235 |  |  | $ | 43,131 |  |

[0000936395-15-000062:notes:49]
The following table sets forth, in thousands, the carrying value and the estimated current fair value of Ciena’s outstanding convertible notes:

[0000936395-15-000062:notes:50]
|  |  | October 31, 2015 |
| Description |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 494,105 |  |  | $ | 494,723 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 |  | 350,000 |  |  | 482,125 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(2) |  | 184,235 |  |  | 265,791 |  |
|  |  | $ | 1,028,340 |  |  | $ | 1,242,639 |  |

[0000936395-15-000062:notes:51]
_________________________________

[0000936395-15-000062:notes:52]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000062:notes:53]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-15-000062:notes:54]
Ciena expenses all advertising costs as incurred.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0000936395-15-000062:notes:55]
These unaudited pro forma amounts (in thousands) do not purport to be indicative of the results that would have actually been obtained if the acquisition occurred as of the beginning of the periods presented, or that may be obtained in the future.

[0000936395-15-000062:notes:56]
|  | Fiscal Year |
|  | 2014 |  | 2015 |
| Pro forma revenue | $ | 2,388,772 |  |  | $ | 2,565,081 |  |
| Pro forma net income (loss) | $ | (168,041 | ) |  | $ | 16,286 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-15-000062:notes:57]
BUSINESS COMBINATIONS

[0000936395-15-000062:notes:58]
On August 3, 2015, Ciena acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all the then-outstanding Cyan unvested restricted stock unit awards and stock options and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

[0000936395-15-000062:notes:59]
Upon the closing of the acquisition, Ciena assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of 2019 Notes surrendered for conversion. Subsequently, during the fourth quarter of fiscal 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes surrendered their 2019 notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, Ciena issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

[0000936395-15-000062:notes:60]
During fiscal 2015, Ciena incurred approximately $25.5 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other employment-related costs, including payments to certain former Cyan executives and approximately $7.6 million of non-cash share-based compensation expense.

[0000936395-15-000062:notes:61]
The following table summarizes the purchase price for the acquisition (in thousands):

[0000936395-15-000062:notes:62]
|  | Amount |
| Cash | $ | 33,621 |  |
| Value of common stock issued | 270,113 |  |
| Fair value of vested stock awards | 32,001 |  |
| Total purchase price | $ | 335,735 |  |

[0000936395-15-000062:notes:63]
The fair value of Ciena's common stock issued in the acquisition was based on Ciena's opening stock price on August 3, 2015. The fair value of replacement vested stock options was determined using the Black-Scholes option-pricing model.

[0000936395-15-000062:notes:64]
The following table summarizes the final allocation related to Cyan based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-15-000062:notes:65]
|  | Amount |
| Cash and cash equivalents | $ | 60,831 |  |
| Restricted cash | 10,001 |  |
| Accounts receivable | 23,891 |  |
| Inventory | 12,849 |  |
| Prepaid expenses and other | 3,502 |  |
| Equipment, furniture and fixtures | 7,962 |  |
| Goodwill | 256,434 |  |
| Customer relationships | 36,323 |  |
| Trademarks | 3,432 |  |
| Developed technology | 88,814 |  |
| Order backlog | 25,293 |  |
| Other long-term assets | 789 |  |
| Accounts payable | (30,856 | ) |
| Accrued liabilities | (15,887 | ) |
| Deferred revenue | (16,643 | ) |
| Long-term debt | (48,836 | ) |
| Additional paid-in capital related to equity component of long-term debt | (82,164 | ) |
| Total purchase consideration | $ | 335,735 |  |

[0000936395-15-000062:notes:66]
Under purchase accounting rules, Ciena valued the acquired finished goods inventory to fair value, which is defined as the estimated selling price less the sum of (a) costs of disposal, and (b) a reasonable profit allowance for Ciena’s selling effort. This valuation resulted in an increase in inventory carrying value of approximately $3.1 million for marketable inventory.

[0000936395-15-000062:notes:67]
Customer relationships and contracts represent agreements with existing Cyan customers and have estimated useful lives of 4 years to 7 years. The majority of the order backlog, which is amortized over the fulfillment period, was fulfilled during the  fourth quarter of fiscal 2015.

[0000936395-15-000062:notes:68]
Developed technology represents purchased technology that had reached technological feasibility and for which Cyan had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful lives of 5 years to 7 years.

[0000936395-15-000062:notes:69]
The goodwill generated from the acquisition of Cyan was primarily related to expected synergies. The amount of goodwill allocated to the Converged Packet Optical segment and the Software and Services segment was $55.0 million and $201.4 million, respectively. The goodwill is not deductible for income tax purposes.

[0000936395-15-000062:notes:70]
The following unaudited pro forma financial information summarizes the results of operations for the periods indicated as if Ciena’s acquisition of Cyan had been completed as of the beginning of the earliest period. Revenue attributable to Cyan since the August 3, 2015 acquisition date was $84.4 million. As Ciena has begun to integrate the combined operations, eliminating overlapping processes and expenses and integrating its products and sales efforts with those of Cyan, it is impractical to determine the earnings specific to Cyan since the acquisition date. These unaudited pro forma amounts (in thousands) do not purport to be indicative of the results that would have actually been obtained if the acquisition occurred as of the beginning of the periods presented, or that may be obtained in the future.

[0000936395-15-000062:notes:71]
The pro forma earnings were adjusted to exclude $25.5 million in acquisition-related costs and $3.1 million of nonrecurring expense related to the fair value adjustment to acquisition-date inventory incurred in fiscal 2015. Fiscal 2014 pro forma earnings were adjusted to include these amounts.

[0000936395-15-000062:notes:72]
Additionally, pro forma earnings were adjusted to (i) exclude the mark to market changes in the fair value of Cyan's warrants, as they were automatically exercised on a cashless basis immediately prior to the effective time of the merger and (ii) exclude the fair value of bifurcated conversion features in Cyan's convertible notes, as these features were no longer bifurcated upon the consummation of the merger. The total amounts of these adjustments were $4.7 million and $60.6 million in fiscal 2014 and 2015, respectively.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-15-000062:notes:73]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-15-000062:notes:74]
COMMITMENTS AND CONTINGENCIES

[0000936395-15-000062:notes:75]
Ontario Grant

[0000936395-15-000062:notes:76]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena was eligible to receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of October 31, 2015, Ciena has received payment for the full amount of the grant. Payments received were recorded as a reduction in research and development expenses.

[0000936395-15-000062:notes:77]
Foreign Tax Contingencies

[0000936395-15-000062:notes:78]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-15-000062:notes:79]
Litigation

[0000936395-15-000062:notes:80]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:

[0000936395-15-000062:notes:81]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

[0000936395-15-000062:notes:82]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

[0000936395-15-000062:notes:83]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

[0000936395-15-000062:notes:84]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

[0000936395-15-000062:notes:85]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

[0000936395-15-000062:notes:86]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss. A briefing schedule for these motions has been set, with briefing to be completed in March 2016.

[0000936395-15-000062:notes:87]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-15-000062:notes:88]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-15-000062:notes:89]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-15-000062:notes:90]
Lease Commitments

[0000936395-15-000062:notes:91]
Ciena has certain minimum obligations under non-cancelable leases expiring on various dates through 2032 for equipment and facilities. The following table summarizes our future annual minimum lease commitments under non-cancelable leases that are not recorded on the balance as of October 31, 2015 (in thousands):

[0000936395-15-000062:notes:92]
|  |  | 2016 |  | 2017 |  | 2018 |  | 2019 |  | 2020 |  | Thereafter |  | Total |
| Operating leases |  | $ | 32,480 |  |  | $ | 30,030 |  |  | $ | 18,823 |  |  | $ | 12,279 |  |  | $ | 9,693 |  |  | $ | 46,449 |  |  | $ | 149,754 |  |
| Other lease commitments (1) |  | 646 |  |  | 1,731 |  |  | 6,081 |  |  | 6,081 |  |  | 6,146 |  |  | 82,139 |  |  | 102,824 |  |
| Total |  | $ | 33,126 |  |  | $ | 31,761 |  |  | $ | 24,904 |  |  | $ | 18,360 |  |  | $ | 15,839 |  |  | $ | 128,588 |  |  | $ | 252,578 |  |

[0000936395-15-000062:notes:93]
(1) Represents the expected timing and amounts of payments for rent associated with capital and build-to-suit lease arrangements that have not yet been placed into service. For future payments related to capital leases that have been placed into service, see Note 12 above.

[0000936395-15-000062:notes:94]
Rental expense for fiscal 2013, fiscal 2014 and fiscal 2015 was approximately $26.0 million, $22.9 million and $25.7 million, respectively. In addition, Ciena paid approximately $1.6 million, $0.5 million and $0.8 million during fiscal 2013, fiscal 2014 and fiscal 2015, respectively, related to rent costs for restructured facilities and unfavorable lease commitments, which were offset against Ciena’s restructuring liabilities and unfavorable lease obligations. The amount for operating lease commitments above does not include variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material impact on Ciena's financial condition, results of operations or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-15-000062:notes:95]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-15-000062:notes:96]
OTHER EMPLOYEE BENEFIT PLANS

[0000936395-15-000062:notes:97]
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$25,370 for 2015). This plan includes a required employer contribution of 1% for all participants and a 50% matching of participant contributions up to a total annual maximum of CAD$3,000 per employee. During fiscal 2013, 2014 and 2015, Ciena made matching contributions of approximately CAD$3.9 million, CAD$4.1 million and CAD$4.3 million, respectively.

[0000936395-15-000062:notes:98]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of pre-tax compensation, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2013, 2014 and 2015, Ciena made matching contributions of approximately $4.0 million, $4.5 million and $4.7 million, respectively.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-15-000062:notes:99]
ACCUMULATED OTHER COMPREHENSIVE INCOME

[0000936395-15-000062:notes:100]
The following table summarizes the changes in accumulated balances of other comprehensive income (AOCI):

[0000936395-15-000062:notes:101]
|  |  | Unrealized Gain/(Loss) on Marketable Securities |  | Unrealized Gain/(Loss) on Foreign Currency Forward Contracts |  | Unrealized Gain/(Loss) on Forward Starting Interest Rate Swap |  | Cumulative Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2012 |  | $ | 44 |  |  | $ | 49 |  |  | $ | — |  |  | $ | (3,447 | ) |  | $ | (3,354 | ) |
| Other comprehensive loss before reclassifications |  | (14 | ) |  | (1,431 | ) |  | — |  |  | (4,096 | ) |  | (5,541 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 1,121 |  |  | — |  |  | — |  |  | 1,121 |  |
| Balance at October 31, 2013 |  | 30 |  |  | (261 | ) |  | — |  |  | (7,543 | ) |  | (7,774 | ) |
| Other comprehensive loss before reclassifications |  | 41 |  |  | (1,265 | ) |  | (2,083 | ) |  | (4,940 | ) |  | (8,247 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 1,353 |  |  | — |  |  | — |  |  | 1,353 |  |
| Balance at October 31, 2014 |  | 71 |  |  | (173 | ) |  | (2,083 | ) |  | (12,483 | ) |  | (14,668 | ) |
| Other comprehensive loss before reclassifications |  | (149 | ) |  | (5,547 | ) |  | (4,232 | ) |  | (3,775 | ) |  | (13,703 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 5,452 |  |  | 793 |  |  | — |  |  | 6,245 |  |
| Balance at October 31, 2015 |  | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |

[0000936395-15-000062:notes:102]
All amounts reclassified from accumulated other comprehensive income related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted "research and development" on the Consolidated Statements of Operations. All amounts reclassified from accumulated other comprehensive income related to settlement (gains)  losses on forward starting interest swaps designated as cash flow hedges impacted "interest and other income (loss), net" on the Consolidated Statements of Operations.


## us-gaap:ConsolidationPolicyTextBlock

[0000936395-15-000062:notes:103]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-15-000062:notes:104]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-15-000062:notes:105]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-15-000062:notes:106]
|  | October 31, |
|  | 2014 |  | 2015 |
| Products | $ | 50,457 |  |  | $ | 66,527 |  |
| Services | 95,161 |  |  | 122,546 |  |
|  | 145,618 |  |  | 189,073 |  |
| Less current portion | (104,688 | ) |  | (126,111 | ) |
| Long-term deferred revenue | $ | 40,930 |  |  | $ | 62,962 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-15-000062:notes:107]
DERIVATIVE INSTRUMENTS

[0000936395-15-000062:notes:108]
Foreign Currency Derivatives

[0000936395-15-000062:notes:109]
As of October 31, 2015 and 2014, Ciena had forward contracts to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $68.1 million and $51.5 million as of October 31, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-15-000062:notes:110]
During fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount. During fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. The notional principal of these contracts was approximately $146.5 million and $194.5 million as of October 31, 2015 and October 31, 2014. These foreign exchange contracts have maturities of 12 months or less. These derivative contracts have not been designated as hedges.

[0000936395-15-000062:notes:111]
Interest Rate Derivatives

[0000936395-15-000062:notes:112]
During fiscal 2014 Ciena entered into interest rate cap arrangements to limit interest paid under the Term Loan to a maximum of 0.75% plus a spread of 300 basis points through July 2015. The interest rate caps expired in July 2015. Also in fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004%, for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of October 31, 2015 and October 31, 2014 was $246.9 million and $247.5 million, respectively.

[0000936395-15-000062:notes:113]
Ciena expects the variable rate payments to be received under the terms of the interest rate swap to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-15-000062:notes:114]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 4 and Note 6 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-15-000062:notes:115]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative that expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000062:notes:116]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-15-000062:notes:117]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.

[0000936395-15-000062:notes:118]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-15-000062:notes:119]
SHARE-BASED COMPENSATION EXPENSE

[0000936395-15-000062:notes:120]
Ciena has outstanding equity awards issued under its legacy equity plans and equity plans assumed as a result of previous acquisitions. In connection with its acquisition of Cyan during the fourth quarter of fiscal 2015, Ciena also assumed the Cyan, Inc. 2006 and 2013 Stock Incentive Plans and exchanged outstanding Cyan stock options and unvested restricted stock unit awards at closing for options to acquire approximately 2.4 million shares of Ciena common stock and 1.0 million Ciena restricted stock units. Ciena grants equity awards under its 2008 Omnibus Incentive Plan and makes shares of its common stock available for purchase under its Amended and Restated Employee Stock Purchase Plan (“ESPP”).

[0000936395-15-000062:notes:121]
2008 Plan

[0000936395-15-000062:notes:122]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. As of October 31, 2015, the total number of shares authorized for issuance under the 2008 Plan is 25.1 million and approximately 6.3 million shares remained available for issuance thereunder.

[0000936395-15-000062:notes:123]
Stock Options

[0000936395-15-000062:notes:124]
Outstanding stock option awards to employees are generally subject to service-based vesting conditions and vest incrementally over a four-year period. The following table is a summary of Ciena's stock option activity for the periods indicated (shares in thousands):

[0000936395-15-000062:notes:125]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of October 31, 2014 | 1,288 |  |  | $ | 25.43 |  |
| Granted | — |  |  | — |  |
| Granted in exchange for Cyan options | 2,381 |  |  | 18.20 |  |
| Exercised | (1,165 | ) |  | 12.49 |  |
| Canceled | (211 | ) |  | 25.84 |  |
| Balance as of October 31, 2015 | 2,293 |  |  | $ | 24.45 |  |

[0000936395-15-000062:notes:126]
The total intrinsic value of options exercised during fiscal 2013, fiscal 2014 and fiscal 2015 was $2.0 million, $1.0 million and $11.8 million, respectively. There were no stock options granted by Ciena during fiscal 2013, fiscal 2014 or fiscal 2015. The weighted average fair value of each stock option granted by Ciena in exchange for Cyan awards was $13.04.

[0000936395-15-000062:notes:127]
The following table summarizes information with respect to stock options outstanding at October 31, 2015, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2015 (shares and intrinsic value in thousands):

[0000936395-15-000062:notes:128]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | October 31, 2015 |  | October 31, 2015 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) | Price |  | Value |
| $ | 0.05 |  |  | — |  |  | $ | 11.16 |  |  | 418 |  |  | 3.65 |  | $ | 6.58 |  |  | $ | 7,337 |  |  | 414 |  |  | 3.59 | $ | 6.55 |  |  | $ | 7,277 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 599 |  |  | 5.74 |  | 13.52 |  |  | 6,366 |  |  | 488 |  |  | 5.41 | 13.36 |  |  | 5,267 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 81 |  |  | 4.92 |  | 19.52 |  |  | 372 |  |  | 52 |  |  | 2.91 | 20.28 |  |  | 200 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 268 |  |  | 1.45 |  | 27.37 |  |  | — |  |  | 265 |  |  | 1.39 | 27.39 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 31.08 |  |  | 89 |  |  | 1.83 |  | 29.82 |  |  | — |  |  | 89 |  |  | 1.83 | 29.82 |  |  | — |  |
| $ | 31.85 |  |  | — |  |  | $ | 32.55 |  |  | 56 |  |  | 4.87 |  | 32.04 |  |  | — |  |  | 46 |  |  | 4.41 | 32.03 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 398 |  |  | 2.36 |  | 35.95 |  |  | — |  |  | 378 |  |  | 2.10 | 35.90 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 55.63 |  |  | 384 |  |  | 4.00 |  | 45.69 |  |  | — |  |  | 311 |  |  | 3.15 | 45.65 |  |  | — |  |
| $ | 0.05 |  |  | — |  |  | $ | 55.63 |  |  | 2,293 |  |  | 3.78 |  | $ | 24.45 |  |  | $ | 14,075 |  |  | 2,043 |  |  | 3.32 | $ | 24.20 |  |  | $ | 12,744 |  |

[0000936395-15-000062:notes:129]
Assumptions for Option-Based Awards

[0000936395-15-000062:notes:130]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2013, fiscal 2014, or fiscal 2015. Ciena used the following assumptions for option-based awards issued in exchange for Cyan options:

[0000936395-15-000062:notes:131]
| Expected volatility | 35.87 | % |
| Risk-free interest rate | 1.26 | % |
| Expected term (years) | 0.72-6.88 |  |
| Expected dividend yield | 0.0 | % |

[0000936395-15-000062:notes:132]
Restricted Stock Units

[0000936395-15-000062:notes:133]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-15-000062:notes:134]
The following table is a summary of Ciena's restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena's closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-15-000062:notes:135]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of October 31, 2014 | 4,012 |  |  | $ | 18.02 |  |  | $ | 67,241 |  |
| Granted | 2,666 |  |  |  |  |  |
| Granted in exchange for Cyan awards | 1,030 |  |  |  |  |  |
| Vested | (2,320 | ) |  |  |  |  |
| Canceled or forfeited | (502 | ) |  |  |  |  |
| Balance as of October 31, 2015 | 4,886 |  |  | $ | 20.02 |  |  | $ | 117,951 |  |

[0000936395-15-000062:notes:136]
The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2013, fiscal 2014 and fiscal 2015 was $37.3 million, $48.1 million and $50.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2013, fiscal 2014 and fiscal 2015 was $16.30, $21.82 and $19.41, respectively. The weighted average fair value of each restricted stock unit granted by Ciena in exchange for Cyan awards was $25.39.

[0000936395-15-000062:notes:137]
Assumptions for Restricted Stock Unit Awards

[0000936395-15-000062:notes:138]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized, net of estimated forfeitures, ratably over the vesting period on a straight-line basis.

[0000936395-15-000062:notes:139]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-15-000062:notes:140]
Because share-based compensation expense is recognized only for those awards that are ultimately expected to vest, the amount of share-based compensation expense recognized reflects a reduction for estimated forfeitures. Ciena estimates forfeitures at the time of grant and revises those estimates in subsequent periods based upon new or changed information.

[0000936395-15-000062:notes:141]
Amended and Restated Employee Stock Purchase Plan (ESPP)

[0000936395-15-000062:notes:142]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP's “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-15-000062:notes:143]
During fiscal 2013, fiscal 2014 and fiscal 2015, Ciena issued 0.9 million, 0.9 million and 1.0 million shares under the ESPP, respectively. At October 31, 2015, 6.4 million shares remained available for issuance under the ESPP.

[0000936395-15-000062:notes:144]
Share-Based Compensation Expense for Periods Reported

[0000936395-15-000062:notes:145]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-15-000062:notes:146]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Product costs | $ | 2,522 |  |  | $ | 2,531 |  |  | $ | 2,400 |  |
| Service costs | 1,771 |  |  | 2,216 |  |  | 2,156 |  |
| Share-based compensation expense included in cost of goods sold | 4,293 |  |  | 4,747 |  |  | 4,556 |  |
| Research and development | 8,214 |  |  | 9,682 |  |  | 10,665 |  |
| Sales and marketing | 13,290 |  |  | 14,958 |  |  | 15,539 |  |
| General and administrative | 12,055 |  |  | 13,568 |  |  | 17,018 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 7,588 |  |
| Share-based compensation expense included in operating expense | 33,559 |  |  | 38,208 |  |  | 50,810 |  |
| Share-based compensation expense capitalized in inventory, net | (132 | ) |  | (25 | ) |  | (26 | ) |
| Total share-based compensation | $ | 37,720 |  |  | $ | 42,930 |  |  | $ | 55,340 |  |

[0000936395-15-000062:notes:147]
As of October 31, 2015, total unrecognized share-based compensation expense was $78.7 million: (i) $2.8 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.6 years; and (ii) $75.9 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-15-000062:notes:148]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement.


## us-gaap:EarningsPerShareTextBlock

[0000936395-15-000062:notes:149]
EARNINGS (LOSS) PER SHARE CALCULATION

[0000936395-15-000062:notes:150]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, and (iv) shares underlying Ciena’s outstanding convertible notes.

[0000936395-15-000062:notes:151]
Numerator

[0000936395-15-000062:notes:152]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Net income (loss) | $ | (85,431 | ) |  | $ | (40,637 | ) |  | $ | 11,667 |  |

[0000936395-15-000062:notes:153]
Denominator

[0000936395-15-000062:notes:154]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Basic weighted average shares outstanding | 102,350 |  |  | 105,783 |  |  | 118,416 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | — |  |  | — |  |  | 1,685 |  |
| Diluted weighted average shares outstanding | 102,350 |  |  | 105,783 |  |  | 120,101 |  |

[0000936395-15-000062:notes:155]
EPS

[0000936395-15-000062:notes:156]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Basic EPS | $ | (0.83 | ) |  | $ | (0.38 | ) |  | $ | 0.10 |  |
| Diluted EPS | $ | (0.83 | ) |  | $ | (0.38 | ) |  | $ | 0.10 |  |

[0000936395-15-000062:notes:157]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-15-000062:notes:158]
|  | Year Ended October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Shares underlying stock options and restricted stock units | 3,890 |  |  | 3,176 |  |  | 1,562 |  |
| 0.25% Convertible Senior Notes due May 1, 2013 | 2,682 |  |  | — |  |  | — |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 10,541 |  |  | 9,198 |  |  | 3,386 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | 13,108 |  |  | 13,080 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,355 |  |  | 17,355 |  |  | 17,355 |  |
| 8.0% Cyan Convertible Senior Notes due 2019 | — |  |  | — |  |  | 187 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 7,855 |  |  | 9,198 |  |  | 9,198 |  |
| Total excluded due to anti-dilutive effect | 55,431 |  |  | 52,035 |  |  | 44,768 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-15-000062:notes:159]
As of the dates indicated, the following tables summarizes the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-15-000062:notes:160]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 440,013 |  |  | $ | — |  |  | $ | — |  |  | $ | 440,013 |  |
| U.S. government obligations | — |  |  | 160,268 |  |  | — |  |  | 160,268 |  |
| Commercial paper | — |  |  | 89,989 |  |  | — |  |  | 89,989 |  |
| Foreign currency forward contracts | — |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Forward starting interest rate swap | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |

[0000936395-15-000062:notes:161]
|  | October 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 642,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,073 |  |
| U.S. government obligations | — |  |  | 205,223 |  |  | — |  |  | 205,223 |  |
| Commercial paper | — |  |  | 74,983 |  |  | — |  |  | 74,983 |  |
| Foreign currency forward contracts | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total assets measured at fair value | $ | 642,073 |  |  | $ | 280,295 |  |  | $ | — |  |  | $ | 922,368 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 512 |  |  | $ | — |  |  | $ | 512 |  |
| Forward starting interest rate swap | — |  |  | 5,522 |  |  | — |  |  | 5,522 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,034 |  |  | $ | — |  |  | $ | 6,034 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-15-000062:notes:162]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-15-000062:notes:163]
|  | October 31, 2014 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 440,013 |  |  | $ | 59,995 |  |  | $ | — |  |  | $ | 500,008 |  |
| Short-term investments | — |  |  | 140,205 |  |  | — |  |  | 140,205 |  |
| Prepaid expenses and other | — |  |  | 1,561 |  |  | — |  |  | 1,561 |  |
| Long-term investments | — |  |  | 50,057 |  |  | — |  |  | 50,057 |  |
| Total assets measured at fair value | $ | 440,013 |  |  | $ | 251,818 |  |  | $ | — |  |  | $ | 691,831 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 200 |  |  | $ | — |  |  | $ | 200 |  |
| Other long-term obligations | — |  |  | 2,083 |  |  | — |  |  | 2,083 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,283 |  |  | $ | — |  |  | $ | 2,283 |  |

[0000936395-15-000062:notes:164]
|  | October 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 642,073 |  |  | $ | 49,994 |  |  | $ | — |  |  | $ | 692,067 |  |
| Short-term investments | — |  |  | 135,107 |  |  | — |  |  | 135,107 |  |
| Prepaid expenses and other | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Long-term investments | — |  |  | 95,105 |  |  | — |  |  | 95,105 |  |
| Total assets measured at fair value | $ | 642,073 |  |  | $ | 280,295 |  |  | $ | — |  |  | $ | 922,368 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 512 |  |  | $ | — |  |  | $ | 512 |  |
| Other long-term obligations | — |  |  | 5,522 |  |  | — |  |  | 5,522 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,034 |  |  | $ | — |  |  | $ | 6,034 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-15-000062:notes:165]
FAIR VALUE MEASUREMENTS

[0000936395-15-000062:notes:166]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-15-000062:notes:167]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-15-000062:notes:168]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-15-000062:notes:169]
INCOME TAXES

[0000936395-15-000062:notes:170]
For the periods indicated, the provision for income taxes consists of the following (in thousands):

[0000936395-15-000062:notes:171]
|  | October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Provision for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | — |  |  | $ | — |  |  | $ | — |  |
| State | 906 |  |  | 1,831 |  |  | 1,435 |  |
| Foreign | 4,334 |  |  | 12,133 |  |  | 10,662 |  |
| Total current | 5,240 |  |  | 13,964 |  |  | 12,097 |  |
| Deferred: |  |  |  |  |  |
| Federal | — |  |  | — |  |  | — |  |
| State | — |  |  | — |  |  | — |  |
| Foreign | — |  |  | — |  |  | — |  |
| Total deferred | — |  |  | — |  |  | — |  |
| Provision for income taxes | $ | 5,240 |  |  | $ | 13,964 |  |  | $ | 12,097 |  |

[0000936395-15-000062:notes:172]
For the periods indicated, income (loss) before provision for income taxes consists of the following (in thousands):

[0000936395-15-000062:notes:173]
|  | October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| United States | $ | (59,594 | ) |  | $ | (42,742 | ) |  | $ | (1,029 | ) |
| Foreign | (20,597 | ) |  | 16,069 |  |  | 24,793 |  |
| Total | $ | (80,191 | ) |  | $ | (26,673 | ) |  | $ | 23,764 |  |

[0000936395-15-000062:notes:174]
Ciena's foreign income tax as a percentage of foreign income is dependent upon the mix of earnings in our foreign jurisdictions. Depending upon the mix of earnings in these jurisdictions, including those jurisdictions which are loss making, the tax on total foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate. Ciena expects that this result may continue until earnings from foreign operations mature and maintain a more consistent contribution.

[0000936395-15-000062:notes:175]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income or loss before income taxes by the U.S. federal statutory rate of 35% as follows:

[0000936395-15-000062:notes:176]
|  | October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| Provision at statutory rate | 35.00 | % |  | 35.00 | % |  | 35.00 | % |
| State taxes | (1.13 | )% |  | (6.87 | )% |  | 6.04 | % |
| Foreign taxes | (12.70 | )% |  | (70.25 | )% |  | 28.98 | % |
| Research and development credit | 17.39 | % |  | 32.07 | % |  | (25.55 | )% |
| Non-deductible loss on debt extinguishment | (11.21 | )% |  | — | % |  | — | % |
| Non-deductible compensation and other | (8.78 | )% |  | (29.59 | )% |  | 30.16 | % |
| Valuation allowance | (25.10 | )% |  | (12.71 | )% |  | (23.73 | )% |
| Effective income tax rate | (6.53 | )% |  | (52.35 | )% |  | 50.90 | % |

[0000936395-15-000062:notes:177]
As a result of prospective application of Accounting Standards Update No. 2015-17, Income Taxes (Topic 740): Balance Sheet Classification of Deferred Taxes, Ciena offset all deferred tax liabilities and assets, as well as any related valuation allowance, and is presenting them as a single non-current amount as of October 31, 2015. Ciena has not retrospectively adjusted prior periods.

[0000936395-15-000062:notes:178]
The significant components of deferred tax assets and liabilities are as follows (in thousands):

[0000936395-15-000062:notes:179]
|  | October 31, |
|  | 2014 |  | 2015 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 59,707 |  |  | $ | 63,290 |  |
| Depreciation and amortization | 268,783 |  |  | 203,991 |  |
| NOL and credit carry forward | 1,155,389 |  |  | 1,202,641 |  |
| Other | 12,956 |  |  | 25,750 |  |
| Gross deferred tax assets | 1,496,835 |  |  | 1,495,672 |  |
| Valuation allowance | (1,496,835 | ) |  | (1,495,672 | ) |
| Net deferred tax asset | $ | — |  |  | $ | — |  |

[0000936395-15-000062:notes:180]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-15-000062:notes:181]
|  | Amount |
| Unrecognized tax benefits at October 31, 2012 | $ | 11,052 |  |
| Decrease related to positions taken in prior period | (3,925 | ) |
| Increase related to positions taken in current period | 2,146 |  |
| Reductions related to expiration of statute of limitations | (994 | ) |
| Unrecognized tax benefits at October 31, 2013 | 8,279 |  |
| Increase related to positions taken in prior period | 2,479 |  |
| Increase related to positions taken in current period | 5,241 |  |
| Reductions related to expiration of statute of limitations | (899 | ) |
| Unrecognized tax benefits at October 31, 2014 | 15,100 |  |
| Increase related to positions taken in prior period | 3,658 |  |
| Increase related to positions taken in current period | 9,138 |  |
| Reductions related to expiration of statute of limitations | (360 | ) |
| Unrecognized tax benefits at October 31, 2015 | $ | 27,536 |  |

[0000936395-15-000062:notes:182]
As of October 31, 2014 and 2015, Ciena had accrued $3.4 million and $4.3 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $2.0 million and $0.9 million were recorded to the provision for income taxes during fiscal 2014 and fiscal 2015 respectively, and no such charges or benefits were recorded for fiscal 2013. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-15-000062:notes:183]
During fiscal 2002, Ciena established a valuation allowance against its deferred tax assets. Ciena intends to maintain a valuation allowance until sufficient positive evidence exists to support a reversal. Any future release of the valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements. The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-15-000062:notes:184]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Additions |  | Deductions |  | Balance |
| 2013 |  | $ | 1,488,994 |  |  | $ | — |  |  | $ | 1,695 |  |  | $ | 1,487,299 |  |
| 2014 |  | $ | 1,487,299 |  |  | $ | 9,536 |  |  | $ | — |  |  | $ | 1,496,835 |  |
| 2015 |  | $ | 1,496,835 |  |  | $ | — |  |  | $ | 1,163 |  |  | $ | 1,495,672 |  |

[0000936395-15-000062:notes:185]
As of October 31, 2015, Ciena had a $2.9 billion net operating loss carry forward and a $0.1 billion income tax credit carry forward which begin to expire in fiscal year 2018 and 2019, respectively. Ciena’s ability to use net operating losses and credit carry forwards is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0000936395-15-000062:notes:186]
The income tax provision does not reflect the tax savings resulting from deductions associated with Ciena’s equity compensation and the call spread option associated with Ciena’s convertible debt. The cumulative tax benefit through October 31, 2015 of approximately $83.0 million will be credited to additional paid-in capital when realized. For deductions associated with Ciena’s equity compensation, credits to paid-in capital will be recorded when those tax benefits are used to reduce taxes payable.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-15-000062:notes:187]
Ciena accounts for income taxes using an asset and liability approach that recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-15-000062:notes:188]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 through 2013 and in Canada for 2010 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2012), United Kingdom (2013), Canada (2010) and India (2010). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-15-000062:notes:189]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and any expansion requirements.

[0000936395-15-000062:notes:190]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-15-000062:notes:191]
INTANGIBLE ASSETS

[0000936395-15-000062:notes:192]
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-15-000062:notes:193]
|  | October 31, |
|  | 2014 |  | 2015 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (351,929 | ) |  | $ | 65,904 |  |  | $ | 506,647 |  |  | $ | (382,130 | ) |  | $ | 124,517 |  |
| Patents and licenses | 46,538 |  |  | (45,908 | ) |  | 630 |  |  | 46,538 |  |  | (46,072 | ) |  | 466 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (261,430 | ) |  | 62,143 |  |  | 388,621 |  |  | (310,931 | ) |  | 77,690 |  |
| Total intangible assets | $ | 787,944 |  |  | $ | (659,267 | ) |  | $ | 128,677 |  |  | $ | 941,806 |  |  | $ | (739,133 | ) |  | $ | 202,673 |  |

[0000936395-15-000062:notes:194]
The aggregate amortization expense of intangible assets was $71.3 million, $57.2 million and $79.9 million for fiscal 2013, fiscal 2014 and fiscal 2015, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-15-000062:notes:195]
| Year Ended October 31, |  |
| 2016 | $ | 75,627 |  |
| 2017 | 41,773 |  |
| 2018 | 19,092 |  |
| 2019 | 18,545 |  |
| 2020 | 17,518 |  |
| Thereafter | 30,118 |  |
|  | $ | 202,673 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-15-000062:notes:196]
INVENTORIES

[0000936395-15-000062:notes:197]
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-15-000062:notes:198]
|  | October 31, |
|  | 2014 |  | 2015 |
| Raw materials | $ | 64,853 |  |  | $ | 53,082 |  |
| Work-in-process | 8,371 |  |  | 9,120 |  |
| Finished goods | 165,799 |  |  | 125,966 |  |
| Deferred cost of goods sold | 75,763 |  |  | 55,995 |  |
|  | 314,786 |  |  | 244,163 |  |
| Provision for excess and obsolescence | (60,126 | ) |  | (53,001 | ) |
|  | $ | 254,660 |  |  | $ | 191,162 |  |

[0000936395-15-000062:notes:199]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During fiscal 2013 and fiscal 2014, Ciena recorded a provision for inventory reserves that were primarily related to engineering design changes and the discontinuance of certain parts and components used in the manufacture of our Optical Transport products, including our Corestream® Agility Optical Transport platform and Converged Packet Optical products. During fiscal 2015, Ciena recorded a provision for excess and obsolescence of $26.8 million, primarily related to the discontinuance of certain parts and components used in the manufacture of its Converged Packet Optical products and a decrease in the forecasted demand for both its legacy, stand-alone WDM and SONET/SDH-based transport platforms and its 5410 Service Aggregation Switch. Deductions from the provision for excess and obsolete inventory relate to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-15-000062:notes:200]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-15-000062:notes:201]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions.


## us-gaap:InvestmentPolicyTextBlock

[0000936395-15-000062:notes:202]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-15-000062:notes:203]
The following table summarizes the legal maturities of debt investments at October 31, 2015:

[0000936395-15-000062:notes:204]
|  | October 31, 2015 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 135,097 |  |  | $ | 135,107 |  |
| Due in 1-2 years | 95,171 |  |  | 95,105 |  |
|  | $ | 230,268 |  |  | $ | 230,212 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-15-000062:notes:205]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-15-000062:notes:206]
As of October 31, 2014, investments are comprised of the following (in thousands):

[0000936395-15-000062:notes:207]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |

[0000936395-15-000062:notes:208]
As of October 31, 2015, investments are comprised of the following (in thousands):

[0000936395-15-000062:notes:209]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-15-000062:notes:210]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-15-000062:notes:211]
ACCOUNTS RECEIVABLE

[0000936395-15-000062:notes:212]
As of October 31, 2014, there were no customers that accounted for greater than 10% of net accounts receivable. As of October 31, 2015, there was one customer that accounted for 10.4% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-15-000062:notes:213]
| Year ended |  | Beginning |  |  |  | Net |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Deductions |  | Balance |
| 2013 |  | $ | 1,500 |  |  | $ | 2,339 |  |  | $ | 1,884 |  |  | $ | 1,955 |  |
| 2014 |  | $ | 1,955 |  |  | $ | 2,761 |  |  | $ | 2,633 |  |  | $ | 2,083 |  |
| 2015 |  | $ | 2,083 |  |  | $ | 1,576 |  |  | $ | 696 |  |  | $ | 2,963 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-15-000062:notes:214]
In November 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2015-17 (Topic 740), Balance Sheet Classification of Deferred Taxes. ASU 2015-17 requires deferred tax liabilities and assets to be classified as noncurrent in the Consolidated Balance Sheet. The standard will be effective for financial statements issued for annual periods beginning after December 15, 2016, and interim periods within those annual periods. Early adoption is permitted for financial statements that have not been previously issued. The ASU may be applied either prospectively to all deferred tax liabilities and assets or retrospectively to all periods presented. Ciena adopted this ASU on a prospective basis in the fourth quarter of fiscal 2015.

[0000936395-15-000062:notes:215]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-15-000062:notes:216]
In May 2014, FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.  In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-15-000062:notes:217]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect that the impact of adopting this guidance will be material to its Consolidated Financial Statements or disclosures.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-15-000062:notes:218]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES

[0000936395-15-000062:notes:219]
Description of Business

[0000936395-15-000062:notes:220]
Ciena Corporation (“Ciena” or the “Company”) is a network specialist focused on providing communications networking solutions that enable a wide range of network operators to adopt next-generation architectures. Ciena has optimized its business and solutions to enable network operators to create and deliver the broad array of high-bandwidth services relied upon by enterprise and consumer end users. Ciena provides equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. In addition to its high-capacity hardware platforms, Ciena offers network management and control software platforms that help network operators simplify and automate their networks and virtualize certain network functions. Ciena's solutions are designed to enable network operators to adopt open, multi-vendor, software-programmable network infrastructures that improve automation, reduce network complexity and flexibly support changing service requirements. Ciena's solutions yield business and operational value for its customers by enabling them to introduce new, revenue-generating services and to reduce network complexity and expense.

[0000936395-15-000062:notes:221]
Ciena's Converged Packet Optical, Packet Networking and Optical Transport products are used, individually or as part of an integrated solution, by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other network operators across the globe. Ciena's products, which support applications from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Ciena's software solutions are oriented around its Blue Planet software platform, a modular, network virtualization, service orchestration and network management software platform designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement its hardware and software solutions, Ciena offers a broad range of network transformation and related support services that help its customers design, optimize, deploy, manage and maintain their networks. Ciena’s principal executive offices are located at 7035 Ridge Road, Hanover, Maryland 21076.

[0000936395-15-000062:notes:222]
Basis of Presentation

[0000936395-15-000062:notes:223]
Ciena has a 52 or 53 week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 2, 2013,  November 1, 2014 and October 31, 2015 for the periods reported). Fiscal 2013, fiscal 2014 and fiscal 2015 each consisted of a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31.

[0000936395-15-000062:notes:224]
Ciena has identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each of the three quarters of fiscal 2015. The matters identified have no impact on any of the cash flow statement sub totals in any of the quarters, and are limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena intends to revise the affected periods when they are presented in fiscal 2016 on a comparable basis to reflect the correct accounting. The revisions will result in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $19.0 million, $10.0 million and $0.1 million for the nine, six and three month periods ending July 31, 2015, April 30, 2015 and January 31, 2015, respectively.

[0000936395-15-000062:notes:225]
Business Combinations

[0000936395-15-000062:notes:226]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-15-000062:notes:227]
Use of Estimates

[0000936395-15-000062:notes:228]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles ("GAAP") requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-15-000062:notes:229]
Cash and Cash Equivalents

[0000936395-15-000062:notes:230]
Investments

[0000936395-15-000062:notes:231]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of October 31, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

[0000936395-15-000062:notes:232]
Inventories

[0000936395-15-000062:notes:233]
Segment Reporting

[0000936395-15-000062:notes:234]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit(loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services. See Note 21 below.

[0000936395-15-000062:notes:235]
Goodwill

[0000936395-15-000062:notes:236]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-15-000062:notes:237]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period.

[0000936395-15-000062:notes:238]
Long-lived Assets

[0000936395-15-000062:notes:239]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-15-000062:notes:240]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The lease building is part of Ciena's new campus facility that will replace the Lab 10 research and development center on the former Nortel Carling campus. See Note 10 below.

[0000936395-15-000062:notes:241]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 12 below.

[0000936395-15-000062:notes:242]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two to five years.

[0000936395-15-000062:notes:243]
Intangible Assets

[0000936395-15-000062:notes:244]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-15-000062:notes:245]
Maintenance Spares

[0000936395-15-000062:notes:246]
Concentrations

[0000936395-15-000062:notes:247]
Revenue Recognition

[0000936395-15-000062:notes:248]
Ciena recognizes revenue when all of the following criteria are met: persuasive evidence of an arrangement exists; delivery has occurred or services have been rendered; the price to the buyer is fixed or determinable; and collectibility is reasonably assured. Customer purchase agreements and customer purchase orders are generally used to determine the existence of an arrangement. Shipping documents and evidence of customer acceptance, when applicable, are used to verify delivery or services rendered. Ciena assesses whether the price is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. Ciena assesses collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer's payment history. Revenue for maintenance services is deferred and recognized ratably over the period during which the services are performed. Shipping and handling fees billed to customers are included in revenue, with the associated expenses included in product cost of goods sold.

[0000936395-15-000062:notes:249]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the fiscal years ended October 31, 2013, October 31, 2014 and October 31, 2015 were 4.5%, 4.0% and 1.8%, respectively.

[0000936395-15-000062:notes:250]
Software revenue is recognized when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is probable. In instances where final acceptance criteria of the software are specified by the customer, revenue is deferred until there are no uncertainties regarding customer acceptance.

[0000936395-15-000062:notes:251]
Ciena limits the amount of revenue recognition for delivered elements to the amount that is not contingent on the future delivery of products or services, future performance obligations or subject to customer-specified return or refund privileges.

[0000936395-15-000062:notes:252]
Revenue for multiple element arrangements is allocated to each unit of accounting based on the relative selling price of each delivered element, with revenue recognized for each delivered element when the revenue recognition criteria are met. Ciena determines the selling price for each deliverable based upon the selling price hierarchy for multiple-deliverable arrangements. Under this hierarchy, Ciena uses vendor-specific objective evidence ("VSOE") of selling price, if it exists, or third party evidence ("TPE") of selling price if VSOE does not exist. If neither VSOE nor TPE of selling price exists for a deliverable, Ciena uses its best estimate of selling price ("BESP") for that deliverable. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, revenue for the entire arrangement is recognized over the maintenance term.

[0000936395-15-000062:notes:253]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

[0000936395-15-000062:notes:254]
Warranty Accruals

[0000936395-15-000062:notes:255]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based upon actual warranty cost experience, estimates of component failure rates and management's industry experience. Ciena's sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-15-000062:notes:256]
Accounts Receivable, Net

[0000936395-15-000062:notes:257]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.

[0000936395-15-000062:notes:258]
Research and Development

[0000936395-15-000062:notes:259]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, cost of prototype equipment, consulting and third party services, depreciation, facility costs and information technology.

[0000936395-15-000062:notes:260]
Government Grants

[0000936395-15-000062:notes:261]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Consolidated Statement of Operations to which the grant activity relates. See Note 23 below.

[0000936395-15-000062:notes:262]
Advertising Costs

[0000936395-15-000062:notes:263]
Legal Costs

[0000936395-15-000062:notes:264]
Share-Based Compensation Expense

[0000936395-15-000062:notes:265]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for shared-based awards with only service-based vesting. See Note 20 below.

[0000936395-15-000062:notes:266]
Income Taxes

[0000936395-15-000062:notes:267]
Loss Contingencies

[0000936395-15-000062:notes:268]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-15-000062:notes:269]
Fair Value of Financial Instruments

[0000936395-15-000062:notes:270]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loan, see Note 15 below.

[0000936395-15-000062:notes:271]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-15-000062:notes:272]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

[0000936395-15-000062:notes:273]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0000936395-15-000062:notes:274]
| • | Level 3 inputs are unobservable inputs based on Ciena's assumptions used to measure assets and liabilities at fair value. |

[0000936395-15-000062:notes:275]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset's or liability's classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-15-000062:notes:276]
Restructuring

[0000936395-15-000062:notes:277]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-15-000062:notes:278]
Foreign Currency

[0000936395-15-000062:notes:279]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000062:notes:280]
Derivatives

[0000936395-15-000062:notes:281]
See Notes 6 and 13 below.

[0000936395-15-000062:notes:282]
Computation of Net Income (Loss) per Share

[0000936395-15-000062:notes:283]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.

[0000936395-15-000062:notes:284]
Software Development Costs

[0000936395-15-000062:notes:285]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-15-000062:notes:286]
Newly Issued Accounting Standards -Effective


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-15-000062:notes:287]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-15-000062:notes:288]
|  | October 31, |
|  | 2014 |  | 2015 |
| Income tax liability | $ | 14,342 |  |  | $ | 13,308 |  |
| Deferred tenant allowance | 10,839 |  |  | 9,807 |  |
| Straight-line rent | 5,174 |  |  | 6,237 |  |
| Capital lease obligations | 4,589 |  |  | 13,794 |  |
| Construction liability | — |  |  | 18,663 |  |
| Forward starting interest rate swap | 2,083 |  |  | 5,522 |  |
| Other | 8,363 |  |  | 5,209 |  |
|  | $ | 45,390 |  |  | $ | 72,540 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-15-000062:notes:289]
INTEREST AND OTHER INCOME (LOSS), NET

[0000936395-15-000062:notes:290]
The components of interest and other income (loss), net, were as follow (in thousands):

[0000936395-15-000062:notes:291]
|  |  | October 31, |
|  |  | 2013 |  | 2014 |  | 2015 |
| Interest income |  | $ | 550 |  |  | $ | 407 |  |  | $ | 1,178 |  |
| Change in fair value of embedded derivative |  | 2,950 |  |  | (2,740 | ) |  | — |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts |  | 296 |  |  | (5,757 | ) |  | 23,243 |  |
| Foreign currency exchange losses |  | (8,168 | ) |  | (15,663 | ) |  | (47,607 | ) |
| Other |  | (1,372 | ) |  | (1,509 | ) |  | (2,319 | ) |
| Interest and other income (loss), net |  | $ | (5,744 | ) |  | $ | (25,262 | ) |  | $ | (25,505 | ) |

[0000936395-15-000062:notes:292]
Ciena Corporation, as the U.S. parent entity, uses the U.S. dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2013, fiscal 2014 and fiscal 2015, Ciena recorded $8.2 million, $15.7 million and $47.6 million in foreign currency exchange losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net. During fiscal 2014 Ciena recorded losses of $5.8 million from non-hedge designated foreign currency forward contracts. During fiscal 2015, Ciena recorded gains of $23.2 million from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-15-000062:notes:293]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES

[0000936395-15-000062:notes:294]
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-15-000062:notes:295]
|  | October 31, |
|  | 2014 |  | 2015 |
| Equipment, furniture and fixtures | $ | 383,059 |  |  | $ | 404,935 |  |
| Building subject to capital lease | — |  |  | 13,459 |  |
| Construction in progress, subject to build-to-suit lease | — |  |  | 18,663 |  |
| Leasehold improvements | 46,354 |  |  | 49,196 |  |
|  | 429,413 |  |  | 486,253 |  |
| Accumulated depreciation and amortization | (302,781 | ) |  | (294,280 | ) |
|  | $ | 126,632 |  |  | $ | 191,973 |  |

[0000936395-15-000062:notes:296]
On October 23, 2014, Ciena entered into a lease agreement to lease an office building located in Ottawa, Canada. During fiscal 2015, Ciena gained access to a portion of the building and recorded a capital lease asset and liability.

[0000936395-15-000062:notes:297]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease, two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. This arrangement qualifies as a capital lease. As a result, the facilities will be depreciated over the lease term.

[0000936395-15-000062:notes:298]
During fiscal 2013, fiscal 2014 and fiscal 2015, Ciena recorded depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements of $48.3 million, $46.6 million and $46.1 million, respectively.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-15-000062:notes:299]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-15-000062:notes:300]
|  | Fiscal Year |
|  | 2013 |  | 2014 |  | 2015 |
| Segment profit: |  |  |  |  |  |
| Converged Packet Optical | $ | 242,335 |  |  | $ | 353,942 |  |  | $ | 471,484 |  |
| Packet Networking | 22,740 |  |  | 19,467 |  |  | 28,136 |  |
| Optical Transport | 89,754 |  |  | 38,974 |  |  | 15,930 |  |
| Software and Services | 126,938 |  |  | 134,789 |  |  | 145,812 |  |
| Total segment profit | 481,767 |  |  | 547,172 |  |  | 661,362 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 304,170 |  |  | 328,325 |  |  | 333,836 |  |
| General and administrative | 122,432 |  |  | 126,824 |  |  | 123,402 |  |
| Amortization of intangible assets | 49,771 |  |  | 45,970 |  |  | 69,511 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 25,539 |  |
| Restructuring costs | 7,169 |  |  | 349 |  |  | 8,626 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest expense and other income (loss), net | (49,786 | ) |  | (72,377 | ) |  | (76,684 | ) |
| Loss on extinguishment of debt | (28,630 | ) |  | — |  |  | — |  |
| Less: Provision for income taxes | 5,240 |  |  | 13,964 |  |  | 12,097 |  |
| Consolidated net income (loss) | $ | (85,431 | ) |  | $ | (40,637 | ) |  | $ | 11,667 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-15-000062:notes:301]
The table below (in thousands, except percentage data) sets forth Ciena’s segment revenue for the respective periods indicated:

[0000936395-15-000062:notes:302]
|  | Fiscal Year |
|  | 2013 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |
| Converged Packet Optical | $ | 1,187,231 |  |  | $ | 1,455,501 |  |  | $ | 1,661,702 |  |
| Packet Networking | 222,898 |  |  | 244,116 |  |  | 229,223 |  |
| Optical Transport | 233,821 |  |  | 127,215 |  |  | 73,004 |  |
| Software and Services | 438,596 |  |  | 461,457 |  |  | 481,740 |  |
| Consolidated revenue | $ | 2,082,546 |  |  | $ | 2,288,289 |  |  | $ | 2,445,669 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-15-000062:notes:303]
RESTRUCTURING COSTS

[0000936395-15-000062:notes:304]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the fiscal years indicated (in thousands):

[0000936395-15-000062:notes:305]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2012 | $ | 1,449 |  |  | $ | 3,600 |  |  | $ | 5,049 |  |
| Additional liability recorded | 5,041 |  | (a) | 2,128 |  | (a) | 7,169 |  |
| Non-cash disposal | — |  |  | (747 | ) |  | (747 | ) |
| Cash payments | (6,410 | ) |  | (3,045 | ) |  | (9,455 | ) |
| Balance at October 31, 2013 | 80 |  |  | 1,936 |  |  | 2,016 |  |
| Additional liability recorded | 685 |  | (b) | 9 |  |  | 694 |  |
| Adjustment to previous estimates | — |  |  | (345 | ) |  | (345 | ) |
| Cash payments | (584 | ) |  | (466 | ) |  | (1,050 | ) |
| Balance at October 31, 2014 | 181 |  |  | 1,134 |  |  | 1,315 |  |
| Additional liability recorded | 8,631 |  | (c) | (5 | ) |  | 8,626 |  |
| Cash payments | (8,221 | ) |  | (441 | ) |  | (8,662 | ) |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Current restructuring liabilities | $ | 591 |  |  | $ | 362 |  |  | $ | 953 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 326 |  |  | $ | 326 |  |

[0000936395-15-000062:notes:306]
| (a) | During fiscal 2013, Ciena recorded a charge of $5.0 million of severance and other employee-related costs associated with a workforce reduction of approximately 100 employees. Ciena also recorded charges of $2.1 million related to its consolidation of several facilities primarily in the Linthicum, Maryland area. |

[0000936395-15-000062:notes:307]
| (b) | During fiscal 2014, Ciena recorded a charge of $0.7 million of severance and other employee-related costs associated with a workforce reduction of approximately 25 employees. |

[0000936395-15-000062:notes:308]
| (c) | During fiscal 2015, Ciena recorded a charge of $8.6 million of severance and other employee-related costs associated with a global workforce reduction of approximately 125 employees. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-15-000062:notes:309]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-15-000062:notes:310]
|  | October 31, |
|  | 2014 |  | 2015 |
| Compensation, payroll related tax and benefits | $ | 82,207 |  |  | $ | 109,466 |  |
| Warranty | 55,997 |  |  | 56,654 |  |
| Vacation | 35,126 |  |  | 34,189 |  |
| Capital lease obligations | 7,788 |  |  | 4,923 |  |
| Interest payable | 6,409 |  |  | 5,389 |  |
| Other | 89,081 |  |  | 105,662 |  |
|  | $ | 276,608 |  |  | $ | 316,283 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-15-000062:notes:311]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of October 31, 2015 (in thousands):

[0000936395-15-000062:notes:312]
| Period ending October 31, | Amount |
| 2016 | $ | 6,057 |  |
| 2017 | 1,630 |  |
| 2018 | 1,292 |  |
| 2019 | 1,292 |  |
| 2020 | 1,390 |  |
| Thereafter | 18,445 |  |
| Net minimum capital lease payments | 30,106 |  |
| Less: Amount representing interest | (11,389 | ) |
| Present value of minimum lease payments | 18,717 |  |
| Less: Current portion of present value of minimum lease payments | (4,923 | ) |
| Long-term portion of present value of minimum lease payments | $ | 13,794 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-15-000062:notes:313]
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-15-000062:notes:314]
|  | October 31, |
|  | 2014 |  | 2015 |
| Maintenance spares inventory, net | $ | 54,101 |  |  | $ | 55,259 |  |
| Deferred debt issuance costs, net | 15,160 |  |  | 10,820 |  |
| Financing receivable | — |  |  | 10,107 |  |
| Other | 4,815 |  |  | 8,470 |  |
|  | $ | 74,076 |  |  | $ | 84,656 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-15-000062:notes:315]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-15-000062:notes:316]
| Year ended |  | Beginning |  |  |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Acquired |  | Provisions |  | Settlements |  | Balance |
| 2013 |  | $ | 55,132 |  |  | $ | — |  |  | $ | 24,558 |  |  | $ | 23,387 |  |  | $ | 56,303 |  |
| 2014 |  | $ | 56,303 |  |  | $ | — |  |  | $ | 22,129 |  |  | $ | 22,435 |  |  | $ | 55,997 |  |
| 2015 |  | $ | 55,997 |  |  | $ | 2,996 |  |  | $ | 17,881 |  |  | $ | 20,220 |  |  | $ | 56,654 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-15-000062:notes:317]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-15-000062:notes:318]
|  | Fiscal Year |
|  | 2013 |  | 2014 |  | 2015 |
| North America | $ | 1,360,169 |  |  | $ | 1,477,329 |  |  | $ | 1,598,328 |  |
| EMEA | 376,405 |  |  | 417,399 |  |  | 400,294 |  |
| CALA | 174,360 |  |  | 212,018 |  |  | 201,499 |  |
| APAC | 171,612 |  |  | 181,543 |  |  | 245,548 |  |
| Total | $ | 2,082,546 |  |  | $ | 2,288,289 |  |  | $ | 2,445,669 |  |

[0000936395-15-000062:notes:319]
For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-15-000062:notes:320]
|  | October 31, |
|  | 2013 |  | 2014 |  | 2015 |
| United States | $ | 64,132 |  |  | $ | 73,420 |  |  | $ | 96,292 |  |
| Canada | 43,772 |  |  | 42,015 |  |  | 84,318 |  |
| Other International | 11,825 |  |  | 11,197 |  |  | 11,363 |  |
| Total | $ | 119,729 |  |  | $ | 126,632 |  |  | $ | 191,973 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-15-000062:notes:321]
SEGMENT AND ENTITY WIDE DISCLOSURES

[0000936395-15-000062:notes:322]
Ciena’s internal organizational structure and the management of its business are grouped into the following operating segments:

[0000936395-15-000062:notes:323]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Waveserver, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. Revenue from sales of the Z-Series Packet-Optical Platform acquired from Cyan is included in our Converged Packet Optical segment. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:notes:324]
| • | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This segment also includes the 8700 Packetwave Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:notes:325]
| • | Optical Transport — includes the 4200 Advanced Services Platform, Corestream® Agility Optical Transport System, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. This segment includes sales from SONET/SDH, transport and data networking products, as well as certain enterprise-oriented transport solutions that support storage and LAN extension, interconnection of data centers, and virtual private networks. This segment also includes operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:notes:326]
| • | Software and Services — includes the sale of network management solutions, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. This segment includes sales of Ciena's Blue Planet software platform, a modular network virtualization, service orchestration and network management software solution, and Ciena's SDN Multilayer WAN Controller and its related applications. This segment includes a broad range of services for consulting and network design, installation and deployment, software subscription, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Consolidated Statement of Operations. |

[0000936395-15-000062:notes:327]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2015, equipment, building, furniture and fixtures totaling $192.0 million primarily supports asset groups within Ciena's Converged Packet Optical segment, Packet Networking segment, Software and Services segment and Ciena's unallocated selling and general and administrative activities. As of October 31, 2015, $166.5 million of Ciena's intangible assets, including goodwill of $55.0 million from the acquisition of Cyan, were assigned to asset groups within Ciena's Converged Packet Optical segment and $292.6 million of Ciena's intangible assets, including goodwill of $201.4 million from the acquisition of Cyan, were assigned to asset groups within Ciena's Software and Services segment. As of October 31, 2015, all of the maintenance spares totaling $55.3 million were assigned to asset groups within Ciena's Software and Services segment.

[0000936395-15-000062:notes:328]
Segment Revenue

[0000936395-15-000062:notes:329]
Segment Profit

[0000936395-15-000062:notes:330]
Segment profit is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; acquisition and integration costs; amortization of intangible assets; restructuring costs; interest and other income (loss), net; interest expense; loss on extinguishment of debt and provisions for income taxes.

[0000936395-15-000062:notes:331]
Entity Wide Reporting

[0000936395-15-000062:notes:332]
Ciena's operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia Pacific (“APAC”); and Caribbean and Latin America ("CALA"). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena's delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-15-000062:notes:333]
North America includes $1,217.5 million, $1,318.0 million and $1,479.5 million of United States revenue for fiscal years ended October 31, 2013, 2014 and 2015, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-15-000062:notes:334]
The following table reflects Ciena's geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-15-000062:notes:335]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal years ended October 31, 2013, 2014 and 2015, with total revenue of $373.6 million, $423.5 million and $487.8 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-15-000062:notes:336]
STOCKHOLDERS’ EQUITY

[0000936395-15-000062:notes:337]
Call Spread Option

[0000936395-15-000062:notes:338]
Ciena purchased a call spread option relating to the 0.875% convertible senior notes due June 15, 2017 for $42.5 million during the third quarter of fiscal 2007. The call spread option is designed to mitigate exposure to potential dilution from the conversion of the notes. The call spread option was purchased at the time of the notes offering from an affiliate of the underwriter. The cost of the call spread option was recorded as a reduction in paid-in capital.

[0000936395-15-000062:notes:339]
The call spread option is exercisable, upon maturity of the relevant issue of convertible note, for such number of shares of Ciena common stock issuable upon conversion of that series of notes in full. The call spread option has a “lower strike price” equal to the conversion price for the notes and a “higher strike price” that serves to cap the amount of dilution protection provided. At its election, Ciena can exercise the call spread option on a net cash basis or a net share basis. The value of the consideration of a net share settlement will be equal to the value upon a net cash settlement and can range from $0, if the market price per share of Ciena common stock upon exercise is equal to or below the lower strike price, or approximately $76.1 million, if the market price per share of Ciena common stock upon exercise is at or above the higher strike price. If the market price on the date of exercise is between the lower strike price and the higher strike price, in lieu of a net settlement, Ciena may elect to receive the full number of shares underlying the call spread option by paying the aggregate option exercise price, which is equal to the original principal outstanding on that series of notes. Should there be an early unwind of the call spread option, the amount of cash or shares to be received by Ciena will depend upon the existing overall market conditions, and on Ciena’s stock price, the volatility of Ciena’s stock and the remaining term of the call spread option. The number of shares subject to the call spread option, and the lower and higher strike prices, are subject to customary adjustments.


## us-gaap:SubsequentEventsTextBlock

[0000936395-15-000062:notes:340]
SUBSEQUENT EVENT

[0000936395-15-000062:notes:341]
During the first quarter of fiscal 2016, Ciena reorganized its internal organizational structure, management of its business and the reporting of its operating segments. In connection with the creation of its new Chief Operating Officer organization, Ciena has reorganized the management of its business resulting in three operating segments: Networking Platforms; Software and Software-Related Services; and Global Services. As a result of this reorganization, the Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form a new Networking Platforms segment under a single operating segment manager. Ciena's existing Software and Service operating segment was reorganized into two separate operating segments; Software and Software-Related Services and Global Services. The Software and Software-Related Services segment will include sales of Ciena's network virtualization, management, control and orchestration software solutions and software-related services, including subscription, installation, support and consulting services. The Global Services segment will include sales of a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-15-000062:notes:342]
OTHER BALANCE SHEET DETAILS

[0000936395-15-000062:notes:343]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 15 below), Term Loan (described in Note 15 below) and ABL Credit Facility (described in Note 16 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $5.4 million, $4.8 million and $4.7 million for fiscal 2013, fiscal 2014 and fiscal 2015, respectively.

[0000936395-15-000062:notes:344]
The decreases in fiscal 2013, fiscal 2014 and fiscal 2015 warranty provisions were primarily due to lower failure rates and reduced costs due to efficiencies.

[0000936395-15-000062:notes:345]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner during the construction period for accounting purposes.
