# CIEN note change history — 0000936395-21-000040 → 0000936395-22-000029


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2022-03-09):
[0000936395-22-000029:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of January 29, 2022, Ciena has recorded CAD$54.8 million (approximately $42.9 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.9 million ($3.0 million) was recorded in the first three months of fiscal 2022. As of January 29, 2022, amounts receivable from this grant were CAD$2.9 million ($2.2 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

- removed (2022-03-09):
[0000936395-21-000040:note_history:2]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.2 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31,

- removed (2022-03-09):
[0000936395-21-000040:note_history:3]
2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2021, Ciena has recorded CAD$48.6 million (approximately $39.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$8.0 million ($6.3 million) was recorded in the first nine months of fiscal 2021. As of July 31, 2021, amounts receivable from this grant were CAD$5.8 million ($4.7 million).


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2022-03-09):
[0000936395-22-000029:note_history:4]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- added (2022-03-09):
[0000936395-22-000029:note_history:5]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. Ciena elected to adopt ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

- added (2022-03-09):
[0000936395-22-000029:note_history:6]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London

- added (2022-03-09):
[0000936395-22-000029:note_history:7]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

- added (2022-03-09):
[0000936395-22-000029:note_history:8]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its condensed consolidated financial statements and related disclosures.

- removed (2022-03-09):
[0000936395-21-000040:note_history:9]
In June 2016, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

- removed (2022-03-09):
[0000936395-21-000040:note_history:10]
Ciena’s significant accounting policies updated as a result of adopting this standard are as follows:

- removed (2022-03-09):
[0000936395-21-000040:note_history:11]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

- removed (2022-03-09):
[0000936395-21-000040:note_history:12]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the

- removed (2022-03-09):
[0000936395-21-000040:note_history:13]
probability the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

- removed (2022-03-09):
[0000936395-21-000040:note_history:14]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

- removed (2022-03-09):
[0000936395-21-000040:note_history:15]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: title_similarity, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:16]
The net carrying value of Ciena’s 2025 Term Loan was comprised of the following for the periods indicated (in thousands):
  (was, 2021-09-08, similarity 0.9915):
[0000936395-21-000040:note_history:16]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):

- changed (2022-03-09):
[0000936395-22-000029:note_history:17]
|  |  | January 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 680,873 |  |  | $ | (1,170) |  |  | $ | (2,188) |  |  | $ | 677,515 |  |  | $ | 677,285 |  |
  (was, 2021-09-08, similarity 0.9856):
[0000936395-21-000040:note_history:17]
|  |  | July 31, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 682,605 |  |  | $ | (1,332) |  |  | $ | (2,488) |  |  | $ | 678,785 |  |  | $ | 683,286 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:18]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.2 million as of January 29, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2021-09-08, similarity 0.9796):
[0000936395-21-000040:note_history:18]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.5 million as of July 31, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

- changed (2022-03-09):
[0000936395-22-000029:note_history:19]
As of January 29, 2022, the estimated fair value of the 2025 Term Loan was $681.7 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2021-09-08, similarity 0.9828):
[0000936395-21-000040:note_history:19]
As of July 31, 2021, the estimated fair value of the 2025 Term Loan was $680.9 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2022-03-09):
[0000936395-22-000029:note_history:20]
2030 Notes

- added (2022-03-09):
[0000936395-22-000029:note_history:21]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

- added (2022-03-09):
[0000936395-22-000029:note_history:22]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”).

- added (2022-03-09):
[0000936395-22-000029:note_history:23]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. Ciena intends to use the net proceeds from the Offering for general corporate purposes.

- added (2022-03-09):
[0000936395-22-000029:note_history:24]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

- added (2022-03-09):
[0000936395-22-000029:note_history:25]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

- added (2022-03-09):
[0000936395-22-000029:note_history:26]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

- added (2022-03-09):
[0000936395-22-000029:note_history:27]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

- added (2022-03-09):
[0000936395-22-000029:note_history:28]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

- added (2022-03-09):
[0000936395-22-000029:note_history:29]
The net carrying value of the 2030 Notes was comprised of the following for the periods indicated (in thousands):

- added (2022-03-09):
[0000936395-22-000029:note_history:30]
|  |  | January 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,322) |  |  | $ | 394,678 |  |  |  |

- added (2022-03-09):
[0000936395-22-000029:note_history:31]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Notes totaled $5.3 million as of January 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was minimal during the first three months of fiscal 2022.

- added (2022-03-09):
[0000936395-22-000029:note_history:32]
As of January 29, 2022, the estimated fair value of the 2030 Notes was $395.5 million. Ciena’s 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:33]
|  | January 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 460,683 |  |  | $ | — |  |  | $ | (315) |  |  | $ | 460,368 |  |
| Included in long-term investments | 89,527 |  |  | — |  |  | (887) |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | — |  |  | $ | (1,202) |  |  | $ | 549,008 |  |
  (was, 2021-09-08, similarity 0.673):
[0000936395-21-000040:note_history:33]
|  | July 31, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,966 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 182,010 |  |
| Included in long-term investments | 60,887 |  |  | 7 |  |  | (6) |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 51 |  |  | $ | (6) |  |  | $ | 242,898 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:34]
|  | January 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 460,683 |  |  | $ | — |  |  | $ | (315) |  |  | $ | 460,368 |  |
| Included in long-term investments | 89,527 |  |  | — |  |  | (887) |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | — |  |  | $ | (1,202) |  |  | $ | 549,008 |  |
  (was, 2021-09-08, similarity 0.673):
[0000936395-21-000040:note_history:34]
|  | July 31, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,966 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 182,010 |  |
| Included in long-term investments | 60,887 |  |  | 7 |  |  | (6) |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 51 |  |  | $ | (6) |  |  | $ | 242,898 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:35]
The following table summarizes the final legal maturities of debt investments at January 29, 2022 (in thousands):
  (was, 2021-09-08, similarity 0.9765):
[0000936395-21-000040:note_history:35]
The following table summarizes the final legal maturities of debt investments at July 31, 2021 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:36]
The net carrying value of Ciena’s 2025 Term Loan was comprised of the following for the periods indicated (in thousands):
  (was, 2021-09-08, similarity 0.9915):
[0000936395-21-000040:note_history:36]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):

- changed (2022-03-09):
[0000936395-22-000029:note_history:37]
|  |  | January 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 680,873 |  |  | $ | (1,170) |  |  | $ | (2,188) |  |  | $ | 677,515 |  |  | $ | 677,285 |  |
  (was, 2021-09-08, similarity 0.9856):
[0000936395-21-000040:note_history:37]
|  |  | July 31, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 682,605 |  |  | $ | (1,332) |  |  | $ | (2,488) |  |  | $ | 678,785 |  |  | $ | 683,286 |  |


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2022-03-09):
[0000936395-22-000029:note_history:38]
The net carrying value of the 2030 Notes was comprised of the following for the periods indicated (in thousands):

- added (2022-03-09):
[0000936395-22-000029:note_history:39]
|  |  | January 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,322) |  |  | $ | 394,678 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:40]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
  (was, 2021-09-08, similarity 0.9953):
[0000936395-21-000040:note_history:40]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:41]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
  (was, 2021-09-08, similarity 0.9944):
[0000936395-21-000040:note_history:41]
|  | Quarter Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Routing and Switching | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:42]
|  |  | Quarter Ended |  |  |
|  |  | January 29, |  | January 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  |  |
| EMEA |  | 150,785 |  |  | 155,418 |  |  |  |  |  |
| APAC |  | 98,514 |  |  | 105,101 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  |  |
  (was, 2021-09-08, similarity 0.7631):
[0000936395-21-000040:note_history:42]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 692,853 |  |  | $ | 713,340 |  |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |
| EMEA |  | 189,180 |  |  | 162,465 |  |  | 499,652 |  |  | 433,861 |  |
| APAC |  | 106,108 |  |  | 100,907 |  |  | 302,607 |  |  | 332,091 |  |
| Total revenue by geographic distribution |  | $ | 988,141 |  |  | $ | 976,712 |  |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:43]
For the periods below, the only customer that accounted for at least 10% of Ciena’s revenue was as follows (in thousands):
  (was, 2021-09-08, similarity 0.9754):
[0000936395-21-000040:note_history:43]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2022-03-09):
[0000936395-22-000029:note_history:44]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| AT&T | $ | 110,876 |  |  | n/a |  |  |  |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:45]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:46]
|  | Nine Months Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Routing Switching | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:47]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Verizon | $ | 131,892 |  |  | n/a |  | n/a |  | $ | 272,200 |  |
| Web-scale provider | 119,728 |  |  | n/a |  | n/a |  | n/a |
| AT&T | 119,199 |  |  | 114,963 |  |  | 313,140 |  |  | 304,645 |  |
| Total | $ | 370,819 |  |  | $ | 114,963 |  |  | $ | 313,140 |  |  | $ | 576,845 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-03-09):
[0000936395-22-000029:note_history:48]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line.
  (was, 2021-09-08, similarity 0.6376):
[0000936395-21-000040:note_history:48]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to “Routing and Switching.”

- changed (2022-03-09):
[0000936395-22-000029:note_history:49]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
  (was, 2021-09-08, similarity 0.9953):
[0000936395-21-000040:note_history:49]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:50]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
  (was, 2021-09-08, similarity 0.9944):
[0000936395-21-000040:note_history:50]
|  | Quarter Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Routing and Switching | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:51]
|  |  | Quarter Ended |  |  |
|  |  | January 29, |  | January 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  |  |
| EMEA |  | 150,785 |  |  | 155,418 |  |  |  |  |  |
| APAC |  | 98,514 |  |  | 105,101 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  |  |
  (was, 2021-09-08, similarity 0.7631):
[0000936395-21-000040:note_history:51]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 692,853 |  |  | $ | 713,340 |  |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |
| EMEA |  | 189,180 |  |  | 162,465 |  |  | 499,652 |  |  | 433,861 |  |
| APAC |  | 106,108 |  |  | 100,907 |  |  | 302,607 |  |  | 332,091 |  |
| Total revenue by geographic distribution |  | $ | 988,141 |  |  | $ | 976,712 |  |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:52]
Ciena’s revenue includes $543.5 million and $439.4 million of United States revenue for the first quarter of fiscal 2022 and 2021, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.
  (was, 2021-09-08, similarity 0.7191):
[0000936395-21-000040:note_history:52]
Ciena’s revenue includes $623.9 million and $647.0 million of United States revenue for the third quarter of fiscal 2021 and 2020, respectively. For the nine months ended July 31, 2021 and August 1, 2020, United States revenue was $1.6 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- changed (2022-03-09):
[0000936395-22-000029:note_history:53]
For the periods below, the only customer that accounted for at least 10% of Ciena’s revenue was as follows (in thousands):
  (was, 2021-09-08, similarity 0.9754):
[0000936395-21-000040:note_history:53]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2022-03-09):
[0000936395-22-000029:note_history:54]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| AT&T | $ | 110,876 |  |  | n/a |  |  |  |  |

- added (2022-03-09):
[0000936395-22-000029:note_history:55]
The customer identified above for the first quarter of fiscal 2022 purchased products and services from each of Ciena’s operating segments.

- changed (2022-03-09):
[0000936395-22-000029:note_history:56]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes sales of the Z-Series Packet-Optical Platform.
  (was, 2021-09-08, similarity 0.913):
[0000936395-21-000040:note_history:56]
◦Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.

- added (2022-03-09):
[0000936395-22-000029:note_history:57]
•Routing and Switching - includes the 3900 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

- changed (2022-03-09):
[0000936395-22-000029:note_history:58]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations in which revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2021-09-08, similarity 0.9937):
[0000936395-21-000040:note_history:58]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2022-03-09):
[0000936395-22-000029:note_history:59]
|  |  | Balance at January 29, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 795,247 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 117,003 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 185,626 |  |  | $ | 175,464 |  |
  (was, 2021-09-08, similarity 0.9851):
[0000936395-21-000040:note_history:59]
|  |  | Balance at July 31, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 878,229 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 98,812 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 183,899 |  |  | $ | 158,363 |  |

- changed (2022-03-09):
[0000936395-22-000029:note_history:60]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 11 below.
  (was, 2021-09-08, similarity 0.9856):
[0000936395-21-000040:note_history:60]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 below.

- changed (2022-03-09):
[0000936395-22-000029:note_history:61]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $56.8 million and $46.4 million of revenue during the first three months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 29, 2022 and January 30, 2021.
  (was, 2021-09-08, similarity 0.957):
[0000936395-21-000040:note_history:61]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $94.7 million and $91.8 million of revenue during the first nine months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2021 and August 1, 2020.

- changed (2022-03-09):
[0000936395-22-000029:note_history:62]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $29.6 million and $27.6 million as of January 29, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $7.0 million and $5.5 million during the first three months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.
  (was, 2021-09-08, similarity 0.8982):
[0000936395-21-000040:note_history:62]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $20.4 million and $15.3 million as of July 31, 2021 and October 31, 2020, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $16.8 million and $16.2 million during the first nine months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

- changed (2022-03-09):
[0000936395-22-000029:note_history:63]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 29, 2022, the aggregate amount of RPO was $2.4 billion. As of January 29, 2022, Ciena expects approximately 89% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2021-09-08, similarity 0.9737):
[0000936395-21-000040:note_history:63]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2021, the aggregate amount of RPO was $1.4 billion. As of July 31, 2021, Ciena expects approximately 85% of the RPO to be recognized as revenue within the next twelve months.

- removed (2022-03-09):
[0000936395-21-000040:note_history:64]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:65]
|  | Nine Months Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Routing Switching | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:66]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Verizon | $ | 131,892 |  |  | n/a |  | n/a |  | $ | 272,200 |  |
| Web-scale provider | 119,728 |  |  | n/a |  | n/a |  | n/a |
| AT&T | 119,199 |  |  | 114,963 |  |  | 313,140 |  |  | 304,645 |  |
| Total | $ | 370,819 |  |  | $ | 114,963 |  |  | $ | 313,140 |  |  | $ | 576,845 |  |

- removed (2022-03-09):
[0000936395-21-000040:note_history:67]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.

- removed (2022-03-09):
[0000936395-21-000040:note_history:68]
◦Routing and Switching - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2022-03-09):
[0000936395-22-000029:note_history:69]
SUBSEQUENT EVENTSStock Repurchase Program and Accelerated Share Repurchase AgreementOn February 15, 2022, Ciena received delivery of the remaining 884,531 shares of common stock repurchased under the ASR Agreement, for a total delivery of approximately 3.6 million shares, calculated based on the average of the daily volume-weighted average prices of Ciena’s common stock of $69.78 for the period December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement.

- removed (2022-03-09):
[0000936395-21-000040:note_history:70]
SUBSEQUENT EVENTS
Stock Repurchase Program

- removed (2022-03-09):
[0000936395-21-000040:note_history:71]
From the end of the third quarter of fiscal 2021 through September 3, 2021, Ciena repurchased an additional 176,815 shares of its common stock, for an aggregate purchase price of $10.0 million at an average price of $56.57 per share, inclusive of repurchases pending settlement. As of September 3, 2021, Ciena has repurchased an aggregate of 7,091,166 shares and has an aggregate of $200.0 million of authorized funds remaining under its stock repurchase program.

- removed (2022-03-09):
[0000936395-21-000040:note_history:72]
Vyatta Routing and Switching Technology Acquisition

- removed (2022-03-09):
[0000936395-21-000040:note_history:73]
On August 31, 2021, Ciena entered into a definitive agreement with AT&T to acquire its Vyatta virtual routing and switching technology. The acquisition reflects Ciena’s continued investment in its Routing and Switching solutions roadmap and resources. Ciena plans to integrate the engineering personnel to be hired through this transaction into its Routing and Switching research and development (R&D) organization.
