# CIEN MD&A — 0000936395-22-000029


## mdna

[0000936395-22-000029:mdna:1]
[same as prior period, unchanged from 0000936395-21-000040:mdna:1]

[0000936395-22-000029:mdna:2]
[same as prior period, unchanged from 0000936395-21-000040:mdna:2]

[0000936395-22-000029:mdna:3]
[same as prior period, unchanged from 0000936395-21-000040:mdna:3]

[0000936395-22-000029:mdna:4]
[same as prior period, unchanged from 0000936395-21-000040:mdna:4]

[0000936395-22-000029:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and of our 2021 Annual Report.

[0000936395-22-000029:mdna:6]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that enable the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and emerging network operators. Our portfolio is designed to enable what we refer to as the Adaptive Network™, our vision for a network end state that emphasizes a programmable and scalable network infrastructure, software control and automation capabilities, network analytics and intelligence, and related advanced services. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes a wide array of software solutions that deliver operations, administration, maintenance, and provisioning (OAM&P) functionality, as well as domain control, orchestration, operational support systems (OSS) and service assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through our Blue Planet® Software suite, we enable customers to accelerate the digital transformation of their networks through service lifecycle automation.

[0000936395-22-000029:mdna:7]
[same as prior period, unchanged from 0000936395-21-000040:mdna:14]

[0000936395-22-000029:mdna:8]
Due to increased demand across a range of industries, the global supply market for certain raw materials and components, including, in particular, the semiconductor components used in most of our products, has experienced significant disruption in recent periods. These conditions, which worsened during the second half of fiscal 2021 and the first quarter of fiscal 2022, have been exacerbated in part by the COVID-19 pandemic. As a result, we have experienced ongoing component shortages, longer lead times and increased cost of components, particularly relating to semiconductors. In addition, some of our suppliers have indicated that, as a result of current constraints, they intend to cease manufacturing of certain components used in our products.

[0000936395-22-000029:mdna:9]
These conditions have impacted the lead times for our products and could adversely impact our ability to meet customer demand in circumstances where we cannot timely secure supply of these components. In response, we have worked to implement mitigation strategies and increased our purchases of inventory for certain components. In some cases, we have incurred higher costs to secure available inventory, or have extended our purchase commitments or placed non-cancellable orders with suppliers, which introduces inventory risk if our forecasts and assumptions are inaccurate.

[0000936395-22-000029:mdna:10]
During the first quarter of fiscal 2022, we experienced disruptions in our supply chain relating to later-than-expected delivery of certain key components from a few suppliers and third-party manufacturing disruptions that took production of certain of our products offline for a period of time. Due in part to these events occurring later in our first fiscal quarter, we were unable to mitigate fully these disruptions within the current challenging dynamics for logistics and delivery. As a result, these disruptions adversely impacted our revenue for the first quarter of fiscal 2022.

[0000936395-22-000029:mdna:11]
While the impact of the specific supply chain disruptions we experienced during the first quarter of fiscal 2022 has begun to improve, we believe the global supply chain challenges and their adverse impact on our business and financial results will persist, at least through the remainder of fiscal 2022, and may extend into periods thereafter. We expect these constrained supply conditions to increase our costs of goods sold and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. The current supply conditions can also be expected to adversely impact our gross margin as well as the level and timing of our revenue during the remainder of fiscal 2022.  See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain.

[0000936395-22-000029:mdna:12]
Demand Environment

[0000936395-22-000029:mdna:13]
The demand environment for our products and services remains dynamic and continues to be impacted by both the current global supply environment and the effects of the COVID-19 pandemic. Since the second quarter of fiscal 2021, we have experienced significantly stronger order volumes for our products and services, particularly among a concentrated set of larger customers with which we have existing positions as a supplier. We believe that the increased order volumes in the first quarter of fiscal 2022 reflect, in part, acceleration of future orders due to the implementation of security of supply strategies amidst global supply constraints. Over the longer term, however, we continue to believe that the increased demands placed on network infrastructures as a result of shifts in business and consumer behavior have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation.

[0000936395-22-000029:mdna:14]
Impact of the COVID-19 Pandemic on our Business and Operations

[0000936395-22-000029:mdna:15]
The impact of the COVID-19 pandemic and countermeasures taken to contain its spread remain dynamic. We continue to monitor the situation and actively assess further implications for our business, supply chain, fulfillment operations and customer demand. For example, we have reopened some of our offices and expect most of our offices globally to be reopened by the end of the second quarter of fiscal 2022. We continue to take meaningful precautions in accordance with relevant guidelines to protect the health and safety of our employees. Variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected. For additional information on the impact of COVID-19 upon our business, operations and financial results, and the steps that we have taken in response, see our 2021 Annual Report.

[0000936395-22-000029:mdna:16]
Strategic and Financial Initiatives

[0000936395-22-000029:mdna:17]
Vyatta Acquisition. During the first quarter of fiscal 2022, we acquired AT&T’s Vyatta virtual routing and switching technology, which is intended to expand and accelerate our Adaptive IP solutions and address the growing market opportunity to transform the edge, including 5G networks and cloud environments. Revenue from sales of this technology is included in our Routing and Switching portfolio within our Networking Platforms segment. See Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on this acquisition and the related accounting.

[0000936395-22-000029:mdna:18]
Stock Repurchase Program and Accelerated Share Repurchase Agreement. On December 9, 2021, we announced that our Board of Directors had authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety our previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this

[0000936395-22-000029:mdna:19]
repurchase program, we entered into an accelerated share repurchase agreement (the “ASR Agreement”) for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022 and had $750.0 million remaining under the current repurchase authorization as of January 29, 2022. The repurchases contemplated by the ASR Agreement were completed on February 15, 2022. The amount and timing of any further repurchases under our stock purchase program are subject to a variety of factors, including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 18 and 22 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on our stock repurchase program.

[0000936395-22-000029:mdna:20]
Senior Notes Due 2030. On January 18, 2022, we issued $400 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”). The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. We intend to use the net proceeds from the offering for general corporate purposes. The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022. See Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information on the 2030 Notes.

[0000936395-22-000029:mdna:21]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2021 Annual Report.

[0000936395-22-000029:mdna:22]
[same as prior period, unchanged from 0000936395-21-000040:mdna:19]

[0000936395-22-000029:mdna:23]
[same as prior period, unchanged from 0000936395-21-000040:mdna:20]

[0000936395-22-000029:mdna:24]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000029:mdna:25]
[same as prior period, unchanged from 0000936395-21-000040:mdna:22]

[0000936395-22-000029:mdna:26]
[same as prior period, unchanged from 0000936395-21-000040:mdna:23]

[0000936395-22-000029:mdna:27]
Approximately 14.5% of our revenue was non-U.S. Dollar-denominated during the first quarter of fiscal 2022, primarily including sales in Euros, Canadian Dollars and British Pounds. During the first quarter of fiscal 2022, as compared to the first quarter of fiscal 2021, the U.S. Dollar primarily weakened against these and other currencies. Consequently, our revenue for the first quarter of fiscal 2022 reported in U.S. Dollars slightly increased by approximately $3.7 million, or 0.4%.

[0000936395-22-000029:mdna:28]
[same as prior period, unchanged from 0000936395-21-000040:mdna:25]

[0000936395-22-000029:mdna:29]
[same as prior period, unchanged from 0000936395-21-000040:mdna:26]

[0000936395-22-000029:mdna:30]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | 512,324 |  |  |  |  | 5.6 | % |  |  |  |  |  |  |  |  |
| %** | 64.1 | % |  | 67.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Routing and Switching | 85,710 |  |  | 64,307 |  |  |  |  | 33.3 | % |  |  |  |  |  |  |  |  |
| %** | 10.1 | % |  | 8.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Networking Platforms | 626,646 |  |  | 576,631 |  |  |  |  | 8.7 | % |  |  |  |  |  |  |  |  |
| %** | 74.2 | % |  | 76.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 72,917 |  |  | 49,839 |  |  |  |  | 46.3 | % |  |  |  |  |  |  |  |  |
| %** | 8.6 | % |  | 6.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | 21,110 |  |  | 16,934 |  |  |  |  | 24.7 | % |  |  |  |  |  |  |  |  |
| %** | 2.5 | % |  | 2.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 72,491 |  |  | 67,630 |  |  |  |  | 7.2 | % |  |  |  |  |  |  |  |  |
| %** | 8.6 | % |  | 8.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Installation and Deployment | 40,370 |  |  | 39,611 |  |  |  |  | 1.9 | % |  |  |  |  |  |  |  |  |
| %** | 4.8 | % |  | 5.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Consulting and Network Design | 10,909 |  |  | 6,485 |  |  |  |  | 68.2 | % |  |  |  |  |  |  |  |  |
| %** | 1.3 | % |  | 0.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Global Services | 123,770 |  |  | 113,726 |  |  |  |  | 8.8 | % |  |  |  |  |  |  |  |  |
| %** | 14.7 | % |  | 15.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total revenue | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  | 11.5 | % |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:31]
[same as prior period, unchanged from 0000936395-21-000040:mdna:28]

[0000936395-22-000029:mdna:32]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:33]
[same as prior period, unchanged from 0000936395-21-000040:mdna:30]

[0000936395-22-000029:mdna:34]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:35]
•Networking Platforms segment revenue increased by $50.0 million, reflecting product line sales increases of $28.6 million of our Converged Packet Optical products and $21.4 million of our Routing and Switching products.

[0000936395-22-000029:mdna:36]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $65.3 million of our 6500 Packet-Optical Platform primarily to Web-scale providers, communications service providers and cable and multiservice operators, and $18.1 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers. These sales increases were partially offset primarily by a sales decrease of $47.6 million of our Waveserver® products to Web-scale providers and communication service providers.

[0000936395-22-000029:mdna:37]
◦Routing and Switching sales increased, primarily reflecting sales increases of $14.0 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers and cable and multiservice operators. Sales also include, for the first time, $12.2 million of our Virtualization Edge software, from the acquisition of the Vyatta’s virtual routing and switching technology in the first quarter of fiscal 2022. These sales increases were partially offset by a sales decrease of $8.1 million of our platform independent software to communication service providers.

[0000936395-22-000029:mdna:38]
•Platform Software and Services segment revenue increased by $23.1 million, reflecting sales increases of $13.9 million in sales of software platforms and $9.2 million in software services primarily to communication service providers.

[0000936395-22-000029:mdna:39]
•Blue Planet Automation Software and Services segment revenue increased by $4.2 million, primarily reflecting a sales increase of software platforms.

[0000936395-22-000029:mdna:40]
•Global Services segment revenue increased by $10.0 million, primarily reflecting sales increases of $4.9 million of our maintenance support and training services and $4.4 million of our consulting and network design services.

[0000936395-22-000029:mdna:41]
[same as prior period, unchanged from 0000936395-21-000040:mdna:45]

[0000936395-22-000029:mdna:42]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for the quarter ended January 29, 2022 was primarily driven by increased sales in the United States. The decrease in our APAC region revenue for the quarter ended January 29, 2022 was primarily driven by decreased sales in India and South Korea. The decrease in our EMEA region revenue for the quarter ended January 29, 2022 was primarily driven by decreased sales in The Netherlands and Germany, partially offset by increased sales in the United Kingdom.

[0000936395-22-000029:mdna:43]
[same as prior period, unchanged from 0000936395-21-000040:mdna:47]

[0000936395-22-000029:mdna:44]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Americas | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  | 19.8 | % |  |  |  |  |  |  |  |  |
| %** | 70.5 | % |  | 65.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA | 150,785 |  |  | 155,418 |  |  |  |  | (3.0) | % |  |  |  |  |  |  |  |  |
| %** | 17.8 | % |  | 20.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APAC | 98,514 |  |  | 105,101 |  |  |  |  | (6.3) | % |  |  |  |  |  |  |  |  |
| %** | 11.7 | % |  | 13.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  | 11.5 | % |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:45]
[same as prior period, unchanged from 0000936395-21-000040:mdna:49]

[0000936395-22-000029:mdna:46]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:47]
[same as prior period, unchanged from 0000936395-21-000040:mdna:51]

[0000936395-22-000029:mdna:48]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:49]
•Americas revenue increased by $98.5 million, reflecting sales increases of $66.7 million within our Networking Platforms segment, $17.8 million within our Platform Software and Services segment, $9.1 million within our Global Services segment, and $4.9 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects product line sales increases of $44.2 million of our Converged Packet Optical products and $22.5 million of our Routing and Switching products. The increase of our Converged Packet Optical product line is primarily related to a sales increase of $64.7 million of our 6500 Packet-Optical Platform primarily to communications service providers and Web-scale providers, partially offset by a sales decrease of $20.6 million of our Waveserver® products primarily to Web-scale providers. The increase within our Routing and Switching product line primarily reflects sales increases of $13.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communication service providers, and $12.2 million of our Virtualization Edge software.

[0000936395-22-000029:mdna:50]
•EMEA revenue decreased by $4.6 million, primarily reflecting sales decreases of $8.1 million within our Networking Platforms segment and $1.4 million within our Global Services segment. These sales decreases were partially offset by a sales increase of $4.1 million within our Platform Software and Services segment.

[0000936395-22-000029:mdna:51]
•APAC revenue decreased by $6.6 million, primarily reflecting sales decreases of $8.5 million within our Networking Platforms segment and $1.5 million within our Blue Planet Automation Software and Services segment. These sales decreases were partially offset by sales increases of $2.3 million within our Global Services segment and $1.1 million within our Platform Software and Services segment.

[0000936395-22-000029:mdna:52]
[same as prior period, unchanged from 0000936395-21-000040:mdna:60]

[0000936395-22-000029:mdna:53]
The component elements that comprise our product cost of goods sold and services costs of goods sold are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2021 Annual Report. There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. These are similarly described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2021 Annual Report.

[0000936395-22-000029:mdna:54]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-22-000029:mdna:55]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Total revenue | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  | 11.5 | % |  |  |  |  |  |  |  |  |
| Total cost of goods sold | 460,256 |  |  | 399,239 |  |  |  |  | 15.3 | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 384,187 |  |  | $ | 357,891 |  |  |  |  | 7.3 | % |  |  |  |  |  |  |  |  |
| %** | 45.5 | % |  | 47.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:56]
[same as prior period, unchanged from 0000936395-21-000040:mdna:64]

[0000936395-22-000029:mdna:57]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:58]
[same as prior period, unchanged from 0000936395-21-000040:mdna:66]

[0000936395-22-000029:mdna:59]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Product revenue | $ | 665,007 |  |  | $ | 597,220 |  |  |  |  | 11.4 | % |  |  |  |  |  |  |  |  |
| Product cost of goods sold | 372,565 |  |  | 315,098 |  |  |  |  | 18.2 | % |  |  |  |  |  |  |  |  |
| Product gross profit | $ | 292,442 |  |  | $ | 282,122 |  |  |  |  | 3.7 | % |  |  |  |  |  |  |  |  |
| %** | 44.0 | % |  | 47.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:60]
[same as prior period, unchanged from 0000936395-21-000040:mdna:68]

[0000936395-22-000029:mdna:61]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:62]
[same as prior period, unchanged from 0000936395-21-000040:mdna:70]

[0000936395-22-000029:mdna:63]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Services revenue | $ | 179,436 |  |  | $ | 159,910 |  |  |  |  | 12.2 | % |  |  |  |  |  |  |  |  |
| Services cost of goods sold | 87,691 |  |  | 84,141 |  |  |  |  | 4.2 | % |  |  |  |  |  |  |  |  |
| Services gross profit | $ | 91,745 |  |  | $ | 75,769 |  |  |  |  | 21.1 | % |  |  |  |  |  |  |  |  |
| % ** | 51.1 | % |  | 47.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:64]
[same as prior period, unchanged from 0000936395-21-000040:mdna:72]

[0000936395-22-000029:mdna:65]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:66]
**     Denotes % of Services Revenue

[0000936395-22-000029:mdna:67]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:68]
•Gross profit increased by $26.3 million. Gross margin decreased by 180 basis points, primarily due to increased costs of components, lower manufacturing efficiencies and market-based price compression, partially offset by a favorable product mix and improved services margin. As described in “Overview” above, we expect the current market shortage for semiconductor components and constrained supply environment to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2022. We believe that these supply chain challenges and their adverse impact on our business and financial results will persist, at least through the remainder of fiscal 2022, and may extend into periods thereafter.

[0000936395-22-000029:mdna:69]
•Gross profit on products increased by $10.3 million. Product gross margin decreased by 320 basis points, primarily due to increased costs of components, lower manufacturing efficiencies and market-based price compression, partially offset by a favorable product mix.

[0000936395-22-000029:mdna:70]
•Gross profit on services increased by $16.0 million. Services gross margin increased by 370 basis points, primarily due to increased revenues on higher margin maintenance and consulting services and improved margins on installation and deployment services.

[0000936395-22-000029:mdna:71]
[same as prior period, unchanged from 0000936395-21-000040:mdna:84]

[0000936395-22-000029:mdna:72]
[same as prior period, unchanged from 0000936395-21-000040:mdna:85]

[0000936395-22-000029:mdna:73]
Approximately 50.4% of our operating expense was non-U.S. Dollar-denominated during the first quarter of fiscal 2022, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the first quarter of fiscal 2022, as compared to the first quarter of fiscal 2021, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $1.4 million, or 0.4%.

[0000936395-22-000029:mdna:74]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2021 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-22-000029:mdna:75]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Research and development | $ | 148,409 |  |  | $ | 132,741 |  |  |  |  | 11.8 | % |  |  |  |  |  |  |  |  |
| %** | 17.6 | % |  | 17.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing | 118,881 |  |  | 97,278 |  |  |  |  | 22.2 | % |  |  |  |  |  |  |  |  |
| %** | 14.1 | % |  | 12.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | 44,498 |  |  | 39,993 |  |  |  |  | 11.3 | % |  |  |  |  |  |  |  |  |
| %** | 5.3 | % |  | 5.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 3,409 |  |  | 5,867 |  |  |  |  | (41.9) | % |  |  |  |  |  |  |  |  |
| %** | 0.4 | % |  | 0.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets | 8,918 |  |  | 5,910 |  |  |  |  | 50.9 | % |  |  |  |  |  |  |  |  |
| %** | 1.1 | % |  | 0.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition and integration costs | 68 |  |  | 307 |  |  |  |  | (77.9) | % |  |  |  |  |  |  |  |  |
| %** | — | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 324,183 |  |  | $ | 282,096 |  |  |  |  | 14.9 | % |  |  |  |  |  |  |  |  |
| %** | 38.4 | % |  | 37.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:76]
[same as prior period, unchanged from 0000936395-21-000040:mdna:91]

[0000936395-22-000029:mdna:77]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:78]
[same as prior period, unchanged from 0000936395-21-000040:mdna:93]

[0000936395-22-000029:mdna:79]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:80]
•Research and development expense increased by $15.7 million. This primarily reflects increases in employee headcount and related compensation costs, professional services, prototype expense and technology and related costs.

[0000936395-22-000029:mdna:81]
•Selling and marketing expense increased by $21.6 million. This increase primarily reflects an increase in employee headcount and related compensation costs.

[0000936395-22-000029:mdna:82]
•General and administrative expense increased by $4.5 million, primarily reflecting increases in employee headcount and related compensation costs, recovery of bad debt and professional services.

[0000936395-22-000029:mdna:83]
•Significant asset impairments and restructuring costs decreased by $2.5 million, reflecting reduced costs associated with actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-22-000029:mdna:84]
•Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022.

[0000936395-22-000029:mdna:85]
•Acquisition and integration costs decreased, reflecting costs in the first quarter of fiscal 2021 for acquisition compensation associated with a three-year earn-out arrangement related to the DonRiver Holdings, LLC acquisition in fiscal 2018. Acquisition and integration costs for the first quarter of fiscal 2022 reflect financial, legal and accounting advisors related to our acquisition of Vyatta.

[0000936395-22-000029:mdna:86]
[same as prior period, unchanged from 0000936395-21-000040:mdna:109]

[0000936395-22-000029:mdna:87]
[same as prior period, unchanged from 0000936395-21-000040:mdna:110]

[0000936395-22-000029:mdna:88]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Interest and other income (loss), net | $ | 3,686 |  |  | $ | (1,121) |  |  |  |  | 428.8 | % |  |  |  |  |  |  |  |  |
| %** | 0.4 | % |  | (0.1) | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | 8,648 |  |  | $ | 7,360 |  |  |  |  | 17.5 | % |  |  |  |  |  |  |  |  |
| %** | 1.0 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | $ | 9,219 |  |  | $ | 11,966 |  |  |  |  | (23.0) | % |  |  |  |  |  |  |  |  |
| %** | 1.1 | % |  | 1.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:89]
[same as prior period, unchanged from 0000936395-21-000040:mdna:112]

[0000936395-22-000029:mdna:90]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:91]
[same as prior period, unchanged from 0000936395-21-000040:mdna:114]

[0000936395-22-000029:mdna:92]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:93]
•Interest and other income (loss), net increased by $4.8 million, primarily reflecting a favorable adjustment to the carrying value of a cost method equity investment and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-22-000029:mdna:94]
•Interest expense increased primarily due to additional outstanding indebtedness, including the 2030 Notes entered into in the first quarter of fiscal 2022.

[0000936395-22-000029:mdna:95]
•Provision for income taxes decreased by $2.7 million primarily due to a decrease in pre-tax income as compared to the first quarter of fiscal 2021. The effective tax rate for the first quarter of fiscal 2022 decreased as compared to the first quarter of fiscal 2021, primarily due to an increased tax benefit associated with stock compensation.

[0000936395-22-000029:mdna:96]
[same as prior period, unchanged from 0000936395-21-000040:mdna:124]

[0000936395-22-000029:mdna:97]
[same as prior period, unchanged from 0000936395-21-000040:mdna:125]

[0000936395-22-000029:mdna:98]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 29, 2022 |  | January 30, 2021 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 134,125 |  |  | $ | 156,431 |  |  |  |  | (14.3) | % |  |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 49,496 |  |  | $ | 27,660 |  |  |  |  | 78.9 | % |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | $ | (1,034) |  |  | $ | (2,434) |  |  |  |  | 57.5 | % |  |  |  |  |  |  |  |  |
| Global Services | $ | 53,191 |  |  | $ | 43,493 |  |  |  |  | 22.3 | % |  |  |  |  |  |  |  |  |

[0000936395-22-000029:mdna:99]
[same as prior period, unchanged from 0000936395-21-000040:mdna:127]

[0000936395-22-000029:mdna:100]
*    Denotes % change from 2021 to 2022

[0000936395-22-000029:mdna:101]
Quarter ended January 29, 2022 as compared to the quarter ended January 30, 2021

[0000936395-22-000029:mdna:102]
•Networking Platforms segment profit decreased by $22.3 million, primarily due to lower gross margin, as described above, and higher research and development costs, partially offset by higher sales volume.

[0000936395-22-000029:mdna:103]
•Platform Software and Services segment profit increased by $21.8 million, primarily due to higher sales volume and higher gross margin on software-related services, partially offset by lower gross margin on software platform sales.

[0000936395-22-000029:mdna:104]
•Blue Planet Automation Software and Services segment loss decreased by $1.4 million, primarily due to higher sales volume and higher gross margin on software platform sales, partially offset by lower gross margin on software-related services.

[0000936395-22-000029:mdna:105]
•Global Services segment profit increased by $9.7 million, primarily due to higher sales volume and higher gross margin, as described above.

[0000936395-22-000029:mdna:106]
[same as prior period, unchanged from 0000936395-21-000040:mdna:140]

[0000936395-22-000029:mdna:107]
Overview. For the three months ended January 29, 2022, we used $54.4 million of cash in operating activities as our working capital requirements of $157.6 million exceeded our net income (adjusted for non-cash charges) of $103.2 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-22-000029:mdna:108]
Cash, cash equivalents and investments decreased by $6.4 million during the first three months of fiscal 2022. In addition to the cash used in operations, the decrease in cash also included the following items: (i) cash used to fund our investing activities for capital expenditures totaling $25.8 million; (ii) cash used for our acquisition of Vyatta of $56.0 million; (iii) cash used for stock repurchases under our stock repurchase program of $250.0 million; and (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $25.2 million. Proceeds from the issuance of the 2030 Notes provided $395.5 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan provided $15.1 million in cash during the three months ended January 29, 2022.

[0000936395-22-000029:mdna:109]
See Notes 4, 15 and 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for additional information on these transactions.

[0000936395-22-000029:mdna:110]
[same as prior period, unchanged from 0000936395-21-000040:mdna:143]

[0000936395-22-000029:mdna:111]
|  | January 29,2022 |  | October 30,2021 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,118,636 |  |  | $ | 1,422,546 |  |  | $ | (303,910) |  |
| Short-term investments in marketable debt securities | 460,368 |  |  | 181,483 |  |  | 278,885 |  |
| Long-term investments in marketable debt securities | 88,640 |  |  | 70,038 |  |  | 18,602 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,667,644 |  |  | $ | 1,674,067 |  |  | $ | (6,423) |  |

[0000936395-22-000029:mdna:112]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which, as of January 29, 2022 totaled $1.7 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 29, 2022, letters of credit totaling $84.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 29, 2022.

[0000936395-22-000029:mdna:113]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $231.3 million as of January 29, 2022. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $32.0 million.

[0000936395-22-000029:mdna:114]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and had $750.0 million remaining under the current repurchase authorization as of January 29, 2022. The repurchases contemplated by the ASR Agreement were completed on February 15, 2022. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-22-000029:mdna:115]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets

[0000936395-22-000029:mdna:116]
and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-22-000029:mdna:117]
Cash Used In Operating Activities

[0000936395-22-000029:mdna:118]
The following sections set forth the components of our $54.4 million of cash used in operating activities during the first three months of fiscal 2022:

[0000936395-22-000029:mdna:119]
[same as prior period, unchanged from 0000936395-21-000040:mdna:151]

[0000936395-22-000029:mdna:120]
[same as prior period, unchanged from 0000936395-21-000040:mdna:152]

[0000936395-22-000029:mdna:121]
|  | Three Months Ended |
|  | January 29, 2022 |
| Net income | $ | 45,823 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 23,653 |  |
| Share-based compensation expenses | 24,297 |  |
| Amortization of intangible assets | 12,230 |  |
| Provision for inventory excess and obsolescence | 3,799 |  |
| Provision for warranty | 2,817 |  |
| Deferred taxes | (766) |  |
| Other | (8,615) |  |
| Net income (adjusted for non-cash charges) | $ | 103,238 |  |

[0000936395-22-000029:mdna:122]
[same as prior period, unchanged from 0000936395-21-000040:mdna:154]

[0000936395-22-000029:mdna:123]
We used $157.6 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-22-000029:mdna:124]
|  | Three Months Ended |
|  | January 29, 2022 |
| Cash provided by accounts receivable | $ | 87,223 |  |
| Cash used in inventories | (87,178) |  |
| Cash used in prepaid expenses and other | (14,134) |  |
| Cash used in accounts payable, accruals and other obligations | (152,981) |  |
| Cash provided by deferred revenue | 10,417 |  |
| Cash used in operating lease assets and liabilities, net | (996) |  |
| Total cash used for working capital | $ | (157,649) |  |

[0000936395-22-000029:mdna:125]
As compared to the end of fiscal 2021:

[0000936395-22-000029:mdna:126]
•The $87.2 million cash provided by accounts receivable during the first three months of fiscal 2022 reflects increased cash collections;

[0000936395-22-000029:mdna:127]
•The $87.2 million of cash used in inventories during the first three months of fiscal 2022 primarily reflects increases in raw materials inventory related to the steps that we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-22-000029:mdna:128]
•The $14.1 million of cash used in prepaid expense and other during the first three months of fiscal 2022 primarily reflects increases in contract assets and product demonstration equipment, partially offset by decreases in prepaid VAT taxes and foreign currency forward contracts;

[0000936395-22-000029:mdna:129]
•The $153.0 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2022 primarily reflects the payment to employees under our annual cash incentive compensation plan and increased payments for inventory purchases during the first quarter of fiscal 2022;

[0000936395-22-000029:mdna:130]
•The $10.4 million of cash provided by deferred revenue during the first three months of fiscal 2022 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-22-000029:mdna:131]
•The $1.0 million of cash used in operating lease assets and liabilities, net, during the first three months of fiscal 2022 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-22-000029:mdna:132]
The days sales outstanding (“DSOs”) for the first three months of fiscal 2022 were 97 days, and the inventory turns for the first three months of fiscal 2022 were 3.3. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-22-000029:mdna:133]
[same as prior period, unchanged from 0000936395-21-000040:mdna:165]

[0000936395-22-000029:mdna:134]
[same as prior period, unchanged from 0000936395-21-000040:mdna:166]

[0000936395-22-000029:mdna:135]
|  | Three Months Ended |
|  | January 29, 2022 |
| Term Loan due September 28, 2025(1) | $ | 3,208 |  |
| Senior Notes due January 31, 2030(2) | — |  |
| Interest rate swaps(3) | 2,561 |  |
| ABL Credit Facility(4) | 713 |  |
| Finance leases | 1,188 |  |
| Cash paid during period | $ | 7,670 |  |

[0000936395-22-000029:mdna:136]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the first quarter of fiscal 2022, the interest rate on the 2025 Term Loan was 1.85%.

[0000936395-22-000029:mdna:137]
(2) The 2030 Notes bear interest at a rate of 4.00% per annum and matures on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022. See Note 15 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report.

[0000936395-22-000029:mdna:138]
(3) The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023.

[0000936395-22-000029:mdna:139]
(4) During the first three months of fiscal 2022, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.7 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-22-000029:mdna:140]
[same as prior period, unchanged from 0000936395-21-000040:mdna:171]

[0000936395-22-000029:mdna:141]
Our contractual obligations have not changed materially since October 30, 2021, except for the item listed below. For a summary of our contractual obligations, see Item 7 of Part II of the 2021 Annual Report.

[0000936395-22-000029:mdna:142]
Debt. As of January 29, 2022, we had $400.0 million outstanding principal associated with our 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes total $128.6 million, with $16.6 million payable within 12 months. For additional information about our 2030 Notes, see Note 15 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-22-000029:mdna:143]
[same as prior period, unchanged from 0000936395-21-000040:mdna:175]

[0000936395-22-000029:mdna:144]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact

[0000936395-22-000029:mdna:145]
on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-22-000029:mdna:146]
Our critical accounting policies and estimates have not changed materially since October 30, 2021. For a discussion of our critical accounting policies and estimates, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Item 7 of Part II of our 2021 Annual Report.

[0000936395-22-000029:mdna:147]
[same as prior period, unchanged from 0000936395-21-000040:mdna:184]

[0000936395-22-000029:mdna:148]
[same as prior period, unchanged from 0000936395-21-000040:mdna:185]
