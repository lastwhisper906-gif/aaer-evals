# CIEN 8-K — 0000936395-22-000024 filed 2022-03-07

## item codes, every 8-K on or before 2022-03-09

- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2022-03-09

- none on or before 2022-03-09

## item 2.02 — earnings release, exhibit 99.1

[0000936395-22-000024:8k_2_02:1]
EX-99.1
2
ex991-2022q1earningspressr.htm
EX-99.1

[0000936395-22-000024:8k_2_02:2]
Document

[0000936395-22-000024:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-22-000024:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2022 Financial Results

[0000936395-22-000024:8k_2_02:5]
HANOVER, Md. - March 7, 2022 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal first quarter ended January 29, 2022.

[0000936395-22-000024:8k_2_02:6]
•Q1 Revenue: $844.4 million

[0000936395-22-000024:8k_2_02:7]
•Q1 Net Income per Share: $0.29 GAAP; $0.47 adjusted (non-GAAP)

[0000936395-22-000024:8k_2_02:8]
•Share Repurchases: Ciena entered into a $250 million accelerated share repurchase ("ASR") arrangement during the first quarter of fiscal 2022 under its new share repurchase program. The final settlement of the ASR was completed in the second quarter of fiscal 2022 with approximately 3.6 million shares repurchased.

[0000936395-22-000024:8k_2_02:9]
“First quarter revenue grew more than 10% year-over-year and continued broad-based demand drove very strong orders growth in the quarter, providing us additional visibility for the fiscal year," said Gary Smith, president and CEO of Ciena. "We expect our strategic investments to drive a significant increase in supply chain capacity in the second half, and therefore remain confident in our ability to address demand and achieve the strong revenue growth we expect for the fiscal year.”

[0000936395-22-000024:8k_2_02:10]
For the fiscal first quarter 2022, Ciena reported revenue of $844.4 million as compared to $757.1 million for the fiscal first quarter 2021.

[0000936395-22-000024:8k_2_02:11]
Ciena's GAAP net income for the fiscal first quarter 2022 was $45.8 million, or $0.29 per diluted common share, which compares to a GAAP net income of $55.3 million, or $0.35 per diluted common share, for the fiscal first quarter 2021.

[0000936395-22-000024:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2022 was $72.6 million, or $0.47 per diluted common share, which compares to an adjusted (non-GAAP) net income of $81.3 million, or $0.52 per diluted common share, for the fiscal first quarter 2021.

[0000936395-22-000024:8k_2_02:13]
Fiscal First Quarter 2022 Performance Summary

[0000936395-22-000024:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-22-000024:8k_2_02:15]
|  |  | GAAP Results |
|  |  | Q1 |  | Q1 |  | Period Change |
|  |  | FY 2022 |  | FY 2021 |  | Y-T-Y* |
| Revenue |  | $ | 844.4 |  |  | $ | 757.1 |  |  | 11.5 | % |
| Gross margin |  | 45.5 | % |  | 47.3 | % |  | (1.8) | % |
| Operating expense |  | $ | 324.2 |  |  | $ | 282.1 |  |  | 14.9 | % |
| Operating margin |  | 7.1 | % |  | 10.0 | % |  | (2.9) | % |

[0000936395-22-000024:8k_2_02:16]
|  |  | Non-GAAP Results |
|  |  | Q1 |  | Q1 |  | Period Change |
|  |  | FY 2022 |  | FY 2021 |  | Y-T-Y* |
| Revenue |  | $ | 844.4 |  |  | $ | 757.1 |  |  | 11.5 | % |
| Adj. gross margin |  | 46.2 | % |  | 48.0 | % |  | (1.8) | % |
| Adj. operating expense |  | $ | 290.0 |  |  | $ | 253.0 |  |  | 14.6 | % |
| Adj. operating margin |  | 11.8 | % |  | 14.6 | % |  | (2.8) | % |
| Adj. EBITDA |  | $ | 123.7 |  |  | $ | 133.8 |  |  | (7.5) | % |

[0000936395-22-000024:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-22-000024:8k_2_02:18]
|  |  | Revenue by Segment |
|  |  | Q1 FY 2022 |  | Q1 FY 2021 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 540.9 |  |  | 64.1 |  |  | $ | 512.3 |  |  | 67.7 |  |
| Routing and Switching |  | 85.7 |  |  | 10.1 |  |  | 64.3 |  |  | 8.5 |  |
| Total Networking Platforms |  | 626.6 |  |  | 74.2 |  |  | 576.6 |  |  | 76.2 |  |
| Platform Software and Services |  | 72.9 |  |  | 8.6 |  |  | 49.9 |  |  | 6.6 |  |
| Blue Planet Automation Software and Services |  | 21.1 |  |  | 2.5 |  |  | 16.9 |  |  | 2.2 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 72.5 |  |  | 8.6 |  |  | 67.6 |  |  | 8.9 |  |
| Installation and Deployment |  | 40.4 |  |  | 4.8 |  |  | 39.6 |  |  | 5.2 |  |
| Consulting and Network Design |  | 10.9 |  |  | 1.3 |  |  | 6.5 |  |  | 0.9 |  |
| Total Global Services |  | 123.8 |  |  | 14.7 |  |  | 113.7 |  |  | 15.0 |  |
| Total |  | $ | 844.4 |  |  | 100.0 |  |  | $ | 757.1 |  |  | 100.0 |  |

[0000936395-22-000024:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-22-000024:8k_2_02:20]
2

[0000936395-22-000024:8k_2_02:21]
Additional Performance Metrics for Fiscal First Quarter 2022

[0000936395-22-000024:8k_2_02:22]
|  |  | Revenue by Geographic Region |
|  |  | Q1 FY 2022 |  | Q1 FY 2021 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 595.1 |  |  | 70.5 |  |  | $ | 496.6 |  |  | 65.6 |  |
| Europe, Middle East and Africa |  | 150.8 |  |  | 17.8 |  |  | 155.4 |  |  | 20.5 |  |
| Asia Pacific |  | 98.5 |  |  | 11.7 |  |  | 105.1 |  |  | 13.9 |  |
| Total |  | $ | 844.4 |  |  | 100.0 |  |  | $ | 757.1 |  |  | 100.0 |  |

[0000936395-22-000024:8k_2_02:23]
**  Denotes %  of total revenue

[0000936395-22-000024:8k_2_02:24]
•One 10%-plus customer represented a total of 13.1% of revenue

[0000936395-22-000024:8k_2_02:25]
•Cash and investments totaled $1.7 billion

[0000936395-22-000024:8k_2_02:26]
•Cash flow used in operations totaled $54.4 million

[0000936395-22-000024:8k_2_02:27]
•Average days' sales outstanding (DSOs) were 97

[0000936395-22-000024:8k_2_02:28]
•Accounts receivable, net balance was $795.2 million

[0000936395-22-000024:8k_2_02:29]
•Unbilled contract asset, net balance was $117.0 million

[0000936395-22-000024:8k_2_02:30]
•Inventories totaled $457.6 million, including:

[0000936395-22-000024:8k_2_02:31]
◦Raw materials: $295.9 million

[0000936395-22-000024:8k_2_02:32]
◦Work in process: $10.3 million

[0000936395-22-000024:8k_2_02:33]
◦Finished goods: $149.9 million

[0000936395-22-000024:8k_2_02:34]
◦Deferred cost of sales: $36.9 million

[0000936395-22-000024:8k_2_02:35]
◦Reserve for excess and obsolescence: $(35.4) million

[0000936395-22-000024:8k_2_02:36]
•Product inventory turns were 3.3

[0000936395-22-000024:8k_2_02:37]
•Headcount totaled 7,419

[0000936395-22-000024:8k_2_02:38]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal First Quarter 2022 Results

[0000936395-22-000024:8k_2_02:39]
Today, Monday, March 7, 2022, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal first quarter 2022 results.

[0000936395-22-000024:8k_2_02:40]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-22-000024:8k_2_02:41]
Notes to Investors

[0000936395-22-000024:8k_2_02:42]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include:

[0000936395-22-000024:8k_2_02:43]
"First quarter revenue grew more than 10% year-over-year and continued broad-based demand drove very strong orders growth in the quarter, providing us additional visibility for the fiscal year" and "We expect our strategic investments to drive a significant increase in supply chain capacity in the second half, and therefore remain confident in our ability to address demand and achieve the strong revenue growth we expect for the fiscal year."

[0000936395-22-000024:8k_2_02:44]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results;  changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain constraints or disruptions; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical events, including but not limited to the ongoing conflict between Ukraine and Russia, public health emergencies; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena’s Annual Report on Form 10-K filed with the SEC on December 17, 2021 and included in its Quarterly Report on Form 10-Q for the first quarter of fiscal 2022 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-22-000024:8k_2_02:45]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-22-000024:8k_2_02:46]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-22-000024:8k_2_02:47]
4

[0000936395-22-000024:8k_2_02:48]
CIENA CORPORATION

[0000936395-22-000024:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-22-000024:8k_2_02:50]
(in thousands, except per share data)

[0000936395-22-000024:8k_2_02:51]
(unaudited)

[0000936395-22-000024:8k_2_02:52]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 665,007 |  |  | $ | 597,220 |  |  |  |  |  |
| Services | 179,436 |  |  | 159,910 |  |  |  |  |  |
| Total revenue | 844,443 |  |  | 757,130 |  |  |  |  |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 372,565 |  |  | 315,098 |  |  |  |  |  |
| Services | 87,691 |  |  | 84,141 |  |  |  |  |  |
| Total cost of goods sold | 460,256 |  |  | 399,239 |  |  |  |  |  |
| Gross profit | 384,187 |  |  | 357,891 |  |  |  |  |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 148,409 |  |  | 132,741 |  |  |  |  |  |
| Selling and marketing | 118,881 |  |  | 97,278 |  |  |  |  |  |
| General and administrative | 44,498 |  |  | 39,993 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 3,409 |  |  | 5,867 |  |  |  |  |  |
| Amortization of intangible assets | 8,918 |  |  | 5,910 |  |  |  |  |  |
| Acquisition and integration costs | 68 |  |  | 307 |  |  |  |  |  |
| Total operating expenses | 324,183 |  |  | 282,096 |  |  |  |  |  |
| Income from operations | 60,004 |  |  | 75,795 |  |  |  |  |  |
| Interest and other income (loss), net | 3,686 |  |  | (1,121) |  |  |  |  |  |
| Interest expense | (8,648) |  |  | (7,360) |  |  |  |  |  |
| Income before income taxes | 55,042 |  |  | 67,314 |  |  |  |  |  |
| Provision for income taxes | 9,219 |  |  | 11,966 |  |  |  |  |  |
| Net income | $ | 45,823 |  |  | $ | 55,348 |  |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.30 |  |  | $ | 0.36 |  |  |  |  |  |
| Diluted net income per potential common share | $ | 0.29 |  |  | $ | 0.35 |  |  |  |  |  |
| Weighted average basic common shares outstanding | 154,151 |  |  | 155,174 |  |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 | 155,807 |  |  | 156,583 |  |  |  |  |  |

[0000936395-22-000024:8k_2_02:53]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first quarter of fiscal 2022 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-22-000024:8k_2_02:54]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first quarter of fiscal 2021 includes 1.4 million shares underlying certain stock option and stock unit awards.

[0000936395-22-000024:8k_2_02:55]
CIENA CORPORATION

[0000936395-22-000024:8k_2_02:56]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-22-000024:8k_2_02:57]
(in thousands, except share data)

[0000936395-22-000024:8k_2_02:58]
(unaudited)

[0000936395-22-000024:8k_2_02:59]
|  | January 29,2022 |  | October 30,2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,118,636 |  |  | $ | 1,422,546 |  |
| Short-term investments | 460,368 |  |  | 181,483 |  |
| Accounts receivable, net | 795,247 |  |  | 884,958 |  |
| Inventories | 457,604 |  |  | 374,265 |  |
| Prepaid expenses and other | 332,259 |  |  | 325,654 |  |
| Total current assets | 3,164,114 |  |  | 3,188,906 |  |
| Long-term investments | 88,640 |  |  | 70,038 |  |
| Equipment, building, furniture and fixtures, net | 276,120 |  |  | 284,968 |  |
| Operating lease right-of-use assets | 43,340 |  |  | 44,285 |  |
| Goodwill | 322,822 |  |  | 311,645 |  |
| Other intangible assets, net | 101,026 |  |  | 65,314 |  |
| Deferred tax asset, net | 799,593 |  |  | 800,180 |  |
| Other long-term assets | 104,707 |  |  | 99,891 |  |
| Total assets | $ | 4,900,362 |  |  | $ | 4,865,227 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 310,107 |  |  | $ | 356,176 |  |
| Accrued liabilities and other short-term obligations | 299,408 |  |  | 409,285 |  |
| Deferred revenue | 124,956 |  |  | 118,007 |  |
| Operating lease liabilities | 18,927 |  |  | 18,632 |  |
| Current portion of long-term debt | 6,930 |  |  | 6,930 |  |
| Total current liabilities | 760,328 |  |  | 909,030 |  |
| Long-term deferred revenue | 60,670 |  |  | 57,457 |  |
| Other long-term obligations | 159,942 |  |  | 166,803 |  |
| Long-term operating lease liabilities | 39,369 |  |  | 41,564 |  |
| Long-term debt, net | 1,065,263 |  |  | 670,355 |  |
| Total liabilities | $ | 2,085,572 |  |  | $ | 1,845,209 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 152,990,723and 154,858,981 shares issued and outstanding | 1,530 |  |  | 1,549 |  |
| Additional paid-in capital | 6,567,474 |  |  | 6,803,162 |  |
| Accumulated other comprehensive income (loss) | (14,905) |  |  | 439 |  |
| Accumulated deficit | (3,739,309) |  |  | (3,785,132) |  |
| Total stockholders’ equity | 2,814,790 |  |  | 3,020,018 |  |
| Total liabilities and stockholders’ equity | $ | 4,900,362 |  |  | $ | 4,865,227 |  |

[0000936395-22-000024:8k_2_02:60]
6

[0000936395-22-000024:8k_2_02:61]
CIENA CORPORATION

[0000936395-22-000024:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-22-000024:8k_2_02:63]
(in thousands) (unaudited)

[0000936395-22-000024:8k_2_02:64]
|  | Three Months Ended |
|  | January 29, |  | January 30, |
|  | 2022 |  | 2021 |
| Cash flows used in operating activities: |  |  |  |
| Net income | $ | 45,823 |  |  | $ | 55,348 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 23,653 |  |  | 23,188 |  |
| Share-based compensation expense | 24,297 |  |  | 18,964 |  |
| Amortization of intangible assets | 12,230 |  |  | 9,642 |  |
| Deferred taxes | (766) |  |  | (905) |  |
| Provision for inventory excess and obsolescence | 3,799 |  |  | 5,905 |  |
| Provision for warranty | 2,817 |  |  | 3,239 |  |
| Other | (8,615) |  |  | 4,277 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 87,223 |  |  | 18,862 |  |
| Inventories | (87,178) |  |  | (51,020) |  |
| Prepaid expenses and other | (14,134) |  |  | (13,835) |  |
| Operating lease right-of-use assets | 4,120 |  |  | 4,103 |  |
| Accounts payable, accruals and other obligations | (152,981) |  |  | (112,170) |  |
| Deferred revenue | 10,417 |  |  | 31,917 |  |
| Short and long-term operating lease liabilities | (5,116) |  |  | (4,834) |  |
| Net cash used in operating activities | (54,411) |  |  | (7,319) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (25,804) |  |  | (20,868) |  |
| Purchase of available for sale securities | (350,465) |  |  | (71,756) |  |
| Proceeds from maturities of available for sale securities | 50,000 |  |  | 51,266 |  |
| Settlement of foreign currency forward contracts, net | 1,346 |  |  | 2,357 |  |
| Acquisition of business, net of cash acquired | (56,036) |  |  | — |  |
| Proceeds from sale of equity investment | — |  |  | 4,678 |  |
| Net cash used in investing activities | (380,959) |  |  | (34,323) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of senior notes | 400,000 |  |  | — |  |
| Payment of long term debt | — |  |  | (1,732) |  |
| Payment of debt issuance costs | (4,506) |  |  | — |  |
| Payment of finance lease obligations | (771) |  |  | (702) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (25,150) |  |  | (19,242) |  |
| Repurchases of common stock - repurchase program | (250,000) |  |  | (12,406) |  |
| Proceeds from issuance of common stock | 15,146 |  |  | 13,447 |  |
| Net cash provided by (used in) financing activities | 134,719 |  |  | (20,635) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (3,259) |  |  | 2,879 |  |
| Net decrease in cash, cash equivalents and restricted cash | (303,910) |  |  | (59,398) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,422,604 |  |  | 1,088,708 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,118,694 |  |  | $ | 1,029,310 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 7,670 |  |  | $ | 7,566 |  |
| Cash paid during the period for income taxes, net | $ | 6,112 |  |  | $ | 8,798 |  |
| Operating lease payments | $ | 5,480 |  |  | $ | 5,387 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 2,972 |  |  | $ | 5,935 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | — |  |  | $ | 800 |  |
| Operating lease right-of-use assets subject to lease liability | $ | 3,376 |  |  | $ | 555 |  |

[0000936395-22-000024:8k_2_02:65]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |
|  |  | January 29, |  | January 30, |
|  |  | 2022 |  | 2021 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 384,187 |  |  | $ | 357,891 |  |
| Share-based compensation-products |  | 900 |  |  | 953 |  |
| Share-based compensation-services |  | 1,584 |  |  | 1,205 |  |
| Amortization of intangible assets |  | 3,312 |  |  | 3,732 |  |
| Total adjustments related to gross profit |  | 5,796 |  |  | 5,890 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 389,983 |  |  | $ | 363,781 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 46.2 | % |  | 48.0 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 324,183 |  |  | $ | 282,096 |  |
| Share-based compensation-research and development |  | 6,830 |  |  | 4,794 |  |
| Share-based compensation-sales and marketing |  | 7,060 |  |  | 5,816 |  |
| Share-based compensation-general and administrative |  | 7,912 |  |  | 6,358 |  |
| Significant asset impairments and restructuring costs |  | 3,409 |  |  | 5,867 |  |
| Amortization of intangible assets |  | 8,918 |  |  | 5,910 |  |
| Acquisition and integration costs |  | 68 |  |  | 307 |  |
| Total adjustments related to operating expense |  | 34,197 |  |  | 29,052 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 289,986 |  |  | $ | 253,044 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 60,004 |  |  | $ | 75,795 |  |
| Total adjustments related to gross profit |  | 5,796 |  |  | 5,890 |  |
| Total adjustments related to operating expense |  | 34,197 |  |  | 29,052 |  |
| Total adjustments related to income from operations |  | 39,993 |  |  | 34,942 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 99,997 |  |  | $ | 110,737 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 11.8 | % |  | 14.6 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 45,823 |  |  | $ | 55,348 |  |
| Exclude GAAP provision for income taxes |  | 9,219 |  |  | 11,966 |  |
| Income before income taxes |  | 55,042 |  |  | 67,314 |  |
| Total adjustments related to income from operations |  | 39,993 |  |  | 34,942 |  |
| Unrealized gain on cost method equity investment |  | (4,120) |  |  | — |  |
| Adjusted income before income taxes |  | 90,915 |  |  | 102,256 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 18,365 |  |  | 20,962 |  |
| Adjusted (non-GAAP) net income |  | $ | 72,550 |  |  | $ | 81,294 |  |
| Weighted average basic common shares outstanding |  | 154,151 |  | 155,174 |
| Weighted average dilutive potential common shares outstanding 1 |  | 155,807 |  | 156,583 |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.29 |  |  | $ | 0.35 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.47 |  |  | $ | 0.52 |  |

[0000936395-22-000024:8k_2_02:66]
8

[0000936395-22-000024:8k_2_02:67]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the first quarter of fiscal 2022 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-22-000024:8k_2_02:68]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the first quarter of fiscal 2021 includes 1.4 million shares underlying certain stock option and stock unit awards.

[0000936395-22-000024:8k_2_02:69]
9

[0000936395-22-000024:8k_2_02:70]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |
|  |  | January 29, |  | January 30, |
|  |  | 2022 |  | 2021 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 45,823 |  |  | $ | 55,348 |  |
| Add: Interest expense |  | 8,648 |  |  | 7,360 |  |
| Less: Interest and other income (loss), net |  | 3,686 |  |  | (1,121) |  |
| Add: Provision for income taxes |  | 9,219 |  |  | 11,966 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,653 |  |  | 23,188 |  |
| Add: Amortization of intangible assets |  | 12,230 |  |  | 9,642 |  |
| EBITDA |  | $ | 95,887 |  |  | $ | 108,625 |  |
| Add: Share-based compensation cost |  | 24,297 |  |  | 18,964 |  |
| Add: Significant asset impairments and restructuring costs |  | 3,409 |  |  | 5,867 |  |
| Add: Acquisition and integration costs |  | 68 |  |  | 307 |  |
| Adjusted EBITDA |  | $ | 123,661 |  |  | $ | 133,763 |  |

[0000936395-22-000024:8k_2_02:71]
* * *

[0000936395-22-000024:8k_2_02:72]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-22-000024:8k_2_02:73]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-22-000024:8k_2_02:74]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and the redesign of business processes.

[0000936395-22-000024:8k_2_02:75]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-22-000024:8k_2_02:76]
•Acquisition and integration costs  - includes financial, legal and accounting advisor expense related to our acquisition of Vyatta during the first quarter of fiscal 2022. Acquisition and integration costs for the first quarter of fiscal 2021 include costs of acquisition compensation associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018.

[0000936395-22-000024:8k_2_02:77]
•Unrealized gain on cost method equity investment - reflects a change in the carrying value of a certain cost method equity investment.

[0000936395-22-000024:8k_2_02:78]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20.2% for the first fiscal quarter of 2022 and 20.5% for the first fiscal quarter of 2021. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
