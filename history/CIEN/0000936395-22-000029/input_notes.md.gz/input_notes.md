# CIEN notes — 0000936395-22-000029


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-22-000029:notes:1]
[same as prior period, unchanged from 0000936395-21-000040:notes:1]

[0000936395-22-000029:notes:2]
[same as prior period, unchanged from 0000936395-21-000040:notes:2]

[0000936395-22-000029:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 30, 2021 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2021 (the “2021 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2022 and 2021 are 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-22-000029:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2021 Annual Report.

[0000936395-22-000029:notes:5]
[same as prior period, unchanged from 0000936395-21-000040:notes:5]

[0000936395-22-000029:notes:6]
In December 2019, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022. Ciena adopted ASU 2019-12 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000029:notes:7]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. Ciena elected to adopt ASU 2021-10 in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations

[0000936395-22-000029:notes:8]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London

[0000936395-22-000029:notes:9]
Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance and may be applied prospectively through December 31, 2022. Ciena adopted Topic 848 beginning in the first quarter of fiscal 2022 without any material impact on its financial position and results of operations.

[0000936395-22-000029:notes:10]
[same as prior period, unchanged from 0000936395-21-000040:notes:12]

[0000936395-22-000029:notes:11]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-22-000029:notes:12]
[same as prior period, unchanged from 0000936395-21-000040:notes:14]

[0000936395-22-000029:notes:13]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line.

[0000936395-22-000029:notes:14]
[same as prior period, unchanged from 0000936395-21-000040:notes:16]

[0000936395-22-000029:notes:15]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

[0000936395-22-000029:notes:16]
|  | Quarter Ended January 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 512,324 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 512,324 |  |
| Routing and Switching | 64,307 |  |  | — |  |  | — |  |  | — |  |  | 64,307 |  |
| Platform Software and Services | — |  |  | 49,839 |  |  | — |  |  | — |  |  | 49,839 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,934 |  |  | — |  |  | 16,934 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,630 |  |  | 67,630 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,611 |  |  | 39,611 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 6,485 |  |  | 6,485 |  |
| Total revenue by product line | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 576,631 |  |  | $ | 16,062 |  |  | $ | 5,173 |  |  | $ | 1,857 |  |  | $ | 599,723 |  |
| Services transferred over time | — |  |  | 33,777 |  |  | 11,761 |  |  | 111,869 |  |  | 157,407 |  |
| Total revenue by timing of revenue recognition | $ | 576,631 |  |  | $ | 49,839 |  |  | $ | 16,934 |  |  | $ | 113,726 |  |  | $ | 757,130 |  |

[0000936395-22-000029:notes:17]
[same as prior period, unchanged from 0000936395-21-000040:notes:21]

[0000936395-22-000029:notes:18]
[same as prior period, unchanged from 0000936395-21-000040:notes:22]

[0000936395-22-000029:notes:19]
|  |  | Quarter Ended |  |  |
|  |  | January 29, |  | January 30, |  |  |  |  |
|  |  | 2022 |  | 2021 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 595,144 |  |  | $ | 496,611 |  |  |  |  |  |
| EMEA |  | 150,785 |  |  | 155,418 |  |  |  |  |  |
| APAC |  | 98,514 |  |  | 105,101 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 844,443 |  |  | $ | 757,130 |  |  |  |  |  |

[0000936395-22-000029:notes:20]
Ciena’s revenue includes $543.5 million and $439.4 million of United States revenue for the first quarter of fiscal 2022 and 2021, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-22-000029:notes:21]
For the periods below, the only customer that accounted for at least 10% of Ciena’s revenue was as follows (in thousands):

[0000936395-22-000029:notes:22]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| AT&T | $ | 110,876 |  |  | n/a |  |  |  |  |

[0000936395-22-000029:notes:23]
[same as prior period, unchanged from 0000936395-21-000040:notes:27]

[0000936395-22-000029:notes:24]
The customer identified above for the first quarter of fiscal 2022 purchased products and services from each of Ciena’s operating segments.

[0000936395-22-000029:notes:25]
[same as prior period, unchanged from 0000936395-21-000040:notes:29]

[0000936395-22-000029:notes:26]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes sales of the Z-Series Packet-Optical Platform.

[0000936395-22-000029:notes:27]
•Routing and Switching - includes the 3900 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

[0000936395-22-000029:notes:28]
[same as prior period, unchanged from 0000936395-21-000040:notes:32]

[0000936395-22-000029:notes:29]
[same as prior period, unchanged from 0000936395-21-000040:notes:33]

[0000936395-22-000029:notes:30]
[same as prior period, unchanged from 0000936395-21-000040:notes:34]

[0000936395-22-000029:notes:31]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations in which revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-22-000029:notes:32]
[same as prior period, unchanged from 0000936395-21-000040:notes:36]

[0000936395-22-000029:notes:33]
[same as prior period, unchanged from 0000936395-21-000040:notes:37]

[0000936395-22-000029:notes:34]
[same as prior period, unchanged from 0000936395-21-000040:notes:38]

[0000936395-22-000029:notes:35]
[same as prior period, unchanged from 0000936395-21-000040:notes:39]

[0000936395-22-000029:notes:36]
|  |  | Balance at January 29, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 795,247 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 117,003 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 185,626 |  |  | $ | 175,464 |  |

[0000936395-22-000029:notes:37]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 11 below.

[0000936395-22-000029:notes:38]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $56.8 million and $46.4 million of revenue during the first three months of fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance as of October 30, 2021 and October 31, 2020, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 29, 2022 and January 30, 2021.

[0000936395-22-000029:notes:39]
[same as prior period, unchanged from 0000936395-21-000040:notes:43]

[0000936395-22-000029:notes:40]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $29.6 million and $27.6 million as of January 29, 2022 and October 30, 2021, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $7.0 million and $5.5 million during the first three months of fiscal 2022 and 2021, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statement of Operations.

[0000936395-22-000029:notes:41]
[same as prior period, unchanged from 0000936395-21-000040:notes:45]

[0000936395-22-000029:notes:42]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 29, 2022, the aggregate amount of RPO was $2.4 billion. As of January 29, 2022, Ciena expects approximately 89% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-22-000029:notes:43]
[same as prior period, unchanged from 0000936395-21-000040:notes:47]

[0000936395-22-000029:notes:44]
|  | January 29,2022 |  | October 30,2021 |
| Products | $ | 15,438 |  |  | $ | 12,859 |  |
| Services | 170,188 |  |  | 162,605 |  |
| Total deferred revenue | 185,626 |  |  | 175,464 |  |
| Less current portion | (124,956) |  |  | (118,007) |  |
| Long-term deferred revenue | $ | 60,670 |  |  | $ | 57,457 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-22-000029:notes:45]
BUSINESS COMBINATIONS
Vyatta Acquisition

[0000936395-22-000029:notes:46]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology for approximately $56.0 million in cash. This transaction has been accounted for as the acquisition of a business. AT&T is a customer of Ciena, see Note 3 above.

[0000936395-22-000029:notes:47]
Ciena incurred approximately $1.4 million in acquisition-related costs associated with the acquisition of Vyatta, which were primarily incurred during the fourth quarter of fiscal 2021. These costs and expenses primarily include fees associated with financial, legal and accounting advisors. These costs were recorded in acquisition and integration costs in the Condensed Consolidated Statement of Operations.

[0000936395-22-000029:notes:48]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-22-000029:notes:49]
|  | Amount |
| Prepaid expenses and other | $ | 191 |  |
| Equipment, furniture and fixtures | 694 |  |
| Customer relationships and contracts | 15,800 |  |
| Developed technology | 32,300 |  |
| Goodwill | 11,521 |  |
| Accrued liabilities | (4,470) |  |
| Total purchase consideration | $ | 56,036 |  |

[0000936395-22-000029:notes:50]
Customer relationships and contracts represent agreements with existing Vyatta customers and have an estimated useful life of two years.

[0000936395-22-000029:notes:51]
Developed technology represents purchased technology that has reached technological feasibility and for which Vyatta had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-22-000029:notes:52]
The goodwill generated from the acquisition of Vyatta is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-22-000029:notes:53]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings of Vyatta since the acquisition date included in the Condensed Consolidated Statement of Operations for the reporting period are immaterial.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-22-000029:notes:54]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets, for the three months ended January 29, 2022 (in thousands):

[0000936395-22-000029:notes:55]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 410 |  | (1) | 2,999 |  | (2) | 3,409 |  |
| Cash payments | (421) |  |  | (2,999) |  |  | (3,420) |  |
| Balance at January 29, 2022 | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |
| Current restructuring liabilities | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |

[0000936395-22-000029:notes:56]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 29, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000029:notes:57]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization, and costs related to restructured real estate facilities.

[0000936395-22-000029:notes:58]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets for the three months ended January 30, 2021 (in thousands):

[0000936395-22-000029:notes:59]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 31, 2020 | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 1,990 |  | (1) | 3,877 |  | (2) | 5,867 |  |
| Cash payments | (2,994) |  |  | (3,877) |  |  | (6,871) |  |
| Balance at January 30, 2021 | $ | 1,911 |  |  | $ | — |  |  | $ | 1,911 |  |
| Current restructuring liabilities | $ | 1,911 |  |  | $ | — |  |  | $ | 1,911 |  |

[0000936395-22-000029:notes:60]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 30, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000029:notes:61]
(2) Primarily represents variable costs and imputed interest expense related to restructured real estate facilities and the redesign of certain business processes.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-22-000029:notes:62]
[same as prior period, unchanged from 0000936395-21-000040:notes:62]

[0000936395-22-000029:notes:63]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Interest income | $ | 754 |  |  | $ | 534 |  |  |  |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (4,259) |  |  | 4,530 |  |  |  |  |  |
| Foreign currency exchange gains (losses) | 4,766 |  |  | (6,918) |  |  |  |  |  |
| Unrealized gain on cost method equity investment | 4,120 |  |  | — |  |  |  |  |  |
| Other | (1,694) |  |  | 733 |  |  |  |  |  |
| Interest and other income (loss), net | $ | 3,686 |  |  | $ | (1,121) |  |  |  |  |  |

[0000936395-22-000029:notes:64]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $4.8 million in foreign currency exchange rate gains for the first three months of fiscal 2022 and $6.9 million in foreign currency exchange rate losses during the first three months of fiscal 2021, as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2022, Ciena recorded losses of $4.3 million and during the  first three months of fiscal 2021, Ciena recorded gains of $4.5 million from non-hedge designated foreign currency forward contracts. During the first quarter of fiscal 2021, Ciena recorded an unrealized gain of $4.1 million on its cost method equity investment.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-22-000029:notes:65]
INCOME TAXES
The effective tax rate for the quarter ended January 29, 2022 was lower than the effective tax rate for the quarter ended January 30, 2021, primarily due to an increased tax benefit associated with stock compensation.

[0000936395-22-000029:notes:66]
[same as prior period, unchanged from 0000936395-21-000040:notes:66]


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-22-000029:notes:67]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-22-000029:notes:68]
|  | January 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 460,683 |  |  | $ | — |  |  | $ | (315) |  |  | $ | 460,368 |  |
| Included in long-term investments | 89,527 |  |  | — |  |  | (887) |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | — |  |  | $ | (1,202) |  |  | $ | 549,008 |  |

[0000936395-22-000029:notes:69]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,488 |  |  | $ | 5 |  |  | $ | (10) |  |  | $ | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |

[0000936395-22-000029:notes:70]
The following table summarizes the final legal maturities of debt investments at January 29, 2022 (in thousands):

[0000936395-22-000029:notes:71]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 460,683 |  |  | $ | 460,368 |  |
| Due in 1-2 years | 89,527 |  |  | 88,640 |  |
|  | $ | 550,210 |  |  | $ | 549,008 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-22-000029:notes:72]
FAIR VALUE MEASUREMENTS
    As of the date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-22-000029:notes:73]
|  | January 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 711,027 |  |  | $ | — |  |  | $ | — |  |  | $ | 711,027 |  |
| Bond mutual fund | 100,456 |  |  | — |  |  | — |  |  | 100,456 |  |
| Time deposits | 30,046 |  |  | — |  |  | — |  |  | 30,046 |  |
| Deferred compensation plan assets | 13,847 |  |  | — |  |  | — |  |  | 13,847 |  |
| U.S. government obligations | — |  |  | 648,981 |  |  | — |  |  | 648,981 |  |
| Foreign currency forward contracts | — |  |  | 6,885 |  |  | — |  |  | 6,885 |  |
| Total assets measured at fair value | $ | 855,376 |  |  | $ | 655,866 |  |  | $ | — |  |  | $ | 1,511,242 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,012 |  |  | $ | — |  |  | $ | 3,012 |  |
| Forward starting interest rate swaps | — |  |  | 10,784 |  |  | — |  |  | 10,784 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 13,796 |  |  | $ | — |  |  | $ | 13,796 |  |

[0000936395-22-000029:notes:74]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,120,851 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,120,851 |  |
| Bond mutual fund | 75,425 |  |  | — |  |  | — |  |  | 75,425 |  |
| Time deposits | 30,036 |  |  | — |  |  | — |  |  | 30,036 |  |
| Deferred compensation plan assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| U.S. government obligations | — |  |  | 251,521 |  |  | — |  |  | 251,521 |  |
| Foreign currency forward contracts | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Total assets measured at fair value | $ | 1,239,280 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,505,736 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Forward starting interest rate swaps | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000029:notes:75]
[same as prior period, unchanged from 0000936395-21-000040:notes:75]

[0000936395-22-000029:notes:76]
|  | January 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 841,529 |  |  | $ | 99,973 |  |  | $ | — |  |  | $ | 941,502 |  |
| Short-term investments | — |  |  | 460,368 |  |  | — |  |  | 460,368 |  |
| Prepaid expenses and other | — |  |  | 6,885 |  |  | — |  |  | 6,885 |  |
| Long-term investments | — |  |  | 88,640 |  |  | — |  |  | 88,640 |  |
| Other long-term assets | 13,847 |  |  | — |  |  | — |  |  | 13,847 |  |
| Total assets measured at fair value | $ | 855,376 |  |  | $ | 655,866 |  |  | $ | — |  |  | $ | 1,511,242 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 3,012 |  |  | $ | — |  |  | $ | 3,012 |  |
| Other long-term obligations | — |  |  | 10,784 |  |  | — |  |  | 10,784 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 13,796 |  |  | $ | — |  |  | $ | 13,796 |  |

[0000936395-22-000029:notes:77]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,226,312 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,226,312 |  |
| Short-term investments | — |  |  | 181,483 |  |  | — |  |  | 181,483 |  |
| Prepaid expenses and other | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Long-term investments | — |  |  | 70,038 |  |  | — |  |  | 70,038 |  |
| Other long-term assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| Total assets measured at fair value | $ | 1,239,280 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,505,736 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Other long-term obligations | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000029:notes:78]
[same as prior period, unchanged from 0000936395-21-000040:notes:78]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-22-000029:notes:79]
[same as prior period, unchanged from 0000936395-21-000040:notes:79]

[0000936395-22-000029:notes:80]
|  | January 29,2022 |  | October 30,2021 |
| Raw materials | $ | 295,866 |  |  | $ | 175,399 |  |
| Work-in-process | 10,304 |  |  | 10,260 |  |
| Finished goods | 149,931 |  |  | 180,800 |  |
| Deferred cost of goods sold | 36,925 |  |  | 44,765 |  |
| Gross inventories | 493,026 |  |  | 411,224 |  |
| Reserve for inventory excess and obsolescence | (35,422) |  |  | (36,959) |  |
| Inventories, net | $ | 457,604 |  |  | $ | 374,265 |  |

[0000936395-22-000029:notes:81]
The increase in raw materials inventory is related to the steps Ciena is taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first three months of fiscal 2022, Ciena recorded a provision for inventory excess and obsolescence of $3.8 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-22-000029:notes:82]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-22-000029:notes:83]
|  | January 29,2022 |  | October 30,2021 |
| Contract assets for unbilled accounts receivable, net | $ | 117,003 |  |  | $ | 101,355 |  |
| Prepaid VAT and other taxes | 66,871 |  |  | 77,388 |  |
| Prepaid expenses | 64,288 |  |  | 62,189 |  |
| Product demonstration equipment, net | 40,638 |  |  | 29,362 |  |
| Capitalized contract acquisition costs | 23,950 |  |  | 21,753 |  |
| Other non-trade receivables | 11,951 |  |  | 18,408 |  |
| Derivative assets | 6,885 |  |  | 14,935 |  |
| Deferred deployment expense | 673 |  |  | 264 |  |
|  | $ | 332,259 |  |  | $ | 325,654 |  |

[0000936395-22-000029:notes:84]
Depreciation of product demonstration equipment was $2.4 million during the first three months of fiscal 2022 and $2.6 million during the first three months of fiscal 2021.

[0000936395-22-000029:notes:85]
[same as prior period, unchanged from 0000936395-21-000040:notes:85]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-22-000029:notes:86]
INTANGIBLE ASSETSAs of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-22-000029:notes:87]
|  | January 29, 2022 |  | October 30, 2021 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 428,027 |  |  | $ | (367,304) |  |  | $ | 60,723 |  |  | $ | 395,726 |  |  | $ | (359,828) |  |  | $ | 35,898 |  |
| Patents and licenses | 7,815 |  |  | (3,544) |  |  | 4,271 |  |  | 7,815 |  |  | (3,321) |  |  | 4,494 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 390,840 |  |  | (354,808) |  |  | 36,032 |  |  | 375,329 |  |  | (350,407) |  |  | 24,922 |  |
| Total intangible assets | $ | 826,682 |  |  | $ | (725,656) |  |  | $ | 101,026 |  |  | $ | 778,870 |  |  | $ | (713,556) |  |  | $ | 65,314 |  |

[0000936395-22-000029:notes:88]
The aggregate amortization expense of intangible assets was $12.2 million during the first three months of fiscal 2022 and $9.6 million during the first three months of fiscal 2021. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-22-000029:notes:89]
| Fiscal Year | Amount |  |
| 2022 | $ | 32,026 |  |  |
| 2023 | 29,444 |  |  |
| 2024 | 18,493 |  |  |
| 2025 | 13,287 |  |  |
| 2026 | 7,067 |  |  |
| Thereafter | 709 |  |  |
|  | $ | 101,026 |  |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-22-000029:notes:90]
[same as prior period, unchanged from 0000936395-21-000040:notes:86]

[0000936395-22-000029:notes:91]
|  | January 29,2022 |  | October 30,2021 |
| Compensation, payroll related tax and benefits (1) | $ | 106,365 |  |  | $ | 201,119 |  |
| Warranty | 46,173 |  |  | 48,019 |  |
| Vacation | 30,099 |  |  | 31,200 |  |
| Income taxes payable | 8,820 |  |  | 13,577 |  |
| Finance lease liabilities | 3,711 |  |  | 3,620 |  |
| Interest payable | 1,067 |  |  | 598 |  |
| Other | 103,173 |  |  | 111,152 |  |
|  | $ | 299,408 |  |  | $ | 409,285 |  |

[0000936395-22-000029:notes:92]
(1) Reduction is primarily due to the timing of bonus payments to employees under Ciena’s annual cash incentive compensation plan.

[0000936395-22-000029:notes:93]
[same as prior period, unchanged from 0000936395-21-000040:notes:88]

[0000936395-22-000029:notes:94]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Three Months Ended January 30, 2021 |  | $ | 49,868 |  |  |  |  | 3,239 |  |  | (4,923) |  |  | $ | 48,184 |  |
| Three Months Ended January 29, 2022 |  | $ | 48,019 |  |  |  |  | 2,817 |  |  | (4,663) |  |  | $ | 46,173 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-22-000029:notes:95]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-22-000029:notes:96]
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-22-000029:notes:97]
As of January 29, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability principally related to research and development activities. The notional amount of these contracts was approximately $260.4 million and $288.6 million as of January 29, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-22-000029:notes:98]
As of January 29, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $240.0 million and $296.1 million as of January 29, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-22-000029:notes:99]
[same as prior period, unchanged from 0000936395-21-000040:notes:93]

[0000936395-22-000029:notes:100]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 15 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 15 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of January 29, 2022 and October 30, 2021.

[0000936395-22-000029:notes:101]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the 2025 Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-22-000029:notes:102]
[same as prior period, unchanged from 0000936395-21-000040:notes:96]


## us-gaap:DebtDisclosureTextBlock

[0000936395-22-000029:notes:103]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-22-000029:notes:104]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-22-000029:notes:105]
The net carrying value of Ciena’s 2025 Term Loan was comprised of the following for the periods indicated (in thousands):

[0000936395-22-000029:notes:106]
|  |  | January 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 680,873 |  |  | $ | (1,170) |  |  | $ | (2,188) |  |  | $ | 677,515 |  |  | $ | 677,285 |  |

[0000936395-22-000029:notes:107]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $2.2 million as of January 29, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-22-000029:notes:108]
As of January 29, 2022, the estimated fair value of the 2025 Term Loan was $681.7 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-22-000029:notes:109]
2030 Notes

[0000936395-22-000029:notes:110]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-22-000029:notes:111]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”).

[0000936395-22-000029:notes:112]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $395.5 million. Ciena intends to use the net proceeds from the Offering for general corporate purposes.

[0000936395-22-000029:notes:113]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

[0000936395-22-000029:notes:114]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

[0000936395-22-000029:notes:115]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

[0000936395-22-000029:notes:116]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

[0000936395-22-000029:notes:117]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

[0000936395-22-000029:notes:118]
The net carrying value of the 2030 Notes was comprised of the following for the periods indicated (in thousands):

[0000936395-22-000029:notes:119]
|  |  | January 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (5,322) |  |  | $ | 394,678 |  |  |  |

[0000936395-22-000029:notes:120]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Notes totaled $5.3 million as of January 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was minimal during the first three months of fiscal 2022.

[0000936395-22-000029:notes:121]
As of January 29, 2022, the estimated fair value of the 2030 Notes was $395.5 million. Ciena’s 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-22-000029:notes:122]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 29, 2022 (in thousands):

[0000936395-22-000029:notes:123]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (774) |  |  | (4,477) |  |  | 1,364 |  |  | (13,157) |  |  | (17,044) |  |
| Amounts reclassified from AOCI | — |  |  | (862) |  |  | 2,562 |  |  | — |  |  | 1,700 |  |
| Balance at January 29, 2022 | $ | (938) |  |  | $ | 877 |  |  | $ | (8,253) |  |  | $ | (6,591) |  |  | $ | (14,905) |  |

[0000936395-22-000029:notes:124]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 30, 2021 (in thousands):

[0000936395-22-000029:notes:125]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive loss before reclassifications | (49) |  |  | 7,848 |  |  | (659) |  |  | 15,861 |  |  | 23,001 |  |
| Amounts reclassified from AOCI | — |  |  | (1,231) |  |  | 2,041 |  |  | — |  |  | 810 |  |
| Balance at January 30, 2021 | $ | (4) |  |  | $ | 6,398 |  |  | $ | (20,153) |  |  | $ | 2,212 |  |  | $ | (11,547) |  |

[0000936395-22-000029:notes:126]
All amounts reclassified from AOCI, related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges, impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI, related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges, impacted interest and other income (loss), net, on the Condensed Consolidated Statements of Operations.


## us-gaap:EarningsPerShareTextBlock

[0000936395-22-000029:notes:127]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-22-000029:notes:128]
The following table presents the calculation of basic and diluted EPS (in thousands, except per share amounts):

[0000936395-22-000029:notes:129]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Net income | $ | 45,823 |  |  | $ | 55,348 |  |  |  |  |  |
| Basic weighted average shares outstanding | 154,151 |  |  | 155,174 |  |  |  |  |  |
| Effect of dilutive potential common shares | 1,656 |  |  | 1,409 |  |  |  |  |  |
| Diluted weighted average shares | 155,807 |  |  | 156,583 |  |  |  |  |  |
| Basic EPS | $ | 0.30 |  |  | $ | 0.36 |  |  |  |  |  |
| Diluted EPS | $ | 0.29 |  |  | $ | 0.35 |  |  |  |  |  |
| Antidilutive employee share-based awards, excluded | 761 |  |  | 135 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-22-000029:notes:130]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program and Accelerated Share Repurchase Agreement

[0000936395-22-000029:notes:131]
On December 9, 2021, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received an initial share delivery of approximately 2.7 million shares of its common stock from Goldman, representing approximately 80% of the expected share repurchases under the ASR Agreement, based on the closing price of Ciena’s common stock of $74.12 on December 13, 2021. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital. Repurchased common stock is reflected as a reduction of stockholders’ equity. The repurchases contemplated by the ASR Agreement were completed on February 15, 2022. See Note 22 below for information relating to the settlement of the ASR Agreement following the end of Ciena’s first quarter of fiscal 2022.

[0000936395-22-000029:notes:132]
[same as prior period, unchanged from 0000936395-21-000040:notes:128]

[0000936395-22-000029:notes:133]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $25.2 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2022 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-22-000029:notes:134]
SHARE-BASED COMPENSATION EXPENSE
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-22-000029:notes:135]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Products | $ | 900 |  |  | $ | 953 |  |  |  |  |  |
| Services | 1,584 |  |  | 1,205 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 2,484 |  |  | 2,158 |  |  |  |  |  |
| Research and development | 6,830 |  |  | 4,794 |  |  |  |  |  |
| Selling and marketing | 7,060 |  |  | 5,816 |  |  |  |  |  |
| General and administrative | 7,912 |  |  | 6,358 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 21,802 |  |  | 16,968 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net | 11 |  |  | (162) |  |  |  |  |  |
| Total share-based compensation expense | $ | 24,297 |  |  | $ | 18,964 |  |  |  |  |  |

[0000936395-22-000029:notes:136]
As of January 29, 2022, total unrecognized share-based compensation expense was approximately $237.6 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.74 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-22-000029:notes:137]
[same as prior period, unchanged from 0000936395-21-000040:notes:134]

[0000936395-22-000029:notes:138]
[same as prior period, unchanged from 0000936395-21-000040:notes:135]

[0000936395-22-000029:notes:139]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 29, 2022, equipment, building, furniture and fixtures, net, totaled $276.1 million, and operating ROU assets totaled $43.3 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of January 29, 2022, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-22-000029:notes:140]
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 51,317 |  |  | $ | — |  |  | $ | 49,709 |  |  | $ | — |  |  | $ | 101,026 |  |
| Goodwill | $ | 77,582 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 322,822 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 55,464 |  |  | $ | 55,464 |  |

[0000936395-22-000029:notes:141]
[same as prior period, unchanged from 0000936395-21-000040:notes:138]

[0000936395-22-000029:notes:142]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income (loss), net; interest expense; and provision for income taxes.

[0000936395-22-000029:notes:143]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to net income for the periods indicated (in thousands):

[0000936395-22-000029:notes:144]
|  | Quarter Ended |  |  |
|  | January 29, |  | January 30, |  |  |  |  |
|  | 2022 |  | 2021 |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 134,125 |  |  | $ | 156,431 |  |  |  |  |  |
| Platform Software and Services | 49,496 |  |  | 27,660 |  |  |  |  |  |
| Blue Planet Automation Software and Services | (1,034) |  |  | (2,434) |  |  |  |  |  |
| Global Services | 53,191 |  |  | 43,493 |  |  |  |  |  |
| Total segment profit | 235,778 |  |  | 225,150 |  |  |  |  |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 118,881 |  |  | 97,278 |  |  |  |  |  |
| General and administrative | 44,498 |  |  | 39,993 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 3,409 |  |  | 5,867 |  |  |  |  |  |
| Amortization of intangible assets | 8,918 |  |  | 5,910 |  |  |  |  |  |
| Acquisition and integration costs | 68 |  |  | 307 |  |  |  |  |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (4,962) |  |  | (8,481) |  |  |  |  |  |
| Less: Provision for income taxes | 9,219 |  |  | 11,966 |  |  |  |  |  |
| Net income | $ | 45,823 |  |  | $ | 55,348 |  |  |  |  |  |

[0000936395-22-000029:notes:145]
[same as prior period, unchanged from 0000936395-21-000040:notes:143]

[0000936395-22-000029:notes:146]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-22-000029:notes:147]
|  | January 29,2022 |  | October 30,2021 |
| Canada | $ | 233,644 |  |  | $ | 240,968 |  |
| United States | 47,504 |  |  | 50,744 |  |
| Other International | 38,312 |  |  | 37,541 |  |
| Total | $ | 319,460 |  |  | $ | 329,253 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-22-000029:notes:148]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

[0000936395-22-000029:notes:149]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.1 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. As of January 29, 2022, Ciena has recorded CAD$54.8 million (approximately $42.9 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.9 million ($3.0 million) was recorded in the first three months of fiscal 2022. As of January 29, 2022, amounts receivable from this grant were CAD$2.9 million ($2.2 million) included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

[0000936395-22-000029:notes:150]
Tax Contingencies

[0000936395-22-000029:notes:151]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-22-000029:notes:152]
Litigation

[0000936395-22-000029:notes:153]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-22-000029:notes:154]
SUBSEQUENT EVENTSStock Repurchase Program and Accelerated Share Repurchase AgreementOn February 15, 2022, Ciena received delivery of the remaining 884,531 shares of common stock repurchased under the ASR Agreement, for a total delivery of approximately 3.6 million shares, calculated based on the average of the daily volume-weighted average prices of Ciena’s common stock of $69.78 for the period December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement.
