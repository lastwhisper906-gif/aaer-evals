# CIEN 8-K — 0001628280-25-056425 filed 2025-12-11

## item codes, every 8-K on or before 2025-12-12

- 2025-12-11 0001628280-25-056425 — 2.02, 9.01
- 2025-12-04 0001628280-25-055133 — 5.02
- 2025-10-07 0001628280-25-044494 — 8.01
- 2025-09-22 0001628280-25-042266 — 8.01, 9.01
- 2025-09-04 0000936395-25-000037 — 2.02, 9.01
- 2025-06-18 0000936395-25-000029 — 5.02, 7.01, 9.01
- 2025-06-05 0000936395-25-000023 — 2.02, 9.01
- 2025-04-01 0000936395-25-000015 — 5.07
- 2025-03-11 0000936395-25-000005 — 2.02, 9.01
- 2025-01-21 0001193125-25-009588 — 1.01, 2.03, 9.01
- 2024-12-12 0000936395-24-000037 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2024-10-02 0000936395-24-000035 — 8.01, 9.01
- 2024-09-04 0000936395-24-000030 — 2.02, 5.02, 9.01
- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2025-12-12

- none on or before 2025-12-12

## item 2.02 — earnings release, exhibit 99.1

[0001628280-25-056425:8k_2_02:1]
EX-99.1
2
ex9912025q4earningspressre.htm
EX-99.1

[0001628280-25-056425:8k_2_02:2]
Document

[0001628280-25-056425:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0001628280-25-056425:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2025 and Year-End Financial Results

[0001628280-25-056425:8k_2_02:5]
Summary

[0001628280-25-056425:8k_2_02:6]
•Fiscal fourth quarter 2025 revenue was $1.35 billion, up 20% year-over-year

[0001628280-25-056425:8k_2_02:7]
•Fiscal year 2025 revenue was $4.77 billion, up 19% year-over-year

[0001628280-25-056425:8k_2_02:8]
•Providing guidance for revenue in the range of $1.35 billion to $1.43 billion for the first fiscal quarter of 2026 and $5.7 billion to $6.1 billion for fiscal year 2026

[0001628280-25-056425:8k_2_02:9]
HANOVER, Md. - December 11, 2025 - Ciena® Corporation (NYSE: CIEN) today announced financial results for its fiscal fourth quarter and year ended November 1, 2025.

[0001628280-25-056425:8k_2_02:10]
"Our record fiscal fourth quarter and full-year performance reinforces our position as the global leader in high-speed connectivity with an expanding role in the AI ecosystem," said Gary Smith, president and CEO, Ciena. "Looking ahead, we are confident in our growth trajectory over the coming years, driven by durable demand from our cloud and service provider customers and a growing set of opportunities inside and around the data center."

[0001628280-25-056425:8k_2_02:11]
Performance Summary for Fiscal Fourth Quarter and Year Ended November 1, 2025

[0001628280-25-056425:8k_2_02:12]
Revenue:

[0001628280-25-056425:8k_2_02:13]
•$1.35 billion in the fiscal fourth quarter 2025, compared to $1.12 billion in the fiscal fourth quarter 2024

[0001628280-25-056425:8k_2_02:14]
•$4.77 billion in fiscal year 2025, compared to $4.01 billion in the fiscal year 2024

[0001628280-25-056425:8k_2_02:15]
Net Income per diluted share:

[0001628280-25-056425:8k_2_02:16]
•$0.13 GAAP and $0.91 adjusted (non-GAAP) for the fiscal fourth quarter 2025, compared to $0.25 and $0.54 for fiscal fourth quarter 2024, respectively

[0001628280-25-056425:8k_2_02:17]
•$0.85 GAAP and $2.64 adjusted (non-GAAP) for fiscal year 2025, compared to $0.58 and $1.82 for fiscal year 2024, respectively

[0001628280-25-056425:8k_2_02:18]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0001628280-25-056425:8k_2_02:19]
|  |  | GAAP Results (unaudited) |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Quarter Ended |  | Period |
|  |  | November 1, |  | November 2, |  | Change |  | November 1, |  | November 2, |  | Change |
|  |  | 2025 |  | 2024 |  | Y-T-Y* |  | 2025 |  | 2024 |  | Y-T-Y* |
| Revenue |  | $ | 1,352.0 |  |  | $ | 1,124.1 |  |  | 20.3 | % |  | $ | 1,352.0 |  |  | $ | 1,124.1 |  |  | 20.3 | % |
| Gross margin |  | 42.7 | % |  | 40.9 | % |  | 1.8 | % |  | 43.4 | % |  | 41.6 | % |  | 1.8 | % |
| Operating expense |  | $ | 566.7 |  |  | $ | 400.8 |  |  | 41.4 | % |  | $ | 408.7 |  |  | $ | 354.9 |  |  | 15.2 | % |
| Operating margin |  | 0.8 | % |  | 5.3 | % |  | (4.5) | % |  | 13.2 | % |  | 10.0 | % |  | 3.2 | % |
| EBITDA |  | $ | 47.8 |  |  | $ | 93.0 |  |  | (48.6) | % |  | $ | 205.5 |  |  | $ | 136.7 |  |  | 50.3 | % |

[0001628280-25-056425:8k_2_02:20]
|  |  | GAAP Results (unaudited) |  | Non-GAAP Results (unaudited) |
|  |  | Year Ended |  | Period |  | Year Ended |  | Period |
|  |  | November 1, |  | November 2, |  | Change |  | November 1, |  | November 2, |  | Change |
|  |  | 2025 |  | 2024 |  | Y-T-Y* |  | 2025 |  | 2024 |  | Y-T-Y* |
| Revenue |  | $ | 4,769.5 |  |  | $ | 4,014.9 |  |  | 18.8 | % |  | $ | 4,769.5 |  |  | $ | 4,014.9 |  |  | 18.8 | % |
| Gross margin |  | 42.0 | % |  | 42.8 | % |  | (0.8) | % |  | 42.7 | % |  | 43.6 | % |  | (0.9) | % |
| Operating expense |  | $ | 1,807.4 |  |  | $ | 1,553.0 |  |  | 16.4 | % |  | $ | 1,505.8 |  |  | $ | 1,361.7 |  |  | 10.6 | % |
| Operating margin |  | 4.1 | % |  | 4.1 | % |  | — | % |  | 11.2 | % |  | 9.7 | % |  | 1.5 | % |
| EBITDA |  | $ | 337.9 |  |  | $ | 300.1 |  |  | 12.6 | % |  | $ | 636.7 |  |  | $ | 481.0 |  |  | 32.4 | % |

[0001628280-25-056425:8k_2_02:21]
*  Denotes % change, or in the case of margin, absolute change

[0001628280-25-056425:8k_2_02:22]
Business Outlook

[0001628280-25-056425:8k_2_02:23]
"Our results reflect Ciena’s market momentum within a strong demand environment and our commitment to financial discipline, delivering strong top and bottom line performance that exceeded our guidance for the fourth quarter,” said Marc Graff, CFO of Ciena. “With our growing operating leverage and strong cash generation and balance sheet, we are well-positioned to deliver value for our customers and shareholders in 2026."

[0001628280-25-056425:8k_2_02:24]
Ciena expects fiscal year 2026 to include:

[0001628280-25-056425:8k_2_02:25]
• Revenue in the range of $5.7 billion to $6.1 billion

[0001628280-25-056425:8k_2_02:26]
• Adjusted (non-GAAP) gross margin of 43% plus or minus 1%

[0001628280-25-056425:8k_2_02:27]
• Adjusted (non-GAAP) operating expense of approximately $1.52 billion

[0001628280-25-056425:8k_2_02:28]
• Adjusted (non-GAAP) operating margin of 17% plus or minus 1%

[0001628280-25-056425:8k_2_02:29]
Ciena expects fiscal first quarter 2026 to include:

[0001628280-25-056425:8k_2_02:30]
• Revenue in the range of $1.35 billion to $1.43 billion

[0001628280-25-056425:8k_2_02:31]
• Adjusted (non-GAAP) gross margin between 43% to 44%

[0001628280-25-056425:8k_2_02:32]
• Adjusted (non-GAAP) operating expense of approximately $380 million

[0001628280-25-056425:8k_2_02:33]
• Adjusted (non-GAAP) operating margin between 15.5% and 16.5%

[0001628280-25-056425:8k_2_02:34]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the “Economic considerations and assumptions” in our accompanying

[0001628280-25-056425:8k_2_02:35]
Earnings Presentation and each of the "Forward-Looking Statements" and "Reconciliation of Adjusted (Non- GAAP) Measurements" found in the Notes to Investors below.

[0001628280-25-056425:8k_2_02:36]
Financial Highlights

[0001628280-25-056425:8k_2_02:37]
•Three customers represented 10%-plus of revenue for a total of 43.6% of revenue for the fiscal fourth quarter 2025.

[0001628280-25-056425:8k_2_02:38]
•Two customers represented 10%-plus of revenue for a total of 28.4% of revenue for the fiscal year 2025.

[0001628280-25-056425:8k_2_02:39]
•Average days' sales outstanding (DSOs) were 77 and 88 for the fiscal fourth quarter and the fiscal year 2025, respectively.

[0001628280-25-056425:8k_2_02:40]
•Product inventory turns were 3.1 and 2.7 for the fiscal fourth quarter and the fiscal year 2025, respectively.

[0001628280-25-056425:8k_2_02:41]
•Repurchased approximately 0.7 million and 4.0 million shares of common stock for an aggregate price of $84.5 million and $329.7 million during fiscal fourth quarter and fiscal year 2025, respectively.

[0001628280-25-056425:8k_2_02:42]
Financial Performance by Segment

[0001628280-25-056425:8k_2_02:43]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | November 1, 2025 |  | November 2, 2024 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 929.2 |  |  | 68.7 |  |  | $ | 779.6 |  |  | 69.4 |  |
| Routing and Switching |  | 118.4 |  |  | 8.8 |  |  | 79.4 |  |  | 7.0 |  |
| Total Networking Platforms |  | 1,047.6 |  |  | 77.5 |  |  | 859.0 |  |  | 76.4 |  |
| Platform Software and Services |  | 93.3 |  |  | 6.9 |  |  | 99.6 |  |  | 8.9 |  |
| Blue Planet Automation Software and Services |  | 33.8 |  |  | 2.5 |  |  | 23.5 |  |  | 2.1 |  |
| Global Services 1 |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning |  | 82.5 |  |  | 6.1 |  |  | 77.2 |  |  | 6.9 |  |
| Implementation |  | 74.3 |  |  | 5.5 |  |  | 51.4 |  |  | 4.5 |  |
| Advisory and Enablement |  | 20.5 |  |  | 1.5 |  |  | 13.4 |  |  | 1.2 |  |
| Total Global Services |  | 177.3 |  |  | 13.1 |  |  | 142.0 |  |  | 12.6 |  |
| Total |  | $ | 1,352.0 |  |  | 100.0 |  |  | $ | 1,124.1 |  |  | 100.0 |  |

[0001628280-25-056425:8k_2_02:44]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | November 1, 2025 |  | November 2, 2024 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 3,246.3 |  |  | 68.1 |  |  | $ | 2,642.6 |  |  | 65.8 |  |
| Routing and Switching |  | 430.1 |  |  | 9.0 |  |  | 399.5 |  |  | 10.0 |  |
| Total Networking Platforms |  | 3,676.4 |  |  | 77.1 |  |  | 3,042.1 |  |  | 75.8 |  |
| Platform Software and Services |  | 363.8 |  |  | 7.6 |  |  | 358.0 |  |  | 8.9 |  |
| Blue Planet Automation Software and Services |  | 115.5 |  |  | 2.4 |  |  | 77.6 |  |  | 2.0 |  |
| Global Services 1 |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning |  | 317.2 |  |  | 6.7 |  |  | 303.1 |  |  | 7.5 |  |
| Implementation |  | 246.1 |  |  | 5.2 |  |  | 184.3 |  |  | 4.6 |  |
| Advisory and Enablement |  | 50.5 |  |  | 1.0 |  |  | 49.8 |  |  | 1.2 |  |
| Total Global Services |  | 613.8 |  |  | 12.9 |  |  | 537.2 |  |  | 13.3 |  |
| Total |  | $ | 4,769.5 |  |  | 100.0 |  |  | $ | 4,014.9 |  |  | 100.0 |  |

[0001628280-25-056425:8k_2_02:45]
**  Denotes % of total revenue

[0001628280-25-056425:8k_2_02:46]
1 Effective as of the fourth quarter of fiscal 2025, Ciena renamed (i) its "Maintenance Support and Training" product line to "Maintenance, Support, and Learning", (ii) its "Installation and Deployment" product line to "Implementation", and (iii) its "Consulting and Network Design" product line to "Advisory and Enablement". These changes, affecting only the presentation of such information, were made on a prospective basis and do not impact comparability of previous financial results. However, the references to the prior reported product lines have been changed herein to the new names above.

[0001628280-25-056425:8k_2_02:47]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2025 Results

[0001628280-25-056425:8k_2_02:48]
Today, Thursday, December 11, 2025, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter 2025 results.

[0001628280-25-056425:8k_2_02:49]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0001628280-25-056425:8k_2_02:50]
Notes to Investors

[0001628280-25-056425:8k_2_02:51]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future

[0001628280-25-056425:8k_2_02:52]
and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include the statements in the "Summary" and "Business Outlook" sections of this press release and "Our record fiscal fourth quarter and full-year performance underscores our focused execution and solidifies our position as a global leader in high-speed connectivity with an expanding role in the evolving AI ecosystem. Looking ahead, we are increasingly confident in our growth trajectory over the coming years, driven by accelerating, durable demand from our cloud and service provider customers and a growing set of opportunities inside and around the data center." and “With our growing operating leverage, and strong cash generation and balance sheet, we are well-positioned to deliver value for our customers and shareholders in 2026."

[0001628280-25-056425:8k_2_02:53]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our business and that of our customers, including their spending; the development and use of artificial intelligence and its impact on overall networking technology spending; our ability to execute our business and growth strategies; supply chain constraints or disruptions including increased costs and lead times; the introduction of new technologies by us or our competitors; the timing and size of customer orders, their delivery dates and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, and public health emergencies, epidemics, or pandemics; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena's Quarterly Report on Form 10-Q filed with the SEC on September 4, 2025 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0001628280-25-056425:8k_2_02:54]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0001628280-25-056425:8k_2_02:55]
With respect to Ciena’s expectations under “Business Outlook" above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin and adjusted (non-GAAP) operating expense guidance measures to the corresponding gross profit and gross profit percentage, and operating expense GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty. For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0001628280-25-056425:8k_2_02:56]
5

[0001628280-25-056425:8k_2_02:57]
About Ciena. Ciena (NYSE: CIEN) is the global leader in high-speed connectivity. We build the world’s most adaptive networks to support exponential growth in bandwidth demand. By harnessing the power of our networking systems, interconnects, automation software, and services, Ciena revolutionizes data transmission and network management. With unparalleled expertise and innovation, we empower our customers, partners, and communities to thrive in the AI era. For updates on Ciena, follow us on LinkedIn, X, the Ciena Insights blog, or visit www.ciena.com.

[0001628280-25-056425:8k_2_02:58]
6

[0001628280-25-056425:8k_2_02:59]
CIENA CORPORATION

[0001628280-25-056425:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0001628280-25-056425:8k_2_02:61]
(in thousands, except per share data)

[0001628280-25-056425:8k_2_02:62]
(unaudited)

[0001628280-25-056425:8k_2_02:63]
|  | Quarter Ended |  | Year Ended |
|  | November 1, |  | November 2, |  | November 1, |  | November 2, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 1,092,451 |  |  | $ | 892,425 |  |  | $ | 3,822,618 |  |  | $ | 3,159,021 |  |
| Services | 259,533 |  |  | 231,687 |  |  | 946,889 |  |  | 855,934 |  |
| Total revenue | 1,351,984 |  |  | 1,124,112 |  |  | 4,769,507 |  |  | 4,014,955 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 630,150 |  |  | 545,580 |  |  | 2,250,966 |  |  | 1,861,317 |  |
| Services | 144,655 |  |  | 118,510 |  |  | 513,624 |  |  | 434,048 |  |
| Total cost of goods sold | 774,805 |  |  | 664,090 |  |  | 2,764,590 |  |  | 2,295,365 |  |
| Gross profit | 577,179 |  |  | 460,022 |  |  | 2,004,917 |  |  | 1,719,590 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 228,900 |  |  | 195,960 |  |  | 848,329 |  |  | 767,497 |  |
| Selling and marketing | 156,420 |  |  | 136,919 |  |  | 581,331 |  |  | 510,668 |  |
| General and administrative | 67,257 |  |  | 58,143 |  |  | 238,707 |  |  | 220,647 |  |
| Significant asset impairments and restructuring costs | 106,851 |  |  | 2,605 |  |  | 112,113 |  |  | 24,592 |  |
| Amortization of intangible assets | 6,112 |  |  | 7,185 |  |  | 25,758 |  |  | 29,569 |  |
| Acquisition and integration costs | 1,148 |  |  | — |  |  | 1,148 |  |  | — |  |
| Total operating expenses | 566,688 |  |  | 400,812 |  |  | 1,807,386 |  |  | 1,552,973 |  |
| Income from operations | 10,491 |  |  | 59,210 |  |  | 197,531 |  |  | 166,617 |  |
| Interest and other income, net | 14,349 |  |  | 13,801 |  |  | 48,888 |  |  | 50,261 |  |
| Interest expense | (21,982) |  |  | (24,990) |  |  | (89,403) |  |  | (97,028) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (729) |  |  | — |  |
| Income before income taxes | 2,858 |  |  | 48,021 |  |  | 156,287 |  |  | 119,850 |  |
| Provision (benefit) for income taxes | (16,631) |  |  | 10,993 |  |  | 32,949 |  |  | 35,894 |  |
| Net income | $ | 19,489 |  |  | $ | 37,028 |  |  | $ | 123,338 |  |  | $ | 83,956 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.14 |  |  | $ | 0.26 |  |  | $ | 0.87 |  |  | $ | 0.58 |  |
| Diluted net income per potential common share | $ | 0.13 |  |  | $ | 0.25 |  |  | $ | 0.85 |  |  | $ | 0.58 |  |
| Weighted average basic common shares outstanding | 141,527 |  |  | 144,240 |  |  | 142,221 |  |  | 144,715 |  |
| Weighted average dilutive potential common shares outstanding1 | 145,470 |  |  | 146,487 |  |  | 145,248 |  |  | 145,964 |  |

[0001628280-25-056425:8k_2_02:64]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 3.9 million and 3.0 million for the fourth quarter and year ended fiscal 2025, respectively; and (ii) 2.2 million and 1.2 million for the fourth quarter and year ended fiscal 2024, respectively.

[0001628280-25-056425:8k_2_02:65]
CIENA CORPORATION

[0001628280-25-056425:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001628280-25-056425:8k_2_02:67]
(in thousands, except share data)

[0001628280-25-056425:8k_2_02:68]
(unaudited)

[0001628280-25-056425:8k_2_02:69]
|  | November 1,2025 |  | November 2,2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,091,952 |  |  | $ | 934,863 |  |
| Short-term investments | 216,148 |  |  | 316,343 |  |
| Accounts receivable, net | 975,856 |  |  | 908,597 |  |
| Inventories, net | 826,235 |  |  | 820,430 |  |
| Prepaid expenses and other | 455,316 |  |  | 564,183 |  |
| Total current assets | 3,565,507 |  |  | 3,544,416 |  |
| Long-term investments | 57,142 |  |  | 80,920 |  |
| Equipment, building, furniture and fixtures, net | 386,779 |  |  | 337,722 |  |
| Operating lease right-of-use assets | 38,613 |  |  | 27,417 |  |
| Goodwill | 521,204 |  |  | 444,707 |  |
| Other intangible assets, net | 224,210 |  |  | 165,020 |  |
| Deferred tax asset, net | 884,889 |  |  | 886,441 |  |
| Other long-term assets | 186,323 |  |  | 154,694 |  |
| Total assets | $ | 5,864,667 |  |  | $ | 5,641,337 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 542,841 |  |  | $ | 423,401 |  |
| Accrued liabilities and other short-term obligations | 531,081 |  |  | 393,905 |  |
| Deferred revenue | 208,936 |  |  | 156,379 |  |
| Operating lease liabilities | 13,956 |  |  | 14,455 |  |
| Current portion of long-term debt | 11,580 |  |  | 11,700 |  |
| Total current liabilities | 1,308,394 |  |  | 999,840 |  |
| Long-term deferred revenue | 94,850 |  |  | 81,240 |  |
| Other long-term obligations | 175,426 |  |  | 185,938 |  |
| Long-term operating lease liabilities | 32,516 |  |  | 25,107 |  |
| Long-term debt, net | 1,524,158 |  |  | 1,533,074 |  |
| Total liabilities | 3,135,344 |  |  | 2,825,199 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 141,016,300 and 142,656,116 shares issued and outstanding | 1,410 |  |  | 1,427 |  |
| Additional paid-in capital | 5,953,057 |  |  | 6,154,869 |  |
| Accumulated other comprehensive loss | (55,035) |  |  | (46,711) |  |
| Accumulated deficit | (3,170,109) |  |  | (3,293,447) |  |
| Total stockholders’ equity | 2,729,323 |  |  | 2,816,138 |  |
| Total liabilities and stockholders’ equity | $ | 5,864,667 |  |  | $ | 5,641,337 |  |

[0001628280-25-056425:8k_2_02:70]
8

[0001628280-25-056425:8k_2_02:71]
CIENA CORPORATION

[0001628280-25-056425:8k_2_02:72]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001628280-25-056425:8k_2_02:73]
(in thousands)

[0001628280-25-056425:8k_2_02:74]
(unaudited)

[0001628280-25-056425:8k_2_02:75]
|  | Year Ended |
|  | November 1, |  | November 2, |
|  | 2025 |  | 2024 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 123,338 |  |  | $ | 83,956 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 104,133 |  |  | 92,846 |  |
| Abandonment of acquired in-process research and development | 89,100 |  |  | — |  |
| Share-based compensation expense | 184,525 |  |  | 156,404 |  |
| Amortization of intangible assets | 36,205 |  |  | 40,624 |  |
| Deferred taxes | (23,173) |  |  | (76,810) |  |
| Provision for inventory excess and obsolescence | 48,424 |  |  | 77,341 |  |
| Provision for warranty | 24,442 |  |  | 25,643 |  |
| Other | (736) |  |  | 11,768 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (98,743) |  |  | 80,313 |  |
| Inventories | (53,602) |  |  | 153,021 |  |
| Prepaid expenses and other | 86,204 |  |  | (198,910) |  |
| Operating lease right-of-use assets | 11,613 |  |  | 11,837 |  |
| Accounts payable, accruals and other obligations | 226,486 |  |  | 64,255 |  |
| Deferred revenue | 63,760 |  |  | 9,884 |  |
| Short and long-term operating lease liabilities | (15,883) |  |  | (17,640) |  |
| Net cash provided by operating activities | 806,093 |  |  | 514,532 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, and fixtures | (140,801) |  |  | (136,641) |  |
| Purchases of investments | (214,162) |  |  | (287,536) |  |
| Proceeds from sales and maturities of investments | 348,579 |  |  | 140,836 |  |
| Settlement of foreign currency forward contracts, net | (4,015) |  |  | (1,454) |  |
| Purchase of equity investments | — |  |  | (21,682) |  |
| Acquisition of business, net of cash acquired | (231,100) |  |  | — |  |
| Net cash used in investing activities | (241,499) |  |  | (306,477) |  |
| Cash flows used in financing activities: |  |  |  |
| Proceeds for modification of debt, net | 19,175 |  |  | — |  |
| Cash paid for extinguishment of debt | (19,175) |  |  | — |  |
| Payment of long term debt | (11,580) |  |  | (11,700) |  |
| Payment of debt issuance costs | (12) |  |  | (2,554) |  |
| Payment of finance lease obligations | (4,380) |  |  | (4,029) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (91,315) |  |  | (46,567) |  |
| Repurchases of common stock - repurchase program, net | (334,507) |  |  | (254,502) |  |
| Proceeds from issuance of common stock | 35,876 |  |  | 34,291 |  |
| Net cash used in financing activities | (405,918) |  |  | (285,061) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (1,505) |  |  | 1,246 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 157,171 |  |  | (75,760) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 935,026 |  |  | 1,010,786 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,092,197 |  |  | $ | 935,026 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 85,217 |  |  | $ | 92,515 |  |
| Cash paid during the period for income taxes, net | $ | 113,608 |  |  | $ | 54,956 |  |
| Operating lease payments | $ | 17,840 |  |  | $ | 19,452 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 17,449 |  |  | $ | 14,682 |  |
| Repurchase of common stock in accrued liabilities from repurchase program, net | $ | 2,579 |  |  | $ | 6,172 |  |
| Operating right-of-use assets subject to lease liability | $ | 23,586 |  |  | $ | 6,912 |  |

[0001628280-25-056425:8k_2_02:76]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | November 1, |  | November 2, |  | November 1, |  | November 2, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 577,179 |  |  | $ | 460,022 |  |  | $ | 2,004,917 |  |  | $ | 1,719,590 |  |
| Share-based compensation-products |  | 1,964 |  |  | 1,736 |  |  | 7,774 |  |  | 6,474 |  |
| Share-based compensation-services |  | 3,857 |  |  | 3,257 |  |  | 15,184 |  |  | 12,743 |  |
| Amortization of intangible assets |  | 3,750 |  |  | 2,764 |  |  | 10,447 |  |  | 11,055 |  |
| Total adjustments related to gross profit |  | 9,571 |  |  | 7,757 |  |  | 33,405 |  |  | 30,272 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 586,750 |  |  | $ | 467,779 |  |  | $ | 2,038,322 |  |  | $ | 1,749,862 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.4 | % |  | 41.6 | % |  | 42.7 | % |  | 43.6 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 566,688 |  |  | $ | 400,812 |  |  | $ | 1,807,386 |  |  | $ | 1,552,973 |  |
| Share-based compensation-research and development |  | 16,274 |  |  | 14,065 |  |  | 64,281 |  |  | 54,129 |  |
| Share-based compensation-sales and marketing |  | 13,543 |  |  | 11,168 |  |  | 52,066 |  |  | 42,954 |  |
| Share-based compensation-general and administrative |  | 13,248 |  |  | 10,842 |  |  | 45,424 |  |  | 40,053 |  |
| Significant asset impairments and restructuring costs |  | 106,851 |  |  | 2,605 |  |  | 112,113 |  |  | 24,592 |  |
| Amortization of intangible assets |  | 6,112 |  |  | 7,185 |  |  | 25,758 |  |  | 29,569 |  |
| Acquisition and integration costs |  | 1,148 |  |  | — |  |  | 1,148 |  |  | — |  |
| Holdback arrangement |  | 802 |  |  | — |  |  | 802 |  |  | — |  |
| Total adjustments related to operating expense |  | 157,978 |  |  | 45,865 |  |  | 301,592 |  |  | 191,297 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 408,710 |  |  | $ | 354,947 |  |  | $ | 1,505,794 |  |  | $ | 1,361,676 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 10,491 |  |  | $ | 59,210 |  |  | $ | 197,531 |  |  | $ | 166,617 |  |
| Total adjustments related to gross profit |  | 9,571 |  |  | 7,757 |  |  | 33,405 |  |  | 30,272 |  |
| Total adjustments related to operating expense |  | 157,978 |  |  | 45,865 |  |  | 301,592 |  |  | 191,297 |  |
| Total adjustments related to income from operations |  | 167,549 |  |  | 53,622 |  |  | 334,997 |  |  | 221,569 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 178,040 |  |  | $ | 112,832 |  |  | $ | 532,528 |  |  | $ | 388,186 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.2 | % |  | 10.0 | % |  | 11.2 | % |  | 9.7 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 19,489 |  |  | $ | 37,028 |  |  | $ | 123,338 |  |  | $ | 83,956 |  |
| Exclude GAAP provision (benefit) for income taxes |  | (16,631) |  |  | 10,993 |  |  | 32,949 |  |  | 35,894 |  |
| Income before income taxes |  | 2,858 |  |  | 48,021 |  |  | 156,287 |  |  | 119,850 |  |
| Total adjustments related to income from operations |  | 167,549 |  |  | 53,622 |  |  | 334,997 |  |  | 221,569 |  |
| Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | 729 |  |  | — |  |
| Adjusted income before income taxes |  | 170,407 |  |  | 101,643 |  |  | 492,013 |  |  | 341,419 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 37,490 |  |  | 22,361 |  |  | 108,243 |  |  | 75,112 |  |
| Adjusted (non-GAAP) net income |  | $ | 132,917 |  |  | $ | 79,282 |  |  | $ | 383,770 |  |  | $ | 266,307 |  |
| Weighted average basic common shares outstanding |  | 141,527 |  | 144,240 |  | 142,221 |  | 144,715 |
| Weighted average dilutive potential common shares outstanding 1 |  | 145,470 |  | 146,487 |  | 145,248 |  | 145,964 |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.13 |  |  | $ | 0.25 |  |  | $ | 0.85 |  |  | $ | 0.58 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.91 |  |  | $ | 0.54 |  |  | $ | 2.64 |  |  | $ | 1.82 |  |

[0001628280-25-056425:8k_2_02:77]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 3.9 million and 3.0 million for the fourth quarter and year ended fiscal 2025; and (ii) 2.2 million and 1.2 million for the fourth quarter and year ended fiscal 2024.

[0001628280-25-056425:8k_2_02:78]
10

[0001628280-25-056425:8k_2_02:79]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | November 1, |  | November 2, |  | November 1, |  | November 2, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 19,489 |  |  | $ | 37,028 |  |  | $ | 123,338 |  |  | $ | 83,956 |  |
| Add: Interest expense |  | 21,982 |  |  | 24,990 |  |  | 89,403 |  |  | 97,028 |  |
| Less: Interest and other income, net |  | 14,349 |  |  | 13,801 |  |  | 48,888 |  |  | 50,261 |  |
| Add: Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | 729 |  |  | — |  |
| Add: Provision (benefit) for income taxes |  | (16,631) |  |  | 10,993 |  |  | 32,949 |  |  | 35,894 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 27,496 |  |  | 23,849 |  |  | 104,133 |  |  | 92,846 |  |
| Add: Amortization of intangible assets |  | 9,862 |  |  | 9,949 |  |  | 36,205 |  |  | 40,624 |  |
| EBITDA |  | $ | 47,849 |  |  | $ | 93,008 |  |  | $ | 337,869 |  |  | $ | 300,087 |  |
| Add: Share-based compensation expense |  | 48,886 |  |  | 41,068 |  |  | 184,729 |  |  | 156,353 |  |
| Add: Significant asset impairments and restructuring costs |  | 106,851 |  |  | 2,605 |  |  | 112,113 |  |  | 24,592 |  |
| Add: Acquisition and integration costs |  | 1,148 |  |  | — |  |  | 1,148 |  |  | — |  |
| Add: Holdback arrangement |  | 802 |  |  | — |  |  | 802 |  |  | — |  |
| Adjusted EBITDA |  | $ | 205,536 |  |  | $ | 136,681 |  |  | $ | 636,661 |  |  | $ | 481,032 |  |

[0001628280-25-056425:8k_2_02:80]
* * *

[0001628280-25-056425:8k_2_02:81]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0001628280-25-056425:8k_2_02:82]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0001628280-25-056425:8k_2_02:83]
•Significant asset impairments and restructuring costs - non-recurring costs primarily reflecting expenses associated with significant impairment or abandonment of assets and actions Ciena has taken to restructure our business, including reductions in force, facility optimization, and the redesign of business processes. For the fiscal fourth quarter and fiscal year of 2025, this also includes a charge of $89.1 million related to the abandonment of an in-process R&D intangible asset.

[0001628280-25-056425:8k_2_02:84]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0001628280-25-056425:8k_2_02:85]
•Acquisition and integration costs - consists of financial, legal, and accounting advisors and employee-related costs related to our acquisition of Nubis Communications, Inc. during the fourth quarter of fiscal 2025.

[0001628280-25-056425:8k_2_02:86]
•Holdback arrangement - reflects a one-time holdback of a portion of the merger consideration otherwise payable at closing to certain key employee shareholders of Nubis Communications, Inc. who became employees of Ciena, which is treated as contingent compensation for GAAP reporting purposes. These transaction-related amounts are not part of Ciena's standard compensation and benefits.

[0001628280-25-056425:8k_2_02:87]
•Loss on extinguishment and modification of debt - reflects extinguishment and debt modification expenses related to refinancing our term loan during the first quarter of fiscal 2025.

[0001628280-25-056425:8k_2_02:88]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for all fiscal periods of fiscal 2025 and fiscal 2024. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. The Non-GAAP tax provision excludes the impact of a $21.6 million tax benefit in the fourth quarter of fiscal 2025 related to the expiration of the statute of limitations on previously uncertain tax positions.
