# CIEN MD&A — 0001628280-25-056698


## mdna

[0001628280-25-056698:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0001628280-25-056698:mdna:2]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and notes thereto included elsewhere in this annual report.

[0001628280-25-056698:mdna:3]
Overview

[0001628280-25-056698:mdna:4]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, voice, video, data, and AI. Our network solutions are used globally by cloud providers, service providers, and other network operators across multiple industry verticals.

[0001628280-25-056698:mdna:5]
The markets into which we sell are dynamic and characterized by a high rate of change. Networks continue to experience strong demand for increased bandwidth due to traffic growth, which is being driven by a diverse set of services, technologies, and customer needs.

[0001628280-25-056698:mdna:6]
Business Momentum

[0001628280-25-056698:mdna:7]
Our industry has been experiencing unprecedented increases in demand, in particular as a result of expenditures related to AI and other cloud-based applications. As a result, we experienced broad-based business momentum in fiscal 2025, including significant year-over-year order growth in both of our major customer segments, cloud providers and service providers. Our revenue increased by 19% to $4.8 billion in fiscal 2025 as compared to $4.0 billion in fiscal 2024, with orders for our products and services significantly exceeding our revenue. We also significantly grew our backlog, which includes both products and services, to $5.0 billion, as compared to $2.1 billion at the end of fiscal 2024. While we believe much of this backlog growth reflects the increased demand for connectivity to address AI workloads, a portion is related to an industry-wide constrained supply environment. Our ability to scale our operational and manufacturing capacity is critical to our success within this environment. As such, we and many of our suppliers have sought to increase capacity to ensure availability of key inputs for our products and reduce extended lead times.

[0001628280-25-056698:mdna:8]
Within this environment, we have experienced increased customer concentration in both orders and revenue, particularly with cloud providers, with a single cloud provider customer continuing to provide a significant volume of orders and two cloud providers in our top five customers by revenue for fiscal 2025. Our growing sales to cloud providers has resulted in a changing mix in our product sales.

[0001628280-25-056698:mdna:9]
Gross Margin Dynamics

[0001628280-25-056698:mdna:10]
Our gross margin decreased to 42.0% in fiscal 2025, compared to 42.8% in fiscal 2024, primarily due to lower services margin driven by increased incentive compensation and shifts in services mix. In fiscal 2025, our growing sales to cloud providers contributed to a changing product mix and an increase in sales of interconnect products, impacting our product gross margin. Through our continued focus on a range of initiatives to maintain and enhance our gross margin, including cost reductions, manufacturing efficiencies and lower inventory provisions, we were able to offset the impact of this dynamic and our product margin was unchanged from fiscal 2024 to fiscal 2025.

[0001628280-25-056698:mdna:11]
Investment in Technology Innovation

[0001628280-25-056698:mdna:12]
During fiscal 2025, we invested $848.3 million in research and development activities, an increase of 11% compared to fiscal 2024. We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets, which requires considerable investment capacity and expenditures. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we continued to increase the performance of, and enhance the capabilities for our leading WaveLogicTM coherent modem technology, through which we seek to extend our leadership in optical networking, and leverage it to expand our addressable market, including inside and around the data center.

[0001628280-25-056698:mdna:13]
In an effort to expand our addressable market, during the fourth quarter of fiscal 2025, we acquired privately-held Nubis, which specializes in high-performance, ultra-compact, low-power optical and electrical interconnects tailored to support AI workloads. Nubis’s portfolio, including technologies for co-packaged optics, near packaged optics and electrical active copper cables, will complement our existing optical networking portfolio of high-speed interconnects. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on this acquisition.

[0001628280-25-056698:mdna:14]
Operating Expense Management

[0001628280-25-056698:mdna:15]
Our operating expense grew from $1.6 billion in fiscal 2024 to $1.8 billion in fiscal 2025. As a result of our strong financial performance and order levels in fiscal 2025, our expense associated with our incentive compensation programs, including our annual bonus plan and sales compensation, increased year over year.

[0001628280-25-056698:mdna:16]
We regularly monitor our spending to optimize our operating expenses and to ensure that our strategic investments are aligned with our highest-growth demand opportunities. During the fourth quarter of fiscal 2025, we began implementing a plan intended to deliver increased operating efficiencies through a reduction in headcount of 4% to 5% of our global workforce and a decision to cease forward investment in certain broadband development initiatives, primarily 25G PON.

[0001628280-25-056698:mdna:17]
Capital Allocation Strategy

[0001628280-25-056698:mdna:18]
Our capital allocation strategy is focused on maintaining our significant innovation investment, investing in select transactions, and returning value to stockholders, while preserving our strategic and operational flexibility. We continuously work to improve our cash cycle and evaluate alternatives to manage our capital structure in order to enhance our liquidity. We ended fiscal 2025 with $1.4 billion of cash, cash equivalents, and investments. Cash generated from operations increased to $806.1 million in fiscal 2025 as compared to $514.5 million in fiscal 2024. Consistent with our capital allocation priorities, we invested $140.8 million in capital purchases, primarily for supply chain equipment, and research and development, $231.1 million for the acquisition of Nubis and $334.5 million on our share buyback program.

[0001628280-25-056698:mdna:19]
Consolidated Results of Operations

[0001628280-25-056698:mdna:20]
A discussion regarding results of operations for fiscal 2025 compared to fiscal 2024 is presented below. A discussion of fiscal 2024 compared to fiscal 2023 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended November 2, 2024, filed with the SEC on December 20, 2024, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0001628280-25-056698:mdna:21]
Our results of operations are presented based on our operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Effective as of the fourth quarter of fiscal 2025, we renamed (i) our “Maintenance Support and Training” product line to “Maintenance, Support, and Learning”, (ii) our “Installation and Deployment” product line to “Implementation”, and (iii) our “Consulting and Network Design” product line to “Advisory and Enablement.” These changes, affecting only the presentation of such information, were made on a prospective basis and do not impact comparability of previous financial results. However, references to the prior reported product lines have been changed herein to the new names described above. See Notes 2 and 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0001628280-25-056698:mdna:22]
Revenue

[0001628280-25-056698:mdna:23]
As a result of the increased demand described above, our revenue increased by 18.8% in fiscal 2025 as compared to fiscal 2024.

[0001628280-25-056698:mdna:24]
Operating Segment Revenue

[0001628280-25-056698:mdna:25]
The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0001628280-25-056698:mdna:26]
|  | Fiscal Year |  |  |  |  |
|  | 2025 |  | %* |  | 2024 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 3,246,239 |  |  | 68.1 |  | $ | 2,642,563 |  |  | 65.8 |  | $ | 603,676 |  |  | 22.8 |
| Routing and Switching | 430,138 |  |  | 9.0 |  | 399,492 |  |  | 10.0 |  | 30,646 |  |  | 7.7 |
| Total Networking Platforms | 3,676,377 |  |  | 77.1 |  | 3,042,055 |  |  | 75.8 |  | 634,322 |  |  | 20.9 |
| Platform Software and Services | 363,830 |  |  | 7.6 |  | 358,062 |  |  | 8.9 |  | 5,768 |  |  | 1.6 |
| Blue Planet Automation Software and Services | 115,547 |  |  | 2.4 |  | 77,619 |  |  | 2.0 |  | 37,928 |  |  | 48.9 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning | 317,247 |  |  | 6.7 |  | 303,086 |  |  | 7.5 |  | 14,161 |  |  | 4.7 |
| Implementation | 246,047 |  |  | 5.2 |  | 184,358 |  |  | 4.6 |  | 61,689 |  |  | 33.5 |
| Advisory and Enablement | 50,459 |  |  | 1.0 |  | 49,775 |  |  | 1.2 |  | 684 |  |  | 1.4 |
| Total Global Services | 613,753 |  |  | 12.9 |  | 537,219 |  |  | 13.3 |  | 76,534 |  |  | 14.2 |
| Consolidated revenue | $ | 4,769,507 |  |  | 100.0 |  | $ | 4,014,955 |  |  | 100.0 |  | $ | 754,552 |  |  | 18.8 |

[0001628280-25-056698:mdna:27]
_________________________________

[0001628280-25-056698:mdna:28]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2024 to 2025 |

[0001628280-25-056698:mdna:29]
•Networking Platforms segment revenue increased by $634.3 million.

[0001628280-25-056698:mdna:30]
◦Optical Networking revenue increased by $603.7 million, primarily driven by increases in sales of our RLS to cloud providers. Revenue also benefited from increased sales of our coherent pluggable transceivers to cloud providers, 6500 Packet-Optical Platforms to service provider customers, and Waveserver® systems.

[0001628280-25-056698:mdna:31]
◦Routing and Switching revenue increased by $30.6 million, primarily driven by an increase in sales of our 3000 and 5000 series of service delivery and aggregation platforms to a cloud provider customer for DCOM solutions.

[0001628280-25-056698:mdna:32]
•Platform Software and Services segment revenue increased by $5.8 million, primarily reflecting sales increases of our software consulting services.

[0001628280-25-056698:mdna:33]
•Blue Planet Automation Software and Services segment revenue increased by $37.9 million, primarily reflecting sales increases in our orchestration software, unified assurance and analytics software, and our inventory management software services.

[0001628280-25-056698:mdna:34]
•Global Services segment revenue increased by $76.5 million, primarily reflecting sales increases of $61.7 million of our implementation services and $14.2 million of our maintenance, support, and learning.

[0001628280-25-056698:mdna:35]
Revenue by Geographic Region

[0001628280-25-056698:mdna:36]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The following table reflects our geographic distribution of revenue, principally based on the relevant location for our delivery of products and performance of services (in thousands, except percentage data):

[0001628280-25-056698:mdna:37]
|  | Fiscal Year |  |  |  |  |
|  | 2025 |  | %* |  | 2024 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 3,606,407 |  |  | 75.6 |  | $ | 2,951,915 |  |  | 73.5 |  | $ | 654,492 |  |  | 22.2 |
| EMEA | 731,912 |  |  | 15.4 |  | 648,870 |  |  | 16.2 |  | 83,042 |  |  | 12.8 |
| APAC | 431,188 |  |  | 9.0 |  | 414,170 |  |  | 10.3 |  | 17,018 |  |  | 4.1 |
| Total | $ | 4,769,507 |  |  | 100.0 |  | $ | 4,014,955 |  |  | 100.0 |  | $ | 754,552 |  |  | 18.8 |

[0001628280-25-056698:mdna:38]
_________________________________

[0001628280-25-056698:mdna:39]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2024 to 2025 |

[0001628280-25-056698:mdna:40]
•Americas revenue increased by $654.5 million, primarily driven by increased sales to cloud providers as well as increased sales to service providers, each primarily in the United States.

[0001628280-25-056698:mdna:41]
•EMEA revenue increased by $83.0 million, primarily driven by increased sales to cloud providers in the Netherlands and service providers in the United Kingdom, partially offset by decreased sales to submarine network operators.

[0001628280-25-056698:mdna:42]
•APAC revenue increased by $17.0 million, primarily driven by increased sales in Japan and Singapore, partially offset by decreased sales to Hong Kong and India.

[0001628280-25-056698:mdna:43]
Revenue Concentration

[0001628280-25-056698:mdna:44]
Sales to our five largest customers contributed 49.7% of our revenue in fiscal 2025 and 43.8% of our revenue in fiscal 2024. Sales to one cloud provider were $851.6 million, or 17.9% of total revenue in fiscal 2025 and $532.3 million or 13.3% of total revenue in fiscal 2024. Sales to AT&T were $500.7 million, or 10.5% of total revenue, in fiscal 2025, and $475.3 million, or 11.8% of total revenue, in fiscal 2024. No other customer accounted for greater than 10% of our revenue in fiscal 2025 or fiscal 2024.

[0001628280-25-056698:mdna:45]
Currency Fluctuations

[0001628280-25-056698:mdna:46]
During fiscal 2025, 9.9% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Indian Rupees and Canadian Dollars. During fiscal 2025, as compared to fiscal 2024, the U.S. Dollar fluctuated against these and other currencies, with minimal impact as compared to fiscal 2024.

[0001628280-25-056698:mdna:47]
Gross Margin

[0001628280-25-056698:mdna:48]
Gross margin is calculated as revenue less cost of goods sold, divided by revenue.

[0001628280-25-056698:mdna:49]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs, shipping, logistics, and tariff costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, any estimated losses on committed customer contracts.

[0001628280-25-056698:mdna:50]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services, including implementation, maintenance, support, learning, advisory and enablement activities, and any estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0001628280-25-056698:mdna:51]
Gross margin can fluctuate due to a number of factors, including technology-based price compression, product and service mix, the lifecycle stage of our products and cost reductions.

[0001628280-25-056698:mdna:52]
The tables below set forth the changes in revenue and gross margin for the periods indicated (in thousands, except percentage data):

[0001628280-25-056698:mdna:53]
|  | Fiscal Year |  |  |  |  |
|  | 2025 |  | 2024 |  |  |  | Gross |
|  | Revenue |  | Gross Margin (%) |  | Revenue |  | Gross Margin (%) |  | Revenue Change (%) |  | Margin Change |
| Total | $ | 4,769,507 |  |  | 42.0 |  | $ | 4,014,955 |  |  | 42.8 |  | 18.8 |  | (0.8) |
| Products | $ | 3,822,618 |  |  | 41.1 |  | $ | 3,159,021 |  |  | 41.1 |  | 21.0 |  | — |
| Services | $ | 946,889 |  |  | 45.8 |  | $ | 855,934 |  |  | 49.3 |  | 10.6 |  | (3.5) |

[0001628280-25-056698:mdna:54]
_________________________________

[0001628280-25-056698:mdna:55]
•Gross margin decreased by 80 basis points from 42.8% for fiscal 2024 to 42.0% for fiscal 2025, primarily reflecting decreased services margin.

[0001628280-25-056698:mdna:56]
•Product gross margin did not change for fiscal 2025 as compared to fiscal 2024. However, the primary changes within gross margin were a less favorable product mix, offset by improved manufacturing efficiencies, product cost reductions and reduced inventory writedowns.

[0001628280-25-056698:mdna:57]
•Services gross margin decreased by 350 basis points, from 49.3% for fiscal 2024 to 45.8% for fiscal 2025, primarily due to higher incentive compensation, a lower proportion of maintenance services sales, and a higher proportion of implementation services sales.

[0001628280-25-056698:mdna:58]
Operating Expense

[0001628280-25-056698:mdna:59]
Operating expense consists of the component elements described below.

[0001628280-25-056698:mdna:60]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0001628280-25-056698:mdna:61]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0001628280-25-056698:mdna:62]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0001628280-25-056698:mdna:63]
•Significant asset impairments and restructuring costs primarily reflect the costs associated with significant impairment or abandonment of assets and actions we have taken to restructure our business, including reductions in force, facility optimization, and the redesign of business processes.

[0001628280-25-056698:mdna:64]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and customer relationships derived from our acquisitions.

[0001628280-25-056698:mdna:65]
•Acquisition and integration costs primarily consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition activity.

[0001628280-25-056698:mdna:66]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0001628280-25-056698:mdna:67]
|  | Fiscal Year |  |  |  |  |
|  | 2025 |  | %* |  | 2024 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 848,329 |  |  | 17.8 |  | $ | 767,497 |  |  | 19.1 |  | $ | 80,832 |  |  | 10.5 |
| Selling and marketing | 581,331 |  |  | 12.2 |  | 510,668 |  |  | 12.7 |  | 70,663 |  |  | 13.8 |
| General and administrative | 238,707 |  |  | 5.0 |  | 220,647 |  |  | 5.5 |  | 18,060 |  |  | 8.2 |
| Significant asset impairments and restructuring costs | 112,113 |  |  | 2.4 |  | 24,592 |  |  | 0.6 |  | 87,521 |  |  | 355.9 |
| Amortization of intangible assets | 25,758 |  |  | 0.5 |  | 29,569 |  |  | 0.7 |  | (3,811) |  |  | (12.9) |
| Acquisition and integration costs | 1,148 |  |  | — |  | — |  |  | — |  | 1,148 |  |  | 100.0 |
| Total operating expenses | $ | 1,807,386 |  |  | 37.9 |  | $ | 1,552,973 |  |  | 38.6 |  | $ | 254,413 |  |  | 16.4 |

[0001628280-25-056698:mdna:68]
_________________________________

[0001628280-25-056698:mdna:69]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2024 to 2025 |

[0001628280-25-056698:mdna:70]
•Research and development expense increased by $80.8 million, primarily due to higher incentive compensation. Expenses were also increased by professional services, partially offset by foreign exchange benefits.

[0001628280-25-056698:mdna:71]
•Selling and marketing expense increased by $70.7 million, primarily due to higher incentive compensation.

[0001628280-25-056698:mdna:72]
•General and administrative expense increased by $18.1 million, primarily due to incentive compensation, partially offset by lower legal fees and bad debt expense.

[0001628280-25-056698:mdna:73]
•Significant asset impairments and restructuring costs increased by $87.5 million, primarily due to the abandonment of our in-process R&D intangible asset. For more information on our restructuring costs, see Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:74]
•Amortization of intangible assets decreased by $3.8 million primarily reflecting certain intangible assets having reached the end of their economic lives.

[0001628280-25-056698:mdna:75]
•Acquisition and integration costs in fiscal 2025 primarily reflect financial, legal, and accounting advisory costs and certain employee-related costs related to our acquisition of Nubis.

[0001628280-25-056698:mdna:76]
Currency Fluctuations

[0001628280-25-056698:mdna:77]
During fiscal 2025, 46.3% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars and Indian Rupees. During fiscal 2025 as compared to fiscal 2024, the U.S. Dollar fluctuated against these and other currencies with minimal impact as compared to fiscal 2024.

[0001628280-25-056698:mdna:78]
Segment Profit (Loss)

[0001628280-25-056698:mdna:79]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0001628280-25-056698:mdna:80]
|  | Fiscal Year |  |  |
|  | 2025 |  | 2024 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 774,058 |  |  | $ | 594,170 |  |  | $ | 179,888 |  |  | 30.3 |
| Platform Software and Services | $ | 235,134 |  |  | $ | 240,341 |  |  | $ | (5,207) |  |  | (2.2) |
| Blue Planet Automation Software and Services | $ | 31,243 |  |  | $ | (2,395) |  |  | $ | 33,638 |  |  | 1,404.5 |
| Global Services | $ | 213,839 |  |  | $ | 204,378 |  |  | $ | 9,461 |  |  | 4.6 |

[0001628280-25-056698:mdna:81]
_________________________________

[0001628280-25-056698:mdna:82]
| * | Denotes % change from 2024 to 2025 |

[0001628280-25-056698:mdna:83]
•Networking Platforms segment profit increased by $179.9 million, primarily due to higher sales volume as described above, partially offset by higher research and development costs.

[0001628280-25-056698:mdna:84]
•Platform Software and Services segment profit decreased by $5.2 million, primarily due to increased research and development costs and reduced services margins as described above, partially offset by higher services sales volume.

[0001628280-25-056698:mdna:85]
•Blue Planet Automation Software and Services segment profit increased by $33.6 million, primarily due to higher sales volume as described above, improved margins, and lower research and development costs.

[0001628280-25-056698:mdna:86]
•Global Services segment profit increased by $9.5 million, primarily due to increased sales volumes as described above, partially offset by reduced margins also described above.

[0001628280-25-056698:mdna:87]
Other Items

[0001628280-25-056698:mdna:88]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0001628280-25-056698:mdna:89]
|  | Fiscal Year |  |  |  |  |
|  | 2025 |  | %* |  | 2024 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income, net | $ | 48,888 |  |  | 1.0 |  | $ | 50,261 |  |  | 1.3 |  | $ | (1,373) |  |  | (2.7) |
| Interest expense | $ | 89,403 |  |  | 1.9 |  | $ | 97,028 |  |  | 2.4 |  | $ | (7,625) |  |  | (7.9) |
| Loss on extinguishment and modification of debt | $ | 729 |  |  | — |  | $ | — |  |  | — |  | $ | 729 |  |  | 100.0 |
| Provision for income taxes | $ | 32,949 |  |  | 0.7 |  | $ | 35,894 |  |  | 0.9 |  | $ | (2,945) |  |  | (8.2) |

[0001628280-25-056698:mdna:90]
_________________________________

[0001628280-25-056698:mdna:91]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2024 to 2025 |

[0001628280-25-056698:mdna:92]
•Interest and other income, net decreased by $1.4 million, primarily resulting from lower interest income on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0001628280-25-056698:mdna:93]
•Interest expense decreased by $7.6 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity.

[0001628280-25-056698:mdna:94]
•Loss on extinguishment and modification of debt reflects the refinancing of our 2030 Term Loan in the first quarter of fiscal 2025.

[0001628280-25-056698:mdna:95]
•Provision for income taxes decreased by $2.9 million, primarily due to the effective tax rate for fiscal 2025 being lower than the effective tax rate for fiscal 2024. The lower effective tax rate was a result of the recognition of tax benefits related to Uncertain Tax Positions for which the statute of limitations has expired.

[0001628280-25-056698:mdna:96]
Liquidity and Capital Resources

[0001628280-25-056698:mdna:97]
We regularly evaluate our capital structure, liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and we will continue to consider capital raising and other market opportunities that may be available to us.

[0001628280-25-056698:mdna:98]
Principal Sources of Liquidity. Our principal sources of liquidity include our cash, cash equivalents and investments, which as of November 1, 2025 totaled $1.4 billion, as well as our Credit Facility (as defined in Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report). Based on past performance and current expectations, we believe that will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the reasonably foreseeable future, including the next 12 months.

[0001628280-25-056698:mdna:99]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $412.4 million as of November 1, 2025. Approximately $92.3 million of undistributed earnings from these foreign subsidiaries is expected to be repatriated, with any remaining amounts continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:100]
Stock Repurchase Authorization. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022 and completed in fiscal 2024. During fiscal 2025, we repurchased $329.7 million of our common stock under the stock repurchase program, and $670.3 million remained under the current repurchase authorization as of November 1, 2025. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 21 and 27 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:101]
Cash Flows

[0001628280-25-056698:mdna:102]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0001628280-25-056698:mdna:103]
|  | November 1, 2025 |  | November 2, 2024 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 1,091,952 |  |  | $ | 934,863 |  |  | $ | 157,089 |  |
| Short-term investments in marketable debt securities | 216,148 |  |  | 316,343 |  |  | (100,195) |  |
| Long-term investments in marketable debt securities | 57,142 |  |  | 80,920 |  |  | (23,778) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,365,242 |  |  | $ | 1,332,126 |  |  | $ | 33,116 |  |

[0001628280-25-056698:mdna:104]
Cash, cash equivalents and investments increased by $33.1 million during fiscal 2025. Cash from operating activities generated $806.1 million, which was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $334.5 million; (ii) cash used for the acquisition of a business of $231.1 million, net of cash acquired; (iii) cash used to fund our investing activities for capital expenditures totaling $140.8 million; (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $91.3 million; and (v) cash used for payments on our term loan due October 28, 2030 (the “Refinanced 2030 Term Loan”) of $11.6 million. In addition to cash provided by operations, the issuance of equity under our employee stock purchase plans provided $35.9 million in cash during fiscal 2025.

[0001628280-25-056698:mdna:105]
See Notes 3, 18, and 21 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to these transactions.

[0001628280-25-056698:mdna:106]
Cash Provided by Operating Activities

[0001628280-25-056698:mdna:107]
The following sections set forth the components of our $806.1 million of cash provided by operating activities for fiscal 2025. Net income (adjusted for non-cash charges) provided cash of $586.3 million and cash provided by our operating assets and liabilities was $219.8 million.

[0001628280-25-056698:mdna:108]
Net Income (adjusted for non-cash charges)

[0001628280-25-056698:mdna:109]
The following table sets forth our net income (adjusted for non-cash charges) during fiscal 2025 (in thousands):

[0001628280-25-056698:mdna:110]
|  | Year Ended |
|  | November 1, 2025 |
| Net income | $ | 123,338 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 104,133 |  |
| Abandonment of acquired in-process research and development | 89,100 |  |
| Share-based compensation costs | 184,525 |  |
| Amortization of intangible assets | 36,205 |  |
| Deferred taxes | (23,173) |  |
| Provision for inventory excess and obsolescence | 48,424 |  |
| Provision for warranty | 24,442 |  |
| Other | (736) |  |
| Net income (adjusted for non-cash charges) | $ | 586,258 |  |

[0001628280-25-056698:mdna:111]
Operating Assets and Liabilities

[0001628280-25-056698:mdna:112]
Operating asset and liability requirements decreased by $219.8 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0001628280-25-056698:mdna:113]
|  | Year Ended |
|  | November 1, 2025 |
| Accounts receivable | $ | (98,743) |  |
| Inventories | (53,602) |  |
| Prepaid expenses and other | 86,204 |  |
| Accounts payable, accruals, and other obligations | 226,486 |  |
| Deferred revenue | 63,760 |  |
| Operating lease assets and liabilities, net | (4,270) |  |
| Total cash provided by operating assets and liabilities | $ | 219,835 |  |

[0001628280-25-056698:mdna:114]
As compared to the end of fiscal 2024:

[0001628280-25-056698:mdna:115]
•The change in accounts receivable which includes accounts receivable, net, and long-term accounts receivable (see Notes 2 and 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to these transactions) primarily reflects increased sales volume, partially offset by improved cash collections;

[0001628280-25-056698:mdna:116]
•The change in inventories primarily reflects increases in raw materials;

[0001628280-25-056698:mdna:117]
•The change in prepaid expenses and other primarily reflects a significant reduction in the amount of refundable cash advances to third-party contract manufacturers, partially offset by increases in contract assets for unbilled accounts receivable and non-trade accounts receivable;

[0001628280-25-056698:mdna:118]
•The change in accounts payable, accruals, and other obligations primarily reflects a higher accrual associated with our incentive compensation and the timing of payments to suppliers;

[0001628280-25-056698:mdna:119]
•The change in deferred revenue primarily represents an increase in advanced payments received from customers for product orders prior to revenue recognition; and

[0001628280-25-056698:mdna:120]
•The change in operating lease assets and liabilities, net, represents cash paid for operating lease payments in excess of operating lease costs.

[0001628280-25-056698:mdna:121]
Cash Paid for Interest, Net

[0001628280-25-056698:mdna:122]
The following table sets forth the cash paid for interest, net during fiscal 2025 (in thousands):

[0001628280-25-056698:mdna:123]
|  | Year Ended |
|  | November 1, 2025 |
| 2030 Term Loan terminated January 17, 2025(1) | $ | 18,639 |  |
| Refinanced 2030 Term Loan due October 28, 2030(2) | 53,523 |  |
| 2030 Senior Notes due January 31, 2030(3) | 16,000 |  |
| Interest rate swaps(4) | (8,076) |  |
| Revolving Credit Facility(5) | 1,775 |  |
| Finance leases | 3,356 |  |
| Cash paid during period | $ | 85,217 |  |

[0001628280-25-056698:mdna:124]
(1) The 2030 Term Loan bore interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%.

[0001628280-25-056698:mdna:125]
(2) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of fiscal 2025, the interest rate on the Refinanced 2030 Term Loan was 5.78%.

[0001628280-25-056698:mdna:126]
(3) The 2030 Senior Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest on the 2030 Notes is payable semiannually on January 31 and July 31 of each year.

[0001628280-25-056698:mdna:127]
(4) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loans at 3.47% through January 2028 and another $350.0 million of our Term Loans at 3.287% through December 2028. The interest rate swaps entered into in April 2022, which matured in September 2025, fixed the SOFR rate for $350.0 million of our Term Loans at 2.968% from September 2023 to September 2025.

[0001628280-25-056698:mdna:128]
(5) During fiscal 2025, we utilized the revolving credit facility to issue certain standby letters of credit and paid nominal commitment fees, letter of credit fees, and other administrative charges primarily relating to the revolving credit facility.

[0001628280-25-056698:mdna:129]
For additional information about our debt, credit facility, and interest rate swaps, see Notes 15, 18 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0001628280-25-056698:mdna:130]
Contractual Obligations

[0001628280-25-056698:mdna:131]
Debt. As of November 1, 2025, we had $1.15 billion outstanding principal associated with our Refinanced 2030 Term Loan, with $11.6 million maturing within 12 months. Interest payments on the Refinanced 2030 Term Loan and payments to be received under the interest rate swaps are variable and are calculated using the interest rate in effect as of November 1, 2025. Future interest payments associated with the Refinanced 2030 Term Loan totaled $328.5 million, with $67.0 million payable within 12 months. Future interest to be received net of payments under the interest rate swaps totaled $12.9 million, with $4.6 million to be received within 12 months. As of November 1, 2025, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes totaled $72.0 million, with $16.0 million payable within 12 months.For additional information about our short-term and long-term debt and interest rate swaps, see Notes 15 and 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0001628280-25-056698:mdna:132]
Purchase Order Obligations. As of November 1, 2025, we had $2.1 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0001628280-25-056698:mdna:133]
Leases. We have lease arrangements for facilities globally to support the ongoing operations of our business segments and related functions. Office facilities are leased under various non-cancelable operating or finance leases. As of November 1, 2025, we had fixed lease payment obligations of $109.3 million, with $23.4 million payable within 12 months. See Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:134]
Off-Balance Sheet Arrangements

[0001628280-25-056698:mdna:135]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0001628280-25-056698:mdna:136]
Critical Accounting Policies and Estimates

[0001628280-25-056698:mdna:137]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 1 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0001628280-25-056698:mdna:138]
Revenue Recognition

[0001628280-25-056698:mdna:139]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price.

[0001628280-25-056698:mdna:140]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0001628280-25-056698:mdna:141]
When transfer of control is judged to be over time for implementation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred.

[0001628280-25-056698:mdna:142]
Our total deferred revenue for products was $65.4 million and $19.0 million as of November 1, 2025 and November 2, 2024, respectively. Our services revenue is deferred and primarily recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $238.4 million and $218.6 million as of November 1, 2025 and November 2, 2024, respectively.

[0001628280-25-056698:mdna:143]
Reserve for Inventory Obsolescence

[0001628280-25-056698:mdna:144]
We estimate future customer demand for our products to determine the appropriate reserve for excess and obsolete inventory. Forecasted demand is based on customer backlog, historical usage and sales forecast by product line. We write down inventory that has become obsolete, slow-moving or unmarketable to reduce its carrying value to the estimated net realizable value. Inventory write downs are a component of our product cost of goods sold. Once recorded, inventory write-downs establish a new lower cost basis for that inventory, and are not reversed. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. From time to time, we may purchase products in excess of near term demand due to supplier last time buy requirements, or for other strategic reasons. We continue to manage long-lead component purchases and non-cancelable commitments with contract manufacturers and suppliers. As of November 1, 2025 and November 2, 2024, we had $2.1 billion and $1.7 billion, respectively, in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory.

[0001628280-25-056698:mdna:145]
For fiscal 2025, 2024 and 2023, we recorded charges for excess and obsolete inventory of $48.4 million, $77.3 million and $29.5 million, respectively, primarily related to a lower forecasted demand for certain Networking Platforms products primarily sold to service providers. Inventory, net of allowance for excess and obsolescence, was $826.2 million and $820.4 million as of November 1, 2025 and November 2, 2024, respectively.

[0001628280-25-056698:mdna:146]
Goodwill

[0001628280-25-056698:mdna:147]
We record acquisitions using the purchase method of accounting. The assets acquired and liabilities assumed are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms.

[0001628280-25-056698:mdna:148]
We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year, or if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value. In evaluating goodwill for impairment, we first decide whether to solely perform a qualitative test, which considers whether events and circumstances exist that indicate it is more likely than not that goodwill for a reporting unit is impaired. If such events or condition are identified, or if we elect to bypass the qualitative evaluation, we test goodwill impairment quantitatively by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period.

[0001628280-25-056698:mdna:149]
As of November 1, 2025 and November 2, 2024, the goodwill balance was $521.2 million and $444.7 million, respectively. There were no goodwill impairments resulting from our fiscal 2025 and 2024 impairment tests, and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 12 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:150]
Purchased Intangible Assets

[0001628280-25-056698:mdna:151]
Our purchased intangible assets primarily result from our acquisitions. The accounting for acquisitions requires significant estimates and judgments in their valuation. Critical estimates used in the valuation of purchased intangible assets include, the amount and timing of expected future cash flows, useful lives, and discount rates. While our estimates of fair value are based on assumptions that are believed to be reasonable, these assumptions are inherently uncertain and unpredictable and may not reflect circumstances that may occur.

[0001628280-25-056698:mdna:152]
We review purchased intangible assets for impairment quarterly or whenever triggering events or changes in circumstances indicate that the assets’ carrying amount may not be recoverable from its undiscounted cash flows. These assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0001628280-25-056698:mdna:153]
During fiscal 2025, approximately $89.1 million was abandoned from in-process research and development with a corresponding expense reported in significant asset impairments and restructuring costs on the Consolidated Statement of Operations. As of November 1, 2025 and November 2, 2024, these assets totaled $224.2 million and $165.0 million, net, respectively. There were no asset impairments resulting from our fiscal 2025 and 2024 impairment tests. See Note 13 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0001628280-25-056698:mdna:154]
Deferred Tax Assets

[0001628280-25-056698:mdna:155]
Pursuant to Accounting Standards Codification (“ASC”) Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0001628280-25-056698:mdna:156]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The net deferred tax assets as of November 1, 2025 and November 2, 2024 were $884.4 million and $885.9 million, respectively, including valuation allowances of $214.5 million and $192.4 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax law or our tax planning strategy.
