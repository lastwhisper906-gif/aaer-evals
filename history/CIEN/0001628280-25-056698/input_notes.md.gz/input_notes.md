# CIEN notes — 0001628280-25-056698


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001628280-25-056698:notes:1]
Part III of this annual report on Form 10-K (the “annual report”) incorporates by reference certain portions of the registrant’s definitive proxy statement for its 2026 Annual Meeting of Stockholders, which is expected to be filed with the Commission not later than 120 days after the end of the fiscal year covered by this annual report.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0001628280-25-056698:notes:2]
Our Board of Directors and the Audit Committee of our Board of Directors (the “Audit Committee”) are responsible for overseeing and assessing management’s execution of and approach to cybersecurity risk management. Our Chief Information Security Officer (“CISO”), who reports directly to our General Counsel, is primarily responsible for assessing cybersecurity risks and managing our cybersecurity program on a day-to-day basis, with support from other members of senior management.

[0001628280-25-056698:notes:3]
Our CISO is an accomplished security professional with 20 years of experience in cybersecurity and risk management across numerous industries and holds degrees in computer science and information assurance, and additional executive education in building and leading cybersecurity programs. The CISO and his team (the “Security Team”), which includes trained cybersecurity professionals, are responsible for implementing and maintaining our cybersecurity strategy and program and its related processes. We also maintain a Security Advisory Committee (“SAC”), which is chaired by our General Counsel and composed of members of executive leadership and other functional leaders, including our Chief Financial Officer, CISO, Chief Digital Information Officer, and Vice President of Internal Audit. The SAC meets regularly to, among other things, review cybersecurity program developments and serves as a path of escalation and decision-making in certain situations, including incident response.

[0001628280-25-056698:notes:4]
We, and our managed security partners, regularly monitor our environment for indicators of malicious or suspicious activity and security relevant events. The potential risk and impact of certain events is evaluated by a cross-functional team that includes members of our Security Team, legal department and other business functions as necessary and appropriate. Materiality determinations related to escalated events are made by the SAC without unreasonable delay. The CISO, on a quarterly basis, generally provides the Audit Committee a summary of relevant cybersecurity events, with certain events escalated to the Audit Committee, or Board of Directors, outside of these quarterly meetings depending upon their nature.
As part of our Board of Directors’ oversight of risk management, they devote time and attention to cybersecurity related risks. The Audit Committee is responsible for overseeing cybersecurity, data privacy, and information technology-related programs, policies and other efforts to manage or mitigate cybersecurity risks. As part of its standing agenda, the Audit Committee receives quarterly updates on cybersecurity risks and initiatives from our CISO. These updates have included reviews of our cybersecurity risk management efforts, including the development of relevant processes and policies, the implementation of technologies and systems, or use of third-party partners to safeguard our information systems, the conduct of education and training initiatives with employees and business partners, and incident response preparedness, including simulations and tabletop exercises. The Audit Committee regularly updates the Board of Directors on such matters. Separately, and in addition to such quarterly reporting, our Board of Directors also receives an annual update from our CISO on information and cybersecurity risks and related initiatives. These Board updates have included briefings from our CISO, as well as external counsel and third-party security advisors, which have included continuing education sessions as our Board of Directors seeks to enhance its understanding of cybersecurity risk, leading practices and an evolving cyber threat landscape.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001628280-25-056698:notes:5]
Risk Management and Strategy

[0001628280-25-056698:notes:6]
The safeguarding of information systems, that store employee and customer data, and proprietary information, are of paramount importance to us, our business and our reputation. We strive to maintain a robust and proactive enterprise cybersecurity program designed to identify, assess and manage cybersecurity risks that may impact our business or assets.

[0001628280-25-056698:notes:7]
Cybersecurity Strategy

[0001628280-25-056698:notes:8]
Our cybersecurity strategy focuses on (i) maintaining a cybersecurity framework and set of controls to assess and manage security risks and (ii) protecting against threats by deploying and monitoring security controls and mitigating exposures and potential threats. We maintain a security program designed to align with industry standards, principles, and frameworks, such as those set by the National Institute of Standards and Technology (NIST) and the International Organization for Standardization (ISO). Our program is also informed by various legal requirements, including contractual requirements from our customers. In addition, we maintain internal policies and procedures that govern the measures we take to secure our information technology environment. These include a wide variety of capabilities designed to prevent, detect, or address risks to systems and data. We also employ a range of tools and services, including regular network and endpoint monitoring, penetration testing, and vulnerability assessments, to inform our risk identification and management strategy.

[0001628280-25-056698:notes:9]
Security Risk Management

[0001628280-25-056698:notes:10]
Our Security Team regularly assesses cybersecurity risks, including their likelihood and potential impact, to develop mitigation strategies. The team utilizes enterprise governance, risk, and compliance solutions and tools licensed from third-party vendors to conduct various analytic assessments, including cloud and container security, detection and response, threat intelligence, and application security assessments. We also routinely evaluate and update our understanding of our cybersecurity threat landscape and evolve our related assessments and mitigation strategies accordingly.

[0001628280-25-056698:notes:11]
We regularly review our cybersecurity program for compliance with evolving regulations and to protect against emerging cyber threats. Because we operate in a dynamic threat landscape, we conduct regular reviews of our program and procedures, and we periodically engage third parties to supplement and review our cybersecurity practices. We also maintain a cybersecurity risk insurance policy as part of our risk management efforts, and regularly engage and collaborate with peers, industry groups, and U.S. government partners relating to cybersecurity risk management and the evolving threat environment.

[0001628280-25-056698:notes:12]
We seek to identify and address cybersecurity threats and risks that can arise from our use of third parties, including those that comprise our information systems, supply chain operations or who have access to certain data. We utilize supplier risk management practices, including enhanced due diligence assessments, that seek to identify cybersecurity risks associated with our use of third-party providers and the scope and nature of their work with us. These risks are assessed and prioritized based on, among other things, supplier assessments, threat intelligence, and industry practices. We consider these risks at the time of supplier onboarding and endeavor to assess changes in risk throughout the lifecycle of our relationship with suppliers.

[0001628280-25-056698:notes:13]
Promoting an engaged and aware workforce is a key part of our cybersecurity defense program. We carry out regular security awareness training for our personnel to help them better identify and address potential cybersecurity issues. This includes regular exercises to simulate and detect phishing attempts, various awareness and communication initiatives, and required online security awareness training at the time of hire and generally on an annual basis thereafter.

[0001628280-25-056698:notes:14]
Incident Response Readiness

[0001628280-25-056698:notes:15]
We utilize a combination of internal and third-party resources to monitor for threats to our network, systems and data. To promote cybersecurity readiness and advance the preparedness of our teams, our cross-functional incident response teams maintain an incident response plan, in addition to more technical response playbooks, and meet regularly to assess these resources. Among other things, they perform “tabletop” simulation exercises, internally and with third-party experts, to outline their roles and responsibilities during a cybersecurity event and to refine risk identification and management practices.

[0001628280-25-056698:notes:16]
We have in the past, and may in the future, utilize third-party cyber security assessors or consultants to review our program, to share their findings with our Board of Directors or leadership, and to help identify opportunities for continuous improvement.

[0001628280-25-056698:notes:17]
Additional information about cybersecurity risks we face is discussed in Item 1A of Part I of this annual report, “Risk Factors,” including under the heading “Cyber-attacks could compromise our technology and information, damaging our business and reputation and disrupting our operations,” which should be read in conjunction with the information above. While we continue to monitor, identify, investigate, respond to, and manage cybersecurity threats, risks and incidents, to date we have not experienced cybersecurity risks, including as a result of previous cybersecurity incidents, that have had a material effect. There can be no assurance that we will not experience such risks in the future.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0001628280-25-056698:notes:18]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0001628280-25-056698:notes:19]
Ciena Corporation (“Ciena”) is a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Ciena’s solutions support network traffic across a wide range of applications, including cloud, voice, video, data, and artificial intelligence (“AI”). Ciena’s network solutions are used globally by cloud providers, service providers, and other network operators across multiple industry verticals.

[0001628280-25-056698:notes:20]
Basis of Presentation

[0001628280-25-056698:notes:21]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001628280-25-056698:notes:22]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 1, 2025, November 2, 2024, and October 28, 2023, for the periods reported). Fiscal 2025 and fiscal 2023 each consisted of a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.

[0001628280-25-056698:notes:23]
Use of Estimates

[0001628280-25-056698:notes:24]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element and input method arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0001628280-25-056698:notes:25]
Cash, Cash Equivalents and Investments

[0001628280-25-056698:notes:26]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Restricted cash collateralizing letters of credit are included in other current assets and other long-term assets, depending on the duration of the restriction.

[0001628280-25-056698:notes:27]
Ciena’s debt security investments are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive loss. Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price, investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than the cost basis, and the intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year to be short-term investments, with all others considered to be long-term investments.

[0001628280-25-056698:notes:28]
Inventories

[0001628280-25-056698:notes:29]
Inventories are valued at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0001628280-25-056698:notes:30]
Goodwill

[0001628280-25-056698:notes:31]
Ciena records acquisitions using the purchase method of accounting. The assets acquired and liabilities assumed are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and intangible assets acquired is recorded as goodwill. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year or if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0001628280-25-056698:notes:32]
Ciena tests goodwill impairment qualitatively or quantitatively by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then a non-cash impairment loss is recognized, limited to the total amount of goodwill allocated to that reporting unit.

[0001628280-25-056698:notes:33]
Long-lived Assets

[0001628280-25-056698:notes:34]
Long-lived assets include equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0001628280-25-056698:notes:35]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0001628280-25-056698:notes:36]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method, generally over useful lives of three years to five years for equipment and furniture and fixtures. Leasehold improvements are generally over the shorter of useful life or lease term.

[0001628280-25-056698:notes:37]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0001628280-25-056698:notes:38]
Leases

[0001628280-25-056698:notes:39]
At the inception of a contract, Ciena must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts follows the assessment of whether there is a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating ROU assets, Operating lease liabilities and Long-term operating lease liabilities on the Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations on the Consolidated Balance Sheets.

[0001628280-25-056698:notes:40]
Ciena has operating and finance leases that primarily relate to real property. Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that is likely to be exercised. Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses, such as common area maintenance and utilities.

[0001628280-25-056698:notes:41]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Consolidated Statements of Operations.

[0001628280-25-056698:notes:42]
Intangible Assets

[0001628280-25-056698:notes:43]
Intangible assets primarily result from acquisitions. The accounting for acquisitions requires significant estimates and judgments in their valuation based on assumptions that are believed to be reasonable.

[0001628280-25-056698:notes:44]
Ciena records finite-lived intangible assets from acquisitions as developed technology and customer relationships. These assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the estimated expected economic life of the respective asset, historically up to seven years.

[0001628280-25-056698:notes:45]
Ciena records indefinite-lived intangible assets from acquisitions as in-process research and development. These assets are carried at cost until the completion or abandonment of the associated research and development efforts. On a quarterly basis during the period that these assets are considered indefinite lived, Ciena tests them for impairment qualitatively or quantitatively. If this test indicates that the fair value is less than the carrying value, then a non-cash impairment loss is recognized limited to the total amount of carrying value.

[0001628280-25-056698:notes:46]
Maintenance Spares

[0001628280-25-056698:notes:47]
Maintenance spares, which are included in other long-term assets on the Consolidated Balance Sheets, are recorded at cost. Ciena depreciates spares ratably over four years.

[0001628280-25-056698:notes:48]
Cloud Computing Arrangements

[0001628280-25-056698:notes:49]
Ciena capitalizes certain costs related to hosting arrangements that are service contracts (cloud computing arrangements). Capitalized costs are included in Other long-term assets on the Consolidated Balance Sheets and are amortized on a straight-line basis over the estimated useful life.

[0001628280-25-056698:notes:50]
Minority Equity Investments

[0001628280-25-056698:notes:51]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of November 1, 2025, the combined carrying value of these investments was $21.7 million. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena evaluates these investments for impairment or observable price changes quarterly and records adjustments to interest and other income, net on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:52]
Fair Value of Financial Instruments

[0001628280-25-056698:notes:53]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s short-term and long-term debt, see Note 18 below.

[0001628280-25-056698:notes:54]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. By distinguishing between inputs that are observable in the marketplace, and those that are more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. The classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0001628280-25-056698:notes:55]
•Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities;

[0001628280-25-056698:notes:56]
•Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0001628280-25-056698:notes:57]
•Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data.

[0001628280-25-056698:notes:58]
Stock Repurchase Program

[0001628280-25-056698:notes:59]
Shares repurchased pursuant to Ciena’s stock repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena reduces its common stock based on the par value of the shares and its capital surplus for the excess of the repurchase price over the par value. Ciena has had an accumulated deficit balance, therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0001628280-25-056698:notes:60]
Concentrations

[0001628280-25-056698:notes:61]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0001628280-25-056698:notes:62]
Historically, a significant percentage of Ciena’s revenue and accounts receivable have been concentrated among a small number of large customers. See Note 2 below.

[0001628280-25-056698:notes:63]
Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0001628280-25-056698:notes:64]
Revenue Recognition

[0001628280-25-056698:notes:65]
Ciena determines revenue recognition by applying the following five-step approach:

[0001628280-25-056698:notes:66]
•identification of the contract, or contracts, with a customer;

[0001628280-25-056698:notes:67]
•identification of the performance obligations in the contract;

[0001628280-25-056698:notes:68]
•determination of the transaction price;

[0001628280-25-056698:notes:69]
•allocation of the transaction price to the performance obligations in the contract; and

[0001628280-25-056698:notes:70]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0001628280-25-056698:notes:71]
Ciena makes sales pursuant to purchase orders placed by customers, primarily under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders are used to determine the identification of the contract with the customer. Purchase orders typically include the description, quantity, and price of each product or service purchased.

[0001628280-25-056698:notes:72]
Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0001628280-25-056698:notes:73]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price.

[0001628280-25-056698:notes:74]
As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena’s transfer of the products or services to the customer and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0001628280-25-056698:notes:75]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0001628280-25-056698:notes:76]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services, such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0001628280-25-056698:notes:77]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0001628280-25-056698:notes:78]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually primarily in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers.

[0001628280-25-056698:notes:79]
Capitalized Contract Acquisition Costs

[0001628280-25-056698:notes:80]
Ciena capitalizes and amortizes incremental costs of obtaining a contract considering each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena elects to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole, and the capitalized costs of obtaining a purchase order is applied, even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0001628280-25-056698:notes:81]
For the additional disclosures on capitalized contract acquisition costs, see Note 2 below.

[0001628280-25-056698:notes:82]
Warranty Accruals

[0001628280-25-056698:notes:83]
Ciena’s products are generally covered by a warranty for periods ranging from one to five years. Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Technical support labor cost is estimated based primarily on historical trends and the cost to support customer repairs within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, is included in accrued liabilities and other short-term obligations. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 14 below.

[0001628280-25-056698:notes:84]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0001628280-25-056698:notes:85]
Ciena estimates its allowances for credit losses using information from internal and external sources related to past events, current conditions, and supportable forecasts. Historical credit loss experience provides a basis for the estimation of expected future credit losses. Ciena determines collectability by pooling assets with similar characteristics, which are measured on a collective basis when similar risk characteristics exist. Additionally, a number of other factors, including, but not limited to, various customer-specific details, the potential sovereign risk of the geographic locations in which the customer is operating, and macroeconomic conditions may be assessed to determine if further exposure exists and should be accounted for. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0001628280-25-056698:notes:86]
Accounts Receivable Factoring

[0001628280-25-056698:notes:87]
Ciena has entered into factoring agreements to sell certain receivables to unrelated third-parties on a non-recourse basis. These transactions result in a reduction in accounts receivable because the agreements transfer effective control over, and risk related to, the receivables to the buyers. Trade accounts receivables balances sold are removed from the consolidated balance sheets and cash received is reflected as cash provided by operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest and other income, net on the Consolidated Statements of Operations. See Note 8 below.

[0001628280-25-056698:notes:88]
Government Grants

[0001628280-25-056698:notes:89]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates.

[0001628280-25-056698:notes:90]
Advertising Costs

[0001628280-25-056698:notes:91]
Ciena expenses all advertising costs as incurred.

[0001628280-25-056698:notes:92]
Software Development Costs

[0001628280-25-056698:notes:93]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date that technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0001628280-25-056698:notes:94]
Share-Based Compensation Expense

[0001628280-25-056698:notes:95]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis in the Consolidated Statements of Operations. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed.

[0001628280-25-056698:notes:96]
Ciena also awards stock units with performance-based vesting conditions that: (i) require the achievement of certain operational, financial or other performance criteria or targets; or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part.

[0001628280-25-056698:notes:97]
Ciena estimates the fair value of stock units subject to performance-based vesting conditions, other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense, for such stock units is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved in the Consolidated Statements of Operations. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed.

[0001628280-25-056698:notes:98]
Ciena estimates the fair value of performance based stock units subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant and recognizes the related share-based compensation expense over the performance period. Ciena reverses share-based compensation expense on performance based awards subject to total stockholder return only when the requisite service period is not reached.

[0001628280-25-056698:notes:99]
Ciena measures and recognizes compensation expense for share-based awards and employee stock purchases related to its employee stock purchase plan based on estimated fair values on the date of grant. Ciena estimates the fair value of such purchases using the Black-Scholes option-pricing model. See Note 23 below.

[0001628280-25-056698:notes:100]
Income Taxes

[0001628280-25-056698:notes:101]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0001628280-25-056698:notes:102]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0001628280-25-056698:notes:103]
Ciena is electing to use the period cost method for future global intangible low-taxed income (“GILTI”) inclusions.

[0001628280-25-056698:notes:104]
Loss Contingencies

[0001628280-25-056698:notes:105]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information in order to determine whether any accruals are required to be made or adjusted.

[0001628280-25-056698:notes:106]
Restructuring

[0001628280-25-056698:notes:107]
Ciena recognizes a liability for any cost associated with restructuring activities in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 4 below.

[0001628280-25-056698:notes:108]
Foreign Currency

[0001628280-25-056698:notes:109]
Ciena subsidiaries using the local currency as their functional currency, have their assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income, net on the Consolidated Statements of Operations. See Note 5 below.

[0001628280-25-056698:notes:110]
Derivatives

[0001628280-25-056698:notes:111]
Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. Ciena also uses foreign currency forward contracts to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. Generally, these derivatives have maturities of 24 months or less. These derivatives are designated as net investment hedges. Ciena assesses whether the derivative has been effective in offsetting changes attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive loss and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statements of Operations to which the hedged transaction relates. Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0001628280-25-056698:notes:112]
Ciena also uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:113]
See Notes 7 and 15 below.

[0001628280-25-056698:notes:114]
Computation of Net Income per Share

[0001628280-25-056698:notes:115]
Ciena calculates basic net income per common share (“Basic EPS”) by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of Basic EPS and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 20 below.

[0001628280-25-056698:notes:116]
Newly Issued Accounting Standards - Effective

[0001628280-25-056698:notes:117]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. Ciena adopted this standard with its fiscal 2025 Annual Report on Form 10-K with comparative periods updated to reflect additional disclosures. See Note 24 for additional information.

[0001628280-25-056698:notes:118]
Newly Issued Accounting Standards - Not Yet Effective

[0001628280-25-056698:notes:119]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures to decision makers. ASU 2023-09 is effective for annual periods beginning in fiscal 2026 and will result in changes to certain of its income tax disclosures including substantially more information on a disaggregated basis, but it does not affect recognition or measurement of income taxes and therefore is not expected to have a material effect on our consolidated financial statements. The amendments are applied on a prospective basis; however, retrospective application is permitted.

[0001628280-25-056698:notes:120]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40) to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-25-056698:notes:121]
In July 2025, the FASB issued ASU No. 2025-05 (“ASU 2025-05”), Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, to introduce a practical expedient for all entities, which simplifies the calculation required for estimating credit losses and assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. ASU 2025-05 is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods; however, early adoption is permitted. ASU 2025-05 allows for adoption using a prospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-25-056698:notes:122]
In September 2025, the FASB issues ASU No. 2025-06 (“ASU 2025-06”), Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) to modernize the accounting for software costs that are accounted for under Subtopic 350-40 by shifting away from prescriptive and sequential software development stages to an incremental and iterative method when capitalizing software costs. ASU 2025-06 is effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-25-056698:notes:123]
REVENUE
Segment and Product Line Disaggregation of Revenue

[0001628280-25-056698:notes:124]
Ciena’s disaggregated segment and product line revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Effective as of the fourth quarter of fiscal 2025, Ciena renamed (i) its “Maintenance Support and Training” product line to “Maintenance, Support, and Learning”, (ii) its “Installation and Deployment” product line to “Implementation”, and (iii) its “Consulting and Network Design” product line to “Advisory and Enablement.” These changes, affecting only the presentation of such information, were made on a prospective basis and do not impact comparability of previous financial results. However, references to the prior reported product lines have been changed herein to the new names described above. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 24 below.

[0001628280-25-056698:notes:125]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

[0001628280-25-056698:notes:126]
|  | Year Ended November 1, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 3,246,239 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 3,246,239 |  |
| Routing and Switching | 430,138 |  |  | — |  |  | — |  |  | — |  |  | 430,138 |  |
| Platform Software and Services | — |  |  | 363,830 |  |  | — |  |  | — |  |  | 363,830 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 115,547 |  |  | — |  |  | 115,547 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 317,247 |  |  | 317,247 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 246,047 |  |  | 246,047 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 50,459 |  |  | 50,459 |  |
| Total revenue by product line | $ | 3,676,377 |  |  | $ | 363,830 |  |  | $ | 115,547 |  |  | $ | 613,753 |  |  | $ | 4,769,507 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,676,377 |  |  | $ | 103,906 |  |  | $ | 49,401 |  |  | $ | 48,579 |  |  | $ | 3,878,263 |  |
| Products and services transferred over time | — |  |  | 259,924 |  |  | 66,146 |  |  | 565,174 |  |  | 891,244 |  |
| Total revenue by timing of revenue recognition | $ | 3,676,377 |  |  | $ | 363,830 |  |  | $ | 115,547 |  |  | $ | 613,753 |  |  | $ | 4,769,507 |  |

[0001628280-25-056698:notes:127]
|  | Year Ended November 2, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,642,563 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,642,563 |  |
| Routing and Switching | 399,492 |  |  | — |  |  | — |  |  | — |  |  | 399,492 |  |
| Platform Software and Services | — |  |  | 358,062 |  |  | — |  |  | — |  |  | 358,062 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 77,619 |  |  | — |  |  | 77,619 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 303,086 |  |  | 303,086 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 184,358 |  |  | 184,358 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 49,775 |  |  | 49,775 |  |
| Total revenue by product line | $ | 3,042,055 |  |  | $ | 358,062 |  |  | $ | 77,619 |  |  | $ | 537,219 |  |  | $ | 4,014,955 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,042,055 |  |  | $ | 99,317 |  |  | $ | 19,267 |  |  | $ | 44,410 |  |  | $ | 3,205,049 |  |
| Products and services transferred over time | — |  |  | 258,745 |  |  | 58,352 |  |  | 492,809 |  |  | 809,906 |  |
| Total revenue by timing of revenue recognition | $ | 3,042,055 |  |  | $ | 358,062 |  |  | $ | 77,619 |  |  | $ | 537,219 |  |  | $ | 4,014,955 |  |

[0001628280-25-056698:notes:128]
|  | Year Ended October 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,987,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,987,245 |  |
| Routing and Switching | 506,247 |  |  | — |  |  | — |  |  | — |  |  | 506,247 |  |
| Platform Software and Services | — |  |  | 303,873 |  |  | — |  |  | — |  |  | 303,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 69,170 |  |  | — |  |  | 69,170 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 288,334 |  |  | 288,334 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 180,951 |  |  | 180,951 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 50,729 |  |  | 50,729 |  |
| Total revenue by product line | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,493,492 |  |  | $ | 67,013 |  |  | $ | 21,842 |  |  | $ | 55,036 |  |  | $ | 3,637,383 |  |
| Products and services transferred over time | — |  |  | 236,860 |  |  | 47,328 |  |  | 464,978 |  |  | 749,166 |  |
| Total revenue by timing of revenue recognition | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |

[0001628280-25-056698:notes:129]
•Networking Platforms revenue reflects sales of Ciena’s Optical Networking and Routing and Switching product lines.

[0001628280-25-056698:notes:130]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products.

[0001628280-25-056698:notes:131]
•Routing and Switching - includes the 3000 family of service delivery platforms and 5000 family of service aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and other routing and switching portfolio products.

[0001628280-25-056698:notes:132]
Revenue from this segment is included in product revenue on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:133]
•Platform Software and Services revenue reflects sales of Ciena’s Platform Software and Platform Services.

[0001628280-25-056698:notes:134]
•Platform Software - includes Ciena’s Navigator Network Control SuiteTM domain controller solution and its applications, and legacy software solutions.

[0001628280-25-056698:notes:135]
•Platform Services - includes sales of subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

[0001628280-25-056698:notes:136]
Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:137]
•Blue Planet Automation Software and Services revenue reflects sales of Blue Planet Automation Software and Blue Planet Services.

[0001628280-25-056698:notes:138]
•Blue Planet Automation Software - includes inventory management, orchestration, route optimization and analysis, and unified assurance and analytics software.

[0001628280-25-056698:notes:139]
•Blue Planet Services - includes sales of subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.

[0001628280-25-056698:notes:140]
Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:141]
•Global Services revenue reflects sales of a broad range of Ciena’s services for advisory and enablement, implementation, and maintenance, support and learning activities.

[0001628280-25-056698:notes:142]
Revenue from this segment is included in services revenue on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:143]
•Revenue from the Networking Platforms segment includes, in addition to the products described above, sales of operating system software and enhanced software features embedded therein, which are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0001628280-25-056698:notes:144]
•Revenue from software platforms typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control.

[0001628280-25-056698:notes:145]
•Revenue from software subscription and support is recognized ratably over the period during which the services are performed.

[0001628280-25-056698:notes:146]
•Revenue from professional services for customization, consulting, and design services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0001628280-25-056698:notes:147]
•Revenue from maintenance and support is recognized ratably over the period during which the services are performed.

[0001628280-25-056698:notes:148]
•Revenue from implementation services and advisory and enablement services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0001628280-25-056698:notes:149]
•Revenue from learning services is generally recognized at a point in time upon completion of the service.

[0001628280-25-056698:notes:150]
Geographic Disaggregation of Revenue

[0001628280-25-056698:notes:151]
Ciena reports its sales geographically in the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0001628280-25-056698:notes:152]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0001628280-25-056698:notes:153]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Geographic distribution: |  |  |  |  |  |
| Americas | $ | 3,606,407 |  |  | $ | 2,951,915 |  |  | $ | 3,110,347 |  |
| EMEA | 731,912 |  |  | 648,870 |  |  | 643,142 |  |
| APAC | 431,188 |  |  | 414,170 |  |  | 633,060 |  |
| Total revenue by geographic distribution | $ | 4,769,507 |  |  | $ | 4,014,955 |  |  | $ | 4,386,549 |  |

[0001628280-25-056698:notes:154]
Ciena’s revenue includes United States revenue of $3.4 billion for fiscal 2025, and $2.8 billion for both fiscal 2024 and fiscal 2023. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0001628280-25-056698:notes:155]
Ciena’s revenue from a certain cloud provider includes $851.6 million, $532.3 million, and $561.4 million for fiscal 2025, fiscal 2024, and fiscal 2023, respectively. The cloud provider purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for each of the periods presented. Revenue also includes $500.7 million, $475.3 million, and $464.7 million from AT&T for fiscal 2025, fiscal 2024, and fiscal 2023, respectively. AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented. No other customer accounted for 10% or more of total revenue for the fiscal years presented.

[0001628280-25-056698:notes:156]
Contract Balances

[0001628280-25-056698:notes:157]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

[0001628280-25-056698:notes:158]
|  |  | Balance at November 1, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 975,856 |  |  | $ | 908,597 |  |
| Long-term accounts receivable |  | $ | 28,610 |  |  | $ | — |  |
| Deferred revenue |  | $ | 303,786 |  |  | $ | 237,619 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 157,868 |  |  | $ | 127,919 |  |

[0001628280-25-056698:notes:159]
Ciena’s contract assets represent unbilled accounts receivable, net, where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to implementation and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Consolidated Balance Sheets. See Note 10 below.

[0001628280-25-056698:notes:160]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $153.9 million of revenue in each of fiscal 2025 and 2024, which was included in the deferred revenue balance as at November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2025 and 2024.

[0001628280-25-056698:notes:161]
Capitalized contract acquisition costs consist of deferred sales commissions and were $37.4 million and $28.4 million as of November 1, 2025 and November 2, 2024, respectively. These are included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $36.8 million and $30.5 million during fiscal 2025 and fiscal 2024, respectively, and are included in selling and marketing expense on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:162]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of November 1, 2025, the aggregate amount of RPO was $2.1 billion. As of November 1, 2025, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0001628280-25-056698:notes:163]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0001628280-25-056698:notes:164]
|  | November 1, 2025 |  | November 2, 2024 |
| Products | $ | 65,382 |  |  | $ | 19,017 |  |
| Services | 238,404 |  |  | 218,602 |  |
| Total deferred revenue | 303,786 |  |  | 237,619 |  |
| Less current portion | (208,936) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 94,850 |  |  | $ | 81,240 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001628280-25-056698:notes:165]
BUSINESS COMBINATIONS
Fiscal 2025 Acquisitions: Nubis Communications

[0001628280-25-056698:notes:166]
On October 7, 2025, Ciena acquired 100% of the equity in Nubis Communications, a company specializing in high-performance, ultra-compact, low-power optical and electrical interconnects tailored to support AI workloads, including co-packaged optics, near packaged optics and electrical active copper cables that complement Ciena’s optical networking portfolio and high-speed interconnects. Nubis was acquired for an aggregate of approximately $270.5 million. This transaction has been accounted for as the acquisition of a business under ASC 805. The purchase price of $232.6 million was paid in cash at the time of the acquisition. In addition, there were $37.9 million of future payable arrangements including $28.9 million of contingent compensation and $9.0 million of unvested options converted to a right to receive cash over a four year period. These arrangements are tied to future employment and accordingly are being recognized as post-combination compensation expense over the associated service period.

[0001628280-25-056698:notes:167]
ASC 805 requires that the allocation of the purchase price to the assets acquired and liabilities assumed be based on their fair values as of the acquisition date. Ciena has made the determination of fair values using the best information available at the time. ASC 805 allows Ciena to adjust the provisional amounts recognized in the table below to be adjusted retrospectively for a period no later than one year from the acquisition date in case subsequent events identify a necessary adjustment. These adjustments could materially impact the amounts of goodwill, identified intangible assets, and deferred tax assets.

[0001628280-25-056698:notes:168]
During fiscal 2025, Ciena incurred approximately $1.1 million in acquisition-related costs associated with this acquisition. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:169]
The following table summarizes the preliminary purchase price allocation related to the acquisitions based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0001628280-25-056698:notes:170]
|  | Amount |
| Cash and cash equivalents | $ | 1,538 |  |
| Accounts receivable, net, and prepaid expenses and other | 227 |  |
| ROU assets | 1,649 |  |
| Equipment, furniture and fixtures | 1,259 |  |
| Goodwill | 76,539 |  |
| Developed technology | 98,000 |  |
| In-process technology | 86,000 |  |
| Deferred tax liability, net | (29,134) |  |
| Accounts payable, Accrued liabilities and other short-term obligations | (789) |  |
| Lease liabilities | (1,649) |  |
| Deferred revenue | (1,000) |  |
| Total purchase consideration | $ | 232,640 |  |

[0001628280-25-056698:notes:171]
Developed technology represents purchased technology that has reached technological feasibility and for which Nubis had substantially completed development as of the date of acquisition. Fair value was determined using the discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. This developed technology will be amortized on a straight-line basis over its estimated useful life of five years.

[0001628280-25-056698:notes:172]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using the discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Upon completion of the in-process technology, it will be amortized on a straight line basis over its to be estimated useful life.

[0001628280-25-056698:notes:173]
The goodwill generated from the acquisition of Nubis is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platform segment. The goodwill is not deductible for income tax purposes.

[0001628280-25-056698:notes:174]
Pro forma disclosures have not been included due to materiality.

[0001628280-25-056698:notes:175]
Fiscal 2023 Acquisitions: Benu and Tibit

[0001628280-25-056698:notes:176]
On November 17, 2022, Ciena acquired Benu, a provider of broadband software solutions. On December 30, 2022, Ciena acquired Tibit, a provider of passive optical network hardware and operating software. These businesses were acquired for an aggregate of approximately $291.7 million, of which $244.7 million was paid in cash, and $47.0 million represents the fair value of Ciena’s previously held cost method equity investment in Tibit. The acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. Each of these transactions has been accounted for as the acquisition of a business.

[0001628280-25-056698:notes:177]
Ciena incurred approximately $3.4 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Consolidated Statements of Operations.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-25-056698:notes:178]
SIGNIFICANT ASSET IMPAIRMENT AND RESTRUCTURING COSTS
Ciena regularly monitors its spending to optimize operating expenses and to ensure that its strategic investments are aligned with its highest-growth demand opportunities. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Consolidated Balance Sheets, for the fiscal years indicated (in thousands):

[0001628280-25-056698:notes:179]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 6,885 |  | (1) | 16,949 |  | (2) | 23,834 |  |
| Cash payments | (6,187) |  |  | (21,569) |  |  | (27,756) |  |
| Balance at October 28, 2023 | 1,913 |  |  | — |  |  | 1,913 |  |
| Charges | 15,408 |  | (1) | 9,184 |  | (2) | 24,592 |  |
| Cash payments | (15,394) |  |  | (9,184) |  |  | (24,578) |  |
| Balance at November 2, 2024 | 1,927 |  |  | — |  |  | 1,927 |  |
| Charges | 18,622 |  | (1) | 93,491 |  | (3) | 112,113 |  |
| Cash payments | (12,113) |  |  | (93,491) |  |  | (105,604) |  |
| Balance at November 1, 2025 | $ | 8,436 |  |  | $ | — |  |  | $ | 8,436 |  |
| Current restructuring liabilities | $ | 8,436 |  |  | $ | — |  |  | $ | 8,436 |  |

[0001628280-25-056698:notes:180]
_________________________________

[0001628280-25-056698:notes:181]
(1) Reflects employee costs associated with global workforce reductions of approximately 380, 420 and 120 employees during fiscal 2025, 2024 and 2023, respectively, as part of a business optimization strategy to reduce operating costs.

[0001628280-25-056698:notes:182]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure, and costs related to restructured real estate facilities.

[0001628280-25-056698:notes:183]
(3) Primarily related to the abandonment of an in-process R&D intangible asset associated with the decision to cease investment in 25G PON, within the routing and switching product line of the Network Platforms operating segment.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001628280-25-056698:notes:184]
INTEREST AND OTHER INCOME, NET
The components of interest and other income, net, were as follows (in thousands):

[0001628280-25-056698:notes:185]
|  |  | Year Ended |
|  |  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Interest income |  | $ | 55,020 |  |  | $ | 62,121 |  |  | $ | 45,011 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts(1) |  | (3,708) |  |  | 1,377 |  |  | (3,896) |  |
| Foreign currency exchange losses(2) |  | (63) |  |  | (11,653) |  |  | (427) |  |
| Gain on equity investments, net(3) |  | — |  |  | — |  |  | 26,368 |  |
| Other |  | (2,361) |  |  | (1,584) |  |  | (5,048) |  |
| Interest and other income, net |  | $ | 48,888 |  |  | $ | 50,261 |  |  | $ | 62,008 |  |

[0001628280-25-056698:notes:186]
(1) Ciena has forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Consolidated Statements of Operations.

[0001628280-25-056698:notes:187]
(2) Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. The related remeasurement adjustments were recorded in interest and other income, net, on the Consolidated Statements of Operations.
(3) During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of the previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its equity investment of $26.5 million. See Note 3 above.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-25-056698:notes:188]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0001628280-25-056698:notes:189]
|  | November 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 147,466 |  |  | $ | 304 |  |  | $ | — |  |  | $ | 147,770 |  |
| Corporate debt securities | 119,808 |  |  | 260 |  |  | — |  |  | 120,068 |  |
| Time deposits | 74,984 |  |  | 6 |  |  | — |  |  | 74,990 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |
| Included in cash equivalents | $ | 69,538 |  |  | $ | — |  |  | $ | — |  |  | $ | 69,538 |  |
| Included in short-term investments | 215,786 |  |  | 362 |  |  | — |  |  | 216,148 |  |
| Included in long-term investments | 56,934 |  |  | 208 |  |  | — |  |  | 57,142 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |

[0001628280-25-056698:notes:190]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

[0001628280-25-056698:notes:191]
The following table summarizes the legal maturities of debt investments at November 1, 2025 (in thousands):

[0001628280-25-056698:notes:192]
|  | November 1, 2025 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 285,324 |  |  | $ | 285,686 |  |
| Due in 1-2 years | 56,934 |  |  | 57,142 |  |
|  | $ | 342,258 |  |  | $ | 342,828 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-25-056698:notes:193]
FAIR VALUE MEASUREMENTS
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0001628280-25-056698:notes:194]
|  | November 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 713,707 |  |  | $ | — |  |  | $ | — |  |  | $ | 713,707 |  |
| Bond mutual fund | 117,931 |  |  | — |  |  | — |  |  | 117,931 |  |
| Time deposits | 74,990 |  |  | — |  |  | — |  |  | 74,990 |  |
| Deferred compensation plan assets | 21,179 |  |  | — |  |  | — |  |  | 21,179 |  |
| U.S. government obligations | — |  |  | 147,770 |  |  | — |  |  | 147,770 |  |
| Corporate debt securities | — |  |  | 120,068 |  |  | — |  |  | 120,068 |  |
| Foreign currency forward contracts | — |  |  | 3,236 |  |  | — |  |  | 3,236 |  |
| Total assets measured at fair value | $ | 927,807 |  |  | $ | 271,074 |  |  | $ | — |  |  | $ | 1,198,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 6,314 |  |  | $ | — |  |  | $ | 6,314 |  |
| Forward starting interest rate swaps | — |  |  | 1,345 |  |  | — |  |  | 1,345 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,659 |  |  | $ | — |  |  | $ | 7,659 |  |

[0001628280-25-056698:notes:195]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 636,097 |  |  | $ | — |  |  | $ | — |  |  | $ | 636,097 |  |
| Bond mutual fund | 112,703 |  |  | — |  |  | — |  |  | 112,703 |  |
| Time deposits | 92,804 |  |  | — |  |  | — |  |  | 92,804 |  |
| Deferred compensation plan assets | 16,519 |  |  | — |  |  | — |  |  | 16,519 |  |
| U.S. government obligations | — |  |  | 286,181 |  |  | — |  |  | 286,181 |  |
| Commercial paper | — |  |  | 111,143 |  |  | — |  |  | 111,143 |  |
| Foreign currency forward contracts | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Interest rate swaps | — |  |  | 11,777 |  |  | — |  |  | 11,777 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0001628280-25-056698:notes:196]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheets as follows (in thousands):

[0001628280-25-056698:notes:197]
|  | November 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 901,077 |  |  | $ | 99 |  |  | $ | — |  |  | $ | 901,176 |  |
| Short-term investments | 5,551 |  |  | 210,597 |  |  | — |  |  | 216,148 |  |
| Prepaid expenses and other | — |  |  | 3,236 |  |  | — |  |  | 3,236 |  |
| Long-term investments | — |  |  | 57,142 |  |  | — |  |  | 57,142 |  |
| Other long-term assets | 21,179 |  |  | — |  |  | — |  |  | 21,179 |  |
| Total assets measured at fair value | $ | 927,807 |  |  | $ | 271,074 |  |  | $ | — |  |  | $ | 1,198,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 6,314 |  |  | $ | — |  |  | $ | 6,314 |  |
| Other long-term obligations | — |  |  | 1,345 |  |  | — |  |  | 1,345 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,659 |  |  | $ | — |  |  | $ | 7,659 |  |

[0001628280-25-056698:notes:198]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 832,239 |  |  | $ | 9,426 |  |  | $ | — |  |  | $ | 841,665 |  |
| Short-term investments | 9,365 |  |  | 306,978 |  |  | — |  |  | 316,343 |  |
| Prepaid expenses and other | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Long-term investments | — |  |  | 80,920 |  |  | — |  |  | 80,920 |  |
| Other long-term assets | 16,519 |  |  | 11,777 |  |  | — |  |  | 28,296 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0001628280-25-056698:notes:199]
There were no transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0001628280-25-056698:notes:200]
ACCOUNTS RECEIVABLE
As of November 1, 2025, two customers accounted for 15.0% and 11.0% of net accounts receivable, respectively. As of November 2, 2024, two customers accounted for 13.0% and 12.0% of net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for credit losses for the fiscal years indicated (in thousands):

[0001628280-25-056698:notes:201]
| Year Ended |  | Beginning Balance |  |  |  | Provisions |  | Net Deductions |  | Ending Balance |
| October 28, 2023 |  | $ | 10,958 |  |  |  |  | $ | 5,718 |  |  | $ | 5,022 |  |  | $ | 11,654 |  |
| November 2, 2024 |  | $ | 11,654 |  |  |  |  | $ | 7,996 |  |  | $ | 9,770 |  |  | $ | 9,880 |  |
| November 1, 2025 |  | $ | 9,880 |  |  |  |  | $ | 4,226 |  |  | $ | 2,894 |  |  | $ | 11,212 |  |

[0001628280-25-056698:notes:202]
Accounts Receivable Factoring
Ciena may service transferred receivables which qualify as sales of receivables. Amounts sold through these arrangements during fiscal 2025, 2024, and 2023 were $1.0 million, $18.1 million, and $60.3 million, respectively. Additionally, Ciena may settle receivables through customer paying agent arrangements. Amounts settled through these arrangements for fiscal 2025, 2024, and 2023 were $50.9 million, $32.5 million, and $41.9 million, respectively. Factoring related expense recorded to interest and other income, net was $0.9 million, $1.2 million, and $3.8 million for fiscal 2025, 2024, and 2023, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0001628280-25-056698:notes:203]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0001628280-25-056698:notes:204]
|  | November 1, 2025 |  | November 2, 2024 |
| Raw materials | $ | 593,783 |  |  | $ | 542,785 |  |
| Work-in-process | 35,051 |  |  | 32,219 |  |
| Finished goods | 286,050 |  |  | 324,697 |  |
| Deferred cost of goods sold | 40,759 |  |  | 27,902 |  |
| Gross inventories | 955,643 |  |  | 927,603 |  |
| Reserve for excess and obsolescence | (129,408) |  |  | (107,173) |  |
| Inventories, net | $ | 826,235 |  |  | $ | 820,430 |  |

[0001628280-25-056698:notes:205]
Ciena estimates future customer demand for its products to determine the appropriate reserve for excess and obsolete inventory. For the periods presented, estimates were based on a combination of customer backlog, historical usage, and forecasted sales, and are inherently subject to uncertainty. These estimates are often impacted by changes in market conditions, declines in customer demand for certain products, discontinuation of certain products or introduction of newer product versions, or changes in strategic direction. Ciena writes down its inventor-y for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value. Reductions to the reserve relate primarily to the sale of previously reserved items and disposal activities. During fiscal 2025, 2024 and 2023, Ciena recorded a provision for excess and obsolescence of $48.4 million, $77.3 million, and $29.5 million, respectively.

[0001628280-25-056698:notes:206]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0001628280-25-056698:notes:207]
| Year Ended |  | Beginning Balance |  | Provisions |  | Disposals |  | Ending Balance |
| October 28, 2023 |  | $ | 36,086 |  |  | $ | 29,464 |  |  | $ | 15,547 |  |  | $ | 50,003 |  |
| November 2, 2024 |  | $ | 50,003 |  |  | $ | 77,341 |  |  | $ | 20,171 |  |  | $ | 107,173 |  |
| November 1, 2025 |  | $ | 107,173 |  |  | $ | 48,424 |  |  | $ | 26,189 |  |  | $ | 129,408 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0001628280-25-056698:notes:208]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0001628280-25-056698:notes:209]
|  | November 1, 2025 |  | November 2, 2024 |
| Contract assets for unbilled accounts receivable, net | $ | 157,868 |  |  | $ | 127,919 |  |
| Prepaid VAT and other taxes | 90,771 |  |  | 106,095 |  |
| Other non-trade receivables | 63,054 |  |  | 45,935 |  |
| Prepaid expenses | 54,845 |  |  | 50,597 |  |
| Product demonstration equipment, net (1) | 47,452 |  |  | 43,245 |  |
| Capitalized contract acquisition costs | 29,662 |  |  | 20,310 |  |
| Deferred deployment expense | 8,174 |  |  | 596 |  |
| Foreign currency forward contracts | 3,236 |  |  | 2,149 |  |
| Cash advances to contract manufacturers (2) | 254 |  |  | 167,337 |  |
|  | $ | 455,316 |  |  | $ | 564,183 |  |

[0001628280-25-056698:notes:210]
(1) Depreciation of product demonstration equipment was $9.7 million, $8.3 million and $8.0 million for fiscal 2025, 2024 and 2023, respectively.

[0001628280-25-056698:notes:211]
(2) Decrease reflects a significant reduction in the amount of refundable cash advances to third-party contract manufacturers.

[0001628280-25-056698:notes:212]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001628280-25-056698:notes:213]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0001628280-25-056698:notes:214]
|  | November 1, 2025 |  | November 2, 2024 |
| Equipment, furniture and fixtures | $ | 892,223 |  |  | $ | 788,781 |  |
| Building subject to finance lease | 67,242 |  |  | 67,517 |  |
| Leasehold improvements | 91,562 |  |  | 77,451 |  |
| Equipment, building, furniture and fixtures | 1,051,027 |  |  | 933,749 |  |
| Accumulated depreciation and amortization | (664,248) |  |  | (596,027) |  |
| Equipment, building, furniture and fixtures, net | $ | 386,779 |  |  | $ | 337,722 |  |

[0001628280-25-056698:notes:215]
During fiscal 2025, 2024, and 2023, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $94.4 million, $84.5 million and $84.6 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001628280-25-056698:notes:216]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of November 1, 2025 and November 2, 2024, as well as the changes to goodwill during fiscal 2025 (in thousands):

[0001628280-25-056698:notes:217]
|  | Balance at November 2, 2024 |  | Acquisitions |  |  |  | Translation |  | Balance at November 1, 2025 |
| Platform Software and Services | $ | 156,191 |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services | 89,049 |  |  | — |  |  |  |  | — |  |  | 89,049 |  |
| Networking Platforms | 199,467 |  |  | 76,539 |  |  |  |  | (42) |  |  | 275,964 |  |
| Total | $ | 444,707 |  |  | $ | 76,539 |  |  |  |  | $ | (42) |  |  | $ | 521,204 |  |


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001628280-25-056698:notes:218]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0001628280-25-056698:notes:219]
|  | November 1, 2025 |  | November 2, 2024 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 601,618 |  |  | $ | (466,827) |  |  | $ | 134,791 |  |  | $ | 503,618 |  |  | $ | (442,345) |  |  | $ | 61,273 |  |
| In-process research and development (1) | 86,000 |  |  | — |  |  | 86,000 |  |  | 89,100 |  |  | — |  |  | 89,100 |  |
| Patents and licenses | 9,295 |  |  | (6,898) |  |  | 2,397 |  |  | 8,795 |  |  | (6,150) |  |  | 2,645 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 410,899 |  |  | (409,877) |  |  | 1,022 |  |  | 410,934 |  |  | (398,932) |  |  | 12,002 |  |
| Total intangible assets | $ | 1,107,812 |  |  | $ | (883,602) |  |  | $ | 224,210 |  |  | $ | 1,012,447 |  |  | $ | (847,427) |  |  | $ | 165,020 |  |

[0001628280-25-056698:notes:220]
(1) During fiscal 2025, approximately $89.1 million was abandoned from in-process research and development with a corresponding expense reported in significant asset impairments and restructuring costs on the Consolidated Statement of Operations. Additionally, Ciena acquired $86.0 million of in-process research and development technology with its acquisition of Nubis. See Notes 3 and 4 above.

[0001628280-25-056698:notes:221]
The aggregate amortization expense of intangible assets was $36.2 million, $40.6 million and $49.6 million for fiscal 2025, 2024, and 2023, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0001628280-25-056698:notes:222]
| Fiscal Year | Amount (1) |  |  |
| 2026 | $ | 43,019 |  |  |  |
| 2027 | 35,514 |  |  |  |
| 2028 | 21,663 |  |  |  |
| 2029 | 19,797 |  |  |  |
| 2030 | 18,074 |  |  |  |
| Thereafter | 143 |  |  |  |
|  | $ | 138,210 |  |  |  |

[0001628280-25-056698:notes:223]
(1) Does not include amortization of in-process research and development, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-25-056698:notes:224]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0001628280-25-056698:notes:225]
|  | November 1, 2025 |  | November 2, 2024 |
| Maintenance spares inventory, net | $ | 92,392 |  |  | $ | 77,918 |  |
| Long-term accounts receivable(1) | 28,610 |  |  | — |  |
| Equity investments | 21,735 |  |  | 21,730 |  |
| Deferred compensation plan assets | 21,179 |  |  | 16,519 |  |
| Capitalized contract acquisition costs | 7,692 |  |  | 8,111 |  |
| Cloud computing arrangements(2) | 2,534 |  |  | 5,641 |  |
| Deferred debt issuance costs, net(3 | 1,440 |  |  | 1,733 |  |
| Restricted cash | 245 |  |  | 163 |  |
| Interest rate swaps | — |  |  | 11,777 |  |
| Other | 10,496 |  |  | 11,102 |  |
|  | $ | 186,323 |  |  | $ | 154,694 |  |

[0001628280-25-056698:notes:226]
(1)  Represents unbilled receivables attributable to non-cancellable software licenses recognized as revenue when made available to customers, to be billed in the future.

[0001628280-25-056698:notes:227]
(2)  During fiscal 2025, 2024, and 2023, Ciena recorded amortization of cloud computing arrangements of $5.0 million, $4.9 million and $2.6 million, respectively.

[0001628280-25-056698:notes:228]
(3) Deferred debt issuance costs relate to Ciena’s Credit Facility entered into during fiscal 2023 and its predecessor asset-backed credit facility (described in Note 19 below). The amortization of deferred debt issuance costs for the Credit Facility and its predecessor facility is included in interest expense, and was $0.3 million for both fiscal 2025 and fiscal 2024, and $0.4 million fiscal 2023.

[0001628280-25-056698:notes:229]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0001628280-25-056698:notes:230]
|  | November 1, 2025 |  | November 2, 2024 |
| Compensation, payroll related tax and benefits (1) | $ | 281,542 |  |  | $ | 148,732 |  |
| Warranty | 55,533 |  |  | 55,267 |  |
| Vacation | 33,708 |  |  | 31,250 |  |
| Income taxes payable | 10,729 |  |  | 35,111 |  |
| Foreign currency forward contracts | 6,314 |  |  | 9,155 |  |
| Interest payable | 6,101 |  |  | 6,120 |  |
| Finance lease liabilities | 4,741 |  |  | 4,395 |  |
| Other | 132,413 |  |  | 103,875 |  |
|  | $ | 531,081 |  |  | $ | 393,905 |  |

[0001628280-25-056698:notes:231]
(1)  Increase is primarily due to incentive compensation.

[0001628280-25-056698:notes:232]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years presented (in thousands):

[0001628280-25-056698:notes:233]
| Year Ended |  | Beginning Balance |  |  |  | Current Year Provisions |  |  |  | Settlements |  | Ending Balance |
| October 28, 2023 |  | $ | 45,503 |  |  |  |  | $ | 31,742 |  |  |  |  | $ | (20,156) |  |  | $ | 57,089 |  |
| November 2, 2024 |  | $ | 57,089 |  |  |  |  | $ | 25,643 |  |  |  |  | $ | (27,465) |  |  | $ | 55,267 |  |
| November 1, 2025 |  | $ | 55,267 |  |  |  |  | $ | 24,442 |  |  |  |  | $ | (24,176) |  |  | $ | 55,533 |  |

[0001628280-25-056698:notes:234]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0001628280-25-056698:notes:235]
|  | November 1, 2025 |  | November 2, 2024 |
| Income tax liability | $ | 102,718 |  |  | $ | 113,365 |  |
| Finance lease liabilities | 38,603 |  |  | 43,522 |  |
| Deferred compensation plan liability | 21,196 |  |  | 16,509 |  |
| Interest rate swap liability | 1,345 |  |  | — |  |
| Other | 11,564 |  |  | 12,542 |  |
|  | $ | 175,426 |  |  | $ | 185,938 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-25-056698:notes:236]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0001628280-25-056698:notes:237]
Ciena conducts business globally, and is exposed to foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0001628280-25-056698:notes:238]
As of November 1, 2025 and November 2, 2024, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $431.4 million and $257.0 million as of November 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 24 months or less, and have been designated as cash flow hedges.

[0001628280-25-056698:notes:239]
As of November 1, 2025 and November 2, 2024, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. In April 2024, Ciena terminated a portion of its existing net investment hedges for a cash loss of $0.6 million, which was recorded to other comprehensive loss. Ciena replaced its terminated net investment hedges with new net investment hedges. The notional amount of these contracts was approximately $62.0 million and $65.4 million as of November 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0001628280-25-056698:notes:240]
As of November 1, 2025 and November 2, 2024, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $175.7 million and $201.2 million as of November 1, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0001628280-25-056698:notes:241]
Interest Rate Derivatives

[0001628280-25-056698:notes:242]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 18 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0001628280-25-056698:notes:243]
In April 2022, Ciena entered into interest rate swaps which fixed the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million its floating rate debt at 2.968% from September 2023 through September 2025. These swaps expired in September 2025. The total notional amount of such swaps was $350 million as of November 2, 2024.

[0001628280-25-056698:notes:244]
In January 2023, Ciena entered into interest rate swaps to fix the SOFR rate for an additional $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of such swaps in effect as of November 1, 2025 and November 2, 2024 was $350.0 million.

[0001628280-25-056698:notes:245]
In December 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028. The total notional amount of such swaps in effect as of November 1, 2025 and November 2, 2024 was $350.0 million.

[0001628280-25-056698:notes:246]
Ciena expects the variable rate payments to be received under the terms interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the 2030 New Term Loan (as defined in Note 18 below). These derivative contracts have been designated as cash flow hedges.

[0001628280-25-056698:notes:247]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 5 and 7 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-25-056698:notes:248]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax (in thousands):

[0001628280-25-056698:notes:249]
|  |  | Unrealized Gain (Loss) on |  |  |  |  |
|  |  | Available-for-Sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 |  | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications |  | 2,593 |  |  | (8,455) |  |  | 19,600 |  |  | (5,321) |  |  | 8,417 |  |
| Amounts reclassified from AOCI |  | — |  |  | 10,496 |  |  | (10,035) |  |  | — |  |  | 461 |  |
| Balance at October 28, 2023 |  | (372) |  |  | (8,156) |  |  | 18,962 |  |  | (48,201) |  |  | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications |  | 1,170 |  |  | (1,424) |  |  | 4,574 |  |  | (3,096) |  |  | 1,224 |  |
| Amounts reclassified from AOCI |  | — |  |  | 4,700 |  |  | (14,868) |  |  | — |  |  | (10,168) |  |
| Balance at November 2, 2024 |  | 798 |  |  | (4,880) |  |  | 8,668 |  |  | (51,297) |  |  | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications |  | (376) |  |  | (1,996) |  |  | (1,646) |  |  | 697 |  |  | (3,321) |  |
| Amounts reclassified from AOCI |  | — |  |  | 3,073 |  |  | (8,076) |  |  | — |  |  | (5,003) |  |
| Balance at November 1, 2025 |  | $ | 422 |  |  | $ | (3,803) |  |  | $ | (1,054) |  |  | $ | (50,600) |  |  | $ | (55,035) |  |

[0001628280-25-056698:notes:250]
All amounts reclassified from AOCI related to settlement (gains) or losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) or losses on interest rate swaps designated as cash flow hedges impacted interest and other income, net on the Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0001628280-25-056698:notes:251]
LEASES
Ciena leases approximately 1.2 million square feet of facilities globally. Ciena’s corporate headquarters are located in Maryland, United States. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 10 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within 3 years.

[0001628280-25-056698:notes:252]
Leases included on the Consolidated Balance Sheets for the fiscal periods indicated were as follows (in thousands):

[0001628280-25-056698:notes:253]
|  | Classification |  | Balance at November 1, 2025 |  | Balance at November 2, 2024 |
| Operating leases (1) |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 38,613 |  |  | $ | 27,417 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 46,472 |  |  | $ | 39,562 |  |
| Finance leases: |  |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 67,242 |  |  | $ | 67,517 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (38,348) |  |  | (34,206) |  |
| Buildings, net |  |  | $ | 28,894 |  |  | $ | 33,311 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 43,344 |  |  | $ | 47,917 |  |

[0001628280-25-056698:notes:254]
(1) Ciena added two new ten-year operating leases to its portfolio in the second quarter of fiscal 2025. The addition of these operating leases increased both operating right-of-use (“ROU”) assets and lease liabilities for fiscal 2025.

[0001628280-25-056698:notes:255]
ROU assets that involve subleased or vacant space aggregate to an amount of $3.5 million as of November 1, 2025. Finance lease buildings, net, that involve subleased or vacant space aggregate to an amount of $3.9 million as of November 1, 2025. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized.

[0001628280-25-056698:notes:256]
For the periods indicated, the components of lease expense included in the Consolidated Statements of Operations were as follows (in thousands):

[0001628280-25-056698:notes:257]
|  |  |  | Year Ended |  | Year Ended |  | Year Ended |
|  | Classification |  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Operating lease costs | Operating expense |  | $ | 13,607 |  |  | $ | 13,595 |  |  | $ | 16,080 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 4,283 |  |  | 4,406 |  |  | 4,448 |  |
| Interest on finance lease liabilities | Interest expense |  | 3,356 |  |  | 3,769 |  |  | 4,069 |  |
| Total finance lease cost |  |  | 7,639 |  |  | 8,175 |  |  | 8,517 |  |
| Non-capitalized lease cost | Operating expense |  | 736 |  |  | 954 |  |  | 910 |  |
| Variable lease cost(1) | Operating expense |  | 2,688 |  |  | 2,562 |  |  | 3,421 |  |
| Net lease cost(2) |  |  | $ | 24,670 |  |  | $ | 25,286 |  |  | $ | 28,928 |  |

[0001628280-25-056698:notes:258]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0001628280-25-056698:notes:259]
(2) Excludes other operating expense of $5.3 million, $5.3 million, and $6.5 million for the fiscal years ended November 1, 2025, November 2, 2024, and October 28, 2023, respectively, related to amortization of leasehold improvements.

[0001628280-25-056698:notes:260]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of November 1, 2025 were as follows (in thousands):

[0001628280-25-056698:notes:261]
| Fiscal Year | Operating Leases |  | Finance Leases |  | Total |
| 2026 | $ | 15,639 |  |  | $ | 7,748 |  |  | $ | 23,387 |  |
| 2027 | 9,965 |  |  | 8,016 |  |  | 17,981 |  |
| 2028 | 5,078 |  |  | 8,285 |  |  | 13,363 |  |
| 2029 | 5,653 |  |  | 8,285 |  |  | 13,938 |  |
| 2030 | 4,631 |  |  | 8,437 |  |  | 13,068 |  |
| Thereafter | 13,142 |  |  | 14,406 |  |  | 27,548 |  |
| Total lease payments | 54,108 |  |  | 55,177 |  |  | 109,285 |  |
| Less: Imputed interest | (7,636) |  |  | (11,833) |  |  | (19,469) |  |
| Present value of lease liabilities | 46,472 |  |  | 43,344 |  |  | 89,816 |  |
| Less: Current portion of present value of minimum lease payments | 13,956 |  |  | 4,741 |  |  | 18,697 |  |
| Long-term portion of present value of minimum lease payments | $ | 32,516 |  |  | $ | 38,603 |  |  | $ | 71,119 |  |

[0001628280-25-056698:notes:262]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows (in thousands):

[0001628280-25-056698:notes:263]
|  | As of November 1, 2025 |  | As of November 2, 2024 |
| Weighted-average remaining lease term in years: |  |  |  |
| Operating leases | 5.51 |  | 4.00 |
| Finance leases | 6.71 |  | 7.71 |
| Weighted-average discount rates: |  |  |  |
| Operating leases | 4.99 | % |  | 4.29 | % |
| Finance leases | 7.56 | % |  | 7.56 | % |


## us-gaap:DebtDisclosureTextBlock

[0001628280-25-056698:notes:264]
SHORT-TERM AND LONG-TERM DEBT
Outstanding Term Loan Payable

[0001628280-25-056698:notes:265]
Refinanced 2030 Term Loan

[0001628280-25-056698:notes:266]
Pursuant to a credit agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained a senior secured term loan with an outstanding aggregate principal amount, as of January 17, 2025, of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

[0001628280-25-056698:notes:267]
On January 17, 2025, Ciena Corporation, as borrower, and certain of its subsidiaries, as guarantors, entered into a Refinancing Amendment to the Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

[0001628280-25-056698:notes:268]
•mature on October 24, 2030;

[0001628280-25-056698:notes:269]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date (as defined in the Credit Agreement), or $11.6 million annually, with the balance payable at maturity;

[0001628280-25-056698:notes:270]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0001628280-25-056698:notes:271]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

[0001628280-25-056698:notes:272]
•be repayable at any time at Ciena’s election; and

[0001628280-25-056698:notes:273]
•except as described above or as set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

[0001628280-25-056698:notes:274]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0001628280-25-056698:notes:275]
The net carrying value of Ciena’s term loans was comprised of the following as of the date indicated (in thousands):

[0001628280-25-056698:notes:276]
|  |  | November 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| Refinanced 2030 Term Loan |  | $ | 1,146,720 |  |  | $ | (3,556) |  |  | $ | (4,545) |  |  | $ | 1,138,619 |  |  | $ | — |  |  |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |  |  |

[0001628280-25-056698:notes:277]
Deferred debt issuance costs that were deducted from the carrying amount of the term loans totaled $4.5 million as of November 1, 2025 and $5.6 million as of November 2, 2024. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $1.0 million and $0.9 million during fiscal 2025 and fiscal 2024, respectively.

[0001628280-25-056698:notes:278]
As of November 1, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0001628280-25-056698:notes:279]
Outstanding Senior Notes Payable

[0001628280-25-056698:notes:280]
2030 Notes

[0001628280-25-056698:notes:281]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0001628280-25-056698:notes:282]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0001628280-25-056698:notes:283]
|  |  | November 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (2,881) |  |  | $ | 397,119 |  |  | $ | 396,427 |  |  |  |

[0001628280-25-056698:notes:284]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $2.9 million as of November 1, 2025 and $3.6 million as of November 2, 2024. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.7 million during fiscal 2025 and fiscal 2024.

[0001628280-25-056698:notes:285]
As of November 1, 2025, the estimated fair value of the 2030 Notes was $383.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
REVOLVING CREDIT FACILITY
Ciena Corporation and certain of its subsidiaries are parties to a revolving credit facility (the “Credit Facility”), which provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. The Credit Facility was entered into on February 10, 2023 and replaced a predecessor senior secured asset-based revolving credit facility and is principally used to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. The Credit Facility contains customary covenants that limit, absent lender approval, the ability of Ciena and certain of its subsidiaries to, among other things, pay cash dividends, incur debt, create liens and encumbrances, and redeem or repurchase stock.

[0001628280-25-056698:notes:286]
Under the Credit Facility, Ciena is also required to maintain certain financial maintenance covenants, including:

[0001628280-25-056698:notes:287]
•prior to an Investment Grade Event, a maximum Total Secured Net Leverage Ratio (as defined in the Credit Facility) of no greater than 3.50 to 1.00 as of the end of any period of four fiscal quarters (provided, that in the event Ciena consummates a qualifying acquisition, Ciena can elect to increase the maximum Total Secured Net Leverage Ratio level to 4.00 to 1.00 for the fiscal quarter in which such qualifying acquisition is consummated and for the next five consecutive fiscal quarters);

[0001628280-25-056698:notes:288]
•on or after an Investment Grade Event (as defined in the Credit Facility), a maximum Total Net Leverage Ratio of no greater than 4.00 to 1.00 as of the end of any period of four fiscal quarters; and

[0001628280-25-056698:notes:289]
•a minimum Interest Coverage Ratio (as defined in the Credit Facility) of no less than 3.00 to 1.00 as of the end of any period of four fiscal quarters.

[0001628280-25-056698:notes:290]
As of November 1, 2025, Ciena was in compliance with the above financial maintenance covenants. As of November 1, 2025, letters of credit totaling $50.5 million were issued under our Credit Facility. There were no borrowings outstanding under the Credit Facility as of November 1, 2025.


## us-gaap:EarningsPerShareTextBlock

[0001628280-25-056698:notes:291]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following unless the impact of the item is anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0001628280-25-056698:notes:292]
The following table presents the calculation of Basic and Diluted EPS (in thousands except per share amounts):

[0001628280-25-056698:notes:293]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Net income | $ | 123,338 |  |  | $ | 83,956 |  |  | $ | 254,827 |  |
| Basic weighted average shares outstanding | 142,221 |  |  | 144,715 |  |  | 148,971 |  |
| Effect of dilutive potential common shares | 3,027 |  |  | 1,249 |  |  | 409 |  |
| Diluted weighted average shares outstanding | 145,248 |  |  | 145,964 |  |  | 149,380 |  |
| Basic EPS | $ | 0.87 |  |  | $ | 0.58 |  |  | $ | 1.71 |  |
| Diluted EPS | $ | 0.85 |  |  | $ | 0.58 |  |  | $ | 1.71 |  |
| Anti-dilutive stock unit awards excluded | 1,004 |  | 1,057 |  | 2,675 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-25-056698:notes:294]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program and Accelerated Share Repurchase Agreement

[0001628280-25-056698:notes:295]
On December 9, 2021, Ciena announced that its Board of Directors replaced its previously authorized program with a program to repurchase up to $1.0 billion of its common stock. During fiscal 2023, Ciena repurchased 5.7 million shares of its common stock under this program, for an aggregate purchase price of $250.0 million at an average price of $44.08 per share. During fiscal 2024, Ciena repurchased an additional 4.5 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $55.07 per share, which completed the authorized repurchases contemplated under the program. In aggregate, Ciena repurchased 18.6 million shares for an aggregate purchase price of $1.0 billion, at an average price of $53.63 per share.

[0001628280-25-056698:notes:296]
On October 2, 2024, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock, commencing in Ciena’s fiscal year 2025 and continuing through the end of Ciena’s fiscal year 2027. Ciena may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors, including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time.

[0001628280-25-056698:notes:297]
During fiscal 2025, Ciena repurchased approximately 4.0 million shares of its common stock, for an aggregate purchase price of $329.7 million at an average price of $83.38 per share. As of November 1, 2025, Ciena has an aggregate of $670.3 million authorized and remaining shares under its stock repurchase program.

[0001628280-25-056698:notes:298]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0001628280-25-056698:notes:299]
Impact of Excise Tax on Share Repurchases

[0001628280-25-056698:notes:300]
Beginning fiscal 2023, a 1% excise tax on the market value of shares repurchased, net of compensatory shares issued became effective. During fiscal 2025 and fiscal 2024, a net excise tax of of $1.3 million and $1.4 million, respectively, was recorded to additional paid-in capital on the Consolidated Balance Sheets.

[0001628280-25-056698:notes:301]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0001628280-25-056698:notes:302]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $91.3 million for the shares of Ciena’s stock repurchased during fiscal 2025 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-25-056698:notes:303]
INCOME TAXES
For the periods indicated, the provision for income taxes consists of the following (in thousands):

[0001628280-25-056698:notes:304]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Provision for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 14,881 |  |  | $ | 70,208 |  |  | $ | 36,537 |  |
| State | 4,208 |  |  | 14,106 |  |  | 18,860 |  |
| Foreign | 37,034 |  |  | 28,390 |  |  | 28,281 |  |
| Total current | 56,123 |  |  | 112,704 |  |  | 83,678 |  |
| Deferred: |  |  |  |  |  |
| Federal | (36,359) |  |  | (52,300) |  |  | (8,010) |  |
| State | 13,643 |  |  | (4,868) |  |  | (17,354) |  |
| Foreign | (458) |  |  | (19,642) |  |  | 10,512 |  |
| Total deferred | (23,174) |  |  | (76,810) |  |  | (14,852) |  |
| Provision for income taxes | $ | 32,949 |  |  | $ | 35,894 |  |  | $ | 68,826 |  |

[0001628280-25-056698:notes:305]
For the periods indicated, income before provision for income taxes consists of the following (in thousands):

[0001628280-25-056698:notes:306]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| United States | $ | (22,804) |  |  | $ | 244 |  |  | $ | 93,682 |  |
| Foreign | 179,091 |  |  | 119,606 |  |  | 229,971 |  |
| Total | $ | 156,287 |  |  | $ | 119,850 |  |  | $ | 323,653 |  |

[0001628280-25-056698:notes:307]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0001628280-25-056698:notes:308]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2025, fiscal 2024 and fiscal 2023 as follows:

[0001628280-25-056698:notes:309]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Provision at statutory rate | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State taxes | 1.03 | % |  | 5.60 | % |  | 1.65 | % |
| Withholding and other foreign taxes | 5.87 | % |  | 3.53 | % |  | (0.09) | % |
| Research and development credit | (34.10) | % |  | (40.23) | % |  | (16.78) | % |
| Non-deductible compensation | 10.04 | % |  | 13.92 | % |  | 5.29 | % |
| U.S. Taxation on foreign activity | 1.20 | % |  | 9.59 | % |  | 5.08 | % |
| Foreign Nontaxable interest | 0.01 | % |  | (2.96) | % |  | (1.06) | % |
| Taxation on foreign inflation | 0.41 | % |  | 3.03 | % |  | 1.34 | % |
| Rate change | 7.58 | % |  | 4.46 | % |  | (3.71) | % |
| Valuation allowance | 14.08 | % |  | 2.15 | % |  | 9.44 | % |
| Loss on equity transactions | — | % |  | — | % |  | (1.72) | % |
| Uncertain tax positions | (4.65) | % |  | 8.09 | % |  | 1.72 | % |
| Other | (1.39) | % |  | 1.77 | % |  | (0.89) | % |
| Effective income tax rate | 21.08 | % |  | 29.95 | % |  | 21.27 | % |

[0001628280-25-056698:notes:310]
Ciena’s future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations.

[0001628280-25-056698:notes:311]
The significant components of deferred tax assets are as follows (in thousands):

[0001628280-25-056698:notes:312]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 76,148 |  |  | $ | 79,272 |  |
| Depreciation and amortization | 734,427 |  |  | 760,685 |  |
| NOL and credit carry forward | 243,193 |  |  | 211,792 |  |
| Other | 45,109 |  |  | 26,574 |  |
| Gross deferred tax assets | 1,098,877 |  |  | 1,078,323 |  |
| Valuation allowance | (214,456) |  |  | (192,447) |  |
| Deferred tax asset, net of valuation allowance | $ | 884,421 |  |  | $ | 885,876 |  |

[0001628280-25-056698:notes:313]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0001628280-25-056698:notes:314]
|  | Amount |
| Unrecognized tax benefits at October 29, 2022 | $ | 80,514 |  |
| Increase related to positions taken in prior period | 9,940 |  |
| Reductions related to settlements with taxing authorities | (625) |  |
| Increase related to positions taken in current period | 4,960 |  |
| Reductions related to expiration of statute of limitations | (869) |  |
| Unrecognized tax benefits at October 28, 2023 | 93,920 |  |
| Increase related to positions taken in prior period | 11,482 |  |
| Reductions related to settlements with taxing authorities | (4,345) |  |
| Increase related to positions taken in current period | 4,340 |  |
| Reductions related to expiration of statute of limitations | (116) |  |
| Unrecognized tax benefits at November 2, 2024 | 105,281 |  |
| Increase related to positions taken in prior period | 6,771 |  |
| Reductions related to settlements with taxing authorities | (234) |  |
| Increase related to positions taken in current period | 5,463 |  |
| Reductions related to expiration of statute of limitations | (21,596) |  |
| Unrecognized tax benefits at November 1, 2025 | $ | 95,685 |  |

[0001628280-25-056698:notes:315]
If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. As statutes of limitation expire, unrecognized tax benefits including interest and penalties related to contingencies may be reversed, resulting in an income tax benefit. Over the next twelve months, Ciena estimates that statutes on approximately $27.0 million of unrecognized tax benefits may expire, which would result in a net tax benefit.

[0001628280-25-056698:notes:316]
In addition, as of November 1, 2025 and November 2, 2024, Ciena had accrued $17.9 million and $16.3 million of interest and penalties, respectively, related to unrecognized tax benefits included in other long-term obligations on the Consolidated Balance Sheets. Interest and penalties of $1.6 million, $8.2 million and $2.7 million were recorded as a net expense to the provision for income taxes during fiscal 2025, fiscal 2024 and fiscal 2023, respectively.

[0001628280-25-056698:notes:317]
Changes in tax laws, regulations, administrative practices, and interpretations may impact Ciena’s tax contingencies. Due to various factors, the amounts ultimately paid, if any, upon the resolution of the issues raised by the taxing authorities may differ from the amounts accrued. It is reasonably possible that within the next twelve months Ciena will receive additional assessments by various tax authorities or possibly reach resolution of income tax controversies in one or more various jurisdictions. These factors could result in changes to our contingencies related to positions on prior years’ tax filings. Ciena cannot currently provide an estimate of potential changes.

[0001628280-25-056698:notes:318]
As of November 1, 2025, Ciena has approximately $92.3 million of undistributed earnings at foreign subsidiaries that were identified in fiscal 2023 as no longer indefinitely reinvested and $2.0 million of deferred tax liability remaining on Ciena’s Consolidated Balance sheets for the income tax effects related to the future repatriation of these earnings. No additional income tax expense has been provided for any remaining undistributed foreign earnings, or any additional outside basis difference from investments in the foreign subsidiaries, as these amounts continue to be indefinitely reinvested. If the remaining undistributed foreign earnings and profits that are subject to withholding tax of $413.0 million were repatriated to the U.S., the provisional amount of unrecognized deferred tax liability, which is primarily related to foreign withholding taxes, is an estimated $37.0 million, provided that the amount may be lower depending on Ciena’s ability to utilize tax credits associated with the distribution. Additionally, there are no other significant temporary differences for which a deferred tax liability or asset is not being recognized.

[0001628280-25-056698:notes:319]
As of November 1, 2025, Ciena continues to maintain a valuation allowance of $214.5 million primarily against its gross deferred tax assets. The valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates that it will not be able to use.

[0001628280-25-056698:notes:320]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0001628280-25-056698:notes:321]
| Year Ended |  | Beginning Balance |  | Additions |  | Deductions |  | Ending Balance |
| October 28, 2023 |  | $ | 162,076 |  |  | $ | 28,746 |  |  | $ | 952 |  |  | $ | 189,870 |  |
| November 2, 2024 |  | $ | 189,870 |  |  | $ | 16,816 |  |  | $ | 14,239 |  |  | $ | 192,447 |  |
| November 1, 2025 |  | $ | 192,447 |  |  | $ | 22,702 |  |  | $ | 693 |  |  | $ | 214,456 |  |

[0001628280-25-056698:notes:322]
As of November 1, 2025, Ciena had a $75.9 million net operating loss carry forward for U.S. federal income tax which does not expire, and $196.0 million net operating loss carry forwards for U.S. state income taxes which begin to expire in fiscal 2027. As of November 1, 2025, Ciena also had a $187.6 million net operating loss carry forward in non-U.S. jurisdictions which begin to expire in fiscal 2029. Ciena’s ability to use U.S. federal net operating losses is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0001628280-25-056698:notes:323]
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The OBBBA includes provisions, such as the permanent extension of certain expiring provision of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions such as bonus depreciation and expensing of domestic research and experimental expenditures. The legislations has multiple effective dates, with certain provisions that became effective in fiscal 2025 and others to be effective in fiscal 2026 and fiscal 2027. Ciena expects future cash tax savings, but does not expect a material impact on its future effective tax rate. The legislation did not have a material impact on Ciena’s consolidated financial statements in fiscal 2025.

[0001628280-25-056698:notes:324]
Tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2020 through 2024, in Canada for 2014, and in the United Kingdom for 2016 through 2022. Ciena does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2022), United Kingdom (2016), Canada (2014), and India (2020).

[0001628280-25-056698:notes:325]
The Organization for Economic Co-operation and Development has introduced a framework to implement a global minimum tax of 15% for certain highly profitable multinational companies, referred to as Pillar Two or the minimum tax directive. While the United States has not enacted legislation to adopt Pillar Two, certain countries in which Ciena operates have enacted legislation and many aspects of Pillar Two are effective for Ciena beginning in fiscal 2025. Pillar Two taxes are considered an alternative minimum tax accounted for as a period cost that could impact the effective tax rate in the year the Pillar Two tax obligation arises. Therefore, deferred taxes will not be recognized for the estimated effects of future minimum taxes. Pillar Two does not have a material effect on Ciena’s effective tax rate, financial results or cash flows for fiscal 2025.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-25-056698:notes:326]
SHARE-BASED COMPENSATION EXPENSE
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. Ciena also makes shares of its common stock available for purchase under the ESPP. Each of the 2017 Plan and the ESPP is described below.

[0001628280-25-056698:notes:327]
2017 Plan

[0001628280-25-056698:notes:328]
The 2017 Plan has a ten-year term and authorizes the issuance of awards, including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs), and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0001628280-25-056698:notes:329]
The 2017 Plan authorizes and reserves 21.1 million shares for issuance. The number of shares available under the 2017 Plan is also increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of November 1, 2025, the total number of shares authorized for issuance under the 2017 Plan was 21.1 million and approximately 8.5 million shares remained available for issuance thereunder.

[0001628280-25-056698:notes:330]
Restricted Stock Units

[0001628280-25-056698:notes:331]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part.

[0001628280-25-056698:notes:332]
During fiscal 2023, Ciena introduced a benefit pursuant to which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, the United Kingdom, or Canada, and who provide 12 months’ notice of their retirement, will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these and certain other countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their unvested RSU awards upon retirement. This program results in the acceleration of share-based compensation expense.

[0001628280-25-056698:notes:333]
Assumptions for Restricted Stock Unit Awards

[0001628280-25-056698:notes:334]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0001628280-25-056698:notes:335]
Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. Each reporting period, Ciena assesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0001628280-25-056698:notes:336]
Share-based compensation expense for restricted stock units subject only to service-based vesting conditions and restricted stock units subject to performance-based vesting conditions other than total stockholder return, is recognized only for those awards that ultimately vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0001628280-25-056698:notes:337]
Ciena estimates the fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation model. Ciena reverses share-based compensation expense on performance based awards subject to total stockholder return only when the requisite service period is not reached. Assumptions for awards granted during fiscal 2025, fiscal 2024 and fiscal 2023 included the following:

[0001628280-25-056698:notes:338]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 41.89% |  | 36.00% |  | 40.37% |
| Historical volatility of Ciena common stock | 39.90% |  | 36.74% |  | 43.11% |
| Volatility of S&P Networking Index(1) | 47.99% |  | 44.94% |  | 30.93% |
| Correlation coefficient | 0.3039 |  | 0.3665 |  | 0.7781 |
| Expected life in years | 2.87 |  | 2.89 |  | 2.89 |
| Risk-free interest rate | 4.18% |  | 4.41% |  | 3.95% |
| Expected dividend yield | 0.0% |  | 0.0% |  | 0.0% |

[0001628280-25-056698:notes:339]
(1) For fiscal 2023, reflects the volatility of the S&P Networking Index as a whole. For fiscal 2024 and fiscal 2025, reflects the volatility of the median company within the S&P Networking Index as of the date of the award, measured as of the last day of the prior fiscal year.

[0001628280-25-056698:notes:340]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0001628280-25-056698:notes:341]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance at November 2, 2024 | 6,112 |  |  | $ | 48.41 |  |  | $ | 390,995 |  |
| Granted | 2,341 |  |  |  |  |  |
| Vested | (2,578) |  |  |  |  |  |
| Canceled or forfeited | (373) |  |  |  |  |  |
| Balance at November 1, 2025 | 5,502 |  |  | $ | 62.76 |  |  | $ | 1,044,895 |  |

[0001628280-25-056698:notes:342]
As of both November 1, 2025 and November 2, 2024, 0.3 million of the total restricted stock units outstanding are performance based awards subject to total stockholder return. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2025, fiscal 2024 and fiscal 2023 was $224.4 million, $116.9 million and $98.2 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2025, fiscal 2024 and fiscal 2023 was $91.84, $44.57 and $50.48, respectively.

[0001628280-25-056698:notes:343]
Amended and Restated ESPP

[0001628280-25-056698:notes:344]
Ciena makes shares of its common stock available for purchase under the ESPP, under which eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0001628280-25-056698:notes:345]
During fiscal 2025, Ciena issued 0.8 million shares and during fiscal 2024 and fiscal 2023, Ciena issued 0.9 million and 0.8 million shares, respectively, under the ESPP. At November 1, 2025, 9.6 million shares remained available for issuance under the ESPP.

[0001628280-25-056698:notes:346]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0001628280-25-056698:notes:347]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Products | $ | 7,774 |  |  | $ | 6,474 |  |  | $ | 4,518 |  |
| Services | 15,184 |  |  | 12,743 |  |  | 10,470 |  |
| Share-based compensation expense included in cost of goods sold | 22,958 |  |  | 19,217 |  |  | 14,988 |  |
| Research and development | 64,281 |  |  | 54,129 |  |  | 42,331 |  |
| Sales and marketing | 52,066 |  |  | 42,954 |  |  | 35,136 |  |
| General and administrative | 45,424 |  |  | 40,053 |  |  | 37,587 |  |
| Share-based compensation expense included in operating expense | 161,771 |  |  | 137,136 |  |  | 115,054 |  |
| Share-based compensation expense capitalized in inventory, net | (204) |  |  | 51 |  |  | 413 |  |
| Total share-based compensation | $ | 184,525 |  |  | $ | 156,404 |  |  | $ | 130,455 |  |

[0001628280-25-056698:notes:348]
As of November 1, 2025, total unrecognized share-based compensation expense was $253.8 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.41 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-25-056698:notes:349]
SEGMENT AND ENTITY WIDE DISCLOSURES
Operating segments are defined as components of an enterprise that engage in business activities that earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Ciena’s chief operating decision maker (“CODM”) is its chief executive officer, Gary Smith, who evaluates Ciena’s performance and allocates resources based on segment profit (loss) as compared to annual targets for these four operating segments.

[0001628280-25-056698:notes:350]
Segment Profit (Loss)

[0001628280-25-056698:notes:351]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income for the respective periods indicated (in thousands). The CODM excludes the following items in his assessment of performance of the operating segments: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; share-based compensation expense, amortization of intangible assets; acquisition and integration costs; interest and other income, net; interest expense; loss on extinguishment and modification of debt; and provision for income taxes. Effective as of the fourth quarter of fiscal 2025, Ciena recast its segment profit (loss) to align with the CODM assessment of performance of the operating segments to exclude share-based compensation expense. This change affects only the presentation of such information:

[0001628280-25-056698:notes:352]
|  | Year Ended |
|  | November 1, 2025 |  | November 2, 2024 |  | October 28, 2023 |
| Revenue: |  |  |  |  |  |
| Networking Platforms | $ | 3,676,377 |  |  | $ | 3,042,055 |  |  | $ | 3,493,492 |  |
| Platform Software and Services | 363,830 |  |  | 358,062 |  |  | 303,873 |  |
| Blue Planet Automation Software and Services | 115,547 |  |  | 77,619 |  |  | 69,170 |  |
| Global Services | 613,753 |  |  | 537,219 |  |  | 520,014 |  |
| Total revenue | $ | 4,769,507 |  |  | $ | 4,014,955 |  |  | $ | 4,386,549 |  |
| Segment gross profit: |  |  |  |  |  |
| Networking Platforms | $ | 1,445,373 |  |  | $ | 1,199,978 |  |  | $ | 1,421,947 |  |
| Platform Software and Services | 307,320 |  |  | 305,486 |  |  | 258,031 |  |
| Blue Planet Automation Software and Services | 67,239 |  |  | 35,494 |  |  | 18,458 |  |
| Global Services | 218,390 |  |  | 208,904 |  |  | 207,667 |  |
| Total segment gross profit | $ | 2,038,322 |  |  | $ | 1,749,862 |  |  | $ | 1,906,103 |  |
| Research and development expense: |  |  |  |  |  |
| Networking Platforms | $ | 671,315 |  |  | $ | 605,808 |  |  | $ | 597,644 |  |
| Platform Software and Services | 72,186 |  |  | 65,145 |  |  | 64,641 |  |
| Blue Planet Automation Software and Services | 35,996 |  |  | 37,889 |  |  | 41,802 |  |
| Global Services | 4,551 |  |  | 4,526 |  |  | 4,141 |  |
| Total segment research and development expense | $ | 784,048 |  |  | $ | 713,368 |  |  | $ | 708,228 |  |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 774,058 |  |  | $ | 594,170 |  |  | $ | 824,303 |  |
| Platform Software and Services | 235,134 |  |  | 240,341 |  |  | 193,390 |  |
| Blue Planet Automation Software and Services | 31,243 |  |  | (2,395) |  |  | (23,344) |  |
| Global Services | 213,839 |  |  | 204,378 |  |  | 203,526 |  |
| Total segment profit | $ | 1,254,274 |  |  | $ | 1,036,494 |  |  | $ | 1,197,875 |  |
| Less: Unallocated cost of goods sold | $ | 33,405 |  |  | $ | 30,272 |  |  | $ | 27,252 |  |
| Less: Unallocated operating and non-operating expenses | 1,097,531 |  |  | 922,266 |  |  | 915,796 |  |
| Consolidated net income | $ | 123,338 |  |  | $ | 83,956 |  |  | $ | 254,827 |  |

[0001628280-25-056698:notes:353]
Entity Wide Reporting

[0001628280-25-056698:notes:354]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, goodwill, and maintenance spares, are not reviewed by Ciena’s CODM for purposes of evaluating performance and allocating resources. As of November 1, 2025, equipment, building, furniture and fixtures, net, totaled $386.8 million, and operating ROU assets totaled $38.6 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of November 1, 2025, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0001628280-25-056698:notes:355]
|  | November 1, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 224,210 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 224,210 |  |
| Goodwill | $ | 275,964 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 521,204 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 92,392 |  |  | $ | 92,392 |  |

[0001628280-25-056698:notes:356]
|  | November 2, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 158,903 |  |  | $ | — |  |  | $ | 6,117 |  |  | $ | — |  |  | $ | 165,020 |  |
| Goodwill | $ | 199,467 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 444,707 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 77,918 |  |  | $ | 77,918 |  |

[0001628280-25-056698:notes:357]
As of November 1, 2025, finite-lived intangible assets, goodwill, and maintenance spares allocated by segment reconciled to total assets (in thousands):

[0001628280-25-056698:notes:358]
|  | November 1, 2025 |  | November 2, 2024 |  |  |
| Assets assigned to segments | $ | 837,806 |  |  | $ | 687,645 |  |  |  |
| Other unallocated assets | 5,026,861 |  |  | 4,953,692 |  |  |  |
| Total assets | $ | 5,864,667 |  |  | $ | 5,641,337 |  |  |  |

[0001628280-25-056698:notes:359]
The following table shows Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets (in thousands) for any country accounting for at least 10% of the total. Any countries representing less than 10% are reflected in aggregate as “Other International.”

[0001628280-25-056698:notes:360]
|  | November 1, 2025 |  | November 2, 2024 |  |  |
| Canada | $ | 325,584 |  |  | $ | 283,760 |  |  |  |
| United States | 44,634 |  |  | 49,195 |  |  |  |
| Other International | 55,174 |  |  | 32,184 |  |  |  |
| Total | $ | 425,392 |  |  | $ | 365,139 |  |  |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0001628280-25-056698:notes:361]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual limit of CAD$35,390 (approximately $25,260 for 2025). This plan includes a required employer contribution of 1% for all participants and an employer matching contribution equal to 50% of the first 6% an employee contributes. During fiscal 2025, 2024 and 2023, Ciena made matching contributions of approximately CAD$11.9 million (approximately $8.5 million), CAD$11.6 million (approximately $8.3 million) and CAD$10.6 million (approximately $7.6 million), respectively.

[0001628280-25-056698:notes:362]
Ciena has a 401(k) defined contribution profit sharing plan that covers a majority of its United States-based employees. Participants may contribute up to 60% of base pay through pre-tax or Roth contributions, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 8% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2025, 2024 and 2023, Ciena made matching contributions of approximately $14.0 million, $11.0 million and $10.4 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-25-056698:notes:363]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0001628280-25-056698:notes:364]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0001628280-25-056698:notes:365]
Litigation

[0001628280-25-056698:notes:366]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0001628280-25-056698:notes:367]
Purchase Order Obligations

[0001628280-25-056698:notes:368]
Ciena has certain advanced orders for supply of certain long lead time components. As of November 1, 2025, Ciena had $2.1 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0001628280-25-056698:notes:369]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0001628280-25-056698:notes:370]
From the end of the fourth quarter of fiscal 2025 through December 5, 2025, Ciena repurchased 162,347 shares of its common stock for an aggregate purchase price of $31.7 million at an average price of $195.12 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of December 5, 2025, Ciena has an aggregate of $638.6 million of authorized funds remaining under this repurchase program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-25-056698:notes:371]
The following table describes, for the fourth quarter of fiscal 2025, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0001628280-25-056698:notes:372]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Joseph Cumello (Senior Vice President and General Manager of Blue Planet) | Modification (October 13, 2025) (1) | Rule 10b5-1 trading arrangement | Sales | Until December 31, 2026, or such earlier date upon which all transactions are completed or expire without execution (2) | (3) |
| Patrick T. Gallagher (Director) | Adoption (October 13, 2025) | Rule 10b5-1 trading arrangement | Sales | Until October 13, 2026, or such earlier date upon which all transactions are completed or expire without execution | Up to 11,618 shares of common stock |
| Sheela Kosaraju (Senior Vice President and General Counsel, and acting Chief People Officer) | Adoption (October 14, 2025) | Rule 10b5-1 trading arrangement | Sales | Until January 8, 2027, or such earlier date upon which all transactions are completed or expire without execution (4) | (5) |
| Jason Phipps (Senior Vice President, Global Customer Engagement) | Modification (October 6, 2025) (6) | Rule 10b5-1 trading arrangement | Sales | Until October 9, 2026, or such earlier date upon which all transactions are completed or expire without execution (7) | (8) |
| David M. Rothenstein (Senior Vice President, Chief Strategy Officer and Secretary) | Adoption (October 10, 2025) | Rule 10b5-1 trading arrangement | Sales | Until December 23, 2026, or such earlier date upon which all transactions are completed or expire without execution (9) | Up to 30,000 shares of common stock |
| Gary B Smith (President and Chief Executive Officer) | Adoption (October 4, 2025) | Rule 10b5-1 trading arrangement | Sales | Until December 15, 2026, or such earlier date upon which all transactions are completed or expire without execution (10) | (11) |

[0001628280-25-056698:notes:373]
(1)    On October 13, 2025, Mr. Cumello modified the Rule 10b5-1 trading arrangement (as modified, the “Cumello Modified Arrangement”) that he adopted on January 14, 2025 (the “Cumello Original Arrangement”).

[0001628280-25-056698:notes:374]
(2)    The Cumello Modified Arrangement changed the trading schedule and awards sold but not the duration of the arrangement. Sales under the Cumello Modified Arrangement will not begin until January 12, 2026.

[0001628280-25-056698:notes:375]
(3)    The aggregate number of shares of common stock to be sold pursuant to the Cumello Original Arrangement was up to 100% of the net after-tax shares of common stock to be received as a result of the vesting of an aggregate of 23,496 restricted stock units on June 20, 2025, September 20, 2025, December 20, 2025, March 20, 2026, June 20, 2026, September 20, 2026, and December 20, 2026. The aggregate number of shares of common stock to be sold pursuant to the Cumello Modified Arrangement is up to 100% of the net after-tax shares of common stock to be received as a result of the vesting of (i) an aggregate of 16,160 restricted stock units on December 20, 2025, March 20, 2026, June 20, 2026, September 20, 2026, and December 20, 2026, plus (ii) an aggregate of 2,272 performance stock units on December 20, 2025, plus (iii) performance stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 6,467 shares subject to the award at the target level of performance, which will vest on December 20, 2025 and December 20, 2026, plus (iv) market stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 13,313 shares subject to the award at the target level of performance, which will vest on  December 20, 2025 and December 20, 2026. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.

[0001628280-25-056698:notes:376]
(4)    Sales under this arrangement will not begin until January 15, 2026, following expiration of Ms. Kosaraju’s existing Rule 10b5-1 trading arrangement.

[0001628280-25-056698:notes:377]
(5)    The aggregate number of shares of common stock to be sold pursuant to Ms. Kosaraju’s arrangement is up to 100% of the net after-tax shares of common stock to be received as a result of the vesting of an aggregate of 19,137 restricted stock units on December 20, 2025, March 20, 2026, June 20, 2026, September 20, 2026, and December 20, 2026. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.

[0001628280-25-056698:notes:378]
(6)    On October 6, 2025, Mr. Phipps modified the Rule 10b5-1 trading arrangement (as modified, the “Phipps Modified Arrangement”) that he adopted on October 9, 2024 (the “Phipps Original Arrangement”).

[0001628280-25-056698:notes:379]
(7)    The Phipps Modified Arrangement changed the trading schedule and awards sold but not the duration of the arrangement. Sales under the Phipps Modified Arrangement will not begin until January 15, 2026.

[0001628280-25-056698:notes:380]
(8)    The aggregate number of shares of common stock to be sold pursuant to the Phipps Original Arrangement was up to (i) 14,381 shares of common stock, plus (ii) 100% of the net after-tax shares of common stock to be received as a result of the vesting of an aggregate of 28,736 restricted stock units on December 20, 2024, March 20, 2025, June 20, 2025, September 20, 2025, December 20, 2025, March 20, 2026, June 20, 2026, and September 20, 2026. The aggregate number of shares of common stock to be sold pursuant to the Phipps Modified Arrangement is up to (i) 18,170 shares of common stock, plus (ii) 100% of the net after-tax shares of common stock to be received as a result of the vesting of (a) an aggregate of 24,725 restricted stock units on December 20, 2025, March 20, 2026, June 20, 2026, and September 20, 2026, (b) an aggregate of 3,718 performance stock units on December 20, 2025, (c) performance stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 10,892 shares subject to the award at the target level of performance, half of which will vest on December 20, 2025, and (d) market stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 10,598 shares subject to the award at the target level of performance, which will vest on December 20, 2025. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.

[0001628280-25-056698:notes:381]
(9)    Sales under this arrangement will not begin until January 9, 2026, following expiration of Mr. Rothenstein’s existing Rule 10b5-1 trading arrangement.

[0001628280-25-056698:notes:382]
(10)    Sales under this arrangement will not begin until January 5, 2026, following expiration of Mr. Smith’s existing Rule 10b5-1 trading arrangement.

[0001628280-25-056698:notes:383]
(11)    The aggregate number of shares of common stock to be sold pursuant to Mr. Smith’s arrangement is up to (i) 67,937 shares of common stock, plus (ii) 100% of the net after-tax shares of common stock to be received as a result of the vesting of (a) performance stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 51,055 shares subject to the award at the target level of performance, half of which will vest on December 20, 2025, and (b) market stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 58,291 shares subject to the award at the target level of performance, which will vest on December 20, 2025.
