# CIEN MD&A — 0000936395-17-000051


## mdna

[0000936395-17-000051:mdna:1]
[same as prior period, unchanged from 0000936395-17-000038:mdna:1]

[0000936395-17-000051:mdna:2]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” "projects," "targets," or  “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, adoption of next-generation network technology and software programmability and control of networks; our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; our corporate strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including real estate and IT transitions or initiatives; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-17-000051:mdna:3]
[same as prior period, unchanged from 0000936395-17-000038:mdna:3]

[0000936395-17-000051:mdna:4]
[same as prior period, unchanged from 0000936395-17-000038:mdna:4]

[0000936395-17-000051:mdna:5]
[same as prior period, unchanged from 0000936395-17-000038:mdna:5]

[0000936395-17-000051:mdna:6]
[same as prior period, unchanged from 0000936395-17-000038:mdna:6]

[0000936395-17-000051:mdna:7]
[same as prior period, unchanged from 0000936395-17-000038:mdna:7]

[0000936395-17-000051:mdna:8]
[same as prior period, unchanged from 0000936395-17-000038:mdna:8]

[0000936395-17-000051:mdna:9]
[same as prior period, unchanged from 0000936395-17-000038:mdna:9]

[0000936395-17-000051:mdna:10]
[same as prior period, unchanged from 0000936395-17-000038:mdna:10]

[0000936395-17-000051:mdna:11]
| • | the level of growth in network traffic and bandwidth consumption and the corresponding level of investment in network infrastructures by network operators; |

[0000936395-17-000051:mdna:12]
[same as prior period, unchanged from 0000936395-17-000038:mdna:12]

[0000936395-17-000051:mdna:13]
[same as prior period, unchanged from 0000936395-17-000038:mdna:13]

[0000936395-17-000051:mdna:14]
[same as prior period, unchanged from 0000936395-17-000038:mdna:14]

[0000936395-17-000051:mdna:15]
[same as prior period, unchanged from 0000936395-17-000038:mdna:15]

[0000936395-17-000051:mdna:16]
[same as prior period, unchanged from 0000936395-17-000038:mdna:16]

[0000936395-17-000051:mdna:17]
| • | the potential failure to maintain the security of confidential, proprietary or otherwise sensitive business information or systems or to protect against cyber security attacks; |

[0000936395-17-000051:mdna:18]
[same as prior period, unchanged from 0000936395-17-000038:mdna:18]

[0000936395-17-000051:mdna:19]
[same as prior period, unchanged from 0000936395-17-000038:mdna:19]

[0000936395-17-000051:mdna:20]
[same as prior period, unchanged from 0000936395-17-000038:mdna:20]

[0000936395-17-000051:mdna:21]
[same as prior period, unchanged from 0000936395-17-000038:mdna:21]

[0000936395-17-000051:mdna:22]
[same as prior period, unchanged from 0000936395-17-000038:mdna:22]

[0000936395-17-000051:mdna:23]
[same as prior period, unchanged from 0000936395-17-000038:mdna:23]

[0000936395-17-000051:mdna:24]
[same as prior period, unchanged from 0000936395-17-000038:mdna:24]

[0000936395-17-000051:mdna:25]
[same as prior period, unchanged from 0000936395-17-000038:mdna:25]

[0000936395-17-000051:mdna:26]
[same as prior period, unchanged from 0000936395-17-000038:mdna:26]

[0000936395-17-000051:mdna:27]
[same as prior period, unchanged from 0000936395-17-000038:mdna:27]

[0000936395-17-000051:mdna:28]
[same as prior period, unchanged from 0000936395-17-000038:mdna:28]

[0000936395-17-000051:mdna:29]
[same as prior period, unchanged from 0000936395-17-000038:mdna:29]

[0000936395-17-000051:mdna:30]
[same as prior period, unchanged from 0000936395-17-000038:mdna:30]

[0000936395-17-000051:mdna:31]
[same as prior period, unchanged from 0000936395-17-000038:mdna:31]

[0000936395-17-000051:mdna:32]
[same as prior period, unchanged from 0000936395-17-000038:mdna:32]

[0000936395-17-000051:mdna:33]
[same as prior period, unchanged from 0000936395-17-000038:mdna:33]

[0000936395-17-000051:mdna:34]
[same as prior period, unchanged from 0000936395-17-000038:mdna:34]

[0000936395-17-000051:mdna:35]
| • | adverse results in litigation matters. |

[0000936395-17-000051:mdna:36]
[same as prior period, unchanged from 0000936395-17-000038:mdna:36]

[0000936395-17-000051:mdna:37]
[same as prior period, unchanged from 0000936395-17-000038:mdna:37]

[0000936395-17-000051:mdna:38]
Our Converged Packet Optical, Packet Networking and Optical Transport products are used by a diverse set of customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which provide functionality from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware platforms, we offer network management and control software platforms designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. Our software solutions are oriented around our modular Blue Planet software platform for multi-domain service

[0000936395-17-000051:mdna:39]
[same as prior period, unchanged from 0000936395-17-000038:mdna:41]

[0000936395-17-000051:mdna:40]
orchestration, network function virtualization, and network management and control. To complement our hardware and software solutions, we offer a broad range of transformation and automation services that help our customers design, optimize, integrate, deploy, manage and maintain their networks.

[0000936395-17-000051:mdna:41]
[same as prior period, unchanged from 0000936395-17-000038:mdna:39]

[0000936395-17-000051:mdna:42]
[same as prior period, unchanged from 0000936395-17-000038:mdna:40]

[0000936395-17-000051:mdna:43]
The markets in which we sell our communications networking solutions have seen significant changes in recent years, including rapid growth in network traffic, evolving cloud-based service offerings, changes in the type of customers building communications networks, and heightened end-user service demands. These conditions have placed significant demands on networks, challenged the business models of network operators, and altered the overall competitive landscape of network operators. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services, while managing the costs of their networks and seeking to ensure a profitable business model. These dynamics are driving convergence of network features, functions and layers, virtualization of certain network functions, and solutions that leverage increased software-based network control and programmability. We believe that these dynamics, and the need to adapt to rapidly changing business and network demands, will cause network operators to adopt or evolve their networks to be more open, programmable and automated.

[0000936395-17-000051:mdna:44]
[same as prior period, unchanged from 0000936395-17-000038:mdna:43]

[0000936395-17-000051:mdna:45]
The markets in which we compete are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to gain or retain market share. The markets for our solutions are both highly competitive and fragmented, as we regularly compete with number of large, multi-national vendors with greater financial, operational and marketing resources, and significantly broader product offerings. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, higher-capacity, higher-speed network solutions with improved reach, spectral efficiency, automation, power consumption and cost per bit. We expect the competitive landscape in which we operate to continue to broaden and to remain challenging and dynamic. As we have expanded our solutions offerings to include our 8700 Packetwave Platform and Waveserver DCI platform, our solutions have become increasingly competitive with IP router vendors, data center switch providers, and other IT suppliers or integrators. In software, as we seek increased customer adoption of our Blue Planet software platform, we expect to compete more directly with additional software vendors and information technology vendors or integrators of these solutions.

[0000936395-17-000051:mdna:46]
In addition to the above dynamics, many network operators are continuing to consider a variety of “consumption models”, or approaches to the design and procurement of their network infrastructure. While broader adoption of those consumption models emphasizing disaggregation in the procurement of hardware and software remains uncertain, we expect that the potential for different models will require us and other system vendors to assess and possibly broaden our existing commercial models over time. We may also face competition from component vendors, including those in our supply chain, that develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware. Further, some of our competitors are not vertically integrated in their packet optical supply chain and therefore sell a set of networking solutions that rely upon coherent modem technology developed by and procured from third party “merchant” providers. In connection with consumption models involving greater disaggregation, the continued use of such third party modem technology by these competitors and/or the availability of such technology in the market may increase overall pricing pressure in this space and may negatively impact our ability to derive higher gross margins for Converged Packet Optical solutions.

[0000936395-17-000051:mdna:47]
[same as prior period, unchanged from 0000936395-17-000038:mdna:46]

[0000936395-17-000051:mdna:48]
[same as prior period, unchanged from 0000936395-17-000038:mdna:47]

[0000936395-17-000051:mdna:49]
[same as prior period, unchanged from 0000936395-17-000038:mdna:48]

[0000936395-17-000051:mdna:50]
Promote Choice and Openness through our OPn Philosophy. We previously introduced our OPn Architecture as a focused approach to next-generation networks through scalability, programmability and network level applications. Today, OPn has evolved and expanded from an architecture into our governing philosophy and broader belief system, which is rooted in enabling choice in the market through openness. Choice is an increasingly important element of our customers’ efforts to keep pace with bandwidth demands and emerging service offerings, the shift to more automated and programmable networks, and the need to manage network costs. We believe that the best way to enable choice for our customers is by developing and providing network technologies and strategies that facilitate openness through innovation, virtualization, automation and collaboration. We also believe that we are well-positioned in this regard to offer an expansive range of choice to the market. Our OPn belief system shapes the operation of our business in a number of ways. It guides our research and development strategy and solutions offerings, including our focus on coherent modem leadership, packet-optical convergence, and on multi-vendor network orchestration, management and control through our Blue Planet software platform. By embracing design principles that leverage open application programming interfaces (APIs), including those found in our Waveserver platform, we believe we facilitate openness and choice. By offering collaborative tools and environments, including our Emulation Cloud and DevOps Toolkit, we enable the development, testing and customization of services and applications. Our OPn belief system also influences our go-to-market approach, as we expect to partner increasingly with an ecosystem of solutions vendors and virtual network function providers, and to integrate services and applications across multi-vendor and multi-domain networks. We intend to offer solutions and pursue opportunities across a range of customer consumption models in order to drive the evolution of next-generation network infrastructures and accelerate the realization of our OPn philosophy.

[0000936395-17-000051:mdna:51]
[same as prior period, unchanged from 0000936395-17-000038:mdna:51]

[0000936395-17-000051:mdna:52]
As part of our strategy to expand the application of our solutions and capitalize on the evolving market dynamics and different consumption models described above, on March 20, 2017, we announced global distribution relationships with leading component vendors Lumentum, NeoPhotonics and Oclaro. Through this new distribution channel, we intend to supply our WaveLogic Ai coherent optical technology for use as a component of a Ciena-designed optical module to be manufactured, marketed and sold by the component vendors. Once these modules are available, Lumentum, NeoPhotonics and Oclaro will each have the ability to sell such modules to customers on a non-exclusive basis. We believe that potential customers for optical modules through this distribution channel may include a variety of market participants, including certain of our customers, other system vendors, and network operators or vendors that plan to build or use “white box” hardware. In addition, we intend to work together with these component vendors to contribute to the establishment of specifications, both independently and within relevant industry forums, for 400G pluggable technology solutions focused on data center interconnect requirements for greater scale and power efficiency and lower cost. We believe that this distribution channel will further our efforts to continue to diversify our business and expand our addressable market to include new geographies and market segments, while enabling greater choice for network operators in offering an alternative to “merchant” modems. No revenue was generated through this distribution channel during the first nine months of fiscal 2017. We expect the results of operations related to this distribution channel to be reflected within our Networking Platforms segment.

[0000936395-17-000051:mdna:53]
Increase Diversification of our Business. The continued diversification of our business is a key element of our strategy. We believe this diversification positions us to continue to grow our business and to better withstand potential slowdowns adversely affecting particular geographies, markets, customer segments and applications. We intend to pursue initiatives that broaden sales to existing customers across our solutions portfolio and also to secure additional relationships with a diverse set of network operators in high-growth customer segments and geographies.

[0000936395-17-000051:mdna:54]
[same as prior period, unchanged from 0000936395-17-000038:mdna:56]

[0000936395-17-000051:mdna:55]
[same as prior period, unchanged from 0000936395-17-000038:mdna:54]

[0000936395-17-000051:mdna:56]
We also intend to target important growth markets, including key customer market segments and geographies. Our go-to-market strategy is focused on further diversifying our customer base by penetrating additional internet content providers, data center operators and other emerging network operators that form the “Web-scale” marketplace. We are also focused on securing additional customers within our traditional base of communications service providers, particularly in higher growth markets, including our Asia-Pacific region and India. We intend to use our direct and indirect sales channels to target, and to expand our sales with, several other market verticals, including cable and multiservice operators, submarine network operators, enterprise customers and in the government and R&E markets. For example, we intend to gain greater reach providing network solutions to submarine network operators, particularly in the new cable build market, in part through our recently announced supply partnership with TE SubCom. To leverage the geographic reach of our direct sales resources and expand sales into key geographies, we have pursued channel and distribution opportunities, including our strategic relationship with Ericsson, that enable sales through third parties, including service providers, systems integrators and value-added resellers.

[0000936395-17-000051:mdna:57]
[same as prior period, unchanged from 0000936395-17-000038:mdna:58]

[0000936395-17-000051:mdna:58]
Maturity of 0.875% Convertible Senior Notes due June 15, 2017

[0000936395-17-000051:mdna:59]
We repaid in cash the $185.3 million in aggregate principal amount outstanding of our 0.875% convertible senior notes at maturity on June 15, 2017.

[0000936395-17-000051:mdna:60]
Exchange Offer for 2018 Convertible Notes to Add Cash Settlement Conversion Options

[0000936395-17-000051:mdna:61]
On August 2, 2017, we completed our offer to exchange our currently outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount. The New Notes give us the option, at our election, to settle conversions of the New Notes for cash, shares of our common stock, or a combination of cash and shares. Through these cash settlement options, we believe that we will gain additional flexibility to better manage our long-term capital structure and reduce the dilutive impact of our convertible notes upon stockholders. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash. Accordingly, we intend to use the treasury stock method for the New Notes in our diluted earnings per share calculation starting in the fourth quarter of fiscal 2017. Following settlement of the exchange offer, approximately $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding.

[0000936395-17-000051:mdna:62]
Financial Results for Third Quarter of Fiscal 2017 and Sequential Comparison

[0000936395-17-000051:mdna:63]
Revenue for the third quarter of fiscal 2017 was $728.7 million, representing a sequential increase of 3.1% from $707.0 million in the second quarter of fiscal 2017. Revenue-related details reflecting sequential changes from the second quarter of fiscal 2017 include:

[0000936395-17-000051:mdna:64]
| • | Product revenue for the third quarter of fiscal 2017 increased by $26.1 million, primarily reflecting revenue increases in Packet Networking and Converged Packet Optical within our Networking Platforms segment and software platforms within our Software and Software-Related Services segment. |

[0000936395-17-000051:mdna:65]
| • | Service revenue for the third quarter of fiscal 2017 decreased by $4.4 million. |

[0000936395-17-000051:mdna:66]
| • | North America revenue for the third quarter of fiscal 2017 was $465.2 million, an increase from $424.4 million in the second quarter of fiscal 2017. This primarily reflects revenue increases of $37.9 million within our Networking Platforms segment and $5.5 million within our Software and Software-Related Services segment. These increases were partially offset by a revenue decrease of $2.5 million within our Global Services segment. |

[0000936395-17-000051:mdna:67]
| • | Europe, Middle East and Africa ("EMEA") revenue for the third quarter of fiscal 2017 was $96.1 million, a decrease from $105.8 million in the second quarter of fiscal 2017. This primarily reflects a revenue decrease of $12.1 million within our Networking Platforms segment, partially offset by a revenue increase of $2.6 million within our Global Services segment. |

[0000936395-17-000051:mdna:68]
| • | Caribbean and Latin America ("CALA") revenue for the third quarter of fiscal 2017 was $51.7 million, an increase from $33.9 million in the second quarter of fiscal 2017. This primarily reflects a revenue increase of $18.5 million within our Networking Platforms segment, partially offset by a revenue decrease of $1.2 million within our Global Services segment. |

[0000936395-17-000051:mdna:69]
| • | Asia Pacific ("APAC") revenue for the third quarter of fiscal 2017 was $115.7 million, a decrease from $142.9 million in the second quarter of fiscal 2017. This primarily reflects revenue decreases of $23.5 million within our Networking Platforms segment, $2.5 million within our Global Services segment and $1.2 million within our Software and Software-Related Services segment. |

[0000936395-17-000051:mdna:70]
| • | For the third quarter of fiscal 2017, two customers accounted for greater than 10% of total revenue. AT&T accounted for 16.6% of total revenue and Verizon accounted for 11.4%. AT&T accounted for 15.2% of total revenue in the second quarter of fiscal 2017. |

[0000936395-17-000051:mdna:71]
Gross margin for both the third quarter and the second quarter of fiscal 2017 was 45.0%.

[0000936395-17-000051:mdna:72]
Operating expense was $246.1 million for the third quarter of fiscal 2017, a decrease from $260.4 million in the second quarter of fiscal 2017. Third quarter fiscal 2017 operating expense primarily reflects decreases of $7.1 million in amortization of intangibles expense, $3.9 million in research and development expense, $2.1 million in restructuring costs and $1.8 million in sales and marketing expense.

[0000936395-17-000051:mdna:73]
Income from operations for the third quarter of fiscal 2017 was $82.0 million, compared to income from operations of $57.8 million during the second quarter of fiscal 2017. Our net income for the third quarter of fiscal 2017 was $60.0 million, or $0.39 per diluted common share, compared to a net income of $38.0 million, or $0.25 per diluted common share, for the second quarter of fiscal 2017.

[0000936395-17-000051:mdna:74]
We generated cash from operations of $50.6 million during the third quarter of fiscal 2017, compared to $72.0 million of cash generated from operations during the second quarter of fiscal 2017. As of July 31, 2017, we had $559.5 million in cash and cash equivalents, $234.8 million of short-term investments in U.S. treasury securities and commercial paper and $59.9 million of long-term investments in U.S. treasury securities. This compares to $628.6 million in cash and cash equivalents, $274.8 million of short-term investments in U.S. treasury securities and commercial paper and $89.9 million of long-term investments in U.S. treasury securities at April 30, 2017.

[0000936395-17-000051:mdna:75]
As of July 31, 2017, we had 5,780 employees, which reflects an increase from 5,555 at October 31, 2016 and an increase from 5,559 at July 31, 2016.

[0000936395-17-000051:mdna:76]
[same as prior period, unchanged from 0000936395-17-000038:mdna:77]

[0000936395-17-000051:mdna:77]
[same as prior period, unchanged from 0000936395-17-000038:mdna:78]

[0000936395-17-000051:mdna:78]
[same as prior period, unchanged from 0000936395-17-000038:mdna:79]

[0000936395-17-000051:mdna:79]
[same as prior period, unchanged from 0000936395-17-000038:mdna:80]

[0000936395-17-000051:mdna:80]
Quarter ended July 31, 2017 compared to the quarter ended July 31, 2016

[0000936395-17-000051:mdna:81]
[same as prior period, unchanged from 0000936395-17-000038:mdna:82]

[0000936395-17-000051:mdna:82]
During the third quarter of fiscal 2017, approximately 17.0% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Brazilian Reais, Argentina Pesos, and British Pounds. During the third quarter of fiscal 2017 as compared to the third quarter of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $2.0 million, or 0.3%, as compared to the third quarter of fiscal 2016. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000051:mdna:83]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 506,532 |  |  | 69.5 |  | $ | 467,615 |  |  | 69.7 |  | $ | 38,917 |  |  | 8.3 |  |
| Packet Networking | 82,121 |  |  | 11.3 |  | 63,658 |  |  | 9.5 |  | 18,463 |  |  | 29.0 |  |
| Optical Transport | 3,694 |  |  | 0.5 |  | 9,619 |  |  | 1.4 |  | (5,925 | ) |  | (61.6 | ) |
| Total Networking Platforms | 592,347 |  |  | 81.3 |  | 540,892 |  |  | 80.6 |  | 51,455 |  |  | 9.5 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 18,395 |  |  | 2.5 |  | 12,558 |  |  | 1.9 |  | 5,837 |  |  | 46.5 |  |
| Software-Related Services | 23,856 |  |  | 3.3 |  | 19,011 |  |  | 2.8 |  | 4,845 |  |  | 25.5 |  |
| Total Software and Software-Related Services | 42,251 |  |  | 5.8 |  | 31,569 |  |  | 4.7 |  | 10,682 |  |  | 33.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 57,902 |  |  | 7.9 |  | 55,996 |  |  | 8.4 |  | 1,906 |  |  | 3.4 |  |
| Installation and Deployment | 27,397 |  |  | 3.8 |  | 31,245 |  |  | 4.7 |  | (3,848 | ) |  | (12.3 | ) |
| Consulting and Network Design | 8,822 |  |  | 1.2 |  | 10,848 |  |  | 1.6 |  | (2,026 | ) |  | (18.7 | ) |
| Total Global Services | 94,121 |  |  | 12.9 |  | 98,089 |  |  | 14.7 |  | (3,968 | ) |  | (4.0 | ) |
| Consolidated revenue | $ | 728,719 |  |  | 100.0 |  | $ | 670,550 |  |  | 100.0 |  | $ | 58,169 |  |  | 8.7 |  |

[0000936395-17-000051:mdna:84]
[same as prior period, unchanged from 0000936395-17-000038:mdna:85]

[0000936395-17-000051:mdna:85]
[same as prior period, unchanged from 0000936395-17-000038:mdna:86]

[0000936395-17-000051:mdna:86]
[same as prior period, unchanged from 0000936395-17-000038:mdna:87]

[0000936395-17-000051:mdna:87]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $38.9 million of our Converged Packet Optical products and $18.5 million in sales of our Packet Networking products partially offset by a product line sales decrease of $5.9 million in sales of our Optical Transport products. |

[0000936395-17-000051:mdna:88]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $38.1 million of our Waveserver stackable interconnect system and $15.3 million of our 6500 Packet-Optical Platform. These increases were partially offset by sales decreases of $13.2 million of our Z-Series Packet-Optical Platform and $1.6 million of our OTN configuration for the 5410 Reconfigurable Switching System. |

[0000936395-17-000051:mdna:89]
| ◦ | Packet Networking sales primarily reflect sales increases of $13.2 million of our 3000 and 5000 families of service delivery and aggregation switches and $5.3 million of our 8700 Packetwave Platform. |

[0000936395-17-000051:mdna:90]
[same as prior period, unchanged from 0000936395-17-000038:mdna:91]

[0000936395-17-000051:mdna:91]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $4.9 million in software-related services and $5.8 million of our software platforms. The increase in software-related services is primarily due to sales increases of $3.4 million of software subscription services and $1.0 million of services supporting our Blue Planet software platform and advance software applications. The increase in software platform sales primarily reflects increases of $4.6 million in sales of our OneControl Unified Management System and $1.0 million in sales of our Blue Planet software platform. |

[0000936395-17-000051:mdna:92]
| • | Global Services segment revenue decreased, primarily reflecting sales decreases of $3.9 million of our installation and deployment services and $2.0 million of our network transformation services, partially offset by a sales increase of $1.9 million of our maintenance support and training services. |

[0000936395-17-000051:mdna:93]
[same as prior period, unchanged from 0000936395-17-000038:mdna:94]

[0000936395-17-000051:mdna:94]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| North America | $ | 465,238 |  |  | 63.8 |  | $ | 438,013 |  |  | 65.3 |  | $ | 27,225 |  |  | 6.2 |  |
| EMEA | 96,068 |  |  | 13.2 |  | 104,266 |  |  | 15.5 |  | (8,198 | ) |  | (7.9 | ) |
| CALA | 51,709 |  |  | 7.1 |  | 46,606 |  |  | 7.0 |  | 5,103 |  |  | 10.9 |  |
| APAC | 115,704 |  |  | 15.9 |  | 81,665 |  |  | 12.2 |  | 34,039 |  |  | 41.7 |  |
| Total | $ | 728,719 |  |  | 100.0 |  | $ | 670,550 |  |  | 100.0 |  | $ | 58,169 |  |  | 8.7 |  |

[0000936395-17-000051:mdna:95]
[same as prior period, unchanged from 0000936395-17-000038:mdna:96]

[0000936395-17-000051:mdna:96]
[same as prior period, unchanged from 0000936395-17-000038:mdna:97]

[0000936395-17-000051:mdna:97]
[same as prior period, unchanged from 0000936395-17-000038:mdna:98]

[0000936395-17-000051:mdna:98]
| • | North America revenue primarily reflects increases of $20.5 million within our Networking Platforms segment and $8.2 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $1.5 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $11.5 million of Converged Packet Optical sales and $9.9 million of Packet Networking sales. The revenue increase within Converged Packet Optical primarily reflects an increase of $35.1 million in sales of our Waveserver stackable interconnect system, partially offset by decreases of $13.4 million in sales of our Z-Series Packet-Optical Platform, $6.4 million in sales of our 5430 Reconfigurable Switching System and $2.3 million in sales of our 6500 Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. The revenue increase within Packet Networking primarily reflects increases of $7.3 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $3.1 million in sales of our 8700 Packetwave Platform. The revenue increase for our 3000 and 5000 families of service delivery and aggregation switches primarily reflects increased sales to AT&T and other service providers. The revenue increase within our Software and Software-Related Services segment primarily reflects sales increases of $3.6 million in sales of our OneControl Unified Management System and $2.8 million of our software subscription services. |

[0000936395-17-000051:mdna:99]
[same as prior period, unchanged from 0000936395-17-000038:mdna:101]

[0000936395-17-000051:mdna:100]
| • | EMEA revenue primarily reflects a decrease of $12.2 million within our Networking Platforms segment, partially offset by revenue increases of $2.9 million within our Global Services segment and $1.1 million within our Software and Software-Related Services segment. Our Networking Platforms segment revenue primarily reflects a product line decrease of $7.5 million in Converged Packet Optical sales, primarily due to a decrease of $12.0 million in sales for our 6500 Packet-Optical Platform partially offset by increases of $2.6 million in sales of our 5430 Reconfigurable Switching System and $2.0 million in sales of our Waveserver stackable interconnect system. |

[0000936395-17-000051:mdna:101]
| • | CALA revenue primarily reflects an increase of $12.2 million within our Networking Platforms segment partially offset by a revenue decrease of $7.2 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects a product line increase of $11.0 million of Converged Packet Optical sales primarily due to increased sales of our 6500 Packet-Optical Platform to cable and multiservice operators and certain communication service providers. |

[0000936395-17-000051:mdna:102]
| • | APAC revenue primarily reflects increases of $31.0 million within our Networking Platforms segment, $1.8 million within our Global Services segment and $1.2 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $23.8 million of Converged Packet Optical sales and $8.2 million of Packet Networking sales. The revenue increase within Converged Packet Optical primarily reflects a revenue increase of $18.2 million in sales of our 6500 Packet-Optical Platform, primarily related to sales through our strategic relationship with Ericsson in Australia. The revenue increase within Packet Networking primarily reflects increased sales of $4.5 million of our 3000 and 5000 families of service delivery and aggregation switches and $2.8 million of our 8700 Packetwave Platform to a certain communication service provider in India. APAC revenue has increased meaningfully in recent periods reflecting in part significant revenue growth in India, where we have benefited from service provider customer initiatives to gain subscribers and unprecedented subscriber growth and related network projects. Changes in spending and the timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-17-000051:mdna:103]
[same as prior period, unchanged from 0000936395-17-000038:mdna:105]

[0000936395-17-000051:mdna:104]
[same as prior period, unchanged from 0000936395-17-000038:mdna:106]

[0000936395-17-000051:mdna:105]
[same as prior period, unchanged from 0000936395-17-000038:mdna:107]

[0000936395-17-000051:mdna:106]
[same as prior period, unchanged from 0000936395-17-000038:mdna:108]

[0000936395-17-000051:mdna:107]
[same as prior period, unchanged from 0000936395-17-000038:mdna:109]

[0000936395-17-000051:mdna:108]
[same as prior period, unchanged from 0000936395-17-000038:mdna:110]

[0000936395-17-000051:mdna:109]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 728,719 |  |  | 100.0 |  | $ | 670,550 |  |  | 100.0 |  | $ | 58,169 |  |  | 8.7 |
| Total cost of goods sold | 400,643 |  |  | 55.0 |  | 362,065 |  |  | 54.0 |  | 38,578 |  |  | 10.7 |
| Gross profit | $ | 328,076 |  |  | 45.0 |  | $ | 308,485 |  |  | 46.0 |  | $ | 19,591 |  |  | 6.4 |

[0000936395-17-000051:mdna:110]
[same as prior period, unchanged from 0000936395-17-000038:mdna:112]

[0000936395-17-000051:mdna:111]
[same as prior period, unchanged from 0000936395-17-000038:mdna:113]

[0000936395-17-000051:mdna:112]
[same as prior period, unchanged from 0000936395-17-000038:mdna:114]

[0000936395-17-000051:mdna:113]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 610,742 |  |  | 100.0 |  | $ | 553,450 |  |  | 100.0 |  | $ | 57,292 |  |  | 10.4 |
| Product cost of goods sold | 341,197 |  |  | 55.9 |  | 299,381 |  |  | 54.1 |  | 41,816 |  |  | 14.0 |
| Product gross profit | $ | 269,545 |  |  | 44.1 |  | $ | 254,069 |  |  | 45.9 |  | $ | 15,476 |  |  | 6.1 |

[0000936395-17-000051:mdna:114]
[same as prior period, unchanged from 0000936395-17-000038:mdna:116]

[0000936395-17-000051:mdna:115]
[same as prior period, unchanged from 0000936395-17-000038:mdna:117]

[0000936395-17-000051:mdna:116]
[same as prior period, unchanged from 0000936395-17-000038:mdna:118]

[0000936395-17-000051:mdna:117]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 117,977 |  |  | 100.0 |  | $ | 117,100 |  |  | 100.0 |  | $ | 877 |  |  | 0.7 |  |
| Service cost of goods sold | 59,446 |  |  | 50.4 |  | 62,684 |  |  | 53.5 |  | (3,238 | ) |  | (5.2 | ) |
| Service gross profit | $ | 58,531 |  |  | 49.6 |  | $ | 54,416 |  |  | 46.5 |  | $ | 4,115 |  |  | 7.6 |  |

[0000936395-17-000051:mdna:118]
[same as prior period, unchanged from 0000936395-17-000038:mdna:120]

[0000936395-17-000051:mdna:119]
[same as prior period, unchanged from 0000936395-17-000038:mdna:121]

[0000936395-17-000051:mdna:120]
[same as prior period, unchanged from 0000936395-17-000038:mdna:122]

[0000936395-17-000051:mdna:121]
| • | Gross profit as a percentage of revenue reflects reduced product gross profit partially offset by improved services gross profit. |

[0000936395-17-000051:mdna:122]
| • | Gross profit on products as a percentage of product revenue decreased primarily as a result of market-based price erosion partially offset by product cost reductions and increased software platform sales. |

[0000936395-17-000051:mdna:123]
| • | Gross profit on services as a percentage of services revenue increased primarily due to sales of higher margin software subscription services and maintenance support services. |

[0000936395-17-000051:mdna:124]
[same as prior period, unchanged from 0000936395-17-000038:mdna:126]

[0000936395-17-000051:mdna:125]
[same as prior period, unchanged from 0000936395-17-000038:mdna:127]

[0000936395-17-000051:mdna:126]
[same as prior period, unchanged from 0000936395-17-000038:mdna:128]

[0000936395-17-000051:mdna:127]
[same as prior period, unchanged from 0000936395-17-000038:mdna:129]

[0000936395-17-000051:mdna:128]
[same as prior period, unchanged from 0000936395-17-000038:mdna:130]

[0000936395-17-000051:mdna:129]
[same as prior period, unchanged from 0000936395-17-000038:mdna:131]

[0000936395-17-000051:mdna:130]
[same as prior period, unchanged from 0000936395-17-000038:mdna:132]

[0000936395-17-000051:mdna:131]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition of Cyan on August 3, 2015 and our acquisition of the HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016.

[0000936395-17-000051:mdna:132]
[same as prior period, unchanged from 0000936395-17-000038:mdna:134]

[0000936395-17-000051:mdna:133]
During the third quarter of fiscal 2017, approximately 53% of our operating expense was non-U.S. Dollar denominated,  including expenses in Canadian Dollars, Euros, British Pounds, Indian Rupees, and Brazilian Reais. During the third quarter of fiscal 2017 as compared to the third quarter of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $1.7 million, or 1.0%, as compared to the third quarter of fiscal 2016. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-17-000051:mdna:134]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 117,729 |  |  | 16.2 |  | $ | 116,697 |  |  | 17.4 |  | $ | 1,032 |  |  | 0.9 |  |
| Selling and marketing | 86,739 |  |  | 11.9 |  | 83,732 |  |  | 12.5 |  | 3,007 |  |  | 3.6 |  |
| General and administrative | 35,569 |  |  | 4.9 |  | 34,336 |  |  | 5.1 |  | 1,233 |  |  | 3.6 |  |
| Amortization of intangible assets | 3,837 |  |  | 0.5 |  | 14,529 |  |  | 2.2 |  | (10,692 | ) |  | (73.6 | ) |
| Acquisition and integration costs | — |  |  | — |  | 1,029 |  |  | 0.2 |  | (1,029 | ) |  | (100.0 | ) |
| Restructuring costs | 2,203 |  |  | 0.3 |  | 1,138 |  |  | 0.2 |  | 1,065 |  |  | 93.6 |  |
| Total operating expenses | $ | 246,077 |  |  | 33.8 |  | $ | 251,461 |  |  | 37.6 |  | $ | (5,384 | ) |  | (2.1 | ) |

[0000936395-17-000051:mdna:135]
[same as prior period, unchanged from 0000936395-17-000038:mdna:137]

[0000936395-17-000051:mdna:136]
[same as prior period, unchanged from 0000936395-17-000038:mdna:138]

[0000936395-17-000051:mdna:137]
[same as prior period, unchanged from 0000936395-17-000038:mdna:139]

[0000936395-17-000051:mdna:138]
| • | Research and development expense benefited by $1.8 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $1.0 million. This change primarily reflects increased employee and compensation costs. |

[0000936395-17-000051:mdna:139]
| • | Selling and marketing expense increased by $3.0 million, primarily reflecting increased employee and compensation costs. |

[0000936395-17-000051:mdna:140]
| • | General and administrative expense increased by $1.2 million, primarily reflecting increased employee and compensation costs. |

[0000936395-17-000051:mdna:141]
[same as prior period, unchanged from 0000936395-17-000038:mdna:143]

[0000936395-17-000051:mdna:142]
[same as prior period, unchanged from 0000936395-17-000038:mdna:144]

[0000936395-17-000051:mdna:143]
[same as prior period, unchanged from 0000936395-17-000038:mdna:145]

[0000936395-17-000051:mdna:144]
[same as prior period, unchanged from 0000936395-17-000038:mdna:146]

[0000936395-17-000051:mdna:145]
[same as prior period, unchanged from 0000936395-17-000038:mdna:147]

[0000936395-17-000051:mdna:146]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (848 | ) |  | (0.1 | ) |  | $ | (3,647 | ) |  | (0.5 | ) |  | $ | 2,799 |  |  | 76.7 |  |
| Interest expense | $ | 13,415 |  |  | 1.8 |  |  | $ | 15,967 |  |  | 2.4 |  |  | $ | (2,552 | ) |  | (16.0 | ) |
| Provision for income taxes | $ | 7,726 |  |  | 1.1 |  |  | $ | 3,864 |  |  | 0.6 |  |  | $ | 3,862 |  |  | 99.9 |  |

[0000936395-17-000051:mdna:147]
[same as prior period, unchanged from 0000936395-17-000038:mdna:149]

[0000936395-17-000051:mdna:148]
[same as prior period, unchanged from 0000936395-17-000038:mdna:150]

[0000936395-17-000051:mdna:149]
[same as prior period, unchanged from 0000936395-17-000038:mdna:151]

[0000936395-17-000051:mdna:150]
| • | Interest and other income (loss), net primarily reflects a $3.5 million gain in foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-17-000051:mdna:151]
| • | Interest expense decreased primarily due to a reduction in our aggregate outstanding debt due to the refinancing of our term loans during the second quarter of fiscal 2017 and the maturity of our outstanding 0.875% Convertible Senior Notes on June 15, 2017. For additional information about our term loans and convertible notes, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000051:mdna:152]
[same as prior period, unchanged from 0000936395-17-000038:mdna:154]

[0000936395-17-000051:mdna:153]
Nine months ended July 31, 2017 compared to the nine months ended July 31, 2016

[0000936395-17-000051:mdna:154]
[same as prior period, unchanged from 0000936395-17-000038:mdna:156]

[0000936395-17-000051:mdna:155]
During the first nine months of fiscal 2017, approximately 18.0% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Brazilian Reais, British Pounds, Argentina Pesos and Japanese Yen. During the first nine months of fiscal 2017, as compared to the first nine months of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $6.7 million or 0.3%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000051:mdna:156]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,421,315 |  |  | 69.1 |  | $ | 1,291,956 |  |  | 68.6 |  | $ | 129,359 |  |  | 10.0 |  |
| Packet Networking | 220,641 |  |  | 10.7 |  | 180,437 |  |  | 9.6 |  | 40,204 |  |  | 22.3 |  |
| Optical Transport | 11,822 |  |  | 0.6 |  | 30,215 |  |  | 1.6 |  | (18,393 | ) |  | (60.9 | ) |
| Total Networking Platforms | 1,653,778 |  |  | 80.4 |  | 1,502,608 |  |  | 79.8 |  | 151,170 |  |  | 10.1 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 48,587 |  |  | 2.4 |  | 32,409 |  |  | 1.7 |  | 16,178 |  |  | 49.9 |  |
| Software-Related Services | 70,760 |  |  | 3.4 |  | 55,059 |  |  | 2.9 |  | 15,701 |  |  | 28.5 |  |
| Total Software and Software-Related Services | 119,347 |  |  | 5.8 |  | 87,468 |  |  | 4.6 |  | 31,879 |  |  | 36.4 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 171,133 |  |  | 8.3 |  | 169,123 |  |  | 9.0 |  | 2,010 |  |  | 1.2 |  |
| Installation and Deployment | 84,011 |  |  | 4.1 |  | 92,317 |  |  | 4.9 |  | (8,306 | ) |  | (9.0 | ) |
| Consulting and Network Design | 28,969 |  |  | 1.4 |  | 32,866 |  |  | 1.7 |  | (3,897 | ) |  | (11.9 | ) |
| Total Global Services | 284,113 |  |  | 13.8 |  | 294,306 |  |  | 15.6 |  | (10,193 | ) |  | (3.5 | ) |
| Consolidated revenue | $ | 2,057,238 |  |  | 100.0 |  | $ | 1,884,382 |  |  | 100.0 |  | $ | 172,856 |  |  | 9.2 |  |

[0000936395-17-000051:mdna:157]
[same as prior period, unchanged from 0000936395-17-000038:mdna:159]

[0000936395-17-000051:mdna:158]
[same as prior period, unchanged from 0000936395-17-000038:mdna:160]

[0000936395-17-000051:mdna:159]
[same as prior period, unchanged from 0000936395-17-000038:mdna:161]

[0000936395-17-000051:mdna:160]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $129.4 million of our Converged Packet Optical products and $40.2 million of our Packet Networking products, partially offset by a product line sales decrease of $18.4 million in sales of our Optical Transport products. |

[0000936395-17-000051:mdna:161]
| ◦ | Converged Packet Optical sales primarily reflect increases of $81.6 million of our 6500 Packet-Optical Platform, $68.8 million of our Waveserver stackable interconnect system, $14.3 million of our 5430 Reconfigurable Switching System and $2.1 million of our OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by sales decreases of $31.2 million of our Z-Series Packet-Optical Platform and $6.2 million of our CoreDirector® Multiservice Optical Switches. |

[0000936395-17-000051:mdna:162]
| ◦ | Packet Networking sales primarily reflect increases of $33.7 million of our 3000 and 5000 families of service delivery and aggregation switches and $6.2 million of our 8700 Packetwave Platform. |

[0000936395-17-000051:mdna:163]
[same as prior period, unchanged from 0000936395-17-000038:mdna:165]

[0000936395-17-000051:mdna:164]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $15.7 million in software-related services and $16.2 million of our software platforms. The increase in software-related services is primarily due to sales increases of $10.7 million of software subscription services, $3.4 million of services supporting our Blue Planet software platform and advance software applications, and $1.2 million of software-enabled services. The increase in software platform sales primarily reflects increases of $7.8 million in sales of our Blue Planet software platform and advanced software applications and $6.7 million in sales of our OneControl Unified Management System. |

[0000936395-17-000051:mdna:165]
| • | Global Services segment revenue decreased, primarily reflecting sales decreases of $8.3 million of our installation and deployment services and $3.9 million of our consulting and network design services, partially offset by a sales increase of $2.0 million of our maintenance support and training services. |

[0000936395-17-000051:mdna:166]
[same as prior period, unchanged from 0000936395-17-000038:mdna:168]

[0000936395-17-000051:mdna:167]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,295,539 |  |  | 63.0 |  | $ | 1,226,222 |  |  | 65.1 |  | $ | 69,317 |  |  | 5.7 |  |
| EMEA | 293,387 |  |  | 14.3 |  | 281,163 |  |  | 14.9 |  | 12,224 |  |  | 4.3 |  |
| CALA | 120,826 |  |  | 5.8 |  | 148,312 |  |  | 7.9 |  | (27,486 | ) |  | (18.5 | ) |
| APAC | 347,486 |  |  | 16.9 |  | 228,685 |  |  | 12.1 |  | 118,801 |  |  | 51.9 |  |
| Total | $ | 2,057,238 |  |  | 100.0 |  | $ | 1,884,382 |  |  | 100.0 |  | $ | 172,856 |  |  | 9.2 |  |

[0000936395-17-000051:mdna:168]
[same as prior period, unchanged from 0000936395-17-000038:mdna:170]

[0000936395-17-000051:mdna:169]
[same as prior period, unchanged from 0000936395-17-000038:mdna:171]

[0000936395-17-000051:mdna:170]
[same as prior period, unchanged from 0000936395-17-000038:mdna:172]

[0000936395-17-000051:mdna:171]
| • | North America revenue primarily reflects increases of $53.8 million within our Networking Platforms segment and $23.7 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $8.2 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $37.1 million of Converged Packet Optical sales and $20.5 million of Packet Networking sales, partially offset by a product line decrease of $3.8 million in Optical Transport sales. The revenue increase within Converged Packet Optical sales primarily reflects increases of $61.2 million in sales of our Waveserver stackable interconnect system and $10.4 million in sales of our 6500 Packet-Optical Platform, partially offset by a decrease of $30.1 million in sales of our Z-Series Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. The revenue increase for our 6500 Packet-Optical Platform primarily reflects increased sales to service providers, partially offset by decreases in sales to AT&T, certain Web-scale providers and to a cable and multiservice operator that was acquired |

[0000936395-17-000051:mdna:172]
[same as prior period, unchanged from 0000936395-17-000038:mdna:175]

[0000936395-17-000051:mdna:173]
during the third quarter of 2016. The revenue increase within Packet Networking primarily reflects an increase of $19.5 million in sales of our 3000 and 5000 families of service delivery and aggregation switches to AT&T and other communication service providers. The revenue increase within our Software and Software-Related Services segment primarily reflects sales increases of $9.4 million of our software subscription services, $5.3 million in sales of our Blue Planet software platform, $4.9 million of our OneControl Unified Management System and $2.1 million of services supporting our Blue Planet software platform and advance software applications.

[0000936395-17-000051:mdna:174]
| • | EMEA revenue primarily reflects increases of $10.6 million within our Networking Platforms segment and $3.7 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $2.1 million within our Global Services segment. Our Networking Platforms segment revenue primarily reflects a product line increase of $15.3 million in Converged Packet Optical sales, primarily due to increased sales of $9.2 million of our 6500 Packet-Optical Platform and $6.0 million of our Waveserver stackable interconnect system. |

[0000936395-17-000051:mdna:175]
| • | CALA revenue primarily reflects decreases of $23.0 million within our Networking Platforms segment and $4.8 million within our Global Services segment. The revenue decrease within our Networking Platforms segment primarily reflects product line decreases of $22.3 million of Converged Packet Optical sales and $4.3 million in Optical Transport sales partially offset by a product line increase of $3.6 million of Packet Networking sales. |

[0000936395-17-000051:mdna:176]
| • | APAC revenue primarily reflects increases of $109.8 million within our Networking Platforms segment, $4.8 million within our Global Services segment and $4.2 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $99.3 million of Converged Packet Optical sales and $13.2 million of Packet Networking sales, partially offset by a product line decrease of $2.7 million in Optical Transport sales. The revenue increase within Converged Packet Optical reflects an increase of $66.5 million in sales of our 6500 Packet-Optical Platform primarily due to increases in sales through our strategic relationship with Ericsson in Australia, sales to Reliance Jio Infocomm in India and sales to service providers in Japan. The revenue increase within Converged Packet Optical also reflects an increase of $30.7 million of our 5430 Reconfigurable Switching System sales primarily due to increased sales to Reliance Jio Infocomm in India. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-17-000051:mdna:177]
[same as prior period, unchanged from 0000936395-17-000038:mdna:179]

[0000936395-17-000051:mdna:178]
[same as prior period, unchanged from 0000936395-17-000038:mdna:180]

[0000936395-17-000051:mdna:179]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 2,057,238 |  |  | 100.0 |  | $ | 1,884,382 |  |  | 100.0 |  | $ | 172,856 |  |  | 9.2 |
| Total cost of goods sold | 1,137,137 |  |  | 55.3 |  | 1,041,354 |  |  | 55.3 |  | 95,783 |  |  | 9.2 |
| Gross profit | $ | 920,101 |  |  | 44.7 |  | $ | 843,028 |  |  | 44.7 |  | $ | 77,073 |  |  | 9.1 |

[0000936395-17-000051:mdna:180]
[same as prior period, unchanged from 0000936395-17-000038:mdna:182]

[0000936395-17-000051:mdna:181]
[same as prior period, unchanged from 0000936395-17-000038:mdna:183]

[0000936395-17-000051:mdna:182]
[same as prior period, unchanged from 0000936395-17-000038:mdna:184]

[0000936395-17-000051:mdna:183]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,702,365 |  |  | 100.0 |  | $ | 1,535,017 |  |  | 100.0 |  | $ | 167,348 |  |  | 10.9 |
| Product cost of goods sold | 955,303 |  |  | 56.1 |  | 851,641 |  |  | 55.5 |  | 103,662 |  |  | 12.2 |
| Product gross profit | $ | 747,062 |  |  | 43.9 |  | $ | 683,376 |  |  | 44.5 |  | $ | 63,686 |  |  | 9.3 |

[0000936395-17-000051:mdna:184]
[same as prior period, unchanged from 0000936395-17-000038:mdna:186]

[0000936395-17-000051:mdna:185]
[same as prior period, unchanged from 0000936395-17-000038:mdna:187]

[0000936395-17-000051:mdna:186]
[same as prior period, unchanged from 0000936395-17-000038:mdna:188]

[0000936395-17-000051:mdna:187]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 354,873 |  |  | 100.0 |  | $ | 349,365 |  |  | 100.0 |  | $ | 5,508 |  |  | 1.6 |  |
| Service cost of goods sold | 181,834 |  |  | 51.2 |  | 189,713 |  |  | 54.3 |  | (7,879 | ) |  | (4.2 | ) |
| Service gross profit | $ | 173,039 |  |  | 48.8 |  | $ | 159,652 |  |  | 45.7 |  | $ | 13,387 |  |  | 8.4 |  |

[0000936395-17-000051:mdna:188]
[same as prior period, unchanged from 0000936395-17-000038:mdna:190]

[0000936395-17-000051:mdna:189]
[same as prior period, unchanged from 0000936395-17-000038:mdna:191]

[0000936395-17-000051:mdna:190]
[same as prior period, unchanged from 0000936395-17-000038:mdna:192]

[0000936395-17-000051:mdna:191]
[same as prior period, unchanged from 0000936395-17-000038:mdna:123]

[0000936395-17-000051:mdna:192]
| • | Gross profit on products as a percentage of product revenue decreased, primarily as a result of market-based price erosion partially offset by product cost reductions and increased software platform sales. |

[0000936395-17-000051:mdna:193]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to sales of higher margin software subscription services and maintenance support services. |

[0000936395-17-000051:mdna:194]
[same as prior period, unchanged from 0000936395-17-000038:mdna:196]

[0000936395-17-000051:mdna:195]
During the first nine months of fiscal 2017, approximately 52% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, British Pounds, Euros, Indian Rupees and Brazilian Reais. During the first nine months of fiscal 2017, there was minimal impact of foreign currency exchange rates to our operating expense, in comparison to the first nine months of fiscal 2016. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-17-000051:mdna:196]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 356,221 |  |  | 17.3 |  | $ | 339,346 |  |  | 18.0 |  | $ | 16,875 |  |  | 5.0 |  |
| Selling and marketing | 260,292 |  |  | 12.7 |  | 252,878 |  |  | 13.4 |  | 7,414 |  |  | 2.9 |  |
| General and administrative | 106,423 |  |  | 5.2 |  | 100,681 |  |  | 5.3 |  | 5,742 |  |  | 5.7 |  |
| Amortization of intangible assets | 29,368 |  |  | 1.4 |  | 46,957 |  |  | 2.5 |  | (17,589 | ) |  | (37.5 | ) |
| Acquisition and integration costs | — |  |  | — |  | 4,613 |  |  | 0.2 |  | (4,613 | ) |  | (100.0 | ) |
| Restructuring costs | 8,874 |  |  | 0.4 |  | 2,057 |  |  | 0.1 |  | 6,817 |  |  | 331.4 |  |
| Total operating expenses | $ | 761,178 |  |  | 37.0 |  | $ | 746,532 |  |  | 39.6 |  | $ | 14,646 |  |  | 2.0 |  |

[0000936395-17-000051:mdna:197]
[same as prior period, unchanged from 0000936395-17-000038:mdna:199]

[0000936395-17-000051:mdna:198]
[same as prior period, unchanged from 0000936395-17-000038:mdna:200]

[0000936395-17-000051:mdna:199]
[same as prior period, unchanged from 0000936395-17-000038:mdna:201]

[0000936395-17-000051:mdna:200]
| • | Research and development expense increased by $16.9 million. This increase primarily reflects increases of $9.7 million in employee and compensation costs, $7.0 million in facilities and information technology costs and $1.4 million of depreciation costs. These increases were partially offset by a decrease of $1.0 million in professional services. |

[0000936395-17-000051:mdna:201]
| • | Selling and marketing expense increased by $7.4 million, primarily reflecting increases of $3.3 million in employee and compensation costs, $1.4 million in facilities and information technology costs, $1.2 million in technology and related costs and $1.0 million in selling and marketing costs. |

[0000936395-17-000051:mdna:202]
| • | General and administrative expense increased by $5.7 million, primarily reflecting increases of $3.8 million for professional services and legal fees, $1.3 million for employee and compensation costs, and $1.2 million for facilities and information technology costs. |

[0000936395-17-000051:mdna:203]
[same as prior period, unchanged from 0000936395-17-000038:mdna:205]

[0000936395-17-000051:mdna:204]
[same as prior period, unchanged from 0000936395-17-000038:mdna:206]

[0000936395-17-000051:mdna:205]
| • | Restructuring costs increased due to unfavorable lease commitments and relocation costs incurred in connection with the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000051:mdna:206]
[same as prior period, unchanged from 0000936395-17-000038:mdna:208]

[0000936395-17-000051:mdna:207]
[same as prior period, unchanged from 0000936395-17-000038:mdna:209]

[0000936395-17-000051:mdna:208]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (3,396 | ) |  | (0.2 | ) |  | $ | (11,456 | ) |  | (0.6 | ) |  | $ | 8,060 |  |  | 70.4 |
| Interest expense | $ | 41,926 |  |  | 2.0 |  |  | $ | 41,285 |  |  | 2.2 |  |  | $ | 641 |  |  | 1.6 |
| Provision for income taxes | $ | 11,704 |  |  | 0.6 |  |  | $ | 7,758 |  |  | 0.4 |  |  | $ | 3,946 |  |  | 50.9 |

[0000936395-17-000051:mdna:209]
[same as prior period, unchanged from 0000936395-17-000038:mdna:211]

[0000936395-17-000051:mdna:210]
[same as prior period, unchanged from 0000936395-17-000038:mdna:212]

[0000936395-17-000051:mdna:211]
[same as prior period, unchanged from 0000936395-17-000038:mdna:213]

[0000936395-17-000051:mdna:212]
[same as prior period, unchanged from 0000936395-17-000038:mdna:214]

[0000936395-17-000051:mdna:213]
| • | Interest expense remained relatively unchanged. |

[0000936395-17-000051:mdna:214]
| • | Provision for income taxes increased primarily due to increased foreign and state tax expense. |

[0000936395-17-000051:mdna:215]
[same as prior period, unchanged from 0000936395-17-000038:mdna:217]

[0000936395-17-000051:mdna:216]
[same as prior period, unchanged from 0000936395-17-000038:mdna:218]

[0000936395-17-000051:mdna:217]
|  | Quarter Ended July 31, |  |  |  |
|  | 2017 |  | 2016 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 159,649 |  |  | $ | 150,521 |  |  | $ | 9,128 |  |  | 6.1 |
| Software and Software-Related Services | $ | 11,133 |  |  | $ | 2,412 |  |  | $ | 8,721 |  |  | 361.6 |
| Global Services | $ | 39,565 |  |  | $ | 38,855 |  |  | $ | 710 |  |  | 1.8 |

[0000936395-17-000051:mdna:218]
[same as prior period, unchanged from 0000936395-17-000038:mdna:220]

[0000936395-17-000051:mdna:219]
[same as prior period, unchanged from 0000936395-17-000038:mdna:221]

[0000936395-17-000051:mdna:220]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, slightly offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs as a result of the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000051:mdna:221]
| • | Software and Software-Related Services segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, slightly offset by increased research and development costs. Research and development costs primarily reflect increased expense relating to the continued development of our Blue Planet software platform. |

[0000936395-17-000051:mdna:222]
| • | Global Services segment profit increased, primarily due to improved gross margin on consulting and network design services offset by lower sales volume. |

[0000936395-17-000051:mdna:223]
[same as prior period, unchanged from 0000936395-17-000038:mdna:225]

[0000936395-17-000051:mdna:224]
|  | Nine Months Ended July 31, |  |  |  |  |
|  | 2017 |  | 2016 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 423,859 |  |  | $ | 390,109 |  |  | $ | 33,750 |  |  | 8.7 |
| Software and Software-Related Services | $ | 23,384 |  |  | $ | (970 | ) |  | $ | 24,354 |  |  | NM** |
| Global Services | $ | 116,637 |  |  | $ | 114,543 |  |  | $ | 2,094 |  |  | 1.8 |

[0000936395-17-000051:mdna:225]
[same as prior period, unchanged from 0000936395-17-000038:mdna:227]

[0000936395-17-000051:mdna:226]
[same as prior period, unchanged from 0000936395-17-000038:mdna:228]

[0000936395-17-000051:mdna:227]
**            Not meaningful

[0000936395-17-000051:mdna:228]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, slightly offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs as a result of the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000051:mdna:229]
[same as prior period, unchanged from 0000936395-17-000038:mdna:230]

[0000936395-17-000051:mdna:230]
[same as prior period, unchanged from 0000936395-17-000038:mdna:231]

[0000936395-17-000051:mdna:231]
[same as prior period, unchanged from 0000936395-17-000038:mdna:232]

[0000936395-17-000051:mdna:232]
For the nine months ended July 31, 2017, we generated $96.3 million in cash to fund our operating needs, as our net income (adjusted for non-cash charges) of $289.3 million exceeded our working capital requirements of $193.0 million. The increase in working capital was primarily driven by inventory increases of $93.9 million and an increase in our accounts receivable of $80.7 million. For additional details, see the discussion below entitled “Cash from Operations.”

[0000936395-17-000051:mdna:233]
Despite our cash generated from operations, our total cash, cash equivalents and investments decreased by $288.9 million during the first nine months of fiscal 2017. This decrease principally reflects the use of cash to fund the repurchase of $46.3 million in aggregate principal amount outstanding of our 0.875 % Convertible Senior Notes, which matured on June 15, 2017 (the “2017 Notes”), repayment at maturity of the remaining $185.3 million in aggregate principal amount outstanding of the 2017 Notes, and $93.6 million for the refinancing of our existing 2019 Term Loan and 2021 Term Loan into a new 2022 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information relating to these transactions. The decrease also reflects cash used in investing activities for capital expenditures totaling $76.0 million, and our settlement of certain foreign currency forward contracts of $1.6 million. Proceeds from the issuance of equity under our employee stock purchase plans provided approximately $20.4 million in cash during the period. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-17-000051:mdna:234]
|  | July 31, 2017 |  | October 31, 2016 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 559,540 |  |  | $ | 777,615 |  |  | $ | (218,075 | ) |
| Short-term investments in marketable debt securities | 234,743 |  |  | 275,248 |  |  | (40,505 | ) |
| Long-term investments in marketable debt securities | 59,874 |  |  | 90,172 |  |  | (30,298 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 854,157 |  |  | $ | 1,143,035 |  |  | $ | (288,878 | ) |

[0000936395-17-000051:mdna:235]
Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of July 31, 2017 totaled $854.2 million, as well as our ABL Credit Facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 31, 2017, letters of credit totaling $74.1 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2017.

[0000936395-17-000051:mdna:236]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $45.4 million as of July 31, 2017. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-17-000051:mdna:237]
As more fully described in Note 22 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, following the settlement of an exchange offer on August 2, 2017, approximately $288.7 million in aggregate principal amount at maturity of Original Notes were exchanged for New Notes, which provide us with the option, at our election, to settle conversions for cash, shares of our common stock, or a combination of cash and shares. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash.

[0000936395-17-000051:mdna:238]
[same as prior period, unchanged from 0000936395-17-000038:mdna:240]

[0000936395-17-000051:mdna:239]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations, including the settlement of the principal amount of the New Notes in cash upon any conversions prior to maturity, through at least the next 12 months.

[0000936395-17-000051:mdna:240]
[same as prior period, unchanged from 0000936395-17-000038:mdna:242]

[0000936395-17-000051:mdna:241]
The following sections set forth the components of our $96.3 million of cash generated from operating activities during the first nine months of fiscal 2017:

[0000936395-17-000051:mdna:242]
[same as prior period, unchanged from 0000936395-17-000038:mdna:244]

[0000936395-17-000051:mdna:243]
[same as prior period, unchanged from 0000936395-17-000038:mdna:245]

[0000936395-17-000051:mdna:244]
|  | Nine months ended |
|  | July 31, 2017 |
| Net income | $ | 101,897 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 55,873 |  |
| Share-based compensation costs | 36,843 |  |
| Amortization of intangible assets | 39,721 |  |
| Provision for inventory excess and obsolescence | 28,727 |  |
| Provision for warranty | 5,188 |  |
| Other | 21,076 |  |
| Net income (adjusted for non-cash charges) | $ | 289,325 |  |

[0000936395-17-000051:mdna:245]
[same as prior period, unchanged from 0000936395-17-000038:mdna:247]

[0000936395-17-000051:mdna:246]
We used $193.0 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-17-000051:mdna:247]
|  | Nine months ended |
|  | July 31, 2017 |
| Cash used in accounts receivable | $ | (80,652 | ) |
| Cash used in inventories | (93,896 | ) |
| Cash used in prepaid expenses and other | (26,450 | ) |
| Cash used in accounts payable, accruals and other obligations | (5,960 | ) |
| Cash provided by deferred revenue | 13,978 |  |
| Total cash used for working capital | $ | (192,980 | ) |

[0000936395-17-000051:mdna:248]
[same as prior period, unchanged from 0000936395-17-000038:mdna:250]

[0000936395-17-000051:mdna:249]
| • | The $80.7 million of cash used by accounts receivable during the first nine months of fiscal 2017 reflects increased sales volume; |

[0000936395-17-000051:mdna:250]
| • | The $93.9 million of cash used in inventory during the first nine months of fiscal 2017 primarily reflects increases in finished goods to meet customer delivery schedules and deferred costs of sales awaiting customer acceptance; |

[0000936395-17-000051:mdna:251]
| • | Cash used in prepaid expense and other during the first nine months of fiscal 2017 was $26.5 million, primarily reflecting higher prepaid value added taxes and higher deferred deployment expense; |

[0000936395-17-000051:mdna:252]
| • | The $6.0 million of cash used in accounts payable, accruals and other obligations during the first nine months of fiscal 2017 primarily reflects a slight increase in payments to our suppliers; and |

[0000936395-17-000051:mdna:253]
| • | The $14.0 million of cash provided by deferred revenue during the first nine months of fiscal 2017 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-17-000051:mdna:254]
Our days sales outstanding (DSOs) for the first nine months of fiscal 2017 were 86 days, and our inventory turns for the first nine months of fiscal 2017 were 4.6.

[0000936395-17-000051:mdna:255]
[same as prior period, unchanged from 0000936395-17-000038:mdna:257]

[0000936395-17-000051:mdna:256]
[same as prior period, unchanged from 0000936395-17-000038:mdna:258]

[0000936395-17-000051:mdna:257]
|  | Nine months ended |
|  | July 31, 2017 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 1,824 |  |
| 3.75% Convertible Senior Notes due October 15, 2018(2) | 6,562 |  |
| 4.0% Convertible Senior Notes due December 15, 2020(3) | 7,500 |  |
| Term Loan due July 15, 2019(4) | 2,342 |  |
| Term Loan due April 25, 2021(5) | 2,702 |  |
| Term Loan due January 30, 2022 (6) | 6,584 |  |
| Interest rate swaps(7) | 2,727 |  |
| ABL Credit Facility(8) | 1,180 |  |
| Capital leases | 2,440 |  |
| Cash paid during period | $ | 33,861 |  |

[0000936395-17-000051:mdna:258]
| (1) | The final interest payment owing on our 0.875% Convertible Senior Notes due June 15, 2017 was paid during the third quarter of fiscal 2017. |

[0000936395-17-000051:mdna:259]
| (2) | Interest on our outstanding 3.75% Convertible Senior Notes due October 15, 2018 is payable on April 15 and October 15 of each year. |

[0000936395-17-000051:mdna:260]
| (3) | Interest on our outstanding 4.0% Convertible Senior Notes due December 15, 2020 is payable on June 15 and December 15 of each year. |

[0000936395-17-000051:mdna:261]
| (4) | Interest on the 2019 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bore interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. On the first day of our second quarter of fiscal 2017, we refinanced and replaced this term loan with the 2022 |

[0000936395-17-000051:mdna:262]
[same as prior period, unchanged from 0000936395-17-000038:mdna:267]

[0000936395-17-000051:mdna:263]
Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information.

[0000936395-17-000051:mdna:264]
[same as prior period, unchanged from 0000936395-17-000038:mdna:264]

[0000936395-17-000051:mdna:265]
| (6) | Interest on the 2022 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of the third quarter of fiscal 2017, the interest rate on the 2022 Term Loan was 3.73%. |

[0000936395-17-000051:mdna:266]
| (7) | Prior to the term loan refinancing, payments on our interest rate swaps were variable and effectively fixed the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. In connection with the refinancing of the 2019 and 2021 Term Loans into the 2022 Term Loan, in order to align our interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, we reduced the total outstanding value of our interest rate swaps and also entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during the periods described above will be 4.25%, 4.25% and 4.75%, respectively. |

[0000936395-17-000051:mdna:267]
| (8) | During the first nine months of fiscal 2017, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.2 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-17-000051:mdna:268]
For additional information about our convertible notes and term loans (including the refinancing of our 2019 and 2021 Term Loans into the 2022 Term Loan), ABL Credit Facility and interest rate swaps, see Notes 14, 16 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-17-000051:mdna:269]
[same as prior period, unchanged from 0000936395-17-000038:mdna:271]

[0000936395-17-000051:mdna:270]
The following is a summary of our future minimum payments under contractual obligations as of July 31, 2017 (in thousands):

[0000936395-17-000051:mdna:271]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 567,127 |  |  | $ | — |  |  | $ | 350,000 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on Term Loan due January 30, 2022 (2) | 399,000 |  |  | 4,000 |  |  | 8,000 |  |  | 8,000 |  |  | 379,000 |  |
| Interest due on convertible notes | 45,938 |  |  | 20,625 |  |  | 21,563 |  |  | 3,750 |  |  | — |  |
| Interest due on Term Loan due January 30, 2022 (2) | 66,838 |  |  | 15,008 |  |  | 29,602 |  |  | 22,228 |  |  | — |  |
| Payments due under interest rate swaps (2) | 7,050 |  |  | 2,034 |  |  | 3,461 |  |  | 1,555 |  |  | — |  |
| Operating leases (3) | 134,891 |  |  | 30,829 |  |  | 39,066 |  |  | 27,846 |  |  | 37,150 |  |
| Purchase obligations (4) | 250,356 |  |  | 250,356 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 3,576 |  |  | 1,717 |  |  | 1,859 |  |  | — |  |  | — |  |
| Capital leases— buildings (5) | 129,670 |  |  | 7,768 |  |  | 15,656 |  |  | 16,142 |  |  | 90,104 |  |
| Other obligations | 2,132 |  |  | 1,033 |  |  | 1,099 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,606,578 |  |  | $ | 333,370 |  |  | $ | 470,306 |  |  | $ | 296,648 |  |  | $ | 506,254 |  |

[0000936395-17-000051:mdna:272]
[same as prior period, unchanged from 0000936395-17-000038:mdna:274]

[0000936395-17-000051:mdna:273]
| (1) | Includes the accretion of the principal amount on our outstanding 4.0% Convertible Senior Notes due December 15, 2020 payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-17-000051:mdna:274]
[same as prior period, unchanged from 0000936395-17-000038:mdna:276]

[0000936395-17-000051:mdna:275]
[same as prior period, unchanged from 0000936395-17-000038:mdna:277]

[0000936395-17-000051:mdna:276]
[same as prior period, unchanged from 0000936395-17-000038:mdna:278]

[0000936395-17-000051:mdna:277]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-17-000051:mdna:278]
| (6) | As of July 31, 2017, we also had approximately $15.6 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-17-000051:mdna:279]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of July 31, 2017 (in thousands):

[0000936395-17-000051:mdna:280]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 77,803 |  |  | $ | 40,092 |  |  | $ | 16,739 |  |  | $ | 11,885 |  |  | $ | 9,087 |  |

[0000936395-17-000051:mdna:281]
[same as prior period, unchanged from 0000936395-17-000038:mdna:283]

[0000936395-17-000051:mdna:282]
[same as prior period, unchanged from 0000936395-17-000038:mdna:284]

[0000936395-17-000051:mdna:283]
[same as prior period, unchanged from 0000936395-17-000038:mdna:285]

[0000936395-17-000051:mdna:284]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-17-000051:mdna:285]
[same as prior period, unchanged from 0000936395-17-000038:mdna:287]

[0000936395-17-000051:mdna:286]
[same as prior period, unchanged from 0000936395-17-000038:mdna:288]

[0000936395-17-000051:mdna:287]
[same as prior period, unchanged from 0000936395-17-000038:mdna:289]

[0000936395-17-000051:mdna:288]
[same as prior period, unchanged from 0000936395-17-000038:mdna:290]

[0000936395-17-000051:mdna:289]
[same as prior period, unchanged from 0000936395-17-000038:mdna:291]

[0000936395-17-000051:mdna:290]
[same as prior period, unchanged from 0000936395-17-000038:mdna:292]

[0000936395-17-000051:mdna:291]
[same as prior period, unchanged from 0000936395-17-000038:mdna:293]

[0000936395-17-000051:mdna:292]
Our total deferred revenue for products was $61.9 million and $45.2 million as of July 31, 2017 and October 31, 2016, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $135.6 million and $137.7 million as of July 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000051:mdna:293]
[same as prior period, unchanged from 0000936395-17-000038:mdna:295]

[0000936395-17-000051:mdna:294]
[same as prior period, unchanged from 0000936395-17-000038:mdna:296]

[0000936395-17-000051:mdna:295]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 19 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of July 31, 2017, total unrecognized compensation expense was $76.5 million: (i) $0.2 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.1 years; and (ii) $76.3 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.

[0000936395-17-000051:mdna:296]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be

[0000936395-17-000051:mdna:297]
considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

[0000936395-17-000051:mdna:298]
[same as prior period, unchanged from 0000936395-17-000038:mdna:299]

[0000936395-17-000051:mdna:299]
[same as prior period, unchanged from 0000936395-17-000038:mdna:300]

[0000936395-17-000051:mdna:300]
For fiscal 2017, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2017. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for cash incentive compensation in any interim period in fiscal 2017 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $45.0 million of expense in the first nine months of fiscal 2017 associated with our cash incentive bonus plan for fiscal 2017.

[0000936395-17-000051:mdna:301]
[same as prior period, unchanged from 0000936395-17-000038:mdna:303]

[0000936395-17-000051:mdna:302]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $28.7 million and $26.7 million in the first nine months of fiscal 2017 and 2016, respectively. The charges in fiscal 2017 primarily were related to a decrease in the forecasted demand for certain Networking Platform products. Our inventory net of allowance for excess and obsolescence was $276.4 million and $211.3 million as of July 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000051:mdna:303]
[same as prior period, unchanged from 0000936395-17-000038:mdna:305]

[0000936395-17-000051:mdna:304]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable, which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $653.2 million and $576.2 million as of July 31, 2017 and October 31, 2016, respectively. Our allowance for doubtful accounts was $3.6 million and $4.0 million as of July 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000051:mdna:305]
[same as prior period, unchanged from 0000936395-17-000038:mdna:307]

[0000936395-17-000051:mdna:306]
[same as prior period, unchanged from 0000936395-17-000038:mdna:308]

[0000936395-17-000051:mdna:307]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, which we adopted in the first quarter in fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of July 31, 2017 and October 31, 2016, the goodwill balance was $267.8 million and $267.0 million, respectively.

[0000936395-17-000051:mdna:308]
[same as prior period, unchanged from 0000936395-17-000038:mdna:310]

[0000936395-17-000051:mdna:309]
Our long-lived assets include: equipment, building, furniture and fixtures; finite-lived intangible assets; in-process research and development; and maintenance spares. As of July 31, 2017 and October 31, 2016, these assets totaled $468.4 million and $484.7 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups, which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-17-000051:mdna:310]
[same as prior period, unchanged from 0000936395-17-000038:mdna:312]

[0000936395-17-000051:mdna:311]
We provide a valuation allowance for our deferred tax assets in excess of deferred tax liabilities because we have concluded that it is more likely than not that such deferred tax assets will ultimately not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. We assess available positive and negative evidence regarding our ability to realize our deferred tax assets and record a valuation allowance when it is more likely than not that deferred tax assets will not be realized. To form a conclusion, management considers our recent financial results and trends and makes judgments and estimates related to projections of profitability, the timing and extent of the use of net operating loss carryforwards, and tax planning strategies. At July 31, 2017, we were not in a three-year cumulative loss position in the United States. However, management determined that a valuation allowance is still necessary, due to, among other things, the relatively low level of cumulative pre-tax income during this period — cumulative 12-quarter profit was only recently achieved in the second half of fiscal 2016 — and our lengthy history of operating losses. We are in the process of completing the annual update to our budget and forecasting of expected financial performance for future fiscal periods, which we expect to finalize in the fourth quarter of fiscal 2017. We will consider these items together with our actual performance for fiscal 2017 as part of our ongoing evaluation of whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements. The valuation allowance balance at July 31, 2017 was $1.4 billion.

[0000936395-17-000051:mdna:312]
[same as prior period, unchanged from 0000936395-17-000038:mdna:314]

[0000936395-17-000051:mdna:313]
Our liability for product warranties, included in other accrued liabilities, was $44.3 million and $52.3 million as of July 31, 2017 and October 31, 2016, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $5.2 million and $13.1 million for the first nine months of fiscal 2017 and 2016, respectively. See Note 13 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
