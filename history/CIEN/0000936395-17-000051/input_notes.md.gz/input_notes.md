# CIEN notes — 0000936395-17-000051


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-17-000051:notes:1]
ABL CREDIT FACILITY

[0000936395-17-000051:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-17-000051:notes:3]
As of July 31, 2017, letters of credit totaling $74.1 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2017.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-17-000051:notes:4]
[same as prior period, unchanged from 0000936395-17-000038:notes:4]

[0000936395-17-000051:notes:5]
[same as prior period, unchanged from 0000936395-17-000038:notes:5]

[0000936395-17-000051:notes:6]
[same as prior period, unchanged from 0000936395-17-000038:notes:6]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-17-000051:notes:7]
[same as prior period, unchanged from 0000936395-17-000038:notes:7]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-17-000051:notes:8]
[same as prior period, unchanged from 0000936395-17-000038:notes:8]

[0000936395-17-000051:notes:9]
[same as prior period, unchanged from 0000936395-17-000038:notes:9]

[0000936395-17-000051:notes:10]
|  | July 31, 2017 |  | October 31, 2016 |
| Prepaid VAT and other taxes | $ | 92,998 |  |  | $ | 77,474 |  |
| Product demonstration equipment, net | 42,881 |  |  | 42,259 |  |
| Deferred deployment expense | 28,028 |  |  | 19,138 |  |
| Prepaid expenses | 25,229 |  |  | 25,659 |  |
| Other non-trade receivables | 6,847 |  |  | 4,398 |  |
| Financing receivable | 1,395 |  |  | 3,740 |  |
| Derivative assets | 1,811 |  |  | 175 |  |
|  | $ | 199,189 |  |  | $ | 172,843 |  |

[0000936395-17-000051:notes:11]
Depreciation of product demonstration equipment was $7.5 million and $8.1 million for the first nine months of fiscal 2017 and 2016, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-17-000051:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-17-000051:notes:13]
Outstanding Term Loan Payable

[0000936395-17-000051:notes:14]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000051:notes:15]
|  |  | July 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,674 |  |  | — |  |
|  |  | $ | 393,674 |  |  | $ | 486,303 |  |

[0000936395-17-000051:notes:16]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.3 million at July 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.7 million and $0.8 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.

[0000936395-17-000051:notes:17]
2022 Term Loan

[0000936395-17-000051:notes:18]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1.0 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed. The aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.

[0000936395-17-000051:notes:19]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2022 Term Loan will, among other things:

[0000936395-17-000051:notes:20]
| • | be subject to mandatory prepayment on the same basis as under the Term Loan Credit Agreement; |

[0000936395-17-000051:notes:21]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

[0000936395-17-000051:notes:22]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

[0000936395-17-000051:notes:23]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-17-000051:notes:24]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of July 31, 2017 (in thousands):

[0000936395-17-000051:notes:25]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,038 | ) |  | $ | (3,288 | ) |  | $393,674 |

[0000936395-17-000051:notes:26]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

[0000936395-17-000051:notes:27]
|  |  | July 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 393,674 |  |  | $ | 401,993 |  |

[0000936395-17-000051:notes:28]
| (1) | Includes unamortized debt discount and debt issuance costs. |

[0000936395-17-000051:notes:29]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-17-000051:notes:30]
Prior Term Loans

[0000936395-17-000051:notes:31]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000051:notes:32]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000051:notes:33]
Maturity of 2017 Convertible Notes

[0000936395-17-000051:notes:34]
On June 15, 2017, the outstanding 0.875% Convertible Senior Notes matured and Ciena repaid the approximately $185.3 million in aggregate principal amount outstanding, together with approximately $0.8 million in accrued interest through the date of maturity.

[0000936395-17-000051:notes:35]
Outstanding Convertible Notes Payable

[0000936395-17-000051:notes:36]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000051:notes:37]
|  |  | July 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 188,509 |  |
|  |  | $ | 541,628 |  |  | $ | 767,379 |  |

[0000936395-17-000051:notes:38]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.5 million at July 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.4 million and $2.1 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

[0000936395-17-000051:notes:39]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of July 31, 2017 (in thousands):

[0000936395-17-000051:notes:40]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,443 | ) |  | $ | 348,557 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,996 |  |  | $ | (9,893 | ) |  | $ | (1,032 | ) |  | $ | 193,071 |  |  | $ | 43,131 |  |

[0000936395-17-000051:notes:41]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2017:

[0000936395-17-000051:notes:42]
|  |  | July 31, 2017 |
|  |  | Net Carrying Value (1) |  | Fair Value(2) |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 482,825 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 269,719 |  |
|  |  | $ | 541,628 |  |  | $ | 752,544 |  |

[0000936395-17-000051:notes:43]
| (1) | Includes unamortized debt discount, accretion of principal and deferred debt issuance costs. |

[0000936395-17-000051:notes:44]
| (2) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-17-000051:notes:45]
[same as prior period, unchanged from 0000936395-17-000038:notes:43]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-17-000051:notes:46]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included either in other current assets or in other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-17-000051:notes:47]
COMMITMENTS AND CONTINGENCIES

[0000936395-17-000051:notes:48]
Foreign Tax Contingencies

[0000936395-17-000051:notes:49]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-17-000051:notes:50]
Litigation

[0000936395-17-000051:notes:51]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 15, 2016, the plaintiffs filed a third amended complaint against the members of Cyan's board of directors, which generally alleged that they breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.

[0000936395-17-000051:notes:52]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, which petition was granted on June 27, 2017. The matter is expected to be heard during the Supreme Court’s October 2017 Term. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-17-000051:notes:53]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-17-000051:notes:54]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-17-000051:notes:55]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-17-000051:notes:56]
[same as prior period, unchanged from 0000936395-17-000038:notes:54]

[0000936395-17-000051:notes:57]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the nine months ended July 31, 2017:

[0000936395-17-000051:notes:58]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (533 | ) |  | 896 |  |  | 4,838 |  |  | 11,891 |  |  | 17,092 |  |
| Amounts reclassified from AOCI | — |  |  | 2,010 |  |  | (268 | ) |  | — |  |  | 1,742 |  |
| Balance at July 31, 2017 | $ | (394 | ) |  | $ | 1,815 |  |  | $ | (1,397 | ) |  | $ | (5,519 | ) |  | $ | (5,495 | ) |

[0000936395-17-000051:notes:59]
The following table summarizes the changes in AOCI for the nine months ended July 31, 2016:

[0000936395-17-000051:notes:60]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 425 |  |  | (70 | ) |  | (4,655 | ) |  | 1,969 |  |  | (2,331 | ) |
| Amounts reclassified from AOCI | — |  |  | 588 |  |  | 2,479 |  |  | — |  |  | 3,067 |  |
| Balance at July 31, 2016 | $ | 347 |  |  | $ | 250 |  |  | $ | (7,698 | ) |  | $ | (14,289 | ) |  | $ | (21,390 | ) |

[0000936395-17-000051:notes:61]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense and sales and marketing expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-17-000051:notes:62]
[same as prior period, unchanged from 0000936395-17-000038:notes:60]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-17-000051:notes:63]
[same as prior period, unchanged from 0000936395-17-000038:notes:61]

[0000936395-17-000051:notes:64]
|  | July 31, 2017 |  | October 31, 2016 |
| Products | $ | 61,913 |  |  | $ | 45,216 |  |
| Services | 135,614 |  |  | 137,647 |  |
|  | 197,527 |  |  | 182,863 |  |
| Less current portion | (110,629 | ) |  | (109,009 | ) |
| Long-term deferred revenue | $ | 86,898 |  |  | $ | 73,854 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-17-000051:notes:65]
[same as prior period, unchanged from 0000936395-17-000038:notes:63]

[0000936395-17-000051:notes:66]
[same as prior period, unchanged from 0000936395-17-000038:notes:64]

[0000936395-17-000051:notes:67]
As of July 31, 2017 and October 31, 2016, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, and its British Pound denominated expense, which principally relates to sales and marketing activities. The notional amount of these contracts was approximately $35.4 million and $107.6 million as of July 31, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-17-000051:notes:68]
During the first nine months of fiscal 2017 and fiscal 2016, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $86.8 million and $59.6 million as of July 31, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-17-000051:notes:69]
[same as prior period, unchanged from 0000936395-17-000038:notes:67]

[0000936395-17-000051:notes:70]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). During the second quarter of fiscal 2017, Ciena refinanced its existing 2019 and 2021 Term Loans into a new 2022 Term Loan (as defined in Note 16), thereby reducing the aggregate outstanding principal to $400 million and extending the maturity to January 2022 (see Note 16 below). In order to align its interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, Ciena also reduced the total outstanding value of its interest rate swaps, as described below, and entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020, and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25%, 4.25% and 4.75%, respectively. The total notional amount of these interest rate swaps in effect as of July 31, 2017 was $390.6 million.

[0000936395-17-000051:notes:71]
[same as prior period, unchanged from 0000936395-17-000038:notes:69]

[0000936395-17-000051:notes:72]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loans. These derivative contracts have been designated as cash flow hedges.

[0000936395-17-000051:notes:73]
[same as prior period, unchanged from 0000936395-17-000038:notes:71]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-17-000051:notes:74]
[same as prior period, unchanged from 0000936395-17-000038:notes:72]

[0000936395-17-000051:notes:75]
[same as prior period, unchanged from 0000936395-17-000038:notes:73]

[0000936395-17-000051:notes:76]
[same as prior period, unchanged from 0000936395-17-000038:notes:74]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-17-000051:notes:77]
[same as prior period, unchanged from 0000936395-17-000038:notes:75]

[0000936395-17-000051:notes:78]
[same as prior period, unchanged from 0000936395-17-000038:notes:76]

[0000936395-17-000051:notes:79]
[same as prior period, unchanged from 0000936395-17-000038:notes:77]

[0000936395-17-000051:notes:80]
[same as prior period, unchanged from 0000936395-17-000038:notes:78]

[0000936395-17-000051:notes:81]
The 2017 Plan authorizes and reserves 8.9 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena's prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of July 31, 2017, approximately 10.4 million shares remained available for issuance under the 2017 Plan.

[0000936395-17-000051:notes:82]
[same as prior period, unchanged from 0000936395-17-000038:notes:80]

[0000936395-17-000051:notes:83]
Ciena did not grant any stock options during the first nine months of fiscal 2017 or fiscal 2016. Outstanding stock option awards granted to employees in prior periods or assumed as a result of acquisitions are generally subject to service-based vesting conditions and vest incrementally over a four-year period. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-17-000051:notes:84]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2016 | 1,387 |  |  | $ | 26.90 |  |
| Exercised | (223 | ) |  | 10.74 |  |
| Canceled | (270 | ) |  | 28.80 |  |
| Balance at July 31, 2017 | 894 |  |  | $ | 30.35 |  |

[0000936395-17-000051:notes:85]
The total intrinsic value of options exercised during the first nine months of fiscal 2017 and fiscal 2016 was $3.1 million and $4.6 million, respectively.

[0000936395-17-000051:notes:86]
The following table summarizes information with respect to stock options outstanding at July 31, 2017, based on Ciena’s closing stock price on the last trading day of Ciena’s third fiscal quarter of 2017 (shares and intrinsic value in thousands):

[0000936395-17-000051:notes:87]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | July 31, 2017 |  | July 31, 2017 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 1.88 |  |  | — |  |  | $ | 11.16 |  |  | 65 |  |  | 2.84 |  | $ | 8.66 |  |  | $ | 1,094 |  |  | 64 |  |  | 2.78 |  | $ | 8.64 |  |  | $ | 1,082 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 178 |  |  | 4.84 |  | 13.44 |  |  | 2,130 |  |  | 172 |  |  | 4.76 |  | 13.39 |  |  | 2,065 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.46 |  |  | 127 |  |  | 1.82 |  | 25.90 |  |  | 222 |  |  | 119 |  |  | 1.48 |  | 26.35 |  |  | 172 |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 299 |  |  | 1.74 |  | 35.10 |  |  | — |  |  | 299 |  |  | 1.74 |  | 35.10 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 225 |  |  | 3.92 |  | 46.17 |  |  | — |  |  | 224 |  |  | 3.91 |  | 46.19 |  |  | — |  |
| $ | 1.88 |  |  | — |  |  | $ | 55.63 |  |  | 894 |  |  | 3.00 |  | $ | 30.35 |  |  | $ | 3,446 |  |  | 878 |  |  | 2.92 |  | $ | 30.56 |  |  | $ | 3,319 |  |

[0000936395-17-000051:notes:88]
[same as prior period, unchanged from 0000936395-17-000038:notes:86]

[0000936395-17-000051:notes:89]
[same as prior period, unchanged from 0000936395-17-000038:notes:87]

[0000936395-17-000051:notes:90]
[same as prior period, unchanged from 0000936395-17-000038:notes:88]

[0000936395-17-000051:notes:91]
[same as prior period, unchanged from 0000936395-17-000038:notes:89]

[0000936395-17-000051:notes:92]
[same as prior period, unchanged from 0000936395-17-000038:notes:90]

[0000936395-17-000051:notes:93]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2016 | 4,280 |  |  | $ | 19.96 |  |  | $ | 83,511 |  |
| Granted | 2,211 |  |  |  |  |  |
| Vested | (1,687 | ) |  |  |  |  |
| Canceled or forfeited | (476 | ) |  |  |  |  |
| Balance at July 31, 2017 | 4,328 |  |  | $ | 21.36 |  |  | $ | 110,051 |  |

[0000936395-17-000051:notes:94]
The total fair value of restricted stock units that vested and were converted into common stock during the first nine months of fiscal 2017 and fiscal 2016 was $41.5 million and $41.3 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first nine months of fiscal 2017 and fiscal 2016 was $23.36 and $19.72 respectively.

[0000936395-17-000051:notes:95]
[same as prior period, unchanged from 0000936395-17-000038:notes:93]

[0000936395-17-000051:notes:96]
[same as prior period, unchanged from 0000936395-17-000038:notes:94]

[0000936395-17-000051:notes:97]
[same as prior period, unchanged from 0000936395-17-000038:notes:95]

[0000936395-17-000051:notes:98]
[same as prior period, unchanged from 0000936395-17-000038:notes:96]

[0000936395-17-000051:notes:99]
[same as prior period, unchanged from 0000936395-17-000038:notes:97]

[0000936395-17-000051:notes:100]
[same as prior period, unchanged from 0000936395-17-000038:notes:98]

[0000936395-17-000051:notes:101]
During the first nine months of fiscal 2017, Ciena issued 1.0 million shares under the ESPP. At July 31, 2017, 5.5 million shares remained available for issuance under the ESPP.

[0000936395-17-000051:notes:102]
[same as prior period, unchanged from 0000936395-17-000038:notes:100]

[0000936395-17-000051:notes:103]
[same as prior period, unchanged from 0000936395-17-000038:notes:101]

[0000936395-17-000051:notes:104]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Product costs | $ | 709 |  |  | $ | 645 |  |  | $ | 1,978 |  |  | $ | 1,845 |  |
| Service costs | 619 |  |  | 637 |  |  | 1,926 |  |  | 1,922 |  |
| Share-based compensation expense included in cost of sales | 1,328 |  |  | 1,282 |  |  | 3,904 |  |  | 3,767 |  |
| Research and development | 3,139 |  |  | 3,479 |  |  | 10,001 |  |  | 10,698 |  |
| Sales and marketing | 3,242 |  |  | 3,590 |  |  | 9,628 |  |  | 12,248 |  |
| General and administrative | 4,321 |  |  | 4,284 |  |  | 13,191 |  |  | 14,381 |  |
| Acquisition and integration costs | — |  |  | — |  |  | — |  |  | 714 |  |
| Share-based compensation expense included in operating expense | 10,702 |  |  | 11,353 |  |  | 32,820 |  |  | 38,041 |  |
| Share-based compensation expense capitalized in inventory, net | (17 | ) |  | (13 | ) |  | 119 |  |  | 24 |  |
| Total share-based compensation | $ | 12,013 |  |  | $ | 12,622 |  |  | $ | 36,843 |  |  | $ | 41,832 |  |

[0000936395-17-000051:notes:105]
As of July 31, 2017, total unrecognized share-based compensation expense was approximately $76.5 million: (i) $0.2 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.1 years; and (ii) $76.3 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-17-000051:notes:106]
[same as prior period, unchanged from 0000936395-17-000038:notes:104]


## us-gaap:EarningsPerShareTextBlock

[0000936395-17-000051:notes:107]
[same as prior period, unchanged from 0000936395-17-000038:notes:105]

[0000936395-17-000051:notes:108]
[same as prior period, unchanged from 0000936395-17-000038:notes:106]

[0000936395-17-000051:notes:109]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net income | $ | 60,010 |  |  | $ | 33,546 |  |  | $ | 101,897 |  |  | $ | 35,997 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | 246 |  |  | 1,326 |  |  | 1,343 |  |  | — |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 | 3,572 |  |  | 3,572 |  |  | 10,750 |  |  | — |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | 3,323 |  |  | — |  |  | — |  |  | — |  |
| Net income used to calculate Diluted EPS | $ | 67,151 |  |  | $ | 38,444 |  |  | $ | 113,990 |  |  | $ | 35,997 |  |

[0000936395-17-000051:notes:110]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Basic weighted average shares outstanding | 142,464 |  |  | 138,881 |  |  | 141,631 |  |  | 137,835 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 1,386 |  |  | 895 |  |  | 1,401 |  |  | 1,218 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | 1,708 |  |  | 12,217 |  |  | 4,043 |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | — |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | 9,198 |  |  | — |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 172,112 |  |  | 169,349 |  |  | 164,431 |  |  | 139,053 |  |

[0000936395-17-000051:notes:111]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Basic EPS | $ | 0.42 |  |  | $ | 0.24 |  |  | $ | 0.72 |  |  | $ | 0.26 |  |
| Diluted EPS | $ | 0.39 |  |  | $ | 0.23 |  |  | $ | 0.69 |  |  | $ | 0.26 |  |

[0000936395-17-000051:notes:112]
[same as prior period, unchanged from 0000936395-17-000038:notes:110]

[0000936395-17-000051:notes:113]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Shares underlying stock options and restricted stock units | 682 |  |  | 2,082 |  |  | 988 |  |  | 2,089 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | — |  |  | — |  |  | 12,571 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | — |  |  | — |  |  | — |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 682 |  |  | 11,280 |  |  | 10,186 |  |  | 41,214 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-17-000051:notes:114]
[same as prior period, unchanged from 0000936395-17-000038:notes:112]

[0000936395-17-000051:notes:115]
|  | July 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 392,351 |  |  | $ | — |  |  | $ | — |  |  | $ | 392,351 |  |
| U.S. government obligations | — |  |  | 284,634 |  |  | — |  |  | 284,634 |  |
| Commercial paper | — |  |  | 89,887 |  |  | — |  |  | 89,887 |  |
| Foreign currency forward contracts | — |  |  | 1,811 |  |  | — |  |  | 1,811 |  |
| Total assets measured at fair value | $ | 392,351 |  |  | $ | 376,332 |  |  | $ | — |  |  | $ | 768,683 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 229 |  |  | $ | — |  |  | $ | 229 |  |
| Forward starting interest rate swap | — |  |  | 1,396 |  |  | — |  |  | 1,396 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,625 |  |  | $ | — |  |  | $ | 1,625 |  |

[0000936395-17-000051:notes:116]
[same as prior period, unchanged from 0000936395-17-000038:notes:114]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-17-000051:notes:117]
[same as prior period, unchanged from 0000936395-17-000038:notes:115]

[0000936395-17-000051:notes:118]
|  | July 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 392,351 |  |  | $ | 79,904 |  |  | $ | — |  |  | $ | 472,255 |  |
| Short-term investments | — |  |  | 234,743 |  |  | — |  |  | 234,743 |  |
| Prepaid expenses and other | — |  |  | 1,811 |  |  | — |  |  | 1,811 |  |
| Long-term investments | — |  |  | 59,874 |  |  | — |  |  | 59,874 |  |
| Total assets measured at fair value | $ | 392,351 |  |  | $ | 376,332 |  |  | $ | — |  |  | $ | 768,683 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 229 |  |  | $ | — |  |  | $ | 229 |  |
| Other long-term obligations | — |  |  | 1,396 |  |  | — |  |  | 1,396 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,625 |  |  | $ | — |  |  | $ | 1,625 |  |

[0000936395-17-000051:notes:119]
[same as prior period, unchanged from 0000936395-17-000038:notes:117]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-17-000051:notes:120]
[same as prior period, unchanged from 0000936395-17-000038:notes:118]

[0000936395-17-000051:notes:121]
[same as prior period, unchanged from 0000936395-17-000038:notes:119]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-17-000051:notes:122]
[same as prior period, unchanged from 0000936395-17-000038:notes:120]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-17-000051:notes:123]
[same as prior period, unchanged from 0000936395-17-000038:notes:121]

[0000936395-17-000051:notes:124]
[same as prior period, unchanged from 0000936395-17-000038:notes:122]

[0000936395-17-000051:notes:125]
|  |  | Balance at October 31, 2016 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at July 31, 2017 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 65,546 |  |  | — |  |  | — |  |  | 867 |  |  | 66,413 |  |
| Total |  | $ | 266,974 |  |  | $ | — |  |  | $ | — |  |  | $ | 867 |  |  | $ | 267,841 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-17-000051:notes:126]
[same as prior period, unchanged from 0000936395-17-000038:notes:124]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-17-000051:notes:127]
[same as prior period, unchanged from 0000936395-17-000038:notes:125]

[0000936395-17-000051:notes:128]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2014), United Kingdom (2014), Canada (2011), India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-17-000051:notes:129]
[same as prior period, unchanged from 0000936395-17-000038:notes:127]

[0000936395-17-000051:notes:130]
[same as prior period, unchanged from 0000936395-17-000038:notes:128]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-17-000051:notes:131]
[same as prior period, unchanged from 0000936395-17-000038:notes:129]

[0000936395-17-000051:notes:132]
[same as prior period, unchanged from 0000936395-17-000038:notes:130]

[0000936395-17-000051:notes:133]
|  | July 31, 2017 |  | October 31, 2016 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 341,255 |  |  | $ | (262,308 | ) |  | $ | 78,947 |  |  | $ | 347,727 |  |  | $ | (248,128 | ) |  | $ | 99,599 |  |
| In-process research and development | 671 |  |  | — |  |  | 671 |  |  | 4,200 |  |  | — |  |  | 4,200 |  |
| Patents and licenses | 7,165 |  |  | (6,473 | ) |  | 692 |  |  | 7,165 |  |  | (6,285 | ) |  | 880 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 334,642 |  |  | (307,962 | ) |  | 26,680 |  |  | 358,647 |  |  | (316,615 | ) |  | 42,032 |  |
| Total other intangible assets | $ | 683,733 |  |  | $ | (576,743 | ) |  | $ | 106,990 |  |  | $ | 717,739 |  |  | $ | (571,028 | ) |  | $ | 146,711 |  |

[0000936395-17-000051:notes:134]
During the third quarter of fiscal 2017, certain fully amortized intangible assets of approximately $34.0 million were eliminated from gross intangible assets and accumulated amortization, with no corresponding impact to the income statement. These assets were primarily technology for products no longer being sold by Ciena.

[0000936395-17-000051:notes:135]
As the result of the acquisition of the high-speed photonics components assets from TeraXion and its wholly-owned subsidiary on February 1, 2016, Ciena had recorded in-process research and development projects acquired as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the assets. In the third quarter of fiscal 2017, Ciena placed into service $3.5 million of developed technology, which will be amortized over the expected economic life of five years.

[0000936395-17-000051:notes:136]
The aggregate amortization expense of intangible assets was $39.7 million and $59.4 million for the first nine months of fiscal 2017 and 2016, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-17-000051:notes:137]
| Period ended October 31, |  |  |
| 2017 (remaining three months) | $ | 5,993 |  |  |
| 2018 | 23,386 |  |  |
| 2019 | 22,839 |  |  |
| 2020 | 21,812 |  |  |
| 2021 | 18,878 |  |  |
| Thereafter | 13,411 |  |  |
|  | $ | 106,319 |  | (1) |

[0000936395-17-000051:notes:138]
[same as prior period, unchanged from 0000936395-17-000038:notes:134]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-17-000051:notes:139]
[same as prior period, unchanged from 0000936395-17-000038:notes:135]

[0000936395-17-000051:notes:140]
[same as prior period, unchanged from 0000936395-17-000038:notes:136]

[0000936395-17-000051:notes:141]
|  | July 31, 2017 |  | October 31, 2016 |
| Raw materials | $ | 46,857 |  |  | $ | 44,644 |  |
| Work-in-process | 16,172 |  |  | 12,852 |  |
| Finished goods | 179,394 |  |  | 156,402 |  |
| Deferred cost of goods sold | 90,157 |  |  | 59,856 |  |
|  | 332,580 |  |  | 273,754 |  |
| Provision for excess and obsolescence | (56,159 | ) |  | (62,503 | ) |
|  | $ | 276,421 |  |  | $ | 211,251 |  |

[0000936395-17-000051:notes:142]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2017, Ciena recorded a provision for excess and obsolescence of $28.7 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-17-000051:notes:143]
[same as prior period, unchanged from 0000936395-17-000038:notes:139]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-17-000051:notes:144]
[same as prior period, unchanged from 0000936395-17-000038:notes:140]

[0000936395-17-000051:notes:145]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-17-000051:notes:146]
The following table summarizes the final legal maturities of debt investments at July 31, 2017 (in thousands):

[0000936395-17-000051:notes:147]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 235,015 |  |  | $ | 234,743 |  |
| Due in 1-2 years | 59,976 |  |  | 59,874 |  |
|  | $ | 294,991 |  |  | $ | 294,617 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-17-000051:notes:148]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-17-000051:notes:149]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-17-000051:notes:150]
|  | July 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 225,032 |  |  | $ | — |  |  | (272 | ) |  | $ | 224,760 |  |
| Included in long-term investments | 59,976 |  |  | — |  |  | (102 | ) |  | 59,874 |  |
|  | $ | 285,008 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 284,634 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,983 |  |  | — |  |  | — |  |  | $ | 9,983 |  |
|  | $ | 9,983 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,983 |  |

[0000936395-17-000051:notes:151]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | — |  |  | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-17-000051:notes:152]
Ciena expenses legal costs associated with litigation as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-17-000051:notes:153]
[same as prior period, unchanged from 0000936395-17-000038:notes:149]

[0000936395-17-000051:notes:154]
As of July 31, 2017, one customer accounted for 10.3% of Ciena's net accounts receivable and as of October 31, 2016, a different customer accounted for 10.4% of Ciena's net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The allowance for doubtful accounts was $3.6 million and $4.0 million as of July 31, 2017 and October 31, 2016, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-17-000051:notes:155]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $5.8 million at July 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and to continue to present such capitalized costs in other assets.

[0000936395-17-000051:notes:156]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

[0000936395-17-000051:notes:157]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-17-000051:notes:158]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) ("ASU 2014-09"), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

[0000936395-17-000051:notes:159]
For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require that it determine the stand alone selling price for each of the elements at the contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-17-000051:notes:160]
Ciena also expects certain installation and deployment and consulting and network design services will be recognized over a period of time rather than at a point in time.

[0000936395-17-000051:notes:161]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less and amortized over the period of performance if the period of the asset recognition is greater than one year.

[0000936395-17-000051:notes:162]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000051:notes:163]
In February 2016, the FASB issued ASU No. 2016-02, Leases ("ASU 2016-02"), which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000051:notes:164]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any related valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, with the prior periods adjusted accordingly, as a result of the adoption. Finally, Ciena will elect to continue to estimate expected forfeitures rather than account for forfeitures as they occur.

[0000936395-17-000051:notes:165]
In January 2017, the FASB issued ASU No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.

[0000936395-17-000051:notes:166]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. ASU 2017-12 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is evaluating the effect of the update on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-17-000051:notes:167]
[same as prior period, unchanged from 0000936395-17-000038:notes:158]

[0000936395-17-000051:notes:168]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the "SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2016 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2016.

[0000936395-17-000051:notes:169]
[same as prior period, unchanged from 0000936395-17-000038:notes:160]


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-17-000051:notes:170]
[same as prior period, unchanged from 0000936395-17-000038:notes:161]

[0000936395-17-000051:notes:171]
|  | July 31, 2017 |  | October 31, 2016 |
| Capital lease obligations | $ | 76,549 |  |  | $ | 24,298 |  |
| Income tax liability | 15,621 |  |  | 14,122 |  |
| Deferred tenant allowance | 8,412 |  |  | 9,164 |  |
| Straight-line rent | 7,371 |  |  | 6,406 |  |
| Forward starting interest rate swap | 1,396 |  |  | 5,967 |  |
| Construction liability | — |  |  | 57,602 |  |
| Other | 7,185 |  |  | 6,835 |  |
|  | $ | 116,534 |  |  | $ | 124,394 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-17-000051:notes:172]
[same as prior period, unchanged from 0000936395-17-000038:notes:163]

[0000936395-17-000051:notes:173]
[same as prior period, unchanged from 0000936395-17-000038:notes:164]

[0000936395-17-000051:notes:174]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest income | $ | 1,820 |  |  | $ | 1,250 |  |  | $ | 4,609 |  |  | $ | 2,918 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 834 |  |  | (4,787 | ) |  | (891 | ) |  | (20,000 | ) |
| Foreign currency exchange gain (loss) | (2,946 | ) |  | (839 | ) |  | (4,071 | ) |  | 5,291 |  |
| Modification of term loan | — |  |  | — |  |  | (2,924 | ) |  | — |  |
| Other | (556 | ) |  | 729 |  |  | (119 | ) |  | 335 |  |
| Interest and other income (loss), net | $ | (848 | ) |  | $ | (3,647 | ) |  | $ | (3,396 | ) |  | $ | (11,456 | ) |

[0000936395-17-000051:notes:175]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first nine months of fiscal 2017 Ciena recorded $4.1 million in foreign currency exchange rate losses, and during the first nine months of fiscal 2016, Ciena recorded $5.3 million in foreign currency exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first nine months of fiscal 2017 and fiscal 2016, Ciena recorded losses of $0.9 million and $20.0 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-17-000051:notes:176]
[same as prior period, unchanged from 0000936395-17-000038:notes:167]

[0000936395-17-000051:notes:177]
[same as prior period, unchanged from 0000936395-17-000038:notes:168]

[0000936395-17-000051:notes:178]
|  | July 31, 2017 |  | October 31, 2016 |
| Equipment, furniture and fixtures | $ | 483,482 |  |  | $ | 451,029 |  |
| Building subject to capital lease | 79,002 |  |  | 22,529 |  |
| Construction in progress subject to build-to-suit lease | — |  |  | 57,602 |  |
| Leasehold improvements | 86,617 |  |  | 60,011 |  |
|  | 649,101 |  |  | 591,171 |  |
| Accumulated depreciation and amortization | (334,251 | ) |  | (302,765 | ) |
|  | $ | 314,850 |  |  | $ | 288,406 |  |

[0000936395-17-000051:notes:179]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord constructed, and Ciena subsequently leased, two new office buildings at its new Ottawa, Canada campus. The landlord constructed the buildings and contributed up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena was responsible for any additional construction costs. As of May 1, 2017, occupancy for both of the office buildings was complete. As such, Ciena recorded capital leases of $50.4 million for these buildings, which will be depreciated over the lease term and removed the build-to-suit construction in progress asset and the corresponding long-term liability.

[0000936395-17-000051:notes:180]
The total of the depreciation of equipment, furniture and fixtures and the amortization of leasehold improvements was $48.3 million and $38.5 million for the first nine months of fiscal 2017 and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-17-000051:notes:181]
[same as prior period, unchanged from 0000936395-17-000038:notes:172]

[0000936395-17-000051:notes:182]
[same as prior period, unchanged from 0000936395-17-000038:notes:173]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-17-000051:notes:183]
[same as prior period, unchanged from 0000936395-17-000038:notes:174]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-17-000051:notes:184]
The table below (in thousands) sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income during the respective periods indicated:

[0000936395-17-000051:notes:185]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 159,649 |  |  | $ | 150,521 |  |  | $ | 423,859 |  |  | $ | 390,109 |  |
| Software and Software-Related Services | 11,133 |  |  | 2,412 |  |  | 23,384 |  |  | (970 | ) |
| Global Services | 39,565 |  |  | 38,855 |  |  | 116,637 |  |  | 114,543 |  |
| Total segment profit | 210,347 |  |  | 191,788 |  |  | 563,880 |  |  | 503,682 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 86,739 |  |  | 83,732 |  |  | 260,292 |  |  | 252,878 |  |
| General and administrative | 35,569 |  |  | 34,336 |  |  | 106,423 |  |  | 100,681 |  |
| Amortization of intangible assets | 3,837 |  |  | 14,529 |  |  | 29,368 |  |  | 46,957 |  |
| Acquisition and integration costs | — |  |  | 1,029 |  |  | — |  |  | 4,613 |  |
| Restructuring costs | 2,203 |  |  | 1,138 |  |  | 8,874 |  |  | 2,057 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (14,263 | ) |  | (19,614 | ) |  | (45,322 | ) |  | (52,741 | ) |
| Less: Provision for income taxes | 7,726 |  |  | 3,864 |  |  | 11,704 |  |  | 7,758 |  |
| Consolidated net income | $ | 60,010 |  |  | $ | 33,546 |  |  | $ | 101,897 |  |  | $ | 35,997 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-17-000051:notes:186]
[same as prior period, unchanged from 0000936395-17-000038:notes:177]

[0000936395-17-000051:notes:187]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 506,532 |  |  | $ | 467,615 |  |  | $ | 1,421,315 |  |  | $ | 1,291,956 |  |
| Packet Networking | 82,121 |  |  | 63,658 |  |  | 220,641 |  |  | 180,437 |  |
| Optical Transport | 3,694 |  |  | 9,619 |  |  | 11,822 |  |  | 30,215 |  |
| Total Networking Platforms | 592,347 |  |  | 540,892 |  |  | 1,653,778 |  |  | 1,502,608 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 18,395 |  |  | 12,558 |  |  | 48,587 |  |  | 32,409 |  |
| Software-Related Services | 23,856 |  |  | 19,011 |  |  | 70,760 |  |  | 55,059 |  |
| Total Software and Software-Related Services | 42,251 |  |  | 31,569 |  |  | 119,347 |  |  | 87,468 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 57,902 |  |  | 55,996 |  |  | 171,133 |  |  | 169,123 |  |
| Installation and Deployment | 27,397 |  |  | 31,245 |  |  | 84,011 |  |  | 92,317 |  |
| Consulting and Network Design | 8,822 |  |  | 10,848 |  |  | 28,969 |  |  | 32,866 |  |
| Total Global Services | 94,121 |  |  | 98,089 |  |  | 284,113 |  |  | 294,306 |  |
| Consolidated revenue | $ | 728,719 |  |  | $ | 670,550 |  |  | $ | 2,057,238 |  |  | $ | 1,884,382 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-17-000051:notes:188]
[same as prior period, unchanged from 0000936395-17-000038:notes:179]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-17-000051:notes:189]
[same as prior period, unchanged from 0000936395-17-000038:notes:180]

[0000936395-17-000051:notes:190]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2017 (in thousands):

[0000936395-17-000051:notes:191]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 3,967 |  | (1) | 4,907 |  | (2) | 8,874 |  |
| Cash payments | (3,370 | ) |  | (2,679 | ) |  | (6,049 | ) |
| Balance at July 31, 2017 | $ | 1,465 |  |  | $ | 4,198 |  |  | $ | 5,663 |  |
| Current restructuring liabilities | $ | 1,465 |  |  | $ | 4,198 |  |  | $ | 5,663 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-17-000051:notes:192]
| (1) | Reflects a global workforce reduction of approximately 60 employees during fiscal 2017 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes and systems. |

[0000936395-17-000051:notes:193]
| (2) | Reflects unfavorable lease commitments and relocation costs incurred during fiscal 2017 in connection with the facility transition from Ciena's existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000051:notes:194]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2016 (in thousands):

[0000936395-17-000051:notes:195]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 2,067 |  |  | (9 | ) |  | 2,058 |  |
| Cash payments | (1,736 | ) |  | (316 | ) |  | (2,052 | ) |
| Balance at July 31, 2016 | $ | 922 |  |  | $ | 363 |  |  | $ | 1,285 |  |
| Current restructuring liabilities | $ | 922 |  |  | $ | 363 |  |  | $ | 1,285 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-17-000051:notes:196]
[same as prior period, unchanged from 0000936395-17-000038:notes:187]

[0000936395-17-000051:notes:197]
[same as prior period, unchanged from 0000936395-17-000038:notes:188]

[0000936395-17-000051:notes:198]
[same as prior period, unchanged from 0000936395-17-000038:notes:189]

[0000936395-17-000051:notes:199]
[same as prior period, unchanged from 0000936395-17-000038:notes:190]

[0000936395-17-000051:notes:200]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-17-000051:notes:201]
[same as prior period, unchanged from 0000936395-17-000038:notes:192]

[0000936395-17-000051:notes:202]
|  | July 31, 2017 |  | October 31, 2016 |
| Compensation, payroll related tax and benefits | $ | 94,934 |  |  | $ | 106,687 |  |
| Warranty | 44,296 |  |  | 52,324 |  |
| Vacation | 40,541 |  |  | 36,112 |  |
| Capital lease obligations | 3,784 |  |  | 2,321 |  |
| Interest payable | 5,032 |  |  | 4,649 |  |
| Other | 96,042 |  |  | 108,260 |  |
|  | $ | 284,629 |  |  | $ | 310,353 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-17-000051:notes:203]
The following is a schedule by fiscal year of future minimum lease payments under capital leases and the present value of minimum lease payments as of July 31, 2017 (in thousands):

[0000936395-17-000051:notes:204]
| Period ended October 31, |  |
| 2017 (remaining three months) | $ | 2,371 |  |
| 2018 | 9,486 |  |
| 2019 | 9,060 |  |
| 2020 | 8,078 |  |
| 2021 | 7,974 |  |
| Thereafter | 96,279 |  |
| Net minimum capital lease payments | 133,248 |  |
| Less: Amount representing interest | (52,915 | ) |
| Present value of minimum lease payments | 80,333 |  |
| Less: Current portion of present value of minimum lease payments | (3,784 | ) |
| Long-term portion of present value of minimum lease payments | $ | 76,549 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-17-000051:notes:205]
[same as prior period, unchanged from 0000936395-17-000038:notes:196]

[0000936395-17-000051:notes:206]
|  | July 31, 2017 |  | October 31, 2016 |
| Maintenance spares, net | $ | 46,576 |  |  | $ | 49,535 |  |
| Deferred debt issuance costs, net (1) | 1,122 |  |  | 1,363 |  |
| Financing receivable | 716 |  |  | 1,870 |  |
| Other | 15,556 |  |  | 15,352 |  |
|  | $ | 63,970 |  |  | $ | 68,120 |  |

[0000936395-17-000051:notes:207]
(1) As described in Note 2 above, in connection with Ciena's adoption of ASU 2015-03 during the first quarter of fiscal 2017, deferred debt issuance costs associated with its convertible notes and term loans were retrospectively reclassified from other long-term assets to current portion of long-term debt and long-term debt, net on the Condensed Consolidated Balance Sheets. The deferred debt issuance costs reflected relate to Ciena's ABL Credit Facility (described in Note 17 below). The amortization of deferred debt issuance costs for Ciena's ABL Credit Facility is included in interest expense, and was $0.3 million and $0.3 million during the first nine months of fiscal 2017 and 2016, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-17-000051:notes:208]
[same as prior period, unchanged from 0000936395-17-000038:notes:199]

[0000936395-17-000051:notes:209]
| Nine months ended |  | Beginning |  |  |  |  |  | Ending |
| July 31, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2016 |  | $ | 56,654 |  |  | 13,114 |  |  | (15,289 | ) |  | $ | 54,479 |  |
| 2017 |  | $ | 52,324 |  |  | 5,188 |  |  | (13,216 | ) |  | $ | 44,296 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-17-000051:notes:210]
For the periods below, customers accounting for at least 10% of Ciena’s revenue, were as follows (in thousands):

[0000936395-17-000051:notes:211]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| AT&T | $ | 120,931 |  |  | $ | 105,418 |  |  | $ | 324,900 |  |  | $ | 348,032 |  |
| Verizon | 82,918 |  |  | n/a |  |  | 206,272 |  |  | n/a |  |
| Total | $ | 203,849 |  |  | $ | 105,418 |  |  | $ | 531,172 |  |  | $ | 348,032 |  |

[0000936395-17-000051:notes:212]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-17-000051:notes:213]
[same as prior period, unchanged from 0000936395-17-000038:notes:203]

[0000936395-17-000051:notes:214]
|  | July 31, 2017 |  | October 31, 2016 |
| Canada | $ | 208,422 |  |  | $ | 173,885 |  |
| United States | 94,790 |  |  | 103,018 |  |
| Other International | 11,638 |  |  | 11,503 |  |
| Total | $ | 314,850 |  |  | $ | 288,406 |  |

[0000936395-17-000051:notes:215]
[same as prior period, unchanged from 0000936395-17-000038:notes:205]

[0000936395-17-000051:notes:216]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| North America | $ | 465,238 |  |  | $ | 438,013 |  |  | $ | 1,295,539 |  |  | $ | 1,226,222 |  |
| EMEA | 96,068 |  |  | 104,266 |  |  | 293,387 |  |  | 281,163 |  |
| CALA | 51,709 |  |  | 46,606 |  |  | 120,826 |  |  | 148,312 |  |
| APAC | 115,704 |  |  | 81,665 |  |  | 347,486 |  |  | 228,685 |  |
| Total | $ | 728,719 |  |  | $ | 670,550 |  |  | $ | 2,057,238 |  |  | $ | 1,884,382 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-17-000051:notes:217]
[same as prior period, unchanged from 0000936395-17-000038:notes:207]

[0000936395-17-000051:notes:218]
[same as prior period, unchanged from 0000936395-17-000038:notes:208]

[0000936395-17-000051:notes:219]
[same as prior period, unchanged from 0000936395-17-000038:notes:209]

[0000936395-17-000051:notes:220]
[same as prior period, unchanged from 0000936395-17-000038:notes:210]

[0000936395-17-000051:notes:221]
[same as prior period, unchanged from 0000936395-17-000038:notes:211]

[0000936395-17-000051:notes:222]
[same as prior period, unchanged from 0000936395-17-000038:notes:212]

[0000936395-17-000051:notes:223]
[same as prior period, unchanged from 0000936395-17-000038:notes:213]

[0000936395-17-000051:notes:224]
[same as prior period, unchanged from 0000936395-17-000038:notes:214]

[0000936395-17-000051:notes:225]
[same as prior period, unchanged from 0000936395-17-000038:notes:215]

[0000936395-17-000051:notes:226]
[same as prior period, unchanged from 0000936395-17-000038:notes:216]

[0000936395-17-000051:notes:227]
[same as prior period, unchanged from 0000936395-17-000038:notes:217]

[0000936395-17-000051:notes:228]
[same as prior period, unchanged from 0000936395-17-000038:notes:218]

[0000936395-17-000051:notes:229]
[same as prior period, unchanged from 0000936395-17-000038:notes:219]

[0000936395-17-000051:notes:230]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2017, equipment, building, furniture and fixtures, net totaled $314.9 million primarily supporting asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supporting Ciena's unallocated selling and general and administrative activities. As of July 31, 2017, $40.4 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Networking Platforms segment and $66.6 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of July 31, 2017, all of the maintenance spares, net, totaling $46.6 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-17-000051:notes:231]
[same as prior period, unchanged from 0000936395-17-000038:notes:221]

[0000936395-17-000051:notes:232]
[same as prior period, unchanged from 0000936395-17-000038:notes:222]

[0000936395-17-000051:notes:233]
[same as prior period, unchanged from 0000936395-17-000038:notes:223]

[0000936395-17-000051:notes:234]
[same as prior period, unchanged from 0000936395-17-000038:notes:224]

[0000936395-17-000051:notes:235]
[same as prior period, unchanged from 0000936395-17-000038:notes:225]

[0000936395-17-000051:notes:236]
North America includes $438.1 million and $410.0 million of United States revenue for fiscal quarters ended July 31, 2017 and 2016, respectively. For the nine months ended July 31, 2017 and 2016, United States revenue was $1.2 billion and $1.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-17-000051:notes:237]
[same as prior period, unchanged from 0000936395-17-000038:notes:227]

[0000936395-17-000051:notes:238]
The customers identified above purchased products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-17-000051:notes:239]
[same as prior period, unchanged from 0000936395-17-000038:notes:229]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-17-000051:notes:240]
[same as prior period, unchanged from 0000936395-17-000038:notes:230]

[0000936395-17-000051:notes:241]
[same as prior period, unchanged from 0000936395-17-000038:notes:231]

[0000936395-17-000051:notes:242]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-17-000051:notes:243]
[same as prior period, unchanged from 0000936395-17-000038:notes:233]

[0000936395-17-000051:notes:244]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-17-000051:notes:245]
[same as prior period, unchanged from 0000936395-17-000038:notes:235]

[0000936395-17-000051:notes:246]
[same as prior period, unchanged from 0000936395-17-000038:notes:236]

[0000936395-17-000051:notes:247]
[same as prior period, unchanged from 0000936395-17-000038:notes:237]

[0000936395-17-000051:notes:248]
[same as prior period, unchanged from 0000936395-17-000038:notes:238]

[0000936395-17-000051:notes:249]
[same as prior period, unchanged from 0000936395-17-000038:notes:239]

[0000936395-17-000051:notes:250]
[same as prior period, unchanged from 0000936395-17-000038:notes:240]

[0000936395-17-000051:notes:251]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by Financial Accounting Standards Board ("FASB") Accounting Standards Update ("ASU") No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-17-000051:notes:252]
[same as prior period, unchanged from 0000936395-17-000038:notes:242]

[0000936395-17-000051:notes:253]
[same as prior period, unchanged from 0000936395-17-000038:notes:243]

[0000936395-17-000051:notes:254]
[same as prior period, unchanged from 0000936395-17-000038:notes:244]

[0000936395-17-000051:notes:255]
[same as prior period, unchanged from 0000936395-17-000038:notes:245]

[0000936395-17-000051:notes:256]
[same as prior period, unchanged from 0000936395-17-000038:notes:246]

[0000936395-17-000051:notes:257]
[same as prior period, unchanged from 0000936395-17-000038:notes:247]

[0000936395-17-000051:notes:258]
[same as prior period, unchanged from 0000936395-17-000038:notes:248]

[0000936395-17-000051:notes:259]
[same as prior period, unchanged from 0000936395-17-000038:notes:249]

[0000936395-17-000051:notes:260]
[same as prior period, unchanged from 0000936395-17-000038:notes:250]

[0000936395-17-000051:notes:261]
[same as prior period, unchanged from 0000936395-17-000038:notes:251]

[0000936395-17-000051:notes:262]
[same as prior period, unchanged from 0000936395-17-000038:notes:252]

[0000936395-17-000051:notes:263]
[same as prior period, unchanged from 0000936395-17-000038:notes:253]

[0000936395-17-000051:notes:264]
[same as prior period, unchanged from 0000936395-17-000038:notes:254]

[0000936395-17-000051:notes:265]
[same as prior period, unchanged from 0000936395-17-000038:notes:255]

[0000936395-17-000051:notes:266]
[same as prior period, unchanged from 0000936395-17-000038:notes:256]

[0000936395-17-000051:notes:267]
[same as prior period, unchanged from 0000936395-17-000038:notes:257]

[0000936395-17-000051:notes:268]
[same as prior period, unchanged from 0000936395-17-000038:notes:258]

[0000936395-17-000051:notes:269]
[same as prior period, unchanged from 0000936395-17-000038:notes:259]

[0000936395-17-000051:notes:270]
[same as prior period, unchanged from 0000936395-17-000038:notes:260]

[0000936395-17-000051:notes:271]
Loss Contingencies

[0000936395-17-000051:notes:272]
[same as prior period, unchanged from 0000936395-17-000038:notes:262]

[0000936395-17-000051:notes:273]
[same as prior period, unchanged from 0000936395-17-000038:notes:263]

[0000936395-17-000051:notes:274]
[same as prior period, unchanged from 0000936395-17-000038:notes:264]

[0000936395-17-000051:notes:275]
[same as prior period, unchanged from 0000936395-17-000038:notes:265]

[0000936395-17-000051:notes:276]
[same as prior period, unchanged from 0000936395-17-000038:notes:266]

[0000936395-17-000051:notes:277]
[same as prior period, unchanged from 0000936395-17-000038:notes:267]

[0000936395-17-000051:notes:278]
[same as prior period, unchanged from 0000936395-17-000038:notes:268]

[0000936395-17-000051:notes:279]
[same as prior period, unchanged from 0000936395-17-000038:notes:269]

[0000936395-17-000051:notes:280]
[same as prior period, unchanged from 0000936395-17-000038:notes:270]

[0000936395-17-000051:notes:281]
[same as prior period, unchanged from 0000936395-17-000038:notes:271]

[0000936395-17-000051:notes:282]
[same as prior period, unchanged from 0000936395-17-000038:notes:272]

[0000936395-17-000051:notes:283]
[same as prior period, unchanged from 0000936395-17-000038:notes:273]

[0000936395-17-000051:notes:284]
[same as prior period, unchanged from 0000936395-17-000038:notes:274]

[0000936395-17-000051:notes:285]
[same as prior period, unchanged from 0000936395-17-000038:notes:275]

[0000936395-17-000051:notes:286]
[same as prior period, unchanged from 0000936395-17-000038:notes:276]

[0000936395-17-000051:notes:287]
[same as prior period, unchanged from 0000936395-17-000038:notes:277]

[0000936395-17-000051:notes:288]
[same as prior period, unchanged from 0000936395-17-000038:notes:278]

[0000936395-17-000051:notes:289]
[same as prior period, unchanged from 0000936395-17-000038:notes:279]


## us-gaap:SubsequentEventsTextBlock

[0000936395-17-000051:notes:290]
SUBSEQUENT EVENT

[0000936395-17-000051:notes:291]
On August 2, 2017, Ciena completed its offer to exchange its outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount. The New Notes give Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares. Through these cash settlement options, Ciena believes that it will gain additional flexibility to better manage its long-term capital structure and reduce the dilutive impact of its convertible notes upon stockholders. It is Ciena’s current intent that upon any conversion of the New Notes, Ciena will settle the principal amount thereof in cash. Accordingly, beginning in the fourth quarter of fiscal 2017, Ciena intends to use the treasury stock method for the New Notes in its diluted earnings per share calculation. Following settlement of the exchange, $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-17-000051:notes:292]
[same as prior period, unchanged from 0000936395-17-000038:notes:280]

[0000936395-17-000051:notes:293]
The decrease in warranty provisions during fiscal 2017 was primarily due to lower failure rates than previously estimated and reduced costs due to efficiencies.

[0000936395-17-000051:notes:294]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner during the construction period for accounting purposes. As of May 1, 2017, occupancy of both office buildings was complete. As such, Ciena recorded capital leases for these buildings, which will be depreciated over the lease terms and removed the build-to-suit construction in progress asset and the corresponding long-term liability. See Note 10 for more details regarding this arrangement.
