# CIEN note change history — 0000936395-17-000038 → 0000936395-17-000051


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2017-09-07):
[0000936395-17-000051:note_history:1]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 15, 2016, the plaintiffs filed a third amended complaint against the members of Cyan's board of directors, which generally alleged that they breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.

- changed (2017-09-07):
[0000936395-17-000051:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, which petition was granted on June 27, 2017. The matter is expected to be heard during the Supreme Court’s October 2017 Term. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2017-06-07, similarity 0.8352):
[0000936395-17-000038:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. On November 18, 2016, the parties each filed motions for summary judgment. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- changed (2017-09-07):
[0000936395-17-000051:note_history:3]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.
  (was, 2017-06-07, similarity 0.94):
[0000936395-17-000038:note_history:3]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the ‘673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

- removed (2017-09-07):
[0000936395-17-000038:note_history:4]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:5]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the "SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2016 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2016.
  (was, 2017-06-07, similarity 0.9986):
[0000936395-17-000038:note_history:5]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2016 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2016.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:6]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, share-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.
  (was, 2017-06-07, similarity 0.9994):
[0000936395-17-000038:note_history:6]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- changed (2017-09-07):
[0000936395-17-000051:note_history:7]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included either in other current assets or in other long-term assets depending upon the duration of the restriction.
  (was, 2017-06-07, similarity 0.8852):
[0000936395-17-000038:note_history:7]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in either other current assets or other long-term assets depending upon the duration of the restriction.

- changed (2017-09-07):
[0000936395-17-000051:note_history:8]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.
  (was, 2017-06-07, similarity 0.9947):
[0000936395-17-000038:note_history:8]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.

- changed (2017-09-07):
[0000936395-17-000051:note_history:9]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by Financial Accounting Standards Board ("FASB") Accounting Standards Update ("ASU") No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.
  (was, 2017-06-07, similarity 0.949):
[0000936395-17-000038:note_history:9]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

- changed (2017-09-07):
[0000936395-17-000051:note_history:10]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.
  (was, 2017-06-07, similarity 0.9994):
[0000936395-17-000038:note_history:10]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.

- changed (2017-09-07):
[0000936395-17-000051:note_history:11]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2014), United Kingdom (2014), Canada (2011), India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.
  (was, 2017-06-07, similarity 0.9995):
[0000936395-17-000038:note_history:11]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

- changed (2017-09-07):
[0000936395-17-000051:note_history:12]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $5.8 million at July 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and to continue to present such capitalized costs in other assets.
  (was, 2017-06-07, similarity 0.9686):
[0000936395-17-000038:note_history:12]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $6.4 million at April 30, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.

- added (2017-09-07):
[0000936395-17-000051:note_history:13]
In May 2014, the FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606) ("ASU 2014-09"), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

- added (2017-09-07):
[0000936395-17-000051:note_history:14]
For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require that it determine the stand alone selling price for each of the elements at the contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

- added (2017-09-07):
[0000936395-17-000051:note_history:15]
Ciena also expects certain installation and deployment and consulting and network design services will be recognized over a period of time rather than at a point in time.

- added (2017-09-07):
[0000936395-17-000051:note_history:16]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less and amortized over the period of performance if the period of the asset recognition is greater than one year.

- added (2017-09-07):
[0000936395-17-000051:note_history:17]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- added (2017-09-07):
[0000936395-17-000051:note_history:18]
In February 2016, the FASB issued ASU No. 2016-02, Leases ("ASU 2016-02"), which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- added (2017-09-07):
[0000936395-17-000051:note_history:19]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any related valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, with the prior periods adjusted accordingly, as a result of the adoption. Finally, Ciena will elect to continue to estimate expected forfeitures rather than account for forfeitures as they occur.

- added (2017-09-07):
[0000936395-17-000051:note_history:20]
In January 2017, the FASB issued ASU No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.

- added (2017-09-07):
[0000936395-17-000051:note_history:21]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. ASU 2017-12 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is evaluating the effect of the update on its Consolidated Financial Statements and disclosures.

- removed (2017-09-07):
[0000936395-17-000038:note_history:22]
In May 2014, FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require Ciena to determine the stand alone selling price for each of the elements at the contract inception and consequently Ciena expects certain software deliverables will be recognized at a point in time rather than over a period of time. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures, as well as the transition method.

- removed (2017-09-07):
[0000936395-17-000038:note_history:23]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- removed (2017-09-07):
[0000936395-17-000038:note_history:24]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard.

- removed (2017-09-07):
[0000936395-17-000038:note_history:25]
In January 2017, the FASB issued ASU No. 2017-1, Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:26]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-06-07, similarity 0.9683):
[0000936395-17-000038:note_history:26]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:27]
|  |  | July 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,674 |  |  | — |  |
|  |  | $ | 393,674 |  |  | $ | 486,303 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:28]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.3 million at July 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans is included in interest expense, and was $0.7 million and $0.8 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the term loans listed above are also net of any unamortized debt discounts.
  (was, 2017-06-07, similarity 0.9344):
[0000936395-17-000038:note_history:28]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.5 million at April 30, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.5 million and $0.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.

- changed (2017-09-07):
[0000936395-17-000051:note_history:29]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1.0 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed. The aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.
  (was, 2017-06-07, similarity 0.9981):
[0000936395-17-000038:note_history:29]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed and the aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.

- changed (2017-09-07):
[0000936395-17-000051:note_history:30]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of July 31, 2017 (in thousands):
  (was, 2017-06-07, similarity 0.9436):
[0000936395-17-000038:note_history:30]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability components of our 2022 Term Loan were as follows as of April 30, 2017 (in thousands):

- changed (2017-09-07):
[0000936395-17-000051:note_history:31]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,038 | ) |  | $ | (3,288 | ) |  | $393,674 |
  (was, 2017-06-07, similarity 0.9815):
[0000936395-17-000038:note_history:31]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,153 | ) |  | $ | (3,470 | ) |  | $393,377 |

- changed (2017-09-07):
[0000936395-17-000051:note_history:32]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):
  (was, 2017-06-07, similarity 0.9871):
[0000936395-17-000038:note_history:32]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loan (in thousands):

- changed (2017-09-07):
[0000936395-17-000051:note_history:33]
|  |  | July 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 393,674 |  |  | $ | 401,993 |  |
  (was, 2017-06-07, similarity 0.9469):
[0000936395-17-000038:note_history:33]
|  |  | April 30, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022(1) |  | $ | 393,377 |  |  | $ | 401,494 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:34]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2017-06-07, similarity 0.9961):
[0000936395-17-000038:note_history:34]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2017-09-07):
[0000936395-17-000051:note_history:35]
Maturity of 2017 Convertible Notes

- added (2017-09-07):
[0000936395-17-000051:note_history:36]
On June 15, 2017, the outstanding 0.875% Convertible Senior Notes matured and Ciena repaid the approximately $185.3 million in aggregate principal amount outstanding, together with approximately $0.8 million in accrued interest through the date of maturity.

- changed (2017-09-07):
[0000936395-17-000051:note_history:37]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-06-07, similarity 0.9737):
[0000936395-17-000038:note_history:37]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:38]
|  |  | July 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 188,509 |  |
|  |  | $ | 541,628 |  |  | $ | 767,379 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:39]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.5 million at July 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.4 million and $2.1 million during the first nine months of fiscal 2017 and 2016, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.
  (was, 2017-06-07, similarity 0.8878):
[0000936395-17-000038:note_history:39]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.9 million at April 30, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.0 million and $1.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.

- changed (2017-09-07):
[0000936395-17-000051:note_history:40]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of July 31, 2017 (in thousands):
  (was, 2017-06-07, similarity 0.9622):
[0000936395-17-000038:note_history:40]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our Ciena's outstanding issues of convertible notes were as follows as of April 30, 2017 (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:41]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,443 | ) |  | $ | 348,557 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,996 |  |  | $ | (9,893 | ) |  | $ | (1,032 | ) |  | $ | 193,071 |  |  | $ | 43,131 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:42]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2017:
  (was, 2017-06-07, similarity 0.9662):
[0000936395-17-000038:note_history:42]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2017:

- changed (2017-09-07):
[0000936395-17-000051:note_history:43]
|  |  | July 31, 2017 |
|  |  | Net Carrying Value (1) |  | Fair Value(2) |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 482,825 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 269,719 |  |
|  |  | $ | 541,628 |  |  | $ | 752,544 |  |
  (was, 2017-06-07, similarity 0.6549):
[0000936395-17-000038:note_history:43]
|  |  | April 30, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 185,085 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 449,313 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 254,925 |  |
|  |  | $ | 725,026 |  |  | $ | 889,323 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:44]
| (1) | Includes unamortized debt discount, accretion of principal and deferred debt issuance costs. |
  (was, 2017-06-07, similarity 0.9538):
[0000936395-17-000038:note_history:44]
| (1) | Includes unamortized debt discount, accretion of principal and debt issuance costs. |

- removed (2017-09-07):
[0000936395-17-000038:note_history:45]
|  |  | April 30, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,377 |  |  | — |  |
|  |  | $ | 393,377 |  |  | $ | 486,303 |  |

- removed (2017-09-07):
[0000936395-17-000038:note_history:46]
|  |  | April 30, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 188,509 |  |
|  |  | $ | 725,026 |  |  | $ | 767,379 |  |

- removed (2017-09-07):
[0000936395-17-000038:note_history:47]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 0.875% Convertible Senior Notes due June 15, 2017 | $ | 185,258 |  |  | $ | — |  |  | $ | (37 | ) |  | $185,221 |  | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,752 | ) |  | $348,248 |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,093 |  |  | $ | (10,428 | ) |  | $ | (1,108 | ) |  | $191,557 |  | $ | 43,131 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:48]
|  | July 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 225,032 |  |  | $ | — |  |  | (272 | ) |  | $ | 224,760 |  |
| Included in long-term investments | 59,976 |  |  | — |  |  | (102 | ) |  | 59,874 |  |
|  | $ | 285,008 |  |  | $ | — |  |  | $ | (374 | ) |  | $ | 284,634 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,983 |  |  | — |  |  | — |  |  | $ | 9,983 |  |
|  | $ | 9,983 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,983 |  |
  (was, 2017-06-07, similarity 0.9915):
[0000936395-17-000038:note_history:48]
|  | April 30, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 255,042 |  |  | $ | — |  |  | (233 | ) |  | $ | 254,809 |  |
| Included in long-term investments | 89,987 |  |  | — |  |  | (135 | ) |  | 89,852 |  |
|  | $ | 345,029 |  |  | $ | — |  |  | $ | (368 | ) |  | $ | 344,661 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,970 |  |  | — |  |  | — |  |  | $ | 19,970 |  |
|  | $ | 19,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,970 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:49]
The following table summarizes the final legal maturities of debt investments at July 31, 2017 (in thousands):
  (was, 2017-06-07, similarity 0.9668):
[0000936395-17-000038:note_history:49]
The following table summarizes the final legal maturities of debt investments at April 30, 2017 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:50]
The net carrying values of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-06-07, similarity 0.9683):
[0000936395-17-000038:note_history:50]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:51]
|  |  | July 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,674 |  |  | — |  |
|  |  | $ | 393,674 |  |  | $ | 486,303 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:52]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):
  (was, 2017-06-07, similarity 0.9871):
[0000936395-17-000038:note_history:52]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loan (in thousands):

- changed (2017-09-07):
[0000936395-17-000051:note_history:53]
|  |  | July 31, 2017 |
|  |  | Carrying Value(1) |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022 |  | $ | 393,674 |  |  | $ | 401,993 |  |
  (was, 2017-06-07, similarity 0.9469):
[0000936395-17-000038:note_history:53]
|  |  | April 30, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022(1) |  | $ | 393,377 |  |  | $ | 401,494 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:54]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2017-06-07, similarity 0.9737):
[0000936395-17-000038:note_history:54]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:55]
|  |  | July 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | — |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 188,509 |  |
|  |  | $ | 541,628 |  |  | $ | 767,379 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:56]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2017:
  (was, 2017-06-07, similarity 0.9662):
[0000936395-17-000038:note_history:56]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2017:

- changed (2017-09-07):
[0000936395-17-000051:note_history:57]
|  |  | July 31, 2017 |
|  |  | Net Carrying Value (1) |  | Fair Value(2) |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,557 |  |  | 482,825 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 193,071 |  |  | 269,719 |  |
|  |  | $ | 541,628 |  |  | $ | 752,544 |  |
  (was, 2017-06-07, similarity 0.6549):
[0000936395-17-000038:note_history:57]
|  |  | April 30, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 185,085 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 449,313 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 254,925 |  |
|  |  | $ | 725,026 |  |  | $ | 889,323 |  |

- changed (2017-09-07):
[0000936395-17-000051:note_history:58]
| (1) | Includes unamortized debt discount, accretion of principal and deferred debt issuance costs. |
  (was, 2017-06-07, similarity 0.9538):
[0000936395-17-000038:note_history:58]
| (1) | Includes unamortized debt discount, accretion of principal and debt issuance costs. |

- removed (2017-09-07):
[0000936395-17-000038:note_history:59]
|  |  | April 30, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,377 |  |  | — |  |
|  |  | $ | 393,377 |  |  | $ | 486,303 |  |

- removed (2017-09-07):
[0000936395-17-000038:note_history:60]
|  |  | April 30, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 188,509 |  |
|  |  | $ | 725,026 |  |  | $ | 767,379 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:61]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of July 31, 2017 (in thousands):
  (was, 2017-06-07, similarity 0.9436):
[0000936395-17-000038:note_history:61]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability components of our 2022 Term Loan were as follows as of April 30, 2017 (in thousands):

- changed (2017-09-07):
[0000936395-17-000051:note_history:62]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,038 | ) |  | $ | (3,288 | ) |  | $393,674 |
  (was, 2017-06-07, similarity 0.9815):
[0000936395-17-000038:note_history:62]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,153 | ) |  | $ | (3,470 | ) |  | $393,377 |

- changed (2017-09-07):
[0000936395-17-000051:note_history:63]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of July 31, 2017 (in thousands):
  (was, 2017-06-07, similarity 0.9622):
[0000936395-17-000038:note_history:63]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our Ciena's outstanding issues of convertible notes were as follows as of April 30, 2017 (in thousands):

- added (2017-09-07):
[0000936395-17-000051:note_history:64]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,443 | ) |  | $ | 348,557 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,996 |  |  | $ | (9,893 | ) |  | $ | (1,032 | ) |  | $ | 193,071 |  |  | $ | 43,131 |  |

- removed (2017-09-07):
[0000936395-17-000038:note_history:65]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 0.875% Convertible Senior Notes due June 15, 2017 | $ | 185,258 |  |  | $ | — |  |  | $ | (37 | ) |  | $185,221 |  | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,752 | ) |  | $348,248 |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,093 |  |  | $ | (10,428 | ) |  | $ | (1,108 | ) |  | $191,557 |  | $ | 43,131 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2017-09-07):
[0000936395-17-000051:note_history:66]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service falls within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.
  (was, 2017-06-07, similarity 0.9994):
[0000936395-17-000038:note_history:66]
VSOE, when determinable, is established based on Ciena's pricing and discounting practices for the specific product or service when sold separately. In determining whether VSOE exists, Ciena requires that a substantial majority of the selling prices for a product or service fall within a reasonably narrow pricing range. Ciena has been unable to establish TPE of selling price because its go-to-market strategy differs from that of others in its markets, and the extent of customization and differentiated features and functions varies among comparable products or services from its peers. Ciena determines BESP based upon management-approved pricing guidelines, which consider multiple factors including the type of product or service, gross margin objectives, competitive and market conditions, and the go-to-market strategy, all of which can affect pricing practices.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2017-09-07):
[0000936395-17-000051:note_history:67]
SUBSEQUENT EVENT

- added (2017-09-07):
[0000936395-17-000051:note_history:68]
On August 2, 2017, Ciena completed its offer to exchange its outstanding 3.75% Convertible Senior Notes due 2018 (the “Original Notes”) for a new series of 3.75% Convertible Senior Notes due 2018 (the “New Notes”) and an exchange fee of $2.50 per $1,000 original principal amount. The New Notes give Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares. Through these cash settlement options, Ciena believes that it will gain additional flexibility to better manage its long-term capital structure and reduce the dilutive impact of its convertible notes upon stockholders. It is Ciena’s current intent that upon any conversion of the New Notes, Ciena will settle the principal amount thereof in cash. Accordingly, beginning in the fourth quarter of fiscal 2017, Ciena intends to use the treasury stock method for the New Notes in its diluted earnings per share calculation. Following settlement of the exchange, $61.3 million in aggregate principal amount at maturity of Original Notes and $288.7 million in aggregate principal amount at maturity of the New Notes were outstanding.
