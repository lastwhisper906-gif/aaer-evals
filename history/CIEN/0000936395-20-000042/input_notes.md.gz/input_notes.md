# CIEN notes — 0000936395-20-000042


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000936395-20-000042:notes:1]
Part III of the Form 10-K incorporates by reference certain portions of the registrant’s definitive proxy statement for its 2021 Annual Meeting of Stockholders to be filed with the Commission not later than 120 days after the end of the fiscal year covered by this report.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-20-000042:notes:2]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0000936395-20-000042:notes:3]
Ciena Corporation (“Ciena” or the “Company”) is a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. Ciena provides hardware, software and services that e the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Ciena’s solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and emerging network operators.

[0000936395-20-000042:notes:4]
Ciena’s solutions include Networking Platforms, including Ciena’s Converged Packet Optical and Packet Networking portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Ciena’s Converged Packet Optical portfolio includes products and solutions that support the connection of content to content and users to content, including in long haul and regional, submarine and data center interconnect networks. Ciena’s Packet Networking portfolio includes products and solutions that enable next-generation metro, access and aggregation networks, connecting users to content in applications that include 5G, mobile backhaul, virtualization and enterprise services.

[0000936395-20-000042:notes:5]
To complement these solutions, Ciena offers Platform Software, which provides management, domain control and specialized applications that automate network lifecycle operations, including provisioning equipment and services, network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through Ciena’s Blue Planet® Software suite, Ciena enables customers to transform their business and operations support systems (“OSS”) through software-based automation of their network and IT infrastructures. To complement these hardware and software products, Ciena offers a broad range of services that help its customers build, operate and improve their networks and associated operational environments, including network optimization and migration offerings.

[0000936395-20-000042:notes:6]
Ciena refers to its complete portfolio vision as the Adaptive Network. The Adaptive Network emphasizes a programmable network infrastructure, software control and automation capabilities, network analytics and intelligence, and related advanced services. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-20-000042:notes:7]
Basis of Presentation

[0000936395-20-000042:notes:8]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000936395-20-000042:notes:9]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October in each year. Fiscal 2020 and fiscal 2019 each consisted of a 52-week fiscal year and fiscal 2018 consisted of a 53-week fiscal year. Effective the second quarter of fiscal 2020, Ciena changed the presentation of reporting for its financial statements and notes thereto to reflect the actual dates on which fiscal years ended. Because these dates can change from period to period, for consistency purposes, Ciena previously presented such information indicating that its fiscal years ended on October 31. This change, affecting only the presentation of such information, was made on a prospective basis and it does not impact comparability of previous financial results. Reference to prior reported periods have been changed to reflect the actual period end dates of November 2, 2019, November 3, 2018 and October 28, 2017 for periods reported herein.

[0000936395-20-000042:notes:10]
Business Combinations

[0000936395-20-000042:notes:11]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market

[0000936395-20-000042:notes:12]
participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-20-000042:notes:13]
Use of Estimates

[0000936395-20-000042:notes:14]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-20-000042:notes:15]
Cash and Cash Equivalents

[0000936395-20-000042:notes:16]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending on the duration of the restriction.

[0000936395-20-000042:notes:17]
Investments

[0000936395-20-000042:notes:18]
Ciena’s investments in debt securities are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-20-000042:notes:19]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 31, 2020, the combined carrying value of these investments was $13.4 million. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena evaluates these investments for impairment or observable price changes quarterly and records adjustments to interest and other income (loss), net on the Consolidated Statements of Operations.

[0000936395-20-000042:notes:20]
Inventories

[0000936395-20-000042:notes:21]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-20-000042:notes:22]
Segment Reporting

[0000936395-20-000042:notes:23]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the Company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 24 below.

[0000936395-20-000042:notes:24]
Goodwill

[0000936395-20-000042:notes:25]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-20-000042:notes:26]
Ciena tests goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-20-000042:notes:27]
Long-lived Assets

[0000936395-20-000042:notes:28]
Long-lived assets include: equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0000936395-20-000042:notes:29]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-20-000042:notes:30]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two years to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-20-000042:notes:31]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0000936395-20-000042:notes:32]
Leases

[0000936395-20-000042:notes:33]
At the inception of a contract, Ciena must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts follows the assessment of whether there is a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations in the Consolidated Balance Sheets.

[0000936395-20-000042:notes:34]
Ciena has operating and finance leases that primarily relate to real property. Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities.

[0000936395-20-000042:notes:35]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Consolidated Statements of Operations.

[0000936395-20-000042:notes:36]
Intangible Assets

[0000936395-20-000042:notes:37]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-20-000042:notes:38]
Maintenance Spares

[0000936395-20-000042:notes:39]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.

[0000936395-20-000042:notes:40]
Concentrations

[0000936395-20-000042:notes:41]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-20-000042:notes:42]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers and Web-scale providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 24 below.

[0000936395-20-000042:notes:43]
Additionally, Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0000936395-20-000042:notes:44]
Revenue Recognition

[0000936395-20-000042:notes:45]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-20-000042:notes:46]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-20-000042:notes:47]
•identification of the contract, or contracts, with a customer;

[0000936395-20-000042:notes:48]
•identification of the performance obligations in the contract;

[0000936395-20-000042:notes:49]
•determination of the transaction price;

[0000936395-20-000042:notes:50]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-20-000042:notes:51]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-20-000042:notes:52]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-20-000042:notes:53]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing

[0000936395-20-000042:notes:54]
component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-20-000042:notes:55]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-20-000042:notes:56]
Significant Judgments

[0000936395-20-000042:notes:57]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-20-000042:notes:58]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-20-000042:notes:59]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-20-000042:notes:60]
Capitalized Contract Acquisition Costs

[0000936395-20-000042:notes:61]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the Financial Accounting Standards Board (“FASB”) Transition Resource Group for Revenue Recognition with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-20-000042:notes:62]
For the additional disclosures on capitalized contract acquisition costs, see Note 2 below.

[0000936395-20-000042:notes:63]
Warranty Accruals

[0000936395-20-000042:notes:64]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-20-000042:notes:65]
Accounts Receivable, Net

[0000936395-20-000042:notes:66]
Ciena’s allowance for doubtful accounts receivable is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena’s allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer’s financial condition changes, or if actual defaults are higher than Ciena’s historical experience, Ciena may be required to take a charge for an allowance for doubtful accounts receivable, which could have an adverse impact on its results of operations.

[0000936395-20-000042:notes:67]
Research and Development

[0000936395-20-000042:notes:68]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-20-000042:notes:69]
Government Grants

[0000936395-20-000042:notes:70]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates. See Note 26 below.

[0000936395-20-000042:notes:71]
Advertising Costs

[0000936395-20-000042:notes:72]
Ciena expenses all advertising costs as incurred.

[0000936395-20-000042:notes:73]
Legal Costs

[0000936395-20-000042:notes:74]
Ciena expenses legal costs associated with litigation as incurred.

[0000936395-20-000042:notes:75]
Share-Based Compensation Expense

[0000936395-20-000042:notes:76]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena’s stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total shareholder return as compared to an index of peer companies, in whole or in part. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total shareholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of performance based awards subject to total shareholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. See Note 23 below.

[0000936395-20-000042:notes:77]
Stock Repurchase Plan

[0000936395-20-000042:notes:78]
Shares repurchased pursuant to Ciena’s share repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena’s accounting policy related to its share repurchases is to reduce its common stock based on the par value of the shares and to reduce its capital surplus for the excess of the repurchase price over the par value. Since the inception of its share repurchase program in December 2018, Ciena has had an accumulated deficit balance; therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0000936395-20-000042:notes:79]
Due to the continued uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, Ciena considered it prudent to temporarily suspend purchases of its common stock under its stock repurchase program effective as of March 17, 2020. See Note 27 below for information related to the resumption of purchases under this plan in fiscal 2021.

[0000936395-20-000042:notes:80]
Income Taxes

[0000936395-20-000042:notes:81]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities (“DTA”) for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-20-000042:notes:82]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 and 2014 through 2018, in Canada for 2013 through 2015, and in the United Kingdom for 2014 through 2018. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2017), United Kingdom (2014), Canada (2013), and India (2012). Limited adjustments can be made to federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-20-000042:notes:83]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2020, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized totaled approximately $375.0 million. If these earnings were distributed to the U.S. in the form of dividends, or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, Ciena would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes.

[0000936395-20-000042:notes:84]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-20-000042:notes:85]
Ciena adopted ASU 2016-09, Improvements to Employee Share-Based Payment Accounting, in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018.

[0000936395-20-000042:notes:86]
The Tax Cuts and Jobs Act (the “Tax Act”) includes provisions that affected Ciena in fiscal 2019 and fiscal 2020, including a provision designed to tax global intangible low-taxed income (“GILTI”). An accounting policy choice is allowed to either treat taxes due on future U.S. inclusions related to GILTI in taxable income as a current-period expense when incurred (the “period cost method”) or factor such amounts into the measurement of deferred taxes (the “deferred method”). The calculation of the deferred balance with respect to the GILTI tax provisions will depend, in part, on analyzing global income to determine whether future U.S. inclusions in taxable income are expected related to GILTI and, if so, what the impact is expected to be. Ciena is electing to use the period cost method for future GILTI inclusions. Additionally, Ciena is electing to use the incremental cash tax savings approach when determining whether a valuation allowance needs to be recorded against the U.S. net operating loss (“NOL”) due to the GILTI inclusions.

[0000936395-20-000042:notes:87]
The Tax Act also introduced an alternative tax known as the base erosion and anti-abuse tax (“BEAT”). An accounting policy choice has been made to consider BEAT as a period cost when incurred.

[0000936395-20-000042:notes:88]
Loss Contingencies

[0000936395-20-000042:notes:89]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates

[0000936395-20-000042:notes:90]
current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-20-000042:notes:91]
Fair Value of Financial Instruments

[0000936395-20-000042:notes:92]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s term loan, see Note 18 below.

[0000936395-20-000042:notes:93]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-20-000042:notes:94]
•Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities;

[0000936395-20-000042:notes:95]
•Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000936395-20-000042:notes:96]
•Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data.

[0000936395-20-000042:notes:97]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-20-000042:notes:98]
Restructuring

[0000936395-20-000042:notes:99]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions and redesign business processes. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 4 below.

[0000936395-20-000042:notes:100]
Foreign Currency

[0000936395-20-000042:notes:101]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 5 below.

[0000936395-20-000042:notes:102]
Derivatives

[0000936395-20-000042:notes:103]
Ciena’s 3.75% Convertible Senior Notes due October 15, 2018 (the “New Notes”) included a conversion feature that was accounted for as a separate embedded derivative. The embedded conversion feature was recorded at fair value using the underlying stock price, time to maturity and expected volatility of Ciena’s stock and conversion price. These changes are included in interest and other income (loss), net on the Consolidated Statement of Operations. On November 15, 2018, Ciena settled this embedded conversion feature.

[0000936395-20-000042:notes:104]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loan. All of these derivatives

[0000936395-20-000042:notes:105]
are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates.

[0000936395-20-000042:notes:106]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-20-000042:notes:107]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.

[0000936395-20-000042:notes:108]
See Notes 7 and 15 below.

[0000936395-20-000042:notes:109]
Computation of Net Income (Loss) per Share

[0000936395-20-000042:notes:110]
Ciena calculates basic earnings per share by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income (loss) per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic net income (loss) per common share (“Basic EPS”) and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 20 below.

[0000936395-20-000042:notes:111]
Software Development Costs

[0000936395-20-000042:notes:112]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-20-000042:notes:113]
Newly Issued Accounting Standards - Effective

[0000936395-20-000042:notes:114]
In February 2016, FASB issued ASC 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 3, 2019, Ciena adopted ASC 842, which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet, on a modified retrospective basis, such that related amounts in prior periods have not been restated.

[0000936395-20-000042:notes:115]
As a practical expedient for disclosure, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient, Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities. In connection with its adoption of ASC 842, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 842.

[0000936395-20-000042:notes:116]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of November 2, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Consolidated Balance Sheet under prior accounting guidance. Upon adoption of ASC 842, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying

[0000936395-20-000042:notes:117]
values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Consolidated Statements of Operations or Consolidated Statements of Cash Flows.

[0000936395-20-000042:notes:118]
Opening Balance Adjustments

[0000936395-20-000042:notes:119]
The following table summarizes the cumulative effect of the changes made to Ciena’s Consolidated Balance Sheet in connection with the adoption of ASC 842 (in thousands):

[0000936395-20-000042:notes:120]
|  |  | Balance at November 2, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 3, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484) |  | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244) |  | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders’ equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

[0000936395-20-000042:notes:121]
(1) Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to ROU assets.

[0000936395-20-000042:notes:122]
(2) Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets.

[0000936395-20-000042:notes:123]
(3) Represents $20.5 million of lease liabilities for operating leases.

[0000936395-20-000042:notes:124]
(4) Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to ROU assets.

[0000936395-20-000042:notes:125]
(5) Represents $55.6 million of lease liabilities for operating leases.

[0000936395-20-000042:notes:126]
See Note 17 below for additional information.

[0000936395-20-000042:notes:127]
Fair Value Measurement

[0000936395-20-000042:notes:128]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, and early adoption is permitted. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-20-000042:notes:129]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-20-000042:notes:130]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. The new standard replaces the incurred loss impairment model. Under this standard, Ciena will be required to use a forward-looking expected credit loss model for accounts receivable, contract assets, and other financial instruments. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 on a modified retrospective basis with the cumulative effect of adoption recorded as an adjustment to retained earnings. This standard will not have a material impact on Ciena’s Consolidated Financial Statements and disclosures at adoption.


## us-gaap:InventoryPolicyTextBlock

[0000936395-20-000042:notes:131]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-20-000042:notes:132]
REVENUEDisaggregation of Revenue
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-20-000042:notes:133]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

[0000936395-20-000042:notes:134]
|  | Year Ended October 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,547,647 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,547,647 |  |
| Packet Networking | 267,416 |  |  | — |  |  | — |  |  | — |  |  | 267,416 |  |
| Platform Software and Services | — |  |  | 197,809 |  |  | — |  |  | — |  |  | 197,809 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 62,632 |  |  | — |  |  | 62,632 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 269,354 |  |  | 269,354 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 152,003 |  |  | 152,003 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,296 |  |  | 35,296 |  |
| Total revenue by product line | $ | 2,815,063 |  |  | $ | 197,809 |  |  | $ | 62,632 |  |  | $ | 456,653 |  |  | $ | 3,532,157 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,815,063 |  |  | $ | 69,099 |  |  | $ | 19,583 |  |  | $ | 14,363 |  |  | $ | 2,918,108 |  |
| Products and services transferred over time | — |  |  | 128,710 |  |  | 43,049 |  |  | 442,290 |  |  | 614,049 |  |
| Total revenue by timing of revenue recognition | $ | 2,815,063 |  |  | $ | 197,809 |  |  | $ | 62,632 |  |  | $ | 456,653 |  |  | $ | 3,532,157 |  |

[0000936395-20-000042:notes:135]
|  | Year Ended November 2, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,562,841 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,562,841 |  |
| Packet Networking | 348,477 |  |  | — |  |  | — |  |  | — |  |  | 348,477 |  |
| Platform Software and Services | — |  |  | 155,376 |  |  | — |  |  | — |  |  | 155,376 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,555 |  |  | — |  |  | 54,555 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 261,337 |  |  | 261,337 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 148,233 |  |  | 148,233 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 41,312 |  |  | 41,312 |  |
| Total revenue by product line | $ | 2,911,318 |  |  | $ | 155,376 |  |  | $ | 54,555 |  |  | $ | 450,882 |  |  | $ | 3,572,131 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,911,318 |  |  | $ | 55,530 |  |  | $ | 17,697 |  |  | $ | 18,802 |  |  | $ | 3,003,347 |  |
| Products and services transferred over time | — |  |  | 99,846 |  |  | 36,858 |  |  | 432,080 |  |  | 568,784 |  |
| Total revenue by timing of revenue recognition | $ | 2,911,318 |  |  | $ | 155,376 |  |  | $ | 54,555 |  |  | $ | 450,882 |  |  | $ | 3,572,131 |  |

[0000936395-20-000042:notes:136]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and CALA regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) EMEA; and (iii) APAC. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel.

[0000936395-20-000042:notes:137]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-20-000042:notes:138]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |
| Geographic Distribution: |  |  |  |
| Americas | $ | 2,469,278 |  |  | $ | 2,503,913 |  |
| EMEA | 591,468 |  |  | 566,718 |  |
| APAC | 471,411 |  |  | 501,500 |  |
| Total revenue by geographic distribution | $ | 3,532,157 |  |  | $ | 3,572,131 |  |

[0000936395-20-000042:notes:139]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines.

[0000936395-20-000042:notes:140]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, Waveserver® stackable interconnect system, the 6500 Reconfigurable Line System (RLS) and the 5400 family of Packet-Optical Platforms. This product line also includes sales of the Z-Series Packet-Optical Platform.

[0000936395-20-000042:notes:141]
•Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics.

[0000936395-20-000042:notes:142]
The Networking Platforms segment revenue also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-20-000042:notes:143]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support our installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-20-000042:notes:144]
•Blue Planet Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led OSS transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-20-000042:notes:145]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-20-000042:notes:146]
•Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-20-000042:notes:147]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-20-000042:notes:148]
Contract Balances

[0000936395-20-000042:notes:149]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-20-000042:notes:150]
|  |  | Balance at October 31, 2020 |  | Balance at November 2, 2019 |
| Accounts receivable, net |  | $ | 719,405 |  |  | $ | 724,854 |  |
| Contract assets for unbilled accounts receivable |  | $ | 85,843 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 158,363 |  |  | $ | 156,873 |  |

[0000936395-20-000042:notes:151]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Consolidated Balance Sheets. See Note 10 below.

[0000936395-20-000042:notes:152]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $101.9 million and $95.1 million of revenue during fiscal 2020 and 2019, respectively, that was included in the deferred revenue balance at November 3, 2019 and November 4, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2020 and 2019.

[0000936395-20-000042:notes:153]
Capitalized contract acquisition costs consist of deferred sales commissions and were $15.3 million and $15.7 million as of October 31, 2020 and November 2, 2019, respectively, and are included in other current assets and other assets. The amortization expense associated with these costs was $22.4 million and $18.6 million during fiscal 2020 and fiscal 2019, respectively, and are included in sales and marketing expense.

[0000936395-20-000042:notes:154]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of October 31, 2020, the aggregate amount of RPO was $1.0 billion. As of October 31, 2020, Ciena expects approximately 81% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-20-000042:notes:155]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-20-000042:notes:156]
|  | October 31, 2020 |  | November 2, 2019 |
| Products | $ | 17,534 |  |  | $ | 27,366 |  |
| Services | 140,829 |  |  | 129,507 |  |
|  | 158,363 |  |  | 156,873 |  |
| Less current portion | (108,700) |  |  | (111,381) |  |
| Long-term deferred revenue | $ | 49,663 |  |  | $ | 45,492 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-20-000042:notes:157]
BUSINESS COMBINATIONS
Centina Systems, Inc. Acquisition

[0000936395-20-000042:notes:158]
On November 2, 2019, Ciena acquired Centina Systems, Inc. (“Centina”), a provider of service assurance analytics and network performance management solutions, for approximately $34.0 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-20-000042:notes:159]
During fiscal 2020, Ciena incurred approximately $0.8 million of acquisition-related costs associated with this transaction. These costs primarily reflect fees associated with financial, legal and accounting advisors.

[0000936395-20-000042:notes:160]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-20-000042:notes:161]
|  | Amount |
| Cash and cash equivalents | $ | 5,718 |  |
| Accounts receivable | 610 |  |
| Prepaid expenses and other | 536 |  |
| Equipment, furniture and fixtures | 17 |  |
| Goodwill | 13,055 |  |
| Customer relationships and contracts | 400 |  |
| Developed technology | 22,200 |  |
| Accounts payable | (47) |  |
| Accrued liabilities | (286) |  |
| Deferred revenue | (1,493) |  |
| Deferred tax liability | (6,692) |  |
| Total purchase consideration | $ | 34,018 |  |

[0000936395-20-000042:notes:162]
Customer relationships and contracts represent agreements with existing Centina customers and have an estimated useful life of two years.

[0000936395-20-000042:notes:163]
Developed technology represents purchased technology that has reached technological feasibility and for which Centina had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-20-000042:notes:164]
The goodwill generated from the acquisition of Centina is primarily related to expected synergies. The total goodwill amount was recorded in the Blue Planet Automation Software and Services segment. The goodwill is not deductible for income tax purposes.

[0000936395-20-000042:notes:165]
Pro forma disclosures have not been included due to immateriality.

[0000936395-20-000042:notes:166]
DonRiver Acquisition

[0000936395-20-000042:notes:167]
On October 1, 2018, Ciena acquired Don River Holdings, LLC (“ DonRiver”), a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. This transaction has been accounted for as the acquisition of a business.

[0000936395-20-000042:notes:168]
During fiscal 2020, fiscal 2019 and fiscal 2018, Ciena incurred approximately $6.9 million, $7.5 million and $3.5 million, respectively. These costs and expenses include fees associated with financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisition of DonRiver, including the contingent compensation portion of the three year earn-out agreement as described below. These costs were recorded in acquisition and integration costs in the Consolidated Statement of Operations.

[0000936395-20-000042:notes:169]
The following table summarizes the purchase price for the acquisition (in thousands):

[0000936395-20-000042:notes:170]
|  | Amount |
| Cash | $ | 43,283 |  |
| Contingent consideration | 10,900 |  |
| Total purchase price | $ | 54,183 |  |

[0000936395-20-000042:notes:171]
|  | Amount |
| Cash and cash equivalents | $ | 1,025 |  |
| Accounts receivable | 4,790 |  |
| Prepaid expenses and other long-term assets | 372 |  |
| Goodwill | 10,453 |  |
| Customer relationships and contracts | 37,700 |  |
| Developed technology | 9,700 |  |
| Deferred revenue | (193) |  |
| Other current and long-term liabilities | (9,664) |  |
| Total purchase price | $ | 54,183 |  |

[0000936395-20-000042:notes:172]
The acquisition of DonRiver included a $28.5 million three-year earn-out arrangement that consisted of both a contingent consideration element and a contingent compensation element. The contingent consideration element required additional cash consideration to be paid based on the future revenues generally derived from the DonRiver business over a 25-month period from the acquisition date through October 31, 2020. The undiscounted amounts potentially payable by Ciena under the contingent consideration element ranged from $0.0 million to $15.0 million in the aggregate over the period. The $10.9 million fair value of the contingent consideration element as of the acquisition date was estimated by applying the income approach based on a discounted cash flow technique using Monte Carlo simulations. See Note 7 below. The contingent compensation element of the earn-out arrangement included an employment condition for the selling shareholders who became employees of Ciena upon the completion of the acquisition. The range of amounts that Ciena could pay under the contingent compensation element is between $0.0 million and $13.5 million in the aggregate over the period. These amounts are accrued over the period earned and recorded as expense in the acquisition and integration costs line item in the Consolidated Statement of Operations. During fiscal 2020, fiscal 2019 and fiscal 2018, Ciena recorded $6.9 million, $5.1 million and $0.4 million, of contingent compensation associated with the earn-out arrangement, respectively.

[0000936395-20-000042:notes:173]
The contingent consideration liability established at closing had an acquisition date fair value of $10.9 million. As of November 2, 2019, the fair value of the contingent consideration liability was $8.1 million. During fiscal 2020 and fiscal 2019, decreases of $3.7 million and $2.8 million, respectively, were recorded as reductions to expense in the acquisition and integration cost line item in the Consolidated Statement of Operations. During fiscal 2019, $4.4 million of the total contingent consideration liability was earned. This payment was paid during the first quarter of fiscal 2020. As of October 31, 2020, no contingent consideration liability remained.

[0000936395-20-000042:notes:174]
Customer relationships and contracts represent agreements with existing DonRiver customers. Customer relationships and contracts are amortized on a straight-line basis over their estimated useful life of seven years. Fair value was determined using the multi-period excess earnings method based on the present value of the incremental after-tax cash flows (or “excess earnings”) attributable to customer relationships for a discrete projection period.

[0000936395-20-000042:notes:175]
Developed technology represents purchased technology that had reached technological feasibility and for which DonRiver had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of seven years.

[0000936395-20-000042:notes:176]
The goodwill generated from the acquisition of DonRiver is primarily related to expected synergies. The total goodwill amount was recorded in the previous Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.

[0000936395-20-000042:notes:177]
Packet Design Acquisition

[0000936395-20-000042:notes:178]
On July 2, 2018, Ciena acquired Packet Design, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics, in a cash transaction for approximately $41.1 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-20-000042:notes:179]
During fiscal 2018, Ciena incurred approximately $1.6 million of acquisition-related costs associated with this transaction. There were minimal acquisition-related costs associated with this transaction during fiscal 2019. These costs and expenses include fees associated with financial, legal and accounting advisors and severance and other employment-related costs, including payments to certain former Packet Design employees.

[0000936395-20-000042:notes:180]
|  | Amount |
| Cash and cash equivalents | $ | 642 |  |
| Accounts receivable | 1,525 |  |
| Prepaid expenses and other | 450 |  |
| Equipment, furniture and fixtures | 31 |  |
| Goodwill | 20,304 |  |
| Customer relationships and contracts | 2,200 |  |
| Developed technology | 21,900 |  |
| Accounts payable | (165) |  |
| Accrued liabilities | (657) |  |
| Deferred revenue | (5,176) |  |
| Total purchase price | $ | 41,054 |  |

[0000936395-20-000042:notes:181]
Customer relationships and contracts represent agreements with existing Packet Design customers. Customer relationships and contracts are amortized on a straight line basis over their estimated useful life of three years.

[0000936395-20-000042:notes:182]
Developed technology represents purchased technology that had reached technological feasibility and for which Packet Design had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-20-000042:notes:183]
The goodwill generated from the acquisition of Packet Design is primarily related to expected synergies. The total goodwill amount was recorded in the previous Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-20-000042:notes:184]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Consolidated Balance Sheets, for the fiscal years indicated (in thousands):

[0000936395-20-000042:notes:185]
|  | Workforcereduction |  | Consolidationof excessfacilities and other restructuring activities |  | Total |
| Balance at October 28, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Charges | 14,853 |  | (1) | 3,890 |  | (4) | 18,743 |  |
| Cash payments | (14,036) |  |  | (3,799) |  |  | (17,835) |  |
| Balance at November 3, 2018 | 2,108 |  |  | 1,739 |  |  | 3,847 |  |
| Charges | 13,779 |  | (2) | 10,759 |  | (5) | 24,538 |  |
| Cash payments | (11,904) |  |  | (1,338) |  |  | (13,242) |  |
| Balance at November 2, 2019 | 3,983 |  |  | 11,160 |  |  | 15,143 |  |
| Charges | 7,282 |  | (3) | 15,370 |  | (6) | 22,652 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160) |  | (7) | (11,160) |  |
| Cash payments | (8,350) |  |  | (15,370) |  |  | (23,720) |  |
| Balance at October 31, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Current restructuring liabilities | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-20-000042:notes:186]
_________________________________

[0000936395-20-000042:notes:187]
(1) During fiscal 2018, Ciena recorded a charge of $14.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 240 employees.

[0000936395-20-000042:notes:188]
(2) During fiscal 2019, Ciena recorded a charge of $13.8 million of severance and other employee-related costs associated with a workforce reduction of approximately 283 employees.

[0000936395-20-000042:notes:189]
(3) During fiscal 2020, Ciena recorded a charge of $7.3 million of severance and other employee-related costs associated with a workforce reduction of approximately 149 employees.

[0000936395-20-000042:notes:190]
(4) Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and in Gurgaon, India.

[0000936395-20-000042:notes:191]
(5) Reflects unfavorable lease commitments in connection with a portion of facilities located in Alpharetta, Georgia, Spokane, Washington, Durham, North Carolina and Hanover, Maryland.

[0000936395-20-000042:notes:192]
(6) Primarily represents costs and imputed interest expense related to restructured facilities and the redesign of certain business processes.

[0000936395-20-000042:notes:193]
(7) Represents restructuring reserve liability recognized as a reduction to Operating ROU assets, net in relation to adoption of ASC 842. See Notes 1 and 17 for further discussion.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-20-000042:notes:194]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-20-000042:notes:195]
|  |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Interest income |  | $ | 6,860 |  |  | $ | 14,410 |  |  | $ | 13,703 |  |
| Gain on non-hedge designated foreign currency forward contracts |  | 5,551 |  |  | 3 |  |  | 6,791 |  |
| Foreign currency exchange losses |  | (13,022) |  |  | (9,800) |  |  | (19,434) |  |
| Loss on fair value of debt conversion liability |  | — |  |  | — |  |  | (12,070) |  |
| Other |  | 1,575 |  |  | (737) |  |  | (1,019) |  |
| Interest and other income (loss), net |  | $ | 964 |  |  | $ | 3,876 |  |  | $ | (12,029) |  |

[0000936395-20-000042:notes:196]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2020, 2019 and 2018, Ciena recorded $13.0 million, $9.8 million and $19.4 million, respectively, in exchange rate losses, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the related remeasurement adjustments were recorded in interest and other income (loss), net. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is also reported in interest and other income (loss), net. During fiscal 2019, Ciena recorded minimal gains from non-hedge designated foreign currency forward contracts. For fiscal 2020 and fiscal 2018, Ciena recorded gains of $5.6 million and $6.8 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-20-000042:notes:197]
SHORT-TERM AND LONG-TERM INVESTMENTS
 As of October 31, 2020, investments are comprised of the following (in thousands):

[0000936395-20-000042:notes:198]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

[0000936395-20-000042:notes:199]
As of November 2, 2019, investments are comprised of the following (in thousands):

[0000936395-20-000042:notes:200]
|  | November 2, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3) |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3) |  |  | $ | 119,954 |  |

[0000936395-20-000042:notes:201]
The following table summarizes the legal maturities of debt investments at October 31, 2020 (in thousands):

[0000936395-20-000042:notes:202]
|  | October 31, 2020 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 150,559 |  |  | $ | 150,667 |  |
| Due in 1-2 years | 82,252 |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 232,893 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-20-000042:notes:203]
FAIR VALUE MEASUREMENTS
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-20-000042:notes:204]
|  | October 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 889,293 |  |  | $ | — |  |  | $ | — |  |  | $ | 889,293 |  |
| Bond mutual fund | 50,361 |  |  | — |  |  | — |  |  | 50,361 |  |
| Deferred compensation plan assets | 8,213 |  |  | — |  |  | — |  |  | 8,213 |  |
| U.S. government obligations | — |  |  | 232,893 |  |  | — |  |  | 232,893 |  |
| Foreign currency forward contracts | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Total assets measured at fair value | $ | 947,867 |  |  | $ | 232,975 |  |  | $ | — |  |  | $ | 1,180,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |
| Forward starting interest rate swaps | — |  |  | 28,513 |  |  | — |  |  | 28,513 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 29,194 |  |  | $ | — |  |  | $ | 29,194 |  |

[0000936395-20-000042:notes:205]
|  | November 2, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Deferred compensation plan assets | 4,974 |  |  | — |  |  | — |  |  | 4,974 |  |
| U.S. government obligations | — |  |  | 119,954 |  |  | — |  |  | 119,954 |  |
| Foreign currency forward contracts | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Total assets measured at fair value | $ | 764,088 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 885,612 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Forward starting interest rate swaps | — |  |  | 21,093 |  |  | — |  |  | 21,093 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000042:notes:206]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-20-000042:notes:207]
|  | October 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 939,654 |  |  | $ | — |  |  | $ | — |  |  | $ | 939,654 |  |
| Short-term investments | — |  |  | 150,667 |  |  | — |  |  | 150,667 |  |
| Prepaid expenses and other | — |  |  | 82 |  |  | — |  |  | 82 |  |
| Other long-term assets | 8,213 |  |  | 82,226 |  |  | — |  |  | 90,439 |  |
| Total assets measured at fair value | $ | 947,867 |  |  | $ | 232,975 |  |  | $ | — |  |  | $ | 1,180,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 681 |  |  | $ | — |  |  | $ | 681 |  |
| Other long-term obligations | — |  |  | 28,513 |  |  | — |  |  | 28,513 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 29,194 |  |  | $ | — |  |  | $ | 29,194 |  |

[0000936395-20-000042:notes:208]
|  | November 2, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Short-term investments | — |  |  | 109,940 |  |  | — |  |  | 109,940 |  |
| Prepaid expenses and other | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Long-term investments | — |  |  | 10,014 |  |  | — |  |  | 10,014 |  |
| Other long-term assets | 4,974 |  |  | — |  |  | — |  |  | 4,974 |  |
| Total assets measured at fair value | $ | 764,088 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 885,612 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Other long-term obligations | — |  |  | 21,093 |  |  | 3,705 |  |  | 24,798 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000042:notes:209]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.As of October 31, 2020, none of Ciena’s existing liabilities were classified as Level 3. As of November 2, 2019, Ciena’s Level 3 liability included $3.7 million in accrued liabilities and other short-term obligations. This reflected a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. During the third quarter of fiscal 2020, the total contingent consideration liability was recorded as a reduction to expense in acquisition and integration costs on the Consolidated Statements of Operations to reflect the fair value of the consideration using the income approach. No contingent consideration liability remains in Other long-term obligations on the Consolidated Balance Sheets as of October 31, 2020.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-20-000042:notes:210]
ACCOUNTS RECEIVABLE
As of October 31, 2020, no customer accounted for 10.0% of net accounts receivable. As of November 2, 2019, one customer accounted for 12.0% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The reduction in Ciena’s allowance for doubtful accounts as of October 31, 2020 compared to November 2, 2019 is primarily due to the final settlement from a significant asset impairment of $12.2 million for a trade receivable related to a single customer in the APAC region recorded in fiscal 2017. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-20-000042:notes:211]
| Year Ended |  | Beginning Balance |  | Provisions |  | Net Deductions |  | Ending Balance |
| November 3, 2018 |  | $ | 17,580 |  |  | $ | 2,700 |  |  | $ | 2,902 |  |  | $ | 17,378 |  |
| November 2, 2019 |  | $ | 17,378 |  |  | $ | 6,740 |  |  | $ | 4,017 |  |  | $ | 20,101 |  |
| October 31, 2020 |  | $ | 20,101 |  |  | $ | 8,855 |  |  | $ | 18,358 |  |  | $ | 10,598 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-20-000042:notes:212]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-20-000042:notes:213]
|  | October 31, 2020 |  | November 2, 2019 |
| Raw materials | $ | 119,481 |  |  | $ | 99,041 |  |
| Work-in-process | 13,738 |  |  | 13,657 |  |
| Finished goods | 210,050 |  |  | 226,622 |  |
| Deferred cost of goods sold | 40,747 |  |  | 53,051 |  |
|  | 384,016 |  |  | 392,371 |  |
| Reserve for excess and obsolescence | (39,637) |  |  | (47,322) |  |
|  | $ | 344,379 |  |  | $ | 345,049 |  |

[0000936395-20-000042:notes:214]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During fiscal 2020, fiscal 2019 and fiscal 2018, Ciena recorded a provision for excess and obsolescence of $24.7 million, $28.1 million, and $30.6 million, respectively, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.

[0000936395-20-000042:notes:215]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-20-000042:notes:216]
| Year Ended |  | Beginning Balance |  | Provisions |  | Disposals |  | Ending Balance |
| November 3, 2018 |  | $ | 51,206 |  |  | $ | 30,615 |  |  | $ | 30,883 |  |  | $ | 50,938 |  |
| November 2, 2019 |  | $ | 50,938 |  |  | $ | 28,085 |  |  | $ | 31,701 |  |  | $ | 47,322 |  |
| October 31, 2020 |  | $ | 47,322 |  |  | $ | 24,701 |  |  | $ | 32,386 |  |  | $ | 39,637 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-20-000042:notes:217]
PREPAID EXPENSES AND OTHERAs of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-20-000042:notes:218]
|  | October 31, 2020 |  | November 2, 2019 |
| Contract assets for unbilled accounts receivable | $ | 85,843 |  |  | $ | 84,046 |  |
| Prepaid VAT and other taxes | 72,838 |  |  | 84,706 |  |
| Prepaid expenses | 70,647 |  |  | 48,680 |  |
| Product demonstration equipment, net | 44,793 |  |  | 38,900 |  |
| Other non-trade receivables | 21,981 |  |  | 28,136 |  |
| Capitalized contract acquisition costs | 11,296 |  |  | 11,677 |  |
| Deferred deployment expense | 604 |  |  | 125 |  |
| Derivative assets | 82 |  |  | 1,570 |  |
| Restricted cash | — |  |  | 74 |  |
|  | $ | 308,084 |  |  | $ | 297,914 |  |

[0000936395-20-000042:notes:219]
Depreciation of product demonstration equipment was $9.0 million, $8.8 million and $9.0 million for fiscal 2020, 2019 and 2018, respectively.

[0000936395-20-000042:notes:220]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-20-000042:notes:221]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-20-000042:notes:222]
|  | October 31, 2020 |  | November 2, 2019 |
| Equipment, furniture and fixtures | $ | 523,231 |  |  | $ | 544,012 |  |
| Building subject to finance lease | 70,791 |  |  | 71,760 |  |
| Leasehold improvements | 89,407 |  |  | 94,626 |  |
|  | 683,429 |  |  | 710,398 |  |
| Accumulated depreciation and amortization | (411,052) |  |  | (423,514) |  |
|  | $ | 272,377 |  |  | $ | 286,884 |  |

[0000936395-20-000042:notes:223]
During fiscal 2020, fiscal 2019 and fiscal 2018, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $84.9 million, $78.8 million and $75.3 million, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-20-000042:notes:224]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-20-000042:notes:225]
|  | October 31, 2020 |  | November 2, 2019 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 395,726 |  |  | $ | (335,512) |  |  | $ | 60,214 |  |  | $ | 373,526 |  |  | $ | (308,261) |  |  | $ | 65,265 |  |
| Patents and licenses | 3,565 |  |  | (2,529) |  |  | 1,036 |  |  | 3,565 |  |  | (2,244) |  |  | 1,321 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 374,659 |  |  | (339,262) |  |  | 35,397 |  |  | 374,381 |  |  | (328,186) |  |  | 46,195 |  |
| Total intangible assets | $ | 773,950 |  |  | $ | (677,303) |  |  | $ | 96,647 |  |  | $ | 751,472 |  |  | $ | (638,691) |  |  | $ | 112,781 |  |

[0000936395-20-000042:notes:226]
The aggregate amortization expense of intangible assets was $38.6 million, $35.1 million and $25.8 million for fiscal 2020, fiscal 2019 and fiscal 2018, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-20-000042:notes:227]
| Fiscal Year | Amount |  |
| 2021 | $ | 35,452 |  |  |
| 2022 | 29,232 |  |  |
| 2023 | 14,422 |  |  |
| 2024 | 11,371 |  |  |
| 2025 | 6,170 |  |  |
|  | $ | 96,647 |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-20-000042:notes:228]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of October 31, 2020 and November 2, 2019, as well as the changes to goodwill during fiscal 2020 (in thousands):

[0000936395-20-000042:notes:229]
|  | Balance at November 2, 2019 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at October 31, 2020 |
| Platform Software and Services | $ | 156,191 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services | 75,994 |  |  | 13,055 |  |  | — |  |  | — |  |  | 89,049 |  |
| Networking Platforms | 65,752 |  |  | — |  |  | — |  |  | (145) |  |  | 65,607 |  |
| Total | $ | 297,937 |  |  | $ | 13,055 |  |  | $ | — |  |  | $ | (145) |  |  | $ | 310,847 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-20-000042:notes:230]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-20-000042:notes:231]
|  | October 31, 2020 |  | November 2, 2019 |
| Maintenance spares inventory, net | $ | 62,077 |  |  | $ | 55,482 |  |
| Cost method equity investments(1) | 13,408 |  |  | 10,727 |  |
| Capitalized contract acquisition costs | 4,001 |  |  | 3,994 |  |
| Deferred debt issuance costs, net(2) | 1,596 |  |  | 1,609 |  |
| Restricted cash | 84 |  |  | 42 |  |
| Other | 21,664 |  |  | 17,132 |  |
|  | $ | 102,830 |  |  | $ | 88,986 |  |

[0000936395-20-000042:notes:232]
(1)  Ciena recorded an upward adjustment of $2.7 million to the carrying value of cost method equity investments to interest and other income (loss), net on the Consolidated Statements of Operations during the fourth quarter of fiscal 2020.

[0000936395-20-000042:notes:233]
(2) Deferred debt issuance costs relate to Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”) entered into during fiscal 2019 and its predecessor credit facility (described in Note 19 below). The amortization of deferred debt issuance costs for the ABL Credit Facility and its predecessor is included in interest expense, and was $0.4 million for fiscal 2020, and $0.3 million for fiscal 2019 and fiscal 2018.

[0000936395-20-000042:notes:234]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-20-000042:notes:235]
|  | October 31, 2020 |  | November 2, 2019 |
| Compensation, payroll related tax and benefits | $ | 135,462 |  |  | $ | 182,363 |  |
| Warranty | 49,868 |  |  | 48,498 |  |
| Vacation | 26,945 |  |  | 22,290 |  |
| Finance lease liability | 2,836 |  |  | 2,764 |  |
| Interest payable | 672 |  |  | 1,007 |  |
| Contingent consideration | — |  |  | 4,372 |  |
| Other | 118,349 |  |  | 121,446 |  |
|  | $ | 334,132 |  |  | $ | 382,740 |  |

[0000936395-20-000042:notes:236]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-20-000042:notes:237]
| Year Ended |  | Beginning Balance |  |  |  | Current Year Provisions |  |  |  | Settlements |  | Ending Balance |
| November 3, 2018 |  | $ | 42,456 |  |  |  |  | $ | 20,992 |  |  |  |  | $ | 18,708 |  |  | $ | 44,740 |  |
| November 2, 2019 |  | $ | 44,740 |  |  |  |  | $ | 23,105 |  |  |  |  | $ | 19,347 |  |  | $ | 48,498 |  |
| October 31, 2020 |  | $ | 48,498 |  |  |  |  | $ | 22,417 |  |  |  |  | $ | 21,047 |  |  | $ | 49,868 |  |

[0000936395-20-000042:notes:238]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-20-000042:notes:239]
|  | October 31, 2020 |  | November 2, 2019 |
| Finance lease liability | $ | 61,565 |  |  | $ | 65,284 |  |
| Interest rate swap liability | 28,513 |  |  | 21,093 |  |
| Income tax liability | 16,386 |  |  | 20,546 |  |
| Deferred tenant allowance | — |  |  | 6,248 |  |
| Straight-line rent | — |  |  | 5,434 |  |
| Contingent consideration | — |  |  | 3,705 |  |
| Other | 16,721 |  |  | 26,437 |  |
|  | $ | 123,185 |  |  | $ | 148,747 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-20-000042:notes:240]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-20-000042:notes:241]
During fiscal 2020 and fiscal 2019, Ciena entered into forward contracts to hedge its foreign exchange exposure from its forecasted cash flows in order to reduce the variability in its Canadian Dollar- and Indian Rupee-denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $254.9 million and $197.4 million as of October 31, 2020 and November 2, 2019, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-20-000042:notes:242]
During fiscal 2020 and fiscal 2019, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $212.0 million and $206.0 million as of October 31, 2020 and November 2, 2019. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-20-000042:notes:243]
Interest Rate Derivatives

[0000936395-20-000042:notes:244]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 18 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate of approximately $350.0 million of the principal amount of the New 2025 Term Loan at 2.957% through September 2023. The total notional amount of these interest rate swaps in effect as of October 31, 2020 was $350.0 million.

[0000936395-20-000042:notes:245]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-20-000042:notes:246]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 5 and 7 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-20-000042:notes:247]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax (in thousands):

[0000936395-20-000042:notes:248]
|  |  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  |  | Available-for-Sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 28, 2017 |  | $ | (451) |  |  | $ | (1,386) |  |  | $ | 218 |  |  | $ | (9,398) |  |  | $ | (11,017) |  |
| Other comprehensive gain (loss) before reclassifications |  | 26 |  |  | (3,242) |  |  | 6,011 |  |  | 686 |  |  | 3,481 |  |
| Amounts reclassified from AOCI |  | — |  |  | 1,568 |  |  | 188 |  |  | — |  |  | 1,756 |  |
| Balance at November 3, 2018 |  | (425) |  |  | (3,060) |  |  | 6,417 |  |  | (8,712) |  |  | (5,780) |  |
| Other comprehensive gain (loss) before reclassifications |  | 577 |  |  | 14 |  |  | (18,948) |  |  | (763) |  |  | (19,120) |  |
| Amounts reclassified from AOCI |  | — |  |  | 3,971 |  |  | (1,155) |  |  | — |  |  | 2,816 |  |
| Balance at November 2, 2019 |  | 152 |  |  | 925 |  |  | (13,686) |  |  | (9,475) |  |  | (22,084) |  |
| Other comprehensive loss before reclassifications |  | (107) |  |  | (3,891) |  |  | (12,302) |  |  | (4,174) |  |  | (20,474) |  |
| Amounts reclassified from AOCI |  | — |  |  | 2,747 |  |  | 4,453 |  |  | — |  |  | 7,200 |  |
| Balance at October 31, 2020 |  | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |

[0000936395-20-000042:notes:249]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue, research and development expense or sales and marketing expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000936395-20-000042:notes:250]
LEASES
Ciena leases over 1.3 million square feet of facilities globally related to the ongoing operations of its business segments and related functions. Ciena’s principal executive offices are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering and/or service delivery facilities located in San Jose, California; Alpharetta, Georgia; Quebec, Canada; Austin, Texas; and Pune and Bangalore, India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 12 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within six years.

[0000936395-20-000042:notes:251]
As discussed in Note 1 above, the restructuring reserve liability related to Ciena’s subleased space and vacated space for which subleases are being pursued was $11.1 million as of November 2, 2019. Upon Ciena’s adoption of ASC 842 on November 3, 2019, the existing Accrued liabilities and other short-term obligations and Other long-term obligations were reclassified as a reduction of the Operating ROU assets recorded in accordance with the updated guidance.

[0000936395-20-000042:notes:252]
Leases included in the Consolidated Balance Sheets were as follows (in thousands):

[0000936395-20-000042:notes:253]
|  | Classification |  | Balance as of October 31, 2020 |
| Operating leases: |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 57,026 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 80,450 |  |
| Finance leases: |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 70,791 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (17,837) |  |
| Buildings, net |  |  | $ | 52,954 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 64,401 |  |

[0000936395-20-000042:notes:254]
ROU assets that involve subleased or vacant space aggregate $5.0 million as of October 31, 2020. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized, either of which may be more likely as COVID-19 impacts evolve.

[0000936395-20-000042:notes:255]
The components of lease expense included in the Consolidated Statement of Operations were as follows (in thousands):

[0000936395-20-000042:notes:256]
|  |  |  | Year Ended |
|  | Classification |  | October 31, 2020 |
| Operating lease costs | Operating expense |  | $ | 17,544 |  |
| Finance lease cost: |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 4,465 |  |
| Interest on finance lease liabilities | Interest expense |  | 4,777 |  |
| Total finance lease cost |  |  | 9,242 |  |
| Non-capitalized lease cost | Operating expense |  | 2,976 |  |
| Variable lease cost(1) | Operating expense |  | 5,185 |  |
| Net lease cost(2) |  |  | $ | 34,947 |  |

[0000936395-20-000042:notes:257]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-20-000042:notes:258]
(2) Excludes other operating expense of $11.0 million for the fiscal year ended October 31, 2020 related to amortization of leasehold improvements.

[0000936395-20-000042:notes:259]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of October 31, 2020 were as follows (in thousands):

[0000936395-20-000042:notes:260]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2021 | $ | 20,989 |  |  | $ | 7,444 |  |  | $ | 28,433 |  |
| 2022 | 18,689 |  |  | 7,754 |  |  | 26,443 |  |
| 2023 | 15,415 |  |  | 7,958 |  |  | 23,373 |  |
| 2024 | 13,118 |  |  | 7,958 |  |  | 21,076 |  |
| 2025 | 8,838 |  |  | 8,118 |  |  | 16,956 |  |
| Thereafter | 9,365 |  |  | 58,101 |  |  | 67,466 |  |
| Total lease payments | 86,414 |  |  | 97,333 |  |  | 183,747 |  |
| Less: Imputed interest | (5,964) |  |  | (32,932) |  |  | (38,896) |  |
| Present value of lease liabilities | 80,450 |  |  | 64,401 |  |  | 144,851 |  |
| Less: Current portion of present value of minimum lease payments | (19,035) |  |  | (2,836) |  |  | (21,871) |  |
| Long-term portion of present value of minimum lease payments | $ | 61,415 |  |  | $ | 61,565 |  |  | $ | 122,980 |  |

[0000936395-20-000042:notes:261]
As of October 31, 2020, the weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows (in thousands):

[0000936395-20-000042:notes:262]
| Weighted-average remaining lease term in years: |  |
| Operating leases | 4.87 |
| Finance leases | 11.71 |
| Weighted-average discount rates: |  |
| Operating leases | 2.82 | % |
| Finance leases | 7.56 | % |

[0000936395-20-000042:notes:263]
As of November 2, 2019, minimum aggregate rentals under operating leases were as follows (in thousands):

[0000936395-20-000042:notes:264]
|  |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
| Operating leases(1) |  | $ | 28,776 |  |  | $ | 24,184 |  |  | $ | 16,767 |  |  | $ | 13,393 |  |  | $ | 10,632 |  |  | $ | 26,110 |  |  | $ | 119,862 |  |

[0000936395-20-000042:notes:265]
(1) The amounts for operating lease commitments above include estimated variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease.


## us-gaap:DebtDisclosureTextBlock

[0000936395-20-000042:notes:266]
SHORT-TERM AND LONG-TERM DEBT
New 2025 Term Loan

[0000936395-20-000042:notes:267]
The net carrying values of Ciena’s term loan were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-20-000042:notes:268]
|  |  | October 31, 2020 |  | November 2, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| New 2025 Term Loan |  | $ | 687,802 |  |  | $ | (1,577) |  |  | $ | (2,939) |  |  | $ | 683,286 |  |  | $ | — |  |
| Old 2025 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

[0000936395-20-000042:notes:269]
Deferred debt issuance costs deducted from the carrying amount of the term loan totaled $2.9 million at October 31, 2020 and $3.6 million at November 2, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.6 million during each of fiscal 2020 and fiscal 2019.

[0000936395-20-000042:notes:270]
As of October 31, 2020, the estimated fair value of the term loan was $686.1 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-20-000042:notes:271]
On September 28, 2018, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Increase Joinder and Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent, pursuant to which Ciena refinanced its term loan maturing on January 30,2022 (the “2022 Term Loan”) into term loan maturing on September 28, 2025 (the “Old 2025 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $699.1 million, net of original discount, from the Old 2025 Term Loan and simultaneously repaid $394.0 million of outstanding principal under the 2022 Term Loan, resulting in proceeds of $305.1 million. On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of the Old 2025 Term Loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”). The New 2025 Term Loan requires Ciena to make installment payments of $1.73 million on a quarterly basis. Based on the continuation of existing lenders, this arrangement was primarily accounted for as a modification of debt and, as such, $0.4 million of debt issuance costs associated with the New 2025 Term Loan were expensed. The aggregate balance of $3.4 million of debt issuance costs and approximately $1.9 million of original discount from the Old 2025 Term Loan are included in the carrying value of the New 2025 Term Loan.

[0000936395-20-000042:notes:272]
The Refinancing Amendment to Credit Agreement amends Ciena’s credit agreement, dated July 15, 2014, as amended (the “Credit Agreement”) and provides that the New 2025 Term Loan will, among other things:

[0000936395-20-000042:notes:273]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the New 2025 Term Loan as of January 23, 2020, with the balance payable at maturity;

[0000936395-20-000042:notes:274]
•be subject to mandatory prepayment provisions upon the occurrence of certain specified events substantially similar to the 2022 Term Loan, including certain asset sales, debt issuances and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-20-000042:notes:275]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.00%; and

[0000936395-20-000042:notes:276]
•be repayable at any time at Ciena’s election, provided that repayment of the New 2025 Term Loan with proceeds of certain indebtedness prior to July 23, 2020 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.
ABL CREDIT FACILITY
Ciena Corporation and certain of its subsidiaries are parties to the ABL Credit Facility, which provides for a total commitment of $300 million with a maturity date of October 28, 2024. The ABL Credit Facility was entered into on October 28, 2019 and replaced a predecessor senior secured asset-based revolving credit facility. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-20-000042:notes:277]
As of October 31, 2020, letters of credit totaling $83.0 million were outstanding under the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2020.


## us-gaap:EarningsPerShareTextBlock

[0000936395-20-000042:notes:278]
EARNINGS (LOSS) PER SHARE CALCULATION
The following tables (in thousands except per share amounts) reconcile Basic EPS and Diluted EPS. Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-20-000042:notes:279]
Numerator

[0000936395-20-000042:notes:280]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Net income (loss) | $ | 361,291 |  |  | $ | 253,434 |  |  | $ | (344,690) |  |
| Less: Loss on fair value of debt conversion liability | — |  |  | — |  |  | (12,894) |  |
| Net income (loss) used to calculate Diluted EPS | $ | 361,291 |  |  | $ | 253,434 |  |  | $ | (357,584) |  |

[0000936395-20-000042:notes:281]
Denominator

[0000936395-20-000042:notes:282]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Basic weighted average shares outstanding | 154,287 |  |  | 155,720 |  |  | 143,738 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | 1,668 |  |  | 1,892 |  |  | — |  |
| Diluted weighted average shares outstanding | 155,955 |  |  | 157,612 |  |  | 143,738 |  |

[0000936395-20-000042:notes:283]
EPS

[0000936395-20-000042:notes:284]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Basic EPS | $ | 2.34 |  |  | $ | 1.63 |  |  | $ | (2.40) |  |
| Diluted EPS | $ | 2.32 |  |  | $ | 1.61 |  |  | $ | (2.49) |  |

[0000936395-20-000042:notes:285]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-20-000042:notes:286]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Shares underlying stock options and restricted stock units | 263 |  |  | 234 |  |  | 2,235 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) | — |  |  | — |  |  | 1,780 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original Notes) | — |  |  | — |  |  | 2,883 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | — |  |  | 9,123 |  |
| Total shares excluded due to anti-dilutive effect | 263 |  |  | 234 |  |  | 16,021 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-20-000042:notes:287]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program

[0000936395-20-000042:notes:288]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. The program may be modified, suspended, or discontinued at any time. Due to the continued uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, Ciena considered it prudent to temporarily suspend purchases of its common stock under its stock repurchase program effective as of March 17, 2020. The reinstatement of the program and the amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions.

[0000936395-20-000042:notes:289]
The following table summarizes activity of the stock repurchase program, reported based on trade date:

[0000936395-20-000042:notes:290]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at November 3, 2018 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 3,838,466 |  |  | $ | 39.10 |  |  | 150,076 |  |
| Cumulative balance at November 2, 2019 | 3,838,466 |  |  | $ | 39.10 |  |  | $ | 150,076 |  |
| Repurchase of common stock under the stock repurchase program | 1,872,446 |  |  | $ | 39.81 |  |  | 74,535 |  |
| Cumulative balance at October 31, 2020 | 5,710,912 |  |  | $ | 39.33 |  |  | $ | 224,611 |  |

[0000936395-20-000042:notes:291]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-20-000042:notes:292]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-20-000042:notes:293]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The purchase price of $32.5 million for the shares of Ciena’s stock repurchased is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-20-000042:notes:294]
INCOME TAXESFor the periods indicated, the provision for income taxes consists of the following (in thousands):

[0000936395-20-000042:notes:295]
|  | Year Ended |  |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |  |
| Provision for income taxes: |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |
| Federal | $ | 4,363 |  |  | $ | 13,143 |  |  | $ | 8,327 |  |  |
| State | 13,328 |  |  | 16,945 |  |  | 8,219 |  |  |
| Foreign | 12,640 |  |  | 9,816 |  |  | 13,294 |  |  |
| Total current | 30,331 |  |  | 39,904 |  |  | 29,840 |  |  |
| Deferred: |  |  |  |  |  |  |
| Federal | 60,679 |  |  | 31,872 |  |  | 475,951 |  | (1) |
| State | 4,607 |  |  | (9,159) |  |  | (8,202) |  |  |
| Foreign | (947) |  |  | (2,861) |  |  | (4,118) |  |  |
| Total deferred | 64,339 |  |  | 19,852 |  |  | 463,631 |  |  |
| Provision for income taxes | $ | 94,670 |  |  | $ | 59,756 |  |  | $ | 493,471 |  |  |

[0000936395-20-000042:notes:296]
(1) The income tax expense for 2018 includes the impact of the remeasurement of the net deferred tax assets and the federal transition tax. See further discussion below.

[0000936395-20-000042:notes:297]
For the periods indicated, income before provision for income taxes consists of the following (in thousands):

[0000936395-20-000042:notes:298]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| United States | $ | 387,697 |  |  | $ | 256,461 |  |  | $ | 106,972 |  |
| Foreign | 68,264 |  |  | 56,729 |  |  | 41,809 |  |
| Total | $ | 455,961 |  |  | $ | 313,190 |  |  | $ | 148,781 |  |

[0000936395-20-000042:notes:299]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-20-000042:notes:300]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2020 and fiscal 2019, and 23.4% for fiscal 2018 (see note below) as follows:

[0000936395-20-000042:notes:301]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Provision at statutory rate | 21.00 | % |  | 21.00 | % |  | 23.41 | % |
| Deferred tax assets remeasurement | — | % |  | — | % |  | 294.56 | % |
| Base Erosion and Anti-Abuse Tax | (1.02) | % |  | 3.60 | % |  | — | % |
| State taxes | 2.21 | % |  | 2.18 | % |  | (0.16) | % |
| Foreign taxes | 0.51 | % |  | (0.37) | % |  | 1.22 | % |
| Research and development credit | (7.74) | % |  | (7.53) | % |  | (8.80) | % |
| Non-deductible compensation | 1.79 | % |  | 1.01 | % |  | 3.39 | % |
| Fair value of debt conversion liability | — | % |  | — | % |  | 1.90 | % |
| Transition tax | 0.02 | % |  | 0.29 | % |  | 23.23 | % |
| Valuation allowance | 3.58 | % |  | (2.13) | % |  | (11.95) | % |
| Other | 0.41 | % |  | 1.03 | % |  | 4.88 | % |
| Effective income tax rate | 20.76 | % |  | 19.08 | % |  | 331.68 | % |

[0000936395-20-000042:notes:302]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revised the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.

[0000936395-20-000042:notes:303]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena computed its income tax expense for the November 3, 2018 fiscal year using a blended federal tax rate of 23.41%. Ciena remeasured its DTA using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-20-000042:notes:304]
Our future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and utilizability of tax attributes, changes in tax laws and business reorganizations. Ciena continues to monitor these items and will adopt strategies to address their impact as appropriate.

[0000936395-20-000042:notes:305]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above amounts to the extent they are provisional due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. The enactment of the Tax Act resulted in Ciena recording a provisional tax expense of $472.8 million in fiscal 2018. In the first quarter of fiscal 2019, the measurement period under the Tax Act concluded, which resulted in immaterial adjustments to Ciena’s provisional estimates.

[0000936395-20-000042:notes:306]
Ciena is also required to make accounting policy elections as a result of the Tax Act. These include whether a valuation allowance is recorded for the estimated effect of the application of GILTI and BEAT or if these will be treated as period costs when incurred. Ciena had made the incremental cash tax cost policy election with respect to analyzing the impact of GILTI on the assessment of the realizability of net operating losses. The realizability of U.S. tax carryforwards is not impacted by the BEAT, and the BEAT is a period cost when incurred. Ciena is also required to elect to either treat taxes due on future GILTI inclusions in U.S. taxable income as a current period expense when incurred or reflect such portion of the future GILTI inclusions in U.S. taxable income that relate to existing basis differences in Ciena’s current measurement of deferred taxes. Ciena’s accounting policy election is to treat the taxes due on future U.S. inclusions in taxable income under GILTI as a period cost when incurred.

[0000936395-20-000042:notes:307]
The significant components of DTA are as follows (in thousands):

[0000936395-20-000042:notes:308]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 73,825 |  |  | $ | 54,183 |  |
| Depreciation and amortization | 504,233 |  |  | 455,007 |  |
| NOL and credit carry forward | 188,157 |  |  | 302,325 |  |
| Other | 33,017 |  |  | 39,405 |  |
| Gross deferred tax assets | 799,232 |  |  | 850,920 |  |
| Valuation allowance | (151,427) |  |  | (135,978) |  |
| Deferred tax asset, net of valuation allowance | $ | 647,805 |  |  | $ | 714,942 |  |

[0000936395-20-000042:notes:309]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-20-000042:notes:310]
|  | Amount |
| Unrecognized tax benefits at October 28, 2017 | $ | 141,582 |  |
| Decrease related to positions taken in prior period | (46,400) |  |
| Increase related to positions taken in current period | 2,482 |  |
| Reductions related to expiration of statute of limitations | (1,301) |  |
| Unrecognized tax benefits at November 3, 2018 | 96,363 |  |
| Increase related to positions taken in prior period | 1,959 |  |
| Reductions related to settlements with taxing authorities | (1,224) |  |
| Reductions related to expiration of statute of limitations | (2,494) |  |
| Unrecognized tax benefits at November 2, 2019 | 94,604 |  |
| Increase related to positions taken in prior period | 653 |  |
| Increase related to positions taken in current period | 1,151 |  |
| Reductions related to expiration of statute of limitations | (660) |  |
| Unrecognized tax benefits at October 31, 2020 | $ | 95,748 |  |

[0000936395-20-000042:notes:311]
As of October 31, 2020 and November 2, 2019, Ciena had accrued $3.9 million and $3.0 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $0.9 million and $1.1 million were recorded as an expense to the provision for income taxes during fiscal 2020 and fiscal 2018, respectively. During fiscal 2019, Ciena recorded a provision for interest and penalties in its provision for income taxes of $1.0 million. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-20-000042:notes:312]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2020, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized is an estimated $375.0 million. If these earnings were distributed to the U.S., Ciena would be subject to additional foreign withholding taxes of approximately $25.0 million. Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-20-000042:notes:313]
As of October 31, 2020, Ciena continues to maintain a valuation allowance against net deferred tax assets of $151.4 million primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.

[0000936395-20-000042:notes:314]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-20-000042:notes:315]
| Year Ended |  | Beginning Balance |  | Additions |  | Deductions |  | Ending Balance |
| November 3, 2018 |  | $ | 185,898 |  |  | $ | 23,720 |  |  | $ | 66,968 |  |  | $ | 142,650 |  |
| November 2, 2019 |  | $ | 142,650 |  |  | $ | 27,459 |  |  | $ | 34,131 |  |  | $ | 135,978 |  |
| October 31, 2020 |  | $ | 135,978 |  |  | $ | 25,749 |  |  | $ | 10,300 |  |  | $ | 151,427 |  |

[0000936395-20-000042:notes:316]
As of October 31, 2020, Ciena had a $38.2 million income tax credit carry forward which begins to expire in fiscal 2025. Ciena’s ability to use credit carry forwards is subject to limitations pursuant to the ownership change rules of  Internal Revenue Code Section 382.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-20-000042:notes:317]
SHARE-BASED COMPENSATION EXPENSECiena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under its Amended and Restated 2003 Employee Stock Purchase Plan (the “ESPP”). Each of the 2017 Plan and the ESPP are described below.
2017 Plan

[0000936395-20-000042:notes:318]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-20-000042:notes:319]
At Ciena’s 2020 Annual Meeting of Stockholders on April 2, 2020, Ciena’s stockholders approved an amendment to the 2017 Plan to increase the number of shares available for issuance thereunder by 12.2 million shares, which became effective as of such date. The 2017 Plan authorizes and reserves 21.1 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 31, 2020, the total number of shares authorized for issuance under the 2017 Plan was 21.1 million and approximately 14.7 million shares remained available for issuance thereunder.

[0000936395-20-000042:notes:320]
Stock Options

[0000936395-20-000042:notes:321]
There were no stock options granted by Ciena during fiscal 2020, fiscal 2019 or fiscal 2018. Outstanding stock option awards granted to employees in prior periods are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-20-000042:notes:322]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of November 2, 2019 | 220 |  |  | $ | 35.54 |  |
| Granted | — |  |  | — |  |
| Exercised | (105) |  |  | $ | 40.27 |  |
| Canceled | (8) |  |  | $ | 28.22 |  |
| Balance as of October 31, 2020 | 107 |  |  | $ | 31.41 |  |

[0000936395-20-000042:notes:323]
The total intrinsic value of options exercised during fiscal 2020, fiscal 2019 and fiscal 2018 was $1.3 million, $0.8 million and $2.2 million, respectively.

[0000936395-20-000042:notes:324]
The following table summarizes information with respect to stock options outstanding at October 31, 2020, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2020 (shares and intrinsic value in thousands):

[0000936395-20-000042:notes:325]
|  |  |  |  |  |  | Options Outstanding and Vested at |  |  |
|  |  |  |  |  |  | October 31, 2020 |  |  |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  |  |  |  |  |  |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  |  |  |  |  |  |  |  |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  |  |  |  |  |  |  |  |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  |  |  |  |  |  |  |  |
| $ | 11.34 |  |  | — |  |  | $ | 15.00 |  |  | 37 |  |  | 2.33 |  | $ | 13.60 |  |  | $ | 943 |  |  |  |  |  |  |  |  |  |
| $ | 17.50 |  |  | — |  |  | $ | 18.22 |  |  | 9 |  |  | 1.97 |  | $ | 18.16 |  |  | 203 |  |  |  |  |  |  |  |  |  |
| $ | 32.06 |  |  | — |  |  | $ | 37.10 |  |  | 19 |  |  | 2.26 |  | $ | 35.89 |  |  | 67 |  |  |  |  |  |  |  |  |  |
| $ | 41.52 |  |  | — |  |  | $ | 55.63 |  |  | 42 |  |  | 2.63 |  | $ | 47.87 |  |  | — |  |  |  |  |  |  |  |  |  |
| $ | 11.34 |  |  | — |  |  | $ | 55.63 |  |  | 107 |  |  | 2.41 |  | $ | 31.41 |  |  | $ | 1,213 |  |  |  |  |  |  |  |  |  |

[0000936395-20-000042:notes:326]
Assumptions for Option-Based Awards

[0000936395-20-000042:notes:327]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2020, fiscal 2019, or fiscal 2018.

[0000936395-20-000042:notes:328]
Restricted Stock Units

[0000936395-20-000042:notes:329]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total shareholder return as compared to an index of peer companies, in whole or in part.

[0000936395-20-000042:notes:330]
Assumptions for Restricted Stock Unit Awards

[0000936395-20-000042:notes:331]
Ciena recognizes the estimated fair value of performance-based awards as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-20-000042:notes:332]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total shareholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date.

[0000936395-20-000042:notes:333]
Ciena recognizes the estimated fair value of performance based awards subject to total shareholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model. Assumptions for awards granted during fiscal 2020, fiscal 2019 and fiscal 2018 included the following:

[0000936395-20-000042:notes:334]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 31.77% |  | 34.10% |  | 34.93% |
| Historical volatility of Ciena common stock | 36.29% |  | 36.80% |  | 38.24% |
| Historical volatility of S&P Networking Index | 18.40% |  | 17.39% |  | 17.14% |
| Correlation coefficient | 0.5891 |  | 0.6251 |  | 0.6597 |
| Expected life in years | 2.87 |  | 2.87 |  | 2.89 |
| Risk-free interest rate | 1.65% |  | 2.62% |  | 1.94% |
| Expected dividend yield | 0.0% |  | 0.0% |  | 0.0% |

[0000936395-20-000042:notes:335]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-20-000042:notes:336]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of November 2, 2019 | 4,010 |  |  | $ | 27.94 |  |  | $ | 146,091 |  |
| Granted | 2,195 |  |  |  |  |  |
| Vested | (1,945) |  |  |  |  |  |
| Canceled or forfeited | (211) |  |  |  |  |  |
| Balance as of October 31, 2020 | 4,049 |  |  | $ | 35.08 |  |  | $ | 159,498 |  |

[0000936395-20-000042:notes:337]
As of October 31, 2020 and November 2, 2019, 0.4 million and 0.3 million of the total restricted stock units outstanding are performance based awards subject to total shareholder return, respectively. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2020, fiscal 2019 and fiscal 2018 was $83.5 million, $79.2 million and $54.3 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2020, fiscal 2019 and fiscal 2018 was $41.61, $34.53 and $22.46, respectively.

[0000936395-20-000042:notes:338]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-20-000042:notes:339]
Share-based expense for performance-based restricted stock unit awards is recognized ratably over the performance period based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-20-000042:notes:340]
Share-based compensation expense is recognized only for those awards that are ultimately expected to vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0000936395-20-000042:notes:341]
Amended and Restated ESPP

[0000936395-20-000042:notes:342]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP’s “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-20-000042:notes:343]
During fiscal 2020, fiscal 2019 and fiscal 2018, Ciena issued 0.7 million, 1.0 million and 1.1 million shares under the ESPP, respectively. At October 31, 2020, 4.3 million shares remained available for issuance under the ESPP.

[0000936395-20-000042:notes:344]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-20-000042:notes:345]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Product cost of goods sold | $ | 3,182 |  |  | $ | 2,868 |  |  | $ | 2,984 |  |
| Service cost of goods sold | 3,853 |  |  | 3,175 |  |  | 2,616 |  |
| Share-based compensation expense included in cost of goods sold | 7,035 |  |  | 6,043 |  |  | 5,600 |  |
| Research and development | 16,987 |  |  | 14,321 |  |  | 13,518 |  |
| Sales and marketing | 20,194 |  |  | 16,474 |  |  | 14,246 |  |
| General and administrative | 23,424 |  |  | 22,841 |  |  | 19,709 |  |
| Share-based compensation expense included in operating expense | 60,605 |  |  | 53,636 |  |  | 47,473 |  |
| Share-based compensation expense capitalized in inventory, net | 118 |  |  | 57 |  |  | (101) |  |
| Total share-based compensation | $ | 67,758 |  |  | $ | 59,736 |  |  | $ | 52,972 |  |

[0000936395-20-000042:notes:346]
As of October 31, 2020, total unrecognized share-based compensation expense was $111.9 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.47 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-20-000042:notes:347]
SEGMENT AND ENTITY WIDE DISCLOSURES
Segment Reporting

[0000936395-20-000042:notes:348]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. During fiscal 2019, Ciena separated its

[0000936395-20-000042:notes:349]
previous Software and Software-Related Services into two stand-alone operating segments. Because Ciena previously disclosed its Platform Software and Services and Blue Planet Automation Software and Services as distinct product lines in its presentation of segment revenue for Software and Software-Related Services, there is no significant change to Ciena’s presentation of segment revenues as a result of this separation. Comparative periods have been retrospectively adjusted to disclose segment profit for Platform Software and Services and Blue Planet Automation Software and Services. See Note 2 above.

[0000936395-20-000042:notes:350]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, Operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2020, equipment, building, furniture and fixtures, net, totaled $272.4 million, and Operating ROU assets totaled $57.0 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of October 31, 2020, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-20-000042:notes:351]
|  | October 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 10,977 |  |  | $ | — |  |  | $ | 85,670 |  |  | $ | — |  |  | $ | 96,647 |  |
| Goodwill | $ | 65,607 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 310,847 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 62,077 |  |  | $ | 62,077 |  |

[0000936395-20-000042:notes:352]
Segment Revenue

[0000936395-20-000042:notes:353]
The table below sets forth Ciena’s segment revenue for the respective periods (in thousands):

[0000936395-20-000042:notes:354]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Revenue: |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |
| Converged Packet Optical | $ | 2,547,647 |  |  | $ | 2,562,841 |  |  | $ | 2,194,519 |  |
| Packet Networking | 267,416 |  |  | 348,477 |  |  | 283,499 |  |
| Total Networking Platforms | 2,815,063 |  |  | 2,911,318 |  |  | 2,478,018 |  |
| Platform Software and Services | 197,809 |  |  | 155,376 |  |  | 173,949 |  |
| Blue Planet Automation Software and Services | 62,632 |  |  | 54,555 |  |  | 26,764 |  |
| Global Services |  |  |  |  |  |
| Maintenance Support and Training | 269,354 |  |  | 261,337 |  |  | 245,161 |  |
| Installation and Deployment | 152,003 |  |  | 148,233 |  |  | 128,829 |  |
| Consulting and Network Design | 35,296 |  |  | 41,312 |  |  | 41,565 |  |
| Total Global Services | 456,653 |  |  | 450,882 |  |  | 415,555 |  |
| Consolidated revenue | $ | 3,532,157 |  |  | $ | 3,572,131 |  |  | $ | 3,094,286 |  |

[0000936395-20-000042:notes:355]
Segment Profit (Loss)

[0000936395-20-000042:notes:356]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs, acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision for income taxes.

[0000936395-20-000042:notes:357]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income (loss) for the respective periods indicated (in thousands):

[0000936395-20-000042:notes:358]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 827,105 |  |  | $ | 759,244 |  |  | $ | 581,113 |  |
| Platform Software and Services | 105,609 |  |  | 64,210 |  |  | 78,048 |  |
| Blue Planet Automation Software and Services | (12,446) |  |  | (17,769) |  |  | (8,240) |  |
| Global Services | 202,735 |  |  | 188,242 |  |  | 172,205 |  |
| Total segment profit | 1,123,003 |  |  | 993,927 |  |  | 823,126 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 416,425 |  |  | 423,046 |  |  | 394,060 |  |
| General and administrative | 169,548 |  |  | 174,399 |  |  | 160,133 |  |
| Amortization of intangible assets | 23,383 |  |  | 21,808 |  |  | 15,737 |  |
| Acquisition and integration costs | 4,031 |  |  | 3,370 |  |  | 5,111 |  |
| Significant asset impairments and restructuring costs | 22,652 |  |  | 24,538 |  |  | 18,139 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income (loss), net | 964 |  |  | 3,876 |  |  | (12,029) |  |
| Interest expense | (31,321) |  |  | (37,452) |  |  | (55,249) |  |
| Loss on extinguishment and modification of debt | (646) |  |  | — |  |  | (13,887) |  |
| Less: Provision for income taxes | 94,670 |  |  | 59,756 |  |  | 493,471 |  |
| Consolidated net income (loss) | $ | 361,291 |  |  | $ | 253,434 |  |  | $ | (344,690) |  |

[0000936395-20-000042:notes:359]
Entity Wide Reporting

[0000936395-20-000042:notes:360]
Ciena’s operating segments each engage in business across three geographic regions: Americas; EMEA; and APAC. Americas include activities in North America and South America (previously, CALA). The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-20-000042:notes:361]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| Americas | $ | 2,469,278 |  |  | $ | 2,503,913 |  |  | $ | 2,026,627 |  |
| EMEA | 591,468 |  |  | 566,718 |  |  | 464,876 |  |
| APAC | 471,411 |  |  | 501,500 |  |  | 602,783 |  |
| Total | $ | 3,532,157 |  |  | $ | 3,572,131 |  |  | $ | 3,094,286 |  |

[0000936395-20-000042:notes:362]
North America includes $2.25 billion, $2.25 billion and $1.77 billion of United States revenue for fiscal years ended October 31, 2020, November 2, 2019 and November 3, 2018, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-20-000042:notes:363]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and Operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and Operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and Operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and Operating ROU assets was as follows (in thousands):

[0000936395-20-000042:notes:364]
|  | October 31, 2020 |  | November 2, 2019 |  |  |
| Canada | $ | 214,188 |  |  | $ | 211,901 |  |  |  |
| United States | 65,321 |  |  | 58,119 |  |  |  |
| Other International | 49,894 |  |  | 16,864 |  |  |  |
| Total | $ | 329,403 |  |  | $ | 286,884 |  |  |  |

[0000936395-20-000042:notes:365]
While Ciena has benefited from the diversification of its business and customer base, its ten largest customers contributed 54.5% of fiscal 2020 revenue, 59.3% of fiscal 2019 revenue and 56.5% of fiscal 2018 revenue.

[0000936395-20-000042:notes:366]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-20-000042:notes:367]
|  | October 31, 2020 |  | November 2, 2019 |  | November 3, 2018 |
| AT&T | $ | 373,163 |  |  | $ | 388,704 |  |  | $ | 374,576 |  |
| Verizon | n/a |  | 459,787 |  |  | 318,013 |  |
| Web-scale provider | n/a |  | 370,577 |  |  | n/a |
| Total | $ | 373,163 |  |  | $ | 1,219,068 |  |  | $ | 692,589 |  |

[0000936395-20-000042:notes:368]
________________________________

[0000936395-20-000042:notes:369]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-20-000042:notes:370]
The Web-scale provider noted above contributed greater than 10% of total revenue for the first time in fiscal 2019 and purchased products from each of Ciena’s operating segments excluding Blue Planet Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-20-000042:notes:371]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and Operating ROU assets was as follows (in thousands):


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-20-000042:notes:372]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$27,830 (approximately $20,895) for 2020). This plan includes a required employer contribution of 1% for all participants and an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. During fiscal 2020, 2019 and 2018, Ciena made matching contributions of approximately CAD$7.0 million (approximately $5.3 million), CAD$5.2 million (approximately $3.9 million) and CAD$5.1 million (approximately $3.8 million), respectively.

[0000936395-20-000042:notes:373]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of base pay through pre-tax or Roth contributions, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 8% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2020, 2019 and 2018, Ciena made matching contributions of approximately $7.5 million, $5.9 million and $5.8 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-20-000042:notes:374]
COMMITMENTS AND CONTINGENCIES
Government Grant

[0000936395-20-000042:notes:375]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.2 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of October 31, 2020, Ciena has recorded CAD$40.6 million (approximately $30.5 million) in cumulative benefits as a reduction in research and development expense of which CAD$11.7 million (approximately $8.7 million) was recorded in fiscal 2020. As of October 31, 2020, amounts receivable from this grant were CAD$5.1 million (approximately $3.9 million).

[0000936395-20-000042:notes:376]
Tax Contingencies

[0000936395-20-000042:notes:377]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-20-000042:notes:378]
Litigation

[0000936395-20-000042:notes:379]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-20-000042:notes:380]
SUBSEQUENT EVENTSShare Repurchase ProgramOn December 10, 2020, Ciena announced that it will resume purchases under its stock repurchase program beginning in the first quarter of fiscal 2021. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.
