# CIEN 8-K — 0000936395-20-000038 filed 2020-12-10

## item codes, every 8-K on or before 2020-12-18

- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2020-12-18

- none on or before 2020-12-18

## item 2.02 — earnings release, exhibit 99.1

[0000936395-20-000038:8k_2_02:1]
EX-99.1
2
ex991-2020q4pressrelea.htm
EX-99.1

[0000936395-20-000038:8k_2_02:2]
Document

[0000936395-20-000038:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-20-000038:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2020 and Year-End Financial Results

[0000936395-20-000038:8k_2_02:5]
HANOVER, Md. - December 10, 2020 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2020.

[0000936395-20-000038:8k_2_02:6]
•Q4 Revenue: $828.5 million

[0000936395-20-000038:8k_2_02:7]
•Q4 Net Income per Share: $0.42 GAAP; $0.60 adjusted (non-GAAP), increasing 3.4% year over year

[0000936395-20-000038:8k_2_02:8]
•Share Repurchases: Reinstituting share repurchase program with the intent to resume purchases in the first quarter of 2021

[0000936395-20-000038:8k_2_02:9]
"Our fiscal fourth quarter and full-year 2020 performance reported today demonstrates that we have the innovation, diversification and global scale to perform well in a challenging environment," said Gary Smith, President and CEO, Ciena. "While we expect current market conditions to persist in the near-term, we are confident in strong secular demand dynamics and our ability to continue to outperform the market."

[0000936395-20-000038:8k_2_02:10]
For the fiscal fourth quarter 2020, Ciena reported revenue of $828.5 million as compared to $968.0 million for the fiscal fourth quarter 2019. For fiscal year 2020, Ciena reported revenue of $3.53 billion, as compared to $3.57 billion for fiscal year 2019.

[0000936395-20-000038:8k_2_02:11]
Ciena's GAAP net income for the fiscal fourth quarter 2020 was $65.0 million or $0.42 per diluted common share, which compares to a GAAP net income of $80.3 million, or $0.51 per diluted common share, for the fiscal fourth quarter 2019. For fiscal year 2020, Ciena's GAAP net income was $361.3 million, or $2.32 per diluted common share, as compared to a GAAP net income of $253.4 million, or $1.61 per diluted common share for fiscal year 2019.

[0000936395-20-000038:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2020 was $94.5 million, or $0.60 per diluted common share, which compares to an adjusted (non-GAAP) net income of $90.4 million, or $0.58 per diluted common share, for the fiscal fourth quarter 2019. For fiscal year 2020, Ciena's adjusted (non-GAAP) net income was $460.1 million, or $2.95 per diluted common share, as compared to an adjusted (non-GAAP) net income of $331.8 million, or $2.11 per diluted common share for fiscal year 2019.

[0000936395-20-000038:8k_2_02:13]
Performance Summary for the Fiscal Fourth Quarter and the Year Ended October 31, 2020

[0000936395-20-000038:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-20-000038:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period Change |  | Year Ended |  | Period Change |
|  |  | October 31, |  | November 2, |  |  |  | October 31, |  | November 2, |  |  |
|  |  | 2020 |  | 2019 |  | Y-T-Y* |  | 2020 |  | 2019 |  | Y-T-Y* |
| Revenue |  | $ | 828.5 |  |  | $ | 968.0 |  |  | (14.4) | % |  | $ | 3,532.2 |  |  | $ | 3,572.1 |  |  | (1.1) | % |
| Gross margin |  | 48.8 | % |  | 43.4 | % |  | 5.4 | % |  | 46.8 | % |  | 43.2 | % |  | 3.6 | % |
| Operating expense |  | $ | 310.9 |  |  | $ | 326.5 |  |  | (4.8) | % |  | $ | 1,165.9 |  |  | $ | 1,195.3 |  |  | (2.5) | % |
| Operating margin |  | 11.3 | % |  | 9.6 | % |  | 1.7 | % |  | 13.8 | % |  | 9.7 | % |  | 4.1 | % |

[0000936395-20-000038:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period Change |  | Year Ended |  | Period Change |
|  |  | October 31, |  | November 2, |  |  |  | October 31, |  | November 2, |  |  |
|  |  | 2020 |  | 2019 |  | Y-T-Y* |  | 2020 |  | 2019 |  | Y-T-Y* |
| Revenue |  | $ | 828.5 |  |  | $ | 968.0 |  |  | (14.4) | % |  | $ | 3,532.2 |  |  | $ | 3,572.1 |  |  | (1.1) | % |
| Adj. gross margin |  | 49.5 | % |  | 43.8 | % |  | 5.7 | % |  | 47.4 | % |  | 43.7 | % |  | 3.7 | % |
| Adj. operating expense |  | $ | 278.9 |  |  | $ | 295.3 |  |  | (5.6) | % |  | $ | 1,055.3 |  |  | $ | 1,091.8 |  |  | (3.3) | % |
| Adj. operating margin |  | 15.8 | % |  | 13.3 | % |  | 2.5 | % |  | 17.6 | % |  | 13.1 | % |  | 4.5 | % |
| Adj. EBITDA |  | $ | 154.5 |  |  | $ | 151.6 |  |  | 1.9 | % |  | $ | 713.9 |  |  | $ | 557.3 |  |  | 28.1 | % |

[0000936395-20-000038:8k_2_02:17]
* Denotes % change, or in the case of margin, absolute change

[0000936395-20-000038:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 579.3 |  |  | 69.9 |  |  | $ | 665.8 |  |  | 68.8 |  |
| Packet Networking |  | 56.0 |  |  | 6.8 |  |  | 131.9 |  |  | 13.6 |  |
| Total Networking Platforms |  | 635.3 |  |  | 76.7 |  |  | 797.7 |  |  | 82.4 |  |
| Platform Software and Services |  | 54.5 |  |  | 6.6 |  |  | 41.2 |  |  | 4.3 |  |
| Blue Planet Automation Software and Services |  | 20.9 |  |  | 2.5 |  |  | 16.6 |  |  | 1.7 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 67.0 |  |  | 8.1 |  |  | 65.3 |  |  | 6.7 |  |
| Installation and Deployment |  | 43.0 |  |  | 5.2 |  |  | 36.5 |  |  | 3.8 |  |
| Consulting and Network Design |  | 7.8 |  |  | 0.9 |  |  | 10.7 |  |  | 1.1 |  |
| Total Global Services |  | 117.8 |  |  | 14.2 |  |  | 112.5 |  |  | 11.6 |  |
| Total |  | $ | 828.5 |  |  | 100.0 |  |  | $ | 968.0 |  |  | 100.0 |  |

[0000936395-20-000038:8k_2_02:19]
2

[0000936395-20-000038:8k_2_02:20]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 2,547.6 |  |  | 72.1 |  |  | $ | 2,562.8 |  |  | 71.8 |  |
| Packet Networking |  | 267.5 |  |  | 7.6 |  |  | 348.5 |  |  | 9.8 |  |
| Total Networking Platforms |  | 2,815.1 |  |  | 79.7 |  |  | 2,911.3 |  |  | 81.6 |  |
| Platform Software and Services |  | 197.8 |  |  | 5.6 |  |  | 155.3 |  |  | 4.3 |  |
| Blue Planet Automation Software and Services |  | 62.6 |  |  | 1.8 |  |  | 54.6 |  |  | 1.5 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 269.4 |  |  | 7.6 |  |  | 261.3 |  |  | 7.3 |  |
| Installation and Deployment |  | 152.0 |  |  | 4.3 |  |  | 148.2 |  |  | 4.1 |  |
| Consulting and Network Design |  | 35.3 |  |  | 1.0 |  |  | 41.4 |  |  | 1.2 |  |
| Total Global Services |  | 456.7 |  |  | 12.9 |  |  | 450.9 |  |  | 12.6 |  |
| Total |  | $ | 3,532.2 |  |  | 100.0 |  |  | $ | 3,572.1 |  |  | 100.0 |  |

[0000936395-20-000038:8k_2_02:21]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended October 31, 2020

[0000936395-20-000038:8k_2_02:22]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 531.6 |  |  | 64.2 |  |  | $ | 715.7 |  |  | 73.9 |  |
| Europe, Middle East and Africa |  | 157.6 |  |  | 19.0 |  |  | 153.0 |  |  | 15.8 |  |
| Asia Pacific |  | 139.3 |  |  | 16.8 |  |  | 99.3 |  |  | 10.3 |  |
| Total |  | $ | 828.5 |  |  | 100.0 |  |  | $ | 968.0 |  |  | 100.0 |  |

[0000936395-20-000038:8k_2_02:23]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 2,469.3 |  |  | 69.9 |  |  | $ | 2,503.9 |  |  | 70.1 |  |
| Europe, Middle East and Africa |  | 591.5 |  |  | 16.8 |  |  | 566.7 |  |  | 15.9 |  |
| Asia Pacific |  | 471.4 |  |  | 13.3 |  |  | 501.5 |  |  | 14.0 |  |
| Total |  | $ | 3,532.2 |  |  | 100.0 |  |  | $ | 3,572.1 |  |  | 100.0 |  |

[0000936395-20-000038:8k_2_02:24]
**  Denotes %  of total revenue

[0000936395-20-000038:8k_2_02:25]
•No customer represented more than 10% of revenue for the fiscal quarter

[0000936395-20-000038:8k_2_02:26]
•One 10%-plus customer represented a total of 10.6% of revenue for the fiscal year

[0000936395-20-000038:8k_2_02:27]
•Cash and investments totaled $1.3 billion

[0000936395-20-000038:8k_2_02:28]
•Cash flow from operations totaled $187.3 million and $493.7 million for the fiscal quarter and year, respectively

[0000936395-20-000038:8k_2_02:29]
•Average days' sales outstanding (DSOs) were 88 and 82 for the fiscal quarter and year, respectively

[0000936395-20-000038:8k_2_02:30]
•Accounts receivable, net balance was $719.4 million

[0000936395-20-000038:8k_2_02:31]
•Unbilled contract asset balance was $85.8 million

[0000936395-20-000038:8k_2_02:32]
•Inventories totaled $344.4 million, including:

[0000936395-20-000038:8k_2_02:33]
◦Raw materials: $119.5 million

[0000936395-20-000038:8k_2_02:34]
◦Work in process: $13.7 million

[0000936395-20-000038:8k_2_02:35]
◦Finished goods: $210.1 million

[0000936395-20-000038:8k_2_02:36]
◦Deferred cost of sales: $40.7 million

[0000936395-20-000038:8k_2_02:37]
◦Reserve for excess and obsolescence: $(39.6) million

[0000936395-20-000038:8k_2_02:38]
•Product inventory turns were 4.0 and 4.6 for the fiscal quarter and year, respectively

[0000936395-20-000038:8k_2_02:39]
•Headcount totaled 7,032

[0000936395-20-000038:8k_2_02:40]
Share Repurchase Program

[0000936395-20-000038:8k_2_02:41]
After temporarily suspending repurchases of our common stock during fiscal 2020, we will be reinstituting this program in the first quarter of 2021 and are currently targeting repurchases in the range of $150 million during fiscal 2021. Ciena may purchase shares at management's discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time. During fiscal year 2020, Ciena repurchased approximately 1.9 million shares of its common stock at an average price of $39.81 per share for an aggregate purchase price of $74.5 million.

[0000936395-20-000038:8k_2_02:42]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2020 Results

[0000936395-20-000038:8k_2_02:43]
Today, Thursday, December 10, 2020, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter and fiscal 2020 results.

[0000936395-20-000038:8k_2_02:44]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-20-000038:8k_2_02:45]
Notes to Investors

[0000936395-20-000038:8k_2_02:46]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our fiscal fourth quarter and full-year 2020 performance reported today demonstrates that we have the innovation, diversification and global scale to perform

[0000936395-20-000038:8k_2_02:47]
well in a challenging environment." "While we expect current market conditions to persist in the near-term, we are confident in strong secular demand dynamics and our ability to continue to outperform the market."

[0000936395-20-000038:8k_2_02:48]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread; the impact of COVID-19 on macroeconomic conditions, the level of economic activity, demand for our technology solutions, short- and long-term customer or end user needs and changes thereto, continuity of supply chain, logistics and business operations, liquidity and financial results; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies, including the COVID-19 pandemic; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on September 9, 2020 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-20-000038:8k_2_02:49]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release for the relevant period, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-20-000038:8k_2_02:50]
About Ciena.  Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our clients create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-20-000038:8k_2_02:51]
5

[0000936395-20-000038:8k_2_02:52]
CIENA CORPORATION

[0000936395-20-000038:8k_2_02:53]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-20-000038:8k_2_02:54]
(in thousands, except per share data)

[0000936395-20-000038:8k_2_02:55]
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | November 2, |  | October 31, |  | November 2, |
|  |  | 2020 |  | 2019 |  | 2020 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 668,661 |  |  | $ | 820,007 |  |  | $ | 2,914,790 |  |  | $ | 2,983,815 |  |
| Services |  | 159,819 |  |  | 147,980 |  |  | 617,367 |  |  | 588,316 |  |
| Total revenue |  | 828,480 |  |  | 967,987 |  |  | 3,532,157 |  |  | 3,572,131 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 343,413 |  |  | 469,945 |  |  | 1,573,791 |  |  | 1,716,358 |  |
| Services |  | 80,718 |  |  | 78,346 |  |  | 305,475 |  |  | 313,707 |  |
| Total cost of goods sold |  | 424,131 |  |  | 548,291 |  |  | 1,879,266 |  |  | 2,030,065 |  |
| Gross profit |  | 404,349 |  |  | 419,696 |  |  | 1,652,891 |  |  | 1,542,066 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 137,237 |  |  | 141,657 |  |  | 529,888 |  |  | 548,139 |  |
| Selling and marketing |  | 113,382 |  |  | 117,201 |  |  | 416,425 |  |  | 423,046 |  |
| General and administrative |  | 43,415 |  |  | 50,307 |  |  | 169,548 |  |  | 174,399 |  |
| Amortization of intangible assets |  | 5,851 |  |  | 5,222 |  |  | 23,383 |  |  | 21,808 |  |
| Acquisition and integration costs (recoveries) |  | 3,127 |  |  | (735) |  |  | 4,031 |  |  | 3,370 |  |
| Significant asset impairments and restructuring costs |  | 7,854 |  |  | 12,842 |  |  | 22,652 |  |  | 24,538 |  |
| Total operating expenses |  | 310,866 |  |  | 326,494 |  |  | 1,165,927 |  |  | 1,195,300 |  |
| Income from operations |  | 93,483 |  |  | 93,202 |  |  | 486,964 |  |  | 346,766 |  |
| Interest and other income (loss), net |  | (249) |  |  | (1,183) |  |  | 964 |  |  | 3,876 |  |
| Interest expense |  | (7,395) |  |  | (9,136) |  |  | (31,321) |  |  | (37,452) |  |
| Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | (646) |  |  | — |  |
| Income before income taxes |  | 85,839 |  |  | 82,883 |  |  | 455,961 |  |  | 313,190 |  |
| Provision for income taxes |  | 20,798 |  |  | 2,552 |  |  | 94,670 |  |  | 59,756 |  |
| Net income |  | $ | 65,041 |  |  | $ | 80,331 |  |  | $ | 361,291 |  |  | $ | 253,434 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| Basic net income per common share |  | $ | 0.42 |  |  | $ | 0.52 |  |  | $ | 2.34 |  |  | $ | 1.63 |  |
| Diluted net income per potential common share |  | $ | 0.42 |  |  | $ | 0.51 |  |  | $ | 2.32 |  |  | $ | 1.61 |  |
| Weighted average basic common shares outstanding |  | 154,706 |  |  | 154,852 |  |  | 154,287 |  |  | 155,720 |  |
| Weighted average diluted potential common shares outstanding(1) |  | 156,563 |  |  | 156,612 |  |  | 155,955 |  |  | 157,612 |  |

[0000936395-20-000038:8k_2_02:56]
(1) Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the fourth quarter of fiscal 2020 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:57]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for fiscal 2020 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:58]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the fourth quarter of fiscal 2019 includes 1.8 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:59]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:60]
CIENA CORPORATION

[0000936395-20-000038:8k_2_02:61]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-20-000038:8k_2_02:62]
(in thousands, except share data)

[0000936395-20-000038:8k_2_02:63]
|  | October 31, |  | November 2, |
|  | 2020 |  | 2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,088,624 |  |  | $ | 904,045 |  |
| Short-term investments | 150,667 |  |  | 109,940 |  |
| Accounts receivable, net | 719,405 |  |  | 724,854 |  |
| Inventories | 344,379 |  |  | 345,049 |  |
| Prepaid expenses and other | 308,084 |  |  | 297,914 |  |
| Total current assets | 2,611,159 |  |  | 2,381,802 |  |
| Long-term investments | 82,226 |  |  | 10,014 |  |
| Equipment, building, furniture and fixtures, net | 272,377 |  |  | 286,884 |  |
| Operating lease right-of-use assets | 57,026 |  |  | — |  |
| Goodwill | 310,847 |  |  | 297,937 |  |
| Other intangible assets, net | 96,647 |  |  | 112,781 |  |
| Deferred tax asset, net | 647,805 |  |  | 714,942 |  |
| Other long-term assets | 102,830 |  |  | 88,986 |  |
| Total assets | $ | 4,180,917 |  |  | $ | 3,893,346 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 291,904 |  |  | $ | 344,819 |  |
| Accrued liabilities and other short-term obligations | 334,132 |  |  | 382,740 |  |
| Deferred revenue | 108,700 |  |  | 111,381 |  |
| Operating lease liabilities | 19,035 |  |  | — |  |
| Current portion of long-term debt | 6,930 |  |  | 7,000 |  |
| Total current liabilities | 760,701 |  |  | 845,940 |  |
| Long-term deferred revenue | 49,663 |  |  | 45,492 |  |
| Other long-term obligations | 123,185 |  |  | 148,747 |  |
| Long-term operating lease liabilities | 61,415 |  |  | — |  |
| Long-term debt, net | 676,356 |  |  | 680,406 |  |
| Total liabilities | $ | 1,671,320 |  |  | $ | 1,720,585 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 154,563,005 and 154,403,850 shares issued and outstanding | 1,546 |  |  | 1,544 |  |
| Additional paid-in capital | 6,826,531 |  |  | 6,837,714 |  |
| Accumulated other comprehensive loss | (35,358) |  |  | (22,084) |  |
| Accumulated deficit | (4,283,122) |  |  | (4,644,413) |  |
| Total stockholders’ equity | 2,509,597 |  |  | 2,172,761 |  |
| Total liabilities and stockholders’ equity | $ | 4,180,917 |  |  | $ | 3,893,346 |  |

[0000936395-20-000038:8k_2_02:64]
7

[0000936395-20-000038:8k_2_02:65]
CIENA CORPORATION

[0000936395-20-000038:8k_2_02:66]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-20-000038:8k_2_02:67]
(in thousands)

[0000936395-20-000038:8k_2_02:68]
|  | Year Ended |
|  | October 31, 2020 |  | November 2, 2019 |
| Cash flows from operating activities: |  |  |  |
| Net income | $ | 361,291 |  |  | $ | 253,434 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 93,908 |  |  | 87,576 |  |
| Share-based compensation costs | 67,758 |  |  | 59,736 |  |
| Amortization of intangible assets | 38,619 |  |  | 35,136 |  |
| Deferred taxes | 64,339 |  |  | 19,865 |  |
| Provision for doubtful accounts | 8,855 |  |  | 6,740 |  |
| Provision for inventory excess and obsolescence | 24,701 |  |  | 28,085 |  |
| Provision for warranty | 22,417 |  |  | 23,105 |  |
| Other | 11,628 |  |  | (910) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (17,299) |  |  | 65,712 |  |
| Inventories | (25,044) |  |  | (112,941) |  |
| Prepaid expenses and other | (38,998) |  |  | (96,618) |  |
| Operating lease right-of-use assets | 16,787 |  |  | — |  |
| Accounts payable, accruals and other obligations | (117,931) |  |  | 27,740 |  |
| Deferred revenue | 2,519 |  |  | 16,480 |  |
| Short and long-term operating lease liabilities | (19,896) |  |  | — |  |
| Net cash provided by operating activities | 493,654 |  |  | 413,140 |  |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (82,667) |  |  | (62,579) |  |
| Purchase of available for sale securities | (223,196) |  |  | (158,074) |  |
| Proceeds from maturities of available for sale securities | 110,390 |  |  | 248,748 |  |
| Settlement of foreign currency forward contracts, net | 3,531 |  |  | (1,351) |  |
| Purchase of equity investment | — |  |  | (2,667) |  |
| Acquisition of businesses, net of cash acquired | (28,300) |  |  | — |  |
| Net cash provided by (used in) investing activities | (220,242) |  |  | 24,077 |  |
| Cash flows from financing activities: |  |  |  |
| Payment of long-term debt | (5,198) |  |  | (7,000) |  |
| Payment for debt conversion liability | — |  |  | (111,268) |  |
| Payment of debt issuance costs | (382) |  |  | (1,191) |  |
| Payment of finance lease obligations | (2,703) |  |  | (3,319) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (32,472) |  |  | (29,059) |  |
| Repurchases of common stock - repurchase program | (74,535) |  |  | (150,076) |  |
| Proceeds from issuance of common stock | 28,068 |  |  | 22,947 |  |
| Net cash used in financing activities | (87,222) |  |  | (278,966) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (1,643) |  |  | 476 |  |
| Net increase in cash, cash equivalents and restricted cash | 184,547 |  |  | 158,727 |  |
| Cash, cash equivalents and restricted cash at beginning of fiscal year | 904,161 |  |  | 745,434 |  |
| Cash, cash equivalents and restricted cash at end of fiscal year | $ | 1,088,708 |  |  | $ | 904,161 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 32,837 |  |  | $ | 39,579 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 53,076 |  |  | $ | 33,570 |  |
| Operating lease payments | $ | 22,089 |  |  | $ | — |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 7,854 |  |  | $ | 16,549 |  |
| Conversion of debt conversion liability into 1,585,140 shares of common stock | $ | — |  |  | $ | 52,944 |  |
| Operating lease right-of-use assets subject to lease liability | $ | 24,160 |  |  | $ | — |  |
| Unrealized gain on equity investment | $ | 2,681 |  |  | $ | — |  |

[0000936395-20-000038:8k_2_02:69]
| APPENDIX A - Reconciliation of Adjusted (Non-GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |  | October 31, 2020 |  | November 2, 2019 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 404,349 |  |  | $ | 419,696 |  |  | $ | 1,652,891 |  |  | $ | 1,542,066 |  |
| Share-based compensation-products |  | 724 |  |  | 748 |  |  | 3,182 |  |  | 2,868 |  |
| Share-based compensation-services |  | 968 |  |  | 715 |  |  | 3,853 |  |  | 3,175 |  |
| Amortization of intangible assets |  | 3,732 |  |  | 3,303 |  |  | 15,235 |  |  | 13,327 |  |
| Total adjustments related to gross profit |  | 5,424 |  |  | 4,766 |  |  | 22,270 |  |  | 19,370 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 409,773 |  |  | $ | 424,462 |  |  | $ | 1,675,161 |  |  | $ | 1,561,436 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 49.5 | % |  | 43.8 | % |  | 47.4 | % |  | 43.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 310,866 |  |  | $ | 326,494 |  |  | $ | 1,165,927 |  |  | $ | 1,195,300 |  |
| Share-based compensation-research and development |  | 4,030 |  |  | 3,287 |  |  | 16,987 |  |  | 14,321 |  |
| Share-based compensation-sales and marketing |  | 5,137 |  |  | 4,151 |  |  | 20,194 |  |  | 16,474 |  |
| Share-based compensation-general and administrative |  | 5,982 |  |  | 6,425 |  |  | 23,424 |  |  | 22,841 |  |
| Amortization of intangible assets |  | 5,851 |  |  | 5,222 |  |  | 23,383 |  |  | 21,808 |  |
| Acquisition and integration costs (recoveries) |  | 3,127 |  |  | (735) |  |  | 4,031 |  |  | 3,370 |  |
| Significant asset impairments and restructuring costs |  | 7,854 |  |  | 12,842 |  |  | 22,652 |  |  | 24,538 |  |
| Legal settlements |  | — |  |  | — |  |  | — |  |  | 137 |  |
| Total adjustments related to operating expense |  | $ | 31,981 |  |  | $ | 31,192 |  |  | $ | 110,671 |  |  | $ | 103,489 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 278,885 |  |  | $ | 295,302 |  |  | $ | 1,055,256 |  |  | $ | 1,091,811 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 93,483 |  |  | $ | 93,202 |  |  | $ | 486,964 |  |  | $ | 346,766 |  |
| Total adjustments related to gross profit |  | 5,424 |  |  | 4,766 |  |  | 22,270 |  |  | 19,370 |  |
| Total adjustments related to operating expense |  | 31,981 |  |  | 31,192 |  |  | 110,671 |  |  | 103,489 |  |
| Total adjustments related to income from operations |  | 37,405 |  |  | 35,958 |  |  | 132,941 |  |  | 122,859 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 130,888 |  |  | $ | 129,160 |  |  | $ | 619,905 |  |  | $ | 469,625 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 15.8 | % |  | 13.3 | % |  | 17.6 | % |  | 13.1 | % |

[0000936395-20-000038:8k_2_02:70]
9

[0000936395-20-000038:8k_2_02:71]
| APPENDIX A - Reconciliation of Adjusted (Non-GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |  | October 31, 2020 |  | November 2, 2019 |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 65,041 |  |  | $ | 80,331 |  |  | $ | 361,291 |  |  | $ | 253,434 |  |
| Exclude GAAP provision for income taxes |  | 20,798 |  |  | 2,552 |  |  | 94,670 |  |  | 59,756 |  |
| Income before income taxes |  | 85,839 |  |  | 82,883 |  |  | 455,961 |  |  | 313,190 |  |
| Total adjustments related to income from operations |  | 37,405 |  |  | 35,958 |  |  | 132,941 |  |  | 122,859 |  |
| Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | 646 |  |  | — |  |
| Unrealized gain on equity investment |  | (2,681) |  |  | — |  |  | (2,681) |  |  | — |  |
| Adjusted income before income taxes |  | 120,563 |  |  | 118,841 |  |  | 586,867 |  |  | 436,049 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 26,042 |  |  | 28,403 |  |  | 126,763 |  |  | 104,216 |  |
| Adjusted (non-GAAP) net income |  | $ | 94,521 |  |  | $ | 90,438 |  |  | $ | 460,104 |  |  | $ | 331,833 |  |
| Weighted average basic common shares outstanding |  | 154,706 |  |  | 154,852 |  |  | 154,287 |  |  | 155,720 |  |
| Weighted average diluted potential common shares outstanding(1) |  | 156,563 |  |  | 156,612 |  |  | 155,955 |  |  | 157,612 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.42 |  |  | $ | 0.51 |  |  | $ | 2.32 |  |  | $ | 1.61 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.60 |  |  | $ | 0.58 |  |  | $ | 2.95 |  |  | $ | 2.11 |  |

[0000936395-20-000038:8k_2_02:72]
(1) Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the fourth quarter of fiscal 2020 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:73]
Weighted average diluted potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per potential common share for fiscal 2020 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:74]
Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the fourth quarter of fiscal 2019 includes 1.8 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:75]
Weighted average diluted potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per potential common share for fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-20-000038:8k_2_02:76]
10

[0000936395-20-000038:8k_2_02:77]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, 2020 |  | November 2, 2019 |  | October 31, 2020 |  | November 2, 2019 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 65,041 |  |  | $ | 80,331 |  |  | $ | 361,291 |  |  | $ | 253,434 |  |
| Add: Interest expense |  | 7,395 |  |  | 9,136 |  |  | 31,321 |  |  | 37,452 |  |
| Less: Interest and other income (loss), net |  | (249) |  |  | (1,183) |  |  | 964 |  |  | 3,876 |  |
| Add: Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | (646) |  |  | — |  |
| Add: Provision for income taxes |  | 20,798 |  |  | 2,552 |  |  | 94,670 |  |  | 59,756 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,538 |  |  | 22,505 |  |  | 93,908 |  |  | 87,576 |  |
| Add: Amortization of intangible assets |  | 9,584 |  |  | 8,525 |  |  | 38,619 |  |  | 35,136 |  |
| EBITDA |  | $ | 126,605 |  |  | $ | 124,232 |  |  | $ | 619,491 |  |  | $ | 469,478 |  |
| Add: Share-based compensation cost |  | 16,920 |  |  | 15,290 |  |  | 67,758 |  |  | 59,736 |  |
| Add: Significant asset impairments and restructuring costs |  | 7,854 |  |  | 12,842 |  |  | 22,652 |  |  | 24,538 |  |
| Add: Acquisition and integration costs (recoveries) |  | 3,127 |  |  | (735) |  |  | 4,031 |  |  | 3,370 |  |
| Add: Legal settlement |  | — |  |  | — |  |  | — |  |  | 137 |  |
| Adjusted EBITDA |  | $ | 154,506 |  |  | $ | 151,629 |  |  | $ | 713,932 |  |  | $ | 557,259 |  |

[0000936395-20-000038:8k_2_02:78]
* * *

[0000936395-20-000038:8k_2_02:79]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-20-000038:8k_2_02:80]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-20-000038:8k_2_02:81]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-20-000038:8k_2_02:82]
•Acquisition and integration costs (recoveries) - consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of DonRiver and Centina, including costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities.

[0000936395-20-000038:8k_2_02:83]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and the redesign of business processes.

[0000936395-20-000038:8k_2_02:84]
•Legal settlements - costs incurred as a result of settlements, during the first quarter of fiscal 2019.

[0000936395-20-000038:8k_2_02:85]
•Unrealized gain on equity investment -  reflects a change in the carrying value of a certain cost method equity investment.

[0000936395-20-000038:8k_2_02:86]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 21.6% for fiscal 2020, and 23.9% for fiscal 2019. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
