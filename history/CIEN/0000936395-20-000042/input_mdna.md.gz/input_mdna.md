# CIEN MD&A — 0000936395-20-000042


## mdna

[0000936395-20-000042:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-20-000042:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-20-000042:mdna:3]
Overview

[0000936395-20-000042:mdna:4]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that enable the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and emerging network operators.

[0000936395-20-000042:mdna:5]
Our solutions include Networking Platforms, including our Converged Packet Optical and Packet Networking portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Our Converged Packet Optical portfolio includes products and solutions that support the connection of content to content and users to content, including in long haul and regional, submarine and data center interconnect networks. Our Packet Networking portfolio includes products and solutions that enable next-generation metro, access and aggregation networks, connecting users to content in applications that include 5G, mobile backhaul, virtualization and enterprise services.

[0000936395-20-000042:mdna:6]
To complement these solutions, we offer Platform Software, which provides management, domain control and specialized applications that automate network lifecycle operations, including provisioning equipment and services, network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through our Blue Planet® Software suite, we enable customers to transform their business and operations support systems (“OSS”) through software-based automation of their network and IT infrastructures. To complement our hardware and software products, we offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments, including network optimization and migration offerings.

[0000936395-20-000042:mdna:7]
We refer to our complete portfolio vision as the Adaptive Network. The Adaptive Network emphasizes a programmable network infrastructure, software control and automation capabilities, network analytics and intelligence, and related advanced services. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end-user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-20-000042:mdna:8]
Impact of the COVID-19 Pandemic on our Business and Operations

[0000936395-20-000042:mdna:9]
COVID-19 was declared a pandemic in March 2020 and continues to have a significant impact on the global economy, the industries and customers we serve and our operations. In response to the COVID-19 pandemic, we have prioritized the safety of our employees and business partners, while continuing to support the needs of our customers and communities during this unprecedented period. We have also implemented business continuity plans designed to minimize potential business disruption from the COVID-19 pandemic and to protect our supply chain and customer fulfillment and support operations.

[0000936395-20-000042:mdna:10]
Demand for Products & Services. Since the outset of the COVID-19 pandemic, we have experienced a dynamic demand environment, as reflected in significant changes in our order volumes and revenue. During the second quarter of fiscal 2020, we experienced higher than typical orders for our products and services among a concentrated set of larger customers with whom we had an existing position as a supplier. At that time, we believed that some portion of these orders likely reflected short-term purchasing behaviors based on customer-specific considerations in the face of the pandemic, including: customer concerns about future continued availability of supply; implementation of customer business continuity actions; our enhanced efforts to obtain increased visibility into expected demand; customer consumption of their existing inventory or spare equipment; additional network capacity requirements; acceleration of capital spending; and, possibly, increased bandwidth demands being placed on networks due to the pandemic. During the third and fourth quarters of fiscal 2020, our order volumes declined significantly from the level achieved in the second quarter of fiscal 2020, particularly among our communications service provider customers and cable operator customers. We believe that this greater capital expenditure restraint stems from the deferral or re-prioritization of certain new network initiatives and continued uncertainty associated with the impact of the pandemic and economic uncertainty upon their enterprise business segments. As a result, our order volumes were meaningfully below revenue during the second half of fiscal 2020, challenging our visibility and the outlook for orders and revenue in future

[0000936395-20-000042:mdna:11]
periods. We expect this more cautious spending environment to continue into fiscal 2021 and expect these conditions to continue to adversely affect our order volumes and revenue in the short term. Over the longer term, we continue to believe that the unique and increased demands placed on network infrastructures as a result of the COVID-19 pandemic, and the related increase in remote working worldwide, have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation. We believe that we are well positioned competitively to capitalize on the longer-term opportunities that we expect to be presented by these dynamics.

[0000936395-20-000042:mdna:12]
Supply Chain. During the second quarter of fiscal 2020, some of our component suppliers – particularly those with facilities in China and Malaysia – experienced challenges related to COVID-19 that resulted in temporary closures or reductions of supply capacity. Although in many cases we were able to overcome these conditions through execution of our mitigation planning, supply chain disruptions negatively impacted our revenue for the second quarter of fiscal 2020. During the second half of fiscal 2020, we took a number of steps, some of which remain ongoing, including multi-sourcing and pre-ordering components and finished goods inventory, in an effort to reduce the impact of the adverse supply chain conditions that we experienced. As a result of these actions, and generally improved conditions with our suppliers or the geographies in which they operate, supply chain related challenges to our operations abated in the third and fourth quarters of fiscal 2020 and were not material to revenue. However, there can be no assurance that supply chain disruptions related to COVID-19 will not continue, or worsen, in the future.

[0000936395-20-000042:mdna:13]
Services and Customer Fulfillment. We have experienced some disruption in our ability to provide installation, professional and fulfillment services to customers due to site access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings. These conditions, which adversely impacted revenue in the second quarter of fiscal 2020, have also adversely impacted the timing of customer plans for newer network projects and our ability to operationalize recent customer design wins, primarily in international markets. We expect these conditions to persist in the short-term and, as a result, to continue to adversely impact our revenue and results of operations. We continue to take steps and work with customers to ensure their business needs are supported, while protecting the health and safety of our employees, customers and business partners. However, should restrictions or disruptions persist or worsen, including any reduced availability of air transport, port closures, or increased border controls or closures, our business, operations and ability to meet customer demand could be materially adversely affected.

[0000936395-20-000042:mdna:14]
Sales & Marketing. The competitive nature of our business depends on our ability to conduct sales and marketing activities with our customers. For instance, in the past few years, our ability to be first to market with leading networking solutions, and to conduct sales and marketing activities around these new technology offerings, has had a significant impact on our revenue and growth. In the first half of fiscal 2020, we were the first to market with 800 gigabit technology with our fifth-generation WaveLogic® coherent modem technology. Restrictions on travel due to COVID-19 and limitations on interactions with customers, such as field and lab trials, have negatively impacted our ability to carry out certain sales and marketing activities, including our ability to secure new customers, to qualify and sell new products, and to grow sales with customers. This is particularly the case where we do not have longer-standing supply relationships, such as within international markets and for our Blue Planet Automation Software and Services segment and our Packet Networking product line. We believe customers are exercising greater restraint in networking projects, including data centers, and are also more carefully prioritizing where and when to add network capacity. Delays in operationalizing new network projects that we anticipated occurring on their original timelines adversely affected our revenue during fiscal 2020. Conversely, our recent gross margin performance has benefited from these dynamics, with a larger percentage of our revenue comprised of existing business, as compared to new design wins and early in life projects, which tend to have lower margins.

[0000936395-20-000042:mdna:15]
Market Growth & Conditions. We believe that ongoing concerns relating to the pandemic, and its impact on the enterprise business segments of our communications service provider and cable operator customers, continue to adversely impact the velocity of business in general, with a particular impact on customer willingness and ability to initiate new network projects. For example, our service provider customers rely in part upon the sale of services to consumers and enterprises, including those in the retail, entertainment, and travel industries, which have been acutely impacted by the negative economic effects of the COVID-19 pandemic. Similarly, certain of our Web-scale customers have business models that heavily rely upon advertising revenue from enterprises, including those in industries acutely affected by the COVID-19 pandemic. As a result of these dynamics, the growth rates in our addressable markets slowed during fiscal 2020 as compared to fiscal 2019, which adversely impacted our revenue in fiscal 2020. We expect these market dynamics, including constrained customer spending and the decreased velocity of new business execution, to persist into fiscal 2021.

[0000936395-20-000042:mdna:16]
Liquidity & Balance Sheet. As of the end of the fourth quarter of fiscal 2020, we had $1.3 billion in cash and investments. We believe our strong liquidity and balance sheet position is an important competitive differentiator at this time. It enables us to continue to invest in innovation, ensure a strong inventory position to support customers and provide for working capital needs. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and may consider capital raising and other market opportunities that may be available to us. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020, we temporarily suspended purchases of our common stock under our stock repurchase program and reallocated our investments principally to

[0000936395-20-000042:mdna:17]
U.S. government-backed funds. On December 10, 2020, we announced that we will resume purchases under our stock repurchase program beginning in the first quarter of fiscal 2021.

[0000936395-20-000042:mdna:18]
The COVID-19 pandemic and countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic, and the duration and severity of its impact on our business and results of operations in future periods remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-20-000042:mdna:19]
Market Opportunity

[0000936395-20-000042:mdna:20]
The markets in which we sell our communications networking solutions are dynamic and are characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Emerging services and applications, including 5G mobile communications, Fiber Deep and the Internet of Things, are further impacting or expected to impact wireline network infrastructures, particularly at the edge of networks, where increased computing power and automation are required to provide the quality of experience demanded by end users. Many network operators are under pressure to constrain their capital expenditure budgets, as they cannot grow their network spending at the rate of bandwidth growth, including due to their business models. To address these growing service demands and better manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation. Other network operators are pursuing a diverse range of consumption models in their design and procurement of network infrastructure solutions. Our Adaptive Network vision and our business strategy to capitalize on these changing market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-20-000042:mdna:21]
Business Diversification

[0000936395-20-000042:mdna:22]
A key element of our strategy is to continue to diversify our solutions offerings, customer base and geographic reach to address fast-growing applications and markets. We believe that the continued diversification of our business is important to address the dynamic industry environment in which we operate, to grow our business, and to better withstand potential slowdowns adversely affecting particular geographies, markets or customer segments. In recent fiscal years prior to fiscal 2020, our diversification and global scale were key contributors to our strong revenue growth. In fiscal 2020, we believe this diversification allowed us to maintain a greater degree of stability and allowed us to remain resilient despite the impact of the COVID-19 pandemic on any particular geography, segment or customer account.

[0000936395-20-000042:mdna:23]
Investment in Technology Innovation

[0000936395-20-000042:mdna:24]
We believe that our investment capacity and our efforts to push the pace of innovation in our markets, and to provide market-leading offerings ahead of our competitors, are important competitive differentiators in our markets. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures, and research and development spending represented 45.4% of our operating expenses in fiscal 2020. During fiscal 2020, we invested $529.9 million in research and development activities, a decrease of approximately 3.3% compared to fiscal 2019, primarily due to the impact of COVID-19. However, we expect our operating expenses to increase in fiscal 2021, in part to support additional investment in research and development activities. We believe that remaining competitive in our addressable geographies, markets, and customer segments depends on our continued significant investment in innovation and our ability to offer leading solutions that enable adoption of next-generation network infrastructures and evolving consumption models for networking solutions.

[0000936395-20-000042:mdna:25]
Optical and Packet Infrastructure Technology. We are focused on growing our optical and packet infrastructure business by addressing fast-growing markets and applications, including data center interconnection, packet aggregation and routing and submarine networks. In fiscal 2020, we brought to market our fifth-generation coherent modem technology capable of delivering 800 gigabits of capacity per second over a single wavelength, and, during 2021, we expect to bring to market our footprint-optimized WaveLogic 5 Nano 100G-400G coherent pluggable transceivers. We are also developing Packet Networking solutions with enhanced IP/Ethernet capabilities to expand our addressable market into additional next generation metro and access applications including packet routing, aggregation and switching, 5G cross-haul, Fiber Deep, and edge computing. In fiscal 2020, we also announced the future addition of several new routing platforms to support the demands of mobile xHaul (fronthaul, midhaul and backhaul) transport, which we expect to make available in fiscal 2021.

[0000936395-20-000042:mdna:26]
Blue Planet Automation Software. We have continued to pursue both organic investments and acquisition opportunities to expand our Blue Planet Automation Software and Services portfolio and business. On November 4, 2019, we acquired privately held Centina Systems, Inc., a provider of service assurance analytics and network performance management solutions. The acquisition of Centina is intended to accelerate Blue Planet’s software strategy of providing closed loop, intelligent automation solutions that help communications service providers analyze network conditions, traffic demands, and resource availability, and determine the best placement of traffic for optimal service quality and resource utilization. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on this acquisition and the related accounting. In addition, we have enhanced our Blue Planet Intelligent Automation software portfolio for 5G automation applications, including vendor-agnostic network slicing features and dynamic planning capabilities that are intended to better enable mobile network operators to deliver 5G mobile services.

[0000936395-20-000042:mdna:27]
Fiscal Year-End Backlog

[0000936395-20-000042:mdna:28]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These agreements do not obligate customers to purchase any minimum or guaranteed order quantities. Moreover, we are periodically awarded business for new network opportunities or network upgrades following a selection process. In calculating backlog, we only include (i) customer purchase orders for products that have not been shipped and for services that have not yet been performed; and (ii) customer orders relating to products that have been delivered and services that have been performed, but are awaiting customer acceptance under the applicable contract terms. Generally, our customers may cancel or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. Backlog may be fulfilled several quarters following receipt of a purchase order, or in the case of certain service obligations, may relate to multi-year support period. As a result, backlog should not necessarily be viewed as an accurate indicator of future revenue for any particular period.

[0000936395-20-000042:mdna:29]
Our backlog was $1.19 billion as of October 31, 2020 as compared to $1.21 billion as of November 2, 2019. Backlog includes product and service orders from commercial and government customers combined. Backlog at October 31, 2020 includes approximately $193.5 million primarily related to orders for products and maintenance and support services that are not expected to be filled or performed within fiscal 2021. Because backlog can be defined in different ways by different companies, our presentation of backlog may not be comparable with figures presented by other companies in our industry.

[0000936395-20-000042:mdna:30]
Consolidated Results of Operations

[0000936395-20-000042:mdna:31]
A discussion regarding our financial condition and results of operations for fiscal 2020 compared to fiscal 2019 is presented below. A discussion of fiscal 2019 compared to fiscal 2018 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended November 2, 2019, filed with the SEC on December 20, 2019 (our “2019 Annual Report”), which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-20-000042:mdna:32]
Operating Segments

[0000936395-20-000042:mdna:33]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0000936395-20-000042:mdna:34]
Fiscal 2020 Compared to Fiscal 2019

[0000936395-20-000042:mdna:35]
Revenue

[0000936395-20-000042:mdna:36]
During fiscal 2020, approximately 15.9% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, British Pounds, and Indian Rupee. During fiscal 2020 as compared to fiscal 2019, the U.S. Dollar fluctuated against these and other currencies. Consequently, our revenue reported in U.S. Dollars was slightly reduced by approximately $13.5 million, or 0.4%, as compared to fiscal 2019 due to fluctuations in foreign currency. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000042:mdna:37]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,547,647 |  |  | 72.1 |  |  | $ | 2,562,841 |  |  | 71.8 |  |  | $ | (15,194) |  |  | (0.6) |  |
| Packet Networking | 267,416 |  |  | 7.6 |  |  | 348,477 |  |  | 9.8 |  |  | (81,061) |  |  | (23.3) |  |
| Total Networking Platforms | 2,815,063 |  |  | 79.7 |  |  | 2,911,318 |  |  | 81.6 |  |  | (96,255) |  |  | (3.3) |  |
| Platform Software and Services | 197,809 |  |  | 5.6 |  |  | 155,376 |  |  | 4.3 |  |  | 42,433 |  |  | 27.3 |  |
| Blue Planet Automation Software and Services | 62,632 |  |  | 1.8 |  |  | 54,555 |  |  | 1.5 |  |  | 8,077 |  |  | 14.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 269,354 |  |  | 7.6 |  |  | 261,337 |  |  | 7.3 |  |  | 8,017 |  |  | 3.1 |  |
| Installation and Deployment | 152,003 |  |  | 4.3 |  |  | 148,233 |  |  | 4.1 |  |  | 3,770 |  |  | 2.5 |  |
| Consulting and Network Design | 35,296 |  |  | 1.0 |  |  | 41,312 |  |  | 1.2 |  |  | (6,016) |  |  | (14.6) |  |
| Total Global Services | 456,653 |  |  | 12.9 |  |  | 450,882 |  |  | 12.6 |  |  | 5,771 |  |  | 1.3 |  |
| Consolidated revenue | $ | 3,532,157 |  |  | 100.0 |  |  | $ | 3,572,131 |  |  | 100.0 |  |  | $ | (39,974) |  |  | (1.1) |  |

[0000936395-20-000042:mdna:38]
_________________________________

[0000936395-20-000042:mdna:39]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:40]
•Networking Platforms segment revenue decreased, reflecting product line sales decreases of $15.2 million of our Converged Packet Optical products and $81.1 million of our Packet Networking products.

[0000936395-20-000042:mdna:41]
◦Converged Packet Optical sales decreased, primarily reflecting a sales decrease of $86.7 million of our 6500 Packet-Optical Platform primarily to communications service providers. This sales decrease was partially offset by sales increases of $38.3 million of our Waveserver products, primarily to communications service providers and cable and multiservice operators, and $26.3 million of our 5400 family of Packet-Optical Platforms primarily to communications service providers.

[0000936395-20-000042:mdna:42]
◦Packet Networking sales decreased, primarily reflecting a sales decrease of $87.2 million of our 6500 Packet Transport System (PTS) to a certain communications service provider in the Americas.

[0000936395-20-000042:mdna:43]
•Platform Software and Services segment revenue increased, reflecting increases of $26.3 million in software sales and $16.1 million in services, primarily to communications service providers. The software sales increase was primarily due to increased sales of $32.1 million of our MCP software platform, partially offset by a decline in sales of $6.9 million of our OneControl Unified Management System software. We continue to pursue further customer adoption of our MCP software platform and its enhanced features and functionality. As we transition existing customers as well as features and functionality from our legacy software to this platform, we expect revenue declines for our legacy software solutions within this segment.

[0000936395-20-000042:mdna:44]
•Blue Planet Automation Software and Services segment revenue increased, primarily reflecting an increase of $7.2 million in software services. Our entrance into the software automation market remains in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date.

[0000936395-20-000042:mdna:45]
•Global Services segment revenue increased, primarily reflecting sales increases of $8.0 million of our maintenance support and training and $3.8 million of our installation and deployment services, partially offset by a sales decrease of $6.0 million of our consulting and network design services in part due to impacts of COVID-19 as described above.

[0000936395-20-000042:mdna:46]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”) and Asia Pacific, Japan and India (“APAC”). As discussed in Note 2 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report, effective the beginning of fiscal 2020, our Global Sales and Marketing organization combined our previous North America and Caribbean and Latin America (“CALA”) regions into a new

[0000936395-20-000042:mdna:47]
Americas sales region. The decrease in our Americas region revenue for fiscal 2020 was primarily driven by decreased sales in Canada, Argentina and Mexico. The increase in our EMEA region revenue for fiscal 2020 was primarily driven by increased sales in the Netherlands, the United Arab Emirates and France, partially offset by decreased sales in the United Kingdom. The decrease in our APAC region revenue for fiscal 2020 was primarily driven by decreased sales in Japan, India and South Korea, partially offset by increased sales in Singapore and Australia. The following table reflects our geographic distribution of revenue, which is principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000042:mdna:48]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 2,469,278 |  |  | 69.9 |  |  | $ | 2,503,913 |  |  | 70.1 |  |  | $ | (34,635) |  |  | (1.4) |  |
| EMEA | 591,468 |  |  | 16.8 |  |  | 566,718 |  |  | 15.9 |  |  | 24,750 |  |  | 4.4 |  |
| APAC | 471,411 |  |  | 13.3 |  |  | 501,500 |  |  | 14.0 |  |  | (30,089) |  |  | (6.0) |  |
| Total | $ | 3,532,157 |  |  | 100.0 |  |  | $ | 3,572,131 |  |  | 100.0 |  |  | $ | (39,974) |  |  | (1.1) |  |

[0000936395-20-000042:mdna:49]
_________________________________

[0000936395-20-000042:mdna:50]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:51]
•Americas revenue decreased, primarily reflecting sales decreases of $81.1 million within our Networking Platforms segment and $3.3 million within our Blue Planet Automation Software and Services segment. These sales decreases were partially offset by sales increases of $30.8 million within our Platform Software and Services segment and $19.0 million within our Global Services segment. Our Networking Platforms segment revenue decrease reflects a product line sales decrease of $89.7 million of Packet Networking products, including a decrease of $87.9 million in sales of our 6500 Packet Transport System (PTS) to a communications service provider. Our Networking Platforms segment also reflects an increase of $8.6 million of Converged Packet Optical products, which includes sales contributions from a diverse set of customer verticals, primarily from government, cable and multiservice operators, submarine network operators and communications service providers, and continued strong demand for our Waveserver product, which partially offset a reduction in sales of 6500 Packet-Optical Platform with large communication service providers.

[0000936395-20-000042:mdna:52]
•EMEA revenue increased, primarily reflecting sales increases of $20.4 million within our Networking Platforms segment, $5.2 million within our Platform Software and Services segment and $3.4 million within our Blue Planet Automation Software and Services segment, partially offset by a sales decrease of $4.2 million within our Global Services segment. Our Networking Platforms segment revenue increase reflects a product line sales increase of $15.8 million of Converged Packet Optical products, primarily related to sales increases of $8.4 million of our 6500 Packet-Optical Platform to communications service providers and Web-scale providers and $6.5 million of our 5400 family Packet-Optical Platforms to communications service providers.

[0000936395-20-000042:mdna:53]
•APAC revenue decreased, primarily reflecting sales decreases of $35.6 million within our Networking Platforms segment and $9.0 million of our Global Services segment. These sales decreases were partially offset by sales increases of $8.0 million within our Blue Planet Automation Software and Services segment and $6.4 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $56.5 million in sales of our 6500 Packet-Optical Platform to communications service providers in Japan and India, partially offset by an increase of $16.7 million in sales of our Waveserver products primarily to Web-scale providers.

[0000936395-20-000042:mdna:54]
In fiscal 2020 and fiscal 2019, our top ten customers contributed 54.5% and 59.3% of our revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting the businesses of those customers. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Sales to AT&T were $373.2 million, or 10.6% of total revenue, in fiscal 2020, and $388.7 million, or 10.9% of total revenue, in fiscal 2019. Verizon accounted for $459.8 million, or 12.9% of total revenue, in fiscal 2019. Sales to one of our Web-scale customers was $370.6 million, or 10.4% of total revenue, in fiscal 2019. No other customer accounted for

[0000936395-20-000042:mdna:55]
greater than 10% of our revenue in fiscal 2020 or fiscal 2019. The identity of and percentage of revenue attributable to our largest customers has varied from period to period. For example, the Web-scale provider noted above contributed greater than 10% of our revenue for the first time in fiscal 2019.

[0000936395-20-000042:mdna:56]
While drivers of bandwidth growth and network evolution remain strong, many of our network operator customers are under pressure to constrain their capital expenditure budgets, and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or features, there is a market expectation of solutions that are more cost-effective from a price for performance perspective than existing or competing solutions. The combination of this regular technology-driven price compression, price competition in our markets and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-20-000042:mdna:57]
Cost of Goods Sold and Gross Profit

[0000936395-20-000042:mdna:58]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-20-000042:mdna:59]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-20-000042:mdna:60]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-20-000042:mdna:61]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-20-000042:mdna:62]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-20-000042:mdna:63]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 3,532,157 |  |  | 100.0 |  |  | $ | 3,572,131 |  |  | 100.0 |  |  | $ | (39,974) |  |  | (1.1) |  |
| Total cost of goods sold | 1,879,266 |  |  | 53.2 |  |  | 2,030,065 |  |  | 56.8 |  |  | (150,799) |  |  | (7.4) |  |
| Gross profit | $ | 1,652,891 |  |  | 46.8 |  |  | $ | 1,542,066 |  |  | 43.2 |  |  | $ | 110,825 |  |  | 7.2 |  |

[0000936395-20-000042:mdna:64]
_________________________________

[0000936395-20-000042:mdna:65]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:66]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,914,790 |  |  | 100.0 |  |  | $ | 2,983,815 |  |  | 100.0 |  |  | $ | (69,025) |  |  | (2.3) |  |
| Product cost of goods sold | 1,573,791 |  |  | 54.0 |  |  | 1,716,358 |  |  | 57.5 |  |  | (142,567) |  |  | (8.3) |  |
| Product gross profit | $ | 1,340,999 |  |  | 46.0 |  |  | $ | 1,267,457 |  |  | 42.5 |  |  | $ | 73,542 |  |  | 5.8 |  |

[0000936395-20-000042:mdna:67]
_________________________________

[0000936395-20-000042:mdna:68]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:69]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 617,367 |  |  | 100.0 |  |  | $ | 588,316 |  |  | 100.0 |  |  | $ | 29,051 |  |  | 4.9 |  |
| Service cost of goods sold | 305,475 |  |  | 49.5 |  |  | 313,707 |  |  | 53.3 |  |  | (8,232) |  |  | (2.6) |  |
| Service gross profit | $ | 311,892 |  |  | 50.5 |  |  | $ | 274,609 |  |  | 46.7 |  |  | $ | 37,283 |  |  | 13.6 |  |

[0000936395-20-000042:mdna:70]
_________________________________

[0000936395-20-000042:mdna:71]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:72]
•Gross profit as a percentage of revenue increased as our gross margin benefited significantly from a favorable mix of customers and product lines that we believe to be a short-term effect due to COVID-19 related factors, and, to a lesser extent, continued improvement in our service margin. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, during the last three quarters of fiscal 2020, a higher proportion of our revenue consisted of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, which tend to carry lower margins. We expect our gross margins to reduce from these elevated short-term levels as some of the pandemic’s impacts on new business lessen and our overall revenue resumes a more typical composition of revenue from existing and new business. Our efforts to expand our customer base or market share have in prior periods adversely affected our gross margin depending upon our mix of revenues from new wins or early stage deployments in a particular period.

[0000936395-20-000042:mdna:73]
•Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and product lines, as described above, and continued product cost reductions, partially offset by market-based price compression we encountered during the period.

[0000936395-20-000042:mdna:74]
•Gross profit on services as a percentage of services revenue increased, primarily due to a higher concentration of revenue from maintenance service contracts with relatively low incremental costs, and fewer early stage network deployment activities due to the impact of COVID-19.

[0000936395-20-000042:mdna:75]
Operating Expense

[0000936395-20-000042:mdna:76]
Operating expense decreased in fiscal 2020 from the level reported for fiscal 2019 primarily due to a reduction in certain variable compensation costs associated with our annual cash incentive compensation plan and the impact of COVID-19 on our travel and entertainment costs.

[0000936395-20-000042:mdna:77]
Operating expense consists of the component elements described below.

[0000936395-20-000042:mdna:78]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-20-000042:mdna:79]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-20-000042:mdna:80]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-20-000042:mdna:81]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-20-000042:mdna:82]
•Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of DonRiver and Centina, including costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition.

[0000936395-20-000042:mdna:83]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-20-000042:mdna:84]
During fiscal 2020, approximately 48.5% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, Indian Rupees, Brazilian Reais, British Pounds and Euros. During fiscal 2020 as compared to fiscal 2019, the U.S. Dollar fluctuated against these and other currencies. Consequently, our operating expense reported in U.S. Dollars was reduced by approximately $6.2 million, or 0.5%, net of hedging.

[0000936395-20-000042:mdna:85]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000042:mdna:86]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 529,888 |  |  | 15.0 |  |  | $ | 548,139 |  |  | 15.3 |  |  | $ | (18,251) |  |  | (3.3) |  |
| Selling and marketing | 416,425 |  |  | 11.8 |  |  | 423,046 |  |  | 11.8 |  |  | (6,621) |  |  | (1.6) |  |
| General and administrative | 169,548 |  |  | 4.8 |  |  | 174,399 |  |  | 4.9 |  |  | (4,851) |  |  | (2.8) |  |
| Amortization of intangible assets | 23,383 |  |  | 0.7 |  |  | 21,808 |  |  | 0.6 |  |  | 1,575 |  |  | 7.2 |  |
| Acquisition and integration costs | 4,031 |  |  | 0.1 |  |  | 3,370 |  |  | 0.1 |  |  | 661 |  |  | 19.6 |  |
| Significant asset impairments and restructuring costs | 22,652 |  |  | 0.6 |  |  | 24,538 |  |  | 0.7 |  |  | (1,886) |  |  | (7.7) |  |
| Total operating expenses | $ | 1,165,927 |  |  | 33.0 |  |  | $ | 1,195,300 |  |  | 33.4 |  |  | $ | (29,373) |  |  | (2.5) |  |

[0000936395-20-000042:mdna:87]
_________________________________

[0000936395-20-000042:mdna:88]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:89]
•Research and development expense benefited from $3.5 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, research and development expense decreased by $18.3 million. This decrease primarily reflects decreases in employee and compensation costs, professional services, facility costs, and travel and entertainment costs, as a result of COVID-19, partially offset by an increase in software technology costs.

[0000936395-20-000042:mdna:90]
•Selling and marketing expense benefited from $1.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Brazilian Reais. Including the effect of foreign exchange rates, sales and marketing expense decreased by $6.6 million. This decrease primarily reflects decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19, partially offset by an increase in employee and compensation costs.

[0000936395-20-000042:mdna:91]
•General and administrative expense benefited from $1.1 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Indian Rupee and Brazilian Reais. Including the effect of foreign exchange rates, general and administrative expense decreased by $4.9 million. This decrease primarily reflects decreases in employee and compensation costs and travel and entertainment costs partially offset by increased bad debt expense.

[0000936395-20-000042:mdna:92]
•Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisition of Centina in the first quarter of fiscal 2020.

[0000936395-20-000042:mdna:93]
•Acquisition and integration costs reflect employment-related costs and recoveries of acquisition consideration associated with a three-year earn-out arrangement related to the DonRiver acquisition and, legal, employee-related and other costs related to our acquisition of Centina.

[0000936395-20-000042:mdna:94]
•Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, the redesign of certain business processes and unfavorable lease commitments for certain facility locations in the United States and India where we have vacated unused space.

[0000936395-20-000042:mdna:95]
Other Items

[0000936395-20-000042:mdna:96]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-20-000042:mdna:97]
|  | Fiscal Year |  |  |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | 964 |  |  | — |  |  | $ | 3,876 |  |  | 0.1 |  |  | $ | (2,912) |  |  | (75.1) |  |
| Interest expense | $ | 31,321 |  |  | 0.9 |  |  | $ | 37,452 |  |  | 1.0 |  |  | $ | (6,131) |  |  | (16.4) |  |
| Loss on extinguishment/modification of debt | $ | (646) |  |  | — |  |  | $ | — |  |  | — |  |  | $ | 646 |  |  | — |  |
| Provision for income taxes | $ | 94,670 |  |  | 2.7 |  |  | $ | 59,756 |  |  | 1.7 |  |  | $ | 34,914 |  |  | 58.4 |  |

[0000936395-20-000042:mdna:98]
_________________________________

[0000936395-20-000042:mdna:99]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:100]
•Interest and other income (loss), net decreased, primarily reflecting lower interest income due to reduced interest rates on our investments, partially offset by a favorable adjustment to the carrying value of a cost method equity investment and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-20-000042:mdna:101]
•Interest expense decreased, primarily due to a reduction of LIBOR rates impacting our New 2025 Term Loan. For additional information on our 2025 Term Loan, see Note 18 to our Consolidated Financial Statements in Item 8 of Part II of this report.

[0000936395-20-000042:mdna:102]
•Loss on extinguishment and modification of debt reflects the refinance of our 2025 Term Loan. See Note 18 to our Consolidated Financial Statements in Item 8 of Part II of this report.

[0000936395-20-000042:mdna:103]
•Provision for income taxes increased, due to higher earnings for fiscal 2020 and the effective tax rate for fiscal 2020 was higher compared to fiscal 2019, primarily due to a higher foreign effective tax rate.

[0000936395-20-000042:mdna:104]
Segment Profit (Loss)

[0000936395-20-000042:mdna:105]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-20-000042:mdna:106]
|  | Fiscal Year |  |  |
|  | 2020 |  | 2019 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 827,105 |  |  | $ | 759,244 |  |  | $ | 67,861 |  |  | 8.9 |  |
| Platform Software and Services | $ | 105,609 |  |  | $ | 64,210 |  |  | $ | 41,399 |  |  | 64.5 |  |
| Blue Planet Automation Software and Services | $ | (12,446) |  |  | $ | (17,769) |  |  | $ | 5,323 |  |  | (30.0) |  |
| Global Services | $ | 202,735 |  |  | $ | 188,242 |  |  | $ | 14,493 |  |  | 7.7 |  |

[0000936395-20-000042:mdna:107]
_________________________________

[0000936395-20-000042:mdna:108]
| * | Denotes % change from 2019 to 2020 |

[0000936395-20-000042:mdna:109]
•Networking Platforms segment profit increased, primarily due to higher gross margin and lower research and development costs, partially offset by lower sales volume as described above.

[0000936395-20-000042:mdna:110]
•Platform Software and Services segment profit increased, primarily due to higher sales volume, as described above, and lower research and development costs, partially offset by reduced gross margin on software-related services.

[0000936395-20-000042:mdna:111]
•Blue Planet Automation Software and Services segment loss decreased, primarily due to higher gross margin on software-related services and higher sales volume, partially offset by higher research and development costs and lower gross margin on software revenue due to increased intangible amortization costs.

[0000936395-20-000042:mdna:112]
•Global Services segment profit increased, primarily due to improved gross margin and higher sales volume, as described above.

[0000936395-20-000042:mdna:113]
Liquidity and Capital Resources

[0000936395-20-000042:mdna:114]
Overview. For the fiscal year ended October 31, 2020, we generated $493.7 million of cash from operations, as our net income (adjusted for non-cash charges) of $693.5 million exceeded our working capital requirements of $199.8 million. For additional details on our cash provided by operating activities, see the discussion below under the caption “Cash Provided By Operating Activities.”

[0000936395-20-000042:mdna:115]
Cash, cash equivalents and investments increased by $297.5 million during fiscal 2020. The cash from operations above was partially offset by the following: (i) cash used to fund our investing activities for capital expenditures totaling $82.7 million; (ii) cash used for stock repurchase under our stock repurchase program of $74.5 million; (iii) cash used in the acquisition of Centina of $28.3 million, net of cash acquired; (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $32.5 million; and (v) cash used for payments on our term loan due September 28, 2025 (the “2025 Term Loan”) of $5.2 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $28.1 million in cash during fiscal 2020.

[0000936395-20-000042:mdna:116]
See Notes 3, 18 and 21 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-20-000042:mdna:117]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-20-000042:mdna:118]
|  | October 31, 2020 |  | November 2, 2019 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 1,088,624 |  |  | $ | 904,045 |  |  | $ | 184,579 |  |
| Short-term investments in marketable debt securities | 150,667 |  |  | 109,940 |  |  | 40,727 |  |
| Long-term investments in marketable debt securities | 82,226 |  |  | 10,014 |  |  | 72,212 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,321,517 |  |  | $ | 1,023,999 |  |  | $ | 297,518 |  |

[0000936395-20-000042:mdna:119]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash and investments, which as of October 31, 2020 totaled $1.32 billion, as well as the senior secured asset-based revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility, which we entered into with certain of our subsidiaries on October 28, 2019, replaced a predecessor senior secured asset-based revolving credit facility and provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 31, 2020, letters of credit totaling $83.0 million were outstanding under our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2020.

[0000936395-20-000042:mdna:120]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $96.2 million as of October 31, 2020. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $25.0 million. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-20-000042:mdna:121]
Stock Repurchase Authorization. On December 13, 2018, we announced that our Board of Directors authorized a program to repurchase up to $500 million of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. In light of the uncertainty surrounding the duration and severity of potential macroeconomic impacts of COVID-19, on March 17, 2020, we temporarily suspended purchases of our common stock under this program. We repurchased $74.5 million under this program during fiscal 2020, and had $275.4 million remaining under the current authorization as of October 31, 2020. On December 10, 2020, we announced that we will resume purchases under the stock repurchase program beginning in the first quarter of fiscal 2021. The amount and timing of repurchases are subject to a variety

[0000936395-20-000042:mdna:122]
of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-20-000042:mdna:123]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain, and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-20-000042:mdna:124]
Cash Provided by Operating Activities

[0000936395-20-000042:mdna:125]
The following sections set forth the components of our $493.7 million of cash provided by operating activities for fiscal 2020:

[0000936395-20-000042:mdna:126]
Net income (adjusted for non-cash charges)

[0000936395-20-000042:mdna:127]
The following tables set forth our net income (adjusted for non-cash charges) during fiscal 2020 (in thousands):

[0000936395-20-000042:mdna:128]
|  | Year Ended |
|  | October 31, 2020 |
| Net income | $ | 361,291 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 93,908 |  |
| Share-based compensation costs | 67,758 |  |
| Amortization of intangible assets | 38,619 |  |
| Deferred taxes | 64,339 |  |
| Provision for doubtful accounts | 8,855 |  |
| Provision for inventory excess and obsolescence | 24,701 |  |
| Provision for warranty | 22,417 |  |
| Other | 11,628 |  |
| Net income (adjusted for non-cash charges) | $ | 693,516 |  |

[0000936395-20-000042:mdna:129]
Working Capital

[0000936395-20-000042:mdna:130]
We used $199.8 million of cash for working capital during fiscal 2020. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-20-000042:mdna:131]
|  | Year Ended |
|  | October 31, 2020 |
| Cash used in accounts receivable | $ | (17,299) |  |
| Cash used in inventories | (25,044) |  |
| Cash used in prepaid expenses and other | (38,998) |  |
| Cash used in accounts payable, accruals and other obligations | (117,931) |  |
| Cash provided by deferred revenue | 2,519 |  |
| Cash used in operating lease assets and liabilities, net | (3,109) |  |
| Total cash used for working capital | $ | (199,862) |  |

[0000936395-20-000042:mdna:132]
As compared to the end of fiscal 2019:

[0000936395-20-000042:mdna:133]
•The $17.3 million of cash used in accounts receivable during fiscal 2020 reflects increased sales volume at the end of the fourth quarter of fiscal 2020;

[0000936395-20-000042:mdna:134]
•The $25.0 million of cash used in inventory during fiscal 2020 primarily reflects increases in finished goods to meet customer delivery schedules related to some of the actions that we took during the last three quarters of fiscal 2020 to mitigate the risk of adverse supply chain impact on our business and operations due to COVID-19 related disruptions;

[0000936395-20-000042:mdna:135]
•The $39.0 million of cash used in prepaid expenses and other during fiscal 2020 primarily reflects increases in upfront future discounts paid to customers;

[0000936395-20-000042:mdna:136]
•The $117.9 million of cash used in accounts payable, accruals and other obligations during fiscal 2020 primarily reflects lower employee bonus accrual associated with our annual cash incentive compensation plan and increased payments for inventory purchases;

[0000936395-20-000042:mdna:137]
•The $2.5 million of cash provided by deferred revenue during fiscal 2020 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-20-000042:mdna:138]
•The $3.1 million of cash used in operating lease assets and liabilities, net, during fiscal 2020 represents cash paid for operating leases. For more details, see Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-20-000042:mdna:139]
Our days sales outstanding (“DSOs”) were 82 for both fiscal 2020 and fiscal 2019. Our inventory turns decreased from 5.0 turns during fiscal 2019 to 4.6 turns during fiscal 2020 due to the increase in inventory. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-20-000042:mdna:140]
Cash paid for interest

[0000936395-20-000042:mdna:141]
The following table sets forth the cash paid for interest during fiscal 2020 (in thousands):

[0000936395-20-000042:mdna:142]
|  | Year Ended |
|  | October 31, 2020 |
| Term Loan due September 28, 2025 (Old)(1) | 6,691 |  |
| Term Loan due September 28, 2025 (New)(2) | 12,306 |  |
| Interest rate swaps(3) | 7,258 |  |
| ABL Credit Facilities(4) | 1,801 |  |
| Capital leases | 4,781 |  |
| Total cash paid during period | $ | 32,837 |  |

[0000936395-20-000042:mdna:143]
(1) Interest on the Old 2025 Term Loan was payable periodically based on the interest period selected for borrowing. The Old 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. On January 23, 2020, we refinanced and replaced this term loan with the New 2025 Term Loan. See Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-20-000042:mdna:144]
(2) Interest on the New 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The New 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of fiscal 2020, the interest rate on the New 2025 Term Loan was 1.90%.

[0000936395-20-000042:mdna:145]
(3) The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan at 2.957% through September 2023.

[0000936395-20-000042:mdna:146]
(4) During fiscal 2020, we utilized the ABL Credit Facility and its predecessor to collateralize certain standby letters of credit and paid $1.8 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-20-000042:mdna:147]
For additional information about our term loans, ABL Credit Facility and interest rate swaps, see Notes 15, 18 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-20-000042:mdna:148]
Contractual Obligations

[0000936395-20-000042:mdna:149]
The following is a summary of our future minimum payments under contractual obligations as of October 31, 2020 (in thousands):

[0000936395-20-000042:mdna:150]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due on Term Loan due September 28, 2025(1) | $ | 687,803 |  |  | $ | 6,930 |  |  | $ | 13,860 |  |  | $ | 667,013 |  |  | $ | — |  |
| Interest due on Term Loan due September 28, 2025(1) | 64,032 |  |  | 13,220 |  |  | 26,039 |  |  | 24,773 |  |  | — |  |
| Payments due under interest rate swaps(1) | 29,050 |  |  | 9,956 |  |  | 19,094 |  |  | — |  |  | — |  |
| Operating leases(2) | 86,414 |  |  | 20,989 |  |  | 34,104 |  |  | 21,956 |  |  | 9,365 |  |
| Purchase obligations(3) | 524,074 |  |  | 524,074 |  |  | — |  |  | — |  |  | — |  |
| Finance leases(4) | 97,333 |  |  | 7,444 |  |  | 15,712 |  |  | 16,076 |  |  | 58,101 |  |
| Total(5) | $ | 1,488,706 |  |  | $ | 582,613 |  |  | $ | 108,809 |  |  | $ | 729,818 |  |  | $ | 67,466 |  |

[0000936395-20-000042:mdna:151]
(1) Interest on the New 2025 Term Loan and payments due under the interest rate swaps is variable and is calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 15 and 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-20-000042:mdna:152]
(2) This represents total minimum lease payments subject to operating lease accounting. For more information on our operating leases, see Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-20-000042:mdna:153]
(3) Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations.

[0000936395-20-000042:mdna:154]
(4) This represents the total minimum lease payments subject to finance lease accounting. For more information, see Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-20-000042:mdna:155]
(5) As of October 31, 2020, we also had $9.6 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated.

[0000936395-20-000042:mdna:156]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending on the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2020 (in thousands):

[0000936395-20-000042:mdna:157]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 82,971 |  |  | $ | 35,330 |  |  | $ | 24,464 |  |  | $ | 11,089 |  |  | $ | 12,088 |  |

[0000936395-20-000042:mdna:158]
Off-Balance Sheet Arrangements

[0000936395-20-000042:mdna:159]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-20-000042:mdna:160]
Critical Accounting Policies and Estimates

[0000936395-20-000042:mdna:161]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of our estimates could require further

[0000936395-20-000042:mdna:162]
judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-20-000042:mdna:163]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-20-000042:mdna:164]
Revenue Recognition

[0000936395-20-000042:mdna:165]
We recognize revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which we expect to be entitled in exchange for those products or services.

[0000936395-20-000042:mdna:166]
We determine revenue recognition by applying the following five-step approach:

[0000936395-20-000042:mdna:167]
•identification of the contract, or contracts, with a customer;

[0000936395-20-000042:mdna:168]
•identification of the performance obligations in the contract;

[0000936395-20-000042:mdna:169]
•determination of the transaction price;

[0000936395-20-000042:mdna:170]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-20-000042:mdna:171]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0000936395-20-000042:mdna:172]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. We evaluate each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, we consider, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where we deliver the product or services, we are typically the principal and record revenue and costs of goods sold on a gross basis.

[0000936395-20-000042:mdna:173]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Our other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, we have not provided any material financing arrangements to its customers. As a practical expedient, we do not adjust the amount of consideration we will receive for the effects of a significant financing component as we expect, at contract inception, that the period between our transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. We record revenue net of any associated sales taxes.

[0000936395-20-000042:mdna:174]
We recognize revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation and various professional services as the customer receives the benefit over the contract term.

[0000936395-20-000042:mdna:175]
Significant Judgments

[0000936395-20-000042:mdna:176]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-20-000042:mdna:177]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and

[0000936395-20-000042:mdna:178]
other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-20-000042:mdna:179]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-20-000042:mdna:180]
Our total deferred revenue for products was $17.5 million and $27.4 million as of October 31, 2020 and November 2, 2019, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $140.8 million and $129.5 million as of October 31, 2020 and November 2, 2019, respectively.

[0000936395-20-000042:mdna:181]
Business Combinations

[0000936395-20-000042:mdna:182]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur that may affect the accuracy or validity of such estimates. During fiscal 2018, we completed the Packet Design acquisition for a purchase price of $41.1 million and the DonRiver acquisition for a purchase price of $54.2 million, including a contingent consideration component. During fiscal 2020, we completed the Centina acquisition for a purchase price of $34.0 million. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions and the three-year earn-out arrangement in connection with the DonRiver acquisition.

[0000936395-20-000042:mdna:183]
Share-Based Compensation

[0000936395-20-000042:mdna:184]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-20-000042:mdna:185]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 23 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2020, total unrecognized compensation expense was $111.9 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.47 years.

[0000936395-20-000042:mdna:186]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-20-000042:mdna:187]
Reserve for Inventory Obsolescence

[0000936395-20-000042:mdna:188]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-20-000042:mdna:189]
We recorded charges for excess and obsolete inventory of $24.7 million, $28.1 million and $30.6 million in fiscal 2020, 2019 and 2018, respectively. Our inventory, net of allowance for excess and obsolescence, was $344.4 million and $345.0 million as of October 31, 2020 and November 2, 2019, respectively.

[0000936395-20-000042:mdna:190]
Allowance for Doubtful Accounts Receivable

[0000936395-20-000042:mdna:191]
Our allowance for doubtful accounts receivable is based on management’s assessment, on a specific identification basis, of the collectability of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from them. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer’s financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations.

[0000936395-20-000042:mdna:192]
Our accounts receivable, net of allowance for doubtful accounts, was $719.4 million and $724.9 million as of October 31, 2020 and November 2, 2019, respectively. Our allowance for doubtful accounts was $10.6 million and $20.1 million as of October 31, 2020 and November 2, 2019, respectively. The reduction in our allowance for doubtful accounts as of October 31, 2020 compared to November 2, 2019 is primarily due to the final settlement from a significant asset impairment of $12.2 million for a trade receivable related to a single customer in the APAC region recorded in fiscal 2017.

[0000936395-20-000042:mdna:193]
Goodwill

[0000936395-20-000042:mdna:194]
Our goodwill was generated from the acquisitions of (i) Cyan during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion during fiscal 2016, (iii) Packet Design on July 2, 2018, (iv) DonRiver on October 1, 2018, and (v) Centina on November 2, 2019. The goodwill from these acquisitions is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-20-000042:mdna:195]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 31, 2020 and November 2, 2019, the goodwill balance was $310.8 million and $297.9 million, respectively. There were no goodwill impairments resulting from our fiscal 2020 and 2019 impairment tests and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 13 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-20-000042:mdna:196]
Long-lived Assets

[0000936395-20-000042:mdna:197]
Our long-lived assets include equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares. As of October 31, 2020 and November 2, 2019 these assets totaled $488.1 million and $455.1 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-20-000042:mdna:198]
Deferred Tax Assets

[0000936395-20-000042:mdna:199]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-20-000042:mdna:200]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The valuation allowance balances at October 31, 2020 and November 2, 2019 were $151.4 million and $136.0 million, respectively. The corresponding net deferred tax assets were $647.8 million and $714.9 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For further discussion, see Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-20-000042:mdna:201]
Warranty

[0000936395-20-000042:mdna:202]
Our liability for product warranties, included in other accrued liabilities, was $49.9 million and $48.5 million as of October 31, 2020 and November 2, 2019, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $22.4 million, $23.1 million and $21.0 million for fiscal 2020, 2019 and 2018 respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-20-000042:mdna:203]
Effects of Recent Accounting Pronouncements

[0000936395-20-000042:mdna:204]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-20-000042:mdna:205]
Unaudited Quarterly Results of Operations

[0000936395-20-000042:mdna:206]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2020. Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we

[0000936395-20-000042:mdna:207]
refer to as “book to revenue”) has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-20-000042:mdna:208]
65

[0000936395-20-000042:mdna:209]
|  | Oct. 31, |  | Aug. 1, |  | May. 2, |  | Feb. 1, |  | Nov. 2, |  | Aug. 3, |  | May. 4, |  | Feb. 2, |
|  | 2020 |  | 2020 |  | 2020 |  | 2020 |  | 2019 |  | 2019 |  | 2019 |  | 2019 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 668,661 |  |  | $ | 819,022 |  |  | $ | 739,892 |  |  | $ | 687,215 |  |  | $ | 820,007 |  |  | $ | 810,588 |  |  | $ | 710,688 |  |  | $ | 642,532 |  |
| Services | 159,819 |  |  | 157,690 |  |  | 154,161 |  |  | 145,697 |  |  | 147,980 |  |  | 150,018 |  |  | 154,323 |  |  | 135,995 |  |
| Total revenue | 828,480 |  |  | 976,712 |  |  | 894,053 |  |  | 832,912 |  |  | 967,987 |  |  | 960,606 |  |  | 865,011 |  |  | 778,527 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 343,413 |  |  | 436,227 |  |  | 405,138 |  |  | 389,013 |  |  | 469,945 |  |  | 454,921 |  |  | 411,050 |  |  | 380,442 |  |
| Services | 80,718 |  |  | 75,804 |  |  | 75,589 |  |  | 73,364 |  |  | 78,346 |  |  | 81,333 |  |  | 79,284 |  |  | 74,744 |  |
| Total costs of goods sold | 424,131 |  |  | 512,031 |  |  | 480,727 |  |  | 462,377 |  |  | 548,291 |  |  | 536,254 |  |  | 490,334 |  |  | 455,186 |  |
| Gross profit | 404,349 |  |  | 464,681 |  |  | 413,326 |  |  | 370,535 |  |  | 419,696 |  |  | 424,352 |  |  | 374,677 |  |  | 323,341 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 137,237 |  |  | 130,221 |  |  | 131,530 |  |  | 130,900 |  |  | 141,657 |  |  | 139,880 |  |  | 137,969 |  |  | 128,633 |  |
| Selling and marketing | 113,382 |  |  | 94,763 |  |  | 101,214 |  |  | 107,066 |  |  | 117,201 |  |  | 104,230 |  |  | 103,502 |  |  | 98,113 |  |
| General and administrative | 43,415 |  |  | 41,635 |  |  | 42,030 |  |  | 42,468 |  |  | 50,307 |  |  | 42,695 |  |  | 42,154 |  |  | 39,243 |  |
| Amortization of intangible assets | 5,851 |  |  | 5,840 |  |  | 5,839 |  |  | 5,853 |  |  | 5,222 |  |  | 5,529 |  |  | 5,529 |  |  | 5,528 |  |
| Acquisition and integration costs (recoveries) | 3,127 |  |  | (2,329) |  |  | 1,414 |  |  | 1,819 |  |  | (735) |  |  | 1,362 |  |  | 1,135 |  |  | 1,608 |  |
| Significant asset impairments and restructuring costs | 7,854 |  |  | 6,515 |  |  | 3,811 |  |  | 4,472 |  |  | 12,842 |  |  | 5,355 |  |  | 4,068 |  |  | 2,273 |  |
| Total operating expenses | 310,866 |  |  | 276,645 |  |  | 285,838 |  |  | 292,578 |  |  | 326,494 |  |  | 299,051 |  |  | 294,357 |  |  | 275,398 |  |
| Income from operations | 93,483 |  |  | 188,036 |  |  | 127,488 |  |  | 77,957 |  |  | 93,202 |  |  | 125,301 |  |  | 80,320 |  |  | 47,943 |  |
| Interest and other income (loss), net | (249) |  |  | 232 |  |  | (2,665) |  |  | 3,646 |  |  | (1,183) |  |  | 1,050 |  |  | (244) |  |  | 4,253 |  |
| Interest expense | (7,395) |  |  | (7,251) |  |  | (7,860) |  |  | (8,815) |  |  | (9,136) |  |  | (9,404) |  |  | (9,471) |  |  | (9,441) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | (646) |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Income before income taxes | 85,839 |  |  | 181,017 |  |  | 116,963 |  |  | 72,142 |  |  | 82,883 |  |  | 116,947 |  |  | 70,605 |  |  | 42,755 |  |
| Provision for income tax | 20,798 |  |  | 38,750 |  |  | 25,308 |  |  | 9,814 |  |  | 2,552 |  |  | 30,198 |  |  | 17,867 |  |  | 9,139 |  |
| Net income | $ | 65,041 |  |  | $ | 142,267 |  |  | $ | 91,655 |  |  | $ | 62,328 |  |  | $ | 80,331 |  |  | $ | 86,749 |  |  | $ | 52,738 |  |  | $ | 33,616 |  |
| Basic net income per common share | $ | 0.42 |  |  | $ | 0.92 |  |  | $ | 0.60 |  |  | $ | 0.40 |  |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.34 |  |  | $ | 0.22 |  |
| Diluted net income per potential common share | $ | 0.42 |  |  | $ | 0.91 |  |  | $ | 0.59 |  |  | $ | 0.40 |  |  | $ | 0.51 |  |  | $ | 0.55 |  |  | $ | 0.33 |  |  | $ | 0.21 |  |
| Weighted average basic common shares outstanding | 154,706 |  | 154,184 |  | 153,858 |  | 154,334 |  | 154,852 |  | 155,488 |  | 156,170 |  | 156,314 |
| Weighted average diluted potential common shares outstanding | 156,563 |  | 156,318 |  | 155,141 |  | 155,738 |  | 156,612 |  | 157,455 |  | 158,289 |  | 158,174 |

[0000936395-20-000042:mdna:210]
66
