# CIEN 10-Q controls and the auditor's report


## item_4_controls

[0000936395-16-000083:item_4_controls:1]
Item 4. Controls and Procedures

[0000936395-16-000083:item_4_controls:2]
Disclosure Controls and Procedures

[0000936395-16-000083:item_4_controls:3]
As of the end of the period covered by this report, we carried out an evaluation under the supervision and with the participation of management, including our Chief Executive Officer and Chief Financial Officer, of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Securities Exchange Act of 1934, as amended). Based upon this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0000936395-16-000083:item_4_controls:4]
Changes in Internal Control over Financial Reporting

[0000936395-16-000083:item_4_controls:5]
There was no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended) during the most recently completed fiscal quarter that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.
