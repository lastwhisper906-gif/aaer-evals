# CIEN 8-K — 0000936395-16-000076 filed 2016-03-03

## item codes, every 8-K on or before 2016-03-09

- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2016-03-09

- none on or before 2016-03-09

## item 2.02 — earnings release, exhibit 99.1

[0000936395-16-000076:8k_2_02:1]
EX-99.1
2
exhibit991-2016q1earningsp.htm
EXHIBIT 99.1

[0000936395-16-000076:8k_2_02:2]
Exhibit

[0000936395-16-000076:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-16-000076:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2016 Financial Results

[0000936395-16-000076:8k_2_02:5]
Delivers 8% adjusted operating margin and $0.18 adjusted EPS

[0000936395-16-000076:8k_2_02:6]
HANOVER, Md. - March 3, 2016 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal first quarter ended January 31, 2016.

[0000936395-16-000076:8k_2_02:7]
For the fiscal first quarter 2016, Ciena reported revenue of $573.1 million as compared to $529.2 million for the fiscal first quarter 2015.

[0000936395-16-000076:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net loss for the fiscal first quarter 2016 was $(11.5) million, or $(0.08) per diluted common share, which compares to a GAAP net loss of $(18.8) million, or $(0.17) per diluted common share, for the fiscal first quarter 2015.

[0000936395-16-000076:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2016 was $25.2 million, or $0.18 per diluted common share, which compares to an adjusted (non-GAAP) net income of $13.6 million, or $0.12 per diluted common share, for the fiscal first quarter 2015.

[0000936395-16-000076:8k_2_02:10]
"We delivered strong first quarter business and financial performance, including 8% adjusted operating margin, highlighted by engagement with a more diverse set of customers," said Gary B. Smith, president and CEO, Ciena. “Despite some recent volatility in the broader macroeconomic environment, the demand drivers for our business remain firmly in place and we are well positioned to translate our market leadership into continued growth and profitability this fiscal year.”

[0000936395-16-000076:8k_2_02:11]
Fiscal First Quarter 2016 Performance Summary

[0000936395-16-000076:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-16-000076:8k_2_02:13]
|  |  | GAAP Results |
|  |  | Q1 |  | Q4 |  | Q1 |  | Period Change |
|  |  | FY 2016 |  | FY 2015 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 573.1 |  |  | $ | 692.0 |  |  | $ | 529.2 |  |  | (17.2 | )% |  | 8.3 | % |
| Gross margin |  | 43.9 | % |  | 43.8 | % |  | 43.5 | % |  | 0.1 | % |  | 0.4 | % |
| Operating expense |  | $ | 240.2 |  |  | $ | 293.6 |  |  | $ | 226.1 |  |  | (18.2 | )% |  | 6.2 | % |
| Operating margin |  | 2.0 | % |  | 1.4 | % |  | 0.8 | % |  | 0.6 | % |  | 1.2 | % |

[0000936395-16-000076:8k_2_02:14]
|  |  | Non-GAAP Results |
|  |  | Q1 |  | Q4 |  | Q1 |  | Period Change |
|  |  | FY 2016 |  | FY 2015 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 573.1 |  |  | $ | 692.0 |  |  | $ | 529.2 |  |  | (17.2 | )% |  | 8.3 | % |
| Adj. gross margin |  | 44.7 | % |  | 44.9 | % |  | 44.1 | % |  | (0.2 | )% |  | 0.6 | % |
| Adj. operating expense |  | $ | 208.4 |  |  | $ | 220.5 |  |  | $ | 197.3 |  |  | (5.5 | )% |  | 5.6 | % |
| Adj. operating margin |  | 8.3 | % |  | 13.0 | % |  | 6.8 | % |  | (4.7 | )% |  | 1.5 | % |

[0000936395-16-000076:8k_2_02:15]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-16-000076:8k_2_02:16]
|  |  | Revenue by Segment |
|  |  | Q1 FY 2016 |  | Q4 FY 2015 |  | Q1 FY 2015 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Networking Platforms |  | $ | 449.5 |  |  | 78.4 |  | $ | 564.7 |  |  | 81.6 |  | $ | 413.9 |  |  | 78.2 |
| Software and Software-Related Services |  | 25.4 |  |  | 4.4 |  | 26.3 |  |  | 3.8 |  | 23.5 |  |  | 4.4 |
| Global Services |  | 98.2 |  |  | 17.2 |  | 101.0 |  |  | 14.6 |  | 91.8 |  |  | 17.4 |
| Total |  | $ | 573.1 |  |  | 100.0 |  | $ | 692.0 |  |  | 100.0 |  | $ | 529.2 |  |  | 100.0 |

[0000936395-16-000076:8k_2_02:17]
Additional Performance Metrics for Fiscal First Quarter 2016

[0000936395-16-000076:8k_2_02:18]
|  |  | Revenue by Geographic Region |
|  |  | Q1 FY 2016 |  | Q4 FY 2015 |  | Q1 FY 2015 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 392.7 |  |  | 68.5 |  | $ | 480.0 |  |  | 69.4 |  | $ | 331.5 |  |  | 62.6 |
| Europe, Middle East and Africa |  | 80.7 |  |  | 14.1 |  | 94.0 |  |  | 13.6 |  | 111.0 |  |  | 21.0 |
| Caribbean and Latin America |  | 43.8 |  |  | 7.6 |  | 45.7 |  |  | 6.6 |  | 42.8 |  |  | 8.1 |
| Asia Pacific |  | 55.9 |  |  | 9.8 |  | 72.3 |  |  | 10.4 |  | 43.9 |  |  | 8.3 |
| Total |  | $ | 573.1 |  |  | 100.0 |  | $ | 692.0 |  |  | 100.0 |  | $ | 529.2 |  |  | 100.0 |

[0000936395-16-000076:8k_2_02:19]
| • | U.S. customers contributed 63.7% of total revenue |

[0000936395-16-000076:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 22% of total revenue |

[0000936395-16-000076:8k_2_02:21]
| • | Cash and investments totaled $995.4 million |

[0000936395-16-000076:8k_2_02:22]
| • | Cash flow from operations totaled $15.0 million |

[0000936395-16-000076:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 75 |

[0000936395-16-000076:8k_2_02:24]
| • | Accounts receivable balance was $480.4 million |

[0000936395-16-000076:8k_2_02:25]
| • | Inventories totaled $205.7 million, including: |

[0000936395-16-000076:8k_2_02:26]
| ◦ | Raw materials: $51.9 million |

[0000936395-16-000076:8k_2_02:27]
| ◦ | Work in process: $13.4 million |

[0000936395-16-000076:8k_2_02:28]
| ◦ | Finished goods: $118.0 million |

[0000936395-16-000076:8k_2_02:29]
| ◦ | Deferred cost of sales: $76.4 million |

[0000936395-16-000076:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(54.0) million |

[0000936395-16-000076:8k_2_02:31]
| • | Product inventory turns were 5.1 |

[0000936395-16-000076:8k_2_02:32]
| • | Headcount totaled 5,363 |

[0000936395-16-000076:8k_2_02:33]
Business Outlook for Fiscal Second Quarter 2016

[0000936395-16-000076:8k_2_02:34]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-16-000076:8k_2_02:35]
Ciena expects fiscal second quarter 2016 financial performance to include:

[0000936395-16-000076:8k_2_02:36]
| • | Revenue in the range of $615 to $645 million |

[0000936395-16-000076:8k_2_02:37]
| • | Adjusted (non-GAAP) gross margin in the mid-40s percentage range |

[0000936395-16-000076:8k_2_02:38]
| • | Adjusted (non-GAAP) operating expense of approximately $225 million |

[0000936395-16-000076:8k_2_02:39]
Live Web Broadcast of Unaudited Fiscal First Quarter 2016 Results

[0000936395-16-000076:8k_2_02:40]
Ciena will host a discussion of its unaudited fiscal first quarter 2016 results with investors and financial analysts today, Thursday, March 3, 2016 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-16-000076:8k_2_02:41]
Notes to Investors

[0000936395-16-000076:8k_2_02:42]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered strong first quarter business and financial performance, including 8% adjusted operating margin, highlighted by engagement with a more diverse set of customers"; “Despite some recent volatility in the broader macroeconomic environment, the demand drivers for our business remain firmly in place and we are well positioned to translate our market leadership into continued growth and profitability this fiscal year”; "Ciena expects fiscal second quarter 2016 financial performance to include: Revenue in the range of $615 to $645 million; Adjusted (non-GAAP) gross margin in the mid-40s percentage range; Adjusted (non-GAAP) operating expense of approximately $225 million."

[0000936395-16-000076:8k_2_02:43]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-K, which Ciena filed with the Securities and Exchange Commission on December 21, 2015. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-16-000076:8k_2_02:44]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-16-000076:8k_2_02:45]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-16-000076:8k_2_02:46]
CIENA CORPORATION

[0000936395-16-000076:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-16-000076:8k_2_02:48]
(in thousands, except per share data)

[0000936395-16-000076:8k_2_02:49]
(unaudited)

[0000936395-16-000076:8k_2_02:50]
|  | Three Months Ended January 31, |
|  | 2016 |  | 2015 |
| Revenue: |  |  |  |
| Products | $ | 457,589 |  |  | $ | 422,315 |  |
| Services | 115,526 |  |  | 106,847 |  |
| Total revenue | 573,115 |  |  | 529,162 |  |
| Cost of goods sold: |  |  |  |
| Products | 260,482 |  |  | 236,548 |  |
| Services | 61,183 |  |  | 62,319 |  |
| Total cost of goods sold | 321,665 |  |  | 298,867 |  |
| Gross profit | 251,450 |  |  | 230,295 |  |
| Operating expenses: |  |  |  |
| Research and development | 108,046 |  |  | 100,761 |  |
| Selling and marketing | 82,478 |  |  | 76,712 |  |
| General and administrative | 31,142 |  |  | 29,553 |  |
| Acquisition and integration costs | 1,299 |  |  | — |  |
| Amortization of intangible assets | 16,862 |  |  | 11,019 |  |
| Restructuring costs | 384 |  |  | 8,085 |  |
| Total operating expenses | 240,211 |  |  | 226,130 |  |
| Income from operations | 11,239 |  |  | 4,165 |  |
| Interest and other income (loss), net | (8,776 | ) |  | (8,233 | ) |
| Interest expense | (12,710 | ) |  | (13,661 | ) |
| Loss before income taxes | (10,247 | ) |  | (17,729 | ) |
| Provision for income taxes | 1,299 |  |  | 1,050 |  |
| Net loss | $ | (11,546 | ) |  | $ | (18,779 | ) |
| Net Loss per Common Share |  |  |  |
| Basic net loss per common share | $ | (0.08 | ) |  | $ | (0.17 | ) |
| Diluted net loss per potential common share | $ | (0.08 | ) |  | $ | (0.17 | ) |
| Weighted average basic common shares outstanding | 136,675 |  |  | 107,773 |  |
| Weighted average dilutive potential common shares outstanding | 136,675 |  |  | 107,773 |  |

[0000936395-16-000076:8k_2_02:51]
CIENA CORPORATION

[0000936395-16-000076:8k_2_02:52]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-16-000076:8k_2_02:53]
(in thousands, except share data)

[0000936395-16-000076:8k_2_02:54]
(unaudited)

[0000936395-16-000076:8k_2_02:55]
|  | January 31, 2016 |  | October 31, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 660,321 |  |  | $ | 790,971 |  |
| Short-term investments | 210,010 |  |  | 135,107 |  |
| Accounts receivable, net | 480,382 |  |  | 550,792 |  |
| Inventories | 205,664 |  |  | 191,162 |  |
| Prepaid expenses and other | 194,643 |  |  | 196,178 |  |
| Total current assets | 1,751,020 |  |  | 1,864,210 |  |
| Long-term investments | 125,060 |  |  | 95,105 |  |
| Equipment, building, furniture and fixtures, net | 199,561 |  |  | 191,973 |  |
| Goodwill | 256,434 |  |  | 256,434 |  |
| Other intangible assets, net | 182,167 |  |  | 202,673 |  |
| Other long-term assets | 75,073 |  |  | 84,656 |  |
| Total assets | $ | 2,589,315 |  |  | $ | 2,695,051 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 183,852 |  |  | $ | 222,140 |  |
| Accrued liabilities | 262,213 |  |  | 316,283 |  |
| Deferred revenue | 106,664 |  |  | 126,111 |  |
| Current portion of long-term debt | 2,500 |  |  | 2,500 |  |
| Total current liabilities | 555,229 |  |  | 667,034 |  |
| Long-term deferred revenue | 67,027 |  |  | 62,962 |  |
| Other long-term obligations | 81,716 |  |  | 72,540 |  |
| Long-term debt, net | 1,258,316 |  |  | 1,271,639 |  |
| Total liabilities | $1,962,288 |  | $2,074,175 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 137,436,562 and 135,612,217 shares issued and outstanding | 1,374 |  |  | 1,356 |  |
| Additional paid-in capital | 6,663,765 |  |  | 6,640,436 |  |
| Accumulated other comprehensive loss | (27,776 | ) |  | (22,126 | ) |
| Accumulated deficit | (6,010,336 | ) |  | (5,998,790 | ) |
| Total stockholders’ equity (deficit) | 627,027 |  |  | 620,876 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 2,589,315 |  |  | $ | 2,695,051 |  |

[0000936395-16-000076:8k_2_02:56]
CIENA CORPORATION

[0000936395-16-000076:8k_2_02:57]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-16-000076:8k_2_02:58]
(in thousands)

[0000936395-16-000076:8k_2_02:59]
(unaudited)

[0000936395-16-000076:8k_2_02:60]
|  | Three Months Ended January 31, |
|  | 2016 |  | 2015 |
| Cash flows provided by operating activities: |  |  |  |
| Net loss | $ | (11,546 | ) |  | $ | (18,779 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 14,449 |  |  | 13,772 |  |
| Share-based compensation costs | 14,477 |  |  | 10,807 |  |
| Amortization of intangible assets | 20,506 |  |  | 13,219 |  |
| Provision for inventory excess and obsolescence | 7,016 |  |  | 5,787 |  |
| Provision for warranty | 4,971 |  |  | 2,293 |  |
| Other | 11,087 |  |  | (10,598 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 63,332 |  |  | (1,218 | ) |
| Inventories | (22,134 | ) |  | 7,097 |  |
| Prepaid expenses and other | 6,761 |  |  | (11,536 | ) |
| Accounts payable, accruals and other obligations | (80,014 | ) |  | 2,210 |  |
| Deferred revenue | (13,925 | ) |  | 9,084 |  |
| Net cash provided by operating activities | 14,980 |  |  | 22,138 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (28,873 | ) |  | (11,194 | ) |
| Purchase of available for sale securities | (134,869 | ) |  | (50,085 | ) |
| Proceeds from maturities of available for sale securities | 30,000 |  |  | 40,000 |  |
| Settlement of foreign currency forward contracts, net | (295 | ) |  | 9,314 |  |
| Net cash used in investing activities | (134,037 | ) |  | (11,965 | ) |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Payment of long term debt | (14,639 | ) |  | (625 | ) |
| Payment for debt and equity issuance costs | (797 | ) |  | (60 | ) |
| Payment of capital lease obligations | (1,627 | ) |  | (2,993 | ) |
| Proceeds from issuance of common stock | 8,870 |  |  | 8,302 |  |
| Net cash provided by (used in) financing activities | (8,193 | ) |  | 4,624 |  |
| Effect of exchange rate changes on cash and cash equivalents | (3,400 | ) |  | (2,794 | ) |
| Net increase (decrease) in cash and cash equivalents | (130,650 | ) |  | 12,003 |  |
| Cash and cash equivalents at beginning of period | 790,971 |  |  | 586,720 |  |
| Cash and cash equivalents at end of period | $ | 660,321 |  |  | $ | 598,723 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 9,556 |  |  | $ | 8,754 |  |
| Cash paid during the period for income taxes, net | $ | 3,702 |  |  | $ | 2,894 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 8,782 |  |  | $ | 3,270 |  |
| Debt issuance costs in accrued liabilities | $ | 190 |  |  | $ | 187 |  |
| Equipment acquired under capital lease | $ | 1,219 |  |  | $ | — |  |
| Construction in progress subject to build-to-suit lease | $ | 11,522 |  |  | $ | — |  |

[0000936395-16-000076:8k_2_02:61]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |  |  |
|  |  | Three Months Ended January 31, |
|  |  | 2016 |  | 2015 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 251,450 |  |  | $ | 230,295 |  |
| Share-based compensation-products |  | 571 |  |  | 487 |  |
| Share-based compensation-services |  | 592 |  |  | 519 |  |
| Amortization of intangible assets |  | 3,438 |  |  | 2,200 |  |
| Total adjustments related to gross profit |  | 4,601 |  |  | 3,206 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 256,051 |  |  | $ | 233,501 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 44.7 | % |  | 44.1 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 240,211 |  |  | $ | 226,130 |  |
| Share-based compensation-research and development |  | 3,428 |  |  | 2,167 |  |
| Share-based compensation-sales and marketing |  | 4,735 |  |  | 3,659 |  |
| Share-based compensation-general and administrative |  | 5,129 |  |  | 3,919 |  |
| Acquisition and integration costs |  | 1,299 |  |  | — |  |
| Amortization of intangible assets |  | 16,862 |  |  | 11,019 |  |
| Restructuring costs |  | 384 |  |  | 8,085 |  |
| Total adjustments related to operating expense |  | 31,837 |  |  | 28,849 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 208,374 |  |  | $ | 197,281 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 11,239 |  |  | $ | 4,165 |  |
| Total adjustments related to gross profit |  | 4,601 |  |  | 3,206 |  |
| Total adjustments related to operating expense |  | 31,837 |  |  | 28,849 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 47,677 |  |  | $ | 36,220 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 8.3 | % |  | 6.8 | % |
| Net Income Reconciliation |  |  |  |  |
| GAAP net loss |  | $ | (11,546 | ) |  | $ | (18,779 | ) |
| Total adjustments related to gross profit |  | 4,601 |  |  | 3,206 |  |
| Total adjustments related to operating expense |  | 31,837 |  |  | 28,849 |  |
| Non-cash gain associated with the conversion of convertible notes |  | (106 | ) |  | — |  |
| Non-cash interest expense |  | 441 |  |  | 361 |  |
| Adjusted (non-GAAP) net income |  | $ | 25,227 |  |  | $ | 13,637 |  |
| Weighted average basic common shares outstanding |  | 136,675 |  |  | 107,773 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 151,408 |  |  | 121,896 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net loss per common share |  | $ | (0.08 | ) |  | $ | (0.17 | ) |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.18 |  |  | $ | 0.12 |  |

[0000936395-16-000076:8k_2_02:62]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2016 includes 1.8 million shares underlying certain stock options and restricted stock units and 12.9 million shares underlying Ciena's 0.875% convertible senior notes. |

[0000936395-16-000076:8k_2_02:63]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2015 includes 1.0 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-16-000076:8k_2_02:64]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2016 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-16-000076:8k_2_02:65]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the fiscal first quarter of 2015 requires adding back interest expense of approximately approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000076:8k_2_02:66]
* * *

[0000936395-16-000076:8k_2_02:67]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-16-000076:8k_2_02:68]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-16-000076:8k_2_02:69]
| • | Acquisition and integration costs - consist of expenses for financial, legal and accounting advisors, associated with our acquisitions of Cyan on August 3, 2015 and TeraXion on February 1, 2016. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-16-000076:8k_2_02:70]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-16-000076:8k_2_02:71]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-16-000076:8k_2_02:72]
| • | Non-cash gain associated with the conversion of convertible notes - an infrequent gain related to the repurchase and early extinguishment of a portion of Ciena's 0.875% senior convertible notes due June 15, 2017 during the first quarter of fiscal 2016. |

[0000936395-16-000076:8k_2_02:73]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |
