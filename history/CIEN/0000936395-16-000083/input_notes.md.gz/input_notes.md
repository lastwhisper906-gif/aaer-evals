# CIEN notes — 0000936395-16-000083


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-16-000083:notes:1]
ABL CREDIT FACILITY

[0000936395-16-000083:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-16-000083:notes:3]
On January 8, 2016, Ciena amended the ABL Credit Facility to, among other things:

[0000936395-16-000083:notes:4]
| • | increase the total commitment from $200 million to $250 million, of which $200 million is available for issuances of letters of credit; |

[0000936395-16-000083:notes:5]
| • | extend the maturity date from December 31, 2016 to December 31, 2020, provided an earlier maturity date would apply in the event that Ciena and its subsidiaries are unable to satisfy a minimum liquidity test 90 days prior to the maturity date of any debt equal to $100 million or greater; |

[0000936395-16-000083:notes:6]
| • | reduce the minimum aggregate amount of unrestricted cash and cash equivalents that Ciena and its domestic subsidiaries are required to maintain at all times from $150 million to $100 million; and |

[0000936395-16-000083:notes:7]
| • | reduce the interest rate by 25 basis points on borrowings to either (a) LIBOR plus a margin ranging from 125 to 175 basis points (instead of the previous 150 to 200 basis points) or (b) a base rate plus a margin ranging from 25 to 75 basis points (instead of the previous 50 to 100 basis points), in each case with the actual margin determined according to the Ciena’s utilization of the facility. |

[0000936395-16-000083:notes:8]
As of January 31, 2016, letters of credit totaling $64.5 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2016.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-16-000083:notes:9]
[same as prior period, unchanged from 0000936395-15-000053:notes:3]

[0000936395-16-000083:notes:10]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 20 below.

[0000936395-16-000083:notes:11]
[same as prior period, unchanged from 0000936395-15-000053:notes:5]


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-16-000083:notes:12]
[same as prior period, unchanged from 0000936395-15-000053:notes:6]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-16-000083:notes:13]
[same as prior period, unchanged from 0000936395-15-000053:notes:7]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-16-000083:notes:14]
[same as prior period, unchanged from 0000936395-15-000053:notes:8]

[0000936395-16-000083:notes:15]
[same as prior period, unchanged from 0000936395-15-000053:notes:9]

[0000936395-16-000083:notes:16]
|  | January 31, 2016 |  | October 31, 2015 |
| Prepaid VAT and other taxes | $ | 68,881 |  |  | $ | 74,754 |  |
| Product demonstration equipment, net | 48,167 |  |  | 41,611 |  |
| Deferred deployment expense | 27,085 |  |  | 26,193 |  |
| Prepaid expenses | 24,113 |  |  | 25,074 |  |
| Financing receivable | 20,016 |  |  | 19,869 |  |
| Other non-trade receivables | 6,366 |  |  | 8,588 |  |
| Derivative assets | 15 |  |  | 89 |  |
|  | $ | 194,643 |  |  | $ | 196,178 |  |

[0000936395-16-000083:notes:17]
Depreciation of product demonstration equipment was $2.5 million for each of the first three months of fiscal 2015 and 2016.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-16-000083:notes:18]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-16-000083:notes:19]
Term Loan

[0000936395-16-000083:notes:20]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):

[0000936395-16-000083:notes:21]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 246,250 |  |  | $ | 1,002 |  |  | $ | 245,248 |  |

[0000936395-16-000083:notes:22]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-16-000083:notes:23]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,248 |  |  | $ | 245,019 |  |

[0000936395-16-000083:notes:24]
| (1) | Includes unamortized bond discount. |

[0000936395-16-000083:notes:25]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000083:notes:26]
Outstanding Convertible Notes Payable

[0000936395-16-000083:notes:27]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the 0.875% Convertible Senior Notes due June 15,2017, for cash slightly below par.

[0000936395-16-000083:notes:28]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of January 31, 2016:

[0000936395-16-000083:notes:29]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 198,489 |  |  | $ | 12,906 |  |  | $ | 185,583 |  |  | $ | 43,131 |  |

[0000936395-16-000083:notes:30]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of  convertible notes:

[0000936395-16-000083:notes:31]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 479,985 |  |  | 471,285 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 401,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 185,583 |  |  | 225,938 |  |
|  |  | $ | 1,015,568 |  |  | $ | 1,098,411 |  |

[0000936395-16-000083:notes:32]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000083:notes:33]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-16-000083:notes:34]
[same as prior period, unchanged from 0000936395-15-000053:notes:29]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-16-000083:notes:35]
[same as prior period, unchanged from 0000936395-15-000053:notes:30]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-16-000083:notes:36]
COMMITMENTS AND CONTINGENCIES

[0000936395-16-000083:notes:37]
Foreign Tax Contingencies

[0000936395-16-000083:notes:38]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-16-000083:notes:39]
Litigation

[0000936395-16-000083:notes:40]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:

[0000936395-16-000083:notes:41]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

[0000936395-16-000083:notes:42]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

[0000936395-16-000083:notes:43]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

[0000936395-16-000083:notes:44]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

[0000936395-16-000083:notes:45]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

[0000936395-16-000083:notes:46]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss. A briefing schedule for these motions has been set, with briefing to be completed in March 2016.

[0000936395-16-000083:notes:47]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-16-000083:notes:48]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-16-000083:notes:49]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-16-000083:notes:50]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-16-000083:notes:51]
[same as prior period, unchanged from 0000936395-15-000053:notes:49]

[0000936395-16-000083:notes:52]
The following table summarizes the changes in accumulated balances of other comprehensive income (AOCI) for the three months ending January 31, 2016:

[0000936395-16-000083:notes:53]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 22 |  |  | (3,191 | ) |  | (1,120 | ) |  | (2,823 | ) |  | (7,112 | ) |
| Amounts reclassified from AOCI | — |  |  | 671 |  |  | 791 |  |  | — |  |  | 1,462 |  |
| Balance at January 31, 2016 | $ | (56 | ) |  | $ | (2,788 | ) |  | $ | (5,851 | ) |  | $ | (19,081 | ) |  | $ | (27,776 | ) |

[0000936395-16-000083:notes:54]
The following table summarizes the changes in accumulated balances of other comprehensive income AOCI for the three months ending January 31, 2015:

[0000936395-16-000083:notes:55]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income (loss) before reclassifications | 36 |  |  | (5,315 | ) |  | (2,565 | ) |  | (12,248 | ) |  | (20,092 | ) |
| Amounts reclassified from AOCI | — |  |  | 802 |  |  | — |  |  | — |  |  | 802 |  |
| Balance at January 31, 2015 | $ | 107 |  |  | $ | (4,686 | ) |  | $ | (4,648 | ) |  | $ | (24,731 | ) |  | $ | (33,958 | ) |

[0000936395-16-000083:notes:56]
All amounts reclassified from accumulated other comprehensive income related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted "research and development" on the Condensed Consolidated Statements of Operations. All amounts reclassified from accumulated other comprehensive income related to settlement (gains)  losses on forward starting interest swaps designated as cash flow hedges impacted "interest and other income (loss), net" on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-16-000083:notes:57]
[same as prior period, unchanged from 0000936395-15-000053:notes:55]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-16-000083:notes:58]
[same as prior period, unchanged from 0000936395-15-000053:notes:56]

[0000936395-16-000083:notes:59]
|  | January 31, 2016 |  | October 31, 2015 |
| Products | $ | 54,177 |  |  | $ | 66,527 |  |
| Services | 119,514 |  |  | 122,546 |  |
|  | 173,691 |  |  | 189,073 |  |
| Less current portion | (106,664 | ) |  | (126,111 | ) |
| Long-term deferred revenue | $ | 67,027 |  |  | $ | 62,962 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-16-000083:notes:60]
[same as prior period, unchanged from 0000936395-15-000053:notes:58]

[0000936395-16-000083:notes:61]
[same as prior period, unchanged from 0000936395-15-000053:notes:59]

[0000936395-16-000083:notes:62]
As of January 31, 2016 and October 31, 2015, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $50.0 million and $68.1 million as of January 31, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-16-000083:notes:63]
During the first three months of fiscal 2016 and fiscal 2015, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso versus the U.S. Dollar. The notional amount of these contracts was approximately $86.9 million and $146.5 million as of January 31, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-16-000083:notes:64]
[same as prior period, unchanged from 0000936395-15-000053:notes:62]

[0000936395-16-000083:notes:65]
During fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of January 31, 2016 and October 31, 2015 was $246.3 million and $246.9 million, respectively.

[0000936395-16-000083:notes:66]
[same as prior period, unchanged from 0000936395-15-000053:notes:64]

[0000936395-16-000083:notes:67]
[same as prior period, unchanged from 0000936395-15-000053:notes:65]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-16-000083:notes:68]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-16-000083:notes:69]
[same as prior period, unchanged from 0000936395-15-000053:notes:68]

[0000936395-16-000083:notes:70]
[same as prior period, unchanged from 0000936395-15-000053:notes:69]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-16-000083:notes:71]
[same as prior period, unchanged from 0000936395-15-000053:notes:70]

[0000936395-16-000083:notes:72]
Ciena has outstanding equity awards issued under its 2008 Omnibus Incentive Plan, as well as certain legacy equity plans and equity plans assumed as a result of previous acquisitions. In connection with its acquisition of Cyan during the fourth quarter of fiscal 2015, Ciena assumed the Cyan, Inc. 2006 Stock Plan and Cyan, Inc. 2013 Equity Incentive Plan and exchanged Cyan stock options and unvested restricted stock unit awards outstanding thereunder at closing for options to acquire approximately 2.4 million shares of Ciena common stock and 1.0 million Ciena restricted stock units. Ciena grants equity awards under its 2008 Omnibus Incentive Plan (the "2008 Plan") and makes shares of its common stock available for purchase under its Amended and Restated Employee Stock Purchase Plan (the “ESPP”). These plans were approved by stockholders and are described below.

[0000936395-16-000083:notes:73]
2008 Plan

[0000936395-16-000083:notes:74]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of January 31, 2016, approximately 4.1 million shares remained available for issuance under the 2008 Plan.

[0000936395-16-000083:notes:75]
[same as prior period, unchanged from 0000936395-15-000053:notes:74]

[0000936395-16-000083:notes:76]
Outstanding stock option awards to employees are generally subject to service-based vesting conditions and vest incrementally over a four-year period. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-16-000083:notes:77]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2015 | 2,293 |  |  | $ | 24.45 |  |
| Exercised | (140 | ) |  | 8.42 |  |
| Canceled | (69 | ) |  | 36.67 |  |
| Balance at January 31, 2016 | 2,084 |  |  | $ | 25.13 |  |

[0000936395-16-000083:notes:78]
The total intrinsic value of options exercised during the first three months of fiscal 2015 and fiscal 2016 was $0.1 million and $1.7 million, respectively. Ciena did not grant any stock options during the first three months of fiscal 2015 or fiscal 2016.

[0000936395-16-000083:notes:79]
The following table summarizes information with respect to stock options outstanding at January 31, 2016, based on Ciena’s closing stock price on the last trading day of Ciena’s first fiscal quarter of 2016 (shares and intrinsic value in thousands):

[0000936395-16-000083:notes:80]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | January 31, 2016 |  | January 31, 2016 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.05 |  |  | — |  |  | $ | 11.16 |  |  | 315 |  |  | 3.33 |  | $ | 6.65 |  |  | $ | 3,506 |  |  | 314 |  |  | 3.30 |  | $ | 6.63 |  |  | $ | 3,492 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 563 |  |  | 5.59 |  | 13.55 |  |  | 2,378 |  |  | 486 |  |  | 5.35 |  | 13.41 |  |  | 2,121 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 70 |  |  | 5.24 |  | 19.50 |  |  | 2 |  |  | 43 |  |  | 3.40 |  | 20.31 |  |  | — |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 265 |  |  | 1.18 |  | 27.38 |  |  | — |  |  | 263 |  |  | 1.11 |  | 27.40 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 31.43 |  |  | 88 |  |  | 1.59 |  | 29.81 |  |  | — |  |  | 88 |  |  | 1.59 |  | 29.81 |  |  | — |  |
| $ | 31.71 |  |  | — |  |  | $ | 32.55 |  |  | 46 |  |  | 5.77 |  | 32.03 |  |  | — |  |  | 37 |  |  | 5.59 |  | 32.03 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 380 |  |  | 2.22 |  | 35.90 |  |  | — |  |  | 364 |  |  | 2.00 |  | 35.85 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 55.63 |  |  | 357 |  |  | 4.04 |  | 45.64 |  |  | — |  |  | 295 |  |  | 3.34 |  | 45.60 |  |  | — |  |
| $ | 0.05 |  |  | — |  |  | $ | 55.63 |  |  | 2,084 |  |  | 3.63 |  | $ | 25.13 |  |  | $ | 5,886 |  |  | 1,890 |  |  | 3.25 |  | $ | 24.86 |  |  | $ | 5,613 |  |

[0000936395-16-000083:notes:81]
[same as prior period, unchanged from 0000936395-15-000053:notes:80]

[0000936395-16-000083:notes:82]
[same as prior period, unchanged from 0000936395-15-000053:notes:81]

[0000936395-16-000083:notes:83]
[same as prior period, unchanged from 0000936395-15-000053:notes:82]

[0000936395-16-000083:notes:84]
[same as prior period, unchanged from 0000936395-15-000053:notes:83]

[0000936395-16-000083:notes:85]
[same as prior period, unchanged from 0000936395-15-000053:notes:84]

[0000936395-16-000083:notes:86]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2015 | 4,886 |  |  | $ | 20.02 |  |  | $ | 117,951 |  |
| Granted | 1,762 |  |  |  |  |  |
| Vested | (1,188 | ) |  |  |  |  |
| Canceled or forfeited | (96 | ) |  |  |  |  |
| Balance at January 31, 2016 | 5,364 |  |  | $ | 19.96 |  |  | $ | 95,324 |  |

[0000936395-16-000083:notes:87]
The total fair value of restricted stock units that vested and were converted into common stock during the first three months of fiscal 2015 and fiscal 2016 was $14.0 million and $23.9 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first three months of fiscal 2015 and fiscal 2016 was $18.49 and $19.84 respectively.

[0000936395-16-000083:notes:88]
[same as prior period, unchanged from 0000936395-15-000053:notes:87]

[0000936395-16-000083:notes:89]
[same as prior period, unchanged from 0000936395-15-000053:notes:88]

[0000936395-16-000083:notes:90]
[same as prior period, unchanged from 0000936395-15-000053:notes:89]

[0000936395-16-000083:notes:91]
[same as prior period, unchanged from 0000936395-15-000053:notes:90]

[0000936395-16-000083:notes:92]
[same as prior period, unchanged from 0000936395-15-000053:notes:91]

[0000936395-16-000083:notes:93]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP's “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to approximately 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million shares. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-16-000083:notes:94]
During the first three months of fiscal 2016, Ciena issued 0.5 million shares under the ESPP. At January 31, 2016, 6.5 million shares remained available for issuance under the ESPP.

[0000936395-16-000083:notes:95]
[same as prior period, unchanged from 0000936395-15-000053:notes:94]

[0000936395-16-000083:notes:96]
[same as prior period, unchanged from 0000936395-15-000053:notes:95]

[0000936395-16-000083:notes:97]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| Product costs | $ | 571 |  |  | $ | 487 |  |
| Service costs | 592 |  |  | 519 |  |
| Share-based compensation expense included in cost of sales | 1,163 |  |  | 1,006 |  |
| Research and development | 3,428 |  |  | 2,167 |  |
| Sales and marketing | 4,735 |  |  | 3,659 |  |
| General and administrative | 5,129 |  |  | 3,919 |  |
| Acquisition and integration costs | 17 |  |  | — |  |
| Share-based compensation expense included in operating expense | 13,309 |  |  | 9,745 |  |
| Share-based compensation expense capitalized in inventory, net | 5 |  |  | 56 |  |
| Total share-based compensation | $ | 14,477 |  |  | $ | 10,807 |  |

[0000936395-16-000083:notes:98]
As of January 31, 2016, total unrecognized share-based compensation expense related was approximately $93.9 million: (i) $1.8 million, which related to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years; and (ii) $92.1 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-16-000083:notes:99]
[same as prior period, unchanged from 0000936395-15-000053:notes:98]


## us-gaap:EarningsPerShareTextBlock

[0000936395-16-000083:notes:100]
[same as prior period, unchanged from 0000936395-15-000053:notes:99]

[0000936395-16-000083:notes:101]
[same as prior period, unchanged from 0000936395-15-000053:notes:100]

[0000936395-16-000083:notes:102]
|  | Quarter Ended January 31, |
| Numerator | 2016 |  | 2015 |
| Net loss | $ | (11,546 | ) |  | $ | (18,779 | ) |

[0000936395-16-000083:notes:103]
|  | Quarter Ended January 31, |
| Denominator | 2016 |  | 2015 |
| Basic weighted average shares outstanding | 136,675 |  |  | 107,773 |  |
| Dilutive weighted average shares outstanding | 136,675 |  |  | 107,773 |  |

[0000936395-16-000083:notes:104]
|  | Quarter Ended January 31, |
| EPS | 2016 |  | 2015 |
| Basic EPS | $ | (0.08 | ) |  | $ | (0.17 | ) |
| Diluted EPS | $ | (0.08 | ) |  | $ | (0.17 | ) |

[0000936395-16-000083:notes:105]
[same as prior period, unchanged from 0000936395-15-000053:notes:104]

[0000936395-16-000083:notes:106]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| Shares underlying stock options and restricted stock units | 3,565 |  |  | 3,899 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | — |  |  | 9,198 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 12,912 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,355 |  |  | 17,355 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 43,030 |  |  | 52,758 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-16-000083:notes:107]
[same as prior period, unchanged from 0000936395-15-000053:notes:106]

[0000936395-16-000083:notes:108]
|  | January 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 509,365 |  |  | $ | — |  |  | $ | — |  |  | $ | 509,365 |  |
| U.S. government obligations | — |  |  | 305,094 |  |  | — |  |  | 305,094 |  |
| Commercial paper | — |  |  | 74,958 |  |  | — |  |  | 74,958 |  |
| Foreign currency forward contracts | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Total assets measured at fair value | $ | 509,365 |  |  | $ | 380,067 |  |  | $ | — |  |  | $ | 889,432 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,607 |  |  | $ | — |  |  | $ | 3,607 |  |
| Forward starting interest rate swap | — |  |  | 5,851 |  |  | — |  |  | 5,851 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,458 |  |  | $ | — |  |  | $ | 9,458 |  |

[0000936395-16-000083:notes:109]
|  | October 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 642,073 |  |  | $ | — |  |  | $ | — |  |  | $ | 642,073 |  |
| U.S. government obligations | — |  |  | 205,223 |  |  | — |  |  | 205,223 |  |
| Commercial paper | — |  |  | 74,983 |  |  | — |  |  | 74,983 |  |
| Foreign currency forward contracts | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Total assets measured at fair value | $ | 642,073 |  |  | $ | 280,295 |  |  | $ | — |  |  | $ | 922,368 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 512 |  |  | $ | — |  |  | $ | 512 |  |
| Forward starting interest rate swap | — |  |  | 5,522 |  |  | — |  |  | 5,522 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,034 |  |  | $ | — |  |  | $ | 6,034 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-16-000083:notes:110]
[same as prior period, unchanged from 0000936395-15-000053:notes:109]

[0000936395-16-000083:notes:111]
|  | January 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 509,365 |  |  | $ | 44,982 |  |  | $ | — |  |  | $ | 554,347 |  |
| Short-term investments | — |  |  | 210,010 |  |  | — |  |  | 210,010 |  |
| Prepaid expenses and other | — |  |  | 15 |  |  | — |  |  | 15 |  |
| Long-term investments | — |  |  | 125,060 |  |  | — |  |  | 125,060 |  |
| Total assets measured at fair value | $ | 509,365 |  |  | $ | 380,067 |  |  | $ | — |  |  | $ | 889,432 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,607 |  |  | $ | — |  |  | $ | 3,607 |  |
| Other long-term obligations | — |  |  | 5,851 |  |  | — |  |  | 5,851 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,458 |  |  | $ | — |  |  | $ | 9,458 |  |

[0000936395-16-000083:notes:112]
|  | October 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 642,073 |  |  | $ | 49,994 |  |  | $ | — |  |  | $ | 692,067 |  |
| Short-term investments | — |  |  | 135,107 |  |  | — |  |  | 135,107 |  |
| Prepaid expenses and other | — |  |  | 89 |  |  | — |  |  | 89 |  |
| Long-term investments | — |  |  | 95,105 |  |  | — |  |  | 95,105 |  |
| Total assets measured at fair value | $ | 642,073 |  |  | $ | 280,295 |  |  | $ | — |  |  | $ | 922,368 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 512 |  |  | $ | — |  |  | $ | 512 |  |
| Other long-term obligations | — |  |  | 5,522 |  |  | — |  |  | 5,522 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,034 |  |  | $ | — |  |  | $ | 6,034 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-16-000083:notes:113]
[same as prior period, unchanged from 0000936395-15-000053:notes:112]

[0000936395-16-000083:notes:114]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-16-000083:notes:115]
[same as prior period, unchanged from 0000936395-15-000053:notes:113]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-16-000083:notes:116]
GOODWILL

[0000936395-16-000083:notes:117]
Ciena's goodwill was generated from the acquisition of Cyan, Inc. ("Cyan") and is primarily related to expected synergies. The following table presents the goodwill allocated to Ciena's reportable segments as of the dates indicated (in thousands):

[0000936395-16-000083:notes:118]
|  |  | Balance at October 31, 2015 |  | Acquisitions |  | Impairments |  | Balance at January 31, 2016 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 55,006 |  |  | — |  |  | — |  |  | 55,006 |  |
| Total |  | $ | 256,434 |  |  | $ | — |  |  | $ | — |  |  | $ | 256,434 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-16-000083:notes:119]
[same as prior period, unchanged from 0000936395-15-000053:notes:114]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-16-000083:notes:120]
[same as prior period, unchanged from 0000936395-15-000053:notes:115]

[0000936395-16-000083:notes:121]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2010 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2012), United Kingdom (2013), Canada (2010) and India (2010). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-16-000083:notes:122]
[same as prior period, unchanged from 0000936395-15-000053:notes:117]

[0000936395-16-000083:notes:123]
[same as prior period, unchanged from 0000936395-15-000053:notes:118]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-16-000083:notes:124]
[same as prior period, unchanged from 0000936395-15-000053:notes:119]

[0000936395-16-000083:notes:125]
[same as prior period, unchanged from 0000936395-15-000053:notes:120]

[0000936395-16-000083:notes:126]
|  | January 31, 2016 |  | October 31, 2015 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 506,647 |  |  | $ | (392,081 | ) |  | $ | 114,566 |  |  | $ | 506,647 |  |  | $ | (382,130 | ) |  | $ | 124,517 |  |
| Patents and licenses | 46,538 |  |  | (46,113 | ) |  | 425 |  |  | 46,538 |  |  | (46,072 | ) |  | 466 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 388,621 |  |  | (321,445 | ) |  | 67,176 |  |  | 388,621 |  |  | (310,931 | ) |  | 77,690 |  |
| Total other intangible assets | $ | 941,806 |  |  | $ | (759,639 | ) |  | $ | 182,167 |  |  | $ | 941,806 |  |  | $ | (739,133 | ) |  | $ | 202,673 |  |

[0000936395-16-000083:notes:127]
The aggregate amortization expense of intangible assets was $13.2 million and $20.5 million for the first three months of fiscal 2015 and 2016, respectively.  Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-16-000083:notes:128]
| Period ended October 31, |  |
| 2016 (remaining nine months) | $ | 55,120 |  |
| 2017 | 41,773 |  |
| 2018 | 19,092 |  |
| 2019 | 18,545 |  |
| 2020 | 17,518 |  |
| Thereafter | 30,119 |  |
|  | $ | 182,167 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-16-000083:notes:129]
[same as prior period, unchanged from 0000936395-15-000053:notes:124]

[0000936395-16-000083:notes:130]
[same as prior period, unchanged from 0000936395-15-000053:notes:125]

[0000936395-16-000083:notes:131]
|  | January 31, 2016 |  | October 31, 2015 |
| Raw materials | $ | 51,925 |  |  | $ | 53,082 |  |
| Work-in-process | 13,448 |  |  | 9,120 |  |
| Finished goods | 117,878 |  |  | 125,966 |  |
| Deferred cost of goods sold | 76,371 |  |  | 55,995 |  |
|  | 259,622 |  |  | 244,163 |  |
| Provision for excess and obsolescence | (53,958 | ) |  | (53,001 | ) |
|  | $ | 205,664 |  |  | $ | 191,162 |  |

[0000936395-16-000083:notes:132]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first three months of fiscal 2016, Ciena recorded a provision for excess and obsolescence of $7.0 million, primarily related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-16-000083:notes:133]
[same as prior period, unchanged from 0000936395-15-000053:notes:128]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-16-000083:notes:134]
[same as prior period, unchanged from 0000936395-15-000053:notes:129]

[0000936395-16-000083:notes:135]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-16-000083:notes:136]
The following table summarizes the final legal maturities of debt investments at January 31, 2016 (in thousands):

[0000936395-16-000083:notes:137]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 210,063 |  |  | $ | 210,010 |  |
| Due in 1-2 years | 125,041 |  |  | 125,060 |  |
|  | $ | 335,104 |  |  | $ | 335,070 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-16-000083:notes:138]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-16-000083:notes:139]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-16-000083:notes:140]
|  | January 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 180,087 |  |  | $ | 30 |  |  | (83 | ) |  | $ | 180,034 |  |
| Included in long-term investments | 125,041 |  |  | 117 |  |  | (98 | ) |  | 125,060 |  |
|  | $ | 305,128 |  |  | $ | 147 |  |  | $ | (181 | ) |  | $ | 305,094 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,976 |  |  | — |  |  | — |  |  | $ | 29,976 |  |
|  | $ | 29,976 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,976 |  |

[0000936395-16-000083:notes:141]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 24,989 |  |  | — |  |  | — |  |  | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-16-000083:notes:142]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-16-000083:notes:143]
[same as prior period, unchanged from 0000936395-15-000053:notes:138]

[0000936395-16-000083:notes:144]
As of October 31, 2015, there was one customer that accounted for 10.4% of net accounts receivable. As of January 31, 2016, there was one customer that accounted for 13.2% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $3.0 million and $3.2 million as of October 31, 2015 and January 31, 2016, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-16-000083:notes:145]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-16-000083:notes:146]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect that the impact of adopting this guidance will be material to its Consolidated Financial Statements or disclosures.

[0000936395-16-000083:notes:147]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020, and, at that time, Ciena will adopt the new standard using a modified retrospective approach. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-16-000083:notes:148]
[same as prior period, unchanged from 0000936395-15-000053:notes:143]

[0000936395-16-000083:notes:149]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2015 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2015.

[0000936395-16-000083:notes:150]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2015 and 2016 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.

[0000936395-16-000083:notes:151]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement sub totals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $0.1 million for the three month period ending January 31, 2015.


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-16-000083:notes:152]
[same as prior period, unchanged from 0000936395-15-000053:notes:146]

[0000936395-16-000083:notes:153]
|  | January 31, 2016 |  | October 31, 2015 |
| Construction liability | $ | 28,989 |  |  | $ | 18,663 |  |
| Capital lease obligations | 13,639 |  |  | 13,794 |  |
| Income tax liability | 12,164 |  |  | 13,308 |  |
| Deferred tenant allowance | 9,557 |  |  | 9,807 |  |
| Straight-line rent | 6,479 |  |  | 6,237 |  |
| Forward starting interest rate swap | 5,851 |  |  | 5,522 |  |
| Other | 5,037 |  |  | 5,209 |  |
|  | $ | 81,716 |  |  | $ | 72,540 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-16-000083:notes:154]
[same as prior period, unchanged from 0000936395-15-000053:notes:148]

[0000936395-16-000083:notes:155]
[same as prior period, unchanged from 0000936395-15-000053:notes:149]

[0000936395-16-000083:notes:156]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| Interest income | $ | 686 |  |  | $ | 218 |  |
| Loss on non-hedge designated foreign currency forward contracts | (4,614 | ) |  | (4,350 | ) |
| Foreign currency exchange loss | (4,377 | ) |  | (3,652 | ) |
| Other | (471 | ) |  | (449 | ) |
| Interest and other income (loss), net | $ | (8,776 | ) |  | $ | (8,233 | ) |

[0000936395-16-000083:notes:157]
Ciena Corporation, as the U.S. parent entity, uses the U.S. dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first three months of fiscal 2015 and fiscal 2016, Ciena recorded $3.7 million and $4.4 million in foreign currency exchange losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first three months of fiscal 2015 and fiscal 2016, Ciena recorded losses of $4.4 million and $4.6 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-16-000083:notes:158]
[same as prior period, unchanged from 0000936395-15-000053:notes:151]

[0000936395-16-000083:notes:159]
[same as prior period, unchanged from 0000936395-15-000053:notes:152]

[0000936395-16-000083:notes:160]
|  | January 31, 2016 |  | October 31, 2015 |
| Equipment, furniture and fixtures | $ | 404,844 |  |  | $ | 404,935 |  |
| Building subject to capital lease | 12,598 |  |  | 13,459 |  |
| Construction in progress subject to build-to-suit lease | 28,989 |  |  | 18,663 |  |
| Leasehold improvements | 49,948 |  |  | 49,196 |  |
|  | 496,379 |  |  | 486,253 |  |
| Accumulated depreciation and amortization | (296,818 | ) |  | (294,280 | ) |
|  | $ | 199,561 |  |  | $ | 191,973 |  |

[0000936395-16-000083:notes:161]
During fiscal 2014, Ciena entered into a lease agreement to lease an office building located in Ottawa, Canada. During fiscal 2015, Ciena gained access to a portion of the building and recorded a capital lease asset and liability.

[0000936395-16-000083:notes:162]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of January 31, 2016, there were $29.0 million in costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful life or the lease term.

[0000936395-16-000083:notes:163]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $11.3 million and $11.9 million for the first three months of fiscal 2015 and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-16-000083:notes:164]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

[0000936395-16-000083:notes:165]
[same as prior period, unchanged from 0000936395-15-000053:notes:158]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-16-000083:notes:166]
[same as prior period, unchanged from 0000936395-15-000053:notes:159]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-16-000083:notes:167]
The table below (in thousands) sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net loss during the respective periods indicated:

[0000936395-16-000083:notes:168]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| Segment profit (loss): |  |  |  |
| Networking Platforms | $ | 106,982 |  |  | $ | 95,074 |  |
| Software and Software-Related Services | (3,574 | ) |  | 2,588 |  |
| Global Services | 39,996 |  |  | 31,872 |  |
| Total segment profit | 143,404 |  |  | 129,534 |  |
| Less: Non-performance operating expenses |  |  |  |
| Selling and marketing | 82,478 |  |  | 76,712 |  |
| General and administrative | 31,142 |  |  | 29,553 |  |
| Acquisition and integration costs | 1,299 |  |  | — |  |
| Amortization of intangible assets | 16,862 |  |  | 11,019 |  |
| Restructuring costs | 384 |  |  | 8,085 |  |
| Add: Other non-performance financial items |  |  |  |
| Interest expense and other income (loss), net | (21,486 | ) |  | (21,894 | ) |
| Less: Provision for income taxes | 1,299 |  |  | 1,050 |  |
| Consolidated net loss | $ | (11,546 | ) |  | $ | (18,779 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-16-000083:notes:169]
[same as prior period, unchanged from 0000936395-15-000053:notes:162]

[0000936395-16-000083:notes:170]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| Revenue: |  |  |  |
| Networking Platforms | $ | 449,510 |  |  | $ | 413,882 |  |
| Software and Software-Related Services | 25,426 |  |  | 23,528 |  |
| Global Services | 98,179 |  |  | 91,752 |  |
| Consolidated revenue | $ | 573,115 |  |  | $ | 529,162 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-16-000083:notes:171]
[same as prior period, unchanged from 0000936395-15-000053:notes:164]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-16-000083:notes:172]
[same as prior period, unchanged from 0000936395-15-000053:notes:165]

[0000936395-16-000083:notes:173]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2016 (in thousands):

[0000936395-16-000083:notes:174]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 393 |  |  | — |  |  | 393 |  |
| Adjustments to previous estimates | — |  |  | (9 | ) |  | (9 | ) |
| Cash payments | (613 | ) |  | (148 | ) |  | (761 | ) |
| Balance at January 31, 2016 | $ | 371 |  |  | $ | 531 |  |  | $ | 902 |  |
| Current restructuring liabilities | $ | 371 |  |  | $ | 336 |  |  | $ | 707 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 195 |  |  | $ | 195 |  |

[0000936395-16-000083:notes:175]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2015 (in thousands):

[0000936395-16-000083:notes:176]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,081 |  | (a) | 4 |  |  | 8,085 |  |
| Cash payments | (4,768 | ) |  | (206 | ) |  | (4,974 | ) |
| Balance at January 31, 2015 | $ | 3,494 |  |  | $ | 932 |  |  | $ | 4,426 |  |
| Current restructuring liabilities | $ | 3,494 |  |  | $ | 446 |  |  | $ | 3,940 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 486 |  |  | $ | 486 |  |

[0000936395-16-000083:notes:177]
[same as prior period, unchanged from 0000936395-15-000053:notes:168]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-16-000083:notes:178]
[same as prior period, unchanged from 0000936395-15-000053:notes:171]

[0000936395-16-000083:notes:179]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the three months ended January 31, 2015 and January 31, 2016 was 1.0% and 0.6%, respectively.

[0000936395-16-000083:notes:180]
[same as prior period, unchanged from 0000936395-15-000053:notes:173]

[0000936395-16-000083:notes:181]
[same as prior period, unchanged from 0000936395-15-000053:notes:174]

[0000936395-16-000083:notes:182]
[same as prior period, unchanged from 0000936395-15-000053:notes:175]

[0000936395-16-000083:notes:183]
[same as prior period, unchanged from 0000936395-15-000053:notes:176]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-16-000083:notes:184]
[same as prior period, unchanged from 0000936395-15-000053:notes:177]

[0000936395-16-000083:notes:185]
|  | January 31, 2016 |  | October 31, 2015 |
| Compensation, payroll related tax and benefits | $ | 63,860 |  |  | $ | 109,466 |  |
| Warranty | 56,636 |  |  | 56,654 |  |
| Vacation | 32,963 |  |  | 34,189 |  |
| Capital lease obligations | 3,784 |  |  | 4,923 |  |
| Interest payable | 5,656 |  |  | 5,389 |  |
| Other | 99,314 |  |  | 105,662 |  |
|  | $ | 262,213 |  |  | $ | 316,283 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-16-000083:notes:186]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-16-000083:notes:187]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of January 31, 2016 (in thousands):

[0000936395-16-000083:notes:188]
| Period ended October 31, |  |
| 2016 (remaining nine months) | $ | 4,328 |  |
| 2017 | 1,884 |  |
| 2018 | 1,547 |  |
| 2019 | 1,547 |  |
| 2020 | 1,357 |  |
| Thereafter | 17,263 |  |
| Net minimum capital lease payments | 27,926 |  |
| Less: Amount representing interest | (10,503 | ) |
| Present value of minimum lease payments | 17,423 |  |
| Less: Current portion of present value of minimum lease payments | (3,784 | ) |
| Long-term portion of present value of minimum lease payments | $ | 13,639 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-16-000083:notes:189]
[same as prior period, unchanged from 0000936395-15-000053:notes:182]

[0000936395-16-000083:notes:190]
|  | January 31, 2016 |  | October 31, 2015 |
| Maintenance spares, net | $ | 56,217 |  |  | $ | 55,259 |  |
| Deferred debt issuance costs, net | 10,722 |  |  | 10,820 |  |
| Financing receivable | — |  |  | 10,107 |  |
| Other | 8,134 |  |  | 8,470 |  |
|  | $ | 75,073 |  |  | $ | 84,656 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-16-000083:notes:191]
[same as prior period, unchanged from 0000936395-15-000053:notes:184]

[0000936395-16-000083:notes:192]
| Three months ended | Beginning |  |  |  |  |  | Ending |
| January 31, | Balance |  | Provisions |  | Settlements |  | Balance |
| 2015 | $ | 55,997 |  |  | 2,293 |  |  | (4,908 | ) |  | $ | 53,382 |  |
| 2016 | $ | 56,654 |  |  | 4,971 |  |  | (4,989 | ) |  | $ | 56,636 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-16-000083:notes:193]
[same as prior period, unchanged from 0000936395-15-000053:notes:186]

[0000936395-16-000083:notes:194]
|  | Quarter Ended January 31, |
|  | 2016 |  | 2015 |
| North America | $ | 392,704 |  |  | $ | 331,535 |  |
| EMEA | 80,722 |  |  | 111,006 |  |
| CALA | 43,810 |  |  | 42,742 |  |
| APAC | 55,879 |  |  | 43,879 |  |
| Total | $ | 573,115 |  |  | $ | 529,162 |  |

[0000936395-16-000083:notes:195]
[same as prior period, unchanged from 0000936395-15-000053:notes:188]

[0000936395-16-000083:notes:196]
|  | January 31, 2016 |  | October 31, 2015 |
| United States | $ | 92,052 |  |  | $ | 96,292 |  |
| Canada | 96,665 |  |  | 84,318 |  |
| Other International | 10,844 |  |  | 11,363 |  |
| Total | $ | 199,561 |  |  | $ | 191,973 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-16-000083:notes:197]
[same as prior period, unchanged from 0000936395-15-000053:notes:190]

[0000936395-16-000083:notes:198]
[same as prior period, unchanged from 0000936395-15-000053:notes:191]

[0000936395-16-000083:notes:199]
During the first quarter of fiscal 2016, in connection with the creation of a new Chief Operating Officer organization, Ciena reorganized its internal organizational structure, the management of its business, and the reporting of its operating segments. This resulted in three new operating segments: Networking Platforms, Software and Software-Related Services, and Global Services. Ciena’s previous Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form the Networking Platforms segment under a single operating segment manager. Ciena's previous Software and Services operating segment was reorganized into two separate operating segments; (i) Software and Software-Related Services, and (ii) Global Services. Ciena's segment revenue and segment profit (loss) for fiscal 2015 have been restated to reflect the new operating segments adopted in fiscal 2016. The following describes each of the newly reorganized operating segments:

[0000936395-16-000083:notes:200]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical, Packet Networking and Optical Transport product lines. |

[0000936395-16-000083:notes:201]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include the Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000083:notes:202]
| ◦ | Packet Networking — includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. |

[0000936395-16-000083:notes:203]
| ◦ | Optical Transport — includes the 4200 Advanced Services Platform, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. Ciena's Optical Transport products have either been previously discontinued, or, are expected to be discontinued during fiscal 2016, reflecting network operators' transition toward next-generation converged network architectures. |

[0000936395-16-000083:notes:204]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations.

[0000936395-16-000083:notes:205]
| • | Software and Software-Related Services reflects sales of Ciena’s network virtualization, management, control and orchestration software solutions and software-related services, including subscription, installation, support, and consulting services. |

[0000936395-16-000083:notes:206]
| ◦ | This segment includes Ciena’s element and network management solutions and planning tools, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. |

[0000936395-16-000083:notes:207]
| ◦ | This segment includes Ciena's Blue Planet network virtualization, service orchestration and network management software platform, including the multi-domain service orchestration (MDSO), network function virtualization (NFV) management and orchestration (NFV MANO), and Management and Control Platform (MCP), and Ciena's SDN Multilayer WAN Controller and its related applications. |

[0000936395-16-000083:notes:208]
Revenue from the software platforms portion of this segment is included in product revenue on the Condensed Consolidated Statement of Operations. Revenue from software-related services is included in services revenue on the Condensed Consolidated Statement of Operations.

[0000936395-16-000083:notes:209]
| • | Global Services reflects sales of a broad range of Ciena’s services for consulting and network design, installation and deployment, maintenance support and training activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-16-000083:notes:210]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2016, equipment, building, furniture and fixtures totaling $199.6 million primarily supported asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supported Ciena's unallocated selling and general and administrative activities. As of January 31, 2016, $94.5 million of Ciena's intangible assets were assigned to Ciena's Networking Platforms segment and $87.7 million of Ciena's intangible assets were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of January 31, 2016, all of the maintenance spares, totaling $56.2 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-16-000083:notes:211]
[same as prior period, unchanged from 0000936395-15-000053:notes:198]

[0000936395-16-000083:notes:212]
Segment Profit (Loss)

[0000936395-16-000083:notes:213]
Segment profit (loss) is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; acquisition and integration costs; amortization of intangible assets; restructuring costs; interest and other income (loss), net; interest expense; and provisions for income taxes.

[0000936395-16-000083:notes:214]
[same as prior period, unchanged from 0000936395-15-000053:notes:201]

[0000936395-16-000083:notes:215]
[same as prior period, unchanged from 0000936395-15-000053:notes:202]

[0000936395-16-000083:notes:216]
North America includes $297.7 million and $365.2 million of United States revenue for fiscal quarters ended January 31, 2015 and 2016, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-16-000083:notes:217]
The following table reflects Ciena's geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-16-000083:notes:218]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal quarters ended January 31, 2015 and 2016 with  total revenue of $116.6 million and $126.6 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-16-000083:notes:219]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. As of the first quarter of fiscal 2016, Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-16-000083:notes:220]
[same as prior period, unchanged from 0000936395-15-000053:notes:207]

[0000936395-16-000083:notes:221]
Business Combinations

[0000936395-16-000083:notes:222]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-16-000083:notes:223]
[same as prior period, unchanged from 0000936395-15-000053:notes:208]

[0000936395-16-000083:notes:224]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-16-000083:notes:225]
[same as prior period, unchanged from 0000936395-15-000053:notes:210]

[0000936395-16-000083:notes:226]
[same as prior period, unchanged from 0000936395-15-000053:notes:211]

[0000936395-16-000083:notes:227]
[same as prior period, unchanged from 0000936395-15-000053:notes:212]

[0000936395-16-000083:notes:228]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. As of the first quarter of fiscal 2016, Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 below.

[0000936395-16-000083:notes:229]
Goodwill

[0000936395-16-000083:notes:230]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-16-000083:notes:231]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period.

[0000936395-16-000083:notes:232]
[same as prior period, unchanged from 0000936395-15-000053:notes:214]

[0000936395-16-000083:notes:233]
[same as prior period, unchanged from 0000936395-15-000053:notes:215]

[0000936395-16-000083:notes:234]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 13 below.

[0000936395-16-000083:notes:235]
[same as prior period, unchanged from 0000936395-15-000053:notes:217]

[0000936395-16-000083:notes:236]
[same as prior period, unchanged from 0000936395-15-000053:notes:218]

[0000936395-16-000083:notes:237]
[same as prior period, unchanged from 0000936395-15-000053:notes:219]

[0000936395-16-000083:notes:238]
[same as prior period, unchanged from 0000936395-15-000053:notes:220]

[0000936395-16-000083:notes:239]
[same as prior period, unchanged from 0000936395-15-000053:notes:221]

[0000936395-16-000083:notes:240]
[same as prior period, unchanged from 0000936395-15-000053:notes:222]

[0000936395-16-000083:notes:241]
[same as prior period, unchanged from 0000936395-15-000053:notes:223]

[0000936395-16-000083:notes:242]
[same as prior period, unchanged from 0000936395-15-000053:notes:224]

[0000936395-16-000083:notes:243]
[same as prior period, unchanged from 0000936395-15-000053:notes:225]

[0000936395-16-000083:notes:244]
[same as prior period, unchanged from 0000936395-15-000053:notes:226]

[0000936395-16-000083:notes:245]
[same as prior period, unchanged from 0000936395-15-000053:notes:227]

[0000936395-16-000083:notes:246]
[same as prior period, unchanged from 0000936395-15-000053:notes:229]

[0000936395-16-000083:notes:247]
[same as prior period, unchanged from 0000936395-15-000053:notes:230]

[0000936395-16-000083:notes:248]
[same as prior period, unchanged from 0000936395-15-000053:notes:231]

[0000936395-16-000083:notes:249]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 19 below.

[0000936395-16-000083:notes:250]
[same as prior period, unchanged from 0000936395-15-000053:notes:233]

[0000936395-16-000083:notes:251]
Loss Contingencies

[0000936395-16-000083:notes:252]
[same as prior period, unchanged from 0000936395-15-000053:notes:235]

[0000936395-16-000083:notes:253]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and Term Loan, see Note 16 below.

[0000936395-16-000083:notes:254]
[same as prior period, unchanged from 0000936395-15-000053:notes:237]

[0000936395-16-000083:notes:255]
[same as prior period, unchanged from 0000936395-15-000053:notes:238]

[0000936395-16-000083:notes:256]
[same as prior period, unchanged from 0000936395-15-000053:notes:239]

[0000936395-16-000083:notes:257]
[same as prior period, unchanged from 0000936395-15-000053:notes:240]

[0000936395-16-000083:notes:258]
[same as prior period, unchanged from 0000936395-15-000053:notes:241]

[0000936395-16-000083:notes:259]
[same as prior period, unchanged from 0000936395-15-000053:notes:242]

[0000936395-16-000083:notes:260]
[same as prior period, unchanged from 0000936395-15-000053:notes:243]

[0000936395-16-000083:notes:261]
[same as prior period, unchanged from 0000936395-15-000053:notes:244]

[0000936395-16-000083:notes:262]
[same as prior period, unchanged from 0000936395-15-000053:notes:245]

[0000936395-16-000083:notes:263]
[same as prior period, unchanged from 0000936395-15-000053:notes:246]

[0000936395-16-000083:notes:264]
See Notes 6 and 14 below.

[0000936395-16-000083:notes:265]
[same as prior period, unchanged from 0000936395-15-000053:notes:248]

[0000936395-16-000083:notes:266]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 18 below.

[0000936395-16-000083:notes:267]
[same as prior period, unchanged from 0000936395-15-000053:notes:250]

[0000936395-16-000083:notes:268]
[same as prior period, unchanged from 0000936395-15-000053:notes:251]

[0000936395-16-000083:notes:269]
[same as prior period, unchanged from 0000936395-15-000053:notes:252]


## us-gaap:SubsequentEventsTextBlock

[0000936395-16-000083:notes:270]
SUBSEQUENT EVENTS

[0000936395-16-000083:notes:271]
On January 19, 2016, a wholly-owned subsidiary of Ciena Corporation entered into a definitive agreement with TeraXion, Inc. and its wholly-owned subsidiary to acquire certain high-speed photonics components (HSPC) assets for approximately $32 million in cash. The asset purchase includes, among other things, TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as certain underlying intellectual property. Ciena completed its acquisition of these assets on February 1, 2016.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-16-000083:notes:272]
[same as prior period, unchanged from 0000936395-15-000053:notes:258]

[0000936395-16-000083:notes:273]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 16 below), Term Loan (described in Note 16 below) and  ABL Credit Facility (described in Note 17 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $1.3 million and $1.1 million during the first three months of fiscal 2015 and fiscal 2016, respectively.

[0000936395-16-000083:notes:274]
[same as prior period, unchanged from 0000936395-15-000053:notes:261]
