# CIEN note change history — 0000936395-15-000053 → 0000936395-16-000083


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2016-03-09):
[0000936395-16-000083:note_history:1]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, Merger Sub, and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. The second amended complaint generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The second amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On October 15, 2015, the defendants filed a renewed motion to dismiss. A briefing schedule for these motions has been set, with briefing to be completed in March 2016.

- changed (2016-03-09):
[0000936395-16-000083:note_history:2]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2015-09-09, similarity 0.9074):
[0000936395-15-000053:note_history:2]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-539008. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case. Ciena believes that the consolidated lawsuit is without merit and intend to defend it vigorously.

- removed (2016-03-09):
[0000936395-15-000053:note_history:3]
Ontario Grant

- removed (2016-03-09):
[0000936395-15-000053:note_history:4]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2015, Ciena has received payment for the full amount of the grant. Payments received were recorded as a reduction in research and development expenses.

- removed (2016-03-09):
[0000936395-15-000053:note_history:5]
As of October 31, 2014 and July 31, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of July 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

- removed (2016-03-09):
[0000936395-15-000053:note_history:6]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, plaintiffs filed a verified amended class action complaint, naming Ciena, Merger Sub and the members of Cyan’s board of directors as defendants. The amended complaint alleges, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding, failing to properly value Cyan and obtain the best exchange ratio, ignoring or not protecting against certain conflicts of interest, and failing to disclose all material information necessary for Cyan stockholders to make an informed decision regarding the acquisition. The amended complaint also alleges that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The amended complaint seeks (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger, (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, and (iv) costs including attorneys’ fees and experts’ fees. On August 10, 2015, the defendants filed motions to dismiss the amended complaint. No briefing schedule or hearing date has been set on these motions. Ciena believes that the consolidated lawsuit is without merit, and intends to defend it vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-03-09):
[0000936395-16-000083:note_history:7]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement sub totals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in operating assets and liabilities” of $0.1 million for the three month period ending January 31, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-03-09):
[0000936395-16-000083:note_history:8]
Business Combinations

- added (2016-03-09):
[0000936395-16-000083:note_history:9]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

- changed (2016-03-09):
[0000936395-16-000083:note_history:10]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.
  (was, 2015-09-09, similarity 0.6299):
[0000936395-15-000053:note_history:10]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- changed (2016-03-09):
[0000936395-16-000083:note_history:11]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.
  (was, 2015-09-09, similarity 0.9762):
[0000936395-15-000053:note_history:11]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2016-03-09):
[0000936395-16-000083:note_history:12]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. As of the first quarter of fiscal 2016, Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 below.
  (was, 2015-09-09, similarity 0.8984):
[0000936395-15-000053:note_history:12]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Converged Packet Optical, (ii) Packet Networking, (iii) Optical Transport, and (iv) Software and Services. See Note 19 below.

- added (2016-03-09):
[0000936395-16-000083:note_history:13]
Goodwill

- added (2016-03-09):
[0000936395-16-000083:note_history:14]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

- added (2016-03-09):
[0000936395-16-000083:note_history:15]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period.

- added (2016-03-09):
[0000936395-16-000083:note_history:16]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

- changed (2016-03-09):
[0000936395-16-000083:note_history:17]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the three months ended January 31, 2015 and January 31, 2016 was 1.0% and 0.6%, respectively.
  (was, 2015-09-09, similarity 0.9891):
[0000936395-15-000053:note_history:17]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2014 and July 31, 2015 was 4.3% and 1.9%, respectively.

- changed (2016-03-09):
[0000936395-16-000083:note_history:18]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates.
  (was, 2015-09-09, similarity 0.9762):
[0000936395-15-000053:note_history:18]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 20 below.

- changed (2016-03-09):
[0000936395-16-000083:note_history:19]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2010 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2012), United Kingdom (2013), Canada (2010) and India (2010). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.
  (was, 2015-09-09, similarity 0.997):
[0000936395-15-000053:note_history:19]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2012), United Kingdom (2012), Canada (2010) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

- changed (2016-03-09):
[0000936395-16-000083:note_history:20]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2015-09-09, similarity 0.9751):
[0000936395-15-000053:note_history:20]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.  In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- changed (2016-03-09):
[0000936395-16-000083:note_history:21]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect that the impact of adopting this guidance will be material to its Consolidated Financial Statements or disclosures.
  (was, 2015-09-09, similarity 0.9817):
[0000936395-15-000053:note_history:21]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the its consolidated financial statements and related disclosures.

- added (2016-03-09):
[0000936395-16-000083:note_history:22]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020, and, at that time, Ciena will adopt the new standard using a modified retrospective approach. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- removed (2016-03-09):
[0000936395-15-000053:note_history:23]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

- removed (2016-03-09):
[0000936395-15-000053:note_history:24]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

- removed (2016-03-09):
[0000936395-15-000053:note_history:25]
In August 2014, the FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-09):
[0000936395-16-000083:note_history:26]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):
  (was, 2015-09-09, similarity 0.9918):
[0000936395-15-000053:note_history:26]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):

- changed (2016-03-09):
[0000936395-16-000083:note_history:27]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,248 |  |  | $ | 245,019 |  |
  (was, 2015-09-09, similarity 0.9793):
[0000936395-15-000053:note_history:27]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,351 |  |  | $ | 248,428 |  |

- added (2016-03-09):
[0000936395-16-000083:note_history:28]
During the first quarter of fiscal 2016, Ciena entered into certain private transactions to repurchase $14.1 million of the 0.875% Convertible Senior Notes due June 15,2017, for cash slightly below par.

- changed (2016-03-09):
[0000936395-16-000083:note_history:29]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of January 31, 2016:
  (was, 2015-09-09, similarity 0.9871):
[0000936395-15-000053:note_history:29]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of July 31, 2015:

- changed (2016-03-09):
[0000936395-16-000083:note_history:30]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of  convertible notes:
  (was, 2015-09-09, similarity 0.9643):
[0000936395-15-000053:note_history:30]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

- changed (2016-03-09):
[0000936395-16-000083:note_history:31]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 479,985 |  |  | 471,285 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 401,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 185,583 |  |  | 225,938 |  |
|  |  | $ | 1,015,568 |  |  | $ | 1,098,411 |  |
  (was, 2015-09-09, similarity 0.9875):
[0000936395-15-000053:note_history:31]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 507,813 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 498,750 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 182,910 |  |  | 274,116 |  |
|  |  | $ | 1,032,910 |  |  | $ | 1,280,679 |  |

- removed (2016-03-09):
[0000936395-15-000053:note_history:32]
Maturity of 2015 Convertible Notes

- removed (2016-03-09):
[0000936395-15-000053:note_history:33]
On March 15, 2015, Ciena's outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture, together with certain private exchange transactions conducted by Ciena prior to maturity, approximately $180.6 million in aggregate principal amount of 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, Ciena issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. Ciena repaid in cash approximately $6.9 million in aggregate principal amount of 2015 Notes at maturity.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-09):
[0000936395-16-000083:note_history:34]
|  | January 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 180,087 |  |  | $ | 30 |  |  | (83 | ) |  | $ | 180,034 |  |
| Included in long-term investments | 125,041 |  |  | 117 |  |  | (98 | ) |  | 125,060 |  |
|  | $ | 305,128 |  |  | $ | 147 |  |  | $ | (181 | ) |  | $ | 305,094 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,976 |  |  | — |  |  | — |  |  | $ | 29,976 |  |
|  | $ | 29,976 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,976 |  |
  (was, 2015-09-09, similarity 0.7261):
[0000936395-15-000053:note_history:34]
|  | July 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,041 |  |  | $ | 44 |  |  | — |  |  | $ | 105,085 |  |
| Included in long-term investments | 70,149 |  |  | 12 |  |  | — |  |  | 70,161 |  |
|  | $ | 175,190 |  |  | $ | 56 |  |  | $ | — |  |  | $ | 175,246 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 54,982 |  |  | — |  |  | — |  |  | 54,982 |  |
|  | $ | 54,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 54,982 |  |

- changed (2016-03-09):
[0000936395-16-000083:note_history:35]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 24,989 |  |  | — |  |  | — |  |  | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |
  (was, 2015-09-09, similarity 0.8853):
[0000936395-15-000053:note_history:35]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,994 |  |  | — |  |  | — |  |  | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |

- changed (2016-03-09):
[0000936395-16-000083:note_history:36]
The following table summarizes the final legal maturities of debt investments at January 31, 2016 (in thousands):
  (was, 2015-09-09, similarity 0.9765):
[0000936395-15-000053:note_history:36]
The following table summarizes the final legal maturities of debt investments at July 31, 2015 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-09):
[0000936395-16-000083:note_history:37]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of  convertible notes:
  (was, 2015-09-09, similarity 0.9643):
[0000936395-15-000053:note_history:37]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

- changed (2016-03-09):
[0000936395-16-000083:note_history:38]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 479,985 |  |  | 471,285 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 401,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 185,583 |  |  | 225,938 |  |
|  |  | $ | 1,015,568 |  |  | $ | 1,098,411 |  |
  (was, 2015-09-09, similarity 0.9875):
[0000936395-15-000053:note_history:38]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 507,813 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 498,750 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 182,910 |  |  | 274,116 |  |
|  |  | $ | 1,032,910 |  |  | $ | 1,280,679 |  |

- changed (2016-03-09):
[0000936395-16-000083:note_history:39]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2016 (in thousands):
  (was, 2015-09-09, similarity 0.9811):
[0000936395-15-000053:note_history:39]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):

- changed (2016-03-09):
[0000936395-16-000083:note_history:40]
|  |  | January 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 245,248 |  |  | $ | 245,019 |  |
  (was, 2015-09-09, similarity 0.9793):
[0000936395-15-000053:note_history:40]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,351 |  |  | $ | 248,428 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-03-09):
[0000936395-16-000083:note_history:41]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of January 31, 2016:
  (was, 2015-09-09, similarity 0.9871):
[0000936395-15-000053:note_history:41]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of July 31, 2015:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2016-03-09):
[0000936395-16-000083:note_history:42]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the three months ended January 31, 2015 and January 31, 2016 was 1.0% and 0.6%, respectively.
  (was, 2015-09-09, similarity 0.9891):
[0000936395-15-000053:note_history:42]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2014 and July 31, 2015 was 4.3% and 1.9%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2016-03-09):
[0000936395-16-000083:note_history:43]
On January 19, 2016, a wholly-owned subsidiary of Ciena Corporation entered into a definitive agreement with TeraXion, Inc. and its wholly-owned subsidiary to acquire certain high-speed photonics components (HSPC) assets for approximately $32 million in cash. The asset purchase includes, among other things, TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as certain underlying intellectual property. Ciena completed its acquisition of these assets on February 1, 2016.

- removed (2016-03-09):
[0000936395-15-000053:note_history:44]
Acquisition of Cyan, Inc.

- removed (2016-03-09):
[0000936395-15-000053:note_history:45]
On August 3, 2015, Ciena acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all the then-outstanding Cyan stock options and unvested restricted stock unit awards and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

- removed (2016-03-09):
[0000936395-15-000053:note_history:46]
Upon the closing of the acquisition, Ciena assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of 2019 Notes surrendered for conversion. As of September 3, 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes had surrendered their 2019 notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, Ciena issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

- removed (2016-03-09):
[0000936395-15-000053:note_history:47]
During the first nine months of fiscal 2015, Ciena incurred approximately $3.5 million of acquisition-related costs associated with this transaction. Ciena further expects to incur a number of non-recurring costs associated with the transaction during the remainder of fiscal 2015. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other potential employment-related costs, including payments to certain Cyan executives. Ciena currently expects to incur in total, approximately $25.0 million of such expenses, which includes approximately $7.9 million of non-cash share-based compensation expense. Ciena expects a substantial majority of these acquisition-related costs to be recognized during the fiscal fourth quarter of fiscal 2015.
