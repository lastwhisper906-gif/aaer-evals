# CIEN MD&A — 0000936395-16-000083


## mdna

[0000936395-16-000083:mdna:1]
[same as prior period, unchanged from 0000936395-15-000053:mdna:1]

[0000936395-16-000083:mdna:2]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, adoption of next-generation network technology and software programmability and control of networks; our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; our corporate strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; our acquisition of Cyan, Inc. and its impact on our business and results of operations; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including real estate and IT transitions or initiatives; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-16-000083:mdna:3]
| • | our ability to execute our business and growth strategies; |

[0000936395-16-000083:mdna:4]
| • | fluctuations in our revenue and operating results and our financial results generally; |

[0000936395-16-000083:mdna:5]
| • | the loss of any of our large customers, a significant reduction in their spending, or a material change in their networking or procurement strategies; |

[0000936395-16-000083:mdna:6]
| • | the competitive environment in which we operate and the impact of pricing pressure and recurring market-based price erosion; |

[0000936395-16-000083:mdna:7]
| • | market acceptance of products and services currently under development and delays in product or software development; |

[0000936395-16-000083:mdna:8]
| • | lengthy sales cycles and onerous contract terms with communications service providers, Web-scale providers and other large customers; |

[0000936395-16-000083:mdna:9]
| • | product performance problems and undetected errors; |

[0000936395-16-000083:mdna:10]
| • | our ability to diversify our customer base beyond our traditional customers and broaden the application for our solutions in communications networks; |

[0000936395-16-000083:mdna:11]
| • | the international scale of our operations and fluctuations in currency exchange rates; |

[0000936395-16-000083:mdna:12]
| • | our ability to accurately forecast demand for our products for purposes of inventory purchase practices; |

[0000936395-16-000083:mdna:13]
| • | our ability to enforce our intellectual property rights, and costs we may incur in response to intellectual property right infringement claims made against us; |

[0000936395-16-000083:mdna:14]
| • | the continued availability on commercially reasonable terms of software and other technology under third party licenses; |

[0000936395-16-000083:mdna:15]
| • | failure to maintain the security of confidential, proprietary or otherwise sensitive business information or systems or to protect against cyber security attacks; |

[0000936395-16-000083:mdna:16]
| • | the performance of our third party contract manufacturers; |

[0000936395-16-000083:mdna:17]
| • | changes or disruption in components or supplies provided by third parties, including sole and limited source suppliers; |

[0000936395-16-000083:mdna:18]
| • | our ability to effectively manage our relationships with third party service partners and distributors; |

[0000936395-16-000083:mdna:19]
| • | unanticipated risks and additional obligations in connection with our resale of complementary products or technology of other companies; |

[0000936395-16-000083:mdna:20]
| • | our exposure to the credit risks of our customers and our ability to collect receivables; |

[0000936395-16-000083:mdna:21]
| • | modification or disruption of our internal business processes and information systems; |

[0000936395-16-000083:mdna:22]
| • | the effect of our outstanding indebtedness on our liquidity and business; |

[0000936395-16-000083:mdna:23]
| • | fluctuations in our stock price and our ability to access the capital markets to raise capital; |

[0000936395-16-000083:mdna:24]
| • | unanticipated expenses or disruptions to our operations caused by facilities transitions or restructuring activities; |

[0000936395-16-000083:mdna:25]
| • | inability to attract and retain experienced and qualified personnel; |

[0000936395-16-000083:mdna:26]
| • | disruptions to our operations caused by strategic acquisitions and investments or the inability to achieve the expected benefits and synergies of newly-acquired businesses; |

[0000936395-16-000083:mdna:27]
| • | our ability to integrate Cyan, Inc. into our operations and to use that acquisition to grow our software business; |

[0000936395-16-000083:mdna:28]
| • | changes in, and the impact of, government regulations, including with respect to: the communications industry generally; the business of our customers; the use, import or export of products; and the environment, potential climate change and other social initiatives; |

[0000936395-16-000083:mdna:29]
| • | impairment charges caused by the write-down of goodwill or long-lived assets; |

[0000936395-16-000083:mdna:30]
| • | our ability to maintain effective internal controls over financial reporting and liabilities that result from the inability to comply with corporate governance requirements; and |

[0000936395-16-000083:mdna:31]
| • | adverse results in litigation matters. |

[0000936395-16-000083:mdna:32]
[same as prior period, unchanged from 0000936395-15-000053:mdna:3]

[0000936395-16-000083:mdna:33]
We are a network specialist focused on providing communications networking solutions that enable a wide range of network operators to adopt next-generation architectures. We have optimized our business and solutions to enable network operators to create and deliver the broad array of high-bandwidth services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. In addition to our high-capacity hardware platforms, we offer network management and control software platforms that help network operators simplify and automate their networks and virtualize certain network functions. Our solutions are designed to enable network operators to adopt open, multi-vendor, software-programmable network infrastructures that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to introduce new, revenue-generating services and to reduce network complexity and expense.

[0000936395-16-000083:mdna:34]
Our Converged Packet Optical, Packet Networking and Optical Transport products are used, individually or as part of an integrated solution, by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other network operators across the globe. Our products, which support applications from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Our software solutions are oriented around our Blue Planet software platform, a modular, network virtualization, service orchestration and network management software platform designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of network transformation and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-16-000083:mdna:35]
The rapid proliferation of communications services and devices, together with increased mobility, growth in video, cloud-based services and data center interconnection, have fundamentally affected the bandwidth and service demands placed upon communications networks. As the capacity of their network infrastructures are pressured, many network operators also face a rapidly changing business environment and shifting competitive landscape. Newer market entrants, such as cloud service and over-the-top content providers, are challenging certain traditional business models. Our OPn Architecture, which enables

[0000936395-16-000083:mdna:36]
33

[0000936395-16-000083:mdna:37]
increased network scalability, flexibility and programmability, is designed to meet these challenges. It allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and other network resources. This approach enables highly configurable network infrastructures that can meet the “on-demand” service requirements of both our customers and their end-users. By enhancing software-based management and control, enabling network functions to be provided virtually, and reducing required network elements, our OPn approach optimizes network infrastructures. At the same time, it increases network scale at reduced cost and simplifies the management, deployment and orchestration of multi-vendor hardware and software elements. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the “Strategy” section below.

[0000936395-16-000083:mdna:38]
Our quarterly reports on Form 10-Q, annual reports on Form 10-K, and current reports on Form 8-K filed with the SEC are available through the SEC's website at www.sec.gov or free of charge on our website as soon as reasonably practicable after we file these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the "Investors" section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-16-000083:mdna:39]
[same as prior period, unchanged from 0000936395-15-000053:mdna:18]

[0000936395-16-000083:mdna:40]
The market for communications networking solutions has been subject to significant changes in recent years, including rapid growth in network traffic, increased mobility, and evolving cloud-based service offerings and end-user service demands. These changes have placed significant demands on network infrastructures, challenged the business models of network operators, and altered the overall competitive landscape. Both traditional and emerging network operators are now competing to distinguish their service offerings and to rapidly introduce differentiated, revenue-generating services, while at the same time seeking to manage the costs of their networks and to ensure profitable business models. These dynamics are driving the convergence of network features, functions and layers, the virtualization of certain network functions, and the implementation of solutions that leverage increased software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that network operators and vendors alike will be required to utilize an ecosystem of physical and virtual network resources provided by a variety of third parties, which will further drive increased openness and interoperability of network infrastructures.

[0000936395-16-000083:mdna:41]
Our corporate strategy to capitalize on these market dynamics, promote operational efficiency and drive the profitable growth of our business is set forth, in part, in the “Strategy” section below.

[0000936395-16-000083:mdna:42]
[same as prior period, unchanged from 0000936395-15-000053:mdna:22]

[0000936395-16-000083:mdna:43]
We compete in markets that are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and intense selling efforts to displace incumbent vendors and to capture market share. The markets for our solutions are both highly competitive and fragmented. For example, our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approaches. We expect the competitive landscape in which we operate to remain challenging and dynamic, particularly as we continue to broaden our business. As we expand our solutions offerings, including with Packet Networking solutions such as our 8700 Packetwave Platform and data center interconnect (DCI) solutions such as our Waveserver DCI platform, we expect that our business will increasingly overlap with those of networking solution suppliers - including IP router vendors, data center switch providers, and other suppliers or integrators - whose technology is geared toward different network applications, layers or functions than our traditional competitors. In addition, as we seek adoption of our Blue Planet software platform, and network operator demands for software programmability, management and control increase, we expect to compete more directly with software vendors and information technology vendors or integrators of these solutions. We may also face competition from companies, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware, particularly where a customer's network strategy seeks to emphasize deployment of those product offerings.

[0000936395-16-000083:mdna:44]
Against this competitive landscape, and in order to maintain incumbency with key customers and to secure new opportunities with a diverse set of network operators, we are often required to agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously and may in the future adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also lengthen our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-16-000083:mdna:45]
[same as prior period, unchanged from 0000936395-15-000053:mdna:25]

[0000936395-16-000083:mdna:46]
Our corporate strategy to capitalize on the market dynamics above, promote operational efficiency and drive the profitable growth of our business includes the following initiatives:

[0000936395-16-000083:mdna:47]
Promote our OPn Architecture. We intend to promote our OPn Architecture as the preferred approach for network operators to transition to next-generation networks and address the industry dynamics described above. Our OPn Architecture enables a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Our OPn Architecture leverages this convergence to enable network operators to scale their networks efficiently and cost effectively, while applying advanced software-based network management and control for enhanced programmability. The software-driven aspects of this architecture become increasingly important as we expect network operators increasingly to seek to utilize an open ecosystem that enables multi-vendor and multi-domain network management and virtualized resources required for next-generation network architectures. We see opportunities to drive the evolution of network infrastructures by offering a portfolio of solutions, including our Blue Planet software platform, that can accelerate the realization of our OPn Architecture.

[0000936395-16-000083:mdna:48]
Extend Technology Leaderships and Expand Application of Our Solutions. Our product development strategy is focused on maintaining our technology leadership and expanding our role in customer networks to support service delivery and additional network applications. Our research and development efforts seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce terabit per second and greater transmission speeds. We are also focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnectivity and WAN applications. Separately, we are increasing the scale, density and capability of our packet offerings, reducing power and space requirements, and enabling NFV capabilities for applications in metro networks, user aggregation and data center connectivity. We are also focused on increasing software programmability of networks and enabling network operators to automate and accelerate the creation and delivery of new, cloud-based services. These efforts include investments in our Blue Planet software platform — which is designed to automate, orchestrate, and manage physical network resources and virtualized services across data centers and the WAN —and its integration across our portfolio and with additional third party network resources.

[0000936395-16-000083:mdna:49]
Expand our Role and Reach through Go-to-Market Model. To address the industry dynamics described above, we believe that it is important to secure customer relationships with a diverse set of traditional communications service providers and Web-scale providers, as we expect that their purchasing and network decisions will become increasingly interdependent. As such, our go-to-market model is focused on driving sales growth by diversifying our business with existing customers and penetrating additional customer verticals and international markets.

[0000936395-16-000083:mdna:50]
Our sales and marketing efforts seek to promote increased sales to existing customers, particularly through opportunities that expand our role or the application of our solutions within their network and business. We are pursuing opportunities to increase adoption of our packet access and aggregation solutions, and to secure market share of our Blue Planet software platform, including within our existing customers base. We are also focused on opportunities to support metro aggregation, data center interconnectivity, managed services offerings, cloud-based services, submarine networks, business Ethernet services and mobile backhaul. We intend to leverage our existing customer relationships to increase sales and promote the adoption of our solutions as our customers scale and evolve their networks.

[0000936395-16-000083:mdna:51]
We also intend to target important growth markets, including key customer market segments and geographies. Our go-to-market strategy is focused on further penetrating Internet content providers, data center operators and other emerging network operators that form the “Web-scale” marketplace. We intend to use our direct and indirect sales channels to target and expand our sales with several other market verticals, including cable and multiservice operators, submarine network operators, enterprise customers and in the government, research and education (R&E) markets.  We are also focused on securing additional communications service provider customers in outside of North America, including in high-growth geographies such as Brazil and India. We believe that this is an important part of our strategy and necessary for continued revenue growth. To leverage the geographic reach of our direct sales resources and expand sales into key geographies, we have pursued channel and distribution opportunities, including our strategic relationship with Ericsson, that enable sales through third parties, including service providers, systems integrators and value-added resellers.

[0000936395-16-000083:mdna:52]
Optimize Business to Yield Operating Leverage. We are actively pursuing initiatives to improve our operating margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and supply procurement initiatives to ensure that our product cost model remains ahead of the market-based price erosion that we regularly encounter. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs,

[0000936395-16-000083:mdna:53]
reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-16-000083:mdna:54]
Financial Results and Sequential Comparison

[0000936395-16-000083:mdna:55]
Revenue for the first quarter of fiscal 2016 was $573.1 million, representing a sequential decrease of 17.2% from $692.0 million in the fourth quarter of fiscal 2015. Revenue for the first quarter of fiscal 2016 and fourth quarter of fiscal 2015 includes $40.3 million and $84.4 million, respectively, from products and services relating to the business of Cyan, Inc. ("Cyan"), which we acquired on August 3, 2015. We typically experience reductions in order volume toward the end of the calendar year, as the procurement cycles of some of our customers slow and network deployment activity at service providers is curtailed. This seasonality in our order flows can result in weaker, seasonally affected revenue results in the first quarter of our fiscal year. Revenue-related details reflecting sequential changes from the fourth quarter of fiscal 2015 include:

[0000936395-16-000083:mdna:56]
| • | Product revenue for the first quarter of fiscal 2016 decreased by $116.7 million, primarily reflecting a revenue decrease within our Networking Platforms segment, with product line decreases of $95.1 million in Converged Packet Optical, $15.5 million in Packet Networking, and $4.6 million in Optical Transport. Results for Converged Packet Optical primarily reflect a decrease of $46.9 million in sales of the Z-Series Packet-Optical Platform acquired from Cyan. Sales volume for this platform during the fourth quarter of fiscal 2015 was atypical and primarily benefited from significantly increased sales to Windstream Corporation that we do not expect to recur, as these sales related to the customer's participation in certain U.S. government-supported funding programs. |

[0000936395-16-000083:mdna:57]
| • | Service revenue for the first quarter of fiscal 2016 decreased by $2.2 million. |

[0000936395-16-000083:mdna:58]
| • | North America revenue for the first quarter of fiscal 2016 was $392.7 million, a decrease from $480.0 million in the fourth quarter of fiscal 2015. This primarily reflects a revenue decrease within our Networking Platforms segment of $86.2 million, with product line decreases of $71.9 million in Converged Packet Optical, $10.4 million in Packet Networking and $3.9 million in Optical Transport. |

[0000936395-16-000083:mdna:59]
| • | Europe, Middle East and Africa ("EMEA") revenue for the first quarter of fiscal 2016 was $80.7 million, a decrease from $94.0 million in the fourth quarter of fiscal 2015. This primarily reflects a $9.4 million decrease within our Networking Platforms segment, with a product line decrease of $8.8 million in Converged Packet Optical. EMEA revenue also reflects a revenue decrease of $3.4 million within our Global Services segment. |

[0000936395-16-000083:mdna:60]
| • | Caribbean and Latin America ("CALA") revenue for the first quarter of fiscal 2016 was $43.8 million, a decrease from $45.7 million in the fourth quarter of fiscal 2015. This primarily reflects a $3.6 million decrease within our Global Services segment, partially offset by an increase of $2.0 million within our Networking Platforms segment. |

[0000936395-16-000083:mdna:61]
| • | Asia Pacific ("APAC") revenue for the first quarter of fiscal 2016 was $55.9 million, a decrease from $72.3 million in the fourth quarter of fiscal 2015. This primarily reflects a $21.6 million decrease within our Networking Platforms segment, with product line decreases of $15.0 million in Converged Packet Optical and $6.9 million in Packet Networking. This decrease was partially offset by revenue increases of $4.1 million within our Global Services segment and $1.1 million within our Software and Software-Related Services segment. |

[0000936395-16-000083:mdna:62]
| • | For the first quarter of fiscal 2016, AT&T accounted for 22.1% of total revenue. This compares to 19.1% of total revenue in the fourth quarter of fiscal 2015. |

[0000936395-16-000083:mdna:63]
Gross margin for the first quarter of fiscal 2016 was 43.9%, a slight increase from 43.8% in the fourth quarter of fiscal 2015. The improved gross margin for the first quarter of fiscal 2016 was primarily due to improved services margin.

[0000936395-16-000083:mdna:64]
Operating expense was $240.2 million for the first quarter of fiscal 2016, a decrease from $293.6 million in the fourth quarter of fiscal 2015. First quarter fiscal 2016 operating expense primarily reflects decreases of $20.8 million in acquisition and integration costs and $19.6 million in amortization of intangible assets, related to the Cyan acquisition. Decreased operating expense also reflects decreases of $10.5 million in selling and marketing expense and $2.7 million in general and administrative expense.

[0000936395-16-000083:mdna:65]
Income from operations for the first quarter of fiscal 2016 was $11.2 million, compared to income from operations of $9.4 million during the fourth quarter of fiscal 2015. Our net loss for the first quarter of fiscal 2016 was $11.5 million, or $0.08 per diluted common share. This compares to a net loss of $13.8 million or $0.10 per diluted common share, for the fourth quarter of fiscal 2015.

[0000936395-16-000083:mdna:66]
36

[0000936395-16-000083:mdna:67]
We generated cash from operations of $15.0 million during the first quarter of fiscal 2016, inclusive of our annual payment under our cash incentive compensation plan to employees with respect to fiscal 2015. This compares with $84.6 million of cash generated from operations during the fourth quarter of fiscal 2015. As of January 31, 2016, we had $660.3 million in cash and cash equivalents, $210.0 million of short-term investments in U.S. treasury securities and commercial paper and $125.1 million of long-term investments in U.S. treasury securities. This compares to $791.0 million in cash and cash equivalents, $135.1 million of short-term investments in U.S. treasury securities and commercial paper and $95.1 million of long-term investments in U.S. treasury securities, at October 31, 2015,

[0000936395-16-000083:mdna:68]
As of January 31, 2016, we had 5,363 employees which was an increase from 5,345 at October 31, 2015 and an increase from 5,070 at January 31, 2015.

[0000936395-16-000083:mdna:69]
[same as prior period, unchanged from 0000936395-15-000053:mdna:51]

[0000936395-16-000083:mdna:70]
[same as prior period, unchanged from 0000936395-15-000053:mdna:52]

[0000936395-16-000083:mdna:71]
During the first quarter of fiscal 2016, in connection with the creation of a new Chief Operating Officer organization, Ciena reorganized its internal organizational structure, the management of its business, and the reporting of its operating segments. This resulted in three new operating segments: Networking Platforms, Software and Software-Related Services, and Global Services. Ciena’s previous Converged Packet-Optical, Packet Networking and Optical Transport segments were realigned to form the Networking Platforms segment under a single operating segment manager. Ciena's previous Software and Services operating segment was reorganized into two separate operating segments; (i) Software and Software-Related Services, and (ii) Global Services. Ciena's segment revenue and segment profit (loss) for fiscal 2015 have been restated to reflect the new operating segments adopted in fiscal 2016. See Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-16-000083:mdna:72]
Quarter ended January 31, 2015 compared to the quarter ended January 31, 2016

[0000936395-16-000083:mdna:73]
[same as prior period, unchanged from 0000936395-15-000053:mdna:60]

[0000936395-16-000083:mdna:74]
In recent periods, certain of our service provider customers, including several of our larger customers in North America and EMEA, have taken steps to constrain their capital expenditure budgets. As a result of this measured spending environment, some of our market segments have been adversely impacted and we have experienced lower spending levels on networking equipment from these customers as compared to prior periods. Partly as a result of these dynamics, our sales in EMEA declined 27.3% in the first quarter of fiscal 2016 as compared to the same period a year ago. We expect our total revenue during fiscal 2016 will be adversely affected by anticipated sales declines in EMEA during fiscal 2016 as compared to fiscal 2015. We also expect that our total revenue in fiscal 2016 will be adversely impacted by the recent strengthening of the U.S. Dollar, particularly against the Canadian Dollar, Euro and Brazilian Real. In spite of the conditions above, we were able to grow total revenue in fiscal 2015, in part as a result of our strategy to focus on certain higher growth segments of the network infrastructure market and the shift in spending toward next-generation solutions that enable network operators to monetize their network infrastructures. We also benefited from our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers, cable and multi-service operators, submarine networks, and to secure additional service providers in geographies including Brazil and India. We believe that our results underscore the importance of having established customer relationships with a diverse set of traditional communications service providers and Web-scale providers, especially as their purchasing decisions on open, on-demand network environments become increasingly interdependent.

[0000936395-16-000083:mdna:75]
During the first quarter of fiscal 2016, as compared to the first quarter of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars during the first quarter of fiscal 2016 was adversely impacted by approximately $8.6 million or 1.5% as compared to the first quarter of fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000083:mdna:76]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 449,510 |  |  | 78.5 |  | $ | 413,882 |  |  | 78.3 |  | $ | 35,628 |  |  | 8.6 |
| Software and Software-Related Services | 25,426 |  |  | 4.4 |  | 23,528 |  |  | 4.4 |  | $ | 1,898 |  |  | 8.1 |
| Global Services | 98,179 |  |  | 17.1 |  | 91,752 |  |  | 17.3 |  | 6,427 |  |  | 7.0 |
| Consolidated revenue | $ | 573,115 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | 43,953 |  |  | 8.3 |

[0000936395-16-000083:mdna:77]
[same as prior period, unchanged from 0000936395-15-000053:mdna:63]

[0000936395-16-000083:mdna:78]
[same as prior period, unchanged from 0000936395-15-000053:mdna:64]

[0000936395-16-000083:mdna:79]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:80]
| • | Networking Platforms segment revenue increased, primarily reflecting an increase of $52.6 million in sales of our Converged Packet Optical products, partially offset by decreases of $10.2 million in sales of our Optical Transport products and $6.8 million in sales of our Packet Networking products. |

[0000936395-16-000083:mdna:81]
| ◦ | Converged Packet Optical sales reflect an increase of $35.5 million of our 6500 Packet-Optical Platform, largely driven by network operator demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. Increased revenue from Converged Packet Optical also reflects the addition of $34.1 million relating to the Z-Series Packet-Optical Platform acquired from Cyan and $1.1 million of initial sales of our Waveserver stackable interconnect system. These increases within our Converged Packet Optical product line were partially offset by decreases of $14.9 million in sales of our 5430 Reconfigurable Switching System and $2.8 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System. |

[0000936395-16-000083:mdna:82]
| ◦ | Optical Transport sales, which generally have experienced continued declines, reflect network operators' transition from this product line toward next-generation converged network solutions. As a result, our Optical Transport products have either been previously discontinued, or, are expected to be discontinued during fiscal 2016. |

[0000936395-16-000083:mdna:83]
| ◦ | Packet Networking sales reflect a decrease of $7.3 million in sales of our 3000 family of service delivery switches and service aggregation switches and our 5000 family of service aggregation switches, partially offset by a $1.3 million increase in our 8700 Packetwave Platform sales. |

[0000936395-16-000083:mdna:84]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting an increase of $2.3 million in software-related services. |

[0000936395-16-000083:mdna:85]
| • | Global Services segment revenue increased, primarily reflecting increases of $4.7 million in sales of our installation and deployment services and $1.0 million in maintenance and support services. Global Services segment revenue reflects $6.0 million of services revenue acquired from Cyan. |

[0000936395-16-000083:mdna:86]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as Brazil and India. We believe that this is an important part of our strategy and required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly from quarter to quarter as a result of the factors described elsewhere in this report including "Risk Factors". Among other things, the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-16-000083:mdna:87]
38

[0000936395-16-000083:mdna:88]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 392,704 |  |  | 68.5 |  | $ | 331,535 |  |  | 62.6 |  | $ | 61,169 |  |  | 18.5 |  |
| EMEA | 80,722 |  |  | 14.1 |  | 111,006 |  |  | 21.0 |  | (30,284 | ) |  | (27.3 | ) |
| CALA | 43,810 |  |  | 7.6 |  | 42,742 |  |  | 8.1 |  | 1,068 |  |  | 2.5 |  |
| APAC | 55,879 |  |  | 9.8 |  | 43,879 |  |  | 8.3 |  | 12,000 |  |  | 27.3 |  |
| Total | $ | 573,115 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | 43,953 |  |  | 8.3 |  |

[0000936395-16-000083:mdna:89]
[same as prior period, unchanged from 0000936395-15-000053:mdna:72]

[0000936395-16-000083:mdna:90]
[same as prior period, unchanged from 0000936395-15-000053:mdna:73]

[0000936395-16-000083:mdna:91]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:92]
| • | North America revenue reflects increases of $56.7 million within our Networking Platforms segment, $3.2 million within our Global Services segment, and $1.2 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of $70.3 million of Converged Packet Optical sales, partially offset by decreases of $10.0 million of Packet Networking sales and $3.6 million in Optical Transport sales. Converged Packet Optical sales reflect increases of $44.2 million in sales of our 6500 Packet-Optical Platform, which reflects increased sales to AT&T and other communication service providers, cable and multiservice operators, and enterprise customers, slightly offset by reduced sales to Web-scale providers. Converged Packet Optical also reflects $28.4 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000083:mdna:93]
| • | EMEA revenue primarily reflects a decrease of $29.0 million within our Networking Platform segment. Networking Platform segment revenue reflects a product line decrease of $26.2 million in Converged Packet Optical sales, primarily for the 6500 Packet-Optical Platform. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000083:mdna:94]
| • | CALA revenue primarily reflects an increase of $1.4 million within our Networking Platform segment. CALA revenue benefited from increased sales of $9.0 million to AT&T in Mexico partially offset by lower sales to other service providers primarily in Brazil. |

[0000936395-16-000083:mdna:95]
| • | APAC revenue reflects increases of $6.5 million within our Networking Platform segment, $4.2 million within our Global Services segment and $1.3 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to certain communications service provider customers. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-16-000083:mdna:96]
[same as prior period, unchanged from 0000936395-15-000053:mdna:79]

[0000936395-16-000083:mdna:97]
[same as prior period, unchanged from 0000936395-15-000053:mdna:80]

[0000936395-16-000083:mdna:98]
[same as prior period, unchanged from 0000936395-15-000053:mdna:81]

[0000936395-16-000083:mdna:99]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin products including channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. We regularly encounter pricing pressure and market-based price erosion that can impact our results of operations, and we expect that our gross margins will be subject to fluctuation and significantly dependent upon on our level of success in driving product cost reductions relative to the price reductions that we encounter. Accordingly, our results of operations and gross margin can be adversely affected by the level of pricing pressure and competition that we

[0000936395-16-000083:mdna:100]
encounter in the market. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods.

[0000936395-16-000083:mdna:101]
[same as prior period, unchanged from 0000936395-15-000053:mdna:84]

[0000936395-16-000083:mdna:102]
[same as prior period, unchanged from 0000936395-15-000053:mdna:85]

[0000936395-16-000083:mdna:103]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 573,115 |  |  | 100.0 |  | $ | 529,162 |  |  | 100.0 |  | $ | 43,953 |  |  | 8.3 |
| Total cost of goods sold | 321,665 |  |  | 56.1 |  | 298,867 |  |  | 56.5 |  | 22,798 |  |  | 7.6 |
| Gross profit | $ | 251,450 |  |  | 43.9 |  | $ | 230,295 |  |  | 43.5 |  | $ | 21,155 |  |  | 9.2 |

[0000936395-16-000083:mdna:104]
[same as prior period, unchanged from 0000936395-15-000053:mdna:87]

[0000936395-16-000083:mdna:105]
[same as prior period, unchanged from 0000936395-15-000053:mdna:88]

[0000936395-16-000083:mdna:106]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:107]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 457,589 |  |  | 100.0 |  | $ | 422,315 |  |  | 100.0 |  | $ | 35,274 |  |  | 8.4 |
| Product cost of goods sold | 260,482 |  |  | 56.9 |  | 236,548 |  |  | 56.0 |  | 23,934 |  |  | 10.1 |
| Product gross profit | $ | 197,107 |  |  | 43.1 |  | $ | 185,767 |  |  | 44.0 |  | $ | 11,340 |  |  | 6.1 |

[0000936395-16-000083:mdna:108]
[same as prior period, unchanged from 0000936395-15-000053:mdna:91]

[0000936395-16-000083:mdna:109]
[same as prior period, unchanged from 0000936395-15-000053:mdna:92]

[0000936395-16-000083:mdna:110]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:111]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 115,526 |  |  | 100.0 |  | $ | 106,847 |  |  | 100.0 |  | $ | 8,679 |  |  | 8.1 |  |
| Service cost of goods sold | 61,183 |  |  | 53.0 |  | 62,319 |  |  | 58.3 |  | (1,136 | ) |  | (1.8 | ) |
| Service gross profit | $ | 54,343 |  |  | 47.0 |  | $ | 44,528 |  |  | 41.7 |  | $ | 9,815 |  |  | 22.0 |  |

[0000936395-16-000083:mdna:112]
[same as prior period, unchanged from 0000936395-15-000053:mdna:95]

[0000936395-16-000083:mdna:113]
[same as prior period, unchanged from 0000936395-15-000053:mdna:96]

[0000936395-16-000083:mdna:114]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:115]
[same as prior period, unchanged from 0000936395-15-000053:mdna:98]

[0000936395-16-000083:mdna:116]
| • | Gross profit on products as a percentage of product revenue decreased, as a result of market-based price erosion partially offset by product cost reductions. |

[0000936395-16-000083:mdna:117]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased sales of higher margin software subscription services and improved efficiencies for maintenance, support, installation and deployment services. |

[0000936395-16-000083:mdna:118]
[same as prior period, unchanged from 0000936395-15-000053:mdna:101]

[0000936395-16-000083:mdna:119]
We expect operating expense to increase in fiscal 2016 from the level reported for fiscal 2015, in part due to the additional  personnel and operations related to our acquisition of Cyan during the fourth quarter of fiscal 2015 and our acquisition of the HSPC assets of TeraXion on February 1, 2016. We also expect operating expense to increase in order to fund our research and development initiatives, to provide for investments in the re-engineering of company-wide enterprise resource planning platforms, and to fund the transition of key facilities. In particular, the development of our new facilities and the transition of our operations in Ottawa and India will require significant effort, time and cost.

[0000936395-16-000083:mdna:120]
[same as prior period, unchanged from 0000936395-15-000053:mdna:102]

[0000936395-16-000083:mdna:121]
Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, testing of our products, depreciation expense and third-party consulting costs.

[0000936395-16-000083:mdna:122]
[same as prior period, unchanged from 0000936395-15-000053:mdna:104]

[0000936395-16-000083:mdna:123]
[same as prior period, unchanged from 0000936395-15-000053:mdna:105]

[0000936395-16-000083:mdna:124]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, associated with our acquisition of Cyan on August 3, 2015 and our acquisition of certain high-speed photonics components (HSPC) assets of TeraXion and its wholly-owned subsidiary ("TeraXion") on February 1, 2016.

[0000936395-16-000083:mdna:125]
Amortization of intangible assets primarily reflects the amortization of purchased technology and customer relationships from our acquisitions.

[0000936395-16-000083:mdna:126]
[same as prior period, unchanged from 0000936395-15-000053:mdna:108]

[0000936395-16-000083:mdna:127]
[same as prior period, unchanged from 0000936395-15-000053:mdna:109]

[0000936395-16-000083:mdna:128]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 108,046 |  |  | 18.9 |  | $ | 100,761 |  |  | 19.0 |  | $ | 7,285 |  |  | 7.2 |  |
| Selling and marketing | 82,478 |  |  | 14.4 |  | 76,712 |  |  | 14.5 |  | 5,766 |  |  | 7.5 |  |
| General and administrative | 31,142 |  |  | 5.4 |  | 29,553 |  |  | 5.6 |  | 1,589 |  |  | 5.4 |  |
| Acquisition and integration costs | 1,299 |  |  | 0.2 |  | — |  |  | — |  | 1,299 |  |  | 100.0 |  |
| Amortization of intangible assets | 16,862 |  |  | 2.9 |  | 11,019 |  |  | 2.1 |  | 5,843 |  |  | 53.0 |  |
| Restructuring costs | 384 |  |  | 0.1 |  | 8,085 |  |  | 1.5 |  | (7,701 | ) |  | (95.3 | ) |
| Total operating expenses | $ | 240,211 |  |  | 41.9 |  | $ | 226,130 |  |  | 42.7 |  | $ | 14,081 |  |  | 6.2 |  |

[0000936395-16-000083:mdna:129]
[same as prior period, unchanged from 0000936395-15-000053:mdna:111]

[0000936395-16-000083:mdna:130]
[same as prior period, unchanged from 0000936395-15-000053:mdna:112]

[0000936395-16-000083:mdna:131]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:132]
| • | Research and development expense benefited from $9.3 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $7.3 million. This change reflects increases of $4.9 million in employee and compensation costs, $2.0 million in facilities and information technology costs and $1.0 million in professional services. Research and development expense for fiscal 2016 also reflects a $1.3 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario, due to the maximum funding limit being met in the second quarter of fiscal 2015. These increases were partially offset by a decrease of $2.4 million in prototype expense. |

[0000936395-16-000083:mdna:133]
| • | Selling and marketing expense benefited from $4.0 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, |

[0000936395-16-000083:mdna:134]
selling and marketing expense increased by $5.8 million, primarily reflecting increases of $3.7 million in employee and compensation costs and $1.3 million in professional services.

[0000936395-16-000083:mdna:135]
| • | General and administrative expense benefited from $1.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense increased by $1.6 million, due to increased employee and compensation costs. |

[0000936395-16-000083:mdna:136]
| • | Acquisition and integration costs reflects expense for financial, legal and accounting advisors, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain high-speed photonics components (HSPC) assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-16-000083:mdna:137]
| • | Amortization of intangible assets increased due to expense related to acquired intangible assets from our acquisition of Cyan during fiscal 2015. |

[0000936395-16-000083:mdna:138]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-16-000083:mdna:139]
[same as prior period, unchanged from 0000936395-15-000053:mdna:120]

[0000936395-16-000083:mdna:140]
[same as prior period, unchanged from 0000936395-15-000053:mdna:121]

[0000936395-16-000083:mdna:141]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (8,776 | ) |  | (1.5 | ) |  | $ | (8,233 | ) |  | (1.6 | ) |  | $ | (543 | ) |  | 6.6 |  |
| Interest expense | $ | 12,710 |  |  | 2.2 |  |  | $ | 13,661 |  |  | 2.6 |  |  | $ | (951 | ) |  | (7.0 | ) |
| Provision for income taxes | $ | 1,299 |  |  | 0.2 |  |  | $ | 1,050 |  |  | 0.2 |  |  | $ | 249 |  |  | 23.7 |  |

[0000936395-16-000083:mdna:142]
[same as prior period, unchanged from 0000936395-15-000053:mdna:123]

[0000936395-16-000083:mdna:143]
[same as prior period, unchanged from 0000936395-15-000053:mdna:124]

[0000936395-16-000083:mdna:144]
**    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:145]
| • | Interest and other income (loss), net remained relatively unchanged. During both the first quarter of fiscal 2016 and fiscal 2015, interest and other income (loss), net were adversely impacted by losses in foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-16-000083:mdna:146]
| • | Interest expense decreased, primarily due to a reduction in aggregate of outstanding debt due to the maturity of our outstanding 4.0% Convertible Senior Notes on March 15, 2015. |

[0000936395-16-000083:mdna:147]
| • | Provision for income taxes increased primarily due to foreign tax expense. |

[0000936395-16-000083:mdna:148]
Segment Profit (Loss)

[0000936395-16-000083:mdna:149]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit (loss) for the respective periods:

[0000936395-16-000083:mdna:150]
|  | Quarter Ended January 31, |  |  |  |
|  | 2016 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 106,982 |  |  | $ | 95,074 |  |  | $ | 11,908 |  |  | 12.5 |  |
| Software and Software-Related Services | $ | (3,574 | ) |  | $ | 2,588 |  |  | $ | (6,162 | ) |  | (238.1 | ) |
| Global Services | $ | 39,996 |  |  | $ | 31,872 |  |  | $ | 8,124 |  |  | 25.5 |  |

[0000936395-16-000083:mdna:151]
[same as prior period, unchanged from 0000936395-15-000053:mdna:143]

[0000936395-16-000083:mdna:152]
*    Denotes % change from 2015 to 2016

[0000936395-16-000083:mdna:153]
| • | Networking Platforms segment profit increased, primarily due to increased sales volume from the Z-Series Packet-Optical Platform acquired from Cyan and service provider demand for convergence of high-capacity, coherent 40G |

[0000936395-16-000083:mdna:154]
and 100G network infrastructures with integrated OTN switching and control plane functionality. The increased sales volume was partially offset by reduced gross margin and higher research and development costs.

[0000936395-16-000083:mdna:155]
| • | Software and Software-Related Services segment loss was primarily due to higher research and development costs and lower gross margin from increased amortization of intangibles expense, partially offset by increased sales volume. Higher research and development costs reflect the addition of expenses relating to the development of our Blue Planet software platform. |

[0000936395-16-000083:mdna:156]
| • | Global Services segment profit increased, primarily due to increased gross margin and higher sales volume. The increased gross margin reflects lower costs for maintenance, support, installation and deployment services. |

[0000936395-16-000083:mdna:157]
[same as prior period, unchanged from 0000936395-15-000053:mdna:206]

[0000936395-16-000083:mdna:158]
At January 31, 2016, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-16-000083:mdna:159]
|  | January 31, 2016 |  | October 31, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 660,321 |  |  | $ | 790,971 |  |  | $ | (130,650 | ) |
| Short-term investments in marketable debt securities | 210,010 |  |  | 135,107 |  |  | $ | 74,903 |  |
| Long-term investments in marketable debt securities | 125,060 |  |  | 95,105 |  |  | $ | 29,955 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 995,391 |  |  | $ | 1,021,183 |  |  | $ | (25,792 | ) |

[0000936395-16-000083:mdna:160]
The change in total cash and cash equivalents and investments in marketable debt securities during the first three months of fiscal 2016 was primarily related to the following:

[0000936395-16-000083:mdna:161]
| • | $15.0 million cash generated from operations, consisting of $61.0 million provided by net loss (adjusted for non-cash charges) and $46.0 million used in working capital; |

[0000936395-16-000083:mdna:162]
| • | $28.9 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-16-000083:mdna:163]
| • | $0.3 million used for settlement of foreign currency forward contracts, net; |

[0000936395-16-000083:mdna:164]
| • | $1.6 million used to pay capital lease obligations; |

[0000936395-16-000083:mdna:165]
| • | $14.6 million used for repayment of long-term debt; |

[0000936395-16-000083:mdna:166]
| • | $8.9 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; |

[0000936395-16-000083:mdna:167]
| • | $0.8 million used for payment of debt issuance costs; and |

[0000936395-16-000083:mdna:168]
| • | $3.4 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-16-000083:mdna:169]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of January 31, 2016, letters of credit totaling $64.5 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2016.

[0000936395-16-000083:mdna:170]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-16-000083:mdna:171]
The following sections set forth the components of our $15.0 million of cash generated from operating activities during the first three months of fiscal 2016:

[0000936395-16-000083:mdna:172]
Net loss (adjusted for non-cash charges)

[0000936395-16-000083:mdna:173]
The following table sets forth (in thousands) our net loss (adjusted for non-cash charges) during the period:

[0000936395-16-000083:mdna:174]
|  | Three months ended |
|  | January 31, 2016 |
| Net loss | $ | (11,546 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 14,449 |  |
| Share-based compensation costs | 14,477 |  |
| Amortization of intangible assets | 20,506 |  |
| Provision for inventory excess and obsolescence | 7,016 |  |
| Provision for warranty | 4,971 |  |
| Other | 11,087 |  |
| Net loss (adjusted for non-cash charges) | $ | 60,960 |  |

[0000936395-16-000083:mdna:175]
[same as prior period, unchanged from 0000936395-15-000053:mdna:225]

[0000936395-16-000083:mdna:176]
Our working capital used $46.0 million of cash during the period. The following tables set forth (in thousands) the major components of the reduction in working capital:

[0000936395-16-000083:mdna:177]
|  | Three months ended |
|  | January 31, 2016 |
| Cash provided by accounts receivable | $ | 63,332 |  |
| Cash used in inventories | (22,134 | ) |
| Cash provided by prepaid expenses and other | 6,761 |  |
| Cash used in accounts payable, accruals and other obligations | (80,014 | ) |
| Cash used in deferred revenue | (13,925 | ) |
| Cash used in an increase in working capital | $ | (45,980 | ) |

[0000936395-16-000083:mdna:178]
The $63.3 million of cash provided by accounts receivable during the first three months of fiscal 2016 reflects increased collections and lower sales volume in the first quarter of fiscal 2016 compared to the fourth quarter of fiscal 2015. Our days sales outstanding (DSOs) for the first quarter of fiscal 2016 were 75 days. The $22.1 million of cash used in inventory during the first three months of fiscal 2016 primarily reflects increases in deferred costs of goods sold. Cash provided by prepaid expense and other during the first three months of fiscal 2016 was $6.8 million, primarily reflecting a reduction in financing receivables. The $80.0 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2016 reflects, among other things, the annual payment under our cash incentive compensation plan to employees. The $13.9 million of cash used in deferred revenue during the first three months of fiscal 2016 represents revenue recognized from payments received in prior periods.

[0000936395-16-000083:mdna:179]
Cash Paid for Interest

[0000936395-16-000083:mdna:180]
|  | Three months ended |
|  | January 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 2,176 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | — |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 3,750 |  |
| Term Loan Payable, due July 15, 2019(4) | 2,341 |  |
| Interest rate swap(5) | 791 |  |
| ABL Credit Facility(6) | 498 |  |
| Cash paid during period | $ | 9,556 |  |

[0000936395-16-000083:mdna:181]
44

[0000936395-16-000083:mdna:182]
| (1) | Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. |

[0000936395-16-000083:mdna:183]
| (2) | Interest on our outstanding 3.75% convertible senior notes, due October, 2018, is payable on April 15 and October 15 each year. |

[0000936395-16-000083:mdna:184]
| (3) | Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. |

[0000936395-16-000083:mdna:185]
| (4) | Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. The Term Loan bears interest at LIBOR plus a spread of 300 basis points subject to a minimum LIBOR rate of 0.75%. During the first three months of fiscal 2016, the interest rate on our Term Loan was 3.75%. |

[0000936395-16-000083:mdna:186]
| (5) | Payments on our interest rate swap arrangement are variable and effectively fix the total interest rate under the Term Loan at 5.004% from July 20, 2015 through July 19, 2018. |

[0000936395-16-000083:mdna:187]
| (6) | During the first three months of fiscal 2016, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.5 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-16-000083:mdna:188]
For additional information about our convertible notes and Term Loan, ABL Credit Facility and interest rate swap, see Notes 14, 16 and 17 to our Condensed Consolidated Financial Statements included in in Item 1 of Part I of this report.

[0000936395-16-000083:mdna:189]
[same as prior period, unchanged from 0000936395-15-000053:mdna:250]

[0000936395-16-000083:mdna:190]
The following is a summary of our future minimum payments under contractual obligations as of January 31, 2016 (in thousands):

[0000936395-16-000083:mdna:191]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,047,112 |  |  | $ | — |  |  | $ | 829,985 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on Term Loan | 246,250 |  |  | 1,875 |  |  | 5,000 |  |  | 239,375 |  |  | — |  |
| Interest due on convertible notes | 83,438 |  |  | 25,000 |  |  | 43,438 |  |  | 15,000 |  |  | — |  |
| Interest due on Term Loan (2) | 32,278 |  |  | 9,356 |  |  | 18,401 |  |  | 4,521 |  |  | — |  |
| Payments due under Interest Rate Swap (2) | 7,734 |  |  | 3,128 |  |  | 4,606 |  |  | — |  |  | — |  |
| Operating leases (3) | 140,217 |  |  | 32,806 |  |  | 41,320 |  |  | 21,738 |  |  | 44,353 |  |
| Purchase obligations (4) | 210,529 |  |  | 210,529 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 4,826 |  |  | 3,640 |  |  | 877 |  |  | 309 |  |  | — |  |
| Capital leases— buildings (5) | 119,341 |  |  | 2,015 |  |  | 10,952 |  |  | 14,001 |  |  | 92,373 |  |
| Other obligations | 1,894 |  |  | 1,259 |  |  | 508 |  |  | 127 |  |  | — |  |
| Total (6) | $ | 1,893,619 |  |  | $ | 289,608 |  |  | $ | 955,087 |  |  | $ | 512,198 |  |  | $ | 136,726 |  |

[0000936395-16-000083:mdna:192]
[same as prior period, unchanged from 0000936395-15-000053:mdna:154]

[0000936395-16-000083:mdna:193]
| (1) | Includes the accretion of the principal amount on our outstanding 4.0% convertible senior notes, due December 15, 2020 payable at maturity at a rate of 1.85% per year compounded semi-annually, commencing December 27, 2012. |

[0000936395-16-000083:mdna:194]
| (2) | Interest on the Term Loan and payments due under the Interest Rate Swap are variable and were calculated using the rate in effect on the balance sheet date. For additional information about our Term Loan and the interest rate swap, see Notes 14 and 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-16-000083:mdna:195]
[same as prior period, unchanged from 0000936395-15-000053:mdna:257]

[0000936395-16-000083:mdna:196]
[same as prior period, unchanged from 0000936395-15-000053:mdna:258]

[0000936395-16-000083:mdna:197]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the excepted commencement of the lease term. Does not include variable insurance, taxes, |

[0000936395-16-000083:mdna:198]
maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact.

[0000936395-16-000083:mdna:199]
| (6) | As of January 31, 2016, we also had approximately $12.2 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-16-000083:mdna:200]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of January 31, 2016 (in thousands):

[0000936395-16-000083:mdna:201]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 66,998 |  |  | $ | 31,543 |  |  | $ | 14,665 |  |  | $ | 9,295 |  |  | $ | 11,495 |  |

[0000936395-16-000083:mdna:202]
[same as prior period, unchanged from 0000936395-15-000053:mdna:263]

[0000936395-16-000083:mdna:203]
[same as prior period, unchanged from 0000936395-15-000053:mdna:264]

[0000936395-16-000083:mdna:204]
[same as prior period, unchanged from 0000936395-15-000053:mdna:265]

[0000936395-16-000083:mdna:205]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-16-000083:mdna:206]
[same as prior period, unchanged from 0000936395-15-000053:mdna:267]

[0000936395-16-000083:mdna:207]
[same as prior period, unchanged from 0000936395-15-000053:mdna:268]

[0000936395-16-000083:mdna:208]
[same as prior period, unchanged from 0000936395-15-000053:mdna:269]

[0000936395-16-000083:mdna:209]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the first three months ended January 31, 2015 and January 31, 2016 were 1.0% and 0.6%, respectively.

[0000936395-16-000083:mdna:210]
[same as prior period, unchanged from 0000936395-15-000053:mdna:271]

[0000936395-16-000083:mdna:211]
[same as prior period, unchanged from 0000936395-15-000053:mdna:272]

[0000936395-16-000083:mdna:212]
[same as prior period, unchanged from 0000936395-15-000053:mdna:273]

[0000936395-16-000083:mdna:213]
[same as prior period, unchanged from 0000936395-15-000053:mdna:274]

[0000936395-16-000083:mdna:214]
Our total deferred revenue for products was $66.5 million and $54.2 million as of October 31, 2015 and January 31, 2016, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $122.5 million and $119.5 million as of October 31, 2015 and January 31, 2016, respectively.

[0000936395-16-000083:mdna:215]
[same as prior period, unchanged from 0000936395-15-000053:mdna:276]

[0000936395-16-000083:mdna:216]
[same as prior period, unchanged from 0000936395-15-000053:mdna:277]

[0000936395-16-000083:mdna:217]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 19 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of January 31, 2016, total unrecognized compensation expense was $93.9 million: (i) $1.8 million, which related to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years; and (ii) $92.1 million which related to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.6 years.

[0000936395-16-000083:mdna:218]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-

[0000936395-16-000083:mdna:219]
and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-16-000083:mdna:220]
[same as prior period, unchanged from 0000936395-15-000053:mdna:281]

[0000936395-16-000083:mdna:221]
[same as prior period, unchanged from 0000936395-15-000053:mdna:282]

[0000936395-16-000083:mdna:222]
For fiscal 2016, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2016. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2016 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $13.9 million of expense in the first three months of fiscal 2016 associated with our cash incentive bonus plan for fiscal 2016.

[0000936395-16-000083:mdna:223]
[same as prior period, unchanged from 0000936395-15-000053:mdna:284]

[0000936395-16-000083:mdna:224]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $5.8 million and $7.0 million in the first three months of fiscal 2015 and 2016, respectively. The charges in fiscal 2016 primarily were related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Our inventory net of allowance for excess and obsolescence was $191.2 million and $205.7 million as of October 31, 2015 and January 31, 2016, respectively.

[0000936395-16-000083:mdna:225]
[same as prior period, unchanged from 0000936395-15-000053:mdna:286]

[0000936395-16-000083:mdna:226]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $550.8 million and $480.4 million as of October 31, 2015 and January 31, 2016, respectively. Our allowance for doubtful accounts was $3.0 million and $3.2 million as of October 31, 2015 and January 31, 2016, respectively.

[0000936395-16-000083:mdna:227]
Goodwill

[0000936395-16-000083:mdna:228]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-16-000083:mdna:229]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of the end of first quarter of fiscal 2015, there was no goodwill balance. At the end of first quarter of fiscal 2016, the goodwill balance was $256.4 million as a result of our acquisition of Cyan.

[0000936395-16-000083:mdna:230]
[same as prior period, unchanged from 0000936395-15-000053:mdna:289]

[0000936395-16-000083:mdna:231]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2015 and January 31, 2016, these assets totaled $449.9 million and $437.9 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-16-000083:mdna:232]
[same as prior period, unchanged from 0000936395-15-000053:mdna:291]

[0000936395-16-000083:mdna:233]
As of January 31, 2016, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-16-000083:mdna:234]
[same as prior period, unchanged from 0000936395-15-000053:mdna:293]

[0000936395-16-000083:mdna:235]
Our liability for product warranties, included in other accrued liabilities, was $56.7 million and $56.6 million as of October 31, 2015 and January 31, 2016, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $2.3 million and $5.0 million for the first three months of fiscal 2015 and 2016, respectively. See Note 13 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
