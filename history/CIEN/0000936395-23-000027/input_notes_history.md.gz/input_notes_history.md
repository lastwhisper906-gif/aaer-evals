# CIEN note change history — 0000936395-23-000014 → 0000936395-23-000027


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-06-07):
[0000936395-23-000027:note_history:1]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.
  (was, 2023-03-08, similarity 0.916):
[0000936395-23-000014:note_history:1]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-06-07):
[0000936395-23-000027:note_history:2]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform.
  (was, 2023-03-08, similarity 0.9916):
[0000936395-23-000014:note_history:2]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of Accounting Standards Codification 848 Reference Rate Reform.

- added (2023-06-07):
[0000936395-23-000027:note_history:3]
|  |  | April 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 672,210 |  |  | $ | (767) |  |  | $ | (1,436) |  |  | $ | 670,007 |  |  | $ | 673,010 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:4]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.4 million as of April 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2023-03-08, similarity 0.9838):
[0000936395-23-000014:note_history:4]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.6 million as of January 28, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2023-06-07):
[0000936395-23-000027:note_history:5]
As of April 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-03-08, similarity 0.9814):
[0000936395-23-000014:note_history:5]
As of January 28, 2023, the estimated fair value of the 2025 Term Loan was $670.6 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2023-06-07):
[0000936395-23-000027:note_history:6]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of
  (was, 2023-03-08, similarity 0.7038):
[0000936395-23-000014:note_history:6]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $493.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

- added (2023-06-07):
[0000936395-23-000027:note_history:7]
senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.7 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

- changed (2023-06-07):
[0000936395-23-000027:note_history:8]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):
  (was, 2023-03-08, similarity 0.9339):
[0000936395-23-000014:note_history:8]
The net carrying value of the 2030 Term Loan was comprised of the following for the periods indicated (in thousands):

- changed (2023-06-07):
[0000936395-23-000027:note_history:9]
|  |  | April 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,400) |  |  | $ | (4,667) |  |  | $ | 492,933 |  |  |  |
  (was, 2023-03-08, similarity 0.8732):
[0000936395-23-000014:note_history:9]
|  |  | January 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,491) |  |  | $ | (4,810) |  |  | $ | 492,699 |  |  |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of April 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.2 million during the first six months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2023-03-08, similarity 0.9672):
[0000936395-23-000014:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.8 million as of January 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was minimal during the first three months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2023-06-07):
[0000936395-23-000027:note_history:11]
As of April 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-03-08, similarity 0.9814):
[0000936395-23-000014:note_history:11]
As of January 28, 2023, the estimated fair value of the 2030 Term Loan was $499.4 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2023-06-07):
[0000936395-23-000027:note_history:12]
|  |  | April 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,610) |  |  | $ | 395,390 |  |  | $ | 395,045 |  |  |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:13]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.6 million as of April 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.3 million during the first six months of fiscal 2023 and was $0.2 million during the first six months of fiscal 2022. 
As of April 29, 2023, the estimated fair value of the 2030 Notes was $349.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.

- removed (2023-06-07):
[0000936395-23-000014:note_history:14]
|  |  | January 28, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 673,942 |  |  | $ | (847) |  |  | $ | (1,586) |  |  | $ | 671,509 |  |  | $ | 673,010 |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:15]
|  |  | January 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,783) |  |  | $ | 395,217 |  |  | $ | 395,045 |  |  |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:16]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.8 million as of January 28, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.2 million during the first three months of fiscal 2023 and was minimal during the first three months of fiscal 2022.

- removed (2023-06-07):
[0000936395-23-000014:note_history:17]
As of January 28, 2023, the estimated fair value of the 2030 Notes was $351.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-06-07):
[0000936395-23-000027:note_history:18]
|  | April 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 120,628 |  |  | $ | 39 |  |  | $ | (1,620) |  |  | $ | 119,047 |  |
| Corporate debt securities | 57,707 |  |  | 41 |  |  | (90) |  |  | 57,658 |  |
| Time deposits | 91,454 |  |  | 2 |  |  | (5) |  |  | 91,451 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |
| Included in cash equivalents | $ | 92,455 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,455 |  |
| Included in short-term investments | 152,105 |  |  | 38 |  |  | (1,679) |  |  | 150,464 |  |
| Included in long-term investments | 25,229 |  |  | 44 |  |  | (36) |  |  | 25,237 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:19]
The following table summarizes the final legal maturities of debt investments as of April 29, 2023 (in thousands):
  (was, 2023-03-08, similarity 0.9636):
[0000936395-23-000014:note_history:19]
The following table summarizes the final legal maturities of debt investments as of January 28, 2023 (in thousands):

- removed (2023-06-07):
[0000936395-23-000014:note_history:20]
|  | January 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 89,789 |  |  | $ | — |  |  | $ | (2,473) |  |  | $ | 87,316 |  |
| Corporate debt securities | 16,356 |  |  | 1 |  |  | (7) |  |  | 16,350 |  |
| Time deposits | 41,022 |  |  | — |  |  | — |  |  | 41,022 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |
| Included in cash equivalents | $ | 41,022 |  |  | $ | — |  |  | $ | — |  |  | $ | 41,022 |  |
| Included in short-term investments | 102,900 |  |  | 1 |  |  | (2,477) |  |  | 100,424 |  |
| Included in long-term investments | 3,245 |  |  | — |  |  | (3) |  |  | 3,242 |  |
|  | $ | 147,167 |  |  | $ | 1 |  |  | $ | (2,480) |  |  | $ | 144,688 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-06-07):
[0000936395-23-000027:note_history:21]
|  |  | April 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 672,210 |  |  | $ | (767) |  |  | $ | (1,436) |  |  | $ | 670,007 |  |  | $ | 673,010 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:22]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):
  (was, 2023-03-08, similarity 0.9339):
[0000936395-23-000014:note_history:22]
The net carrying value of the 2030 Term Loan was comprised of the following for the periods indicated (in thousands):

- changed (2023-06-07):
[0000936395-23-000027:note_history:23]
|  |  | April 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,400) |  |  | $ | (4,667) |  |  | $ | 492,933 |  |  |  |
  (was, 2023-03-08, similarity 0.8732):
[0000936395-23-000014:note_history:23]
|  |  | January 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,491) |  |  | $ | (4,810) |  |  | $ | 492,699 |  |  |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:24]
|  |  | April 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,610) |  |  | $ | 395,390 |  |  | $ | 395,045 |  |  |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:25]
|  |  | January 28, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 673,942 |  |  | $ | (847) |  |  | $ | (1,586) |  |  | $ | 671,509 |  |  | $ | 673,010 |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:26]
|  |  | January 28, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,783) |  |  | $ | 395,217 |  |  | $ | 395,045 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-06-07):
[0000936395-23-000027:note_history:27]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2023-03-08, similarity 0.8934):
[0000936395-23-000014:note_history:27]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2023-06-07):
[0000936395-23-000027:note_history:28]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
  (was, 2023-03-08, similarity 0.9949):
[0000936395-23-000014:note_history:28]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:29]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | $ | 773,728 |  |
| Services transferred over time | — |  |  | 47,414 |  |  | 12,845 |  |  | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
  (was, 2023-03-08, similarity 0.9949):
[0000936395-23-000014:note_history:29]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | $ | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:30]
|  | Six Months Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:31]
|  | Six months ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:32]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 794,359 |  |  | $ | 700,840 |  |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |
| EMEA |  | 173,414 |  |  | 145,106 |  |  | 326,218 |  |  | 295,891 |  |
| APAC |  | 164,882 |  |  | 103,281 |  |  | 303,503 |  |  | 201,795 |  |
| Total revenue by geographic distribution |  | $ | 1,132,655 |  |  | $ | 949,227 |  |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |
  (was, 2023-03-08, similarity 0.6924):
[0000936395-23-000014:note_history:32]
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  |  |
| EMEA |  | 152,804 |  |  | 150,785 |  |  |  |  |  |
| APAC |  | 138,621 |  |  | 98,514 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:33]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 123,452 |  |  | n/a |  | $ | 244,779 |  |  | n/a |
| AT&T | n/a |  | 103,189 |  |  | 251,329 |  |  | 214,065 |  |
| Total | $ | 123,452 |  |  | $ | 103,189 |  |  | $ | 496,108 |  |  | $ | 214,065 |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:34]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| AT&T | $ | 149,981 |  |  | $ | 110,876 |  |  |  |  |  |
| Web-scale provider | 121,327 |  |  | n/a |  |  |  |  |
| Total | $ | 271,308 |  |  | $ | 110,876 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-06-07):
[0000936395-23-000027:note_history:35]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2023-03-08, similarity 0.8934):
[0000936395-23-000014:note_history:35]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2023-06-07):
[0000936395-23-000027:note_history:36]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
  (was, 2023-03-08, similarity 0.9949):
[0000936395-23-000014:note_history:36]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:37]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | $ | 773,728 |  |
| Services transferred over time | — |  |  | 47,414 |  |  | 12,845 |  |  | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
  (was, 2023-03-08, similarity 0.9949):
[0000936395-23-000014:note_history:37]
|  | Quarter Ended January 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 540,936 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 540,936 |  |
| Routing and Switching | 85,710 |  |  | — |  |  | — |  |  | — |  |  | 85,710 |  |
| Platform Software and Services | — |  |  | 72,917 |  |  | — |  |  | — |  |  | 72,917 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 21,110 |  |  | — |  |  | 21,110 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,491 |  |  | 72,491 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 40,370 |  |  | 40,370 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,909 |  |  | 10,909 |  |
| Total revenue by product line | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 626,646 |  |  | $ | 29,682 |  |  | $ | 8,774 |  |  | $ | 8,491 |  |  | $ | 673,593 |  |
| Services transferred over time | — |  |  | 43,235 |  |  | 12,336 |  |  | 115,279 |  |  | 170,850 |  |
| Total revenue by timing of revenue recognition | $ | 626,646 |  |  | $ | 72,917 |  |  | $ | 21,110 |  |  | $ | 123,770 |  |  | $ | 844,443 |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:38]
|  | Six Months Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:39]
|  | Six months ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:40]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2023-06-07):
[0000936395-23-000027:note_history:41]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 794,359 |  |  | $ | 700,840 |  |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |
| EMEA |  | 173,414 |  |  | 145,106 |  |  | 326,218 |  |  | 295,891 |  |
| APAC |  | 164,882 |  |  | 103,281 |  |  | 303,503 |  |  | 201,795 |  |
| Total revenue by geographic distribution |  | $ | 1,132,655 |  |  | $ | 949,227 |  |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |
  (was, 2023-03-08, similarity 0.6924):
[0000936395-23-000014:note_history:41]
|  |  | Quarter Ended |  |  |
|  |  | January 28, |  | January 29, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 765,096 |  |  | $ | 595,144 |  |  |  |  |  |
| EMEA |  | 152,804 |  |  | 150,785 |  |  |  |  |  |
| APAC |  | 138,621 |  |  | 98,514 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,056,521 |  |  | $ | 844,443 |  |  |  |  |  |

- added (2023-06-07):
[0000936395-23-000027:note_history:42]
Ciena’s revenue includes $722.6 million and $642.2 million of United States revenue for the second quarter of fiscal 2023 and 2022, respectively. For the six months ended April 29, 2023 and April 30, 2022, United States revenue was $1.4 billion and $1.2 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented in the above table.

- added (2023-06-07):
[0000936395-23-000027:note_history:43]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 123,452 |  |  | n/a |  | $ | 244,779 |  |  | n/a |
| AT&T | n/a |  | 103,189 |  |  | 251,329 |  |  | 214,065 |  |
| Total | $ | 123,452 |  |  | $ | 103,189 |  |  | $ | 496,108 |  |  | $ | 214,065 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:44]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.
  (was, 2023-03-08, similarity 0.9836):
[0000936395-23-000014:note_history:44]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio (“RSP”) components from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.

- changed (2023-06-07):
[0000936395-23-000027:note_history:45]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as
  (was, 2023-03-08, similarity 0.8897):
[0000936395-23-000014:note_history:45]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions.

- added (2023-06-07):
[0000936395-23-000027:note_history:46]
planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2023-06-07):
[0000936395-23-000027:note_history:47]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):
  (was, 2023-03-08, similarity 0.997):
[0000936395-23-000014:note_history:47]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- changed (2023-06-07):
[0000936395-23-000027:note_history:48]
|  |  | Balance at April 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,036,688 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 180,020 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 270,625 |  |  | $ | 200,235 |  |
  (was, 2023-03-08, similarity 0.9746):
[0000936395-23-000014:note_history:48]
|  |  | Balance at January 28, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,054,917 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 148,758 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 231,378 |  |  | $ | 200,235 |  |

- changed (2023-06-07):
[0000936395-23-000027:note_history:49]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 11 below.
  (was, 2023-03-08, similarity 0.9981):
[0000936395-23-000014:note_history:49]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 11 below.

- changed (2023-06-07):
[0000936395-23-000027:note_history:50]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $100.1 million and $82.0 million of revenue during the first six months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 29, 2023 and April 30, 2022.
  (was, 2023-03-08, similarity 0.9162):
[0000936395-23-000014:note_history:50]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $67.9 million and $56.8 million of revenue during the first three months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance at October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 28, 2023 and January 29, 2022.

- changed (2023-06-07):
[0000936395-23-000027:note_history:51]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.6 million and $39.7 million as of April 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $16.2 million and $14.1 million during the first six months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2023-03-08, similarity 0.9811):
[0000936395-23-000014:note_history:51]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $38.2 million and $39.7 million as of January 28, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $7.2 million and $7.0 million during the first three months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2023-06-07):
[0000936395-23-000027:note_history:52]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 29, 2023, the aggregate amount of RPO was $2.4 billion. As of April 29, 2023, Ciena expects approximately 86% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2023-03-08, similarity 0.9698):
[0000936395-23-000014:note_history:52]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 28, 2023, the aggregate amount of RPO was $2.7 billion. As of January 28, 2023, Ciena expects approximately 90% of the RPO to be recognized as revenue within the next 12 months.

- removed (2023-06-07):
[0000936395-23-000014:note_history:53]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- removed (2023-06-07):
[0000936395-23-000014:note_history:54]
Ciena’s revenue includes $693.6 million and $543.5 million of United States revenue for the first quarter of fiscal 2023 and 2022, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- removed (2023-06-07):
[0000936395-23-000014:note_history:55]
|  | Quarter Ended |  |  |
|  | January 28, |  | January 29, |  |  |  |  |
|  | 2023 |  | 2022 |  |  |  |  |
| AT&T | $ | 149,981 |  |  | $ | 110,876 |  |  |  |  |  |
| Web-scale provider | 121,327 |  |  | n/a |  |  |  |  |
| Total | $ | 271,308 |  |  | $ | 110,876 |  |  |  |  |  |

- removed (2023-06-07):
[0000936395-23-000014:note_history:56]
Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2023-06-07):
[0000936395-23-000014:note_history:57]
SUBSEQUENT EVENTS
ABL Credit Facility

- removed (2023-06-07):
[0000936395-23-000014:note_history:58]
On February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300 million, to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.
