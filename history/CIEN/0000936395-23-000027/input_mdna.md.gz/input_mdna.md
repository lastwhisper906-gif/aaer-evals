# CIEN MD&A — 0000936395-23-000027


## mdna

[0000936395-23-000027:mdna:1]
[same as prior period, unchanged from 0000936395-23-000014:mdna:1]

[0000936395-23-000027:mdna:2]
[same as prior period, unchanged from 0000936395-23-000014:mdna:2]

[0000936395-23-000027:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, operational matters including the expansion of manufacturing capacity and accumulation of inventory, business prospects and strategies and other “forward-looking” information. Forward-looking statements may appear throughout this report, including in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors.” In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “would,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” “prepare,” or “continue” or the negative of those words and other comparable words. You should be aware that the forward-looking statements contained in this report are based on our current views and assumptions, and are subject to known and unknown risks, uncertainties, and other factors that may cause actual events or results to differ materially.

[0000936395-23-000027:mdna:4]
[same as prior period, unchanged from 0000936395-23-000014:mdna:4]

[0000936395-23-000027:mdna:5]
[same as prior period, unchanged from 0000936395-23-000014:mdna:5]

[0000936395-23-000027:mdna:6]
We are a networking systems, services, and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that are informed by analytics and intelligence. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Manage, Control and Plan (“MCP”) applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software we also enable complete service lifecycle management automation with productized open source software (OSS) and service assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-23-000027:mdna:7]
[same as prior period, unchanged from 0000936395-23-000014:mdna:7]

[0000936395-23-000027:mdna:8]
From the second quarter of fiscal 2021 through the third quarter of fiscal 2022, we received an unprecedented volume of orders for our products and services. Our quarterly order volumes during this period significantly exceeded our revenue and historical order volumes, with concentration of orders among certain existing Web-scale and North America-based service provider customers. We believe some portion of these orders reflected customer acceleration of future orders due to lengthened

[0000936395-23-000027:mdna:9]
lead times or the implementation of security of supply strategies to address the supply constraints described below. We also believe some portion of these orders reflected pre-pandemic design wins for which orders were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022. We have continued to experience reduced orders relative to revenue in the first half of fiscal 2023 and order volumes lower than those received during the second quarter of fiscal 2021 through the third quarter of fiscal 2022. We believe this reduction has been in part due to customers no longer needing to place significant advanced orders as supply chain conditions and lead times have improved. However, over the longer term, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term opportunities for our business.

[0000936395-23-000027:mdna:10]
Backlog and Order Delivery Timing

[0000936395-23-000027:mdna:11]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and therefore less predictable and subject to fluctuation. As a result of elevated order volumes in recent prior periods and the supply chain constraints described below, however, we generated a significant backlog of customer orders, and, more recently, our quarterly results have been more significantly impacted by availability of supply, as well as customer delivery deferrals of existing backlog. Our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. As supply chain conditions have begun to improve and we have been able to increase shipment volumes and reduce lead times, our backlog has decreased during the first half of fiscal 2023. We expect our backlog to continue to reduce during the remainder of fiscal 2023 as supply chain conditions improve and customers place fewer advanced orders. As that happens, we expect our reliance upon securing quarterly book to revenue orders to grow and those orders to represent a more typical composition of our quarterly revenue over time.

[0000936395-23-000027:mdna:12]
The timing and degree to which we fulfill our backlog will have a significant impact on our rate of revenue growth and can be affected by factors outside of our control, including the supply chain conditions and availability of components described below, and customer readiness and willingness to receive shipment against existing orders. Given their elevated order levels in recent prior periods, during the first half of fiscal 2023, certain customers, including communications service providers and cable and multiservice operators in North America and Web-scale providers, rescheduled deliveries of a portion of their existing orders, including in some cases until after the end of fiscal 2023. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See the risk factors captioned “Our backlog may not be an accurate indicator of our level and timing of future revenues.” and “Our revenue, gross margin, and operating results can fluctuate significantly and unpredictably from quarter to quarter.” in Item 1A of Part II of this report for further discussion of risks related to our backlog and order delivery timing.

[0000936395-23-000027:mdna:13]
[same as prior period, unchanged from 0000936395-23-000014:mdna:11]

[0000936395-23-000027:mdna:14]
In the face of demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits, and other electronic components used in most of our products, experienced substantial constraint and disruption in recent periods. As a result, we experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. While reliability of supply has begun to improve gradually, and the majority of our suppliers have been able to deliver by their promised, though extended, lead times, we continue to experience volatility from a small group of our suppliers of integrated circuit components that represent a small fraction of our overall materials, but which are essential for delivering finished products. This volatility can result in receiving fewer components than expected in a given period, which can adversely impact our revenue. It can also result in receiving more components than expected, as was the case in during the fourth quarter of fiscal 2022 and the first half of fiscal 2023, and which had a positive impact on our revenue. We expect supply chain challenges and the extended lead times and elevated supply chain costs we have experienced will persist at least through fiscal 2023. We expect these supply conditions to continue to impact our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. It is unclear when the supply environment will become less volatile and what impacts it will have on our business and results of operations in future periods.

[0000936395-23-000027:mdna:15]
To mitigate the impact of these supply conditions on our business and customers, we have been placing advanced orders for inventory and accumulating components that are in available supply. We believe that this approach positions us to produce finished goods more quickly when supply constraints ease for those components in shorter supply. As a result, our inventory increased from $946.7 million at the end of fiscal 2022 to $1.2 billion at the end of the first quarter of fiscal 2023. As supply chain conditions have begun to improve and we have been able to fulfill more orders, our inventory has decreased to $1.1 billion at the end of the second quarter of fiscal 2023. We have also implemented additional mitigation strategies, including

[0000936395-23-000027:mdna:16]
expanding manufacturing capacity, implementing multi-sourcing activities, qualifying alternative parts, and redesigning products, and expect, over time, to realize certain benefits of these activities. Together with increased costs of supply, these mitigation strategies have impacted, and we expect them to continue to impact, our result of operations and cash from operations. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain and our mitigation activities.

[0000936395-23-000027:mdna:17]
ABL Credit Facility

[0000936395-23-000027:mdna:18]
On February 10, 2023, we amended our existing ABL Credit Facility (as defined below) to, among other things, extend the maturity date of the ABL Credit Facility to September 28, 2025. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information relating to the amendment of the ABL Credit Facility.

[0000936395-23-000027:mdna:19]
[same as prior period, unchanged from 0000936395-23-000014:mdna:17]

[0000936395-23-000027:mdna:20]
[same as prior period, unchanged from 0000936395-23-000014:mdna:18]

[0000936395-23-000027:mdna:21]
[same as prior period, unchanged from 0000936395-23-000014:mdna:19]

[0000936395-23-000027:mdna:22]
[same as prior period, unchanged from 0000936395-23-000014:mdna:20]

[0000936395-23-000027:mdna:23]
[same as prior period, unchanged from 0000936395-23-000014:mdna:21]

[0000936395-23-000027:mdna:24]
[same as prior period, unchanged from 0000936395-23-000014:mdna:22]

[0000936395-23-000027:mdna:25]
Approximately 15.9% and 15.3% of our revenue was non-U.S. Dollar-denominated during the second quarter and first six months of fiscal 2023, respectively, primarily including sales in Euros, Canadian Dollars, and British Pounds. During the second quarter of fiscal 2023, as compared to the second quarter of fiscal 2022, and during the first six months of fiscal 2023, as compared to the first six months of fiscal 2022, the U.S. Dollar primarily strengthened against these currencies. Consequently, our revenue for the second quarter and first six months of fiscal 2023 reported in U.S. Dollars were adversely impacted by approximately $8.2 million, or 0.7%, and $7.5 million or 0.3%, respectively.

[0000936395-23-000027:mdna:26]
[same as prior period, unchanged from 0000936395-23-000014:mdna:24]

[0000936395-23-000027:mdna:27]
[same as prior period, unchanged from 0000936395-23-000014:mdna:25]

[0000936395-23-000027:mdna:28]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | 625,294 |  |  |  |  | 25.5 | % |  | $ | 1,520,183 |  |  | $ | 1,166,230 |  |  |  |  | 30.4 | % |
| %** | 69.3 | % |  | 65.8 | % |  |  |  |  |  | 69.4 | % |  | 65.0 | % |  |  |  |  |
| Routing and Switching | 130,310 |  |  | 109,186 |  |  |  |  | 19.3 | % |  | 249,814 |  |  | 194,896 |  |  |  |  | 28.2 | % |
| %** | 11.5 | % |  | 11.5 | % |  |  |  |  |  | 11.4 | % |  | 10.9 | % |  |  |  |  |
| Total Networking Platforms | 914,859 |  |  | 734,480 |  |  |  |  | 24.6 | % |  | 1,769,997 |  |  | 1,361,126 |  |  |  |  | 30.0 | % |
| %** | 80.8 | % |  | 77.3 | % |  |  |  |  |  | 80.8 | % |  | 75.9 | % |  |  |  |  |
| Platform Software and Services | 69,443 |  |  | 69,157 |  |  |  |  | 0.4 | % |  | 142,888 |  |  | 142,074 |  |  |  |  | 0.6 | % |
| %** | 6.1 | % |  | 7.3 | % |  |  |  |  |  | 6.6 | % |  | 7.9 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 20,567 |  |  | 16,881 |  |  |  |  | 21.8 | % |  | 35,973 |  |  | 37,992 |  |  |  |  | (5.3) | % |
| %** | 1.8 | % |  | 1.8 | % |  |  |  |  |  | 1.6 | % |  | 2.1 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 73,160 |  |  | 74,019 |  |  |  |  | (1.2) | % |  | 141,051 |  |  | 146,509 |  |  |  |  | (3.7) | % |
| %** | 6.5 | % |  | 7.8 | % |  |  |  |  |  | 6.4 | % |  | 8.2 | % |  |  |  |  |
| Installation and Deployment | 39,486 |  |  | 41,430 |  |  |  |  | (4.7) | % |  | 74,061 |  |  | 81,800 |  |  |  |  | (9.5) | % |
| %** | 3.5 | % |  | 4.4 | % |  |  |  |  |  | 3.4 | % |  | 4.6 | % |  |  |  |  |
| Consulting and Network Design | 15,140 |  |  | 13,260 |  |  |  |  | 14.2 | % |  | 25,206 |  |  | 24,169 |  |  |  |  | 4.3 | % |
| %** | 1.3 | % |  | 1.4 | % |  |  |  |  |  | 1.2 | % |  | 1.3 | % |  |  |  |  |
| Total Global Services | 127,786 |  |  | 128,709 |  |  |  |  | (0.7) | % |  | 240,318 |  |  | 252,478 |  |  |  |  | (4.8) | % |
| %** | 11.3 | % |  | 13.6 | % |  |  |  |  |  | 11.0 | % |  | 14.1 | % |  |  |  |  |
| Total revenue | $ | 1,132,655 |  |  | $ | 949,227 |  |  |  |  | 19.3 | % |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |  |  |  | 22.1 | % |

[0000936395-23-000027:mdna:29]
[same as prior period, unchanged from 0000936395-23-000014:mdna:27]

[0000936395-23-000027:mdna:30]
[same as prior period, unchanged from 0000936395-23-000014:mdna:28]

[0000936395-23-000027:mdna:31]
[same as prior period, unchanged from 0000936395-23-000014:mdna:29]

[0000936395-23-000027:mdna:32]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:33]
•Networking Platforms segment revenue increased by $180.4 million, reflecting product line sales increases of $159.3 million of our Converged Packet Optical products and $21.1 million of our Routing and Switching products.

[0000936395-23-000027:mdna:34]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $106.9 million of our 6500

[0000936395-23-000027:mdna:35]
Packet-Optical Platform, primarily to communications service providers, enterprise customers, and government customers, and $76.0 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers and communications service providers, partially offset by a sales decrease of $28.7 million of our Waveserver® products, primarily to Web-scale providers and cable and multiservice operators.

[0000936395-23-000027:mdna:36]
•Routing and Switching sales increased, primarily reflecting sales increases of $13.9 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, and $5.9 million of our 8100 Coherent IP networking, platforms primarily to communications service providers.

[0000936395-23-000027:mdna:37]
•Platform Software and Services segment revenue reflects a sales increase of $8.7 million in our subscription software services, primarily to communications service providers, offset by a sales decrease of $8.4 million in sales of software platforms, primarily due to decreased sales of our MCP software platform.

[0000936395-23-000027:mdna:38]
•Blue Planet Automation Software and Services segment revenue increased by $3.7 million, primarily reflecting an increase of $3.4 million in software platforms sales primarily to communications service providers.

[0000936395-23-000027:mdna:39]
•Global Services segment revenue remained relatively unchanged.

[0000936395-23-000027:mdna:40]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:41]
•Networking Platforms segment revenue increased by $408.9 million, reflecting product line sales increases of $354.0 million of our Converged Packet Optical products and $54.9 million of our Routing and Switching products.

[0000936395-23-000027:mdna:42]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $183.7 million of our 6500

[0000936395-23-000027:mdna:43]
Packet-Optical Platform, primarily to communications service providers and enterprise customers, $120.3 million of our 6500 RLS products, primarily to Web-scale providers, and $47.2 million of our Waveserver® products, primarily to Web-scale providers and communications service providers.

[0000936395-23-000027:mdna:44]
◦Routing and Switching sales increased, primarily reflecting sales increases of $32.6 million of our Virtualization Edge software, $13.0 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, $7.5 million of our 8100 Coherent IP networking platforms and $7.1 million of our platform independent software, both primarily to communications service providers. The increase in Routing and Switching sales was partially offset by a sales decrease of $8.6 million of our 6500 Packet Transport System (PTS), primarily to government customers and communications service providers.

[0000936395-23-000027:mdna:45]
•Platform Software and Services segment revenue reflects a sales increase of $20.0 million in our subscription software services, primarily to communications service providers, offset by a sales decrease of $19.2 million in sales of software platforms, primarily due to decreased sales of our MCP software platform.

[0000936395-23-000027:mdna:46]
•Blue Planet Automation Software and Services segment revenue decreased by $2.0 million, primarily reflecting a decrease of $1.6 million in sales of automation software platforms.

[0000936395-23-000027:mdna:47]
•Global Services segment revenue decreased by $12.2 million, primarily reflecting sales decreases of $7.7 million of our installation and deployment services and $5.5 million of our maintenance support and training, partially offset by a sales increase of $1.0 million of our consulting and network design services. Installation and deployment services were adversely impacted by the current constrained supply environment, which resulted in delayed delivery of certain products for which installation and deployment services were ordered by customers, as described in more detail in “Overview” above.

[0000936395-23-000027:mdna:48]
[same as prior period, unchanged from 0000936395-23-000014:mdna:39]

[0000936395-23-000027:mdna:49]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for the quarter and six months ended April 29, 2023 was primarily driven by increased sales in the United States. The increase in our APAC region revenue for the quarter and six months ended April 29, 2023 was primarily driven by increased sales in India and Australia. The increase in our EMEA region revenue for the quarter and six months ended April 29, 2023 was primarily driven by increased sales in France, Germany and the Netherlands.

[0000936395-23-000027:mdna:50]
[same as prior period, unchanged from 0000936395-23-000014:mdna:41]

[0000936395-23-000027:mdna:51]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Americas | $ | 794,359 |  |  | $ | 700,840 |  |  |  |  | 13.3 | % |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |  |  |  | 20.3 | % |
| %** | 70.1 | % |  | 73.8 | % |  |  |  |  |  | 71.2 | % |  | 72.3 | % |  |  |  |  |
| EMEA | 173,414 |  |  | 145,106 |  |  |  |  | 19.5 | % |  | 326,218 |  |  | 295,891 |  |  |  |  | 10.2 | % |
| %** | 15.3 | % |  | 15.3 | % |  |  |  |  |  | 14.9 | % |  | 16.5 | % |  |  |  |  |
| APAC | 164,882 |  |  | 103,281 |  |  |  |  | 59.6 | % |  | 303,503 |  |  | 201,795 |  |  |  |  | 50.4 | % |
| %** | 14.6 | % |  | 10.9 | % |  |  |  |  |  | 13.9 | % |  | 11.2 | % |  |  |  |  |
| Total | $ | 1,132,655 |  |  | $ | 949,227 |  |  |  |  | 19.3 | % |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |  |  |  | 22.1 | % |

[0000936395-23-000027:mdna:52]
[same as prior period, unchanged from 0000936395-23-000014:mdna:43]

[0000936395-23-000027:mdna:53]
[same as prior period, unchanged from 0000936395-23-000014:mdna:44]

[0000936395-23-000027:mdna:54]
[same as prior period, unchanged from 0000936395-23-000014:mdna:45]

[0000936395-23-000027:mdna:55]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:56]
•Americas revenue increased by $93.5 million, primarily reflecting a sales increase of $95.9 million within our Networking Platforms segment. This sales increase was partially offset by sales decreases of $1.9 million within our Platform Software and Services segment and $1.3 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects product line sales increases of $81.4 million of our Converged Packet Optical products and $14.5 million of our Routing and Switching products. The increase within our Converged Packet Optical product line was primarily related to sales increases of $59.4 million of our 6500 RLS products, primarily to Web-scale providers, and $57.4 million of our 6500 Packet-Optical Platform primarily to communications service providers. These increases were offset by a product line sales decrease of $36.0 million of our Waveserver® products, primarily to communications service providers, cable and multiservice operators and Web-scale providers. The increase within our Routing and Switching product line reflected sales increases of $8.5 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, and $5.0 million of our 8100 Coherent IP networking platforms, primarily to communications service providers.

[0000936395-23-000027:mdna:57]
•EMEA revenue increased by $28.3 million, primarily reflecting sales increases of $20.0 million within our

[0000936395-23-000027:mdna:58]
Networking Platforms segment, $6.7 million within our Blue Planet Automation Software and Services segment, and $2.9 million within our Platform Software and Services segment, partially offset by a sales decrease of $1.3 million within our Global Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $15.0 million of our Converged Packet Optical product line, primarily related to a sales increase of $12.2 million of our 6500 RLS, primarily to Web-scale customers.

[0000936395-23-000027:mdna:59]
•APAC revenue increased by $61.6 million, primarily reflecting a sales increase of $64.5 million within our

[0000936395-23-000027:mdna:60]
Networking Platforms segment, partially offset by a sales decrease of $1.7 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment primarily reflects a product line sales increase of $62.8 million of Converged Packet Optical products, which includes sales increases of $41.7 million of our 6500 Packet-Optical Platform, primarily to communications service provider and enterprise customers.

[0000936395-23-000027:mdna:61]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:62]
•Americas revenue increased by $263.5 million, primarily reflecting a sales increase of $276.3 million within our Networking Platforms segment. This sales increase was partially offset by sales decreases of $6.5 million within our Global Services segment and $6.2 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $228.6 million of Converged Packet Optical products and $47.7 million of Routing and Switching products. Our Converged Packet Optical revenue primarily reflects sales increases of $102.9 million of our 6500 Packet-Optical Platform primarily to communications service providers, $95.2 million of our 6500 RLS products, primarily to Web-scale providers, and $29.3 million of our Waveserver® products, primarily to Web-scale providers, partially offset by decreased sales to cable and multiservice providers. Routing and Switching product line sales primarily reflect sales increases of $32.6 million of our Virtualization Edge software, $7.7 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, and $7.1 million of our platform independent software to communications service providers. These sales increases were offset by a sales decrease of $8.7 million of our 6500 Packet Transport System (PTS) products, primarily to government customers and communications service providers.

[0000936395-23-000027:mdna:63]
•EMEA revenue increased by $30.3 million, reflecting sales increases of $25.8 million within our Networking Platforms segment, $6.9 million within our Blue Planet Automation Software and Services segment and $1.4 million within our Platform Software and Services segment. These sales increases were offset by a sales decrease of $3.8 million within our Global Services segment. Our Networking Platforms segment revenue increase primarily reflects product line sales increases of $21.3 million of Converged Packet Optical products, primarily reflecting a sales increase of $18.4 million of our 6500 RLS products, primarily to Web-scale providers.

[0000936395-23-000027:mdna:64]
•APAC revenue increased by $101.7 million, primarily reflecting a sales increase of $106.7 million within our

[0000936395-23-000027:mdna:65]
Networking Platforms segment. This sales increase was offset by sales decreases of $2.7 million within our Blue Planet Automation Software and Services segment and $1.9 million within our Global Services segment. Our Networking Platforms segment revenue increase primarily reflects a product line sales increase of $104.0 million of Converged Packet Optical products, including a sales increase of $80.5 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers.

[0000936395-23-000027:mdna:66]
[same as prior period, unchanged from 0000936395-23-000014:mdna:53]

[0000936395-23-000027:mdna:67]
[same as prior period, unchanged from 0000936395-23-000014:mdna:54]

[0000936395-23-000027:mdna:68]
[same as prior period, unchanged from 0000936395-23-000014:mdna:55]

[0000936395-23-000027:mdna:69]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Total revenue | $ | 1,132,655 |  |  | $ | 949,227 |  |  |  |  | 19.3 | % |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |  |  |  | 22.1 | % |
| Total cost of goods sold | 644,972 |  |  | 547,446 |  |  |  |  | 17.8 | % |  | 1,245,547 |  |  | 1,007,702 |  |  |  |  | 23.6 | % |
| Gross profit | $ | 487,683 |  |  | $ | 401,781 |  |  |  |  | 21.4 | % |  | $ | 943,629 |  |  | $ | 785,968 |  |  |  |  | 20.1 | % |
| %** | 43.1 | % |  | 42.3 | % |  |  |  |  |  | 43.1 | % |  | 43.8 | % |  |  |  |  |

[0000936395-23-000027:mdna:70]
[same as prior period, unchanged from 0000936395-23-000014:mdna:57]

[0000936395-23-000027:mdna:71]
[same as prior period, unchanged from 0000936395-23-000014:mdna:58]

[0000936395-23-000027:mdna:72]
[same as prior period, unchanged from 0000936395-23-000014:mdna:59]

[0000936395-23-000027:mdna:73]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Product revenue | $ | 935,330 |  |  | $ | 759,948 |  |  |  |  | 23.1 | % |  | $ | 1,813,045 |  |  | $ | 1,424,955 |  |  |  |  | 27.2 | % |
| Product cost of goods sold | 541,883 |  |  | 452,057 |  |  |  |  | 19.9 | % |  | 1,042,220 |  |  | 824,622 |  |  |  |  | 26.4 | % |
| Product gross profit | $ | 393,447 |  |  | $ | 307,891 |  |  |  |  | 27.8 | % |  | $ | 770,825 |  |  | $ | 600,333 |  |  |  |  | 28.4 | % |
| %** | 42.1 | % |  | 40.5 | % |  |  |  |  |  | 42.5 | % |  | 42.1 | % |  |  |  |  |

[0000936395-23-000027:mdna:74]
[same as prior period, unchanged from 0000936395-23-000014:mdna:61]

[0000936395-23-000027:mdna:75]
[same as prior period, unchanged from 0000936395-23-000014:mdna:62]

[0000936395-23-000027:mdna:76]
[same as prior period, unchanged from 0000936395-23-000014:mdna:63]

[0000936395-23-000027:mdna:77]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Services revenue | $ | 197,325 |  |  | $ | 189,279 |  |  |  |  | 4.3 | % |  | $ | 376,131 |  |  | $ | 368,715 |  |  |  |  | 2.0 | % |
| Services cost of goods sold | 103,089 |  |  | 95,389 |  |  |  |  | 8.1 | % |  | 203,327 |  |  | 183,080 |  |  |  |  | 11.1 | % |
| Services gross profit | $ | 94,236 |  |  | $ | 93,890 |  |  |  |  | 0.4 | % |  | $ | 172,804 |  |  | $ | 185,635 |  |  |  |  | (6.9) | % |
| % ** | 47.8 | % |  | 49.6 | % |  |  |  |  |  | 45.9 | % |  | 50.3 | % |  |  |  |  |

[0000936395-23-000027:mdna:78]
[same as prior period, unchanged from 0000936395-23-000014:mdna:65]

[0000936395-23-000027:mdna:79]
[same as prior period, unchanged from 0000936395-23-000014:mdna:66]

[0000936395-23-000027:mdna:80]
[same as prior period, unchanged from 0000936395-23-000014:mdna:67]

[0000936395-23-000027:mdna:81]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:82]
•Gross profit increased by $85.9 million. Gross margin slightly increased by 80 basis points, primarily due to improved manufacturing efficiencies and product cost reductions, partially offset by a higher concentration of lower margin product mix and lower services margins. As supply conditions gradually improve, particularly for lower margin “common” equipment and photonics, we expect our gross margin to be adversely impacted during the remainder of fiscal 2023 as a result of a higher concentration of lower margin product mix. We also expect our gross margin to continue be adversely impacted due to the challenges and costs associated with the constrained supply environment described in “Overview” above.

[0000936395-23-000027:mdna:83]
•Gross profit on products increased by $85.6 million. Product gross margin increased by 160 basis points, primarily due to improved manufacturing efficiencies and product cost reductions, partially offset by a higher concentration of lower margin product mix.

[0000936395-23-000027:mdna:84]
•Gross profit on services increased by $0.3 million. Services gross margin decreased by 180 basis points, primarily due to lower margin on certain installation and deployment projects and losses incurred on certain Blue Planet software service projects. These decreases were partially offset by increased Platform Software services revenue.

[0000936395-23-000027:mdna:85]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:86]
•Gross profit increased by $157.7 million. Gross margin slightly decreased by 70 basis points, primarily due to lower services margins and a higher concentration of lower margin product mix, partially offset by product cost reductions and improved manufacturing efficiencies. As supply conditions gradually improve, particularly for lower margin “common” equipment and photonics, we expect our gross margin to continue to be adversely impacted during the remainder of fiscal 2023 as a result of a higher concentration of lower margin product mix. We also expect our gross margin to continue be adversely impacted due to the challenges and costs associated with the constrained supply environment described in “Overview” above.

[0000936395-23-000027:mdna:87]
•Gross profit on products increased by $170.5 million. Product gross margin slightly increased by 40 basis points, primarily due to product cost reductions and improved manufacturing efficiencies, partially offset by lower sales of software platforms.

[0000936395-23-000027:mdna:88]
•Gross profit on services decreased by $12.8 million. Services gross margin decreased by 440 basis points, primarily due to lower maintenance support revenue, lower margin on certain installation and deployment projects, and losses incurred on certain Blue Planet software service projects. These decreases were partially offset by an increase in Platform Software services revenue.

[0000936395-23-000027:mdna:89]
[same as prior period, unchanged from 0000936395-23-000014:mdna:72]

[0000936395-23-000027:mdna:90]
[same as prior period, unchanged from 0000936395-23-000014:mdna:73]

[0000936395-23-000027:mdna:91]
Approximately 49.3% of our operating expense was non-U.S. Dollar-denominated during the second quarter of fiscal 2023, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the second quarter of fiscal 2023, as compared to the second quarter of fiscal 2022, and during the first six months of fiscal 2023, as compared to the first six months of fiscal 2022, the U.S. Dollar primarily strengthened against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $12.0 million, or 3.1%, and $21.8 million, or 2.9%, respectively.

[0000936395-23-000027:mdna:92]
[same as prior period, unchanged from 0000936395-23-000014:mdna:75]

[0000936395-23-000027:mdna:93]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Research and development | $ | 189,993 |  |  | $ | 159,324 |  |  |  |  | 19.2 | % |  | $ | 371,723 |  |  | $ | 307,733 |  |  |  |  | 20.8 | % |
| %** | 16.8 | % |  | 16.8 | % |  |  |  |  |  | 17.0 | % |  | 17.2 | % |  |  |  |  |
| Selling and marketing | 125,083 |  |  | 119,939 |  |  |  |  | 4.3 | % |  | 248,890 |  |  | 238,820 |  |  |  |  | 4.2 | % |
| %** | 11.0 | % |  | 12.6 | % |  |  |  |  |  | 11.4 | % |  | 13.3 | % |  |  |  |  |
| General and administrative | 50,939 |  |  | 45,572 |  |  |  |  | 11.8 | % |  | 101,835 |  |  | 90,070 |  |  |  |  | 13.1 | % |
| %** | 4.5 | % |  | 4.8 | % |  |  |  |  |  | 4.6 | % |  | 5.0 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 8,153 |  |  | 9,102 |  |  |  |  | (10.4) | % |  | 12,451 |  |  | 12,511 |  |  |  |  | (0.5) | % |
| %** | 0.7 | % |  | 1.0 | % |  |  |  |  |  | 0.6 | % |  | 0.7 | % |  |  |  |  |
| Amortization of intangible assets | 9,845 |  |  | 8,920 |  |  |  |  | 10.4 | % |  | 17,286 |  |  | 17,838 |  |  |  |  | (3.1) | % |
| %** | 0.9 | % |  | 0.9 | % |  |  |  |  |  | 0.8 | % |  | 1.0 | % |  |  |  |  |
| Acquisition and integration costs | 857 |  |  | 495 |  |  |  |  | 73.1 | % |  | 3,415 |  |  | 563 |  |  |  |  | 506.6 | % |
| %** | 0.1 | % |  | 0.1 | % |  |  |  |  |  | 0.1 | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 384,870 |  |  | $ | 343,352 |  |  |  |  | 12.1 | % |  | $ | 755,600 |  |  | $ | 667,535 |  |  |  |  | 13.2 | % |
| %** | 34.0 | % |  | 36.2 | % |  |  |  |  |  | 34.5 | % |  | 37.2 | % |  |  |  |  |

[0000936395-23-000027:mdna:94]
[same as prior period, unchanged from 0000936395-23-000014:mdna:77]

[0000936395-23-000027:mdna:95]
[same as prior period, unchanged from 0000936395-23-000014:mdna:78]

[0000936395-23-000027:mdna:96]
[same as prior period, unchanged from 0000936395-23-000014:mdna:79]

[0000936395-23-000027:mdna:97]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:98]
•Research and development expense benefited from $7.3 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $30.7 million. This increase

[0000936395-23-000027:mdna:99]
primarily reflects increases in employee headcount and related compensation costs, professional services and technology and related costs. The increase in employee headcount was partially due to our acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”).

[0000936395-23-000027:mdna:100]
•Selling and marketing expense benefited from $3.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased by $5.1 million. This increase primarily reflects increases in employee headcount and related compensation costs, travel and entertainment costs, facility and information technology costs, and professional services.

[0000936395-23-000027:mdna:101]
•General and administrative expense benefited from $1.1 million as a result of foreign exchange rates, primarily due

[0000936395-23-000027:mdna:102]
to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $5.4 million. This increase primarily reflects increases in employee headcount and related compensation costs and professional services.

[0000936395-23-000027:mdna:103]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities.

[0000936395-23-000027:mdna:104]
•Amortization of intangible assets increased by $0.9 million due to additional intangibles acquired in connection with our acquisitions of Benu and Tibit during the first quarter of fiscal 2023, partially offset by certain intangible assets having reached the end of their economic lives.

[0000936395-23-000027:mdna:105]
•Acquisition and integration costs remained relatively unchanged.

[0000936395-23-000027:mdna:106]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:107]
•Research and development expense benefited from $13.7 million as a result of foreign exchange rates, net of hedging, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $64.0 million. This increase primarily reflects increases in employee headcount and related compensation costs, professional services, and technology and related costs. The increase in employee headcount was partially due to our acquisitions of Benu and Tibit. This increase also reflects the effect of a $4.4 million decrease in benefit from the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (ENCQOR) project grant reimbursement program.

[0000936395-23-000027:mdna:108]
•Selling and marketing expense benefited from $6.3 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased by $10.1 million. This increase primarily reflects an increase in professional services and travel and entertainment costs, partially offset by a decrease in employee-related compensation costs related to sales commissions.

[0000936395-23-000027:mdna:109]
•General and administrative expense benefited from $1.8 million as a result of foreign exchange rates, primarily due

[0000936395-23-000027:mdna:110]
to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense increased by $11.8 million. This increase primarily reflects increases in employee headcount and related compensation costs, professional services, and bad debt expense.

[0000936395-23-000027:mdna:111]
•Significant asset impairments and restructuring costs reflects actions that we have taken with respect to our operations, global workforce, and facilities as part of a business optimization strategy to improve gross margin, constrain operating expense, redesign certain business processes, and restructure real estate facilities.

[0000936395-23-000027:mdna:112]
•Amortization of intangible assets reflects certain intangible assets having reached the end of their economic lives, partially offset by additional intangibles acquired in connection with our acquisitions of Benu and Tibit during the first quarter of fiscal 2023.

[0000936395-23-000027:mdna:113]
•Acquisition and integration costs increased by $2.9 million and primarily reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu and Tibit.

[0000936395-23-000027:mdna:114]
[same as prior period, unchanged from 0000936395-23-000014:mdna:89]

[0000936395-23-000027:mdna:115]
[same as prior period, unchanged from 0000936395-23-000014:mdna:90]

[0000936395-23-000027:mdna:116]
[same as prior period, unchanged from 0000936395-23-000014:mdna:91]

[0000936395-23-000027:mdna:117]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Interest and other income, net | $ | 8,551 |  |  | $ | 808 |  |  |  |  | 958.3 | % |  | $ | 40,524 |  |  | $ | 4,494 |  |  |  |  | 801.7 | % |
| %** | 0.8 | % |  | 0.1 | % |  |  |  |  |  | 1.9 | % |  | 0.3 | % |  |  |  |  |
| Interest expense | $ | 23,889 |  |  | $ | 11,985 |  |  |  |  | 99.3 | % |  | $ | 39,759 |  |  | $ | 20,633 |  |  |  |  | 92.7 | % |
| %** | 2.1 | % |  | 1.3 | % |  |  |  |  |  | 1.8 | % |  | 1.2 | % |  |  |  |  |
| Provision for income taxes | $ | 29,821 |  |  | $ | 8,330 |  |  |  |  | 258.0 | % |  | $ | 54,899 |  |  | $ | 17,549 |  |  |  |  | 212.8 | % |
| %** | 2.6 | % |  | 0.9 | % |  |  |  |  |  | 2.5 | % |  | 1.0 | % |  |  |  |  |

[0000936395-23-000027:mdna:118]
[same as prior period, unchanged from 0000936395-23-000014:mdna:93]

[0000936395-23-000027:mdna:119]
[same as prior period, unchanged from 0000936395-23-000014:mdna:94]

[0000936395-23-000027:mdna:120]
[same as prior period, unchanged from 0000936395-23-000014:mdna:95]

[0000936395-23-000027:mdna:121]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:122]
•Interest and other income, net increased by $7.7 million, primarily resulting from higher interest income on our investments. These increases were partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-23-000027:mdna:123]
•Interest expense increased by $11.9 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000027:mdna:124]
•Provision for income taxes increased by $21.5 million, primarily due to an increase in pre-tax income in the second quarter of fiscal 2023 as compared to the second quarter of fiscal 2022. The effective tax rate for the second quarter of fiscal 2023 was higher than the effective tax rate for the second quarter of fiscal 2022, primarily due to the mandatory capitalization of research and development expenses in the second quarter of fiscal 2023.

[0000936395-23-000027:mdna:125]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:126]
•Interest and other income, net increased by $36.0 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, which resulted in a gain on our cost method equity investment of $26.5 million, and higher interest income on our investments. These increases were partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. For more information on our acquisitions, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000027:mdna:127]
•Interest expense increased by $19.1 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including our 2030 Notes issued in the first quarter of fiscal 2022 and the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000027:mdna:128]
•Provision for income taxes increased by $37.4 million, primarily due to an increase in pre-tax income in the first six months of fiscal 2023 as compared to the first six months of fiscal 2022. The effective tax rate for the first six months of fiscal 2023 was higher than the effective tax rate for the first six months of fiscal 2022, primarily due to the mandatory capitalization of research and development expenses in the first six months of fiscal 2023.

[0000936395-23-000027:mdna:129]
[same as prior period, unchanged from 0000936395-23-000014:mdna:100]

[0000936395-23-000027:mdna:130]
The table below sets forth the changes in our segment profit (loss) for the periods indicated (in thousands, except percentage data):

[0000936395-23-000027:mdna:131]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |  | April 29, 2023 |  | April 30, 2022 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 214,754 |  |  | $ | 152,769 |  |  |  |  | 40.6 | % |  | $ | 416,901 |  |  | $ | 286,894 |  |  |  |  | 45.3 | % |
| Platform Software and Services | $ | 40,687 |  |  | $ | 43,556 |  |  |  |  | (6.6) | % |  | $ | 86,337 |  |  | $ | 93,052 |  |  |  |  | (7.2) | % |
| Blue Planet Automation Software and Services | $ | (6,912) |  |  | $ | (6,520) |  |  |  |  | 6.0 | % |  | $ | (17,971) |  |  | $ | (7,554) |  |  |  |  | 137.9 | % |
| Global Services | $ | 49,161 |  |  | $ | 52,652 |  |  |  |  | (6.6) | % |  | $ | 86,639 |  |  | $ | 105,843 |  |  |  |  | (18.1) | % |

[0000936395-23-000027:mdna:132]
[same as prior period, unchanged from 0000936395-23-000014:mdna:103]

[0000936395-23-000027:mdna:133]
[same as prior period, unchanged from 0000936395-23-000014:mdna:104]

[0000936395-23-000027:mdna:134]
Quarter ended April 29, 2023 as compared to the quarter ended April 30, 2022

[0000936395-23-000027:mdna:135]
•Networking Platforms segment profit increased by $62.0 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by increased research and development costs.

[0000936395-23-000027:mdna:136]
•Platform Software and Services segment profit decreased by $2.9 million, primarily due to lower software sales volume, as described above, and increased research and development costs.

[0000936395-23-000027:mdna:137]
•Blue Planet Automation Software and Services segment reflects increased research and development costs and lower gross margin on software-related services, partially offset by higher software sales volume.

[0000936395-23-000027:mdna:138]
•Global Services segment profit decreased by $3.5 million, primarily due to lower gross margin on installation and deployment services as described above.

[0000936395-23-000027:mdna:139]
Six months ended April 29, 2023 as compared to the six months ended April 30, 2022

[0000936395-23-000027:mdna:140]
•Networking Platforms segment profit increased by $130.0 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by increased research and development costs.

[0000936395-23-000027:mdna:141]
•Platform Software and Services segment profit decreased by $6.7 million, primarily due to lower software sales volume, as described above, lower gross margin on software-related services, and increased research and development costs.

[0000936395-23-000027:mdna:142]
•Blue Planet Automation Software and Services segment loss increased by $10.4 million, primarily due to lower gross margin on software-related services, increased research and development costs, and lower software sales volume.

[0000936395-23-000027:mdna:143]
•Global Services segment profit decreased by $19.2 million, primarily due to lower maintenance support revenue and increased installation and deployment costs as described above.

[0000936395-23-000027:mdna:144]
[same as prior period, unchanged from 0000936395-23-000014:mdna:112]

[0000936395-23-000027:mdna:145]
Overview. For the six months ended April 29, 2023, we used $35.8 million of cash in operating activities as our working capital requirements of approximately $310.6 million exceeded our net income (adjusted for non-cash charges) of approximately $274.8 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-23-000027:mdna:146]
Despite our cash used in operations, our total cash, cash equivalents, and investments increased by $159.7 million during the first six months of fiscal 2023. This increase principally reflects proceeds from the issuance of the 2030 Term Loan, which provided $492.7 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan which provided $14.7 million in cash during the six months ended April 29, 2023. In addition to the cash used in operations, uses of cash also included the following items: (i) cash used for the acquisition of businesses of $230.0 million; (ii) cash used to fund our investing activities for capital expenditures totaling $58.0 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $22.0 million.

[0000936395-23-000027:mdna:147]
See Notes 4, 16 and 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for additional information on these transactions.

[0000936395-23-000027:mdna:148]
The following table sets forth changes in our cash, cash equivalents and investments in marketable debt securities for the periods indicated (in thousands):

[0000936395-23-000027:mdna:149]
|  | April 29,2023 |  | October 29,2022 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,167,695 |  |  | $ | 994,352 |  |  | $ | 173,343 |  |
| Short-term investments in marketable debt securities | 150,464 |  |  | 153,989 |  |  | (3,525) |  |
| Long-term investments in marketable debt securities | 25,237 |  |  | 35,385 |  |  | (10,148) |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,343,396 |  |  | $ | 1,183,726 |  |  | $ | 159,670 |  |

[0000936395-23-000027:mdna:150]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of April 29, 2023 totaled $1.3 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of September 28, 2025, as modified on February 10, 2023. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of April 29, 2023, letters of credit totaling $89.7 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 29, 2023.

[0000936395-23-000027:mdna:151]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $304.4 million as of April 29, 2023. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $35.0 million.

[0000936395-23-000027:mdna:152]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the first six months of fiscal 2023, we did not repurchase any additional common stock under the stock repurchase program, and $500.0 million remained under the current repurchase authorization as of April 29, 2023. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000027:mdna:153]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-23-000027:mdna:154]
[same as prior period, unchanged from 0000936395-23-000014:mdna:123]

[0000936395-23-000027:mdna:155]
The following sections set forth the components of our $35.8 million of cash used in operating activities during the first six months of fiscal 2023:

[0000936395-23-000027:mdna:156]
[same as prior period, unchanged from 0000936395-23-000014:mdna:125]

[0000936395-23-000027:mdna:157]
[same as prior period, unchanged from 0000936395-23-000014:mdna:126]

[0000936395-23-000027:mdna:158]
|  | Six Months Ended |
|  | April 29, 2023 |
| Net income | $ | 133,895 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 45,903 |  |
| Share-based compensation expenses | 62,372 |  |
| Amortization of intangible assets | 23,600 |  |
| Deferred taxes | (2,134) |  |
| Provision for inventory excess and obsolescence | 12,691 |  |
| Provision for warranty | 13,577 |  |
| Gain on cost method equity investment | (26,455) |  |
| Other | 11,331 |  |
| Net income (adjusted for non-cash charges) | $ | 274,780 |  |

[0000936395-23-000027:mdna:159]
[same as prior period, unchanged from 0000936395-23-000014:mdna:128]

[0000936395-23-000027:mdna:160]
We used $310.6 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-23-000027:mdna:161]
|  | Six Months Ended |
|  | April 29, 2023 |
| Cash used in accounts receivable | $ | (116,914) |  |
| Cash used in inventories | (162,143) |  |
| Cash used in prepaid expenses and other | (41,511) |  |
| Cash used in accounts payable, accruals, and other obligations | (55,754) |  |
| Cash provided by deferred revenue | 68,818 |  |
| Cash used in operating lease assets and liabilities, net | (3,104) |  |
| Total cash used for working capital | $ | (310,608) |  |

[0000936395-23-000027:mdna:162]
[same as prior period, unchanged from 0000936395-23-000014:mdna:131]

[0000936395-23-000027:mdna:163]
•The $116.9 million of cash used in accounts receivable during the first six months of fiscal 2023 reflects increased sales volume at the end of the second quarter of fiscal 2023;

[0000936395-23-000027:mdna:164]
•The $162.1 million of cash used in inventories during the first six months of fiscal 2023 primarily reflects increases in raw materials inventory related to the steps that we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-23-000027:mdna:165]
•The $41.5 million of cash used in prepaid expense and other during the first six months of fiscal 2023 primarily reflects increases in contract assets and other non-trade receivables;

[0000936395-23-000027:mdna:166]
•The $55.8 million of cash used in accounts payable, accruals, and other obligations during the first six months of fiscal 2023 primarily reflects payments to suppliers, partially offset by increases in income taxes payable;

[0000936395-23-000027:mdna:167]
•The $68.8 million of cash provided by deferred revenue during the first six months of fiscal 2023 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-23-000027:mdna:168]
•The $3.1 million of cash used in operating lease assets and liabilities, net, during the first six months of fiscal 2023 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-23-000027:mdna:169]
Our days sales outstanding (“DSOs”) increased from 86 for first six months of fiscal 2022 to 100 for the first six months of fiscal 2023. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 3.1 for the first six months of fiscal 2022 to 1.9 for the first six months of fiscal 2023 due to the increases in inventory as described in “Overview” above.

[0000936395-23-000027:mdna:170]
[same as prior period, unchanged from 0000936395-23-000014:mdna:139]

[0000936395-23-000027:mdna:171]
[same as prior period, unchanged from 0000936395-23-000014:mdna:140]

[0000936395-23-000027:mdna:172]
|  | Six Months Ended |
|  | April 29, 2023 |
| Term Loan due September 28, 2025(1) | $ | 20,413 |  |
| Term Loan due January 31, 2030(2) | 8,945 |  |
| Senior Notes due January 31, 2030(3) | 8,000 |  |
| Interest rate swaps(4) | (2,979) |  |
| ABL Credit Facility(5) | 1,070 |  |
| Finance leases | 2,065 |  |
| Cash paid during period | $ | 37,514 |  |

[0000936395-23-000027:mdna:173]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00% through its amendment on January 19, 2023. The 2025 Term loan now bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the second quarter of fiscal 2023, the interest rate on the 2025 Term Loan was 6.69%.

[0000936395-23-000027:mdna:174]
(2) Interest on the 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.50% subject to a minimum SOFR rate of 0.00%. At the end of the second quarter of fiscal 2023, the interest rate on the 2030 Term Loan was 7.44%.

[0000936395-23-000027:mdna:175]
(3) The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year.

[0000936395-23-000027:mdna:176]
[same as prior period, unchanged from 0000936395-23-000014:mdna:145]

[0000936395-23-000027:mdna:177]
(5) During the first six months of fiscal 2023, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.1 million in commitment fees, interest expense, and other administrative charges relating to the ABL Credit Facility.

[0000936395-23-000027:mdna:178]
For additional information about our debt, ABL Credit Facility and interest rate swaps, see Notes 15, 16 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000027:mdna:179]
[same as prior period, unchanged from 0000936395-23-000014:mdna:148]

[0000936395-23-000027:mdna:180]
[same as prior period, unchanged from 0000936395-23-000014:mdna:149]

[0000936395-23-000027:mdna:181]
Purchase Order Obligations. As of April 29, 2023 we had $2.2 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-23-000027:mdna:182]
Debt. As of April 29, 2023, we had $500.0 million outstanding principal associated with our 2030 Term Loan, with $5.0 million payable within 12 months. Interest on the 2030 Term Loan and payments due under the interest rate swaps are variable and calculated using the rate in effect on the balance sheet date. Future interest payments associated with the 2030 Term Loan total $238.4 million, with $30.1 million payable within 12 months. For additional information about the 2030 Term Loan, see Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-23-000027:mdna:183]
[same as prior period, unchanged from 0000936395-23-000014:mdna:152]

[0000936395-23-000027:mdna:184]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other

[0000936395-23-000027:mdna:185]
long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-23-000027:mdna:186]
[same as prior period, unchanged from 0000936395-23-000014:mdna:154]

[0000936395-23-000027:mdna:187]
[same as prior period, unchanged from 0000936395-23-000014:mdna:155]

[0000936395-23-000027:mdna:188]
[same as prior period, unchanged from 0000936395-23-000014:mdna:156]
