# CIEN notes — 0000936395-23-000027


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-23-000027:notes:1]
[same as prior period, unchanged from 0000936395-23-000014:notes:1]

[0000936395-23-000027:notes:2]
[same as prior period, unchanged from 0000936395-23-000014:notes:2]

[0000936395-23-000027:notes:3]
[same as prior period, unchanged from 0000936395-23-000014:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-23-000027:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.

[0000936395-23-000027:notes:5]
[same as prior period, unchanged from 0000936395-23-000014:notes:5]

[0000936395-23-000027:notes:6]
In October 2021, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-23-000027:notes:7]
[same as prior period, unchanged from 0000936395-23-000014:notes:7]

[0000936395-23-000027:notes:8]
[same as prior period, unchanged from 0000936395-23-000014:notes:8]

[0000936395-23-000027:notes:9]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

[0000936395-23-000027:notes:10]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |

[0000936395-23-000027:notes:11]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | $ | 773,728 |  |
| Services transferred over time | — |  |  | 47,414 |  |  | 12,845 |  |  | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

[0000936395-23-000027:notes:12]
|  | Six Months Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

[0000936395-23-000027:notes:13]
|  | Six months ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

[0000936395-23-000027:notes:14]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-23-000027:notes:15]
[same as prior period, unchanged from 0000936395-23-000014:notes:13]

[0000936395-23-000027:notes:16]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 794,359 |  |  | $ | 700,840 |  |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |
| EMEA |  | 173,414 |  |  | 145,106 |  |  | 326,218 |  |  | 295,891 |  |
| APAC |  | 164,882 |  |  | 103,281 |  |  | 303,503 |  |  | 201,795 |  |
| Total revenue by geographic distribution |  | $ | 1,132,655 |  |  | $ | 949,227 |  |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |

[0000936395-23-000027:notes:17]
Ciena’s revenue includes $722.6 million and $642.2 million of United States revenue for the second quarter of fiscal 2023 and 2022, respectively. For the six months ended April 29, 2023 and April 30, 2022, United States revenue was $1.4 billion and $1.2 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented in the above table.

[0000936395-23-000027:notes:18]
[same as prior period, unchanged from 0000936395-23-000014:notes:16]

[0000936395-23-000027:notes:19]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 123,452 |  |  | n/a |  | $ | 244,779 |  |  | n/a |
| AT&T | n/a |  | 103,189 |  |  | 251,329 |  |  | 214,065 |  |
| Total | $ | 123,452 |  |  | $ | 103,189 |  |  | $ | 496,108 |  |  | $ | 214,065 |  |

[0000936395-23-000027:notes:20]
[same as prior period, unchanged from 0000936395-23-000014:notes:18]

[0000936395-23-000027:notes:21]
[same as prior period, unchanged from 0000936395-23-000014:notes:19]

[0000936395-23-000027:notes:22]
[same as prior period, unchanged from 0000936395-23-000014:notes:20]

[0000936395-23-000027:notes:23]
[same as prior period, unchanged from 0000936395-23-000014:notes:21]

[0000936395-23-000027:notes:24]
[same as prior period, unchanged from 0000936395-23-000014:notes:22]

[0000936395-23-000027:notes:25]
[same as prior period, unchanged from 0000936395-23-000014:notes:23]

[0000936395-23-000027:notes:26]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.

[0000936395-23-000027:notes:27]
[same as prior period, unchanged from 0000936395-23-000014:notes:25]

[0000936395-23-000027:notes:28]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as

[0000936395-23-000027:notes:29]
planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-23-000027:notes:30]
[same as prior period, unchanged from 0000936395-23-000014:notes:28]

[0000936395-23-000027:notes:31]
[same as prior period, unchanged from 0000936395-23-000014:notes:29]

[0000936395-23-000027:notes:32]
[same as prior period, unchanged from 0000936395-23-000014:notes:30]

[0000936395-23-000027:notes:33]
[same as prior period, unchanged from 0000936395-23-000014:notes:31]

[0000936395-23-000027:notes:34]
[same as prior period, unchanged from 0000936395-23-000014:notes:32]

[0000936395-23-000027:notes:35]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-23-000027:notes:36]
|  |  | Balance at April 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,036,688 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 180,020 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 270,625 |  |  | $ | 200,235 |  |

[0000936395-23-000027:notes:37]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 11 below.

[0000936395-23-000027:notes:38]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $100.1 million and $82.0 million of revenue during the first six months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 29, 2023 and April 30, 2022.

[0000936395-23-000027:notes:39]
[same as prior period, unchanged from 0000936395-23-000014:notes:37]

[0000936395-23-000027:notes:40]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.6 million and $39.7 million as of April 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $16.2 million and $14.1 million during the first six months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-23-000027:notes:41]
[same as prior period, unchanged from 0000936395-23-000014:notes:39]

[0000936395-23-000027:notes:42]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 29, 2023, the aggregate amount of RPO was $2.4 billion. As of April 29, 2023, Ciena expects approximately 86% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-23-000027:notes:43]
[same as prior period, unchanged from 0000936395-23-000014:notes:41]

[0000936395-23-000027:notes:44]
|  | April 29,2023 |  | October 29,2022 |
| Products | $ | 33,914 |  |  | $ | 19,814 |  |
| Services | 236,711 |  |  | 180,421 |  |
| Total deferred revenue | 270,625 |  |  | 200,235 |  |
| Less current portion | (202,818) |  |  | (137,899) |  |
| Long-term deferred revenue | $ | 67,807 |  |  | $ | 62,336 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-23-000027:notes:45]
[same as prior period, unchanged from 0000936395-23-000014:notes:43]

[0000936395-23-000027:notes:46]
On November 17, 2022, Ciena acquired Benu, a portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), that complements Ciena’s existing portfolio of broadband access solutions. On December 30, 2022, Ciena acquired Tibit, a provider and developer of PON-specific hardware and operating software that can be integrated into a carrier-grade Ethernet switch and will strengthen Ciena’s portfolio of next-generation PON solutions that support residential, enterprise, and mobility use cases. These businesses were acquired for an aggregate of approximately $291.7 million, of which $244.7 million was paid in cash, and $47.0 million represents the fair value of Ciena’s previously held cost method equity investment in Tibit. The acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. Each of these transactions has been accounted for as the acquisition of a business.

[0000936395-23-000027:notes:47]
Ciena incurred approximately $3.4 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Condensed Consolidated Statements of Operations.

[0000936395-23-000027:notes:48]
[same as prior period, unchanged from 0000936395-23-000014:notes:46]

[0000936395-23-000027:notes:49]
[same as prior period, unchanged from 0000936395-23-000014:notes:47]

[0000936395-23-000027:notes:50]
[same as prior period, unchanged from 0000936395-23-000014:notes:48]

[0000936395-23-000027:notes:51]
[same as prior period, unchanged from 0000936395-23-000014:notes:49]

[0000936395-23-000027:notes:52]
[same as prior period, unchanged from 0000936395-23-000014:notes:50]

[0000936395-23-000027:notes:53]
[same as prior period, unchanged from 0000936395-23-000014:notes:51]

[0000936395-23-000027:notes:54]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included on the Condensed Consolidated Statements of Operations for the reporting period are immaterial.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-23-000027:notes:55]
[same as prior period, unchanged from 0000936395-23-000014:notes:53]

[0000936395-23-000027:notes:56]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the six months ended April 29, 2023 (in thousands):

[0000936395-23-000027:notes:57]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 2,863 |  | (1) | 9,588 |  | (2) | 12,451 |  |
| Cash payments | (1,783) |  |  | (14,208) |  |  | (15,991) |  |
| Balance at April 29, 2023 | $ | 2,295 |  |  | $ | — |  |  | $ | 2,295 |  |
| Current restructuring liabilities | $ | 2,295 |  |  | $ | — |  |  | $ | 2,295 |  |

[0000936395-23-000027:notes:58]
(1) Reflects employee costs associated with workforce reductions during the six months ended April 29, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-23-000027:notes:59]
(2) Primarily represents costs related to restructured real estate facilities and the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization.

[0000936395-23-000027:notes:60]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the six months ended April 30, 2022 (in thousands):

[0000936395-23-000027:notes:61]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 1,413 |  | (1) | 7,018 |  | (2) | 8,431 |  |
| Cash payments | (1,388) |  |  | (7,018) |  |  | (8,406) |  |
| Balance at April 30, 2022 | $ | 806 |  |  | $ | — |  |  | $ | 806 |  |
| Current restructuring liabilities | $ | 806 |  |  | $ | — |  |  | $ | 806 |  |

[0000936395-23-000027:notes:62]
(1) Reflects employee costs associated with workforce reductions during the six months ended April 30, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-23-000027:notes:63]
[same as prior period, unchanged from 0000936395-23-000014:notes:61]

[0000936395-23-000027:notes:64]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income | $ | 10,416 |  |  | $ | 1,434 |  |  | $ | 17,530 |  |  | $ | 2,188 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (2,795) |  |  | 2,334 |  |  | (4,564) |  |  | (1,926) |  |
| Foreign currency exchange gains (losses) | 2,987 |  |  | (1,267) |  |  | 1,104 |  |  | 3,499 |  |
| Gain on cost method equity investment | — |  |  | — |  |  | 26,455 |  |  | 4,120 |  |
| Other | (2,057) |  |  | (1,693) |  |  | (1) |  |  | (3,387) |  |
| Interest and other income, net | $ | 8,551 |  |  | $ | 808 |  |  | $ | 40,524 |  |  | $ | 4,494 |  |

[0000936395-23-000027:notes:65]
During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. See Note 4 above. 
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $1.1 million and $3.5 million in foreign currency exchange rate gains for the first six months of fiscal 2023 and 2022, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2023 and 2022, Ciena recorded losses of $4.6 million and $1.9 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-23-000027:notes:66]
INCOME TAXES
The effective tax rate for the quarter and six months ended April 29, 2023 was higher than the effective tax rate for the

[0000936395-23-000027:notes:67]
quarter and six months ended April 30, 2022, primarily due to the mandatory capitalization of research and development expenses in the second quarter and six months ended April 29, 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-23-000027:notes:68]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-23-000027:notes:69]
|  | April 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 120,628 |  |  | $ | 39 |  |  | $ | (1,620) |  |  | $ | 119,047 |  |
| Corporate debt securities | 57,707 |  |  | 41 |  |  | (90) |  |  | 57,658 |  |
| Time deposits | 91,454 |  |  | 2 |  |  | (5) |  |  | 91,451 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |
| Included in cash equivalents | $ | 92,455 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,455 |  |
| Included in short-term investments | 152,105 |  |  | 38 |  |  | (1,679) |  |  | 150,464 |  |
| Included in long-term investments | 25,229 |  |  | 44 |  |  | (36) |  |  | 25,237 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |

[0000936395-23-000027:notes:70]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

[0000936395-23-000027:notes:71]
The following table summarizes the final legal maturities of debt investments as of April 29, 2023 (in thousands):

[0000936395-23-000027:notes:72]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 244,560 |  |  | $ | 242,919 |  |
| Due in 1-2 years | 25,229 |  |  | 25,237 |  |
|  | $ | 269,789 |  |  | $ | 268,156 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-23-000027:notes:73]
[same as prior period, unchanged from 0000936395-23-000014:notes:71]

[0000936395-23-000027:notes:74]
|  | April 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 804,637 |  |  | $ | — |  |  | $ | — |  |  | $ | 804,637 |  |
| Bond mutual fund | 101,352 |  |  | — |  |  | — |  |  | 101,352 |  |
| Time deposits | 91,451 |  |  | — |  |  | — |  |  | 91,451 |  |
| Deferred compensation plan assets | 11,565 |  |  | — |  |  | — |  |  | 11,565 |  |
| U.S. government obligations | — |  |  | 119,047 |  |  | — |  |  | 119,047 |  |
| Corporate debt securities | — |  |  | 57,658 |  |  | — |  |  | 57,658 |  |
| Foreign currency forward contracts | — |  |  | 4,240 |  |  | — |  |  | 4,240 |  |
| Interest rate swaps | — |  |  | 6,597 |  |  | — |  |  | 6,597 |  |
| Total assets measured at fair value | $ | 1,009,005 |  |  | $ | 187,542 |  |  | $ | — |  |  | $ | 1,196,547 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 10,364 |  |  | $ | — |  |  | $ | 10,364 |  |
| Interest rate swaps | — |  |  | 3,211 |  |  | — |  |  | 3,211 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 13,575 |  |  | $ | — |  |  | $ | 13,575 |  |

[0000936395-23-000027:notes:75]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 639,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 639,024 |  |
| Bond mutual fund | 71,145 |  |  | — |  |  | — |  |  | 71,145 |  |
| Time deposits | 55,825 |  |  | — |  |  | — |  |  | 55,825 |  |
| Deferred compensation plan assets | 12,751 |  |  | — |  |  | — |  |  | 12,751 |  |
| U.S. government obligations | — |  |  | 134,584 |  |  | — |  |  | 134,584 |  |
| Corporate debt securities | — |  |  | 54,495 |  |  | — |  |  | 54,495 |  |
| Foreign currency forward contracts | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Interest rate swaps | — |  |  | 12,306 |  |  | — |  |  | 12,306 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-23-000027:notes:76]
[same as prior period, unchanged from 0000936395-23-000014:notes:74]

[0000936395-23-000027:notes:77]
|  | April 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 990,921 |  |  | $ | 7,523 |  |  | $ | — |  |  | $ | 998,444 |  |
| Short-term investments | 6,519 |  |  | 143,945 |  |  | — |  |  | 150,464 |  |
| Prepaid expenses and other | — |  |  | 4,240 |  |  | — |  |  | 4,240 |  |
| Long-term investments | — |  |  | 25,237 |  |  | — |  |  | 25,237 |  |
| Other long-term assets | 11,565 |  |  | 6,597 |  |  | — |  |  | 18,162 |  |
| Total assets measured at fair value | $ | 1,009,005 |  |  | $ | 187,542 |  |  | $ | — |  |  | $ | 1,196,547 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 10,364 |  |  | $ | — |  |  | $ | 10,364 |  |
| Other long-term obligations | — |  |  | 3,211 |  |  | — |  |  | 3,211 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 13,575 |  |  | $ | — |  |  | $ | 13,575 |  |

[0000936395-23-000027:notes:78]
[same as prior period, unchanged from 0000936395-23-000014:notes:76]

[0000936395-23-000027:notes:79]
[same as prior period, unchanged from 0000936395-23-000014:notes:77]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-23-000027:notes:80]
[same as prior period, unchanged from 0000936395-23-000014:notes:78]

[0000936395-23-000027:notes:81]
|  | April 29,2023 |  | October 29,2022 |
| Raw materials | $ | 753,374 |  |  | $ | 664,916 |  |
| Work-in-process | 20,927 |  |  | 18,232 |  |
| Finished goods | 307,997 |  |  | 258,584 |  |
| Deferred cost of goods sold | 58,060 |  |  | 41,084 |  |
| Gross inventories | 1,140,358 |  |  | 982,816 |  |
| Reserve for inventory excess and obsolescence | (42,266) |  |  | (36,086) |  |
| Inventories, net | $ | 1,098,092 |  |  | $ | 946,730 |  |

[0000936395-23-000027:notes:82]
The increase in raw materials inventory is related to the steps Ciena has been taking to mitigate the impact on its customers and business of supply chain constraints in recent periods and a global market shortage of semiconductor components. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first six months of fiscal 2023, Ciena recorded a provision for inventory excess and obsolescence of $12.7 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-23-000027:notes:83]
[same as prior period, unchanged from 0000936395-23-000014:notes:81]

[0000936395-23-000027:notes:84]
|  | April 29,2023 |  | October 29,2022 |
| Contract assets for unbilled accounts receivable, net | $ | 180,020 |  |  | $ | 156,039 |  |
| Prepaid VAT and other taxes | 68,769 |  |  | 63,975 |  |
| Prepaid expenses | 50,301 |  |  | 55,440 |  |
| Other non-trade receivables | 41,265 |  |  | 35,929 |  |
| Product demonstration equipment, net | 41,359 |  |  | 33,516 |  |
| Capitalized contract acquisition costs | 29,213 |  |  | 24,026 |  |
| Foreign currency forward contracts | 4,240 |  |  | 251 |  |
| Deferred deployment expense | 520 |  |  | 877 |  |
|  | $ | 415,687 |  |  | $ | 370,053 |  |

[0000936395-23-000027:notes:85]
Depreciation of product demonstration equipment was $3.8 million during the first six months of fiscal 2023 and $4.8 million during the first six months of fiscal 2022.

[0000936395-23-000027:notes:86]
[same as prior period, unchanged from 0000936395-23-000014:notes:84]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-23-000027:notes:87]
[same as prior period, unchanged from 0000936395-23-000014:notes:85]

[0000936395-23-000027:notes:88]
|  | April 29, 2023 |  | October 29, 2022 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 503,618 |  |  | $ | (400,509) |  |  | $ | 103,109 |  |  | $ | 428,218 |  |  | $ | (386,300) |  |  | $ | 41,918 |  |
| In-process technology | 89,100 |  |  | — |  |  | 89,100 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 8,415 |  |  | (4,718) |  |  | 3,697 |  |  | 8,415 |  |  | (4,228) |  |  | 4,187 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 411,190 |  |  | (375,782) |  |  | 35,408 |  |  | 390,271 |  |  | (366,859) |  |  | 23,412 |  |
| Total intangible assets | $ | 1,012,323 |  |  | $ | (781,009) |  |  | $ | 231,314 |  |  | $ | 826,904 |  |  | $ | (757,387) |  |  | $ | 69,517 |  |

[0000936395-23-000027:notes:89]
The aggregate amortization expense of intangible assets was $23.6 million during the first six months of fiscal 2023 and $24.5 million during the first six months of fiscal 2022. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-23-000027:notes:90]
| Fiscal Year | Amount |  |  |
| Remaining fiscal 2023 | $ | 26,815 |  |  |  |
| 2024 | 39,754 |  |  |  |
| 2025 | 34,555 |  |  |  |
| 2026 | 23,293 |  |  |  |
| 2027 | 15,789 |  |  |  |
| Thereafter | 2,008 |  |  |  |
|  | $ | 142,214 |  | (1) |  |

[0000936395-23-000027:notes:91]
[same as prior period, unchanged from 0000936395-23-000014:notes:89]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-23-000027:notes:92]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of April 29, 2023 and October 29, 2022, as well as the changes to goodwill during first six months of fiscal 2023 (in thousands):

[0000936395-23-000027:notes:93]
|  |  | Balance at October 29, 2022 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at April 29, 2023 |
| Platform Software and Services |  | $ | 156,191 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services |  | 89,049 |  |  | — |  |  | — |  |  | — |  |  | 89,049 |  |
| Networking Platforms |  | 83,082 |  |  | 117,997 |  |  | — |  |  | 45 |  |  | 201,124 |  |
| Total |  | $ | 328,322 |  |  | $ | 117,997 |  |  | $ | — |  |  | $ | 45 |  |  | $ | 446,364 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-23-000027:notes:94]
[same as prior period, unchanged from 0000936395-23-000014:notes:92]

[0000936395-23-000027:notes:95]
|  | April 29,2023 |  | October 29,2022 |
| Compensation, payroll related tax and benefits | $ | 130,526 |  |  | $ | 126,338 |  |
| Warranty | 49,187 |  |  | 45,503 |  |
| Income taxes payable | 41,025 |  |  | 11,472 |  |
| Vacation | 29,740 |  |  | 26,396 |  |
| Foreign currency forward contracts | 10,364 |  |  | 15,604 |  |
| Interest payable | 5,692 |  |  | 4,793 |  |
| Finance lease liabilities | 3,904 |  |  | 3,758 |  |
| Other | 110,531 |  |  | 126,918 |  |
|  | $ | 380,969 |  |  | $ | 360,782 |  |

[0000936395-23-000027:notes:96]
[same as prior period, unchanged from 0000936395-23-000014:notes:96]

[0000936395-23-000027:notes:97]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Six Months Ended April 30, 2022 |  | $ | 48,019 |  |  |  |  | 7,228 |  |  | (9,563) |  |  | $ | 45,684 |  |
| Six Months Ended April 29, 2023 |  | $ | 45,503 |  |  |  |  | 13,577 |  |  | (9,893) |  |  | $ | 49,187 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-23-000027:notes:98]
[same as prior period, unchanged from 0000936395-23-000014:notes:98]

[0000936395-23-000027:notes:99]
[same as prior period, unchanged from 0000936395-23-000014:notes:99]

[0000936395-23-000027:notes:100]
As of April 29, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies that are principally related to research and development activities. The notional amount of these contracts was approximately $308.1 million and $272.2 million as of April 29, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-23-000027:notes:101]
As of April 29, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $218.8 million and $108.0 million as of April 29, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-23-000027:notes:102]
[same as prior period, unchanged from 0000936395-23-000014:notes:102]

[0000936395-23-000027:notes:103]
[same as prior period, unchanged from 0000936395-23-000014:notes:103]

[0000936395-23-000027:notes:104]
Prior to amending the 2025 Term Loan (as defined in Note 16 below) to replace LIBOR with the Secured Overnight Financing Rate (“SOFR”), Ciena was exposed to floating rates of LIBOR interest on its 2025 Term Loan borrowings. Ciena

[0000936395-23-000027:notes:105]
hedged this risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023. In January 2023, Ciena entered into a LIBOR to SOFR basis swap (“basis swap”) to hedge its exposure to SOFR rate. The basis swap offsets the LIBOR exposure risk of the interest rate swaps and effectively fixes the SOFR rate for $350.0 million of the 2025 Term Loan at 2.883% through September 2023. The total notional amount of these swaps in effect was $350.0 million as of April 29, 2023 and October 29, 2022. In April 2022, Ciena entered into floating to fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the SOFR for $350.0 million of the 2025 Term Loan at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350.0 million as of April 29, 2023.

[0000936395-23-000027:notes:106]
In January 2023, Ciena entered into floating-to-fixed interest rate swap arrangements (“2028 interest rate swaps”). The 2028 interest rate swaps fix the SOFR rate of approximately $350.0 million of the principal amount of the 2030 Term Loan (as defined in Note 16 below) at 3.47% through January 2028. The total notional amount of these interest rate swaps in effect as of April 29, 2023 was $350.0 million.

[0000936395-23-000027:notes:107]
[same as prior period, unchanged from 0000936395-23-000014:notes:106]

[0000936395-23-000027:notes:108]
[same as prior period, unchanged from 0000936395-23-000014:notes:107]


## us-gaap:DebtDisclosureTextBlock

[0000936395-23-000027:notes:109]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loans Payable

[0000936395-23-000027:notes:110]
2025 Term Loan

[0000936395-23-000027:notes:111]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-23-000027:notes:112]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform.

[0000936395-23-000027:notes:113]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000027:notes:114]
|  |  | April 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 672,210 |  |  | $ | (767) |  |  | $ | (1,436) |  |  | $ | 670,007 |  |  | $ | 673,010 |  |

[0000936395-23-000027:notes:115]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.4 million as of April 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000027:notes:116]
As of April 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000027:notes:117]
2030 Term Loan

[0000936395-23-000027:notes:118]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of

[0000936395-23-000027:notes:119]
senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.7 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

[0000936395-23-000027:notes:120]
The Incremental Agreement amends the Credit Agreement and provides that the 2030 Term Loan will, among other things:

[0000936395-23-000027:notes:121]
•mature on January 19, 2030;

[0000936395-23-000027:notes:122]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

[0000936395-23-000027:notes:123]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-23-000027:notes:124]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

[0000936395-23-000027:notes:125]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-23-000027:notes:126]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-23-000027:notes:127]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-23-000027:notes:128]
|  |  | April 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,400) |  |  | $ | (4,667) |  |  | $ | 492,933 |  |  |  |

[0000936395-23-000027:notes:129]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of April 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.2 million during the first six months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000027:notes:130]
As of April 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000027:notes:131]
Outstanding Senior Notes Payable

[0000936395-23-000027:notes:132]
2030 Notes

[0000936395-23-000027:notes:133]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-23-000027:notes:134]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000027:notes:135]
|  |  | April 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,610) |  |  | $ | 395,390 |  |  | $ | 395,045 |  |  |  |

[0000936395-23-000027:notes:136]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.6 million as of April 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.3 million during the first six months of fiscal 2023 and was $0.2 million during the first six months of fiscal 2022. 
As of April 29, 2023, the estimated fair value of the 2030 Notes was $349.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-23-000027:notes:137]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended April 29, 2023 (in thousands):

[0000936395-23-000027:notes:138]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications | 1,698 |  |  | 9,871 |  |  | (3,848) |  |  | 7,829 |  |  | 15,550 |  |
| Amounts reclassified from AOCI | — |  |  | (5,680) |  |  | (2,979) |  |  | — |  |  | (8,659) |  |
| Balance at April 29, 2023 | $ | (1,267) |  |  | $ | (6,006) |  |  | $ | 2,570 |  |  | $ | (35,051) |  |  | $ | (39,754) |  |

[0000936395-23-000027:notes:139]
The following table summarizes the changes in AOCI, net of tax, for the six months ended April 30, 2022 (in thousands):

[0000936395-23-000027:notes:140]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (2,105) |  |  | (5,083) |  |  | 6,098 |  |  | (18,746) |  |  | (19,836) |  |
| Amounts reclassified from AOCI | — |  |  | (1,602) |  |  | 4,940 |  |  | — |  |  | 3,338 |  |
| Balance at April 30, 2022 | $ | (2,269) |  |  | $ | (469) |  |  | $ | (1,141) |  |  | $ | (12,180) |  |  | $ | (16,059) |  |

[0000936395-23-000027:notes:141]
All amounts reclassified from AOCI, related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges, impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI, related to settlement (gains) losses on interest rate swaps designated as cash flow hedges, impacted interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:EarningsPerShareTextBlock

[0000936395-23-000027:notes:142]
[same as prior period, unchanged from 0000936395-23-000014:notes:141]

[0000936395-23-000027:notes:143]
The following table presents the calculation of Basic and Diluted EPS for the periods indicated (in thousands, except per share amounts):

[0000936395-23-000027:notes:144]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income | $ | 57,654 |  |  | $ | 38,922 |  |  | $ | 133,895 |  |  | $ | 84,745 |  |
| Basic weighted average shares outstanding | 149,616 |  |  | 152,197 |  |  | 149,351 |  |  | 153,179 |  |
| Effect of dilutive potential common shares | 531 |  |  | 1,147 |  |  | 501 |  |  | 1,401 |  |
| Diluted weighted average shares | 150,147 |  |  | 153,344 |  |  | 149,852 |  |  | 154,580 |  |
| Basic EPS | $ | 0.39 |  |  | $ | 0.26 |  |  | $ | 0.90 |  |  | $ | 0.55 |  |
| Diluted EPS | $ | 0.38 |  |  | $ | 0.25 |  |  | $ | 0.89 |  |  | $ | 0.55 |  |
| Antidilutive employee share-based awards, excluded | 1,550 |  |  | 1,392 |  |  | 2,159 |  |  | 1,077 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-23-000027:notes:145]
[same as prior period, unchanged from 0000936395-23-000014:notes:144]

[0000936395-23-000027:notes:146]
[same as prior period, unchanged from 0000936395-23-000014:notes:145]

[0000936395-23-000027:notes:147]
During the first six months of fiscal 2023, Ciena did not repurchase any additional shares of its common stock. As of April 29, 2023, Ciena (i) has repurchased 8.4 million shares for an aggregate purchase price of $500.0 million at an average price of $59.28 per share, and (ii) has an aggregate of $500.0 million authorized and remaining under its stock repurchase program. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-23-000027:notes:148]
[same as prior period, unchanged from 0000936395-23-000014:notes:147]

[0000936395-23-000027:notes:149]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $22.0 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2023 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-23-000027:notes:150]
[same as prior period, unchanged from 0000936395-23-000014:notes:149]

[0000936395-23-000027:notes:151]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Products | $ | 1,155 |  |  | $ | 1,058 |  |  | $ | 2,206 |  |  | $ | 1,958 |  |
| Services | 2,659 |  |  | 1,943 |  |  | 4,956 |  |  | 3,527 |  |
| Share-based compensation expense included in cost of goods sold | 3,814 |  |  | 3,001 |  |  | 7,162 |  |  | 5,485 |  |
| Research and development | 10,731 |  |  | 8,309 |  |  | 19,965 |  |  | 15,140 |  |
| Selling and marketing | 8,755 |  |  | 8,061 |  |  | 17,179 |  |  | 15,121 |  |
| General and administrative | 8,468 |  |  | 7,334 |  |  | 17,936 |  |  | 15,246 |  |
| Share-based compensation expense included in operating expense | 27,954 |  |  | 23,704 |  |  | 55,080 |  |  | 45,507 |  |
| Share-based compensation expense capitalized in inventory, net | 92 |  |  | (32) |  |  | 130 |  |  | (22) |  |
| Total share-based compensation expense | $ | 31,860 |  |  | $ | 26,673 |  |  | $ | 62,372 |  |  | $ | 50,970 |  |

[0000936395-23-000027:notes:152]
As of April 29, 2023, total unrecognized share-based compensation expense was approximately $260.7 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.52 years.
Stock Unit AwardsBeginning in December 2022, Ciena introduced a benefit, under which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, the United Kingdom, or Canada and who provide 12 months’ notice of their retirement will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their granted but unvested RSU awards upon retirement. This program accelerates the recognition of share-based compensation expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-23-000027:notes:153]
[same as prior period, unchanged from 0000936395-23-000014:notes:153]

[0000936395-23-000027:notes:154]
[same as prior period, unchanged from 0000936395-23-000014:notes:154]

[0000936395-23-000027:notes:155]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 29, 2023, equipment, building, furniture and fixtures, net, totaled $278.3 million, and operating ROU assets totaled $41.1 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of April 29, 2023, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-23-000027:notes:156]
|  | April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 207,709 |  |  | — |  |  | 23,605 |  |  | — |  |  | $ | 231,314 |  |
| Goodwill | $ | 201,124 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 446,364 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 45,920 |  |  | $ | 45,920 |  |

[0000936395-23-000027:notes:157]
[same as prior period, unchanged from 0000936395-23-000014:notes:157]

[0000936395-23-000027:notes:158]
[same as prior period, unchanged from 0000936395-23-000014:notes:158]

[0000936395-23-000027:notes:159]
[same as prior period, unchanged from 0000936395-23-000014:notes:159]

[0000936395-23-000027:notes:160]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 214,754 |  |  | $ | 152,769 |  |  | $ | 416,901 |  |  | $ | 286,894 |  |
| Platform Software and Services | 40,687 |  |  | 43,556 |  |  | 86,337 |  |  | 93,052 |  |
| Blue Planet Automation Software and Services | (6,912) |  |  | (6,520) |  |  | (17,971) |  |  | (7,554) |  |
| Global Services | 49,161 |  |  | 52,652 |  |  | 86,639 |  |  | 105,843 |  |
| Total segment profit | 297,690 |  |  | 242,457 |  |  | 571,906 |  |  | 478,235 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 125,083 |  |  | 119,939 |  |  | 248,890 |  |  | 238,820 |  |
| General and administrative | 50,939 |  |  | 45,572 |  |  | 101,835 |  |  | 90,070 |  |
| Significant asset impairments and restructuring costs | 8,153 |  |  | 9,102 |  |  | 12,451 |  |  | 12,511 |  |
| Amortization of intangible assets | 9,845 |  |  | 8,920 |  |  | 17,286 |  |  | 17,838 |  |
| Acquisition and integration costs | 857 |  |  | 495 |  |  | 3,415 |  |  | 563 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 8,551 |  |  | 808 |  |  | 40,524 |  |  | 4,494 |  |
| Interest expense | (23,889) |  |  | (11,985) |  |  | (39,759) |  |  | (20,633) |  |
| Less: Provision for income taxes | 29,821 |  |  | 8,330 |  |  | 54,899 |  |  | 17,549 |  |
| Net income | $ | 57,654 |  |  | $ | 38,922 |  |  | $ | 133,895 |  |  | $ | 84,745 |  |

[0000936395-23-000027:notes:161]
[same as prior period, unchanged from 0000936395-23-000014:notes:161]

[0000936395-23-000027:notes:162]
[same as prior period, unchanged from 0000936395-23-000014:notes:162]

[0000936395-23-000027:notes:163]
|  | April 29,2023 |  | October 29,2022 |
| Canada | $ | 235,929 |  |  | $ | 226,451 |  |
| United States | 43,847 |  |  | 47,515 |  |
| Other International | 39,687 |  |  | 38,921 |  |
| Total | $ | 319,463 |  |  | $ | 312,887 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-23-000027:notes:164]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-23-000027:notes:165]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-23-000027:notes:166]
Litigation

[0000936395-23-000027:notes:167]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.
