# CIEN 8-K — 0000936395-23-000024 filed 2023-06-06

## item codes, every 8-K on or before 2023-06-07

- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2023-06-07

- none on or before 2023-06-07

## item 2.02 — earnings release, exhibit 99.1

[0000936395-23-000024:8k_2_02:1]
EX-99.1
2
ex9912023q2earningspressre.htm
EX-99.1

[0000936395-23-000024:8k_2_02:2]
Document

[0000936395-23-000024:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-23-000024:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2023 Financial Results

[0000936395-23-000024:8k_2_02:5]
HANOVER, Md. - June 6, 2023 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal second quarter ended April 29, 2023.

[0000936395-23-000024:8k_2_02:6]
•Q2 Revenue: $1.13 billion

[0000936395-23-000024:8k_2_02:7]
•Q2 Net Income per Share: $0.38 GAAP; $0.74 adjusted (non-GAAP)

[0000936395-23-000024:8k_2_02:8]
"We delivered outstanding results for the fiscal second quarter as we were able to ship more to customers with continued improvements in supply chain dynamics," said Gary Smith, president and CEO of Ciena. "We are confident in our ability to take market share given our backlog and strategic industry position with market-leading technologies and an expanding addressable market."

[0000936395-23-000024:8k_2_02:9]
For fiscal second quarter 2023, Ciena reported revenue of $1.13 billion as compared to $949.2 million for the fiscal second quarter 2022.

[0000936395-23-000024:8k_2_02:10]
Ciena's GAAP net income for the fiscal second quarter 2023 was $57.7 million, or $0.38 per diluted common share, which compares to a GAAP net income of $38.9 million, or $0.25 per diluted common share, for the fiscal second quarter 2022.

[0000936395-23-000024:8k_2_02:11]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2023 was $110.4 million, or $0.74 per diluted common share, which compares to an adjusted (non-GAAP) net income of $76.4 million, or $0.50 per diluted common share, for the fiscal second quarter 2022.

[0000936395-23-000024:8k_2_02:12]
Fiscal Second Quarter 2023 Performance Summary

[0000936395-23-000024:8k_2_02:13]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-23-000024:8k_2_02:14]
|  |  | GAAP Results (unaudited) |
|  |  | Q2 |  | Q2 |  | Period Change |  |  |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,132.7 |  |  | $ | 949.2 |  |  | 19.3 | % |  |  |  |  |  |  |
| Gross margin |  | 43.1 | % |  | 42.3 | % |  | 0.8 | % |  |  |  |  |  |  |
| Operating expense |  | $ | 384.9 |  |  | $ | 343.4 |  |  | 12.1 | % |  |  |  |  |  |  |
| Operating margin |  | 9.1 | % |  | 6.2 | % |  | 2.9 | % |  |  |  |  |  |  |

[0000936395-23-000024:8k_2_02:15]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q2 |  | Q2 |  | Period Change |  |  |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,132.7 |  |  | $ | 949.2 |  |  | 19.3 | % |  |  |  |  |  |  |
| Adj. gross margin |  | 43.7 | % |  | 43.0 | % |  | 0.7 | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 338.1 |  |  | $ | 301.1 |  |  | 12.3 | % |  |  |  |  |  |  |
| Adj. operating margin |  | 13.8 | % |  | 11.3 | % |  | 2.5 | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 180.6 |  |  | $ | 129.3 |  |  | 39.7 | % |  |  |  |  |  |  |

[0000936395-23-000024:8k_2_02:16]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-23-000024:8k_2_02:17]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q2 FY 2023 |  | Q2 FY 2022 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 784.5 |  |  | 69.3 |  |  | $ | 625.3 |  |  | 65.8 |  |
| Routing and Switching |  | 130.4 |  |  | 11.5 |  |  | 109.2 |  |  | 11.5 |  |
| Total Networking Platforms |  | 914.9 |  |  | 80.8 |  |  | 734.5 |  |  | 77.3 |  |
| Platform Software and Services |  | 69.4 |  |  | 6.1 |  |  | 69.1 |  |  | 7.3 |  |
| Blue Planet Automation Software and Services |  | 20.6 |  |  | 1.8 |  |  | 16.9 |  |  | 1.8 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 73.2 |  |  | 6.5 |  |  | 74.0 |  |  | 7.8 |  |
| Installation and Deployment |  | 39.5 |  |  | 3.5 |  |  | 41.4 |  |  | 4.4 |  |
| Consulting and Network Design |  | 15.1 |  |  | 1.3 |  |  | 13.3 |  |  | 1.4 |  |
| Total Global Services |  | 127.8 |  |  | 11.3 |  |  | 128.7 |  |  | 13.6 |  |
| Total |  | $ | 1,132.7 |  |  | 100.0 |  |  | $ | 949.2 |  |  | 100.0 |  |

[0000936395-23-000024:8k_2_02:18]
**  Denotes %  of total revenue

[0000936395-23-000024:8k_2_02:19]
Additional Performance Metrics for Fiscal Second Quarter 2023

[0000936395-23-000024:8k_2_02:20]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q2 FY 2023 |  | Q2 FY 2022 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 794.4 |  |  | 70.1 |  |  | $ | 700.8 |  |  | 73.8 |  |
| Europe, Middle East and Africa |  | 173.4 |  |  | 15.3 |  |  | 145.1 |  |  | 15.3 |  |
| Asia Pacific |  | 164.9 |  |  | 14.6 |  |  | 103.3 |  |  | 10.9 |  |
| Total |  | $ | 1,132.7 |  |  | 100.0 |  |  | $ | 949.2 |  |  | 100.0 |  |

[0000936395-23-000024:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-23-000024:8k_2_02:22]
•One customer represented 10%-plus of revenue for a total of 10.9% of revenue

[0000936395-23-000024:8k_2_02:23]
2

[0000936395-23-000024:8k_2_02:24]
•Cash and investments totaled $1.34 billion

[0000936395-23-000024:8k_2_02:25]
•Cash flow from operations totaled $229.8 million

[0000936395-23-000024:8k_2_02:26]
•Average days' sales outstanding (DSOs) were 97

[0000936395-23-000024:8k_2_02:27]
•Accounts receivable, net balance was $1.04 billion

[0000936395-23-000024:8k_2_02:28]
•Unbilled contract assets, net balance was $180.0 million

[0000936395-23-000024:8k_2_02:29]
•Inventories totaled $1.10 billion, including:

[0000936395-23-000024:8k_2_02:30]
◦Raw materials: $753.4 million

[0000936395-23-000024:8k_2_02:31]
◦Work in process: $20.9 million

[0000936395-23-000024:8k_2_02:32]
◦Finished goods: $308.0 million

[0000936395-23-000024:8k_2_02:33]
◦Deferred cost of sales: $58.1 million

[0000936395-23-000024:8k_2_02:34]
◦Reserve for excess and obsolescence: $(42.3) million

[0000936395-23-000024:8k_2_02:35]
•Product inventory turns were 2.0

[0000936395-23-000024:8k_2_02:36]
•Headcount totaled 8,385

[0000936395-23-000024:8k_2_02:37]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Second Quarter 2023 Results

[0000936395-23-000024:8k_2_02:38]
Today, Tuesday, June 6, 2023, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal second quarter 2023 results.

[0000936395-23-000024:8k_2_02:39]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-23-000024:8k_2_02:40]
Notes to Investors

[0000936395-23-000024:8k_2_02:41]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered outstanding results for the fiscal second quarter as we were able to ship more to customers with continued improvements in supply chain dynamics, We are confident in our ability to take market share given our backlog and strategic industry position with market-leading technologies and an expanding addressable market."

[0000936395-23-000024:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the impact of supply chain constraints or disruptions; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical events, including but not limited to

[0000936395-23-000024:8k_2_02:43]
the ongoing conflict between Ukraine and Russia, and public health emergencies; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena’s Annual Report on Form 10-K filed with the SEC on December 16, 2022 and included in its Quarterly Report on Form 10-Q for the second quarter of fiscal 2023 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-23-000024:8k_2_02:44]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-23-000024:8k_2_02:45]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-23-000024:8k_2_02:46]
4

[0000936395-23-000024:8k_2_02:47]
CIENA CORPORATION

[0000936395-23-000024:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-23-000024:8k_2_02:49]
(in thousands, except per share data)

[0000936395-23-000024:8k_2_02:50]
(unaudited)

[0000936395-23-000024:8k_2_02:51]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 935,330 |  |  | $ | 759,948 |  |  | $ | 1,813,045 |  |  | $ | 1,424,955 |  |
| Services | 197,325 |  |  | 189,279 |  |  | 376,131 |  |  | 368,715 |  |
| Total revenue | 1,132,655 |  |  | 949,227 |  |  | 2,189,176 |  |  | 1,793,670 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 541,883 |  |  | 452,057 |  |  | 1,042,220 |  |  | 824,622 |  |
| Services | 103,089 |  |  | 95,389 |  |  | 203,327 |  |  | 183,080 |  |
| Total cost of goods sold | 644,972 |  |  | 547,446 |  |  | 1,245,547 |  |  | 1,007,702 |  |
| Gross profit | 487,683 |  |  | 401,781 |  |  | 943,629 |  |  | 785,968 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 189,993 |  |  | 159,324 |  |  | 371,723 |  |  | 307,733 |  |
| Selling and marketing | 125,083 |  |  | 119,939 |  |  | 248,890 |  |  | 238,820 |  |
| General and administrative | 50,939 |  |  | 45,572 |  |  | 101,835 |  |  | 90,070 |  |
| Significant asset impairments and restructuring costs | 8,153 |  |  | 9,102 |  |  | 12,451 |  |  | 12,511 |  |
| Amortization of intangible assets | 9,845 |  |  | 8,920 |  |  | 17,286 |  |  | 17,838 |  |
| Acquisition and integration costs | 857 |  |  | 495 |  |  | 3,415 |  |  | 563 |  |
| Total operating expenses | 384,870 |  |  | 343,352 |  |  | 755,600 |  |  | 667,535 |  |
| Income from operations | 102,813 |  |  | 58,429 |  |  | 188,029 |  |  | 118,433 |  |
| Interest and other income, net | 8,551 |  |  | 808 |  |  | 40,524 |  |  | 4,494 |  |
| Interest expense | (23,889) |  |  | (11,985) |  |  | (39,759) |  |  | (20,633) |  |
| Income before income taxes | 87,475 |  |  | 47,252 |  |  | 188,794 |  |  | 102,294 |  |
| Provision for income taxes | 29,821 |  |  | 8,330 |  |  | 54,899 |  |  | 17,549 |  |
| Net income | $ | 57,654 |  |  | $ | 38,922 |  |  | $ | 133,895 |  |  | $ | 84,745 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.39 |  |  | $ | 0.26 |  |  | $ | 0.90 |  |  | $ | 0.55 |  |
| Diluted net income per potential common share | $ | 0.38 |  |  | $ | 0.25 |  |  | $ | 0.89 |  |  | $ | 0.55 |  |
| Weighted average basic common shares outstanding | 149,616 |  |  | 152,197 |  |  | 149,351 |  |  | 153,179 |  |
| Weighted average dilutive potential common shares outstanding 1 | 150,147 |  |  | 153,344 |  |  | 149,852 |  |  | 154,580 |  |

[0000936395-23-000024:8k_2_02:52]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million shares for both the second quarter and first six months of fiscal 2023; and (ii) 1.1 million and 1.4 million shares for the second quarter and first six months of fiscal 2022, respectively.

[0000936395-23-000024:8k_2_02:53]
CIENA CORPORATION

[0000936395-23-000024:8k_2_02:54]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-23-000024:8k_2_02:55]
(in thousands, except share data)

[0000936395-23-000024:8k_2_02:56]
(unaudited)

[0000936395-23-000024:8k_2_02:57]
|  | April 29,2023 |  | October 29,2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,167,695 |  |  | $ | 994,352 |  |
| Short-term investments | 150,464 |  |  | 153,989 |  |
| Accounts receivable, net | 1,036,688 |  |  | 920,772 |  |
| Inventories | 1,098,092 |  |  | 946,730 |  |
| Prepaid expenses and other | 415,687 |  |  | 370,053 |  |
| Total current assets | 3,868,626 |  |  | 3,385,896 |  |
| Long-term investments | 25,237 |  |  | 35,385 |  |
| Equipment, building, furniture and fixtures, net | 278,344 |  |  | 267,779 |  |
| Operating lease right-of-use assets | 41,119 |  |  | 45,108 |  |
| Goodwill | 446,364 |  |  | 328,322 |  |
| Other intangible assets, net | 231,314 |  |  | 69,517 |  |
| Deferred tax asset, net | 795,051 |  |  | 824,008 |  |
| Other long-term assets | 89,583 |  |  | 113,617 |  |
| Total assets | $ | 5,775,638 |  |  | $ | 5,069,632 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 444,769 |  |  | $ | 516,047 |  |
| Accrued liabilities and other short-term obligations | 380,969 |  |  | 360,782 |  |
| Deferred revenue | 202,818 |  |  | 137,899 |  |
| Operating lease liabilities | 17,443 |  |  | 18,925 |  |
| Current portion of long-term debt | 11,930 |  |  | 6,930 |  |
| Total current liabilities | 1,057,929 |  |  | 1,040,583 |  |
| Long-term deferred revenue | 67,807 |  |  | 62,336 |  |
| Other long-term obligations | 154,870 |  |  | 150,335 |  |
| Long-term operating lease liabilities | 39,979 |  |  | 42,392 |  |
| Long-term debt, net | 1,546,400 |  |  | 1,061,125 |  |
| Total liabilities | $ | 2,866,985 |  |  | $ | 2,356,771 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 149,498,465 and 148,412,943 shares issued and outstanding | 1,495 |  |  | 1,484 |  |
| Additional paid-in capital | 6,445,247 |  |  | 6,390,252 |  |
| Accumulated other comprehensive loss | (39,754) |  |  | (46,645) |  |
| Accumulated deficit | (3,498,335) |  |  | (3,632,230) |  |
| Total stockholders’ equity | 2,908,653 |  |  | 2,712,861 |  |
| Total liabilities and stockholders’ equity | $ | 5,775,638 |  |  | $ | 5,069,632 |  |

[0000936395-23-000024:8k_2_02:58]
6

[0000936395-23-000024:8k_2_02:59]
CIENA CORPORATION

[0000936395-23-000024:8k_2_02:60]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-23-000024:8k_2_02:61]
(in thousands) (unaudited)

[0000936395-23-000024:8k_2_02:62]
|  | Six Months Ended |
|  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income | $ | 133,895 |  |  | $ | 84,745 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 45,903 |  |  | 46,030 |  |
| Share-based compensation expense | 62,372 |  |  | 50,970 |  |
| Amortization of intangible assets | 23,600 |  |  | 24,463 |  |
| Deferred taxes | (2,134) |  |  | (13,474) |  |
| Provision for inventory excess and obsolescence | 12,691 |  |  | 8,487 |  |
| Provision for warranty | 13,577 |  |  | 7,228 |  |
| Gain on cost method equity investment | (26,455) |  |  | (4,120) |  |
| Other | 11,331 |  |  | (1,713) |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (116,914) |  |  | 104,455 |  |
| Inventories | (162,143) |  |  | (171,056) |  |
| Prepaid expenses and other | (41,511) |  |  | (36,673) |  |
| Operating lease right-of-use assets | 7,644 |  |  | 8,222 |  |
| Accounts payable, accruals and other obligations | (55,754) |  |  | (88,960) |  |
| Deferred revenue | 68,818 |  |  | 43,753 |  |
| Short and long-term operating lease liabilities | (10,748) |  |  | (10,216) |  |
| Net cash provided by (used in) operating activities | (35,828) |  |  | 52,141 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (58,034) |  |  | (45,249) |  |
| Purchases of investments | (106,245) |  |  | (461,553) |  |
| Proceeds from sales and maturities of investments | 123,251 |  |  | 90,005 |  |
| Settlement of foreign currency forward contracts, net | (6,194) |  |  | 3,708 |  |
| Purchase of cost method equity investments | — |  |  | (8,000) |  |
| Acquisition of business, net of cash acquired | (230,048) |  |  | (62,043) |  |
| Net cash used in investing activities | (277,270) |  |  | (483,132) |  |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of senior notes | — |  |  | 400,000 |  |
| Proceeds from issuance of term loan, net | 497,500 |  |  | — |  |
| Payment of long term debt | (3,465) |  |  | (3,465) |  |
| Payment of debt issuance costs | (5,230) |  |  | (5,145) |  |
| Payment of finance lease obligations | (1,864) |  |  | (1,635) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (22,022) |  |  | (35,004) |  |
| Repurchases of common stock - repurchase program | — |  |  | (332,794) |  |
| Proceeds from issuance of common stock | 14,656 |  |  | 15,185 |  |
| Net cash provided by financing activities | 479,575 |  |  | 37,142 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 6,867 |  |  | (8,807) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 173,344 |  |  | (402,656) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 994,378 |  |  | 1,422,604 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,167,722 |  |  | $ | 1,019,948 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 37,514 |  |  | $ | 16,809 |  |
| Cash paid during the period for income taxes, net | $ | 24,218 |  |  | $ | 17,905 |  |
| Operating lease payments | $ | 11,689 |  |  | $ | 10,917 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,618 |  |  | $ | 8,093 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | — |  |  | $ | 5,000 |  |
| Operating right-of-use assets subject to lease liability | $ | 6,177 |  |  | $ | 3,589 |  |
| Gain on cost method equity investment | $ | 26,455 |  |  | $ | 4,120 |  |

[0000936395-23-000024:8k_2_02:63]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | April 29, |  | April 30, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 487,683 |  |  | $ | 401,781 |  |  |  |  |  |
| Share-based compensation-products |  | 1,155 |  |  | 1,058 |  |  |  |  |  |
| Share-based compensation-services |  | 2,659 |  |  | 1,943 |  |  |  |  |  |
| Amortization of intangible assets |  | 3,431 |  |  | 3,313 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,245 |  |  | 6,314 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 494,928 |  |  | $ | 408,095 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.7 | % |  | 43.0 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 384,870 |  |  | $ | 343,352 |  |  |  |  |  |
| Share-based compensation-research and development |  | 10,731 |  |  | 8,309 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 8,755 |  |  | 8,061 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 8,468 |  |  | 7,334 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 8,153 |  |  | 9,102 |  |  |  |  |  |
| Amortization of intangible assets |  | 9,845 |  |  | 8,920 |  |  |  |  |  |
| Acquisition and integration costs |  | 857 |  |  | 495 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 46,809 |  |  | 42,221 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 338,061 |  |  | $ | 301,131 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 102,813 |  |  | $ | 58,429 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 7,245 |  |  | 6,314 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 46,809 |  |  | 42,221 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 54,054 |  |  | 48,535 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 156,867 |  |  | $ | 106,964 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.8 | % |  | 11.3 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 57,654 |  |  | $ | 38,922 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 29,821 |  |  | 8,330 |  |  |  |  |  |
| Income before income taxes |  | 87,475 |  |  | 47,252 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 54,054 |  |  | 48,535 |  |  |  |  |  |
| Adjusted income before income taxes |  | 141,529 |  |  | 95,787 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 31,136 |  |  | 19,349 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 110,393 |  |  | $ | 76,438 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 149,616 |  | 152,197 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 150,147 |  | 153,344 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.38 |  |  | $ | 0.25 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.74 |  |  | $ | 0.50 |  |  |  |  |  |

[0000936395-23-000024:8k_2_02:64]
8

[0000936395-23-000024:8k_2_02:65]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.5 million for the second quarter of fiscal 2023; and (ii) 1.1 million for the second quarter of fiscal 2022.

[0000936395-23-000024:8k_2_02:66]
9

[0000936395-23-000024:8k_2_02:67]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | April 29, |  | April 30, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 57,654 |  |  | $ | 38,922 |  |  |  |  |  |
| Add: Interest expense |  | 23,889 |  |  | 11,985 |  |  |  |  |  |
| Less: Interest and other income, net |  | 8,551 |  |  | 808 |  |  |  |  |  |
| Add: Provision for income taxes |  | 29,821 |  |  | 8,330 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,695 |  |  | 22,377 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 13,275 |  |  | 12,233 |  |  |  |  |  |
| EBITDA |  | $ | 139,783 |  |  | $ | 93,039 |  |  |  |  |  |
| Add: Share-based compensation cost |  | 31,768 |  |  | 26,673 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 8,153 |  |  | 9,102 |  |  |  |  |  |
| Add: Acquisition and integration costs |  | 857 |  |  | 495 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 180,561 |  |  | $ | 129,309 |  |  |  |  |  |

[0000936395-23-000024:8k_2_02:68]
* * *

[0000936395-23-000024:8k_2_02:69]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-23-000024:8k_2_02:70]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-23-000024:8k_2_02:71]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, and the redesign of business processes including restructuring certain real estate facilities.

[0000936395-23-000024:8k_2_02:72]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-23-000024:8k_2_02:73]
•Acquisition and integration costs  - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2022 and fiscal 2023.

[0000936395-23-000024:8k_2_02:74]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for the second fiscal quarter of 2023 and 20.2% for the second fiscal quarter of 2022. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
