# CIEN 8-K — 0000936395-24-000037 filed 2024-12-12

## item codes, every 8-K on or before 2024-12-20

- 2024-12-12 0000936395-24-000037 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2024-10-02 0000936395-24-000035 — 8.01, 9.01
- 2024-09-04 0000936395-24-000030 — 2.02, 5.02, 9.01
- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2024-12-20

- none on or before 2024-12-20

## item 2.02 — earnings release, exhibit 99.1

[0000936395-24-000037:8k_2_02:1]
EX-99.1
3
ex9912024q4earningspressre.htm
EX-99.1

[0000936395-24-000037:8k_2_02:2]
Document

[0000936395-24-000037:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-24-000037:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2024 Financial Results

[0000936395-24-000037:8k_2_02:5]
HANOVER, Md. - December 12, 2024 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter ended November 2, 2024.

[0000936395-24-000037:8k_2_02:6]
•Q4 Revenue: $1.12 billion

[0000936395-24-000037:8k_2_02:7]
•Q4 Net Income per Share: $0.25 GAAP; $0.54 adjusted (non-GAAP)

[0000936395-24-000037:8k_2_02:8]
•Share Repurchases: Repurchased approximately 2.1 million shares of common stock for an aggregate price of $132.0 million during the quarter

[0000936395-24-000037:8k_2_02:9]
"Our Q4 revenue and strong order flow reflect our significant and increasing technology leadership and positive industry dynamics," said Gary Smith, president and CEO, Ciena. "As Cloud and AI drive bandwidth demand across the network, we are positioned for accelerated revenue growth and market share expansion moving forward."

[0000936395-24-000037:8k_2_02:10]
For fiscal fourth quarter 2024, Ciena reported revenue of $1.12 billion as compared to $1.13 billion for the fiscal fourth quarter 2023. For fiscal year 2024, Ciena reported revenue of $4.01 billion, as compared to $4.39 billion for fiscal year 2023.

[0000936395-24-000037:8k_2_02:11]
Ciena's GAAP net income for the fiscal fourth quarter 2024 was $37.0 million, or $0.25 per diluted common share, which compares to a GAAP net income of $91.2 million, or $0.62 per diluted common share, for the fiscal fourth quarter 2023. For fiscal year 2024, Ciena's GAAP net income was $84.0 million, or $0.58 per diluted common share, as compared to GAAP net income of $254.8 million, or $1.71 per diluted common share, for fiscal year 2023.

[0000936395-24-000037:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2024 was $79.3 million, or $0.54 per diluted common share, which compares to an adjusted (non-GAAP) net income of $111.2 million, or $0.75 per diluted common share, for the fiscal fourth quarter 2023. For fiscal year 2024, Ciena's adjusted (non-GAAP) net income was $266.3 million, or $1.82 per diluted common share, as compared to adjusted (non-GAAP) net income of $406.3 million, or $2.72 per diluted common share, for fiscal year 2023.

[0000936395-24-000037:8k_2_02:13]
Performance Summary For Fiscal Fourth Quarter and Year Ended November 2, 2024

[0000936395-24-000037:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-24-000037:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | November 2, |  | October 28, |  | Change |  | November 2, |  | October 28, |  | Change |
|  |  | 2024 |  | 2023 |  | Y-T-Y* |  | 2024 |  | 2023 |  | Y-T-Y* |
| Revenue |  | $ | 1,124.1 |  |  | $ | 1,129.5 |  |  | (0.5) | % |  | $ | 4,014.9 |  |  | $ | 4,386.5 |  |  | (8.5) | % |
| Gross margin |  | 40.9 | % |  | 43.1 | % |  | (2.2) | % |  | 42.8 | % |  | 42.8 | % |  | — | % |
| Operating expense |  | $ | 400.8 |  |  | $ | 395.0 |  |  | 1.5 | % |  | $ | 1,553.0 |  |  | $ | 1,521.3 |  |  | 2.1 | % |
| Operating margin |  | 5.3 | % |  | 8.1 | % |  | (2.8) | % |  | 4.1 | % |  | 8.2 | % |  | (4.1) | % |

[0000936395-24-000037:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | November 2, |  | October 28, |  | Change |  | November 2, |  | October 28, |  | Change |
|  |  | 2024 |  | 2023 |  | Y-T-Y* |  | 2024 |  | 2023 |  | Y-T-Y* |
| Revenue |  | $ | 1,124.1 |  |  | $ | 1,129.5 |  |  | (0.5) | % |  | $ | 4,014.9 |  |  | $ | 4,386.5 |  |  | (8.5) | % |
| Adj. gross margin |  | 41.6 | % |  | 43.7 | % |  | (2.1) | % |  | 43.6 | % |  | 43.5 | % |  | 0.1 | % |
| Adj. operating expense |  | $ | 354.9 |  |  | $ | 337.6 |  |  | 5.1 | % |  | $ | 1,361.7 |  |  | $ | 1,332.8 |  |  | 2.2 | % |
| Adj. operating margin |  | 10.0 | % |  | 13.8 | % |  | (3.8) | % |  | 9.7 | % |  | 13.1 | % |  | (3.4) | % |
| Adj. EBITDA |  | $ | 136.7 |  |  | $ | 178.8 |  |  | (23.5) | % |  | $ | 481.0 |  |  | $ | 665.8 |  |  | (27.8) | % |

[0000936395-24-000037:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-24-000037:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | November 2, 2024 |  | October 28, 2023 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 779.6 |  |  | 69.4 |  |  | $ | 748.0 |  |  | 66.2 |  |
| Routing and Switching |  | 79.4 |  |  | 7.0 |  |  | 128.9 |  |  | 11.4 |  |
| Total Networking Platforms |  | 859.0 |  |  | 76.4 |  |  | 876.9 |  |  | 77.6 |  |
| Platform Software and Services |  | 99.6 |  |  | 8.9 |  |  | 82.1 |  |  | 7.3 |  |
| Blue Planet Automation Software and Services |  | 23.5 |  |  | 2.1 |  |  | 20.0 |  |  | 1.8 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 77.2 |  |  | 6.9 |  |  | 74.4 |  |  | 6.6 |  |
| Installation and Deployment |  | 51.4 |  |  | 4.5 |  |  | 60.1 |  |  | 5.3 |  |
| Consulting and Network Design |  | 13.4 |  |  | 1.2 |  |  | 16.0 |  |  | 1.4 |  |
| Total Global Services |  | 142.0 |  |  | 12.6 |  |  | 150.5 |  |  | 13.3 |  |
| Total |  | $ | 1,124.1 |  |  | 100.0 |  |  | $ | 1,129.5 |  |  | 100.0 |  |

[0000936395-24-000037:8k_2_02:19]
2

[0000936395-24-000037:8k_2_02:20]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | November 2, 2024 |  | October 28, 2023 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 2,642.6 |  |  | 65.8 |  |  | $ | 2,987.3 |  |  | 68.1 |  |
| Routing and Switching |  | 399.5 |  |  | 10.0 |  |  | 506.2 |  |  | 11.5 |  |
| Total Networking Platforms |  | 3,042.1 |  |  | 75.8 |  |  | 3,493.5 |  |  | 79.6 |  |
| Platform Software and Services |  | 358.0 |  |  | 8.9 |  |  | 303.9 |  |  | 6.9 |  |
| Blue Planet Automation Software and Services |  | 77.6 |  |  | 2.0 |  |  | 69.1 |  |  | 1.6 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 303.1 |  |  | 7.5 |  |  | 288.3 |  |  | 6.6 |  |
| Installation and Deployment |  | 184.3 |  |  | 4.6 |  |  | 181.0 |  |  | 4.1 |  |
| Consulting and Network Design |  | 49.8 |  |  | 1.2 |  |  | 50.7 |  |  | 1.2 |  |
| Total Global Services |  | 537.2 |  |  | 13.3 |  |  | 520.0 |  |  | 11.9 |  |
| Total |  | $ | 4,014.9 |  |  | 100.0 |  |  | $ | 4,386.5 |  |  | 100.0 |  |

[0000936395-24-000037:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-24-000037:8k_2_02:22]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended November 2, 2024

[0000936395-24-000037:8k_2_02:23]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended |
|  |  | November 2, 2024 |  | October 28, 2023 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 852.2 |  |  | 75.8 |  |  | $ | 801.4 |  |  | 71.0 |  |
| Europe, Middle East and Africa |  | 150.7 |  |  | 13.4 |  |  | 164.1 |  |  | 14.5 |  |
| Asia Pacific |  | 121.2 |  |  | 10.8 |  |  | 164.0 |  |  | 14.5 |  |
| Total |  | $ | 1,124.1 |  |  | 100.0 |  |  | $ | 1,129.5 |  |  | 100.0 |  |

[0000936395-24-000037:8k_2_02:24]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended |
|  |  | November 2, 2024 |  | October 28, 2023 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 2,951.9 |  |  | 73.5 |  |  | $ | 3,110.3 |  |  | 70.9 |  |
| Europe, Middle East and Africa |  | 648.9 |  |  | 16.2 |  |  | 643.1 |  |  | 14.7 |  |
| Asia Pacific |  | 414.1 |  |  | 10.3 |  |  | 633.1 |  |  | 14.4 |  |
| Total |  | $ | 4,014.9 |  |  | 100.0 |  |  | $ | 4,386.5 |  |  | 100.0 |  |

[0000936395-24-000037:8k_2_02:25]
**  Denotes %  of total revenue

[0000936395-24-000037:8k_2_02:26]
•Two customers represented 10%-plus of revenue for the fiscal fourth quarter 2024 and the fiscal year 2024, combining for a total of 31.2% and 25.1% of revenue, respectively.

[0000936395-24-000037:8k_2_02:27]
•Cash and investments at the end of fiscal year 2024 totaled $1.33 billion

[0000936395-24-000037:8k_2_02:28]
•Cash flow from operations totaled $349.3 million and $514.5 million for the fiscal fourth quarter and the fiscal year 2024, respectively

[0000936395-24-000037:8k_2_02:29]
•Average days' sales outstanding (DSOs) were 89 and 96 for the fiscal fourth quarter and the fiscal year 2024, respectively

[0000936395-24-000037:8k_2_02:30]
•Accounts receivable, net balance was $908.6 million

[0000936395-24-000037:8k_2_02:31]
•Unbilled contract assets, net balance was $127.9 million

[0000936395-24-000037:8k_2_02:32]
•Inventories totaled $820.4 million, including:

[0000936395-24-000037:8k_2_02:33]
◦Raw materials: $542.8 million

[0000936395-24-000037:8k_2_02:34]
◦Work in process: $32.2 million

[0000936395-24-000037:8k_2_02:35]
◦Finished goods: $324.7 million

[0000936395-24-000037:8k_2_02:36]
◦Deferred cost of sales: $27.9 million

[0000936395-24-000037:8k_2_02:37]
◦Reserve for excess and obsolescence: $(107.2) million

[0000936395-24-000037:8k_2_02:38]
•Product inventory turns were 2.7 and 2.3 for the fiscal fourth quarter and the fiscal year 2024, respectively

[0000936395-24-000037:8k_2_02:39]
•Headcount totaled 8,657 at the end of fiscal year 2024

[0000936395-24-000037:8k_2_02:40]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2024 Results

[0000936395-24-000037:8k_2_02:41]
Today, Thursday, December 12, 2024, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter 2024 results.

[0000936395-24-000037:8k_2_02:42]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-24-000037:8k_2_02:43]
Notes to Investors

[0000936395-24-000037:8k_2_02:44]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our Q4 revenue and strong order flow reflect our significant and increasing technology leadership and positive industry dynamics. As Cloud and AI drive bandwidth demand across the network, we are positioned for accelerated revenue growth and market share expansion moving forward."

[0000936395-24-000037:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers, their spending and their businesses and markets; our ability to execute our business and growth strategies; the impact of macroeconomic conditions and global supply chain constraints or disruptions including increased supply costs and lead times; the impact of the introduction of new technologies by us or our competitors; seasonality and the timing and size of customer orders, their delivery dates

[0000936395-24-000037:8k_2_02:46]
and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, including but not limited to the ongoing conflicts between Ukraine and Russia, and Israel and Hamas, and public health emergencies or epidemics, including the COVID-19 pandemic; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena's Quarterly Report on Form 10-Q filed with the SEC on September 4, 2024 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-24-000037:8k_2_02:47]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-24-000037:8k_2_02:48]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on LinkedIn, X, the

[0000936395-24-000037:8k_2_02:49]
Ciena Insights blog, or visit www.ciena.com.

[0000936395-24-000037:8k_2_02:50]
5

[0000936395-24-000037:8k_2_02:51]
CIENA CORPORATION

[0000936395-24-000037:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-24-000037:8k_2_02:53]
(in thousands, except per share data)

[0000936395-24-000037:8k_2_02:54]
(unaudited)

[0000936395-24-000037:8k_2_02:55]
|  | Quarter Ended |  | Twelve Months Ended |
|  | November 2, |  | October 28, |  | November 2, |  | October 28, |
|  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 892,425 |  |  | $ | 902,797 |  |  | $ | 3,159,021 |  |  | $ | 3,581,039 |  |
| Services | 231,687 |  |  | 226,690 |  |  | 855,934 |  |  | 805,510 |  |
| Total revenue | 1,124,112 |  |  | 1,129,487 |  |  | 4,014,955 |  |  | 4,386,549 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 545,580 |  |  | 529,320 |  |  | 1,861,317 |  |  | 2,088,440 |  |
| Services | 118,510 |  |  | 113,886 |  |  | 434,048 |  |  | 419,258 |  |
| Total cost of goods sold | 664,090 |  |  | 643,206 |  |  | 2,295,365 |  |  | 2,507,698 |  |
| Gross profit | 460,022 |  |  | 486,281 |  |  | 1,719,590 |  |  | 1,878,851 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 195,960 |  |  | 189,444 |  |  | 767,497 |  |  | 750,559 |  |
| Selling and marketing | 136,919 |  |  | 123,648 |  |  | 510,668 |  |  | 490,804 |  |
| General and administrative | 58,143 |  |  | 64,100 |  |  | 220,647 |  |  | 215,284 |  |
| Significant asset impairments and restructuring costs | 2,605 |  |  | 7,209 |  |  | 24,592 |  |  | 23,834 |  |
| Amortization of intangible assets | 7,185 |  |  | 10,578 |  |  | 29,569 |  |  | 37,351 |  |
| Acquisition and integration costs | — |  |  | — |  |  | — |  |  | 3,474 |  |
| Total operating expenses | 400,812 |  |  | 394,979 |  |  | 1,552,973 |  |  | 1,521,306 |  |
| Income from operations | 59,210 |  |  | 91,302 |  |  | 166,617 |  |  | 357,545 |  |
| Interest and other income, net | 13,801 |  |  | 11,297 |  |  | 50,261 |  |  | 62,008 |  |
| Interest expense | (24,990) |  |  | (24,207) |  |  | (97,028) |  |  | (88,026) |  |
| Loss on extinguishment and modification of debt | — |  |  | (7,874) |  |  | — |  |  | (7,874) |  |
| Income before income taxes | 48,021 |  |  | 70,518 |  |  | 119,850 |  |  | 323,653 |  |
| Provision (benefit) for income taxes 1 | 10,993 |  |  | (20,681) |  |  | 35,894 |  |  | 68,826 |  |
| Net income | $ | 37,028 |  |  | $ | 91,199 |  |  | $ | 83,956 |  |  | $ | 254,827 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.26 |  |  | $ | 0.62 |  |  | $ | 0.58 |  |  | $ | 1.71 |  |
| Diluted net income per potential common share | $ | 0.25 |  |  | $ | 0.62 |  |  | $ | 0.58 |  |  | $ | 1.71 |  |
| Weighted average basic common shares outstanding | 144,240 |  |  | 147,437 |  |  | 144,715 |  |  | 148,971 |  |
| Weighted average dilutive potential common shares outstanding 2 | 146,487 |  |  | 147,891 |  |  | 145,964 |  |  | 149,380 |  |

[0000936395-24-000037:8k_2_02:56]
1 For the fourth quarter and year ended fiscal 2023, reflects a tax benefit resulting, in part, from guidance in Notice 2023-63 issued by the IRS addressing capitalization and amortization of specified research or experimental expenditures under Section 174 in accordance with the Tax Cuts and Jobs Act.

[0000936395-24-000037:8k_2_02:57]
2 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 2.2 million and 1.2 million for the fourth quarter and year ended fiscal 2024, respectively, and (ii) 0.5 million and 0.4 million for the fourth quarter and year ended fiscal 2023, respectively.

[0000936395-24-000037:8k_2_02:58]
CIENA CORPORATION

[0000936395-24-000037:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-24-000037:8k_2_02:60]
(in thousands, except share data)

[0000936395-24-000037:8k_2_02:61]
(unaudited)

[0000936395-24-000037:8k_2_02:62]
|  | November 2,2024 |  | October 28,2023 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 934,863 |  |  | $ | 1,010,618 |  |
| Short-term investments | 316,343 |  |  | 104,753 |  |
| Accounts receivable, net | 908,597 |  |  | 1,003,876 |  |
| Inventories, net | 820,430 |  |  | 1,050,838 |  |
| Prepaid expenses and other | 564,183 |  |  | 405,694 |  |
| Total current assets | 3,544,416 |  |  | 3,575,779 |  |
| Long-term investments | 80,920 |  |  | 134,278 |  |
| Equipment, building, furniture and fixtures, net | 337,722 |  |  | 280,147 |  |
| Operating lease right-of-use assets | 27,417 |  |  | 35,140 |  |
| Goodwill | 444,707 |  |  | 444,765 |  |
| Other intangible assets, net | 165,020 |  |  | 205,627 |  |
| Deferred tax asset, net | 886,441 |  |  | 809,306 |  |
| Other long-term assets | 154,694 |  |  | 116,453 |  |
| Total assets | $ | 5,641,337 |  |  | $ | 5,601,495 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 423,401 |  |  | $ | 317,828 |  |
| Accrued liabilities and other short-term obligations | 393,905 |  |  | 431,419 |  |
| Deferred revenue | 156,379 |  |  | 154,419 |  |
| Operating lease liabilities | 14,455 |  |  | 16,655 |  |
| Current portion of long-term debt | 11,700 |  |  | 11,700 |  |
| Total current liabilities | 999,840 |  |  | 932,021 |  |
| Long-term deferred revenue | 81,240 |  |  | 74,041 |  |
| Other long-term obligations | 185,938 |  |  | 170,407 |  |
| Long-term operating lease liabilities | 25,107 |  |  | 33,259 |  |
| Long-term debt, net | 1,533,074 |  |  | 1,543,406 |  |
| Total liabilities | 2,825,199 |  |  | 2,753,134 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 142,656,116 and 144,829,938 shares issued and outstanding | 1,427 |  |  | 1,448 |  |
| Additional paid-in capital | 6,154,869 |  |  | 6,262,083 |  |
| Accumulated other comprehensive loss | (46,711) |  |  | (37,767) |  |
| Accumulated deficit | (3,293,447) |  |  | (3,377,403) |  |
| Total stockholders’ equity | 2,816,138 |  |  | 2,848,361 |  |
| Total liabilities and stockholders’ equity | $ | 5,641,337 |  |  | $ | 5,601,495 |  |

[0000936395-24-000037:8k_2_02:63]
7

[0000936395-24-000037:8k_2_02:64]
CIENA CORPORATION

[0000936395-24-000037:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-24-000037:8k_2_02:66]
(in thousands) (unaudited)

[0000936395-24-000037:8k_2_02:67]
|  | Year Ended |
|  | November 2, |  | October 28, |
|  | 2024 |  | 2023 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 83,956 |  |  | $ | 254,827 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on extinguishment of debt | — |  |  | 1,864 |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 92,846 |  |  | 92,564 |  |
| Share-based compensation expense | 156,404 |  |  | 130,455 |  |
| Amortization of intangible assets | 40,624 |  |  | 49,616 |  |
| Deferred taxes | (76,810) |  |  | (14,852) |  |
| Provision for inventory excess and obsolescence | 77,341 |  |  | 29,464 |  |
| Provision for warranty | 25,643 |  |  | 31,742 |  |
| Gain on equity investments, net | — |  |  | (26,368) |  |
| Other | 11,768 |  |  | 15,771 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 80,313 |  |  | (94,565) |  |
| Inventories | 153,021 |  |  | (132,497) |  |
| Prepaid expenses and other | (198,910) |  |  | (51,965) |  |
| Operating lease right-of-use assets | 11,837 |  |  | 14,190 |  |
| Accounts payable, accruals and other obligations | 64,255 |  |  | (138,469) |  |
| Deferred revenue | 9,884 |  |  | 27,412 |  |
| Short and long-term operating lease liabilities | (17,640) |  |  | (20,857) |  |
| Net cash provided by operating activities | 514,532 |  |  | 168,332 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (136,641) |  |  | (106,197) |  |
| Purchases of investments | (287,536) |  |  | (252,329) |  |
| Proceeds from sales and maturities of investments | 140,836 |  |  | 208,104 |  |
| Settlement of foreign currency forward contracts, net | (1,454) |  |  | (2,984) |  |
| Purchase of equity investments | (21,682) |  |  | — |  |
| Acquisition of business, net of cash acquired | — |  |  | (230,048) |  |
| Net cash used in investing activities | (306,477) |  |  | (383,454) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | — |  |  | 497,500 |  |
| Payment of long term debt | (11,700) |  |  | (9,430) |  |
| Proceeds for modification of term loan | — |  |  | 830 |  |
| Payment of debt issuance costs | (2,554) |  |  | (6,379) |  |
| Payment of finance lease obligations | (4,029) |  |  | (3,791) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (46,567) |  |  | (38,506) |  |
| Repurchases of common stock - repurchase program, net | (254,502) |  |  | (242,201) |  |
| Proceeds from issuance of common stock | 34,291 |  |  | 31,357 |  |
| Net cash provided by (used in) financing activities | (285,061) |  |  | 229,380 |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 1,246 |  |  | 2,150 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (75,760) |  |  | 16,408 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,010,786 |  |  | 994,378 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 935,026 |  |  | $ | 1,010,786 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 92,515 |  |  | $ | 84,465 |  |
| Cash paid during the period for income taxes, net | $ | 54,956 |  |  | $ | 78,242 |  |
| Operating lease payments | $ | 19,452 |  |  | $ | 22,782 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 14,682 |  |  | $ | 6,990 |  |
| Repurchase of common stock in accrued liabilities from repurchase program, net | $ | 6,172 |  |  | $ | 9,310 |  |
| Operating right-of-use assets subject to lease liability | $ | 6,912 |  |  | $ | 10,236 |  |
| Gain on equity investments, net | $ | — |  |  | $ | 26,368 |  |

[0000936395-24-000037:8k_2_02:68]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | November 2, |  | October 28, |  | November 2, |  | October 28, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 460,022 |  |  | $ | 486,281 |  |  | $ | 1,719,590 |  |  | $ | 1,878,851 |  |
| Share-based compensation-products |  | 1,736 |  |  | 1,194 |  |  | 6,474 |  |  | 4,518 |  |
| Share-based compensation-services |  | 3,257 |  |  | 2,827 |  |  | 12,743 |  |  | 10,470 |  |
| Amortization of intangible assets |  | 2,764 |  |  | 2,763 |  |  | 11,055 |  |  | 12,264 |  |
| Total adjustments related to gross profit |  | 7,757 |  |  | 6,784 |  |  | 30,272 |  |  | 27,252 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 467,779 |  |  | $ | 493,065 |  |  | $ | 1,749,862 |  |  | $ | 1,906,103 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 41.6 | % |  | 43.7 | % |  | 43.6 | % |  | 43.5 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 400,812 |  |  | $ | 394,979 |  |  | $ | 1,552,973 |  |  | $ | 1,521,306 |  |
| Share-based compensation-research and development |  | 14,065 |  |  | 11,412 |  |  | 54,129 |  |  | 42,331 |  |
| Share-based compensation-sales and marketing |  | 11,168 |  |  | 9,187 |  |  | 42,954 |  |  | 35,136 |  |
| Share-based compensation-general and administrative |  | 10,842 |  |  | 10,274 |  |  | 40,053 |  |  | 37,587 |  |
| Significant asset impairments and restructuring costs |  | 2,605 |  |  | 7,209 |  |  | 24,592 |  |  | 23,834 |  |
| Amortization of intangible assets |  | 7,185 |  |  | 10,578 |  |  | 29,569 |  |  | 37,351 |  |
| Acquisition and integration costs |  | — |  |  | — |  |  | — |  |  | 3,474 |  |
| Legal settlement |  | — |  |  | 8,750 |  |  | — |  |  | 8,750 |  |
| Total adjustments related to operating expense |  | 45,865 |  |  | 57,410 |  |  | 191,297 |  |  | 188,463 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 354,947 |  |  | $ | 337,569 |  |  | $ | 1,361,676 |  |  | $ | 1,332,843 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 59,210 |  |  | $ | 91,302 |  |  | $ | 166,617 |  |  | $ | 357,545 |  |
| Total adjustments related to gross profit |  | 7,757 |  |  | 6,784 |  |  | 30,272 |  |  | 27,252 |  |
| Total adjustments related to operating expense |  | 45,865 |  |  | 57,410 |  |  | 191,297 |  |  | 188,463 |  |
| Total adjustments related to income from operations |  | 53,622 |  |  | 64,194 |  |  | 221,569 |  |  | 215,715 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 112,832 |  |  | $ | 155,496 |  |  | $ | 388,186 |  |  | $ | 573,260 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 10.0 | % |  | 13.8 | % |  | 9.7 | % |  | 13.1 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 37,028 |  |  | $ | 91,199 |  |  | $ | 83,956 |  |  | $ | 254,827 |  |
| Exclude GAAP provision (benefit) for income taxes |  | 10,993 |  |  | (20,681) |  |  | 35,894 |  |  | 68,826 |  |
| Income before income taxes |  | 48,021 |  |  | 70,518 |  |  | 119,850 |  |  | 323,653 |  |
| Total adjustments related to income from operations |  | 53,622 |  |  | 64,194 |  |  | 221,569 |  |  | 215,715 |  |
| Loss on extinguishment and modification of debt |  | — |  |  | 7,874 |  |  | — |  |  | 7,874 |  |
| Loss on equity investment |  | — |  |  | — |  |  | — |  |  | (26,368) |  |
| Adjusted income before income taxes |  | 101,643 |  |  | 142,586 |  |  | 341,419 |  |  | 520,874 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 22,361 |  |  | 31,369 |  |  | 75,112 |  |  | 114,592 |  |
| Adjusted (non-GAAP) net income |  | $ | 79,282 |  |  | $ | 111,217 |  |  | $ | 266,307 |  |  | $ | 406,282 |  |

[0000936395-24-000037:8k_2_02:69]
9

[0000936395-24-000037:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | November 2, |  | October 28, |  | November 2, |  | October 28, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Weighted average basic common shares outstanding |  | 144,240 |  | 147,437 |  | 144,715 |  | 148,971 |
| Weighted average dilutive potential common shares outstanding 1 |  | 146,487 |  | 147,891 |  | 145,964 |  | 149,380 |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.25 |  |  | $ | 0.62 |  |  | $ | 0.58 |  |  | $ | 1.71 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.54 |  |  | $ | 0.75 |  |  | $ | 1.82 |  |  | $ | 2.72 |  |

[0000936395-24-000037:8k_2_02:71]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 2.2 million and 1.2 million for the fourth quarter and year ended fiscal 2024; and (ii) 0.5 million and 0.4 million for the fourth quarter and year ended fiscal 2023.

[0000936395-24-000037:8k_2_02:72]
10

[0000936395-24-000037:8k_2_02:73]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | November 2, |  | October 28, |  | November 2, |  | October 28, |
|  |  | 2024 |  | 2023 |  | 2024 |  | 2023 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 37,028 |  |  | $ | 91,199 |  |  | $ | 83,956 |  |  | $ | 254,827 |  |
| Add: Interest expense |  | 24,990 |  |  | 24,207 |  |  | 97,028 |  |  | 88,026 |  |
| Less: Interest and other income, net |  | 13,801 |  |  | 11,297 |  |  | 50,261 |  |  | 62,008 |  |
| Add: Loss on extinguishment and modification of debt |  | — |  |  | 7,874 |  |  | — |  |  | 7,874 |  |
| Add: Provision (benefit) for income taxes |  | 10,993 |  |  | (20,681) |  |  | 35,894 |  |  | 68,826 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,849 |  |  | 23,351 |  |  | 92,846 |  |  | 92,564 |  |
| Add: Amortization of intangible assets |  | 9,949 |  |  | 13,342 |  |  | 40,624 |  |  | 49,616 |  |
| EBITDA |  | $ | 93,008 |  |  | $ | 127,995 |  |  | $ | 300,087 |  |  | $ | 499,725 |  |
| Add: Share-based compensation expense |  | 41,068 |  |  | 34,894 |  |  | 156,353 |  |  | 130,042 |  |
| Add: Significant asset impairments and restructuring costs |  | 2,605 |  |  | 7,209 |  |  | 24,592 |  |  | 23,834 |  |
| Add: Acquisition and integration costs |  | — |  |  | — |  |  | — |  |  | 3,474 |  |
| Add: Legal settlement |  | — |  |  | 8,750 |  |  | — |  |  | 8,750 |  |
| Adjusted EBITDA |  | $ | 136,681 |  |  | $ | 178,848 |  |  | $ | 481,032 |  |  | $ | 665,825 |  |

[0000936395-24-000037:8k_2_02:74]
* * *

[0000936395-24-000037:8k_2_02:75]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-24-000037:8k_2_02:76]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-24-000037:8k_2_02:77]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes and restructuring certain real estate facilities.

[0000936395-24-000037:8k_2_02:78]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0000936395-24-000037:8k_2_02:79]
•Acquisition and integration costs - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2023.

[0000936395-24-000037:8k_2_02:80]
•Loss on extinguishment and modification of debt - reflects extinguishment and debt modification expenses related to refinancing our then existing term loans which occurred during the fourth quarter of fiscal 2023.

[0000936395-24-000037:8k_2_02:81]
•Loss on equity investment - reflects changes in the carrying value of a certain equity investment due to triggering events.

[0000936395-24-000037:8k_2_02:82]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for all fiscal periods of fiscal 2024 and fiscal 2023. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.

## item 5.02 — body, verbatim

[0000936395-24-000037:8k_body:1]
Item 5.02 Departure of Directors or Certain Officers; Election of Directors; Appointment of Certain Officers; Compensatory Arrangements of Certain Officers.

[0000936395-24-000037:8k_body:2]
On December 11, 2024, Patrick H. Nettles, Ph.D., Executive Chair of Ciena’s Board of Directors (the “Board”), notified Ciena of his planned retirement and that he would not stand for re-election as a director at the end of his term at Ciena's 2025 Annual Meeting of Stockholders (the "Annual Meeting"). In connection with this decision, Dr. Nettles stepped down from his position as Executive Chair of the Board effective December 11, 2024. The Board has approved a decrease in the size of the Board from ten to nine directors, effective upon Dr. Nettles's departure from the Board following the Annual Meeting. The Board appointed Lawton W. Fitt as independent Chair of the Board in connection with and effective as of Dr. Nettles stepping down as Executive Chair. In connection with Ms. Fitt's appointment as independent Chair, the Board appointed Devinder Kumar to replace Ms. Fitt as chair of the Audit Committee of the Board, effective January 1, 2025.

[0000936395-24-000037:8k_body:3]
As previously announced, Andrew C. Petrik, Ciena's Vice President, Principal Accounting Officer and Controller, will retire effective April 25, 2025. In connection with Mr. Petrik’s planned retirement, effective immediately following the filing of Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 with the Securities and Exchange Commission (the "SEC"), Mr. Petrik will cease to be Ciena's principal accounting officer and James E. Moylan, Jr., 73, our Senior Vice President and Chief Financial Officer, will assume the responsibilities of principal accounting officer. Ciena previously disclosed Mr. Moylan’s biographical information under the caption "Information About Our Executive Officers and Directors" in Part I, Item 1 of Ciena's Annual Report on Form 10-K for the fiscal year ended October 28, 2023, as filed with the SEC on December 15, 2023, which information is incorporated herein by reference. Mr. Moylan will not receive any additional compensation or equity awards in connection with his appointment as principal accounting officer.
