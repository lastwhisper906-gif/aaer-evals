# CIEN notes — 0000936395-24-000044


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000936395-24-000044:notes:1]
Part III of the Form 10-K incorporates by reference certain portions of the registrant’s definitive proxy statement for its 2025 Annual Meeting of Stockholders, which is expected to be filed with the Commission not later than 120 days after the end of the fiscal year covered by this annual report.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-24-000044:notes:2]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0000936395-24-000044:notes:3]
Ciena Corporation (“Ciena” or the “Company”) is a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, video, data, artificial intelligence (“AI”), and voice. Ciena’s network solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals.

[0000936395-24-000044:notes:4]
Ciena’s portfolio is designed to enable the Adaptive Network™, which is Ciena’s vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. By using Ciena’s network solutions to transform network infrastructures into dynamic, programmable environments driven by automation and analytics, Ciena believes network operators can realize greater business agility, adapt dynamically to changing end-user service demands, rapidly introduce new revenue-generating services, and scale networks to meet increased traffic demands. Ciena’s solutions are also designed to enable network operators to gain valuable real-time network insights, allowing them to optimize network performance and maximize the return on their network infrastructure investment.

[0000936395-24-000044:notes:5]
Ciena’s solutions include Networking Platforms, including its Optical Networking portfolio and Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently, and adapt dynamically to changing end-user service demands. Ciena’s Optical Networking portfolio includes products that support long haul and regional networks, submarine and data center interconnect networks, and metro and edge networks. Ciena’s Routing and Switching portfolio includes products and solutions that enable efficient Internet Protocol (“IP”) transport in next-generation metro, core, aggregation, and access networks, including converged IP, optical, and fiber-based broadband access applications.

[0000936395-24-000044:notes:6]
To complement its Networking Platforms, Ciena offers Platform Software, which includes its Navigator Network Control Software (“Navigator NCS”) (formerly known as Manage, Control and Plan (“MCP”)) and advanced applications that deliver multi-layer domain control and operations for network operators. Ciena, through its Blue Planet® Automation Software, also enables complete service lifecycle management automation with productized operational support systems (“OSS”), including inventory, orchestration, and assurance solutions that help its customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-24-000044:notes:7]
In addition to its systems and software, Ciena also offers a broad range of services that help its customers build, operate, and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, network operations center (NOC) management, learning, and optimization services.

[0000936395-24-000044:notes:8]
Basis of Presentation

[0000936395-24-000044:notes:9]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000936395-24-000044:notes:10]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 2, 2024, October 28, 2023, and October 29, 2022, for the periods reported). Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2023 and fiscal 2022 each consisted of a 52-week fiscal year.

[0000936395-24-000044:notes:11]
Business Combinations

[0000936395-24-000044:notes:12]
Ciena records acquisitions using the purchase method of accounting. The assets acquired, liabilities assumed, contractual contingencies, and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when

[0000936395-24-000044:notes:13]
appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-24-000044:notes:14]
Use of Estimates

[0000936395-24-000044:notes:15]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-24-000044:notes:16]
Cash and Cash Equivalents

[0000936395-24-000044:notes:17]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Restricted cash collateralizing letters of credit are included in other current assets and other long-term assets, depending on the duration of the restriction.

[0000936395-24-000044:notes:18]
Investments

[0000936395-24-000044:notes:19]
Ciena’s investments in debt securities are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive loss. Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-24-000044:notes:20]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of November 2, 2024, the combined carrying value of these investments was $21.7 million. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena evaluates these investments for impairment or observable price changes quarterly and records adjustments to interest and other income, net on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:21]
Inventories

[0000936395-24-000044:notes:22]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-24-000044:notes:23]
Segment Reporting

[0000936395-24-000044:notes:24]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the Company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 24 below.

[0000936395-24-000044:notes:25]
Goodwill

[0000936395-24-000044:notes:26]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-24-000044:notes:27]
Annually, Ciena tests goodwill impairment qualitatively, or quantitatively by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-24-000044:notes:28]
Long-lived Assets

[0000936395-24-000044:notes:29]
Long-lived assets include equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0000936395-24-000044:notes:30]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-24-000044:notes:31]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method, generally over useful lives of three years to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-24-000044:notes:32]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0000936395-24-000044:notes:33]
Leases

[0000936395-24-000044:notes:34]
At the inception of a contract, Ciena must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts follows the assessment of whether there is a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating ROU assets, Operating lease liabilities and Long-term operating lease liabilities on the Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations on the Consolidated Balance Sheets.

[0000936395-24-000044:notes:35]
Ciena has operating and finance leases that primarily relate to real property. Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses, such as common area maintenance and utilities.

[0000936395-24-000044:notes:36]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Consolidated Statements of Operations.

[0000936395-24-000044:notes:37]
Intangible Assets

[0000936395-24-000044:notes:38]
Ciena records finite-lived intangible assets from acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-24-000044:notes:39]
Cloud Computing Arrangements

[0000936395-24-000044:notes:40]
Ciena capitalizes certain costs related to hosting arrangements that are service contracts (cloud computing arrangements). Capitalized costs are included in Other long-term assets on the Consolidated Balance Sheets and are amortized on a straight-line basis over the estimated useful life.

[0000936395-24-000044:notes:41]
Maintenance Spares

[0000936395-24-000044:notes:42]
Maintenance spares are recorded at cost. Ciena depreciates spares ratably over four years.

[0000936395-24-000044:notes:43]
Concentrations

[0000936395-24-000044:notes:44]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-24-000044:notes:45]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers and cloud providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 2 below.

[0000936395-24-000044:notes:46]
Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0000936395-24-000044:notes:47]
Revenue Recognition

[0000936395-24-000044:notes:48]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-24-000044:notes:49]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-24-000044:notes:50]
•identification of the contract, or contracts, with a customer;

[0000936395-24-000044:notes:51]
•identification of the performance obligations in the contract;

[0000936395-24-000044:notes:52]
•determination of the transaction price;

[0000936395-24-000044:notes:53]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-24-000044:notes:54]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-24-000044:notes:55]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-24-000044:notes:56]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and

[0000936395-24-000044:notes:57]
software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena’s transfer of the products or services to the customer and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-24-000044:notes:58]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services, such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-24-000044:notes:59]
Significant Judgments

[0000936395-24-000044:notes:60]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-24-000044:notes:61]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-24-000044:notes:62]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-24-000044:notes:63]
Capitalized Contract Acquisition Costs

[0000936395-24-000044:notes:64]
Ciena capitalizes and amortizes incremental costs of obtaining a contract considering each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole, and thus the capitalized costs of obtaining a purchase order is applied, even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-24-000044:notes:65]
For the additional disclosures on capitalized contract acquisition costs, see Note 2 below.

[0000936395-24-000044:notes:66]
Warranty Accruals

[0000936395-24-000044:notes:67]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-24-000044:notes:68]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-24-000044:notes:69]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions, and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-24-000044:notes:70]
Probability of default rates is published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating, and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-24-000044:notes:71]
Accounts Receivable Factoring

[0000936395-24-000044:notes:72]
Ciena has entered into factoring agreements to sell certain receivables to unrelated third-party financial institution on a non-recourse basis. These transactions result in a reduction in accounts receivable because the agreements transfer effective control over, and risk related to, the receivables to the buyers. Ciena's factoring agreements do not allow for recourse in the event of uncollectability, and Ciena does not retain any interest in the underlying accounts receivable once sold. Trade accounts receivables balances sold are removed from the consolidated balance sheets and cash received is reflected as cash provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest and other income, net on the Consolidated Statements of Operations. See Note 8 below.

[0000936395-24-000044:notes:73]
Research and Development

[0000936395-24-000044:notes:74]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-24-000044:notes:75]
Government Grants

[0000936395-24-000044:notes:76]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates.

[0000936395-24-000044:notes:77]
Advertising Costs

[0000936395-24-000044:notes:78]
Ciena expenses all advertising costs as incurred.

[0000936395-24-000044:notes:79]
Legal Costs

[0000936395-24-000044:notes:80]
Ciena expenses legal costs associated with litigation as incurred.

[0000936395-24-000044:notes:81]
Share-Based Compensation Expense

[0000936395-24-000044:notes:82]
Ciena measures and recognizes compensation expense for share-based awards and employee stock purchases related to its Amended and Restated 2003 Employee Stock Purchase Plan (the “ESPP”) based on estimated fair values on the date of grant. Ciena estimates the fair value of employee stock purchases related to the ESPP using the Black-Scholes option-pricing model. Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis in the Consolidated Statements of Operations.

[0000936395-24-000044:notes:83]
Awards with performance-based vesting conditions: (i) require the achievement of certain operational, financial or other performance criteria or targets; or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part. Ciena estimates the fair value of restricted stock units subject to performance-based vesting conditions, other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense, for performance-based restricted stock units other than total stockholder return, is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved and is included in the Consolidated Statements of Operations. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-24-000044:notes:84]
Share-based compensation expense for restricted stock units subject only to service-based vesting conditions and restricted stock units subject to performance-based vesting conditions other than total stockholder return, is recognized only for those awards that ultimately vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed.

[0000936395-24-000044:notes:85]
Ciena estimates the fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant and recognizes the related share-based compensation expense over the performance period. Ciena reverses share-based compensation expense on performance based awards subject to total stockholder return only when the requisite service period is not reached. See Note 23 below.

[0000936395-24-000044:notes:86]
Stock Repurchase Program

[0000936395-24-000044:notes:87]
Shares repurchased pursuant to Ciena’s stock repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena’s accounting policy related to its share repurchases is to reduce its common stock based on the par value of the shares and to reduce its capital surplus for the excess of the repurchase price over the par value. Since the inception of its stock repurchase programs, Ciena has had an accumulated deficit balance, therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0000936395-24-000044:notes:88]
Income Taxes

[0000936395-24-000044:notes:89]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities (“DTA”) for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-24-000044:notes:90]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2020 through 2023, in Canada for 2014, and in the United Kingdom for 2016 through 2022. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2021), United Kingdom (2016), Canada (2014), and India (2020). Limited adjustments can be made to federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-24-000044:notes:91]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-24-000044:notes:92]
Ciena is electing to use the period cost method for future global intangible low-taxed income (“GILTI”) inclusions.

[0000936395-24-000044:notes:93]
Loss Contingencies

[0000936395-24-000044:notes:94]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-24-000044:notes:95]
Fair Value of Financial Instruments

[0000936395-24-000044:notes:96]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s short-term and long-term debt, see Note 18 below.

[0000936395-24-000044:notes:97]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-24-000044:notes:98]
•Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities;

[0000936395-24-000044:notes:99]
•Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000936395-24-000044:notes:100]
•Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data.

[0000936395-24-000044:notes:101]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-24-000044:notes:102]
Restructuring

[0000936395-24-000044:notes:103]
From time to time, Ciena takes actions to align its workforce, facilities, and operating costs with perceived market opportunities, business strategies, and changes in market and business conditions, and to redesign business processes. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 4 below.

[0000936395-24-000044:notes:104]
Foreign Currency

[0000936395-24-000044:notes:105]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income, net on the Consolidated Statements of Operations. See Note 5 below.

[0000936395-24-000044:notes:106]
Derivatives

[0000936395-24-000044:notes:107]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. Ciena also uses foreign currency forward contracts to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. Generally, these derivatives have maturities of 24 months or less. These derivatives are designated as net investment hedges. At the inception of these hedges, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive loss and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statements of Operations to which the hedged transaction relates.

[0000936395-24-000044:notes:108]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-24-000044:notes:109]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:110]
See Notes 7 and 15 below.

[0000936395-24-000044:notes:111]
Computation of Net Income per Share

[0000936395-24-000044:notes:112]
Ciena calculates basic net income per common share (“Basic EPS”) by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of Basic EPS and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 20 below.

[0000936395-24-000044:notes:113]
Software Development Costs

[0000936395-24-000044:notes:114]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date that technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-24-000044:notes:115]
Newly Issued Accounting Standards - Effective

[0000936395-24-000044:notes:116]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

[0000936395-24-000044:notes:117]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-24-000044:notes:118]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

[0000936395-24-000044:notes:119]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures to decision makers. ASU 2023-09 is effective for annual periods beginning in fiscal 2026 and will result in changes to certain of its income tax disclosures including substantially more information on a disaggregated basis, but it does not affect recognition or measurement of income taxes and therefore is not expected to have a material effect on our consolidated financial statements.

[0000936395-24-000044:notes:120]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive

[0000936395-24-000044:notes:121]
Income—Expense Disaggregation Disclosures (Subtopic 220-40) to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-24-000044:notes:122]
In March 2024, the Securities and Exchange Commission (the “SEC”) adopted final rules under SEC Release No. 33-11275, The Enhancement and Standardization of Climate Related Disclosures for Investors, to require registrants to provide certain climate-related information in their registration statements and annual reports. The rules would require information about a registrant's climate-related risks that are reasonably likely to have a material impact on its business, results of operations, or financial condition. The required information about climate-related risks would also include disclosure of a registrant's greenhouse gas emissions. Finally, the rules would require registrants to present certain climate-related financial metrics in their audited financial statements. On April 12, 2024, the final rules were indefinitely delayed pending the completion of judicial review in consolidated proceedings in the U.S. Court of Appeals, Eighth Circuit.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-24-000044:notes:123]
REVENUE
Disaggregation of Revenue

[0000936395-24-000044:notes:124]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-24-000044:notes:125]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

[0000936395-24-000044:notes:126]
|  | Year Ended November 2, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,642,563 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,642,563 |  |
| Routing and Switching | 399,492 |  |  | — |  |  | — |  |  | — |  |  | 399,492 |  |
| Platform Software and Services | — |  |  | 358,062 |  |  | — |  |  | — |  |  | 358,062 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 77,619 |  |  | — |  |  | 77,619 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 303,086 |  |  | 303,086 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 184,358 |  |  | 184,358 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 49,775 |  |  | 49,775 |  |
| Total revenue by product line | $ | 3,042,055 |  |  | $ | 358,062 |  |  | $ | 77,619 |  |  | $ | 537,219 |  |  | $ | 4,014,955 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,042,055 |  |  | $ | 99,317 |  |  | $ | 19,267 |  |  | $ | 44,410 |  |  | $ | 3,205,049 |  |
| Products and services transferred over time | — |  |  | 258,745 |  |  | 58,352 |  |  | 492,809 |  |  | 809,906 |  |
| Total revenue by timing of revenue recognition | $ | 3,042,055 |  |  | $ | 358,062 |  |  | $ | 77,619 |  |  | $ | 537,219 |  |  | $ | 4,014,955 |  |

[0000936395-24-000044:notes:127]
|  | Year Ended October 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,987,245 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,987,245 |  |
| Routing and Switching | 506,247 |  |  | — |  |  | — |  |  | — |  |  | 506,247 |  |
| Platform Software and Services | — |  |  | 303,873 |  |  | — |  |  | — |  |  | 303,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 69,170 |  |  | — |  |  | 69,170 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 288,334 |  |  | 288,334 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 180,951 |  |  | 180,951 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 50,729 |  |  | 50,729 |  |
| Total revenue by product line | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 3,493,492 |  |  | $ | 67,013 |  |  | $ | 21,842 |  |  | $ | 55,036 |  |  | $ | 3,637,383 |  |
| Products and services transferred over time | — |  |  | 236,860 |  |  | 47,328 |  |  | 464,978 |  |  | 749,166 |  |
| Total revenue by timing of revenue recognition | $ | 3,493,492 |  |  | $ | 303,873 |  |  | $ | 69,170 |  |  | $ | 520,014 |  |  | $ | 4,386,549 |  |

[0000936395-24-000044:notes:128]
|  | Year Ended October 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,379,931 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,379,931 |  |
| Routing and Switching | 398,439 |  |  | — |  |  | — |  |  | — |  |  | 398,439 |  |
| Platform Software and Services | — |  |  | 277,191 |  |  | — |  |  | — |  |  | 277,191 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 76,567 |  |  | — |  |  | 76,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 292,375 |  |  | 292,375 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 157,443 |  |  | 157,443 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 50,715 |  |  | 50,715 |  |
| Total revenue by product line | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,778,370 |  |  | $ | 85,691 |  |  | $ | 25,540 |  |  | $ | 44,091 |  |  | $ | 2,933,692 |  |
| Products and services transferred over time | — |  |  | 191,500 |  |  | 51,027 |  |  | 456,442 |  |  | 698,969 |  |
| Total revenue by timing of revenue recognition | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |

[0000936395-24-000044:notes:129]
Ciena reports its sales geographically in the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-24-000044:notes:130]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-24-000044:notes:131]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Geographic distribution: |  |  |  |  |  |
| Americas | $ | 2,951,915 |  |  | $ | 3,110,347 |  |  | $ | 2,636,840 |  |
| EMEA | 648,870 |  |  | 643,142 |  |  | 555,215 |  |
| APAC | 414,170 |  |  | 633,060 |  |  | 440,606 |  |
| Total revenue by geographic distribution | $ | 4,014,955 |  |  | $ | 4,386,549 |  |  | $ | 3,632,661 |  |

[0000936395-24-000044:notes:132]
Ciena’s revenue includes United States revenue of $2.8 billion for both fiscal 2024 and fiscal 2023, and $2.4 billion for fiscal 2022. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-24-000044:notes:133]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-24-000044:notes:134]
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Cloud Provider | $ | 532,332 |  |  | $ | 561,397 |  |  | n/a |
| AT&T | 475,261 |  |  | 464,662 |  |  | $ | 433,418 |  |
| Verizon | n/a |  | n/a |  | 402,787 |  |
| Total | $ | 1,007,593 |  |  | $ | 1,026,059 |  |  | $ | 836,205 |  |

[0000936395-24-000044:notes:135]
________________________________

[0000936395-24-000044:notes:136]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-24-000044:notes:137]
The cloud provider noted in the above table purchased products from each of Ciena’s operating segments, excluding Blue Planet® Automation Software and Services, for each of the periods presented. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-24-000044:notes:138]
While Ciena has benefited from the diversification of its business and customer base, its ten largest customers contributed 57.9% of fiscal 2024 revenue, 53.7% of fiscal 2023 revenue and 56.3% of fiscal 2022 revenue.

[0000936395-24-000044:notes:139]
◦Networking Platforms revenue reflects sales of Ciena’s Optical Networking and Routing and Switching product lines.

[0000936395-24-000044:notes:140]
▪Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the Coherent ELS open line system, the O-NID edge OTN demarcation device, coherent pluggable transceivers, and the 5400 family of Packet-Optical Platforms.

[0000936395-24-000044:notes:141]
▪Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes, the 8100 Coherent IP networking platforms, Ciena’s WaveRouter® product, virtualization software, the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, and the 8700 Packetwave Platform. This product line also includes SD-Edge software and passive optical network (PON) routing and switching portfolio products.

[0000936395-24-000044:notes:142]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-24-000044:notes:143]
◦Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, previously referred to as “Manage, Control and Plan (MCP),” and legacy software solutions that support Ciena’s installed base of network solutions, including the OneControl Unified Management System. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

[0000936395-24-000044:notes:144]
Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:145]
◦Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to accelerate digital transformation. Ciena’s Blue Planet Automation Platform includes inventory management (BPI), multi-domain service orchestration (MDSO), multi-cloud orchestration (MCO), route optimization and analysis (ROA), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:146]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-24-000044:notes:147]
◦Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Consolidated Statements of Operations. Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-24-000044:notes:148]
Contract Balances

[0000936395-24-000044:notes:149]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-24-000044:notes:150]
|  |  | Balance at November 2, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 908,597 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 127,919 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 237,619 |  |  | $ | 228,460 |  |

[0000936395-24-000044:notes:151]
Ciena’s contract assets represent unbilled accounts receivable, net, where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Consolidated Balance Sheets. See Note 10 below.

[0000936395-24-000044:notes:152]
Deferred Revenue represents contract liabilities and consists of advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $153.9 million and $135.5 million of revenue during fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance at November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2024 and 2023.

[0000936395-24-000044:notes:153]
Capitalized contract acquisition costs consist of deferred sales commissions and were $28.4 million and $30.2 million as of November 2, 2024 and October 28, 2023, respectively, and are included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $30.5 million and $34.2 million during fiscal 2024 and fiscal 2023, respectively, and are included in selling and marketing expense on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:154]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of November 2, 2024, the aggregate amount of RPO was $1.6 billion. As of November 2, 2024, Ciena expects approximately 77% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-24-000044:notes:155]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-24-000044:notes:156]
|  | November 2, 2024 |  | October 28, 2023 |
| Products | $ | 19,017 |  |  | $ | 28,353 |  |
| Services | 218,602 |  |  | 200,107 |  |
| Total deferred revenue | 237,619 |  |  | 228,460 |  |
| Less current portion | (156,379) |  |  | (154,419) |  |
| Long-term deferred revenue | $ | 81,240 |  |  | $ | 74,041 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-24-000044:notes:157]
BUSINESS COMBINATIONS
Fiscal 2023 Acquisitions: Benu and Tibit

[0000936395-24-000044:notes:158]
On November 17, 2022, Ciena acquired Benu, a portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), that complements Ciena’s existing portfolio of broadband access solutions. On December 30, 2022, Ciena acquired Tibit, a provider and developer of passive optical network (“PON”)-specific hardware and operating software that can be integrated into a carrier-grade Ethernet switch and will strengthen Ciena’s portfolio of next-generation PON solutions that support residential, enterprise, and mobility use cases. These businesses were acquired for an aggregate of approximately $291.7 million, of which $244.7 million was paid in cash, and $47.0 million represents the fair value of Ciena’s previously held cost method equity investment in Tibit. The acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. Each of these transactions has been accounted for as the acquisition of a business.

[0000936395-24-000044:notes:159]
Ciena incurred approximately $3.4 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal, and accounting advisors and employment-related costs. These costs were recorded in acquisition and integration costs on the Consolidated Statements of Operations.

[0000936395-24-000044:notes:160]
The following table summarizes the final purchase price allocation related to the acquisitions based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-24-000044:notes:161]
|  | Amount |
| Cash and cash equivalents | $ | 14,634 |  |
| Accounts receivable, net | 443 |  |
| Inventories, net | 1,406 |  |
| Prepaid expenses and other | 810 |  |
| Equipment, furniture and fixtures | 1,090 |  |
| Goodwill | 116,644 |  |
| Developed technology | 75,400 |  |
| In-process technology | 89,100 |  |
| Customer relationships and contracts | 18,400 |  |
| Order backlog | 2,480 |  |
| Deferred tax asset, net | (26,429) |  |
| Accounts payable | (420) |  |
| Accrued liabilities and other short-term obligations | (874) |  |
| Deferred revenue | (851) |  |
| Other long-term obligations | (144) |  |
| Total purchase consideration | $ | 291,689 |  |

[0000936395-24-000044:notes:162]
Developed technology represents purchased technology that has reached technological feasibility and for which the acquired companies had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-24-000044:notes:163]
In-process technology represents purchased technology that had not reached technological feasibility as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the in-process technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Upon completion of the in-process technology, it will be amortized on a straight line basis over its estimated useful life, which will be determined on that date.

[0000936395-24-000044:notes:164]
Customer relationships and contracts represent agreements with existing Tibit customers and have an estimated useful life of three years. Order backlog is amortized over the fulfillment period.

[0000936395-24-000044:notes:165]
The goodwill generated from these acquisitions is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-24-000044:notes:166]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included on the Consolidated Statements of Operations for the reporting period, are immaterial.

[0000936395-24-000044:notes:167]
Fiscal 2022 Acquisitions: Vyatta and Xelic

[0000936395-24-000044:notes:168]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology. AT&T is a customer of Ciena; see Note 2 above. On March 9, 2022, Ciena acquired Xelic, Inc., a provider and developer of field programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores. These businesses were acquired for an aggregate of approximately $64.1 million, of which $63.3 million was paid in cash and $0.8 million represents a future payable arrangement. These transactions have each been accounted for as the acquisition of a business.

[0000936395-24-000044:notes:169]
Ciena incurred approximately $1.7 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal and accounting advisors. These costs were recorded in acquisition and integration costs in the Consolidated Statements of Operations.

[0000936395-24-000044:notes:170]
|  | Amount |
| Cash and cash equivalents | $ | 201 |  |
| Prepaid expenses and other | 1,614 |  |
| Equipment, furniture and fixtures | 694 |  |
| Customer relationships and contracts | 15,800 |  |
| Developed technology | 32,491 |  |
| Goodwill | 17,698 |  |
| Accrued liabilities | (4,434) |  |
| Total purchase consideration | $ | 64,064 |  |

[0000936395-24-000044:notes:171]
Customer relationships and contracts represent agreements with existing Vyatta customers and have an estimated useful life of two years.

[0000936395-24-000044:notes:172]
The goodwill generated from these acquisitions is primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. Goodwill is not deductible for income tax purposes.

[0000936395-24-000044:notes:173]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included in the Consolidated Statements of Operations for the reporting period, are immaterial.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-24-000044:notes:174]
SIGNIFICANT ASSET IMPAIRMENT AND RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Consolidated Balance Sheets, for the fiscal years indicated (in thousands):

[0000936395-24-000044:notes:175]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 3,156 |  | (1) | 26,814 |  | (2) | 29,970 |  |
| Cash payments | (2,722) |  |  | (22,194) |  |  | (24,916) |  |
| Balance at October 29, 2022 | 1,215 |  |  | 4,620 |  |  | 5,835 |  |
| Charges | 6,885 |  | (1) | 16,949 |  | (2) | 23,834 |  |
| Cash payments | (6,187) |  |  | (21,569) |  |  | (27,756) |  |
| Balance at October 28, 2023 | 1,913 |  |  | — |  |  | 1,913 |  |
| Charges | 15,408 |  | (1) | 9,184 |  | (2) | 24,592 |  |
| Cash payments | (15,394) |  |  | (9,184) |  |  | (24,578) |  |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Current restructuring liabilities | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |

[0000936395-24-000044:notes:176]
_________________________________

[0000936395-24-000044:notes:177]
(1) Reflects employee costs associated with a global workforce reduction of approximately 420, 120 and 60 employees during fiscal 2024, 2023 and 2022, respectively, as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-24-000044:notes:178]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.

[0000936395-24-000044:notes:179]
Significant Asset Impairments

[0000936395-24-000044:notes:180]
In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions. On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia. As a result, Ciena recorded impairment charges of approximately $3.8 million, of which $1.8 million was a provision for credit losses.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-24-000044:notes:181]
INTEREST AND OTHER INCOME, NET
The components of interest and other income, net, were as follows (in thousands):

[0000936395-24-000044:notes:182]
|  |  | Year Ended |
|  |  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Interest income |  | $ | 62,121 |  |  | $ | 45,011 |  |  | $ | 10,060 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts |  | 1,377 |  |  | (3,896) |  |  | (4,018) |  |
| Foreign currency exchange gains (losses) |  | (11,653) |  |  | (427) |  |  | 2,501 |  |
| Gain on equity investments, net |  | — |  |  | 26,368 |  |  | 4,120 |  |
| Other |  | (1,584) |  |  | (5,048) |  |  | (5,916) |  |
| Interest and other income, net |  | $ | 50,261 |  |  | $ | 62,008 |  |  | $ | 6,747 |  |

[0000936395-24-000044:notes:183]
During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its equity investment of $26.5 million. See Note 3 above. During fiscal 2022, Ciena recorded a net gain of $4.1 million on its equity investments.

[0000936395-24-000044:notes:184]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2024 and 2023, Ciena recorded $11.7 million and $0.4 million, respectively, in exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. During fiscal 2022, Ciena recorded $2.5 million in exchange 
rate gains as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net on the Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge certain of these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net on the Consolidated Statements of Operations. During fiscal 2024, Ciena recorded a gain of $1.4 million from non-hedge designated foreign currency forward contracts. During fiscal 2023 and 2022, Ciena recorded losses of $3.9 million and $4.0 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-24-000044:notes:185]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-24-000044:notes:186]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

[0000936395-24-000044:notes:187]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

[0000936395-24-000044:notes:188]
The following table summarizes the legal maturities of debt investments at November 2, 2024 (in thousands):

[0000936395-24-000044:notes:189]
|  | November 2, 2024 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 408,519 |  |  | $ | 409,208 |  |
| Due in 1-2 years | 80,879 |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 490,128 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-24-000044:notes:190]
FAIR VALUE MEASUREMENTS
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-24-000044:notes:191]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 636,097 |  |  | $ | — |  |  | $ | — |  |  | $ | 636,097 |  |
| Bond mutual fund | 112,703 |  |  | — |  |  | — |  |  | 112,703 |  |
| Time deposits | 92,804 |  |  | — |  |  | — |  |  | 92,804 |  |
| Deferred compensation plan assets | 16,519 |  |  | — |  |  | — |  |  | 16,519 |  |
| U.S. government obligations | — |  |  | 286,181 |  |  | — |  |  | 286,181 |  |
| Corporate debt securities | — |  |  | 111,143 |  |  | — |  |  | 111,143 |  |
| Foreign currency forward contracts | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Interest rate swaps | — |  |  | 11,777 |  |  | — |  |  | 11,777 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0000936395-24-000044:notes:192]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 661,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,101 |  |
| Bond mutual fund | 104,171 |  |  | — |  |  | — |  |  | 104,171 |  |
| Time deposits | 138,829 |  |  | — |  |  | — |  |  | 138,829 |  |
| Deferred compensation plan assets | 11,456 |  |  | — |  |  | — |  |  | 11,456 |  |
| U.S. government obligations | — |  |  | 169,909 |  |  | — |  |  | 169,909 |  |
| Commercial paper | — |  |  | 59,569 |  |  | — |  |  | 59,569 |  |
| Foreign currency forward contracts | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Interest rate swaps | — |  |  | 24,953 |  |  | — |  |  | 24,953 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-24-000044:notes:193]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheets as follows (in thousands):

[0000936395-24-000044:notes:194]
|  | November 2, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 832,239 |  |  | $ | 9,426 |  |  | $ | — |  |  | $ | 841,665 |  |
| Short-term investments | 9,365 |  |  | 306,978 |  |  | — |  |  | 316,343 |  |
| Prepaid expenses and other | — |  |  | 2,149 |  |  | — |  |  | 2,149 |  |
| Long-term investments | — |  |  | 80,920 |  |  | — |  |  | 80,920 |  |
| Other long-term assets | 16,519 |  |  | 11,777 |  |  | — |  |  | 28,296 |  |
| Total assets measured at fair value | $ | 858,123 |  |  | $ | 411,250 |  |  | $ | — |  |  | $ | 1,269,373 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,155 |  |  | $ | — |  |  | $ | 9,155 |  |

[0000936395-24-000044:notes:195]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 891,788 |  |  | $ | 2,760 |  |  | $ | — |  |  | $ | 894,548 |  |
| Short-term investments | 12,313 |  |  | 92,440 |  |  | — |  |  | 104,753 |  |
| Prepaid expenses and other | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Long-term investments | — |  |  | 134,278 |  |  | — |  |  | 134,278 |  |
| Other long-term assets | 11,456 |  |  | 24,953 |  |  | — |  |  | 36,409 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-24-000044:notes:196]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-24-000044:notes:197]
ACCOUNTS RECEIVABLE
As of November 2, 2024, two customers accounted for 13.0% and 12.0% of net accounts receivable, respectively. As of October 28, 2023, two customers accounted for 11.0% and 10.0% of net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for credit losses for the fiscal years indicated (in thousands):

[0000936395-24-000044:notes:198]
| Year Ended |  | Beginning Balance |  |  |  | Provisions |  | Net Deductions |  | Ending Balance |
| October 29, 2022(1) |  | $ | 10,912 |  |  |  |  | $ | 4,199 |  |  | $ | 4,153 |  |  | $ | 10,958 |  |
| October 28, 2023 |  | $ | 10,958 |  |  |  |  | $ | 5,718 |  |  | $ | 5,022 |  |  | $ | 11,654 |  |
| November 2, 2024 |  | $ | 11,654 |  |  |  |  | $ | 7,996 |  |  | $ | 9,770 |  |  | $ | 9,880 |  |

[0000936395-24-000044:notes:199]
(1) On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia. As a result, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $1.8 million for a trade receivable related to this decision.

[0000936395-24-000044:notes:200]
Accounts Receivable Factoring
In certain situations, Ciena may service transferred receivables which qualify as sales. Amounts sold through these arrangements during fiscal 2024, 2023, and 2022 were $18.1 million, $60.3 million, and $11.8 million, respectively. Additionally, in other situations, Ciena may settle receivables through customer paying agent arrangements. Amounts settled through these arrangements for fiscal 2024, 2023, and 2022 were $32.5 million, $41.9 million, and $13.4 million, respectively. Factoring related expense recorded to interest and other income, net was $1.2 million, $3.8 million, and $0.9 million for fiscal 2024, 2023, and 2022, respectively.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-24-000044:notes:201]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-24-000044:notes:202]
|  | November 2, 2024 |  | October 28, 2023 |
| Raw materials | $ | 542,785 |  |  | $ | 664,797 |  |
| Work-in-process | 32,219 |  |  | 55,242 |  |
| Finished goods | 324,697 |  |  | 314,168 |  |
| Deferred cost of goods sold | 27,902 |  |  | 66,634 |  |
| Gross inventories | 927,603 |  |  | 1,100,841 |  |
| Reserve for excess and obsolescence | (107,173) |  |  | (50,003) |  |
| Inventories, net | $ | 820,430 |  |  | $ | 1,050,838 |  |

[0000936395-24-000044:notes:203]
Ciena has expanded its manufacturing capacity and accumulating raw materials inventory of components that were available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly upon the easing of supply constraints for certain common components. During fiscal 2024 Ciena reduced its raw materials inventory of components primarily due to the consumption of raw materials previously purchased.

[0000936395-24-000044:notes:204]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For the periods presented, future demand was calculated using both customer backlog and future forecasted sales. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During fiscal 2024, fiscal 2023 and fiscal 2022, Ciena recorded a provision for excess and obsolescence of $77.3 million, $29.5 million, and $16.2 million, respectively, primarily related to a decrease in the forecasted demand for certain Networking Platforms products primarily sold to communications service providers. Deductions from the provision for excess and obsolete inventory relate primarily to the sale of previously reserved items and disposal activities.

[0000936395-24-000044:notes:205]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-24-000044:notes:206]
| Year Ended |  | Beginning Balance |  | Provisions |  | Disposals |  | Ending Balance |
| October 29, 2022 |  | $ | 36,959 |  |  | $ | 16,184 |  |  | $ | 17,057 |  |  | $ | 36,086 |  |
| October 28, 2023 |  | $ | 36,086 |  |  | $ | 29,464 |  |  | $ | 15,547 |  |  | $ | 50,003 |  |
| November 2, 2024 |  | $ | 50,003 |  |  | $ | 77,341 |  |  | $ | 20,171 |  |  | $ | 107,173 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-24-000044:notes:207]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-24-000044:notes:208]
|  | November 2, 2024 |  | October 28, 2023 |
| Cash advances to contract manufacturers (1) | $ | 167,337 |  |  | $ | — |  |
| Contract assets for unbilled accounts receivable, net | 127,919 |  |  | 150,312 |  |
| Prepaid VAT and other taxes | 106,095 |  |  | 96,724 |  |
| Prepaid expenses | 50,597 |  |  | 58,954 |  |
| Other non-trade receivables | 45,935 |  |  | 33,408 |  |
| Product demonstration equipment, net (2) | 43,245 |  |  | 40,682 |  |
| Capitalized contract acquisition costs | 20,310 |  |  | 23,326 |  |
| Foreign currency forward contracts | 2,149 |  |  | 1,118 |  |
| Deferred deployment expense | 596 |  |  | 1,170 |  |
|  | $ | 564,183 |  |  | $ | 405,694 |  |

[0000936395-24-000044:notes:209]
(1) Amount reflects refundable cash advances to a third-party contract manufacturer for potential future inventory purchases and transition and logistic costs for future asset relocation. Ciena has initiated a strategic reengineering and realignment of its supply chain, including changes to its systems, processes, partners and people, and this cash advance assists in facilitating such activities.

[0000936395-24-000044:notes:210]
(2) Depreciation of product demonstration equipment was $8.3 million, $8.0 million and $8.7 million for fiscal 2024, 2023 and 2022, respectively.

[0000936395-24-000044:notes:211]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-24-000044:notes:212]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-24-000044:notes:213]
|  | November 2, 2024 |  | October 28, 2023 |
| Equipment, furniture and fixtures | $ | 788,781 |  |  | $ | 676,485 |  |
| Building subject to finance lease | 67,517 |  |  | 67,904 |  |
| Leasehold improvements | 77,451 |  |  | 74,391 |  |
| Equipment, building, furniture and fixtures | 933,749 |  |  | 818,780 |  |
| Accumulated depreciation and amortization | (596,027) |  |  | (538,633) |  |
| Equipment, building, furniture and fixtures, net | $ | 337,722 |  |  | $ | 280,147 |  |

[0000936395-24-000044:notes:214]
During fiscal 2024, fiscal 2023 and fiscal 2022, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $84.5 million, $84.6 million and $87.2 million, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-24-000044:notes:215]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-24-000044:notes:216]
|  | November 2, 2024 |  | October 28, 2023 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 503,618 |  |  | $ | (442,345) |  |  | $ | 61,273 |  |  | $ | 503,618 |  |  | $ | (414,941) |  |  | $ | 88,677 |  |
| In-process research and development | 89,100 |  |  | — |  |  | 89,100 |  |  | 89,100 |  |  | — |  |  | 89,100 |  |
| Patents and licenses | 8,795 |  |  | (6,150) |  |  | 2,645 |  |  | 8,795 |  |  | (5,203) |  |  | 3,592 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 410,934 |  |  | (398,932) |  |  | 12,002 |  |  | 410,983 |  |  | (386,725) |  |  | 24,258 |  |
| Total intangible assets | $ | 1,012,447 |  |  | $ | (847,427) |  |  | $ | 165,020 |  |  | $ | 1,012,496 |  |  | $ | (806,869) |  |  | $ | 205,627 |  |

[0000936395-24-000044:notes:217]
The aggregate amortization expense of intangible assets was $40.6 million, $49.6 million and $44.3 million for fiscal 2024, fiscal 2023 and fiscal 2022, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-24-000044:notes:218]
| Fiscal Year | Amount (1) |  |  |
| 2025 | $ | 34,576 |  |  |  |
| 2026 | 23,348 |  |  |  |
| 2027 | 15,843 |  |  |  |
| 2028 | 1,991 |  |  |  |
| 2029 | 126 |  |  |  |
| Thereafter | 36 |  |  |  |
|  | $ | 75,920 |  |  |  |

[0000936395-24-000044:notes:219]
(1) Does not include amortization of in-process research and development, as estimation of the timing of future amortization expense would be impractical.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-24-000044:notes:220]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of November 2, 2024 and October 28, 2023, as well as the changes to goodwill during fiscal 2024 (in thousands):

[0000936395-24-000044:notes:221]
|  | Balance at October 28, 2023 |  |  |  |  |  | Translation |  | Balance at November 2, 2024 |
| Platform Software and Services | $ | 156,191 |  |  |  |  |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services | 89,049 |  |  |  |  |  |  | — |  |  | 89,049 |  |
| Networking Platforms | 199,525 |  |  |  |  |  |  | (58) |  |  | 199,467 |  |
| Total | $ | 444,765 |  |  |  |  |  |  | $ | (58) |  |  | $ | 444,707 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-24-000044:notes:222]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-24-000044:notes:223]
|  | November 2, 2024 |  | October 28, 2023 |
| Maintenance spares inventory, net | $ | 77,918 |  |  | $ | 54,042 |  |
| Equity investments(1) | 21,730 |  |  | 48 |  |
| Deferred compensation plan assets | 16,519 |  |  | 11,456 |  |
| Interest rate swaps | 11,777 |  |  | 24,953 |  |
| Capitalized contract acquisition costs | 8,111 |  |  | 6,879 |  |
| Cloud computing arrangements(2) | 5,641 |  |  | 8,589 |  |
| Deferred debt issuance costs, net(3) | 1,733 |  |  | 1,956 |  |
| Restricted cash | 163 |  |  | 168 |  |
| Other | 11,102 |  |  | 8,362 |  |
|  | $ | 154,694 |  |  | $ | 116,453 |  |

[0000936395-24-000044:notes:224]
(1)  Increase is due to an equity investment in a privately held technology company during fiscal 2024.

[0000936395-24-000044:notes:225]
(2) During fiscal 2024, fiscal 2023 and fiscal 2022, Ciena recorded amortization of cloud computing arrangements of $4.9 million, $2.6 million and $2.8 million, respectively.

[0000936395-24-000044:notes:226]
(3) Deferred debt issuance costs relate to Ciena’s senior secured revolving credit facility (the “Revolving Credit Facility”) entered into during fiscal 2023 and its predecessor asset-backed credit facility (described in Note 19 below). The amortization of deferred debt issuance costs for the Revolving Credit Facility and its predecessor is included in interest expense, and was $0.3 million for fiscal 2024 and $0.4 million for both fiscal 2023 and fiscal 2022.

[0000936395-24-000044:notes:227]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-24-000044:notes:228]
|  | November 2, 2024 |  | October 28, 2023 |
| Compensation, payroll related tax and benefits | $ | 148,732 |  |  | $ | 159,530 |  |
| Warranty | 55,267 |  |  | 57,089 |  |
| Vacation | 31,250 |  |  | 29,503 |  |
| Income taxes payable | 35,111 |  |  | 16,341 |  |
| Foreign currency forward contracts | 9,155 |  |  | 14,509 |  |
| Interest payable | 6,120 |  |  | 4,514 |  |
| Finance lease liabilities | 4,395 |  |  | 3,953 |  |
| Other | 103,875 |  |  | 145,980 |  |
|  | $ | 393,905 |  |  | $ | 431,419 |  |

[0000936395-24-000044:notes:229]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years presented (in thousands):

[0000936395-24-000044:notes:230]
| Year Ended |  | Beginning Balance |  |  |  | Current Year Provisions |  |  |  | Settlements |  | Ending Balance |
| October 29, 2022 |  | $ | 48,019 |  |  |  |  | $ | 17,440 |  |  |  |  | $ | (19,956) |  |  | $ | 45,503 |  |
| October 28, 2023 |  | $ | 45,503 |  |  |  |  | $ | 31,742 |  |  |  |  | $ | (20,156) |  |  | $ | 57,089 |  |
| November 2, 2024 |  | $ | 57,089 |  |  |  |  | $ | 25,643 |  |  |  |  | $ | (27,465) |  |  | $ | 55,267 |  |

[0000936395-24-000044:notes:231]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-24-000044:notes:232]
|  | November 2, 2024 |  | October 28, 2023 |
| Income tax liability | $ | 113,365 |  |  | $ | 98,259 |  |
| Finance lease liabilities | 43,522 |  |  | 48,192 |  |
| Deferred compensation plan liability | 16,509 |  |  | 11,444 |  |
| Other | 12,542 |  |  | 12,512 |  |
|  | $ | 185,938 |  |  | $ | 170,407 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-24-000044:notes:233]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-24-000044:notes:234]
Ciena conducts business globally in many currencies, and thus is exposed to foreign currency exchange rate changes. To limit this exposure, Ciena entered into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-24-000044:notes:235]
As of November 2, 2024 and October 28, 2023, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $257.0 million and $367.3 million as of November 2, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 24 months or less, and have been designated as cash flow hedges.

[0000936395-24-000044:notes:236]
As of November 2, 2024 and October 28, 2023, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. In April 2024, Ciena terminated a portion of its existing net investment hedges for a cash loss of $0.6 million, which was recorded to other comprehensive income (loss). Ciena replaced its terminated net investment hedges with new net investment hedges. The notional amount of these contracts was approximately $65.4 million and $48.0 million as of November 2, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0000936395-24-000044:notes:237]
As of November 2, 2024 and October 28, 2023, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $201.2 million and $226.3 million as of November 2, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-24-000044:notes:238]
Interest Rate Derivatives

[0000936395-24-000044:notes:239]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 18 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0000936395-24-000044:notes:240]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest swaps was $350 million as of November 2, 2024 and October 28, 2023.

[0000936395-24-000044:notes:241]
In January 2023, Ciena entered into interest rate swaps to fix the SOFR rate for an additional $350.0 million of its floating rate debt at 3.47% through January 2028 (“2028 interest rate swaps”). The total notional amount of the 2028 interest rate swaps in effect as of November 2, 2024 and October 28, 2023 was $350.0 million.

[0000936395-24-000044:notes:242]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of November 2, 2024.

[0000936395-24-000044:notes:243]
Ciena expects the variable rate payments to be received under the terms interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the 2030 New Term Loan (as defined in Note 18 below). These derivative contracts have been designated as cash flow hedges.

[0000936395-24-000044:notes:244]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 5 and 7 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-24-000044:notes:245]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax (in thousands):

[0000936395-24-000044:notes:246]
|  |  | Unrealized Gain (Loss) on |  |  |  |  |
|  |  | Available-for-Sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 30, 2021 |  | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications |  | (2,801) |  |  | (16,299) |  |  | 14,512 |  |  | (49,446) |  |  | (54,034) |  |
| Amounts reclassified from AOCI |  | — |  |  | (114) |  |  | 7,064 |  |  | — |  |  | 6,950 |  |
| Balance at October 29, 2022 |  | (2,965) |  |  | (10,197) |  |  | 9,397 |  |  | (42,880) |  |  | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications |  | 2,593 |  |  | (8,455) |  |  | 19,600 |  |  | (5,321) |  |  | 8,417 |  |
| Amounts reclassified from AOCI |  | — |  |  | 10,496 |  |  | (10,035) |  |  | — |  |  | 461 |  |
| Balance at October 28, 2023 |  | (372) |  |  | (8,156) |  |  | 18,962 |  |  | (48,201) |  |  | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications |  | 1,170 |  |  | (1,424) |  |  | 4,574 |  |  | (3,096) |  |  | 1,224 |  |
| Amounts reclassified from AOCI |  | — |  |  | 4,700 |  |  | (14,868) |  |  | — |  |  | (10,168) |  |
| Balance at November 2, 2024 |  | $ | 798 |  |  | $ | (4,880) |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |

[0000936395-24-000044:notes:247]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on interest rate swaps designated as cash flow hedges impacted interest and other income, net on the Consolidated Statements of Operations.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000936395-24-000044:notes:248]
LEASES
Ciena leases approximately 1.1 million square feet of facilities globally. Ciena’s corporate headquarters are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also leases smaller engineering facilities in the United States, Canada, and Europe. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 8 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within 4 years.

[0000936395-24-000044:notes:249]
Leases included on the Consolidated Balance Sheets for the fiscal periods indicated were as follows (in thousands):

[0000936395-24-000044:notes:250]
|  | Classification |  | Balance at November 2, 2024 |  | Balance at October 28, 2023 |
| Operating leases: |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 27,417 |  |  | $ | 35,140 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 39,562 |  |  | $ | 49,914 |  |
| Finance leases: |  |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 67,517 |  |  | $ | 67,904 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (34,206) |  |  | (30,079) |  |
| Buildings, net |  |  | $ | 33,311 |  |  | $ | 37,825 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 47,917 |  |  | $ | 52,145 |  |

[0000936395-24-000044:notes:251]
ROU assets that involve subleased or vacant space aggregate $4.9 million as of November 2, 2024. Finance lease buildings, net, that involve subleased or vacant space aggregate $5.3 million as of November 2, 2024. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized.

[0000936395-24-000044:notes:252]
For the periods indicated, the components of lease expense included in the Consolidated Statements of Operations were as follows (in thousands):

[0000936395-24-000044:notes:253]
|  |  |  | Year Ended |  | Year Ended |  | Year Ended |
|  | Classification |  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Operating lease costs | Operating expense |  | $ | 13,595 |  |  | $ | 16,080 |  |  | $ | 17,966 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 4,406 |  |  | 4,448 |  |  | 4,592 |  |
| Interest on finance lease liabilities | Interest expense |  | 3,769 |  |  | 4,069 |  |  | 4,601 |  |
| Total finance lease cost |  |  | 8,175 |  |  | 8,517 |  |  | 9,193 |  |
| Non-capitalized lease cost | Operating expense |  | 954 |  |  | 910 |  |  | 917 |  |
| Variable lease cost(1) | Operating expense |  | 2,562 |  |  | 3,421 |  |  | 5,898 |  |
| Net lease cost(2) |  |  | $ | 25,286 |  |  | $ | 28,928 |  |  | $ | 33,974 |  |

[0000936395-24-000044:notes:254]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-24-000044:notes:255]
(2) Excludes other operating expense of $5.3 million, $6.5 million, and $12.8 million for the fiscal years ended November 2, 2024, October 28, 2023, and October 29, 2022, respectively, related to amortization of leasehold improvements.

[0000936395-24-000044:notes:256]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of November 2, 2024 were as follows (in thousands):

[0000936395-24-000044:notes:257]
| Fiscal Year | Operating Leases |  | Finance Leases |  | Total |
| 2025 | $ | 15,601 |  |  | $ | 7,749 |  |  | $ | 23,350 |  |
| 2026 | 11,187 |  |  | 7,779 |  |  | 18,966 |  |
| 2027 | 6,587 |  |  | 8,049 |  |  | 14,636 |  |
| 2028 | 2,157 |  |  | 8,319 |  |  | 10,476 |  |
| 2029 | 2,578 |  |  | 8,319 |  |  | 10,897 |  |
| Thereafter | 5,393 |  |  | 22,937 |  |  | 28,330 |  |
| Total lease payments | 43,503 |  |  | 63,152 |  |  | 106,655 |  |
| Less: Imputed interest | (3,941) |  |  | (15,235) |  |  | (19,176) |  |
| Present value of lease liabilities | 39,562 |  |  | 47,917 |  |  | 87,479 |  |
| Less: Current portion of present value of minimum lease payments | 14,455 |  |  | 4,395 |  |  | 18,850 |  |
| Long-term portion of present value of minimum lease payments | $ | 25,107 |  |  | $ | 43,522 |  |  | $ | 68,629 |  |

[0000936395-24-000044:notes:258]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows (in thousands):

[0000936395-24-000044:notes:259]
| Weighted-average remaining lease term in years: | As of November 2, 2024 |  | As of October 28, 2023 |
| Operating leases | 4.00 |  | 4.07 |
| Finance leases | 7.71 |  | 8.71 |
| Weighted-average discount rates: |  |  |  |
| Operating leases | 4.29 | % |  | 3.88 | % |
| Finance leases | 7.56 | % |  | 7.56 | % |


## us-gaap:DebtDisclosureTextBlock

[0000936395-24-000044:notes:260]
SHORT-TERM AND LONG-TERM DEBT
Outstanding Term Loan Payable

[0000936395-24-000044:notes:261]
2030 New Term Loan

[0000936395-24-000044:notes:262]
On October 24, 2023, Ciena, together with certain of its domestic subsidiaries as guarantors, entered into an Incremental Amendment Agreement (the “Amendment”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto, and Bank of America, N.A., as administrative agent (“Bank of America”), to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300 million (the “Revolving Credit Facility” as defined in Note 19 below).

[0000936395-24-000044:notes:263]
The proceeds of the 2030 New Term Loan, net of original issuance discount, replaced, in full, $668.7 million of outstanding principal of Ciena’s prior senior secured term loan maturing September 28, 2025 (the “2025 Term Loan”) and $497.5 million of outstanding principal of Ciena’s prior senior secured term loan maturing January 19, 2030 (the “2030 Term Loan” and, together with the 2025 Term Loan, the “Refinanced Term Loans”), including accrued interest, and paid transaction fees and expenses, resulting in proceeds of $0.8 million. The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million on a quarterly basis.

[0000936395-24-000044:notes:264]
Based on the continuation of existing lenders and the addition of new lenders, this arrangement was primarily accounted for as a modification of debt and, as such, $6.0 million of debt issuance costs associated with the 2030 New Term Loan were expensed. The aggregate balance of approximately $4.4 million of debt issuance costs and approximately $2.2 million of original discount from the Refinanced Term Loans, $0.1 million of debt issuance costs associated with new lenders for the 2030 New Term Loan, and approximately $2.9 million of original discount from the 2030 New Term Loan, were included in the carrying value of the 2030 New Term Loan.

[0000936395-24-000044:notes:265]
The Amendment amends the Credit Agreement and provides that the 2030 New Term Loan will, among other things:

[0000936395-24-000044:notes:266]
•mature on October 24, 2030;

[0000936395-24-000044:notes:267]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 New Term Loan as of January 19, 2023, or $2.9 million, or $11.7 million annually, with the balance payable at maturity;

[0000936395-24-000044:notes:268]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the Refinanced Term Loans, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-24-000044:notes:269]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.00%; and

[0000936395-24-000044:notes:270]
Among other things, the Amendment also amends the Credit Agreement by (i) modifying the “accordion” feature to provide for incremental term loan facilities (the “Incremental Term Loans”) in an aggregate amount not to exceed the sum of (A) the greater of (1) $640 million and (2) an amount equal to consolidated EBITDA on a pro forma basis for the most recently ended four-quarter period and (B) an amount (1) in the case of secured incremental term facilities that rank pari passu with or junior to the 2030 New Term Loan, such that the Total Secured Net Leverage Ratio (as defined in the Credit Agreement) would not be greater than 3.00 to 1.00 at the time of incurrence and (2) in the case of unsecured incremental term facilities, such that the Interest Coverage Ratio (as defined in the Credit Agreement) would not be less than 2.00 to 1.00 at the time of incurrence, subject to certain conditions, including obtaining commitments from any one or more lenders, whether or not currently party to the Credit Agreement, to provide such increased amounts and (ii) amending certain negative covenants.

[0000936395-24-000044:notes:271]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-24-000044:notes:272]
|  |  | November 2, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 New Term Loan |  | $ | 1,158,300 |  |  | $ | (4,359) |  |  | $ | (5,594) |  |  | $ | 1,148,347 |  |  | $ | 1,159,371 |  |  |  |

[0000936395-24-000044:notes:273]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $5.6 million as of November 2, 2024 and $5.5 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense, and was $0.9 million during fiscal 2024 and $0.1 million during fiscal 2023.

[0000936395-24-000044:notes:274]
As of November 2, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-24-000044:notes:275]
Refinanced Term Loans

[0000936395-24-000044:notes:276]
The proceeds of the 2030 New Term Loan, net of original issuance discount, were used to repay in full $1.2 billion of outstanding principal of the Refinanced Term Loans, including accrued interest.

[0000936395-24-000044:notes:277]
2025 Term Loan

[0000936395-24-000044:notes:278]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.6 million for fiscal 2023.

[0000936395-24-000044:notes:279]
2030 Term Loan

[0000936395-24-000044:notes:280]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were intended to be used for general corporate purposes.

[0000936395-24-000044:notes:281]
The Incremental Agreement amended the Credit Agreement and provided that the 2030 Term Loan would, among other things:

[0000936395-24-000044:notes:282]
•mature on January 19, 2030;

[0000936395-24-000044:notes:283]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

[0000936395-24-000044:notes:284]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-24-000044:notes:285]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

[0000936395-24-000044:notes:286]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-24-000044:notes:287]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remained in full force and effect.

[0000936395-24-000044:notes:288]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.5 million for fiscal 2023.

[0000936395-24-000044:notes:289]
2030 Notes

[0000936395-24-000044:notes:290]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-24-000044:notes:291]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0000936395-24-000044:notes:292]
|  |  | November 2, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (3,573) |  |  | $ | 396,427 |  |  | $ | 395,735 |  |  |  |

[0000936395-24-000044:notes:293]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $3.6 million as of November 2, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.7 million during fiscal 2024 and fiscal 2023.

[0000936395-24-000044:notes:294]
As of November 2, 2024, the estimated fair value of the 2030 Notes was $368.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
REVOLVING CREDIT FACILITY
On February 10, 2023, pursuant to an ABL Credit Agreement dated October 28, 2019, as amended (the “ABL Credit Agreement”), by and among Ciena, certain of its subsidiaries, the lenders party thereto, and Bank of America, as administrative agent, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provided for a total commitment of $300.0 million to extend its maturity date to September 28, 2025.

[0000936395-24-000044:notes:295]
On October 24, 2023 (the “Closing Date”), pursuant to the Incremental Amendment Agreement to the Credit Agreement (as defined in Note 18 above), Ciena incurred a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”), which replaced the ABL Credit Facility. Ciena has the option to increase the total revolving commitments under the Revolving Credit Facility to $450.0 million, subject to certain conditions, including obtaining commitments from one or more lenders. The Credit Agreement provides that $200.0 million of the Revolving Credit Facility is available for issuances of letters of credit and allows for swingline loans in an amount not to exceed $50.0 million. On or about the Closing Date,

[0000936395-24-000044:notes:296]
Ciena transferred to the Revolving Credit Facility certain outstanding letters of credit initially issued under the ABL Credit Facility with an undrawn amount of approximately $65.1 million. There were no borrowings outstanding under the ABL Credit Facility as of the Closing Date. Ciena expects to use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and for general corporate purposes.

[0000936395-24-000044:notes:297]
The Credit Agreement provides that the Revolving Credit Facility will, among other things:

[0000936395-24-000044:notes:298]
•mature on October 24, 2028;

[0000936395-24-000044:notes:299]
•bear interest on outstanding borrowings, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus a credit spread adjustment of 0.10% plus an applicable margin ranging from 1.375% to 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin ranging from 0.375% to 1.00%, in each case, with the actual margin determined according to the Total Net Leverage Ratio (as defined in the Credit Agreement above);

[0000936395-24-000044:notes:300]
•have a commitment fee payable on the unused portion of the Revolving Credit Facility at a per annum rate ranging from 0.225% to 0.300%, with the actual rate determined according to the Total Net Leverage Ratio; and

[0000936395-24-000044:notes:301]
•include a restriction on the aggregate amount of Incremental Term Loans and certain other indebtedness that can be incurred in the future equal to an amount that would not result in the Total Net Leverage Ratio exceeding 5.00 to 1.00 at the time of incurrence.

[0000936395-24-000044:notes:302]
The obligations under the Revolving Credit Facility are guaranteed by all of Ciena’s subsidiaries that currently, or in the future are required to, guarantee the obligations of the 2030 New Term Loan, including, as of the Closing Date, Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., and are secured on a pari passu basis with the 2030 New Term Loan by a pledge of substantially all of the assets of Ciena and the guarantors. Upon the occurrence of certain events related to the improvement of Ciena’s credit rating and repayment of all secured term loans (“Investment Grade Events”), all collateral securing the obligations under the Revolving Credit Facility will be released at Ciena’s election.

[0000936395-24-000044:notes:303]
Under the Revolving Credit Facility, Ciena is also required to maintain certain financial maintenance covenants, including:

[0000936395-24-000044:notes:304]
•prior to an Investment Grade Event, a maximum Total Secured Net Leverage Ratio of no greater than 3.50 to 1.00 as of the end of any period of four fiscal quarters (provided, that in the event Ciena consummates a qualifying acquisition, Ciena can elect to increase the maximum Total Secured Net Leverage Ratio level to 4.00 to 1.00 for the fiscal quarter in which such qualifying acquisition is consummated and for the next five consecutive fiscal quarters);

[0000936395-24-000044:notes:305]
•on or after an Investment Grade Event, a maximum Total Net Leverage Ratio of no greater than 4.00 to 1.00 as of the end of any period of four fiscal quarters; and

[0000936395-24-000044:notes:306]
•a minimum Interest Coverage Ratio of no less than 3.00 to 1.00 as of the end of any period of four fiscal quarters.

[0000936395-24-000044:notes:307]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-24-000044:notes:308]
As of November 2, 2024, Ciena was in compliance with the above financial maintenance covenants. As of November 2, 2024, letters of credit totaling $59.1 million were issued under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of November 2, 2024.


## us-gaap:EarningsPerShareTextBlock

[0000936395-24-000044:notes:309]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-24-000044:notes:310]
The following table presents the calculation of Basic and Diluted EPS (in thousands except per share amounts):

[0000936395-24-000044:notes:311]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Net income | $ | 83,956 |  |  | $ | 254,827 |  |  | $ | 152,902 |  |
| Basic weighted average shares outstanding | 144,715 |  |  | 148,971 |  |  | 151,208 |  |
| Effect of dilutive potential common shares | 1,249 |  |  | 409 |  |  | 985 |  |
| Diluted weighted average shares outstanding | 145,964 |  |  | 149,380 |  |  | 152,193 |  |
| Basic EPS | $ | 0.58 |  |  | $ | 1.71 |  |  | $ | 1.01 |  |
| Diluted EPS | $ | 0.58 |  |  | $ | 1.71 |  |  | $ | 1.00 |  |
| Antidilutive employee share-based awards, excluded | 1,057 |  | 2,675 |  | 1,370 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-24-000044:notes:312]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program and Accelerated Share Repurchase Agreement

[0000936395-24-000044:notes:313]
On December 9, 2021, Ciena announced that its Board of Directors replaced its previously authorized program with a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received approximately 3.6 million shares of its common stock from Goldman, calculated based on the average of the volume-weighted average prices of Ciena’s common stock of $69.78 for the period from December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt. During the remainder of fiscal 2022, Ciena repurchased an additional 4.8 million shares of its common stock, for an aggregate purchase price of $250.0 million, at an average price of $51.53 per share.

[0000936395-24-000044:notes:314]
During fiscal 2023, Ciena repurchased an additional 5.7 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $44.08 per share. During fiscal 2024, Ciena repurchased an additional 4.5 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $55.07 per share, which completed the authorized repurchases contemplated under the program. In aggregate, Ciena repurchased 18.6 million shares for an aggregate purchase price of $1.0 billion, at an average price of $53.63 per share.

[0000936395-24-000044:notes:315]
On October 2, 2024, Ciena announced that its Board of Directors authorized a program to repurchase up to $1.0 billion of its common stock, commencing in Ciena’s fiscal year 2025 and continuing through the end of Ciena’s fiscal year 2027. Ciena may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time.

[0000936395-24-000044:notes:316]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-24-000044:notes:317]
Impact of Inflation Reduction Act 1% Excise Tax on Share Repurchases

[0000936395-24-000044:notes:318]
Beginning fiscal 2023, a 1% excise tax on the market value of shares repurchased offset by 1% of the market value of shares issued was implemented. During fiscal 2023, a net excise tax of $1.5 million was recorded to additional paid-in capital on the Consolidated Balance Sheets. During fiscal 2024, a net excise tax of $1.4 million was recorded to additional paid-in capital on the Consolidated Balance Sheets.

[0000936395-24-000044:notes:319]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-24-000044:notes:320]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $46.6 million for the shares of Ciena’s stock repurchased during fiscal 2024 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-24-000044:notes:321]
INCOME TAXES
For the periods indicated, the provision for income taxes consists of the following (in thousands):

[0000936395-24-000044:notes:322]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Provision for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 70,208 |  |  | $ | 36,537 |  |  | $ | 27,479 |  |
| State | 14,106 |  |  | 18,860 |  |  | 10,289 |  |
| Foreign | 28,390 |  |  | 28,281 |  |  | 19,337 |  |
| Total current | 112,704 |  |  | 83,678 |  |  | 57,105 |  |
| Deferred: |  |  |  |  |  |
| Federal | (52,300) |  |  | (8,010) |  |  | (30,032) |  |
| State | (4,868) |  |  | (17,354) |  |  | 520 |  |
| Foreign | (19,642) |  |  | 10,512 |  |  | 2,010 |  |
| Total deferred | (76,810) |  |  | (14,852) |  |  | (27,502) |  |
| Provision for income taxes | $ | 35,894 |  |  | $ | 68,826 |  |  | $ | 29,603 |  |

[0000936395-24-000044:notes:323]
For the periods indicated, income before provision for income taxes consists of the following (in thousands):

[0000936395-24-000044:notes:324]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| United States | $ | 244 |  |  | $ | 93,682 |  |  | $ | 28,784 |  |
| Foreign | 119,606 |  |  | 229,971 |  |  | 153,721 |  |
| Total | $ | 119,850 |  |  | $ | 323,653 |  |  | $ | 182,505 |  |

[0000936395-24-000044:notes:325]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-24-000044:notes:326]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2024, fiscal 2023 and fiscal 2022 as follows:

[0000936395-24-000044:notes:327]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Provision at statutory rate | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| State taxes | 5.60 | % |  | 1.65 | % |  | 2.31 | % |
| Withholding and other foreign taxes | 3.53 | % |  | (0.09) | % |  | (1.37) | % |
| Research and development credit | (40.23) | % |  | (16.78) | % |  | (23.66) | % |
| Non-deductible compensation | 13.92 | % |  | 5.29 | % |  | 5.26 | % |
| U.S. Taxation on foreign activity | 9.59 | % |  | 5.08 | % |  | 1.73 | % |
| Foreign Nontaxable interest | (2.96) | % |  | (1.06) | % |  | (1.90) | % |
| Taxation on foreign inflation | 3.03 | % |  | 1.34 | % |  | 1.41 | % |
| Rate change | 4.46 | % |  | (3.71) | % |  | 1.27 | % |
| Valuation allowance | 2.15 | % |  | 9.44 | % |  | 8.35 | % |
| Loss on equity transactions | — | % |  | (1.72) | % |  | — | % |
| Uncertain tax positions | 8.09 | % |  | 1.72 | % |  | 1.62 | % |
| Other | 1.77 | % |  | (0.89) | % |  | 0.20 | % |
| Effective income tax rate | 29.95 | % |  | 21.27 | % |  | 16.22 | % |

[0000936395-24-000044:notes:328]
Ciena’s future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations.

[0000936395-24-000044:notes:329]
The significant components of deferred tax assets are as follows (in thousands):

[0000936395-24-000044:notes:330]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 79,272 |  |  | $ | 82,160 |  |
| Depreciation and amortization | 760,685 |  |  | 712,098 |  |
| NOL and credit carry forward | 211,792 |  |  | 197,984 |  |
| Other | 26,574 |  |  | 6,934 |  |
| Gross deferred tax assets | 1,078,323 |  |  | 999,176 |  |
| Valuation allowance | (192,447) |  |  | (189,870) |  |
| Deferred tax asset, net of valuation allowance | $ | 885,876 |  |  | $ | 809,306 |  |

[0000936395-24-000044:notes:331]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-24-000044:notes:332]
|  | Amount |
| Unrecognized tax benefits at October 30, 2021 | $ | 77,091 |  |
| Increase related to positions taken in prior period | 4,732 |  |
| Reductions related to settlements with taxing authorities | (3,229) |  |
| Increase related to positions taken in current period | 2,959 |  |
| Reductions related to expiration of statute of limitations | (1,039) |  |
| Unrecognized tax benefits at October 29, 2022 | 80,514 |  |
| Increase related to positions taken in prior period | 9,940 |  |
| Reductions related to settlements with taxing authorities | (625) |  |
| Increase related to positions taken in current period | 4,960 |  |
| Reductions related to expiration of statute of limitations | (869) |  |
| Unrecognized tax benefits at October 28, 2023 | 93,920 |  |
| Increase related to positions taken in prior period | 11,482 |  |
| Reductions related to settlements with taxing authorities | (4,345) |  |
| Increase related to positions taken in current period | 4,340 |  |
| Reductions related to expiration of statute of limitations | (116) |  |
| Unrecognized tax benefits at November 2, 2024 | $ | 105,281 |  |

[0000936395-24-000044:notes:333]
As of November 2, 2024 and October 28, 2023, Ciena had accrued $16.3 million and $7.9 million of interest and penalties, respectively, related to unrecognized tax benefits included in other long-term obligations on the Consolidated Balance Sheets. Interest and penalties of $8.2 million, $2.7 million and $1.7 million were recorded as a net expense to the provision for income taxes during fiscal 2024, fiscal 2023 and fiscal 2022, respectively. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate.

[0000936395-24-000044:notes:334]
Changes in tax laws, regulations, administrative practices, and interpretations may impact Ciena’s tax contingencies. Due to various factors, the amounts ultimately paid, if any, upon the resolution of the issues raised by the taxing authorities may differ from the amounts accrued. It is reasonably possible that within the next twelve months Ciena will receive additional assessments by various tax authorities or possibly reach resolution of income tax controversies in one or more various jurisdictions. These factors could result in changes to our contingencies related to positions on prior years’ tax filings. Ciena cannot currently provide an estimate of potential changes. As statutes of limitation expire, unrecognized tax benefits including interest and penalties related to contingencies may be reversed, resulting in an income tax benefit. Over the next twelve months,

[0000936395-24-000044:notes:335]
Ciena estimates that statutes on approximately $26.4 million of unrecognized tax benefits may expire, which would result in a net tax benefit.

[0000936395-24-000044:notes:336]
As of November 2, 2024, we have approximately $93.0 million of undistributed earnings at our foreign subsidiaries that we identified in fiscal 2023 as no longer indefinitely reinvested and $1.5 million of deferred tax liability remaining on Ciena’s Consolidated Balance sheets for the income tax effects related to the future repatriation of these earnings. No additional income tax expense has been provided for any remaining undistributed foreign earnings, or any additional outside basis difference from investments in the foreign subsidiaries, as these amounts continue to be indefinitely reinvested. If remaining undistributed foreign earnings and profits of $415.0 million were repatriated to the U.S., the provisional amount of unrecognized deferred tax liability, which is primarily related to foreign withholding taxes, is an estimated $34.0 million; however, the amount may be lower depending on Ciena’s ability to utilize tax credits associated with the distribution. Additionally, there are no other significant temporary differences for which a deferred tax liability or asset is not being recognized.

[0000936395-24-000044:notes:337]
As of November 2, 2024, Ciena continues to maintain a valuation allowance of $192.4 million against its gross deferred tax assets primarily. The valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates that it will not be able to use.

[0000936395-24-000044:notes:338]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-24-000044:notes:339]
| Year Ended |  | Beginning Balance |  | Additions |  | Deductions |  | Ending Balance |
| October 29, 2022 |  | $ | 159,634 |  |  | $ | 15,245 |  |  | $ | 12,803 |  |  | $ | 162,076 |  |
| October 28, 2023 |  | $ | 162,076 |  |  | $ | 28,746 |  |  | $ | 952 |  |  | $ | 189,870 |  |
| November 2, 2024 |  | $ | 189,870 |  |  | $ | 16,816 |  |  | $ | 14,239 |  |  | $ | 192,447 |  |

[0000936395-24-000044:notes:340]
As of November 2, 2024, Ciena had a $31.0 million net operating loss carry forward for U.S. federal income tax which does not expire, and $150.0 million net operating loss carry forwards for U.S. state income taxes which begin to expire in fiscal 2027. As of November 2, 2024, Ciena also had a $174.0 million net operating loss carry forward in non-U.S. jurisdictions which begin to expire in fiscal 2029. Ciena’s ability to use U.S. federal net operating losses is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-24-000044:notes:341]
SHARE-BASED COMPENSATION EXPENSE
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under the ESPP. Each of the 2017 Plan and the ESPP is described below.

[0000936395-24-000044:notes:342]
2017 Plan

[0000936395-24-000044:notes:343]
At Ciena’s 2024 Annual Meeting of Stockholders that was held on March 21, 2024, Ciena’s stockholders approved an amendment to the 2017 Plan, effective as of such date, to (i) increase the number of shares available for issuance thereunder by 10.1 million shares, and (ii) increase the recoupment period for misconduct relating to accounting restatements from 12 months to three years.

[0000936395-24-000044:notes:344]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs), and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-24-000044:notes:345]
The 2017 Plan authorizes and reserves 31.2 million shares for issuance. The number of shares available under the 2017 Plan is also increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition

[0000936395-24-000044:notes:346]
of another company. As of November 2, 2024, the total number of shares authorized for issuance under the 2017 Plan was 31.2 million and approximately 10.9 million shares remained available for issuance thereunder.

[0000936395-24-000044:notes:347]
Stock Options

[0000936395-24-000044:notes:348]
There were no stock options granted by Ciena during fiscal 2024, fiscal 2023 or fiscal 2022. There were no stock options outstanding as of November 2, 2024.

[0000936395-24-000044:notes:349]
The total intrinsic value of options exercised during fiscal 2024, fiscal 2023 and fiscal 2022 was $0.1 million, $0.3 million and $1.6 million, respectively.

[0000936395-24-000044:notes:350]
Assumptions for Option-Based Awards

[0000936395-24-000044:notes:351]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2024, fiscal 2023 or fiscal 2022.

[0000936395-24-000044:notes:352]
Restricted Stock Units

[0000936395-24-000044:notes:353]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part.

[0000936395-24-000044:notes:354]
During fiscal 2023, Ciena introduced a benefit pursuant to which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, the United Kingdom, or Canada, and who provide 12 months’ notice of their retirement, will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these and certain other countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their granted but unvested RSU awards upon retirement. This program accelerates the recognition of share-based compensation expense.

[0000936395-24-000044:notes:355]
Assumptions for Restricted Stock Unit Awards

[0000936395-24-000044:notes:356]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-24-000044:notes:357]
Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-24-000044:notes:358]
Share-based compensation expense for restricted stock units subject only to service-based vesting conditions and restricted stock units subject to performance-based vesting conditions other than total stockholder return, is recognized only for those awards that ultimately vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0000936395-24-000044:notes:359]
Ciena estimates the fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model. Ciena reverses share-based compensation expense on performance based awards subject to total stockholder return only when the requisite service period is not reached. Assumptions for awards granted during fiscal 2024, fiscal 2023 and fiscal 2022 included the following:

[0000936395-24-000044:notes:360]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 36.00% |  | 40.37% |  | 38.27% |
| Historical volatility of Ciena common stock | 36.74% |  | 43.11% |  | 42.17% |
| Volatility of S&P Networking Index(1) | 44.94% |  | 30.93% |  | 27.22% |
| Correlation coefficient | 0.3665 |  | 0.7781 |  | 0.7049 |
| Expected life in years | 2.89 |  | 2.89 |  | 2.89 |
| Risk-free interest rate | 4.41% |  | 3.95% |  | 0.94% |
| Expected dividend yield | 0.0% |  | 0.0% |  | 0.0% |

[0000936395-24-000044:notes:361]
(1) For fiscal 2023 and fiscal 2022, reflects the volatility of the S&P Networking Index as a whole. For fiscal 2024, reflects the volatility of the median company within the S&P Networking Index as of the date of the award, measured as of the last day of fiscal 2023.

[0000936395-24-000044:notes:362]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-24-000044:notes:363]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance at October 28, 2023 | 4,922 |  |  | $ | 53.42 |  |  | $ | 201,916 |  |
| Granted | 4,080 |  |  |  |  |  |
| Vested | (2,382) |  |  |  |  |  |
| Canceled or forfeited | (508) |  |  |  |  |  |
| Balance at November 2, 2024 | 6,112 |  |  | $ | 48.41 |  |  | $ | 390,995 |  |

[0000936395-24-000044:notes:364]
As of both November 2, 2024 and October 28, 2023, 0.3 million of the total restricted stock units outstanding are performance based awards subject to total stockholder return. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2024, fiscal 2023 and fiscal 2022 was $116.9 million, $98.2 million and $119.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2024, fiscal 2023 and fiscal 2022 was $44.57, $50.48 and $67.03, respectively.

[0000936395-24-000044:notes:365]
Amended and Restated ESPP

[0000936395-24-000044:notes:366]
Ciena makes shares of its common stock available for purchase under the ESPP, under which eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0000936395-24-000044:notes:367]
During fiscal 2024, Ciena issued 0.9 million shares and during fiscal 2023 and fiscal 2022, Ciena issued 0.8 million and 0.7 million shares, respectively, under the ESPP. At November 2, 2024, 10.4 million shares remained available for issuance under the ESPP.

[0000936395-24-000044:notes:368]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-24-000044:notes:369]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Products | $ | 6,474 |  |  | $ | 4,518 |  |  | $ | 3,867 |  |
| Services | 12,743 |  |  | 10,470 |  |  | 7,533 |  |
| Share-based compensation expense included in cost of goods sold | 19,217 |  |  | 14,988 |  |  | 11,400 |  |
| Research and development | 54,129 |  |  | 42,331 |  |  | 31,879 |  |
| Sales and marketing | 42,954 |  |  | 35,136 |  |  | 31,280 |  |
| General and administrative | 40,053 |  |  | 37,587 |  |  | 30,435 |  |
| Share-based compensation expense included in operating expense | 137,136 |  |  | 115,054 |  |  | 93,594 |  |
| Share-based compensation expense capitalized in inventory, net | 51 |  |  | 413 |  |  | 137 |  |
| Total share-based compensation | $ | 156,404 |  |  | $ | 130,455 |  |  | $ | 105,131 |  |

[0000936395-24-000044:notes:370]
As of November 2, 2024, total unrecognized share-based compensation expense was $212.9 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.33 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-24-000044:notes:371]
SEGMENT AND ENTITY WIDE DISCLOSURES
Segment Reporting

[0000936395-24-000044:notes:372]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services.

[0000936395-24-000044:notes:373]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena’s chief operating decision maker for purposes of evaluating performance and allocating resources. As of November 2, 2024, equipment, building, furniture and fixtures, net, totaled $337.7 million, and operating ROU assets totaled $27.4 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of November 2, 2024, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-24-000044:notes:374]
|  | November 2, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 158,903 |  |  | $ | — |  |  | $ | 6,117 |  |  | $ | — |  |  | $ | 165,020 |  |
| Goodwill | $ | 199,467 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 444,707 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 77,918 |  |  | $ | 77,918 |  |

[0000936395-24-000044:notes:375]
Segment Profit (Loss)

[0000936395-24-000044:notes:376]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income, net; interest expense; loss on extinguishment and modification of debt; and provision for income taxes.

[0000936395-24-000044:notes:377]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income for the respective periods indicated (in thousands):

[0000936395-24-000044:notes:378]
|  | Year Ended |
|  | November 2, 2024 |  | October 28, 2023 |  | October 29, 2022 |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 536,510 |  |  | $ | 778,641 |  |  | $ | 572,305 |  |
| Platform Software and Services | 231,900 |  |  | 186,945 |  |  | 175,108 |  |
| Blue Planet Automation Software and Services | (11,892) |  |  | (33,669) |  |  | (22,388) |  |
| Global Services | 195,575 |  |  | 196,375 |  |  | 210,663 |  |
| Total segment profit | 952,093 |  |  | 1,128,292 |  |  | 935,688 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 510,668 |  |  | 490,804 |  |  | 466,565 |  |
| General and administrative | 220,647 |  |  | 215,284 |  |  | 179,382 |  |
| Significant asset impairments and restructuring costs | 24,592 |  |  | 23,834 |  |  | 33,824 |  |
| Amortization of intangible assets | 29,569 |  |  | 37,351 |  |  | 32,511 |  |
| Acquisition and integration costs | — |  |  | 3,474 |  |  | 598 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income, net | 50,261 |  |  | 62,008 |  |  | 6,747 |  |
| Interest expense | (97,028) |  |  | (88,026) |  |  | (47,050) |  |
| Loss on extinguishment and modification of debt | — |  |  | (7,874) |  |  | — |  |
| Less: Provision for income taxes | 35,894 |  |  | 68,826 |  |  | 29,603 |  |
| Consolidated net income | $ | 83,956 |  |  | $ | 254,827 |  |  | $ | 152,902 |  |

[0000936395-24-000044:notes:379]
Entity Wide Reporting

[0000936395-24-000044:notes:380]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-24-000044:notes:381]
|  | November 2, 2024 |  | October 28, 2023 |  |  |
| Canada | $ | 283,760 |  |  | $ | 229,707 |  |  |  |
| United States | 49,195 |  |  | 46,933 |  |  |  |
| Other International | 32,184 |  |  | 38,647 |  |  |  |
| Total | $ | 365,139 |  |  | $ | 315,287 |  |  |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-24-000044:notes:382]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit of CAD$32,490 (approximately $23,284 for 2024). This plan includes a required employer contribution of 1% for all participants and an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. During fiscal 2024, 2023 and 2022, Ciena made matching contributions of approximately CAD$11.6 million (approximately $8.3 million), CAD$10.6 million (approximately $7.6 million) and CAD$10.1 million (approximately $7.2 million), respectively.

[0000936395-24-000044:notes:383]
Ciena has a 401(k) defined contribution profit sharing plan that covers a majority of its United States-based employees. Participants may contribute up to 60% of base pay through pre-tax or Roth contributions, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 8% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2024, 2023 and 2022, Ciena made matching contributions of approximately $11.0 million, $10.4 million and $9.2 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-24-000044:notes:384]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-24-000044:notes:385]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-24-000044:notes:386]
Litigation

[0000936395-24-000044:notes:387]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-24-000044:notes:388]
Purchase Order Obligations

[0000936395-24-000044:notes:389]
Ciena has certain advanced orders for supply of certain long lead time components. As of November 2, 2024, Ciena had $1.7 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-24-000044:notes:390]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-24-000044:notes:391]
From the end of the fourth quarter of fiscal 2024 through December 13, 2024, Ciena repurchased 540,521 shares of its common stock for an aggregate purchase price of $38.3 million at an average price of $70.82 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of December 13, 2024, Ciena has an aggregate of $961.7 million of authorized funds remaining under this repurchase program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000936395-24-000044:notes:392]
The following table describes, for the quarter ended November 2, 2024, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0000936395-24-000044:notes:393]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Dino DiPerna (Senior Vice President, Global Research & Development) | Adoption (September 11, 2024) | Rule 10b5-1 trading arrangement | Sales | Until October 31, 2025, or such earlier date upon which all transactions are completed or expire without execution | (1) |
| Brodie Gage (Senior Vice President, Global Products & Supply Chain) | Adoption (September 6, 2024) | Rule 10b5-1 trading arrangement | Sales | Until November 28, 2025, or such earlier date upon which all transactions are completed or expire without execution | Up to 3,961 shares of common stock |
| Sheela Kosaraju (Senior Vice President and General Counsel, and acting Chief People Officer) | Adoption (October 14, 2024) | Rule 10b5-1 trading arrangement | Sales | Until January 9, 2026, or such earlier date upon which all transactions are completed or expire without execution | (2) |
| Jason Phipps (Senior Vice President, Global Customer Engagement) | Adoption (October 9, 2024) | Rule 10b5-1 trading arrangement | Sales | Until October 9, 2026, or such earlier date upon which all transactions are completed or expire without execution | (3) |
| Gary B. Smith (President and Chief Executive Officer) | Adoption (September 11, 2024) | Rule 10b5-1 trading arrangement | Sales | Until December 22, 2025, or such earlier date upon which all transactions are completed or expire without execution | Up to 170,000 shares of common stock |
