# CIEN MD&A — 0000936395-24-000044


## mdna

[0000936395-24-000044:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-24-000044:mdna:2]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-24-000044:mdna:3]
Overview

[0000936395-24-000044:mdna:4]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, video, data, AI, and voice. Our network solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network™, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking portfolio and our Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently, and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator NCS and advanced applications that deliver multi-layer domain control and operations for network operators. Through our Blue Planet Automation Software, we also enable complete service lifecycle management automation with productized OSS, including inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-24-000044:mdna:5]
Market Opportunity and Investment in Technology Innovation

[0000936395-24-000044:mdna:6]
The market into which we sell our communications networking solutions is dynamic and characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Drivers of increased bandwidth demand include enterprise and consumer cloud network adoption, generative AI, 5G, high-definition video, and network operator focus on resilience and automation. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation.

[0000936395-24-000044:mdna:7]
We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures, and research and development spending represented 19.1% of our operating expenses in fiscal 2024. During fiscal 2024, we invested $767.5 million in research and development activities, an increase of 2.3% compared to fiscal 2023. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, in fiscal 2024 we continued to innovate, increase the performance of, and enhance the capabilities for our leading WaveLogic coherent modem technology in multiple form factors. Through this innovation we seek to extend our leadership in our core business and leverage this to expand our addressable market into complementary and adjacent network applications, including inside and around the data center.

[0000936395-24-000044:mdna:8]
Our business strategy to capitalize on these market dynamics and investment opportunities also include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part I of this annual report.

[0000936395-24-000044:mdna:9]
Fluctuation in Order Volumes and Impact on Fiscal 2024 Revenue

[0000936395-24-000044:mdna:10]
During fiscal 2021 and fiscal 2022, we received an unprecedented volume of orders for our products and services. We believe some portion of these orders reflected customer acceleration of future orders due to long lead times during the constrained supply environment of that period, as well as orders that were delayed due to the dynamics of the COVID-19 pandemic. These order volumes resulted in significant revenue growth in fiscal 2023. Our order volumes began to moderate in the fourth quarter of fiscal 2022, and we experienced order levels below revenue during fiscal 2023 and the first half of fiscal 2024, particularly from our communications service provider customers. We believe this was, in part, due to communications service providers in North America working through relatively high levels of inventory previously acquired, which was made more difficult due to challenges installing and deploying equipment. In addition, in certain international geographies, we believe that caution driven by macroeconomic concerns and market-specific issues contributed to lower-than-expected order volumes from communications service providers during fiscal 2024. As a result of these dynamics, our revenue for fiscal 2024 was lower than our revenue in fiscal 2023. Notwithstanding these recent dynamics and their impact on fiscal 2024 revenue, we

[0000936395-24-000044:mdna:11]
continue to believe that certain trends and shifts in business and consumer behaviors and the drivers of bandwidth demand described above under “Market Opportunity and Investment in Technology Innovation” represent long-term opportunities for our business.

[0000936395-24-000044:mdna:12]
Fiscal Year-End Backlog

[0000936395-24-000044:mdna:13]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These agreements do not obligate customers to purchase any minimum or guaranteed order quantities. In calculating backlog, we only include (i) customer purchase orders for products that have not been shipped and for services that have not yet been performed; and (ii) customer orders relating to products that have been delivered and services that have been performed, but are awaiting customer acceptance under the applicable contract terms. Backlog may be fulfilled several quarters following receipt of a purchase order, or in the case of certain service obligations, may relate to multi-year support periods.

[0000936395-24-000044:mdna:14]
Our backlog was $2.1 billion as of November 2, 2024, as compared to $2.6 billion as of October 28, 2023. Backlog includes product and service orders from commercial and government customers combined. Backlog at November 2, 2024 includes approximately $352.5 million primarily related to orders for products and services that are not expected to be filled or performed within fiscal 2025. Because backlog can be defined in different ways by different companies, our presentation of backlog may not be comparable with figures presented by other companies in our industry. In addition, our customers may cancel, delay or change their orders with limited advance notice, or they may decide not to accept our products and services. The timing of our fulfillment of backlog could cause some volatility in our results of operations.

[0000936395-24-000044:mdna:15]
Stock Repurchase Program

[0000936395-24-000044:mdna:16]
On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, commencing in fiscal 2025 and continuing through the end of fiscal 2027. Authorized purchases contemplated under our prior stock repurchase program, which was authorized in fiscal 2022, were completed in fiscal 2024. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 21 and 27 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:17]
Consolidated Results of Operations

[0000936395-24-000044:mdna:18]
A discussion regarding our financial condition and results of operations for fiscal 2024 compared to fiscal 2023 is presented below. A discussion of fiscal 2023 compared to fiscal 2022 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended October 28, 2023, filed with the SEC on December 15, 2023, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-24-000044:mdna:19]
Operating Segments

[0000936395-24-000044:mdna:20]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Notes 2 and 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0000936395-24-000044:mdna:21]
Fiscal 2024 Compared to Fiscal 2023

[0000936395-24-000044:mdna:22]
Revenue

[0000936395-24-000044:mdna:23]
Revenue and Currency Fluctuations

[0000936395-24-000044:mdna:24]
As a result of the factors impacting order volumes described under “Overview” above, our revenue declined by 8.5% in fiscal 2024 as compared to fiscal 2023. In addition, during fiscal 2024, approximately 14.3% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Indian Rupees and Canadian Dollars. During fiscal 2024, as compared to fiscal 2023, the U.S. Dollar fluctuated against these and other currencies with minimal impact as compared to fiscal 2023.

[0000936395-24-000044:mdna:25]
Operating Segment Revenue

[0000936395-24-000044:mdna:26]
See Notes 2 and 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-24-000044:mdna:27]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,642,563 |  |  | 65.8 |  | $ | 2,987,245 |  |  | 68.1 |  | $ | (344,682) |  |  | (11.5) |
| Routing and Switching | 399,492 |  |  | 10.0 |  | 506,247 |  |  | 11.5 |  | (106,755) |  |  | (21.1) |
| Total Networking Platforms | 3,042,055 |  |  | 75.8 |  | 3,493,492 |  |  | 79.6 |  | (451,437) |  |  | (12.9) |
| Platform Software and Services | 358,062 |  |  | 8.9 |  | 303,873 |  |  | 6.9 |  | 54,189 |  |  | 17.8 |
| Blue Planet Automation Software and Services | 77,619 |  |  | 2.0 |  | 69,170 |  |  | 1.6 |  | 8,449 |  |  | 12.2 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 303,086 |  |  | 7.5 |  | 288,334 |  |  | 6.6 |  | 14,752 |  |  | 5.1 |
| Installation and Deployment | 184,358 |  |  | 4.6 |  | 180,951 |  |  | 4.1 |  | 3,407 |  |  | 1.9 |
| Consulting and Network Design | 49,775 |  |  | 1.2 |  | 50,729 |  |  | 1.2 |  | (954) |  |  | (1.9) |
| Total Global Services | 537,219 |  |  | 13.3 |  | 520,014 |  |  | 11.9 |  | 17,205 |  |  | 3.3 |
| Consolidated revenue | $ | 4,014,955 |  |  | 100.0 |  | $ | 4,386,549 |  |  | 100.0 |  | $ | (371,594) |  |  | (8.5) |

[0000936395-24-000044:mdna:28]
_________________________________

[0000936395-24-000044:mdna:29]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:30]
•Networking Platforms segment revenue decreased by $451.4 million, reflecting product line sales decreases of $344.7 million of our Optical Networking products and $106.7 million of our Routing and Switching products.

[0000936395-24-000044:mdna:31]
◦Optical Networking sales decreased, primarily reflecting sales decreases of $470.3 million of our 6500

[0000936395-24-000044:mdna:32]
Packet-Optical Platform primarily to communications service providers, enterprise customers, cable and multiservice operators, and cloud providers, and $17.2 million of our 5400 family of Packet-Optical Platforms primarily to communications service providers. These sales decreases were partially offset by sales increases of $63.1 million primarily of our coherent pluggable transceivers, primarily to cloud providers, $45.2 million of our 6500 RLS products primarily to communications service providers, cable and multiservice operators and cloud providers, and $35.8 million of our Waveserver® products primarily to communications service providers, partially offset by sales decreases to enterprise customers and cloud providers.

[0000936395-24-000044:mdna:33]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $103.8 million of our 3000 and 5000 families of service delivery and aggregation switches primarily to communications service providers, cable and multiservice operators, and enterprise customers, $8.9 million of our 8700 Packetwave Platform, primarily to communications service providers and enterprise customers, $5.4 million of our virtualization software, primarily to communications service providers partially offset by increased sales to enterprise customers, and $4.3 million of our passive optical network (PON) products, primarily to communications service providers. These sales decreases were partially offset by sales increases of $8.7 million of our platform independent software, primarily to communications service providers and cloud providers, $4.8 million of our WaveRouter products, primarily to communications service providers, and $3.6 million of our 8100 Coherent IP networking platforms, primarily to enterprise customers and cloud providers.

[0000936395-24-000044:mdna:34]
•Platform Software and Services segment revenue increased by $54.2 million, reflecting sales increases of $32.3 million in sales of software platforms and $21.9 million in sales of our software maintenance services, both primarily for our Navigator NCS software platform.

[0000936395-24-000044:mdna:35]
•Blue Planet Automation Software and Services segment revenue increased by $8.4 million, primarily reflecting a sales increase of $11.4 million in professional software services primarily for our BPI and ROA platforms partially offset by a sales decrease of $2.9 million in software platforms.

[0000936395-24-000044:mdna:36]
•Global Services segment revenue increased by $17.2 million, primarily reflecting sales increases of $14.8 million of our maintenance support and training and $3.4 million of our installation and deployment services.

[0000936395-24-000044:mdna:37]
Revenue by Geographic Region

[0000936395-24-000044:mdna:38]
Our operating segments engage in business and operations across three geographic regions: Americas, EMEA, and APAC. The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The decrease in our Americas region revenue for fiscal 2024 was primarily driven by decreased sales in Canada and the United States. The decrease in our APAC region revenue for fiscal 2024 was primarily driven by decreased sales in Australia, India, Singapore and South Korea. The increase in our EMEA region revenue for fiscal 2024 was partially offset by sales decreases in Great Britain and the Netherlands. The following table reflects our geographic distribution of revenue, which is principally based on the relevant location for the delivery of our products and performance of services. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-24-000044:mdna:39]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 2,951,915 |  |  | 73.5 |  | $ | 3,110,347 |  |  | 70.9 |  | $ | (158,432) |  |  | (5.1) |
| EMEA | 648,870 |  |  | 16.2 |  | 643,142 |  |  | 14.7 |  | 5,728 |  |  | 0.9 |
| APAC | 414,170 |  |  | 10.3 |  | 633,060 |  |  | 14.4 |  | (218,890) |  |  | (34.6) |
| Total | $ | 4,014,955 |  |  | 100.0 |  | $ | 4,386,549 |  |  | 100.0 |  | $ | (371,594) |  |  | (8.5) |

[0000936395-24-000044:mdna:40]
_________________________________

[0000936395-24-000044:mdna:41]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:42]
•Americas revenue decreased by $158.4 million, reflecting a sales decrease of $207.3 million within our Networking Platforms segment. This sales decrease was offset by sales increases of $40.4 million within our Platform Software and Services segment, $5.4 million within our Global Services segment, and $3.1 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue decrease reflects product line sales decreases of $126.9 million of Optical Networking products and $80.4 million of Routing and Switching products. Our Optical Networking revenue primarily reflects a sales decrease of $248.7 million of our 6500 Packet-Optical Platform, primarily to communications service providers, enterprise customers, cable and multiservice operators, and cloud providers. This sales decrease was partially offset by sales increases of $57.1 million primarily of our coherent pluggable transceivers primarily to cloud providers, $55.4 million of our 6500 RLS products primarily to cloud providers and cable and multiservice operators, and $19.5 million of our Waveserver® modular interconnect system, primarily to communications service providers partially offset by decreased sales to cloud providers. Routing and Switching product line sales primarily reflect a sales decrease of $83.9 million of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers, cable and multiservice operators, and enterprise customers.

[0000936395-24-000044:mdna:43]
•EMEA revenue increased by $5.7 million, primarily reflecting sales increases of $12.2 million within our Global Services segment and $5.5 million within our Platform Software and Services segment. These sales increases were partially offset by a sales decrease of $10.9 million within our Networking Platforms segment.

[0000936395-24-000044:mdna:44]
•APAC revenue decreased by $218.9 million, primarily reflecting a sales decrease of $233.2 million within our Networking Platforms segment. This sales decrease was partially offset by sales increases of $8.3 million within our Platform Software and Services segment and $6.4 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a product line sales decrease of $237.0 million of Optical Networking products, including a sales decrease of $198.3 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers.

[0000936395-24-000044:mdna:45]
In fiscal 2024 and fiscal 2023, our top ten customers contributed 57.9% and 53.7% of our revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can

[0000936395-24-000044:mdna:46]
be significantly affected by market, industry or competitive dynamics affecting the businesses of those customers. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Sales to one of our cloud provider customers were $532.3 million, or 13.3% of total revenue, in fiscal 2024 and $561.4 million or 12.8% of total revenue, in fiscal 2023. Sales to AT&T were $475.3 million, or 11.8% of total revenue, in fiscal 2024, and $464.7 million, or 10.6% of total revenue, in fiscal 2023. No other customer accounted for greater than 10% of our revenue in fiscal 2024 or fiscal 2023.

[0000936395-24-000044:mdna:47]
While drivers of bandwidth growth and network evolution remain strong, many of our service provider customers are under pressure to constrain their capital expenditure budgets, and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or add features, there is a market expectation for solutions that are more cost-effective than existing or competing solutions and that new products consistently deliver lower price per bit performance. The combination of this regular technology-driven price compression, price competition in our markets, and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-24-000044:mdna:48]
Cost of Goods Sold and Gross Profit

[0000936395-24-000044:mdna:49]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-24-000044:mdna:50]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-24-000044:mdna:51]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, as well as our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive annual product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in gaining market share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity and need to monitor their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-24-000044:mdna:52]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-24-000044:mdna:53]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-24-000044:mdna:54]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 4,014,955 |  |  | 100.0 |  | $ | 4,386,549 |  |  | 100.0 |  | $ | (371,594) |  |  | (8.5) |
| Total cost of goods sold | 2,295,365 |  |  | 57.2 |  | 2,507,698 |  |  | 57.2 |  | (212,333) |  |  | (8.5) |
| Gross profit | $ | 1,719,590 |  |  | 42.8 |  | $ | 1,878,851 |  |  | 42.8 |  | $ | (159,261) |  |  | (8.5) |

[0000936395-24-000044:mdna:55]
_________________________________

[0000936395-24-000044:mdna:56]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:57]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 3,159,021 |  |  | 100.0 |  | $ | 3,581,039 |  |  | 100.0 |  | $ | (422,018) |  |  | (11.8) |
| Product cost of goods sold | 1,861,317 |  |  | 58.9 |  | 2,088,440 |  |  | 58.3 |  | (227,123) |  |  | (10.9) |
| Product gross profit | $ | 1,297,704 |  |  | 41.1 |  | $ | 1,492,599 |  |  | 41.7 |  | $ | (194,895) |  |  | (13.1) |

[0000936395-24-000044:mdna:58]
_________________________________

[0000936395-24-000044:mdna:59]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:60]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Services revenue | $ | 855,934 |  |  | 100.0 |  | $ | 805,510 |  |  | 100.0 |  | $ | 50,424 |  |  | 6.3 |
| Services cost of goods sold | 434,048 |  |  | 50.7 |  | 419,258 |  |  | 52.0 |  | 14,790 |  |  | 3.5 |
| Services gross profit | $ | 421,886 |  |  | 49.3 |  | $ | 386,252 |  |  | 48.0 |  | $ | 35,634 |  |  | 9.2 |

[0000936395-24-000044:mdna:61]
_________________________________

[0000936395-24-000044:mdna:62]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:63]
•Gross profit decreased by $159.3 million. Gross margin for fiscal 2024 compared to fiscal 2023 remained consistent, primarily reflecting slightly decreased product margin offset by increased services margin.

[0000936395-24-000044:mdna:64]
•Gross profit on products decreased by $194.9 million. Product gross margin slightly decreased by 60 basis points, primarily due to a higher concentration of lower margin product mix and higher inventory excess and obsolescence costs partially offset by product cost reductions and improved manufacturing efficiencies.

[0000936395-24-000044:mdna:65]
•Gross profit on services increased by $35.6 million. Service gross margin increased by 130 basis points, primarily due to improved margins on Blue Planet software services due to improved efficiencies on delivery, partially offset by lower margins on maintenance support and training.

[0000936395-24-000044:mdna:66]
Operating Expense

[0000936395-24-000044:mdna:67]
Currency Fluctuations

[0000936395-24-000044:mdna:68]
During fiscal 2024, approximately 48.7% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, Indian Rupees, and Euros. During fiscal 2024 as compared to fiscal 2023, the U.S. Dollar primarily strengthened against these and other currencies with minimal impact as compared to fiscal 2023.

[0000936395-24-000044:mdna:69]
Operating expense increased in fiscal 2024 from the level reported for fiscal 2023, primarily due to increases in employee headcount. We have also experienced, and are continuing to experience, increases in the cost of labor and other costs of doing business due to inflation, and continued inflationary pressures could have an adverse impact on our profitability. We expect operating expense to continue to increase from the level reported in fiscal 2024 primarily due to planned investment in research and development to advance our strategy and higher employee compensation costs.

[0000936395-24-000044:mdna:70]
Operating expense consists of the component elements described below.

[0000936395-24-000044:mdna:71]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-24-000044:mdna:72]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-24-000044:mdna:73]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-24-000044:mdna:74]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-24-000044:mdna:75]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-24-000044:mdna:76]
•Acquisition and integration costs primarily consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition activity. For more information on our acquisitions, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:77]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-24-000044:mdna:78]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 767,497 |  |  | 19.1 |  | $ | 750,559 |  |  | 17.1 |  | $ | 16,938 |  |  | 2.3 |
| Selling and marketing | 510,668 |  |  | 12.7 |  | 490,804 |  |  | 11.2 |  | 19,864 |  |  | 4.0 |
| General and administrative | 220,647 |  |  | 5.5 |  | 215,284 |  |  | 4.9 |  | 5,363 |  |  | 2.5 |
| Significant asset impairments and restructuring costs | 24,592 |  |  | 0.6 |  | 23,834 |  |  | 0.5 |  | 758 |  |  | 3.2 |
| Amortization of intangible assets | 29,569 |  |  | 0.7 |  | 37,351 |  |  | 0.9 |  | (7,782) |  |  | (20.8) |
| Acquisition and integration costs | — |  |  | — |  | 3,474 |  |  | 0.1 |  | (3,474) |  |  | (100.0) |
| Total operating expenses | $ | 1,552,973 |  |  | 38.6 |  | $ | 1,521,306 |  |  | 34.7 |  | $ | 31,667 |  |  | 2.1 |

[0000936395-24-000044:mdna:79]
_________________________________

[0000936395-24-000044:mdna:80]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:81]
•Research and development expense increased by $16.9 million, net of hedging. This increase primarily reflects increases in employee-related compensation costs, partially due to higher headcount and increases in salary and share-based compensation costs. In addition, facility, information technology costs and other technology related costs increased, partially offset by decreased professional services and a lower provision associated with our annual cash incentive compensation plan.

[0000936395-24-000044:mdna:82]
•Selling and marketing expense increased by $19.9 million. This increase primarily reflects increases in employee-related compensation costs due to higher variable compensation and share-based compensation, and increases in travel and entertainment costs.

[0000936395-24-000044:mdna:83]
•General and administrative expense expense increased by $5.4 million. This increase primarily reflects increases in employee-related compensation costs, primarily due to increases in salary and share-based compensation costs. In addition, facility and information technology costs increased, partially offset by a lower provision associated with our annual cash incentive compensation plan.

[0000936395-24-000044:mdna:84]
•Significant asset impairments and restructuring costs slightly increased, primarily reflecting an increase in workforce reduction costs of $8.5 million, partially offset by a decline of $7.7 million in costs associated with actions to redesign certain business processes associated with our supply chain and distribution structure reorganization and costs related to restructured real estate facilities. For more information on our restructuring costs, see Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:85]
•Amortization of intangible assets decreased by $7.8 million primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-24-000044:mdna:86]
•Acquisition and integration costs in fiscal 2023 reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu Networks (“Benu”) and Tibit Communications, Inc. (“Tibit”) during the first quarter of fiscal 2023.

[0000936395-24-000044:mdna:87]
Other Items

[0000936395-24-000044:mdna:88]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-24-000044:mdna:89]
|  | Fiscal Year |  |  |  |  |
|  | 2024 |  | %* |  | 2023 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income, net | $ | 50,261 |  |  | 1.3 |  | $ | 62,008 |  |  | 1.4 |  | $ | (11,747) |  |  | (18.9) |
| Interest expense | $ | (97,028) |  |  | (2.4) |  | $ | (88,026) |  |  | (2.0) |  | $ | 9,002 |  |  | 10.2 |
| Loss on extinguishment and modification of debt | $ | — |  |  | — |  | $ | (7,874) |  |  | (0.2) |  | $ | (7,874) |  |  | (100.0) |
| Provision for income taxes | $ | 35,894 |  |  | 0.9 |  | $ | 68,826 |  |  | 1.6 |  | $ | (32,932) |  |  | (47.8) |

[0000936395-24-000044:mdna:90]
_________________________________

[0000936395-24-000044:mdna:91]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:92]
•Interest and other income, net decreased by $11.7 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, in fiscal 2023, which resulted in a gain on our equity investment of $26.5 million and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. These decreases were partially offset by higher interest income on our investments. For more information on our acquisition of Tibit, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:93]
•Interest expense increased, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:94]
•Loss on extinguishment and modification of debt primarily reflects $1.9 million of extinguishment of debt costs and $6.0 million in debt modification costs, both related to our term loan refinancing which occurred in the fourth quarter of fiscal 2023. For more information, see Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:95]
•Provision for income taxes decreased by $32.9 million, primarily due to the decrease in pre-tax income in fiscal 2024. Similarly, the effective tax rate for fiscal 2024 was higher than the effective tax rate for fiscal 2023, primarily due to the decrease in pre-tax income.

[0000936395-24-000044:mdna:96]
Segment Profit (Loss)

[0000936395-24-000044:mdna:97]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-24-000044:mdna:98]
|  | Fiscal Year |  |  |
|  | 2024 |  | 2023 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 536,510 |  |  | $ | 778,641 |  |  | $ | (242,131) |  |  | (31.1) |
| Platform Software and Services | $ | 231,900 |  |  | $ | 186,945 |  |  | $ | 44,955 |  |  | 24.0 |
| Blue Planet Automation Software and Services | $ | (11,892) |  |  | $ | (33,669) |  |  | $ | 21,777 |  |  | 64.7 |
| Global Services | $ | 195,575 |  |  | $ | 196,375 |  |  | $ | (800) |  |  | (0.4) |

[0000936395-24-000044:mdna:99]
_________________________________

[0000936395-24-000044:mdna:100]
| * | Denotes % change from 2023 to 2024 |

[0000936395-24-000044:mdna:101]
•Networking Platforms segment profit decreased by $242.1 million, primarily due to lower product sales volume and lower product margin, as described above and increased research and development costs.

[0000936395-24-000044:mdna:102]
•Platform Software and Services segment profit increased by $45.0 million, primarily due to higher sales volume as described above, partially offset by increased research and development costs.

[0000936395-24-000044:mdna:103]
•Blue Planet Automation Software and Services segment loss decreased by $21.8 million, primarily due to higher gross margin on software-related services, increased sales volume, as described above, and decreased research and development costs.

[0000936395-24-000044:mdna:104]
•Global Services segment profit decreased slightly by $0.8 million, primarily due to lower gross margin on maintenance support and training partially offset by higher sales volume, as described above.

[0000936395-24-000044:mdna:105]
Liquidity and Capital Resources

[0000936395-24-000044:mdna:106]
Overview. For the fiscal year ended November 2, 2024, we generated $514.5 million of cash from operations. Net income (adjusted for non-cash charges) provided cash of $411.8 million and our working capital provided cash of $102.7 million. For additional details on our cash provided by operating activities, see the discussion below under the caption “Cash Provided by Operating Activities.”

[0000936395-24-000044:mdna:107]
Cash, cash equivalents and investments increased by $82.5 million during fiscal 2024. Cash from operations was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $254.5 million; (ii) cash used to fund our investing activities for capital expenditures totaling $136.6 million; (iii) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $46.6 million; (iv) cash used for our purchase of an equity investment in a privately held technology company of $21.7 million; and (v) cash used for payments on our term loan due October 28, 2030 (the “2030 New Term Loan”) of $11.7 million. In addition to cash provided by operations, the issuance of equity under our employee stock purchase plans provided $34.3 million in cash during fiscal 2024.

[0000936395-24-000044:mdna:108]
See Notes 18 and 21 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to these transactions.

[0000936395-24-000044:mdna:109]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-24-000044:mdna:110]
|  | November 2, 2024 |  | October 28, 2023 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 934,863 |  |  | $ | 1,010,618 |  |  | $ | (75,755) |  |
| Short-term investments in marketable debt securities | 316,343 |  |  | 104,753 |  |  | 211,590 |  |
| Long-term investments in marketable debt securities | 80,920 |  |  | 134,278 |  |  | (53,358) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,332,126 |  |  | $ | 1,249,649 |  |  | $ | 82,477 |  |

[0000936395-24-000044:mdna:111]
Principal Sources of Liquidity. Our principal sources of liquidity include our cash, cash equivalents and investments, which as of November 2, 2024 totaled $1.3 billion, as well as the unused portion of the Revolving Credit Facility (as defined in Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report). The Revolving Credit Facility, which we and certain of our subsidiaries entered into on October 24, 2023, replaced the ABL Credit Facility (as defined in Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report) and provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of November 2, 2024, letters of credit totaling $59.1 million were outstanding under our Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of November 2, 2024.

[0000936395-24-000044:mdna:112]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $161.7 million as of November 2, 2024. Approximately $93.0 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:113]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock. During fiscal 2024, we repurchased an additional $250.0 million of our common stock under the stock repurchase program, which completed the authorized repurchases contemplated under the current program. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, commencing in fiscal 2025 and continuing through the end of fiscal 2027. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash

[0000936395-24-000044:mdna:114]
flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Notes 21 and 27 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:115]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and we will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-24-000044:mdna:116]
Cash Provided by Operating Activities

[0000936395-24-000044:mdna:117]
The following sections set forth the components of our $514.5 million of cash provided by operating activities for fiscal 2024:

[0000936395-24-000044:mdna:118]
Net Income (adjusted for non-cash charges)

[0000936395-24-000044:mdna:119]
The following table sets forth our net income (adjusted for non-cash charges) during fiscal 2024 (in thousands):

[0000936395-24-000044:mdna:120]
|  | Year Ended |
|  | November 2, 2024 |
| Net income | $ | 83,956 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 92,846 |  |
| Share-based compensation costs | 156,404 |  |
| Amortization of intangible assets | 40,624 |  |
| Deferred taxes | (76,810) |  |
| Provision for inventory excess and obsolescence | 77,341 |  |
| Provision for warranty | 25,643 |  |
| Other | 11,768 |  |
| Net income (adjusted for non-cash charges) | $ | 411,772 |  |

[0000936395-24-000044:mdna:121]
Working Capital

[0000936395-24-000044:mdna:122]
The following table sets forth the major components of the cash provided by working capital (in thousands):

[0000936395-24-000044:mdna:123]
|  | Year Ended |
|  | November 2, 2024 |
| Cash provided by accounts receivable | $ | 80,313 |  |
| Cash provided by inventories | 153,021 |  |
| Cash used in prepaid expenses and other | (198,910) |  |
| Cash provided by accounts payable, accruals and other obligations | 64,255 |  |
| Cash provided by deferred revenue | 9,884 |  |
| Cash used in operating lease assets and liabilities, net | (5,803) |  |
| Total cash provided by working capital | $ | 102,760 |  |

[0000936395-24-000044:mdna:124]
As compared to the end of fiscal 2023:

[0000936395-24-000044:mdna:125]
•The $80.3 million of cash provided by accounts receivable during fiscal 2024 primarily reflects lower sales volume and favorable cash collections during fiscal 2024;

[0000936395-24-000044:mdna:126]
•The $153.0 million of cash provided by inventory during fiscal 2024 primarily reflects the consumption of raw materials in excess of purchases. See Note 9 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report;

[0000936395-24-000044:mdna:127]
•The $198.9 million of cash used in prepaid expenses and other during fiscal 2024 primarily reflects refundable cash advances to a third-party contract manufacturer and higher maintenance spares. See Note 10 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to the refundable cash advances to a third-party contract manufacturer;

[0000936395-24-000044:mdna:128]
•The $64.3 million of cash provided by accounts payable, accruals and other obligations during fiscal 2024 reflects the timing of payments to suppliers and income taxes;

[0000936395-24-000044:mdna:129]
•The $9.9 million of cash provided by deferred revenue during fiscal 2024 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-24-000044:mdna:130]
•The $5.8 million of cash used in operating lease assets and liabilities, net, during fiscal 2024 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:131]
Our days sales outstanding (“DSOs”) were 96 for fiscal 2024, as compared to 95 for fiscal 2023. The calculation of DSOs includes accounts receivable, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 2.0 during fiscal 2023 to 2.3 during fiscal 2024.

[0000936395-24-000044:mdna:132]
Cash Paid for Interest, Net

[0000936395-24-000044:mdna:133]
The following table sets forth the cash paid for interest, net during fiscal 2024 (in thousands):

[0000936395-24-000044:mdna:134]
|  | Year Ended |
|  | November 2, 2024 |
| 2030 New Term Loan due October 28, 2030(1) | $ | 85,835 |  |
| 2030 Senior Notes due January 31, 2030(2) | 16,000 |  |
| Interest rate swaps(3) | (14,868) |  |
| Revolving Credit Facility(4) | 1,781 |  |
| Finance leases | 3,767 |  |
| Cash paid during period | $ | 92,515 |  |

[0000936395-24-000044:mdna:135]
(1) Interest on the 2030 New Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 New Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%. At the end of fiscal 2024, the interest rate on the 2030 New Term Loan was 6.76%.

[0000936395-24-000044:mdna:136]
(2) The 2030 Senior Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest on the 2030 Notes is payable semiannually on January 31 and July 31 of each year.

[0000936395-24-000044:mdna:137]
(3) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loans at 3.47% through January 2028 and another $350.0 million of our Term Loans at 2.968% through September 2025.

[0000936395-24-000044:mdna:138]
(4) During fiscal 2024, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-24-000044:mdna:139]
For additional information about our debt, revolving credit facilities and interest rate swaps, see Notes 15, 18 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-24-000044:mdna:140]
Contractual Obligations

[0000936395-24-000044:mdna:141]
Debt. As of November 2, 2024, we had $1.2 billion outstanding principal associated with our 2030 New Term Loan, with $11.7 million maturing within 12 months. Interest payments on the 2030 New Term Loan and payments to be received under the interest rate swaps are variable and are calculated using the interest rate in effect as of November 2, 2024. Future interest payments associated with the 2030 New Term Loan totaled $462.8 million, with $78.9 million payable within 12 months. As of November 2, 2024, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes totaled $88.0 million, with $16.0 million payable within 12 months. Future interest payments to be received net of payments under the interest rate swaps totaled $37.7 million, with $10.8 million to be received within 12 months. For additional information about our short-term and long-term debt and interest rate swaps, see Notes 15 and 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-24-000044:mdna:142]
Purchase Order Obligations. As of November 2, 2024, we had $1.7 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0000936395-24-000044:mdna:143]
Leases. We have lease arrangements for facilities including research and development centers, engineering facilities and smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. As of November 2, 2024, we had fixed lease payment obligations of $106.7 million, with $23.4 million payable within 12 months. See Note 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:144]
Off-Balance Sheet Arrangements

[0000936395-24-000044:mdna:145]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-24-000044:mdna:146]
Critical Accounting Policies and Estimates

[0000936395-24-000044:mdna:147]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-24-000044:mdna:148]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-24-000044:mdna:149]
Revenue Recognition

[0000936395-24-000044:mdna:150]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-24-000044:mdna:151]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-24-000044:mdna:152]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-24-000044:mdna:153]
Our total deferred revenue for products was $19.0 million and $28.4 million as of November 2, 2024 and October 28, 2023, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be

[0000936395-24-000044:mdna:154]
performed. Our total deferred revenue for services was $218.6 million and $200.1 million as of November 2, 2024 and October 28, 2023, respectively.

[0000936395-24-000044:mdna:155]
Business Combinations

[0000936395-24-000044:mdna:156]
We record acquisitions using the purchase method of accounting. The assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur that may affect the accuracy or validity of such estimates. During fiscal 2022, we completed the acquisitions of AT&T’s Vyatta Software Technology (“Vyatta”) and Xelic, Inc. (“Xelic”) for an aggregate purchase price of $64.1 million. During fiscal 2023, we completed the acquisitions of Benu and Tibit for an aggregate purchase price of $291.7 million. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions.

[0000936395-24-000044:mdna:157]
Share-Based Compensation

[0000936395-24-000044:mdna:158]
We estimate the fair value of our restricted stock unit (“RSU”) awards based on the fair value of our common stock on the date of grant. Our outstanding RSU awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately. At the end of each reporting period, for performance based awards not subject to total stockholder return, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-24-000044:mdna:159]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this annual report. As of November 2, 2024, total unrecognized compensation expense was $212.9 million, which relates to unvested RSUs and is expected to be recognized over a weighted-average period of 1.33 years.

[0000936395-24-000044:mdna:160]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-24-000044:mdna:161]
Reserve for Inventory Obsolescence

[0000936395-24-000044:mdna:162]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. For fiscal 2024 and fiscal 2023, future demand was calculated using both customer backlog and future forecasted sales. Generally, our customers may cancel or change their orders with limited advance notice, or they may decide not to accept our products and services. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for

[0000936395-24-000044:mdna:163]
that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. Beginning in the second half of fiscal 2021, we started placing significant, advanced orders for supply of certain long lead time components to address our expected customer demand for fiscal 2022 and the then-emerging supply chain challenges. During the second half of fiscal 2023, supply for certain long lead time components began to stabilize, and the need to place advance orders decreased for these components. As of November 2, 2024 and October 28, 2023, we had $1.7 billion, for both fiscal periods in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales or will purchase less than we have forecasted.

[0000936395-24-000044:mdna:164]
We recorded charges for excess and obsolete inventory of $77.3 million, $29.5 million and $16.2 million in fiscal 2024, 2023 and 2022, respectively, primarily related to a decrease in the forecasted demand for certain Networking Platforms products primarily sold to communications service providers. Our inventory, net of allowance for excess and obsolescence, was $820.4 million and $1.1 billion as of November 2, 2024 and October 28, 2023, respectively.

[0000936395-24-000044:mdna:165]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-24-000044:mdna:166]
We estimate our allowances for credit losses using relevant available information from internal and external sources. This information is related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-24-000044:mdna:167]
Probability of default rates is published by third-party credit rating agencies. Adjustments to our exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-24-000044:mdna:168]
Our accounts receivable, net of allowance for credit losses, was $908.6 million and $1.0 billion as of November 2, 2024 and October 28, 2023, respectively. Our allowance for credit losses was $9.9 million and $11.7 million as of November 2, 2024 and October 28, 2023, respectively.

[0000936395-24-000044:mdna:169]
Our contract assets for unbilled accounts receivable, net of allowance for credit losses, was $127.9 million and $150.3 million as of November 2, 2024 and October 28, 2023, respectively. Our allowance for credit losses was $0.4 million and $0.1 million as of November 2, 2024 and October 28, 2023, respectively.

[0000936395-24-000044:mdna:170]
Goodwill

[0000936395-24-000044:mdna:171]
Our goodwill was generated from the acquisitions of (i) Cyan, Inc. during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion, Inc. during fiscal 2016, (iii) Packet Design, LLC and DonRiver Holdings, LLC during fiscal 2019, (iv) Centina Systems, Inc. during fiscal 2020, (v) Vyatta and Xelic during fiscal 2022 and (vi) Benu and Tibit during fiscal 2023. The goodwill from these acquisitions is primarily related to expected economic synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-24-000044:mdna:172]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test indicates that the fair value is less than the carrying value, an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of both November 2, 2024 and October 28, 2023, the goodwill balance was approximately $445.0 million. There were no goodwill impairments resulting from our fiscal 2024 and 2023 impairment tests,

[0000936395-24-000044:mdna:173]
and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 13 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:174]
Long-lived Assets

[0000936395-24-000044:mdna:175]
Our long-lived assets include equipment, building, furniture and fixtures, operating right-of-use assets, finite-lived intangible assets and maintenance spares. As of November 2, 2024 and October 28, 2023, these assets totaled $608.1 million and $575.0 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-24-000044:mdna:176]
Deferred Tax Assets

[0000936395-24-000044:mdna:177]
Pursuant to Accounting Standards Codification (“ASC”) Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-24-000044:mdna:178]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The net deferred tax assets as of November 2, 2024 and October 28, 2023 were $885.9 million and $809.3 million, respectively, including valuation allowances of $192.4 million and $189.9 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy.

[0000936395-24-000044:mdna:179]
For further discussion, see Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:180]
Warranty

[0000936395-24-000044:mdna:181]
Our liability for product warranties, included in accrued liabilities and other short-term obligations, was $55.3 million and $57.1 million as of November 2, 2024 and October 28, 2023, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support customer repairs within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $25.6 million, $31.7 million and $17.4 million for fiscal 2024, 2023 and 2022, respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-24-000044:mdna:182]
Effects of Recent Accounting Pronouncements

[0000936395-24-000044:mdna:183]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.
