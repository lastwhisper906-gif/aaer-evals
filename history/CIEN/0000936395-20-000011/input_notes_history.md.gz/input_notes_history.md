# CIEN note change history — 0000936395-19-000040 → 0000936395-20-000011


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.5 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2020, Ciena has recorded CAD$32.5 million (approximately $24.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million (approximately $2.7 million) was recorded in the first three months of fiscal 2020. As of January 31, 2020, amounts receivable from this grant were CAD$12.0 million (approximately $9.1 million).
  (was, 2019-09-11, similarity 0.9919):
[0000936395-19-000040:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.6 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2019, Ciena has recorded CAD$25.9 million (approximately $19.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$9.3 million (approximately $7.0 million) was recorded in the first nine months of fiscal 2019. As of July 31, 2019, amounts receivable from this grant were CAD$10.8 million (approximately $8.2 million).

- changed (2020-03-11):
[0000936395-20-000011:note_history:2]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.
  (was, 2019-09-11, similarity 0.9248):
[0000936395-19-000040:note_history:2]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

- removed (2020-03-11):
[0000936395-19-000040:note_history:3]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleged violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and sought unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement was subject to notice to class members and approval by the court. On August 8, 2019, the court approved the settlement and entered judgment in the case. The terms of the settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to Ciena’s financial results.

- removed (2020-03-11):
[0000936395-19-000040:note_history:4]
Internal Investigation

- removed (2020-03-11):
[0000936395-19-000040:note_history:5]
As first disclosed in Ciena’s Form 10-K for fiscal 2017, during that year one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act. In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (the “DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it declined to prosecute this matter and that its investigation into this matter is closed. On September 9, 2019, the SEC advised that it has concluded its investigation into this matter and that its staff does not intend to recommend any enforcement action by the SEC against Ciena.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:6]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2019.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.
  (was, 2019-09-11, similarity 0.9716):
[0000936395-19-000040:note_history:6]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2018 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:7]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2019 Annual Report.
  (was, 2019-09-11, similarity 0.8945):
[0000936395-19-000040:note_history:7]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.

- added (2020-03-11):
[0000936395-20-000011:note_history:8]
Leases

- added (2020-03-11):
[0000936395-20-000011:note_history:9]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification ASC 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 1, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

- added (2020-03-11):
[0000936395-20-000011:note_history:10]
Ciena adopted the guidance on a modified retrospective basis as of November 1, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient for disclosure, Ciena has elected not to separate lease and non-lease components on operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass through operating expenses like common area maintenance and utilities.

- added (2020-03-11):
[0000936395-20-000011:note_history:11]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms

- added (2020-03-11):
[0000936395-20-000011:note_history:12]
similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

- added (2020-03-11):
[0000936395-20-000011:note_history:13]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of October 31, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.

- changed (2020-03-11):
[0000936395-20-000011:note_history:14]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in millions):
  (was, 2019-09-11, similarity 0.9972):
[0000936395-19-000040:note_history:14]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheets in connection with the adoption of ASC 606 (in millions):

- added (2020-03-11):
[0000936395-20-000011:note_history:15]
|  |  | Balance at October 31, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 1, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

- added (2020-03-11):
[0000936395-20-000011:note_history:16]
| (1) | Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets. |

- added (2020-03-11):
[0000936395-20-000011:note_history:17]
| (2) | Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets. |

- added (2020-03-11):
[0000936395-20-000011:note_history:18]
| (3) | Represents $20.5 million of lease liabilities for operating leases. |

- added (2020-03-11):
[0000936395-20-000011:note_history:19]
| (4) | Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets. |

- added (2020-03-11):
[0000936395-20-000011:note_history:20]
| (5) | Represents $55.6 million of lease liabilities for operating leases. |

- added (2020-03-11):
[0000936395-20-000011:note_history:21]
See Note 15 for additional information.

- added (2020-03-11):
[0000936395-20-000011:note_history:22]
Fair Value Measurement

- added (2020-03-11):
[0000936395-20-000011:note_history:23]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

- changed (2020-03-11):
[0000936395-20-000011:note_history:24]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and related disclosures.
  (was, 2019-09-11, similarity 0.9913):
[0000936395-19-000040:note_history:24]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and disclosures.

- removed (2020-03-11):
[0000936395-19-000040:note_history:25]
Revenue Recognition

- removed (2020-03-11):
[0000936395-19-000040:note_history:26]
In May 2014, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- removed (2020-03-11):
[0000936395-19-000040:note_history:27]
ASC 606 allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). Effective upon the start of its first quarter of fiscal 2019, Ciena adopted ASC 606 using the modified retrospective method and accordingly recognized the cumulative effect in accumulated deficit for those contracts that were not completed as of October 31, 2018. Accordingly, results for the reporting periods after October 31, 2018 are presented under ASC 606, while prior periods have not been adjusted and continue to be reported in accordance with Ciena’s historical revenue recognition practices. Refer to Opening Balance Adjustments below for the impact of ASC 606 adoption on Ciena’s Condensed Consolidated Financial Statements. In connection with its adoption of ASC 606, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 606.

- removed (2020-03-11):
[0000936395-19-000040:note_history:28]
Revenue Recognition Timing Differences

- removed (2020-03-11):
[0000936395-19-000040:note_history:29]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services. Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to

- removed (2020-03-11):
[0000936395-19-000040:note_history:30]
such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

- removed (2020-03-11):
[0000936395-19-000040:note_history:31]
Revenue Recognition Policy Under ASC 606

- removed (2020-03-11):
[0000936395-19-000040:note_history:32]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

- removed (2020-03-11):
[0000936395-19-000040:note_history:33]
Ciena determines revenue recognition by applying the following five-step approach:

- removed (2020-03-11):
[0000936395-19-000040:note_history:34]
•identification of the contract, or contracts, with a customer;

- removed (2020-03-11):
[0000936395-19-000040:note_history:35]
•identification of the performance obligations in the contract;

- removed (2020-03-11):
[0000936395-19-000040:note_history:36]
•determination of the transaction price;

- removed (2020-03-11):
[0000936395-19-000040:note_history:37]
•allocation of the transaction price to the performance obligations in the contract; and

- removed (2020-03-11):
[0000936395-19-000040:note_history:38]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

- removed (2020-03-11):
[0000936395-19-000040:note_history:39]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

- removed (2020-03-11):
[0000936395-19-000040:note_history:40]
Purchase orders are invoiced based upon the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

- removed (2020-03-11):
[0000936395-19-000040:note_history:41]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

- removed (2020-03-11):
[0000936395-19-000040:note_history:42]
Significant Judgments

- removed (2020-03-11):
[0000936395-19-000040:note_history:43]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- removed (2020-03-11):
[0000936395-19-000040:note_history:44]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

- removed (2020-03-11):
[0000936395-19-000040:note_history:45]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

- removed (2020-03-11):
[0000936395-19-000040:note_history:46]
Capitalized Contract Acquisition Costs

- removed (2020-03-11):
[0000936395-19-000040:note_history:47]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

- removed (2020-03-11):
[0000936395-19-000040:note_history:48]
For the additional disclosures required as part of ASC 606, see Note 3 below.

- removed (2020-03-11):
[0000936395-19-000040:note_history:49]
Impact of ASC 606 Adoption

- removed (2020-03-11):
[0000936395-19-000040:note_history:50]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statements of Operations (in millions):

- removed (2020-03-11):
[0000936395-19-000040:note_history:51]
|  |  | Quarter Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 960,606 |  |  | $ | (2,413 | ) |  | $ | 958,193 |  |
| Total cost of goods sold |  | $ | 536,254 |  |  | $ | 1,789 |  |  | $ | 538,043 |  |
| Net income |  | $ | 86,749 |  |  | $ | (3,879 | ) |  | $ | 82,870 |  |
| Diluted net income per potential common share |  | $ | 0.55 |  |  | $ | (0.02 | ) |  | $ | 0.53 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:52]
|  |  | Nine Months Ended July 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 2,604,144 |  |  | $ | (27,533 | ) |  | $ | 2,576,611 |  |
| Total cost of goods sold |  | $ | 1,481,774 |  |  | $ | (20,776 | ) |  | $ | 1,460,998 |  |
| Net income |  | $ | 173,103 |  |  | $ | (4,781 | ) |  | $ | 168,322 |  |
| Diluted net income per potential common share |  | $ | 1.10 |  |  | $ | (0.03 | ) |  | $ | 1.07 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:53]
For the third quarter and first nine months of fiscal 2019, the increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services revenue that was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheets or any impact on net cash provided by operating activities as of July 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

- removed (2020-03-11):
[0000936395-19-000040:note_history:54]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders’ equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:55]
| (1) | Unpaid accounts receivable and related deferred revenue related to rights and obligations in a contract are interdependent and therefore recorded net within Ciena’s balance sheet. This represents an increase of $12.5 million from the reversal of certain net unpaid accounts receivable and related deferred revenue. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:56]
| (2) | Represents a decrease of $2.5 million in deferred costs of goods sold due to change in revenue recognition for certain product sales. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:57]
| (3) | Represents increases of $27.5 million in unbilled accounts receivable for change in recognizing revenue for installation services, $3.9 million in unbilled accounts receivable from change in recognizing revenue for certain product sales and $9.6 million related to short-term capitalized acquisition costs (e.g., commissions) and a decrease of $19.5 million related to prepaid cost of installation services. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:58]
| (4) | Represents a decrease of $14.4 million in deferred tax asset, net, related to the unrecognized income tax effects of the net adjustments from the new revenue recognition standard. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:59]
| (5) | Represents an increase of $4.0 million related to long-term capitalized acquisition costs (e.g., commissions). |

- removed (2020-03-11):
[0000936395-19-000040:note_history:60]
| (6) | Represents decreases of $23.6 million in deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue, primarily due to a change in revenue recognition for certain product sales, and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:61]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:62]
| (8) | Accumulated deficit impact from the adjustments noted above. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:63]
Intangibles

- removed (2020-03-11):
[0000936395-19-000040:note_history:64]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software, which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software.

- removed (2020-03-11):
[0000936395-19-000040:note_history:65]
Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

- removed (2020-03-11):
[0000936395-19-000040:note_history:66]
Restricted Cash in Statement of Cash Flows

- removed (2020-03-11):
[0000936395-19-000040:note_history:67]
In November 2016, the FASB issued ASU 2016-18 (“ASU 2016-18”), Statement of Cash Flows (Topic 230): Restricted Cash, which broadens the classification and presentation of changes in restricted cash in the statement of cash flows. Ciena adopted ASU 2016-18 during the first quarter of fiscal 2019. The application of this accounting standard update did not have a material impact on Ciena’s Condensed Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

- removed (2020-03-11):
[0000936395-19-000040:note_history:68]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be recognized as assets and liabilities on Ciena’s balance sheet. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

- removed (2020-03-11):
[0000936395-19-000040:note_history:69]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020 and early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:70]
New 2025 Term Loan
  (was, 2019-09-11, similarity 0.8462):
[0000936395-19-000040:note_history:70]
2025 Term Loan

- added (2020-03-11):
[0000936395-20-000011:note_history:71]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained an existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”).

- added (2020-03-11):
[0000936395-20-000011:note_history:72]
On January 23, 2020, Ciena, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Refinancing Agreement”), pursuant to which Ciena consummated a permitted refinancing of the entire outstanding amount of the Old 2025 Term Loan, and in accordance therewith, incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”). The proceeds of the New 2025 Term Loan were used in their entirety to

- added (2020-03-11):
[0000936395-20-000011:note_history:73]
refinance the 2025 Term Loan. This arrangement was primarily accounted for as a modification of debt and, as such, $0.1 million of debt issuance costs associated with the New 2025 Term Loan was expensed.

- added (2020-03-11):
[0000936395-20-000011:note_history:74]
The Refinancing Agreement amends the Credit Agreement and provides that the New 2025 Term Loan will, among other things:

- added (2020-03-11):
[0000936395-20-000011:note_history:75]
| • | mature on September 28, 2025; |

- added (2020-03-11):
[0000936395-20-000011:note_history:76]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25%, or $1.73 million, of the principal amount of the New 2025 Term Loan as of January 23, 2020, with the balance payable at maturity; |

- added (2020-03-11):
[0000936395-20-000011:note_history:77]
| • | be subject to mandatory prepayment provisions on the occurrence of certain specified events substantially similar to the 2025 Term Loan, including certain asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement); |

- added (2020-03-11):
[0000936395-20-000011:note_history:78]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%; and |

- added (2020-03-11):
[0000936395-20-000011:note_history:79]
| • | be repayable at any time at Ciena’s election, provided that repayment of the New 2025 Term Loan with proceeds of certain indebtedness prior to July 23, 2020 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment. |

- added (2020-03-11):
[0000936395-20-000011:note_history:80]
Except as amended by the Refinancing Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

- changed (2020-03-11):
[0000936395-20-000011:note_history:81]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2019-09-11, similarity 0.8502):
[0000936395-19-000040:note_history:81]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

- added (2020-03-11):
[0000936395-20-000011:note_history:82]
|  |  | January 31, 2020 |  | October 31, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 (New) |  | $ | 693,000 |  |  | $ | (1,824 | ) |  | $ | (3,390 | ) |  | $ | 687,786 |  |  | $ | — |  |
| Term Loan Payable due September 28, 2025 (Old) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:83]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.4 million at January 31, 2020 and $3.6 million at October 31, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.2 million during the first three months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.
  (was, 2019-09-11, similarity 0.8706):
[0000936395-19-000040:note_history:83]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $3.8 million at July 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.5 million during the first nine months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2020-03-11):
[0000936395-20-000011:note_history:84]
As of January 31, 2020, the estimated fair value of the New 2025 Term Loan was $694.7 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2019-09-11, similarity 0.8233):
[0000936395-19-000040:note_history:84]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.

- removed (2020-03-11):
[0000936395-19-000040:note_history:85]
Outstanding Term Loan Payable

- removed (2020-03-11):
[0000936395-19-000040:note_history:86]
|  |  | July 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 688,918 |  |  | $ | 693,450 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:87]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of July 31, 2019 (in thousands):

- removed (2020-03-11):
[0000936395-19-000040:note_history:88]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 694,750 |  |  | $ | (2,043 | ) |  | $ | (3,789 | ) |  | $ | 688,918 |  |  | $ | 696,487 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:89]
(1)


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:90]
|  | January 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,962 |  |  | $ | 105 |  |  | $ | — |  |  | $ | 110,067 |  |
| Included in long-term investments | 10,073 |  |  | 3 |  |  | — |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 120,143 |  |
  (was, 2019-09-11, similarity 0.7763):
[0000936395-19-000040:note_history:90]
|  | July 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
|  | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:91]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |
  (was, 2019-09-11, similarity 0.7751):
[0000936395-19-000040:note_history:91]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:92]
|  | January 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,962 |  |  | $ | 105 |  |  | $ | — |  |  | $ | 110,067 |  |
| Included in long-term investments | 10,073 |  |  | 3 |  |  | — |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 120,143 |  |
  (was, 2019-09-11, similarity 0.7763):
[0000936395-19-000040:note_history:92]
|  | July 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |
|  | $ | 119,490 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 119,670 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:93]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |
  (was, 2019-09-11, similarity 0.7751):
[0000936395-19-000040:note_history:93]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:94]
The following table summarizes the final legal maturities of debt investments at January 31, 2020 (in thousands):
  (was, 2019-09-11, similarity 0.9765):
[0000936395-19-000040:note_history:94]
The following table summarizes the final legal maturities of debt investments at July 31, 2019 (in thousands):

- changed (2020-03-11):
[0000936395-20-000011:note_history:95]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 109,962 |  |  | $ | 110,067 |  |
| Due in 1-2 years | 10,073 |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 120,143 |  |
  (was, 2019-09-11, similarity 0.7426):
[0000936395-19-000040:note_history:95]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 119,490 |  |  | $ | 119,670 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:96]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2019-09-11, similarity 0.8502):
[0000936395-19-000040:note_history:96]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

- added (2020-03-11):
[0000936395-20-000011:note_history:97]
|  |  | January 31, 2020 |  | October 31, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 (New) |  | $ | 693,000 |  |  | $ | (1,824 | ) |  | $ | (3,390 | ) |  | $ | 687,786 |  |  | $ | — |  |
| Term Loan Payable due September 28, 2025 (Old) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:98]
|  |  | July 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 688,918 |  |  | $ | 693,450 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2020-03-11):
[0000936395-19-000040:note_history:99]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of July 31, 2019 (in thousands):

- removed (2020-03-11):
[0000936395-19-000040:note_history:100]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 694,750 |  |  | $ | (2,043 | ) |  | $ | (3,789 | ) |  | $ | 688,918 |  |  | $ | 696,487 |  |

- removed (2020-03-11):
[0000936395-19-000040:note_history:101]
(1)

- removed (2020-03-11):
[0000936395-19-000040:note_history:102]
The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:103]
|  | Quarter Ended January 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Packet Networking | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
  (was, 2019-09-11, similarity 0.6221):
[0000936395-19-000040:note_history:103]
|  | Quarter Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 14,598 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 33,244 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:104]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 16,044 |  |  | $ | 6,228 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 25,554 |  |  | 8,746 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
  (was, 2019-09-11, similarity 0.6118):
[0000936395-19-000040:note_history:104]
|  | Nine Months Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 51,017 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Products and services transferred over time | — |  |  | 101,099 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |

- added (2020-03-11):
[0000936395-20-000011:note_history:105]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, we maintain specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel, who ensure that we maintain a high-touch, consultative relationship with our customers.

- added (2020-03-11):
[0000936395-20-000011:note_history:106]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2020-03-11):
[0000936395-20-000011:note_history:107]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 832,912 |  |  | $ | 778,527 |  |
  (was, 2019-09-11, similarity 0.8435):
[0000936395-19-000040:note_history:107]
|  |  | Quarter Ended July 31, 2019 |  | Nine Months Ended July 31, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 617,000 |  |  | $ | 1,678,599 |  |
| EMEA |  | 169,532 |  |  | 413,715 |  |
| CALA |  | 39,261 |  |  | 109,635 |  |
| APAC |  | 134,813 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 960,606 |  |  | $ | 2,604,144 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:108]
|  | Quarter Ended January 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Packet Networking | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
  (was, 2019-09-11, similarity 0.6221):
[0000936395-19-000040:note_history:108]
|  | Quarter Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 724,245 |  |  | $ | — |  |  | $ | — |  |  | $ | 724,245 |  |
| Packet Networking | 71,823 |  |  | — |  |  | — |  |  | 71,823 |  |
| Platform Software and Services | — |  |  | 37,312 |  |  | — |  |  | 37,312 |  |
| Blue Planet Automation Software and Services | — |  |  | 10,530 |  |  | — |  |  | 10,530 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 65,936 |  |  | 65,936 |  |
| Installation and Deployment | — |  |  | — |  |  | 39,802 |  |  | 39,802 |  |
| Consulting and Network Design | — |  |  | — |  |  | 10,958 |  |  | 10,958 |  |
| Total revenue by product line | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 796,068 |  |  | $ | 14,598 |  |  | $ | 4,804 |  |  | $ | 815,470 |  |
| Services transferred over time | — |  |  | 33,244 |  |  | 111,892 |  |  | 145,136 |  |
| Total revenue by timing of revenue recognition | $ | 796,068 |  |  | $ | 47,842 |  |  | $ | 116,696 |  |  | $ | 960,606 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:109]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 16,044 |  |  | $ | 6,228 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 25,554 |  |  | 8,746 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
  (was, 2019-09-11, similarity 0.6118):
[0000936395-19-000040:note_history:109]
|  | Nine Months Ended July 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,897,080 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,897,080 |  |
| Packet Networking | 216,529 |  |  | — |  |  | — |  |  | 216,529 |  |
| Platform Software and Services | — |  |  | 114,139 |  |  | — |  |  | 114,139 |  |
| Blue Planet Automation Software and Services | — |  |  | 37,977 |  |  | — |  |  | 37,977 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 196,002 |  |  | 196,002 |  |
| Installation and Deployment | — |  |  | — |  |  | 111,746 |  |  | 111,746 |  |
| Consulting and Network Design | — |  |  | — |  |  | 30,671 |  |  | 30,671 |  |
| Total revenue by product line | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,113,609 |  |  | $ | 51,017 |  |  | $ | 13,945 |  |  | $ | 2,178,571 |  |
| Products and services transferred over time | — |  |  | 101,099 |  |  | 324,474 |  |  | 425,573 |  |
| Total revenue by timing of revenue recognition | $ | 2,113,609 |  |  | $ | 152,116 |  |  | $ | 338,419 |  |  | $ | 2,604,144 |  |

- added (2020-03-11):
[0000936395-20-000011:note_history:110]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, we maintain specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel, who ensure that we maintain a high-touch, consultative relationship with our customers.

- added (2020-03-11):
[0000936395-20-000011:note_history:111]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2020-03-11):
[0000936395-20-000011:note_history:112]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 832,912 |  |  | $ | 778,527 |  |
  (was, 2019-09-11, similarity 0.8435):
[0000936395-19-000040:note_history:112]
|  |  | Quarter Ended July 31, 2019 |  | Nine Months Ended July 31, 2019 |
| Geographic distribution: |  |  |  |  |
| North America |  | $ | 617,000 |  |  | $ | 1,678,599 |  |
| EMEA |  | 169,532 |  |  | 413,715 |  |
| CALA |  | 39,261 |  |  | 109,635 |  |
| APAC |  | 134,813 |  |  | 402,195 |  |
| Total revenue by geographic distribution |  | $ | 960,606 |  |  | $ | 2,604,144 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:113]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system (“Waveserver”), the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |
  (was, 2019-09-11, similarity 0.9795):
[0000936395-19-000040:note_history:113]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

- changed (2020-03-11):
[0000936395-20-000011:note_history:114]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.
  (was, 2019-09-11, similarity 0.8611):
[0000936395-19-000040:note_history:114]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- changed (2020-03-11):
[0000936395-20-000011:note_history:115]
| • | Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |
  (was, 2019-09-11, similarity 0.7446):
[0000936395-19-000040:note_history:115]
| • | Ciena’s Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

- added (2020-03-11):
[0000936395-20-000011:note_history:116]
| • | Blue Planet® Automation Software and Services is a comprehensive, open software suite, together with related services, that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management, unified assurance and analytics (UAA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

- changed (2020-03-11):
[0000936395-20-000011:note_history:117]
Ciena’s software platform revenue typically reflects sales of either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2019-09-11, similarity 0.9938):
[0000936395-19-000040:note_history:117]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2020-03-11):
[0000936395-20-000011:note_history:118]
|  |  | Balance at January 31, 2020 |  | Balance at October 31, 2019 |
| Accounts receivable, net |  | $ | 655,105 |  |  | $ | 724,854 |  |
| Contract assets |  | $ | 83,717 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 166,835 |  |  | $ | 156,873 |  |
  (was, 2019-09-11, similarity 0.8889):
[0000936395-19-000040:note_history:118]
|  |  | Balance at July 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 798,884 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 74,348 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 145,030 |  |  | $ | 140,704 |  |

- changed (2020-03-11):
[0000936395-20-000011:note_history:119]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 for further discussion.
  (was, 2019-09-11, similarity 0.8297):
[0000936395-19-000040:note_history:119]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.

- added (2020-03-11):
[0000936395-20-000011:note_history:120]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $49.0 million and $39.4 million of revenue during the first three months of fiscal 2020 and 2019 that was included in the deferred revenue balance at October 31, 2019 and November 1, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 31, 2020 and 2019.

- changed (2020-03-11):
[0000936395-20-000011:note_history:121]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.1 million and $15.7 million as of January 31, 2020 and October 31, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $5.6 million and $4.1 million during the first three months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.
  (was, 2019-09-11, similarity 0.8745):
[0000936395-19-000040:note_history:121]
Capitalized contract acquisition costs consist of deferred sales commissions and were $13.2 million and $13.6 million as of July 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $12.5 million during the first nine months of fiscal 2019 and was included in sales and marketing expense.

- changed (2020-03-11):
[0000936395-20-000011:note_history:122]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2020, the aggregate amount of RPO was $905 million. As of January 31, 2020, Ciena expects approximately 82% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2019-09-11, similarity 0.9799):
[0000936395-19-000040:note_history:122]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2019, the aggregate amount of RPO was $1.15 billion. As of July 31, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.

- removed (2020-03-11):
[0000936395-19-000040:note_history:123]
•Software and Software-Related Services reflects sales of the following:

- removed (2020-03-11):
[0000936395-19-000040:note_history:124]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

- removed (2020-03-11):
[0000936395-19-000040:note_history:125]
Revenue from the software portions of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- removed (2020-03-11):
[0000936395-19-000040:note_history:126]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $77.4 million of revenue during the first nine months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2019.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-03-11):
[0000936395-20-000011:note_history:127]
From the end of the first quarter of fiscal 2020 through March 6, 2020, Ciena repurchased an additional 443,958 shares of its common stock, for an aggregate purchase price of $18.6 million at an average price of $41.90 per share, inclusive of repurchases pending settlement. As of March 6, 2020, Ciena has repurchased an aggregate of 5,570,535 shares and has an aggregate of $280.6 million of authorized funds remaining under its stock repurchase program.
  (was, 2019-09-11, similarity 0.9549):
[0000936395-19-000040:note_history:127]
From the end of the third quarter of fiscal 2019 through September 6, 2019, Ciena repurchased an additional 417,819 shares of its common stock, for an aggregate purchase price of $17.3 million at an average price of $41.38 per share, inclusive of repurchases pending settlement. As of September 6, 2019, Ciena has repurchased an aggregate of 3,299,383 shares and has an aggregate of $370.8 million of authorized funds remaining under its Stock Repurchase Program.
