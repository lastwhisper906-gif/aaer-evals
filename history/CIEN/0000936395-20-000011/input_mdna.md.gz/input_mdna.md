# CIEN MD&A — 0000936395-20-000011


## mdna

[0000936395-20-000011:mdna:1]
[same as prior period, unchanged from 0000936395-19-000040:mdna:1]

[0000936395-20-000011:mdna:2]
[same as prior period, unchanged from 0000936395-19-000040:mdna:2]

[0000936395-20-000011:mdna:3]
This report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things: our competitive landscape; market conditions and growth opportunities; factors impacting our industry and markets; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and automation of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including information technology (IT) transitions or initiatives; the impact of the Tax Cuts and Jobs Act and changes in our effective tax rates; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-20-000011:mdna:4]
[same as prior period, unchanged from 0000936395-19-000040:mdna:4]

[0000936395-20-000011:mdna:5]
[same as prior period, unchanged from 0000936395-19-000040:mdna:5]

[0000936395-20-000011:mdna:6]
[same as prior period, unchanged from 0000936395-19-000040:mdna:6]

[0000936395-20-000011:mdna:7]
[same as prior period, unchanged from 0000936395-19-000040:mdna:7]

[0000936395-20-000011:mdna:8]
[same as prior period, unchanged from 0000936395-19-000040:mdna:8]

[0000936395-20-000011:mdna:9]
[same as prior period, unchanged from 0000936395-19-000040:mdna:9]

[0000936395-20-000011:mdna:10]
[same as prior period, unchanged from 0000936395-19-000040:mdna:10]

[0000936395-20-000011:mdna:11]
[same as prior period, unchanged from 0000936395-19-000040:mdna:11]

[0000936395-20-000011:mdna:12]
[same as prior period, unchanged from 0000936395-19-000040:mdna:12]

[0000936395-20-000011:mdna:13]
[same as prior period, unchanged from 0000936395-19-000040:mdna:13]

[0000936395-20-000011:mdna:14]
[same as prior period, unchanged from 0000936395-19-000040:mdna:14]

[0000936395-20-000011:mdna:15]
[same as prior period, unchanged from 0000936395-19-000040:mdna:15]

[0000936395-20-000011:mdna:16]
[same as prior period, unchanged from 0000936395-19-000040:mdna:16]

[0000936395-20-000011:mdna:17]
[same as prior period, unchanged from 0000936395-19-000040:mdna:17]

[0000936395-20-000011:mdna:18]
[same as prior period, unchanged from 0000936395-19-000040:mdna:18]

[0000936395-20-000011:mdna:19]
[same as prior period, unchanged from 0000936395-19-000040:mdna:19]

[0000936395-20-000011:mdna:20]
[same as prior period, unchanged from 0000936395-19-000040:mdna:20]

[0000936395-20-000011:mdna:21]
[same as prior period, unchanged from 0000936395-19-000040:mdna:21]

[0000936395-20-000011:mdna:22]
[same as prior period, unchanged from 0000936395-19-000040:mdna:22]

[0000936395-20-000011:mdna:23]
[same as prior period, unchanged from 0000936395-19-000040:mdna:23]

[0000936395-20-000011:mdna:24]
[same as prior period, unchanged from 0000936395-19-000040:mdna:24]

[0000936395-20-000011:mdna:25]
[same as prior period, unchanged from 0000936395-19-000040:mdna:25]

[0000936395-20-000011:mdna:26]
[same as prior period, unchanged from 0000936395-19-000040:mdna:26]

[0000936395-20-000011:mdna:27]
[same as prior period, unchanged from 0000936395-19-000040:mdna:27]

[0000936395-20-000011:mdna:28]
[same as prior period, unchanged from 0000936395-19-000040:mdna:28]

[0000936395-20-000011:mdna:29]
[same as prior period, unchanged from 0000936395-19-000040:mdna:29]

[0000936395-20-000011:mdna:30]
[same as prior period, unchanged from 0000936395-19-000040:mdna:30]

[0000936395-20-000011:mdna:31]
[same as prior period, unchanged from 0000936395-19-000040:mdna:31]

[0000936395-20-000011:mdna:32]
[same as prior period, unchanged from 0000936395-19-000040:mdna:32]

[0000936395-20-000011:mdna:33]
[same as prior period, unchanged from 0000936395-19-000040:mdna:33]

[0000936395-20-000011:mdna:34]
[same as prior period, unchanged from 0000936395-19-000040:mdna:34]

[0000936395-20-000011:mdna:35]
[same as prior period, unchanged from 0000936395-19-000040:mdna:35]

[0000936395-20-000011:mdna:36]
| • | factors beyond our control such as natural disasters, acts of war or terrorism, and epidemics, including the recent outbreak of the coronavirus COVID-19; |

[0000936395-20-000011:mdna:37]
[same as prior period, unchanged from 0000936395-19-000040:mdna:36]

[0000936395-20-000011:mdna:38]
[same as prior period, unchanged from 0000936395-19-000040:mdna:37]

[0000936395-20-000011:mdna:39]
| • | adverse results in litigation matters. |

[0000936395-20-000011:mdna:40]
[same as prior period, unchanged from 0000936395-19-000040:mdna:39]

[0000936395-20-000011:mdna:41]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and other emerging network operators.

[0000936395-20-000011:mdna:42]
Our solutions include our portfolio of Networking Platforms, including our Converged Packet Optical and Packet Networking products, that can be applied from the network core to end user access points, and that allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We offer Platform Software that provides management and domain control of our hardware solutions and automates network lifecycle operations, including provisioning equipment and services. Through our Blue Planet® Automation Software, we

[0000936395-20-000011:mdna:43]
30

[0000936395-20-000011:mdna:44]
enable network providers to use network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments, streamlining key business and network processes. To complement our hardware and software products, we offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments.

[0000936395-20-000011:mdna:45]
We refer to our complete portfolio vision as the Adaptive Network™. The Adaptive Network emphasizes a programmable network infrastructure, software control and automation capabilities, and network analytics and intelligence. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-20-000011:mdna:46]
Strategic Initiatives

[0000936395-20-000011:mdna:47]
Investment in Blue Planet Automation Software

[0000936395-20-000011:mdna:48]
We have continued to pursue both organic investments and acquisition opportunities to expand our Blue Planet Automation Software and Services portfolio and business. On November 4, 2019, we acquired privately held Centina Systems, Inc. (“Centina”), a provider of service assurance analytics and network performance management solutions. The acquisition of Centina is intended to accelerate Blue Planet’s software strategy of providing closed loop, intelligent automation solutions that help communications service providers to analyze network conditions, traffic demands and resource availability, and to determine the best placement of traffic for optimal service quality and resource utilization. See Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part 1 of this report.

[0000936395-20-000011:mdna:49]
Investment in Adaptive Network Offerings and 5G Innovation

[0000936395-20-000011:mdna:50]
We have continued to use our significant research and development investment capacity to push the pace of innovation in our markets and provide offerings that promote our Adaptive Network vision through further advances in programmable hardware, analytics, and control and automation. In the first quarter of fiscal 2020, we began market trials of our fifth-generation WaveLogic coherent modem technology, which is capable of delivering 800 gigabits of capacity per second over a single wavelength. We expect to make this technology available in certain Converged Packet Optical platforms beginning in the second quarter of fiscal 2020.

[0000936395-20-000011:mdna:51]
In February 2020, we announced the future addition of several new wireline routing platforms to support the demands of mobile xHaul (fronthaul, midhaul and backhaul) transport and to enable mobile network operator migration from 4G to 5G networks. In addition, we enhanced our Blue Planet Intelligent Automation software portfolio for 5G automation applications, including vendor-agnostic network slicing features and dynamic planning capabilities that are intended to better enable mobile network operator delivery of 5G mobile services. We expect to make these new products available in the second half of fiscal 2020.

[0000936395-20-000011:mdna:52]
2025 Term Loan Refinancing Amendment to Credit Agreement

[0000936395-20-000011:mdna:53]
We refinanced our existing senior secured term loan with an outstanding aggregate principal amount of $693 million as of January 23, 2020 and maturing on September 28, 2025 for a lower per annum rate equal to (a) LIBOR plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%. All other terms remain in effect.

[0000936395-20-000011:mdna:54]
Coronavirus (COVID-19)

[0000936395-20-000011:mdna:55]
We have taken a number of precautionary steps to safeguard our business and our employees from the effects of the novel coronavirus COVID-19, including implementing travel bans and restrictions, temporarily closing offices and canceling participation in various industry events. We have also implemented certain business continuity plans, including flexible working arrangements, designed to minimize any potential business disruption and to protect our supply chain and operations. As a result of the spread of the coronavirus, to date we have experienced some disruption and delay of supply, principally related to China, and logistics challenges, including certain limitations on our ability to access certain sites that have impacted our customer fulfillment operations. We expect these conditions to have an adverse impact on our revenue and results of operations for the second quarter of fiscal 2020. We are monitoring the situation and actively assessing further possible implications to our business, supply chain and customer demand. However, the coronavirus situation remains dynamic. For example, on February 28, 2020, the World Health Organization (WHO) raised its assessment of the coronavirus threat from high to very high at a global level due to the continued increase in the number of cases and affected countries. As a result, the broader implications for our business and results of operations remain uncertain. If the coronavirus or its adverse effects become more prevalent in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our operations, we may experience constrained supply or curtailed customer demand that may materially adversely impact our business and results of operations in future periods.

[0000936395-20-000011:mdna:56]
Available Information. Our quarterly reports on Form 10-Q, annual reports on Form 10-K, current reports on Form 8-K, and any amendments thereto filed or furnished with the SEC are available through the SEC’s website at www.sec.gov and are available free of charge on our website as soon as reasonably practicable after we file or furnish these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Information on our website is not deemed to be incorporated by reference into this report. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-20-000011:mdna:57]
For additional information on our business, industry, market opportunity, competitive landscape, and strategy, see our 2019 Annual Report.

[0000936395-20-000011:mdna:58]
[same as prior period, unchanged from 0000936395-19-000040:mdna:42]

[0000936395-20-000011:mdna:59]
[same as prior period, unchanged from 0000936395-19-000040:mdna:50]

[0000936395-20-000011:mdna:60]
[same as prior period, unchanged from 0000936395-19-000040:mdna:51]

[0000936395-20-000011:mdna:61]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-20-000011:mdna:62]
Quarter ended January 31, 2020 compared to the quarter ended January 31, 2019

[0000936395-20-000011:mdna:63]
[same as prior period, unchanged from 0000936395-19-000040:mdna:55]

[0000936395-20-000011:mdna:64]
During the first quarter of fiscal 2020, approximately 17.7% of our revenue was non-U.S. Dollar-denominated, primarily including sales in Japanese Yen, Euro, Canadian Dollars and Brazilian Reais. During the first quarter of fiscal 2020, as compared to the first quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our revenue reported in U.S. Dollars was reduced slightly by approximately $0.9 million, or 0.1%, as compared to the first quarter of fiscal 2019. The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000011:mdna:65]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | 71.0 |  | $ | 548,997 |  |  | 70.5 |  | $ | 42,552 |  |  | 7.8 |  |
| Packet Networking | 67,508 |  |  | 8.1 |  | 71,569 |  |  | 9.2 |  | (4,061 | ) |  | (5.7 | ) |
| Total Networking Platforms | 659,057 |  |  | 79.1 |  | 620,566 |  |  | 79.7 |  | 38,491 |  |  | 6.2 |  |
| Platform Software and Services | 51,888 |  |  | 6.2 |  | 41,598 |  |  | 5.3 |  | 10,290 |  |  | 24.7 |  |
| Blue Planet Automation Software and Services | 15,466 |  |  | 1.9 |  | 14,974 |  |  | 1.9 |  | 492 |  |  | 3.3 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 61,793 |  |  | 7.4 |  | 61,277 |  |  | 8.0 |  | 516 |  |  | 0.8 |  |
| Installation and Deployment | 34,954 |  |  | 4.2 |  | 30,622 |  |  | 3.9 |  | 4,332 |  |  | 14.1 |  |
| Consulting and Network Design | 9,754 |  |  | 1.2 |  | 9,490 |  |  | 1.2 |  | 264 |  |  | 2.8 |  |
| Total Global Services | 106,501 |  |  | 12.8 |  | 101,389 |  |  | 13.1 |  | 5,112 |  |  | 5.0 |  |
| Consolidated revenue | $ | 832,912 |  |  | 100.0 |  | $ | 778,527 |  |  | 100.0 |  | $ | 54,385 |  |  | 7.0 |  |

[0000936395-20-000011:mdna:66]
[same as prior period, unchanged from 0000936395-19-000040:mdna:58]

[0000936395-20-000011:mdna:67]
[same as prior period, unchanged from 0000936395-19-000040:mdna:59]

[0000936395-20-000011:mdna:68]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:69]
| • | Networking Platforms segment revenue increased, reflecting a product line sales increase of $42.6 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $4.1 million of our Packet Networking products. |

[0000936395-20-000011:mdna:70]
| ◦ | Converged Packet Optical sales increased, reflecting increases of $42.5 million of our 6500 Packet-Optical Platform primarily to communications service providers, cable and multi service operators and government, and $34.3 million of our 5430 Reconfigurable Switching Systems to communications service providers. These increases were partially offset by a sales decrease of $35.4 million of our Waveserver products to Web-scale providers. |

[0000936395-20-000011:mdna:71]
| ◦ | Packet Networking sales decreased, primarily reflecting a sales decrease of $14.4 million of our 6500 Packet Transport System (PTS) to communication service providers. The sales decrease was partially offset by a |

[0000936395-20-000011:mdna:72]
sales increase of $8.1 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers.

[0000936395-20-000011:mdna:73]
| • | Platform Software and Services segment revenue increased, reflecting an increase of $8.7 million in software sales and $1.6 million related to services to communication service providers. |

[0000936395-20-000011:mdna:74]
| • | Blue Planet Automation Software and Services segment revenue slightly increased, reflecting an increase of $3.0 million in software services partially offset by a decrease in software sales of $2.5 million. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date. |

[0000936395-20-000011:mdna:75]
| • | Global Services segment revenue increased, primarily reflecting a sales increase of $4.3 million of our installation and deployment services. |

[0000936395-20-000011:mdna:76]
Our operating segments engage in business and operations across three geographic regions: Americas, EMEA and APAC. As discussed in Note 3, effective the beginning of fiscal 2020, our Global Sales and Marketing organization combined our previous North America and CALA regions into a new America sales region. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-20-000011:mdna:77]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Americas | $ | 574,004 |  |  | 68.9 |  | $ | 516,481 |  |  | 66.3 |  | $ | 57,523 |  |  | 11.1 |  |
| EMEA | 129,965 |  |  | 15.6 |  | 129,190 |  |  | 16.6 |  | 775 |  |  | 0.6 |  |
| APAC | 128,943 |  |  | 15.5 |  | 132,856 |  |  | 17.1 |  | (3,913 | ) |  | (2.9 | ) |
| Total | $ | 832,912 |  |  | 100.0 |  | $ | 778,527 |  |  | 100.0 |  | $ | 54,385 |  |  | 7.0 |  |

[0000936395-20-000011:mdna:78]
[same as prior period, unchanged from 0000936395-19-000040:mdna:69]

[0000936395-20-000011:mdna:79]
[same as prior period, unchanged from 0000936395-19-000040:mdna:70]

[0000936395-20-000011:mdna:80]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:81]
| • | Americas revenue increased primarily reflecting sales increases of $46.3 million within our Networking Platforms segment, $6.4 million within our Global Services segment and $7.2 million within our Platform Software and Services segment. These sales increases were slightly offset by a sales decrease of $2.4 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects a product line sales increase of $51.4 million of Converged Packet Optical products, primarily related to sales increases of $54.9 million of our 6500 Packet-Optical Platform and $23.6 million of our 5430 Reconfigurable Switching Systems partially offset by a decrease of $28.6 million of our Waveserver products. Our 6500 Packet-Optical Platform sales primarily reflect increased sales to communications service providers, government customers and cable and multiservice operators. Our 5430 Reconfigurable Switching Systems sales primarily reflect increased sales to communications service providers. Waveserver sales reflect decreased sales to Web-scale providers. |

[0000936395-20-000011:mdna:82]
| • | EMEA revenue slightly increased primarily reflecting an increase of $2.1 million within our Networking Platforms segment. The revenue increase within our Networking Platforms segment reflects a product line sales increase of $1.9 million of Converged Packet Optical products, primarily related to sales increases of $4.4 million of our 6500 Packet-Optical Platform to communications service providers, and $8.7 million of 5430 Reconfigurable Switching Systems to communications service providers. This increase is partially offset by a revenue decrease of $10.7 million of our Waveserver products primarily to Web-scale providers. |

[0000936395-20-000011:mdna:83]
| • | APAC revenue slightly decreased primarily reflecting a decrease of $9.8 million within our Networking Platforms segment, partially offset by sales increases of $3.1 million within our Blue Planet Automation Software and Services segment and $2.7 million within Platform Software and Services segment. Our Networking Platforms segment revenue primarily reflects a decrease of $16.7 million in sales of our 6500 Packet-Optical Platform primarily to communications service providers in India, partially offset by an increase of $4.0 million in sales of our Waveserver products primarily to Web-scale providers. |

[0000936395-20-000011:mdna:84]
[same as prior period, unchanged from 0000936395-19-000040:mdna:77]

[0000936395-20-000011:mdna:85]
34

[0000936395-20-000011:mdna:86]
[same as prior period, unchanged from 0000936395-19-000040:mdna:78]

[0000936395-20-000011:mdna:87]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-20-000011:mdna:88]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-20-000011:mdna:89]
[same as prior period, unchanged from 0000936395-19-000040:mdna:81]

[0000936395-20-000011:mdna:90]
The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-20-000011:mdna:91]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 832,912 |  |  | 100.0 |  | $ | 778,527 |  |  | 100.0 |  | $ | 54,385 |  |  | 7.0 |
| Total cost of goods sold | 462,377 |  |  | 55.5 |  | 455,186 |  |  | 58.5 |  | 7,191 |  |  | 1.6 |
| Gross profit | $ | 370,535 |  |  | 44.5 |  | $ | 323,341 |  |  | 41.5 |  | $ | 47,194 |  |  | 14.6 |

[0000936395-20-000011:mdna:92]
[same as prior period, unchanged from 0000936395-19-000040:mdna:84]

[0000936395-20-000011:mdna:93]
[same as prior period, unchanged from 0000936395-19-000040:mdna:85]

[0000936395-20-000011:mdna:94]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:95]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 687,215 |  |  | 100.0 |  | $ | 642,532 |  |  | 100.0 |  | $ | 44,683 |  |  | 7.0 |
| Product cost of goods sold | 389,013 |  |  | 56.6 |  | 380,442 |  |  | 59.2 |  | 8,571 |  |  | 2.3 |
| Product gross profit | $ | 298,202 |  |  | 43.4 |  | $ | 262,090 |  |  | 40.8 |  | $ | 36,112 |  |  | 13.8 |

[0000936395-20-000011:mdna:96]
[same as prior period, unchanged from 0000936395-19-000040:mdna:88]

[0000936395-20-000011:mdna:97]
[same as prior period, unchanged from 0000936395-19-000040:mdna:89]

[0000936395-20-000011:mdna:98]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:99]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 145,697 |  |  | 100.0 |  | $ | 135,995 |  |  | 100.0 |  | $ | 9,702 |  |  | 7.1 |  |
| Service cost of goods sold | 73,364 |  |  | 50.4 |  | 74,744 |  |  | 55.0 |  | (1,380 | ) |  | (1.8 | ) |
| Service gross profit | $ | 72,333 |  |  | 49.6 |  | $ | 61,251 |  |  | 45.0 |  | $ | 11,082 |  |  | 18.1 |  |

[0000936395-20-000011:mdna:100]
[same as prior period, unchanged from 0000936395-19-000040:mdna:92]

[0000936395-20-000011:mdna:101]
[same as prior period, unchanged from 0000936395-19-000040:mdna:93]

[0000936395-20-000011:mdna:102]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:103]
| • | Gross profit as a percentage of revenue increased, reflecting improved product and services gross profit as described below. In recent periods, we have encountered fluctuations or reductions in our gross margin as a result of our strategy to leverage our technology leadership and to capture aggressively additional market share and displace competitors, with the intent to improve margin in the long term as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. In the fiscal quarter ended January 31, 2020, our gross margin benefited from the success of this ongoing strategy and the resulting favorable mix of customers, network deployments and capacity additions during the period. Continued implementation of this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, or result in an unfavorable mix of revenues from early stage deployments during a particular period, which can adversely impact gross margin. |

[0000936395-20-000011:mdna:104]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to a favorable mix of customers and products and product cost reductions, partially offset by market-based price compression we encountered during the period. |

[0000936395-20-000011:mdna:105]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to higher mix of software-related service sales, as described above, and a reduction in the mix of early stage international network deployments. |

[0000936395-20-000011:mdna:106]
[same as prior period, unchanged from 0000936395-19-000040:mdna:98]

[0000936395-20-000011:mdna:107]
[same as prior period, unchanged from 0000936395-19-000040:mdna:99]

[0000936395-20-000011:mdna:108]
[same as prior period, unchanged from 0000936395-19-000040:mdna:100]

[0000936395-20-000011:mdna:109]
[same as prior period, unchanged from 0000936395-19-000040:mdna:101]

[0000936395-20-000011:mdna:110]
[same as prior period, unchanged from 0000936395-19-000040:mdna:102]

[0000936395-20-000011:mdna:111]
[same as prior period, unchanged from 0000936395-19-000040:mdna:103]

[0000936395-20-000011:mdna:112]
[same as prior period, unchanged from 0000936395-19-000040:mdna:104]

[0000936395-20-000011:mdna:113]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of Packet Design, LLC (“Packet Design”), DonRiver and Centina, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition for 2019. |

[0000936395-20-000011:mdna:114]
During the first quarter of fiscal 2020, approximately 50.7% of our operating expense was non-U.S. Dollar-denominated, including expenses in Canadian Dollars, Indian Rupees, British Pounds and Euros. During the first quarter of fiscal 2020 as compared to the first quarter of fiscal 2019, the U.S. Dollar generally strengthened against these currencies. Consequently, our

[0000936395-20-000011:mdna:115]
36

[0000936395-20-000011:mdna:116]
operating expense reported in U.S. Dollars was reduced slightly by approximately $0.3 million, or 0.1%, as compared to the first quarter of fiscal 2019, due to the strengthening U.S. Dollar, net of hedging. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-20-000011:mdna:117]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 130,900 |  |  | 15.7 |  | $ | 128,633 |  |  | 16.5 |  | $ | 2,267 |  |  | 1.8 |
| Selling and marketing | 107,066 |  |  | 12.9 |  | 98,113 |  |  | 12.6 |  | 8,953 |  |  | 9.1 |
| General and administrative | 42,468 |  |  | 5.1 |  | 39,243 |  |  | 5.0 |  | 3,225 |  |  | 8.2 |
| Amortization of intangible assets | 5,853 |  |  | 0.7 |  | 5,528 |  |  | 0.7 |  | 325 |  |  | 5.9 |
| Significant asset impairments and restructuring costs | 4,472 |  |  | 0.5 |  | 2,273 |  |  | 0.3 |  | 2,199 |  |  | 96.7 |
| Acquisition and integration costs | 1,819 |  |  | 0.2 |  | 1,608 |  |  | 0.2 |  | 211 |  |  | 13.1 |
| Total operating expenses | $ | 292,578 |  |  | 35.1 |  | $ | 275,398 |  |  | 35.3 |  | $ | 17,180 |  |  | 6.2 |

[0000936395-20-000011:mdna:118]
[same as prior period, unchanged from 0000936395-19-000040:mdna:108]

[0000936395-20-000011:mdna:119]
[same as prior period, unchanged from 0000936395-19-000040:mdna:109]

[0000936395-20-000011:mdna:120]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:121]
| • | Research and development expense increased by $2.3 million, primarily reflecting an increase in employee and compensation costs. |

[0000936395-20-000011:mdna:122]
| • | Selling and marketing expense increased by $9.0 million, primarily reflecting an increase in employee and compensation cost. |

[0000936395-20-000011:mdna:123]
| • | General and administrative expense increased by $3.2 million, primarily reflecting increases of $2.1 million in bad debt expense and $1.0 million in employee and compensation costs. |

[0000936395-20-000011:mdna:124]
| • | Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisition of Centina in the first quarter of fiscal 2020. |

[0000936395-20-000011:mdna:125]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. For the first quarter of fiscal 2019, unfavorable lease commitments for certain facility locations in the United States and India where we have vacated unused space. |

[0000936395-20-000011:mdna:126]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisitions of Packet Design, DonRiver and Centina. |

[0000936395-20-000011:mdna:127]
Other Items

[0000936395-20-000011:mdna:128]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-20-000011:mdna:129]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2020 |  | %* |  | 2019 |  | %* |  | (decrease) |  | %** |
| Interest and other income, net | $ | 3,646 |  |  | 0.4 |  | $ | 4,253 |  |  | 0.5 |  | $ | (607 | ) |  | (14.3 | ) |
| Interest expense | $ | 8,815 |  |  | 1.1 |  | $ | 9,441 |  |  | 1.2 |  | $ | (626 | ) |  | (6.6 | ) |
| Loss on extinguishment and modification of debt | $ | (646 | ) |  | 0.1 |  | $ | — |  |  | 0.0 |  | $ | (646 | ) |  | — |  |
| Provision for income taxes | $ | 9,814 |  |  | 1.2 |  | $ | 9,139 |  |  | 1.2 |  | $ | 675 |  |  | 7.4 |  |

[0000936395-20-000011:mdna:130]
[same as prior period, unchanged from 0000936395-19-000040:mdna:120]

[0000936395-20-000011:mdna:131]
[same as prior period, unchanged from 0000936395-19-000040:mdna:121]

[0000936395-20-000011:mdna:132]
**    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:133]
[same as prior period, unchanged from 0000936395-19-000040:mdna:123]

[0000936395-20-000011:mdna:134]
| • | Interest expense decreased, primarily due to a reduction of LIBOR rates impacting our 2025 Term Loan. |

[0000936395-20-000011:mdna:135]
| • | Loss on extinguishment and modification of debt reflects the refinance of our 2025 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements in Item 1 of Part 1 of this report for more details. |

[0000936395-20-000011:mdna:136]
| • | Provision for income taxes increased, due to higher earnings for the first quarter of fiscal 2020. The effective tax rate for the first quarter of fiscal 2020 was lower compared to the first quarter of fiscal 2019, primarily due to the effect of the final regulations released on December 2, 2019 |

[0000936395-20-000011:mdna:137]
Segment Profit (Loss)

[0000936395-20-000011:mdna:138]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-20-000011:mdna:139]
|  | Quarter Ended January 31, |  |  |  |
|  | 2020 |  | 2019 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 168,270 |  |  | $ | 136,590 |  |  | $ | 31,680 |  |  | 23.2 |
| Platform Software and Services | $ | 28,951 |  |  | $ | 20,464 |  |  | $ | 8,487 |  |  | 41.5 |
| Blue Planet Automation Software and Services | $ | (3,113 | ) |  | $ | (2,047 | ) |  | $ | (1,066 | ) |  | 52.1 |
| Global Services | $ | 45,527 |  |  | $ | 39,701 |  |  | $ | 5,826 |  |  | 14.7 |

[0000936395-20-000011:mdna:140]
[same as prior period, unchanged from 0000936395-19-000040:mdna:142]

[0000936395-20-000011:mdna:141]
*    Denotes % change from 2019 to 2020

[0000936395-20-000011:mdna:142]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume and higher gross margin as described above. |

[0000936395-20-000011:mdna:143]
| • | Platform Software and Services segment profit increased, primarily due to higher sales volume, as described above, partially offset by higher research and development cost. |

[0000936395-20-000011:mdna:144]
| • | Blue Planet Automation Software and Services segment loss increased, primarily reflecting decreased software sales and higher research and development costs, partially offset by higher gross margin on software-related services, as described above. |

[0000936395-20-000011:mdna:145]
| • | Global Services segment profit increased, primarily due to higher sales volume and improved gross margin, as described above. |

[0000936395-20-000011:mdna:146]
[same as prior period, unchanged from 0000936395-19-000040:mdna:201]

[0000936395-20-000011:mdna:147]
Overview. For the three months ended January 31, 2020, we generated $39.8 million of cash from operating activities, as our net income (adjusted for non-cash charges) of $143.3 million exceeded our working capital requirements of $103.5 million. For additional details on our cash provided by operating activities, see the discussion below entitled “Cash Provided By Operating Activities.”

[0000936395-20-000011:mdna:148]
Despite our cash generated from operations, cash, cash equivalents and investments decreased by $66.6 million during the first three months of fiscal 2020. The decrease in cash primarily reflects (i) cash used to fund our investing activities for capital expenditures totaling $26.8 million, (ii) cash used for the acquisition of Centina of $28.3 million, (iii) cash used for stock repurchases under our stock repurchase program of $49.2 million, and (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $12.6 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $11.9 million in cash during the three months ended January 31, 2020.

[0000936395-20-000011:mdna:149]
|  | January 31, 2020 |  | October 31, 2019 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 837,286 |  |  | $ | 904,045 |  |  | $ | (66,759 | ) |
| Short-term investments in marketable debt securities | 110,067 |  |  | 109,940 |  |  | 127 |  |
| Long-term investments in marketable debt securities | 10,076 |  |  | 10,014 |  |  | 62 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 957,429 |  |  | $ | 1,023,999 |  |  | $ | (66,570 | ) |

[0000936395-20-000011:mdna:150]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of January 31, 2020 totaled $957.4 million, as well as the senior secured asset-backed revolving credit

[0000936395-20-000011:mdna:151]
facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 31, 2020, letters of credit totaling $81.9 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2020.

[0000936395-20-000011:mdna:152]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $64.0 million as of January 31, 2020. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the

[0000936395-20-000011:mdna:153]
[same as prior period, unchanged from 0000936395-19-000040:mdna:207]

[0000936395-20-000011:mdna:154]
withholding taxes would be approximately $32.0 million.

[0000936395-20-000011:mdna:155]
Stock Repurchase Authorization. On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of its common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. We repurchased $50.7 million under this program during the first quarter of fiscal 2020, and had $299.2 million remaining under the current authorization as of January 31, 2020. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-20-000011:mdna:156]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and to reduce our debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-20-000011:mdna:157]
[same as prior period, unchanged from 0000936395-19-000040:mdna:211]

[0000936395-20-000011:mdna:158]
The following sections set forth the components of our $39.8 million of cash provided by operating activities during the first three months of fiscal 2020:

[0000936395-20-000011:mdna:159]
[same as prior period, unchanged from 0000936395-19-000040:mdna:213]

[0000936395-20-000011:mdna:160]
[same as prior period, unchanged from 0000936395-19-000040:mdna:214]

[0000936395-20-000011:mdna:161]
|  | Three months ended |
|  | January 31, 2020 |
| Net income | $ | 62,328 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 25,782 |  |
| Share-based compensation costs | 15,602 |  |
| Amortization of intangible assets | 9,687 |  |
| Deferred taxes | 10,788 |  |
| Provision for inventory excess and obsolescence | 6,699 |  |
| Provision for warranty | 7,898 |  |
| Other | 4,540 |  |
| Net income (adjusted for non-cash charges) | $ | 143,324 |  |

[0000936395-20-000011:mdna:162]
[same as prior period, unchanged from 0000936395-19-000040:mdna:216]

[0000936395-20-000011:mdna:163]
We used $103.5 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-20-000011:mdna:164]
|  | Three months ended |
|  | January 31, 2020 |
| Cash provided by accounts receivable | $ | 64,938 |  |
| Cash used in inventories | (4,481 | ) |
| Cash used in prepaid expenses and other | (29,792 | ) |
| Cash used in accounts payable, accruals and other obligations | (142,229 | ) |
| Cash provided by deferred revenue | 8,926 |  |
| Cash used in operating lease assets and liabilities, net | (922 | ) |
| Total cash used for working capital | $ | (103,560 | ) |

[0000936395-20-000011:mdna:165]
As compared to the end of fiscal 2019:

[0000936395-20-000011:mdna:166]
| • | The $64.9 million of cash provided by accounts receivable during the first three months of fiscal 2020 reflects increased cash collections; |

[0000936395-20-000011:mdna:167]
| • | The $4.5 million of cash used in inventory during the first three months of fiscal 2020 primarily reflects increases in raw materials to meet customer delivery schedules; |

[0000936395-20-000011:mdna:168]
| • | The $29.8 million of cash used in prepaid expense and other during the first three months of fiscal 2020 primarily reflects increases in upfront future discounts paid to customers and higher non-customer receivables; |

[0000936395-20-000011:mdna:169]
| • | The $142.2 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2020 primarily reflects the timing of payments for bonuses to employees under our annual cash incentive compensation plan and inventory purchases; |

[0000936395-20-000011:mdna:170]
| • | The $8.9 million of cash provided by deferred revenue during the first three months of fiscal 2020 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-20-000011:mdna:171]
| • | The $0.9 million of cash used in operating lease assets and liabilities, net, during the first three months of fiscal 2020 represents cash paid for operating leases. For more details, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-20-000011:mdna:172]
Our days sales outstanding (“DSOs”) for the first three months of fiscal 2020 were 80 days, and our inventory turns for the first three months of fiscal 2020 were 4.5. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-20-000011:mdna:173]
[same as prior period, unchanged from 0000936395-19-000040:mdna:226]

[0000936395-20-000011:mdna:174]
[same as prior period, unchanged from 0000936395-19-000040:mdna:227]

[0000936395-20-000011:mdna:175]
|  | Three months ended |
|  | January 31, 2020 |
| Term Loan due September 28, 2025 (Old) (1) | $ | 6,691 |  |
| Interest rate swaps(2) | 1,055 |  |
| ABL Credit Facility(3) | 331 |  |
| Finance leases | 1,248 |  |
| Cash paid during period | $ | 9,325 |  |

[0000936395-20-000011:mdna:176]
| (1) | Interest on the Old 2025 Term Loan was payable periodically based on the interest period selected for borrowing. The Old 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. On January 23, 2020, we refinanced and replaced this term loan with the New 2025 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report for more information. At the end of the first quarter of fiscal 2020, the interest rate on the New 2025 Term Loan was 3.41%. |

[0000936395-20-000011:mdna:177]
| (2) | The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan at 2.957% through September 2023. |

[0000936395-20-000011:mdna:178]
40

[0000936395-20-000011:mdna:179]
| (3) | During the first three months of fiscal 2020, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.3 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility. |

[0000936395-20-000011:mdna:180]
[same as prior period, unchanged from 0000936395-19-000040:mdna:232]

[0000936395-20-000011:mdna:181]
There have been no material changes to our contractual obligations since October 31, 2019. For a summary of our contractual obligations, see Item 7 of Part II of the 2019 Annual Report.

[0000936395-20-000011:mdna:182]
[same as prior period, unchanged from 0000936395-19-000040:mdna:234]

[0000936395-20-000011:mdna:183]
[same as prior period, unchanged from 0000936395-19-000040:mdna:235]

[0000936395-20-000011:mdna:184]
[same as prior period, unchanged from 0000936395-19-000040:mdna:236]

[0000936395-20-000011:mdna:185]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-20-000011:mdna:186]
Our critical accounting policies and estimates have not changed materially since October 31, 2019, except for items listed below. For a discussion of our critical accounting policies and estimates, see Item 7 of Part II of the 2019 Annual Report.

[0000936395-20-000011:mdna:187]
Leases

[0000936395-20-000011:mdna:188]
For our lease accounting policies due to ASC 842, see Notes 2 and 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-20-000011:mdna:189]
[same as prior period, unchanged from 0000936395-19-000040:mdna:241]

[0000936395-20-000011:mdna:190]
[same as prior period, unchanged from 0000936395-19-000040:mdna:242]
