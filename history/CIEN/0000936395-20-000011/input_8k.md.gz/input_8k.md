# CIEN 8-K — 0000936395-20-000006 filed 2020-03-05

## item codes, every 8-K on or before 2020-03-11

- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2020-03-11

- none on or before 2020-03-11

## item 2.02 — earnings release, exhibit 99.1

[0000936395-20-000006:8k_2_02:1]
EX-99.1
2
ex991-2020q1earningspr.htm
EXHIBIT 99.1

[0000936395-20-000006:8k_2_02:2]
Exhibit

[0000936395-20-000006:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-20-000006:8k_2_02:4]
Ciena Reports Fiscal First Quarter 2020 Financial Results

[0000936395-20-000006:8k_2_02:5]
HANOVER, Md. - March 5, 2020 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal first quarter ended January 31, 2020.

[0000936395-20-000006:8k_2_02:6]
| • | Q1 Revenue: $832.9 million, increasing 7.0% year over year |

[0000936395-20-000006:8k_2_02:7]
| • | Q1 Net Income per Share: $0.40 GAAP; $0.52 adjusted (non-GAAP) |

[0000936395-20-000006:8k_2_02:8]
| • | Share Repurchases: Repurchased approximately 1.3 million shares of common stock for an aggregate price of $50.7 million during the quarter |

[0000936395-20-000006:8k_2_02:9]
"We began fiscal 2020 with another quarter of outstanding financial performance, including 7% year-over-year revenue growth and robust operating results," said Gary Smith, President and CEO, Ciena. "We are well-positioned to continue gaining share by leveraging our financial strength, global scale, diversification and increasing technology leadership."

[0000936395-20-000006:8k_2_02:10]
For the fiscal first quarter 2020, Ciena reported revenue of $832.9 million as compared to $778.5 million for the fiscal first quarter 2019.

[0000936395-20-000006:8k_2_02:11]
Ciena's GAAP net income for the fiscal first quarter 2020 was $62.3 million, or $0.40 per diluted common share, which compares to a GAAP net income of $33.6 million, or $0.21 per diluted common share, for the fiscal first quarter 2019.

[0000936395-20-000006:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal first quarter 2020 was $81.7 million, or $0.52 per diluted common share, which compares to an adjusted (non-GAAP) net income of $52.8 million, or $0.33 per diluted common share, for the fiscal first quarter 2019.

[0000936395-20-000006:8k_2_02:13]
Fiscal First Quarter 2020 Performance Summary

[0000936395-20-000006:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-20-000006:8k_2_02:15]
|  |  | GAAP Results |
|  |  | Q1 |  | Q1 |  |  |
|  |  | FY 2020 |  | FY 2019 |  | Y-T-Y* |
| Revenue |  | $ | 832.9 |  |  | $ | 778.5 |  |  | 7.0 | % |
| Gross margin |  | 44.5 | % |  | 41.5 | % |  | 3.0 | % |
| Operating expense |  | $ | 292.6 |  |  | $ | 275.4 |  |  | 6.2 | % |
| Operating margin |  | 9.4 | % |  | 6.2 | % |  | 3.2 | % |

[0000936395-20-000006:8k_2_02:16]
|  |  | Non-GAAP Results |
|  |  | Q1 |  | Q1 |  |  |
|  |  | FY 2020 |  | FY 2019 |  | Y-T-Y* |
| Revenue |  | $ | 832.9 |  |  | $ | 778.5 |  |  | 7.0 | % |
| Adj. gross margin |  | 45.1 | % |  | 42.2 | % |  | 2.9 | % |
| Adj. operating expense |  | $ | 266.4 |  |  | $ | 253.6 |  |  | 5.0 | % |
| Adj. operating margin |  | 13.1 | % |  | 9.6 | % |  | 3.5 | % |

[0000936395-20-000006:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-20-000006:8k_2_02:18]
|  |  | Revenue by Segment |
|  |  | Q1 FY 2020 |  | Q1 FY 2019 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 591.5 |  |  | 71.0 |  | $ | 548.9 |  |  | 70.5 |
| Packet Networking |  | 67.5 |  |  | 8.1 |  | 71.6 |  |  | 9.2 |
| Total Networking Platforms |  | 659.0 |  |  | 79.1 |  | 620.5 |  |  | 79.7 |
| Platform Software and Services |  | 51.9 |  |  | 6.2 |  | 41.6 |  |  | 5.3 |
| Blue Planet Automation Software and Services |  | 15.5 |  |  | 1.9 |  | 15.0 |  |  | 1.9 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 61.8 |  |  | 7.4 |  | 61.3 |  |  | 8.0 |
| Installation and Deployment |  | 34.9 |  |  | 4.2 |  | 30.6 |  |  | 3.9 |
| Consulting and Network Design |  | 9.8 |  |  | 1.2 |  | 9.5 |  |  | 1.2 |
| Total Global Services |  | 106.5 |  |  | 12.8 |  | 101.4 |  |  | 13.1 |
| Total |  | $ | 832.9 |  |  | 100.0 |  | $ | 778.5 |  |  | 100.0 |

[0000936395-20-000006:8k_2_02:19]
Additional Performance Metrics for Fiscal First Quarter 2020

[0000936395-20-000006:8k_2_02:20]
|  |  | Revenue by Geographic Region |
|  |  | Q1 FY 2020 |  | Q1 FY 2019 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 574.0 |  |  | 68.9 |  | $ | 516.4 |  |  | 66.3 |
| Europe, Middle East and Africa |  | 130.0 |  |  | 15.6 |  | 129.2 |  |  | 16.6 |
| Asia Pacific |  | 128.9 |  |  | 15.5 |  | 132.9 |  |  | 17.1 |
| Total |  | $ | 832.9 |  |  | 100.0 |  | $ | 778.5 |  |  | 100.0 |

[0000936395-20-000006:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-20-000006:8k_2_02:22]
| • | Two 10%-plus customers represented a total of 24% of revenue |

[0000936395-20-000006:8k_2_02:23]
| • | Cash and investments totaled $957.4 million |

[0000936395-20-000006:8k_2_02:24]
| • | Cash flow from operations totaled $39.8 million |

[0000936395-20-000006:8k_2_02:25]
| • | Average days' sales outstanding (DSOs) were 80 |

[0000936395-20-000006:8k_2_02:26]
| • | Accounts receivable balance was $655.1 million |

[0000936395-20-000006:8k_2_02:27]
| • | Unbilled contract asset balance was $83.7 million |

[0000936395-20-000006:8k_2_02:28]
| • | Inventories totaled $342.7 million, including: |

[0000936395-20-000006:8k_2_02:29]
| ◦ | Raw materials: $106.5 million |

[0000936395-20-000006:8k_2_02:30]
| ◦ | Work in process: $11.7 million |

[0000936395-20-000006:8k_2_02:31]
| ◦ | Finished goods: $219.9 million |

[0000936395-20-000006:8k_2_02:32]
| ◦ | Deferred cost of sales: $49.3 million |

[0000936395-20-000006:8k_2_02:33]
| ◦ | Reserve for excess and obsolescence: $(44.7) million |

[0000936395-20-000006:8k_2_02:34]
| • | Product inventory turns were 4.5 |

[0000936395-20-000006:8k_2_02:35]
| • | Headcount totaled 6,588 |

[0000936395-20-000006:8k_2_02:36]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal First Quarter 2020 Results

[0000936395-20-000006:8k_2_02:37]
Today, Thursday, March 5, 2020, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website an accompanying investor presentation for its unaudited fiscal first quarter 2020 results.

[0000936395-20-000006:8k_2_02:38]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-20-000006:8k_2_02:39]
Notes to Investors

[0000936395-20-000006:8k_2_02:40]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “We began fiscal 2020 with another quarter of

[0000936395-20-000006:8k_2_02:41]
outstanding financial performance, including 7% year-over-year revenue growth and robust operating results. We are well-positioned to continue gaining share by leveraging our financial strength, global scale, diversification and increasing technology leadership.”

[0000936395-20-000006:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, pandemics, or a widespread health epidemic, such as the outbreak of the 2019 novel coronavirus; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs and duties; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise; and the other risk factors disclosed in its Annual Report on Form 10-K filed with the SEC on December 20, 2019 and included in its Quarterly Report on Form 10-Q for the current quarter. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-20-000006:8k_2_02:43]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-20-000006:8k_2_02:44]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our clients create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-20-000006:8k_2_02:45]
CIENA CORPORATION

[0000936395-20-000006:8k_2_02:46]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-20-000006:8k_2_02:47]
(in thousands, except per share data)

[0000936395-20-000006:8k_2_02:48]
(unaudited)

[0000936395-20-000006:8k_2_02:49]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Revenue: |  |  |  |
| Products | $ | 687,215 |  |  | $ | 642,532 |  |
| Services | 145,697 |  |  | 135,995 |  |
| Total revenue | 832,912 |  |  | 778,527 |  |
| Cost of goods sold: |  |  |  |
| Products | 389,013 |  |  | 380,442 |  |
| Services | 73,364 |  |  | 74,744 |  |
| Total cost of goods sold | 462,377 |  |  | 455,186 |  |
| Gross profit | 370,535 |  |  | 323,341 |  |
| Operating expenses: |  |  |  |
| Research and development | 130,900 |  |  | 128,633 |  |
| Selling and marketing | 107,066 |  |  | 98,113 |  |
| General and administrative | 42,468 |  |  | 39,243 |  |
| Amortization of intangible assets | 5,853 |  |  | 5,528 |  |
| Significant asset impairments and restructuring costs | 4,472 |  |  | 2,273 |  |
| Acquisition and integration costs | 1,819 |  |  | 1,608 |  |
| Total operating expenses | 292,578 |  |  | 275,398 |  |
| Income from operations | 77,957 |  |  | 47,943 |  |
| Interest and other income, net | 3,646 |  |  | 4,253 |  |
| Interest expense | (8,815 | ) |  | (9,441 | ) |
| Loss on extinguishment and modification of debt | (646 | ) |  | — |  |
| Income before income taxes | 72,142 |  |  | 42,755 |  |
| Provision for income taxes | 9,814 |  |  | 9,139 |  |
| Net income | $ | 62,328 |  |  | $ | 33,616 |  |
| Net Income per Common Share |  |  |  |
| Basic net income per common share | $ | 0.40 |  |  | $ | 0.22 |  |
| Diluted net income per potential common share | $ | 0.40 |  |  | $ | 0.21 |  |
| Weighted average basic common shares outstanding | 154,334 |  |  | 156,314 |  |
| Weighted average dilutive potential common shares outstanding 1 | 155,738 |  |  | 158,174 |  |

[0000936395-20-000006:8k_2_02:50]
1. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first quarter of fiscal 2020 includes 1.4 million shares underlying certain stock options and stock unit awards.

[0000936395-20-000006:8k_2_02:51]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first first quarter of fiscal 2019 includes 1.9 million shares underlying certain stock options and stock unit awards.

[0000936395-20-000006:8k_2_02:52]
CIENA CORPORATION

[0000936395-20-000006:8k_2_02:53]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-20-000006:8k_2_02:54]
(in thousands, except share data)

[0000936395-20-000006:8k_2_02:55]
(unaudited)

[0000936395-20-000006:8k_2_02:56]
|  | January 31, 2020 |  | October 31, 2019 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 837,286 |  |  | $ | 904,045 |  |
| Short-term investments | 110,067 |  |  | 109,940 |  |
| Accounts receivable, net | 655,105 |  |  | 724,854 |  |
| Inventories | 342,673 |  |  | 345,049 |  |
| Prepaid expenses and other | 321,313 |  |  | 297,914 |  |
| Total current assets | 2,266,444 |  |  | 2,381,802 |  |
| Long-term investments | 10,076 |  |  | 10,014 |  |
| Equipment, building, furniture and fixtures, net | 277,739 |  |  | 286,884 |  |
| Operating lease right-of-use assets | 50,148 |  |  | — |  |
| Goodwill | 310,913 |  |  | 297,937 |  |
| Other intangible assets, net | 125,640 |  |  | 112,781 |  |
| Deferred tax asset, net | 699,439 |  |  | 714,942 |  |
| Other long-term assets | 90,488 |  |  | 88,986 |  |
| Total assets | $ | 3,830,887 |  |  | $ | 3,893,346 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 311,748 |  |  | $ | 344,819 |  |
| Accrued liabilities and other short-term obligations | 273,305 |  |  | 382,740 |  |
| Deferred revenue | 122,410 |  |  | 111,381 |  |
| Operating lease liabilities | 18,623 |  |  | — |  |
| Current portion of long-term debt | 7,000 |  |  | 7,000 |  |
| Total current liabilities | 733,086 |  |  | 845,940 |  |
| Long-term deferred revenue | 44,425 |  |  | 45,492 |  |
| Other long-term obligations | 125,607 |  |  | 148,747 |  |
| Long-term operating lease liabilities | 53,333 |  |  | — |  |
| Long-term debt, net | 680,786 |  |  | 680,406 |  |
| Total liabilities | $ | 1,637,237 |  |  | $ | 1,720,585 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 153,946,833 and 154,403,850 shares issued and outstanding | 1,539 |  |  | 1,544 |  |
| Additional paid-in capital | 6,801,907 |  |  | 6,837,714 |  |
| Accumulated other comprehensive loss | (27,711 | ) |  | (22,084 | ) |
| Accumulated deficit | (4,582,085 | ) |  | (4,644,413 | ) |
| Total stockholders’ equity | 2,193,650 |  |  | 2,172,761 |  |
| Total liabilities and stockholders’ equity | $ | 3,830,887 |  |  | $ | 3,893,346 |  |

[0000936395-20-000006:8k_2_02:57]
CIENA CORPORATION

[0000936395-20-000006:8k_2_02:58]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-20-000006:8k_2_02:59]
(in thousands) (unaudited)

[0000936395-20-000006:8k_2_02:60]
|  | Three Months Ended January 31, |
|  | 2020 |  | 2019 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income | $ | 62,328 |  |  | $ | 33,616 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 25,782 |  |  | 21,513 |  |
| Share-based compensation costs | 15,602 |  |  | 13,755 |  |
| Amortization of intangible assets | 9,687 |  |  | 8,947 |  |
| Deferred taxes | 10,788 |  |  | 5,037 |  |
| Provision for inventory excess and obsolescence | 6,699 |  |  | 4,673 |  |
| Provision for warranty | 7,898 |  |  | 3,891 |  |
| Other | 4,540 |  |  | 3,356 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 64,938 |  |  | 38,544 |  |
| Inventories | (4,481 | ) |  | (67,555 | ) |
| Prepaid expenses and other | (29,792 | ) |  | 1,133 |  |
| Operating lease right-of-use assets | 4,176 |  |  | — |  |
| Accounts payable, accruals and other obligations | (142,229 | ) |  | (76,351 | ) |
| Deferred revenue | 8,926 |  |  | (4,664 | ) |
| Short and long-term operating lease liabilities | (5,098 | ) |  | — |  |
| Net cash provided by (used in) operating activities | 39,764 |  |  | (14,105 | ) |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (26,820 | ) |  | (15,345 | ) |
| Purchase of available for sale securities | (29,733 | ) |  | (68,516 | ) |
| Proceeds from maturities of available for sale securities | 30,000 |  |  | 60,000 |  |
| Proceeds from sales of available for sale securities | — |  |  | 98,265 |  |
| Settlement of foreign currency forward contracts, net | (73 | ) |  | (4,650 | ) |
| Acquisition of business, net of cash acquired | (28,300 | ) |  | — |  |
| Purchase of equity investment | — |  |  | (333 | ) |
| Net cash provided by (used in) investing activities | (54,926 | ) |  | 69,421 |  |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | — |  |  | (1,750 | ) |
| Payment of debt issuance costs | (382 | ) |  | — |  |
| Payment of finance lease obligations | (722 | ) |  | (758 | ) |
| Payment for debt conversion liability | — |  |  | (111,268 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (12,572 | ) |  | (10,026 | ) |
| Repurchases of common stock - repurchase program | (49,203 | ) |  | (19,721 | ) |
| Proceeds from issuance of common stock | 11,862 |  |  | 10,899 |  |
| Net cash used in financing activities | (51,017 | ) |  | (132,624 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (643 | ) |  | 695 |  |
| Net decrease in cash, cash equivalents and restricted cash | (66,822 | ) |  | (76,613 | ) |
| Cash, cash equivalents and restricted cash at beginning of period | 904,161 |  |  | 745,423 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 837,339 |  |  | $ | 668,810 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 9,325 |  |  | $ | 10,007 |  |
| Cash paid during the period for income taxes, net | $ | 8,325 |  |  | $ | 3,402 |  |
| Operating lease payments | $ | 5,642 |  |  | $ | — |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 5,905 |  |  | $ | 5,471 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 1,501 |  |  | $ | 1,441 |  |
| Conversion of debt conversion liability into 1,585,140 shares of common stock | $ | — |  |  | $ | 52,944 |  |
| Operating lease right-of-use assets subject to lease liability | $ | 1,157 |  |  | $ | — |  |

[0000936395-20-000006:8k_2_02:61]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 370,535 |  |  | $ | 323,341 |  |
| Share-based compensation-products |  | 671 |  |  | 637 |  |
| Share-based compensation-services |  | 842 |  |  | 770 |  |
| Amortization of intangible assets |  | 3,834 |  |  | 3,418 |  |
| Total adjustments related to gross profit |  | 5,347 |  |  | 4,825 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 375,882 |  |  | $ | 328,166 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 45.1 | % |  | 42.2 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 292,578 |  |  | $ | 275,398 |  |
| Share-based compensation-research and development |  | 3,849 |  |  | 3,391 |  |
| Share-based compensation-sales and marketing |  | 4,613 |  |  | 3,785 |  |
| Share-based compensation-general and administrative |  | 5,527 |  |  | 5,112 |  |
| Amortization of intangible assets |  | 5,853 |  |  | 5,528 |  |
| Significant asset impairments and restructuring costs |  | 4,472 |  |  | 2,273 |  |
| Acquisition and integration costs |  | 1,819 |  |  | 1,608 |  |
| Legal settlement |  | — |  |  | 137 |  |
| Total adjustments related to operating expense |  | 26,133 |  |  | 21,834 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 266,445 |  |  | $ | 253,564 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 77,957 |  |  | $ | 47,943 |  |
| Total adjustments related to gross profit |  | 5,347 |  |  | 4,825 |  |
| Total adjustments related to operating expense |  | 26,133 |  |  | 21,834 |  |
| Total adjustments related to income from operations |  | 31,480 |  |  | 26,659 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 109,437 |  |  | $ | 74,602 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.1 | % |  | 9.6 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 62,328 |  |  | $ | 33,616 |  |
| Exclude GAAP provision for income taxes |  | 9,814 |  |  | 9,139 |  |
| Income before income taxes |  | 72,142 |  |  | 42,755 |  |
| Total adjustments related to income from operations |  | 31,480 |  |  | 26,659 |  |
| Loss on extinguishment and modification of debt |  | 646 |  |  | — |  |
| Adjusted income before income taxes |  | 104,268 |  |  | 69,414 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 22,522 |  |  | 16,590 |  |
| Adjusted (non-GAAP) net income |  | $ | 81,746 |  |  | $ | 52,824 |  |
| Weighted average basic common shares outstanding |  | 154,334 |  |  | 156,314 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 155,738 |  |  | 158,174 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.40 |  |  | $ | 0.21 |  |
| Adjusted (non-GAAP) diluted net income per common share |  | $ | 0.52 |  |  | $ | 0.33 |  |

[0000936395-20-000006:8k_2_02:62]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2020 includes 1.4 million shares underlying certain stock options and stock unit awards. |

[0000936395-20-000006:8k_2_02:63]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the first quarter of fiscal 2019 includes 1.9 million shares underlying certain stock options and restricted stock unit awards.

[0000936395-20-000006:8k_2_02:64]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 62,328 |  |  | $ | 33,616 |  |
| Add: Interest expense |  | 8,815 |  |  | 9,441 |  |
| Less: Interest and other income, net |  | 3,646 |  |  | 4,253 |  |
| Add: Loss on extinguishment and modification of debt |  | 646 |  |  | — |  |
| Add: Provision for income taxes |  | 9,814 |  |  | 9,139 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 25,782 |  |  | 21,513 |  |
| Add: Amortization of intangible assets |  | 9,687 |  |  | 8,947 |  |
| EBITDA |  | $ | 113,426 |  |  | $ | 78,403 |  |
| Add: Shared-based compensation cost |  | 15,602 |  |  | 13,755 |  |
| Add: Significant asset impairments and restructuring costs |  | 4,472 |  |  | 2,273 |  |
| Add: Acquisition and integration costs |  | 1,819 |  |  | 1,608 |  |
| Add: Legal settlement |  | — |  |  | 137 |  |
| Adjusted EBITDA |  | $ | 135,319 |  |  | $ | 96,176 |  |

[0000936395-20-000006:8k_2_02:65]
* * *

[0000936395-20-000006:8k_2_02:66]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-20-000006:8k_2_02:67]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-20-000006:8k_2_02:68]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-20-000006:8k_2_02:69]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-20-000006:8k_2_02:70]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors' costs and severance and other employment-related costs related to Ciena's acquisition of Packet Design and DonRiver in fiscal 2018, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition and Ciena's acquisition of Centina in the first quarter of fiscal 2020. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-20-000006:8k_2_02:71]
| • | Legal settlement - costs incurred as a result of a settlement, during the first quarter of fiscal 2019. |

[0000936395-20-000006:8k_2_02:72]
| • | Loss on extinguishment and modification of debt - reflects extinguishment and modification of debt expenses related to refinancing of our Term Loan due September 28, 2025. |

[0000936395-20-000006:8k_2_02:73]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 21.6% for the first fiscal quarter of 2020 and 23.9% for the first fiscal quarter of 2019. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
