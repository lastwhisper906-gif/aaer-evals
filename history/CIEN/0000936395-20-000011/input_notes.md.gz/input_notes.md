# CIEN notes — 0000936395-20-000011


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-20-000011:notes:1]
INTERIM FINANCIAL STATEMENTS
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2019 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2019.
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2020 and 2019 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-20-000011:notes:2]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2019 Annual Report.

[0000936395-20-000011:notes:3]
[same as prior period, unchanged from 0000936395-19-000040:notes:3]

[0000936395-20-000011:notes:4]
Leases

[0000936395-20-000011:notes:5]
In February 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Codification ASC 842, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Effective November 1, 2019, Ciena adopted ASC 842 which requires right-of-use ("ROU") assets and lease liabilities to be recorded on the balance sheet for leases. The guidance specifies that at the inception of a contract, an entity must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts followed the assessment of whether there was a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating right-of-use assets (“Operating ROU assets”), Operating lease liabilities and Long-term operating lease liabilities in the Condensed Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations are included in the Condensed Consolidated Balance Sheets.

[0000936395-20-000011:notes:6]
Ciena adopted the guidance on a modified retrospective basis as of November 1, 2019, such that related amounts in prior periods have not been restated. Ciena has operating and finance leases that primarily relate to real property. As a practical expedient, Ciena has elected the “package of practical expedients” and, as a result, did not reassess existing lease identifications, lease classifications or initial direct costs. As a practical expedient, Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Also as a practical expedient for disclosure, Ciena has elected not to separate lease and non-lease components on operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass through operating expenses like common area maintenance and utilities.

[0000936395-20-000011:notes:7]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Condensed Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms

[0000936395-20-000011:notes:8]
similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Condensed Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Condensed Consolidated Statements of Operations.

[0000936395-20-000011:notes:9]
Upon adoption, Ciena recorded Operating ROU assets of $53.3 million and lease liabilities of $76.0 million related to its operating leases. As of October 31, 2019, the restructuring reserve liability for vacated office space of $11.1 million was included in Accrued liabilities and other short-term obligations and Other long-term obligations on the Condensed Consolidated Balance Sheet under prior accounting guidance. Upon adoption of the updated guidance, the existing lease reserve liability was reclassified as a reduction to the Operating ROU assets. ROU assets will be tested for impairment when circumstances indicate that the carrying values may not be recoverable. The adoption of this guidance did not require a cumulative effect adjustment or have an impact on the Condensed Consolidated Statements of Income or Condensed Consolidated Statements of Cash Flows.

[0000936395-20-000011:notes:10]
[same as prior period, unchanged from 0000936395-19-000040:notes:33]

[0000936395-20-000011:notes:11]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 842 (in millions):

[0000936395-20-000011:notes:12]
|  |  | Balance at October 31, 2019 |  | New Lease Accounting Standard |  |  | Adjusted Balance at November 1, 2019 |
| ASSETS: |  |  |  |  |  |  |  |
| Operating right-of-use assets |  | $ | — |  |  | $ | 53,334 |  | (1) |  | $ | 53,334 |  |
| Total assets |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations |  | $ | 382,740 |  |  | $ | (1,484 | ) | (2) |  | $ | 381,256 |  |
| Short-term lease liabilities |  | $ | — |  |  | 20,498 |  | (3) |  | $ | 20,498 |  |
| Other long-term obligations |  | $ | 148,747 |  |  | (21,244 | ) | (4) |  | $ | 127,503 |  |
| Long-term operating lease liabilities |  | $ | — |  |  | 55,564 |  | (5) |  | $ | 55,564 |  |
| Total liabilities and stockholders equity |  | $ | 3,893,346 |  |  | $ | 53,334 |  |  |  | $ | 3,946,680 |  |

[0000936395-20-000011:notes:13]
| (1) | Represents $76.0 million of operating leases recognized as Operating ROU assets upon adoption of ASC 842, less $5.4 million of deferred rent, $6.2 million of tenant improvement allowances, $1.5 million of short-term restructuring reserve liability and $9.6 million of long-term restructuring reserve liability all recognized as a reduction to Right-of-use assets. |

[0000936395-20-000011:notes:14]
| (2) | Represents $1.5 million of short-term restructuring reserve liability recognized as a reduction to Operating ROU assets. |

[0000936395-20-000011:notes:15]
| (3) | Represents $20.5 million of lease liabilities for operating leases. |

[0000936395-20-000011:notes:16]
| (4) | Represents $9.6 million of long-term restructuring reserve liability, $5.4 million of deferred rent, and $6.2 million of tenant improvement allowances recognized as a reduction to Right-of-use assets. |

[0000936395-20-000011:notes:17]
| (5) | Represents $55.6 million of lease liabilities for operating leases. |

[0000936395-20-000011:notes:18]
See Note 15 for additional information.

[0000936395-20-000011:notes:19]
Fair Value Measurement

[0000936395-20-000011:notes:20]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. Ciena adopted ASU 2018-13 beginning the first quarter of fiscal year 2020. Adoption of ASU 2018-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-20-000011:notes:21]
[same as prior period, unchanged from 0000936395-19-000040:notes:49]

[0000936395-20-000011:notes:22]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021, and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-20-000011:notes:23]
[same as prior period, unchanged from 0000936395-19-000040:notes:53]

[0000936395-20-000011:notes:24]
[same as prior period, unchanged from 0000936395-19-000040:notes:54]

[0000936395-20-000011:notes:25]
[same as prior period, unchanged from 0000936395-19-000040:notes:55]

[0000936395-20-000011:notes:26]
|  | Quarter Ended January 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 591,549 |  |
| Packet Networking | 67,508 |  |  | — |  |  | — |  |  | — |  |  | 67,508 |  |
| Platform Software and Services | — |  |  | 51,888 |  |  | — |  |  | — |  |  | 51,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,466 |  |  | — |  |  | 15,466 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,793 |  |  | 61,793 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,954 |  |  | 34,954 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,754 |  |  | 9,754 |  |
| Total revenue by product line | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 659,057 |  |  | $ | 13,114 |  |  | $ | 3,736 |  |  | $ | 4,197 |  |  | $ | 680,104 |  |
| Services transferred over time | — |  |  | 38,774 |  |  | 11,730 |  |  | 102,304 |  |  | 152,808 |  |
| Total revenue by timing of revenue recognition | $ | 659,057 |  |  | $ | 51,888 |  |  | $ | 15,466 |  |  | $ | 106,501 |  |  | $ | 832,912 |  |

[0000936395-20-000011:notes:27]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 16,044 |  |  | $ | 6,228 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 25,554 |  |  | 8,746 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 41,598 |  |  | $ | 14,974 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

[0000936395-20-000011:notes:28]
Effective the beginning of fiscal 2020, Ciena’s Global Sales and Marketing organization combined its previous North America and Caribbean and Latin America (“CALA”) regions into a new “Americas” sales region. Accordingly, Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, we maintain specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel, who ensure that we maintain a high-touch, consultative relationship with our customers.

[0000936395-20-000011:notes:29]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-20-000011:notes:30]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Geographic distribution: |  |  |  |  |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 832,912 |  |  | $ | 778,527 |  |

[0000936395-20-000011:notes:31]
[same as prior period, unchanged from 0000936395-19-000040:notes:59]

[0000936395-20-000011:notes:32]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system (“Waveserver”), the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-20-000011:notes:33]
[same as prior period, unchanged from 0000936395-19-000040:notes:61]

[0000936395-20-000011:notes:34]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-20-000011:notes:35]
| • | Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

[0000936395-20-000011:notes:36]
| • | Blue Planet® Automation Software and Services is a comprehensive, open software suite, together with related services, that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management, unified assurance and analytics (UAA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations. |

[0000936395-20-000011:notes:37]
Ciena’s software platform revenue typically reflects sales of either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-20-000011:notes:38]
[same as prior period, unchanged from 0000936395-19-000040:notes:68]

[0000936395-20-000011:notes:39]
[same as prior period, unchanged from 0000936395-19-000040:notes:69]

[0000936395-20-000011:notes:40]
[same as prior period, unchanged from 0000936395-19-000040:notes:70]

[0000936395-20-000011:notes:41]
[same as prior period, unchanged from 0000936395-19-000040:notes:71]

[0000936395-20-000011:notes:42]
|  |  | Balance at January 31, 2020 |  | Balance at October 31, 2019 |
| Accounts receivable, net |  | $ | 655,105 |  |  | $ | 724,854 |  |
| Contract assets |  | $ | 83,717 |  |  | $ | 84,046 |  |
| Deferred revenue |  | $ | 166,835 |  |  | $ | 156,873 |  |

[0000936395-20-000011:notes:43]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Condensed Consolidated Balance Sheets. See Note 11 for further discussion.

[0000936395-20-000011:notes:44]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $49.0 million and $39.4 million of revenue during the first three months of fiscal 2020 and 2019 that was included in the deferred revenue balance at October 31, 2019 and November 1, 2018, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 31, 2020 and 2019.

[0000936395-20-000011:notes:45]
Capitalized Contract Acquisition Costs

[0000936395-20-000011:notes:46]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $13.1 million and $15.7 million as of January 31, 2020 and October 31, 2019, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $5.6 million and $4.1 million during the first three months of fiscal 2020 and 2019, respectively, and was included in sales and marketing expense.

[0000936395-20-000011:notes:47]
[same as prior period, unchanged from 0000936395-19-000040:notes:76]

[0000936395-20-000011:notes:48]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2020, the aggregate amount of RPO was $905 million. As of January 31, 2020, Ciena expects approximately 82% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-20-000011:notes:49]
[same as prior period, unchanged from 0000936395-19-000040:notes:78]

[0000936395-20-000011:notes:50]
Centina Systems, Inc. Acquisition

[0000936395-20-000011:notes:51]
On November 2, 2019 Ciena acquired Centina Systems, Inc. (“Centina”), a provider of service assurance analytics and network performance management solutions, for approximately $34.0 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-20-000011:notes:52]
During the first quarter of fiscal 2020, Ciena incurred approximately $0.5 million of acquisition-related costs associated with this transaction. These costs primarily reflect fees associated with financial, legal and accounting advisors.

[0000936395-20-000011:notes:53]
[same as prior period, unchanged from 0000936395-19-000040:notes:82]

[0000936395-20-000011:notes:54]
|  | Amount |
| Cash and cash equivalents | $ | 5,718 |  |
| Accounts receivable | 610 |  |
| Prepaid expenses and other | 536 |  |
| Equipment, furniture and fixtures | 17 |  |
| Goodwill | 13,055 |  |
| Customer relationships and contracts | 400 |  |
| Developed technology | 22,200 |  |
| Accounts payable | (47 | ) |
| Accrued liabilities | (286 | ) |
| Deferred revenue | (1,493 | ) |
| Deferred tax liability | (6,692 | ) |
| Total purchase consideration | $ | 34,018 |  |

[0000936395-20-000011:notes:55]
Customer relationships and contracts represent agreements with existing Centina customers and have an estimated useful life of two years.

[0000936395-20-000011:notes:56]
Developed technology represents purchased technology that has reached technological feasibility and for which Centina had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-20-000011:notes:57]
The goodwill generated from the acquisition of Centina is primarily related to expected synergies. The total goodwill amount was recorded in the Blue Planet Automation Software and Services segment. The goodwill is not deductible for income tax purposes.

[0000936395-20-000011:notes:58]
[same as prior period, unchanged from 0000936395-19-000040:notes:87]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-20-000011:notes:59]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on our Condensed Consolidated Balance Sheets, for the three months ended January 31, 2020 (in thousands):

[0000936395-20-000011:notes:60]
|  | Workforcereduction |  | Consolidationof excessfacilities and other restructuring activities |  | Total |
| Balance at October 31, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 1,204 |  | (1) | 3,268 |  | (2) | 4,472 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160 | ) | (3) | (11,160 | ) |
| Cash payments | (2,955 | ) |  | (3,268 | ) |  | (6,223 | ) |
| Balance at January 31, 2020 | $ | 2,232 |  |  | $ | — |  |  | $ | 2,232 |  |
| Current restructuring liabilities | $ | 2,232 |  |  | $ | — |  |  | $ | 2,232 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-20-000011:notes:61]
| (1) | Reflects a global workforce reduction of approximately 22 employees during the three months ended January 31, 2020 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-20-000011:notes:62]
| (2) | Primarily represents variable costs and imputed interest expense related to restructured facilities |

[0000936395-20-000011:notes:63]
| (3) | Represents restructuring reserve liability recognized as a reduction to Operating right-of-use assets, net in relation to adoption of ASC 842. See Notes 2 and 15 for further discussion. |

[0000936395-20-000011:notes:64]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on our Condensed Consolidated Balance Sheets for the three months ended January 31, 2019 (in thousands):

[0000936395-20-000011:notes:65]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Charges | 1,752 |  | (1) | 521 |  | (2) | 2,273 |  |
| Cash payments | (3,009 | ) |  | (548 | ) |  | (3,557 | ) |
| Balance at January 31, 2019 | $ | 851 |  |  | $ | 1,712 |  |  | $ | 2,563 |  |
| Current restructuring liabilities | $ | 851 |  |  | $ | 525 |  |  | $ | 1,376 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,187 |  |  | $ | 1,187 |  |

[0000936395-20-000011:notes:66]
| (1) | Reflects a global workforce reduction of approximately 10 employees during the three months ended January 31, 2019 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-20-000011:notes:67]
(2)
Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and Spokane, Washington.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-20-000011:notes:68]
INTEREST AND OTHER INCOME, NET
The components of interest and other income, net, are as follows (in thousands):

[0000936395-20-000011:notes:69]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Interest income | $ | 3,390 |  |  | $ | 3,872 |  |
| Gains on non-hedge designated foreign currency forward contracts | 637 |  |  | 22 |  |
| Foreign currency exchange gains (losses) | (771 | ) |  | 783 |  |
| Other | 390 |  |  | (424 | ) |
| Interest and other income, net | $ | 3,646 |  |  | $ | 4,253 |  |

[0000936395-20-000011:notes:70]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $0.8 million in foreign

[0000936395-20-000011:notes:71]
currency exchange rate losses during the first three months of fiscal 2020 and $0.8 million in foreign currency exchange rate gains during the first three months of fiscal 2019, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2020, Ciena recorded gains of $0.6 million from non-hedge designated foreign currency forward contracts. During the first three months of fiscal 2019, Ciena recorded minimal gains from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-20-000011:notes:72]
[same as prior period, unchanged from 0000936395-19-000040:notes:99]

[0000936395-20-000011:notes:73]
On December 2, 2019, the U.S. Department of the Treasury released final regulations and proposed regulations under Section 59A, Base Erosion and Anti-Abuse Tax (“BEAT”). BEAT, which requires certain U.S. corporations to pay a minimum tax associated with deductible payments to non-U.S. related parties, was enacted by the Tax Cuts and Jobs Act (the “Tax Act”). Also, on December 2, 2019, the U.S. Department of the Treasury released final regulations that provide additional guidance with respect to the foreign tax credit regime under the Tax Act.

[0000936395-20-000011:notes:74]
The effective tax rate for the three months ended January 31, 2020 was lower than the effective tax rate for the three months ended January 31, 2019, primarily due to the effect of the final regulations on December 2, 2019.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-20-000011:notes:75]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-20-000011:notes:76]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-20-000011:notes:77]
|  | January 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,962 |  |  | $ | 105 |  |  | $ | — |  |  | $ | 110,067 |  |
| Included in long-term investments | 10,073 |  |  | 3 |  |  | — |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 108 |  |  | $ | — |  |  | $ | 120,143 |  |

[0000936395-20-000011:notes:78]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

[0000936395-20-000011:notes:79]
The following table summarizes the final legal maturities of debt investments at January 31, 2020 (in thousands):

[0000936395-20-000011:notes:80]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 109,962 |  |  | $ | 110,067 |  |
| Due in 1-2 years | 10,073 |  |  | 10,076 |  |
|  | $ | 120,035 |  |  | $ | 120,143 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-20-000011:notes:81]
[same as prior period, unchanged from 0000936395-19-000040:notes:109]

[0000936395-20-000011:notes:82]
[same as prior period, unchanged from 0000936395-19-000040:notes:110]

[0000936395-20-000011:notes:83]
|  | January 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 632,620 |  |  | $ | — |  |  | $ | — |  |  | $ | 632,620 |  |
| Bond mutual fund | 50,180 |  |  | — |  |  | — |  |  | 50,180 |  |
| U.S. government obligations | — |  |  | 120,143 |  |  | — |  |  | 120,143 |  |
| Foreign currency forward contracts | — |  |  | 273 |  |  | — |  |  | 273 |  |
| Total assets measured at fair value | $ | 682,800 |  |  | $ | 120,416 |  |  | $ | — |  |  | $ | 803,216 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 710 |  |  | $ | — |  |  | $ | 710 |  |
| Forward starting interest rate swaps | — |  |  | 22,225 |  |  | — |  |  | 22,225 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 22,935 |  |  | $ | 3,705 |  |  | $ | 26,640 |  |

[0000936395-20-000011:notes:84]
|  | October 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| U.S. government obligations | — |  |  | 119,954 |  |  | — |  |  | 119,954 |  |
| Foreign currency forward contracts | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Total assets measured at fair value | $ | 759,114 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 880,638 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Forward starting interest rate swaps | — |  |  | 21,093 |  |  | — |  |  | 21,093 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000011:notes:85]
[same as prior period, unchanged from 0000936395-19-000040:notes:113]

[0000936395-20-000011:notes:86]
|  | January 31, 2020 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 682,800 |  |  | $ | — |  |  | $ | — |  |  | $ | 682,800 |  |
| Short-term investments | — |  |  | 110,067 |  |  | — |  |  | 110,067 |  |
| Prepaid expenses and other | — |  |  | 273 |  |  | — |  |  | 273 |  |
| Long-term investments | — |  |  | 10,076 |  |  | — |  |  | 10,076 |  |
| Total assets measured at fair value | $ | 682,800 |  |  | $ | 120,416 |  |  | $ | — |  |  | $ | 803,216 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 710 |  |  | $ | 3,705 |  |  | $ | 4,415 |  |
| Other long-term obligations | — |  |  | 22,225 |  |  | — |  |  | 22,225 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 22,935 |  |  | $ | 3,705 |  |  | $ | 26,640 |  |

[0000936395-20-000011:notes:87]
|  | October 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Short-term investments | — |  |  | 109,940 |  |  | — |  |  | 109,940 |  |
| Prepaid expenses and other | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Long-term investments | — |  |  | 10,014 |  |  | — |  |  | 10,014 |  |
| Total assets measured at fair value | $ | 759,114 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 880,638 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Other long-term obligations | — |  |  | 21,093 |  |  | 3,705 |  |  | 24,798 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-20-000011:notes:88]
[same as prior period, unchanged from 0000936395-19-000040:notes:116]

[0000936395-20-000011:notes:89]
Ciena’s Level 3 liability includes $3.7 million in accrued liabilities and other short-term obligations as of January 31, 2020. This reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver Holdings, LLC (“DonRiver”) in the fourth quarter of fiscal 2018. As of January 31, 2020, there was no material change to the fair value.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-20-000011:notes:90]
[same as prior period, unchanged from 0000936395-19-000040:notes:118]

[0000936395-20-000011:notes:91]
|  | January 31, 2020 |  | October 31, 2019 |
| Raw materials | $ | 106,522 |  |  | $ | 99,041 |  |
| Work-in-process | 11,728 |  |  | 13,657 |  |
| Finished goods | 219,907 |  |  | 226,622 |  |
| Deferred cost of goods sold | 49,256 |  |  | 53,051 |  |
| Gross inventories | 387,413 |  |  | 392,371 |  |
| Provision for excess and obsolescence | (44,740 | ) |  | (47,322 | ) |
| Inventories, net | $ | 342,673 |  |  | $ | 345,049 |  |

[0000936395-20-000011:notes:92]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first three months of fiscal 2020, Ciena recorded a provision for excess and obsolescence of $6.7 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-20-000011:notes:93]
[same as prior period, unchanged from 0000936395-19-000040:notes:121]

[0000936395-20-000011:notes:94]
|  | January 31, 2020 |  | October 31, 2019 |
| Prepaid VAT and other taxes | $ | 87,706 |  |  | $ | 84,706 |  |
| Contract assets for unbilled accounts receivable | 83,717 |  |  | 84,046 |  |
| Prepaid expenses | 65,806 |  |  | 48,680 |  |
| Product demonstration equipment, net | 37,866 |  |  | 38,900 |  |
| Other non-trade receivables | 36,236 |  |  | 28,136 |  |
| Capitalized contract acquisition costs | 9,391 |  |  | 11,677 |  |
| Deferred deployment expense | 318 |  |  | 125 |  |
| Derivative assets | 273 |  |  | 1,570 |  |
| Restricted cash | — |  |  | 74 |  |
|  | $ | 321,313 |  |  | $ | 297,914 |  |

[0000936395-20-000011:notes:95]
Depreciation of product demonstration equipment was $2.2 million during the first three months of each of fiscal 2020 and 2019.

[0000936395-20-000011:notes:96]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 3 above.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-20-000011:notes:97]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-20-000011:notes:98]
|  | January 31, 2020 |  | October 31, 2019 |
| Compensation, payroll related tax and benefits (1) | $ | 68,924 |  |  | $ | 182,363 |  |
| Warranty | 51,190 |  |  | 48,498 |  |
| Vacation | 22,708 |  |  | 22,290 |  |
| Contingent consideration | 3,705 |  |  | 4,372 |  |
| Contingent compensation | 2,880 |  |  | — |  |
| Finance lease obligations | 2,710 |  |  | 2,764 |  |
| Interest payable | 717 |  |  | 1,007 |  |
| Other | 120,471 |  |  | 121,446 |  |
|  | $ | 273,305 |  |  | $ | 382,740 |  |

[0000936395-20-000011:notes:99]
(1) Reduction is primarily due to the timing of bonus payments to employees under our annual cash incentive compensation plan.

[0000936395-20-000011:notes:100]
[same as prior period, unchanged from 0000936395-19-000040:notes:127]

[0000936395-20-000011:notes:101]
| Three Months Ended January 31, |  | Beginning Balance |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| 2019 |  | $ | 44,740 |  |  | 3,891 |  |  | (4,183 | ) |  | $ | 44,448 |  |
| 2020 |  | $ | 48,498 |  |  | 7,898 |  |  | (5,206 | ) |  | $ | 51,190 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-20-000011:notes:102]
[same as prior period, unchanged from 0000936395-19-000040:notes:132]

[0000936395-20-000011:notes:103]
[same as prior period, unchanged from 0000936395-19-000040:notes:133]

[0000936395-20-000011:notes:104]
As of January 31, 2020 and October 31, 2019, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar- and Indian Rupee-denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $180.4 million and $197.4 million as of January 31, 2020 and October 31, 2019, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-20-000011:notes:105]
As of January 31, 2020 and October 31, 2019, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $187.7 million and $206.0 million as of January 31, 2020 and October 31, 2019, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-20-000011:notes:106]
[same as prior period, unchanged from 0000936395-19-000040:notes:136]

[0000936395-20-000011:notes:107]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of January 31, 2020 and October 31, 2019.

[0000936395-20-000011:notes:108]
[same as prior period, unchanged from 0000936395-19-000040:notes:138]

[0000936395-20-000011:notes:109]
[same as prior period, unchanged from 0000936395-19-000040:notes:139]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-20-000011:notes:110]
[same as prior period, unchanged from 0000936395-19-000040:notes:140]

[0000936395-20-000011:notes:111]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 31, 2020:

[0000936395-20-000011:notes:112]
|  | Unrealized Gain/ |  | Unrealized Gain/(Loss) on |  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  | (Loss) on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2019 | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686 | ) |  | $ | (9,475 | ) |  | $ | (22,084 | ) |
| Other comprehensive loss before reclassifications | (86 | ) |  | (921 | ) |  | (1,718 | ) |  | (2,982 | ) |  | (5,707 | ) |
| Amounts reclassified from AOCI | — |  |  | (158 | ) |  | 238 |  |  | — |  |  | 80 |  |
| Balance at January 31, 2020 | $ | 66 |  |  | $ | (154 | ) |  | $ | (15,166 | ) |  | $ | (12,457 | ) |  | $ | (27,711 | ) |

[0000936395-20-000011:notes:113]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 31, 2019:

[0000936395-20-000011:notes:114]
|  | Unrealized |  | Unrealized Losson |  | Unrealized Loss on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2018 | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |
| Other comprehensive income (loss) before reclassifications | 301 |  |  | 402 |  |  | (7,593 | ) |  | 1,150 |  |  | (5,740 | ) |
| Amounts reclassified from AOCI | — |  |  | 1,158 |  |  | (278 | ) |  | — |  |  | 880 |  |
| Balance at January 31, 2019 | $ | (124 | ) |  | $ | (1,500 | ) |  | $ | (1,454 | ) |  | $ | (7,562 | ) |  | $ | (10,640 | ) |

[0000936395-20-000011:notes:115]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-20-000011:notes:116]
LEASES

[0000936395-20-000011:notes:117]
Ciena leases over 1.4 million square feet of facilities globally related to the ongoing operations of its business segments and related functions. Ciena’s principal executive offices are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering and/or service delivery facilities located in San Jose, California; Petaluma, California; Alpharetta, Georgia; Quebec, Canada; Austin, Texas; and Pune and Bangalore, India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 13 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within eight years.

[0000936395-20-000011:notes:118]
As previously disclosed in Note 2, the restructuring reserve liability related to our subleased space and vacated space for which subleases are being pursued was $11.1 million as of October 31, 2019. Upon Ciena’s adoption of ASC 842 on November 1, 2019, the existing Accrued liabilities and other short-term obligations and Other long-term obligations were reclassified as a reduction of the Operating right-of-use assets recorded in accordance with the updated guidance.

[0000936395-20-000011:notes:119]
Leases included in the Condensed Consolidated Balance Sheets were as follows:

[0000936395-20-000011:notes:120]
|  | Classification |  | As of January 31, 2020 |
| Operating leases: |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 50,148 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 71,956 |  |
| Finance leases: |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 71,235 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (14,548 | ) |
| Buildings, net |  |  | $ | 56,687 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 66,831 |  |

[0000936395-20-000011:notes:121]
The components of lease expense included in the Condensed Consolidated Statement of Operations were as follows:

[0000936395-20-000011:notes:122]
|  |  |  | Three months ended |
|  | Classification |  | January 31, 2020 |
| Operating lease costs | Operating expense |  | $ | 4,457 |  |
| Finance lease cost: |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 1,140 |  |
| Interest on finance lease liabilities | Interest expense |  | 1,244 |  |
| Total finance lease cost |  |  | 2,384 |  |
| Non-capitalized lease cost | Operating expense |  | 621 |  |
| Variable lease cost(1) | Operating expense |  | 1,311 |  |
| Net lease cost(2) |  |  | $ | 8,773 |  |

[0000936395-20-000011:notes:123]
(1) Variable lease costs includes expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-20-000011:notes:124]
(2) Excludes other operating expense of $4.3 million for the three months ended January 31, 2020, related to amortization of leasehold improvements.

[0000936395-20-000011:notes:125]
Lease expense (excluding amortization of leasehold improvements of $2.4 million) incurred in the three months ended January 31, 2019 was $6.8 million.

[0000936395-20-000011:notes:126]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of January 31, 2020 were as follows:

[0000936395-20-000011:notes:127]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remaining fiscal 2020 | $ | 15,778 |  |  | $ | 7,512 |  |  | $ | 23,290 |  |
| 2021 | 18,261 |  |  | 7,491 |  |  | 25,752 |  |
| 2022 | 13,440 |  |  | 7,932 |  |  | 21,372 |  |
| 2023 | 10,157 |  |  | 8,008 |  |  | 18,165 |  |
| 2024 | 8,052 |  |  | 8,024 |  |  | 16,076 |  |
| Thereafter | 12,205 |  |  | 64,616 |  |  | 76,821 |  |
| Total lease payments | 77,893 |  |  | 103,583 |  |  | 181,476 |  |
| Less: Imputed interest | (5,937 | ) |  | (36,752 | ) |  | (42,689 | ) |
| Present value of lease liabilities | 71,956 |  |  | 66,831 |  |  | 138,787 |  |
| Less: Current portion of present value of minimum lease payments | (18,623 | ) |  | (2,710 | ) |  | (21,333 | ) |
| Long-term portion of present value of minimum lease payments | $ | 53,333 |  |  | $ | 64,121 |  |  | $ | 117,454 |  |

[0000936395-20-000011:notes:128]
As of January 31, 2020, the weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows:

[0000936395-20-000011:notes:129]
| Weighted-average remaining lease term in years: |  |
| Operating leases | 4.91 |  |
| Finance leases | 12.62 |  |
| Weighted-average discount rates: |  |
| Operating leases | 2.39 | % |
| Finance leases | 7.56 | % |

[0000936395-20-000011:notes:130]
There was no significant non-cash lease activity for the three months ended January 31, 2020.

[0000936395-20-000011:notes:131]
As of October 31, 2019, minimum aggregate rentals under operating leases were as follows:

[0000936395-20-000011:notes:132]
|  |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
| Operating leases (1) |  | $ | 28,776 |  |  | $ | 24,184 |  |  | $ | 16,767 |  |  | $ | 13,393 |  |  | $ | 10,632 |  |  | $ | 26,110 |  |  | $ | 119,862 |  |

[0000936395-20-000011:notes:133]
1) The amount for operating lease commitments above include estimated variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-20-000011:notes:134]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-20-000011:notes:135]
New 2025 Term Loan

[0000936395-20-000011:notes:136]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained an existing senior secured term loan with an outstanding aggregate principal amount of $693.0 million as of January 23, 2020 and maturing on September 28, 2025 (the “Old 2025 Term Loan”).

[0000936395-20-000011:notes:137]
On January 23, 2020, Ciena, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Refinancing Agreement”), pursuant to which Ciena consummated a permitted refinancing of the entire outstanding amount of the Old 2025 Term Loan, and in accordance therewith, incurred new senior secured term loans in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “New 2025 Term Loan”). The proceeds of the New 2025 Term Loan were used in their entirety to

[0000936395-20-000011:notes:138]
refinance the 2025 Term Loan. This arrangement was primarily accounted for as a modification of debt and, as such, $0.1 million of debt issuance costs associated with the New 2025 Term Loan was expensed.

[0000936395-20-000011:notes:139]
The Refinancing Agreement amends the Credit Agreement and provides that the New 2025 Term Loan will, among other things:

[0000936395-20-000011:notes:140]
| • | mature on September 28, 2025; |

[0000936395-20-000011:notes:141]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25%, or $1.73 million, of the principal amount of the New 2025 Term Loan as of January 23, 2020, with the balance payable at maturity; |

[0000936395-20-000011:notes:142]
| • | be subject to mandatory prepayment provisions on the occurrence of certain specified events substantially similar to the 2025 Term Loan, including certain asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement); |

[0000936395-20-000011:notes:143]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%; and |

[0000936395-20-000011:notes:144]
| • | be repayable at any time at Ciena’s election, provided that repayment of the New 2025 Term Loan with proceeds of certain indebtedness prior to July 23, 2020 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment. |

[0000936395-20-000011:notes:145]
Except as amended by the Refinancing Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-20-000011:notes:146]
The net carrying values of Ciena’s term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-20-000011:notes:147]
|  |  | January 31, 2020 |  | October 31, 2019 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 (New) |  | $ | 693,000 |  |  | $ | (1,824 | ) |  | $ | (3,390 | ) |  | $ | 687,786 |  |  | $ | — |  |
| Term Loan Payable due September 28, 2025 (Old) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 687,406 |  |

[0000936395-20-000011:notes:148]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.4 million at January 31, 2020 and $3.6 million at October 31, 2019. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and were $0.2 million during the first three months of fiscal 2020 and fiscal 2019. The carrying value of the term loans listed above is also net of any unamortized debt discounts.

[0000936395-20-000011:notes:149]
As of January 31, 2020, the estimated fair value of the New 2025 Term Loan was $694.7 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-20-000011:notes:150]
EARNINGS PER SHARE CALCULATION
The following tables (in thousands except per share amounts) reconcile basic net income per common share (“Basic EPS”) and diluted net income per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-20-000011:notes:151]
|  | Quarter Ended January 31, |
| Numerator | 2020 |  | 2019 |
| Net income used to calculate Basic and Diluted EPS | $ | 62,328 |  |  | $ | 33,616 |  |

[0000936395-20-000011:notes:152]
|  | Quarter Ended January 31, |
| Denominator | 2020 |  | 2019 |
| Basic weighted average shares outstanding | 154,334 |  |  | 156,314 |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 1,404 |  |  | 1,860 |  |
| Dilutive weighted average shares outstanding | 155,738 |  |  | 158,174 |  |

[0000936395-20-000011:notes:153]
|  | Quarter Ended January 31, |
| EPS | 2020 |  | 2019 |
| Basic EPS | $ | 0.40 |  |  | $ | 0.22 |  |
| Diluted EPS | $ | 0.40 |  |  | $ | 0.21 |  |

[0000936395-20-000011:notes:154]
[same as prior period, unchanged from 0000936395-19-000040:notes:160]

[0000936395-20-000011:notes:155]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Shares underlying stock options and stock unit awards | 731 |  |  | 401 |  |
| Total shares excluded due to anti-dilutive effect | 731 |  |  | 401 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-20-000011:notes:156]
[same as prior period, unchanged from 0000936395-19-000040:notes:162]

[0000936395-20-000011:notes:157]
[same as prior period, unchanged from 0000936395-19-000040:notes:163]

[0000936395-20-000011:notes:158]
[same as prior period, unchanged from 0000936395-19-000040:notes:164]

[0000936395-20-000011:notes:159]
[same as prior period, unchanged from 0000936395-19-000040:notes:165]

[0000936395-20-000011:notes:160]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2019 | 3,838,466 |  |  | $ | 39.10 |  |  | $ | 150,076 |  |
| Repurchase of common stock under the stock repurchase program | 1,288,111 |  |  | 39.36 |  |  | 50,704 |  |
| Cumulative balance at January 31, 2020 | 5,126,577 |  |  | $ | 39.16 |  |  | $ | 200,780 |  |

[0000936395-20-000011:notes:161]
[same as prior period, unchanged from 0000936395-19-000040:notes:167]

[0000936395-20-000011:notes:162]
[same as prior period, unchanged from 0000936395-19-000040:notes:168]

[0000936395-20-000011:notes:163]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $12.6 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2020 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-20-000011:notes:164]
[same as prior period, unchanged from 0000936395-19-000040:notes:170]

[0000936395-20-000011:notes:165]
[same as prior period, unchanged from 0000936395-19-000040:notes:171]

[0000936395-20-000011:notes:166]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Product costs | $ | 671 |  |  | $ | 637 |  |
| Service costs | 842 |  |  | 770 |  |
| Share-based compensation expense included in cost of goods sold | 1,513 |  |  | 1,407 |  |
| Research and development | 3,849 |  |  | 3,391 |  |
| Sales and marketing | 4,613 |  |  | 3,785 |  |
| General and administrative | 5,527 |  |  | 5,112 |  |
| Share-based compensation expense included in operating expense | 13,989 |  |  | 12,288 |  |
| Share-based compensation expense capitalized in inventory, net | 100 |  |  | 60 |  |
| Total share-based compensation | $ | 15,602 |  |  | $ | 13,755 |  |

[0000936395-20-000011:notes:167]
As of January 31, 2020, total unrecognized share-based compensation expense was approximately $141.7 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.7 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-20-000011:notes:168]
[same as prior period, unchanged from 0000936395-19-000040:notes:174]

[0000936395-20-000011:notes:169]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. During fiscal 2019, Ciena separated its previous Software and Software-Related Services segment into two stand-alone operating segments. Because Ciena previously disclosed its Platform Software and Services and Blue Planet Automation Software and Services as distinct product lines in its presentation of segment revenue for Software and Software-Related Services, there is no significant change to the presentation of segment revenues as a result of this separation. Comparative periods have been retrospectively adjusted to disclose segment profit for Platform Software and Services and Blue Planet Automation Software and Services. See Note 3 to Ciena’s Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-20-000011:notes:170]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2020, equipment, building, furniture and fixtures, net, totaled $277.7 million, and operating right of use assets, net totaled $50.1 million, primarily supporting asset groups within Ciena’s Networking Platforms, Platform Software and Services and Blue Planet Automation Software and Services segments and supporting Ciena’s unallocated selling and general and administrative activities. As of January 31, 2020, $17.9 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Networking Platforms segment and $107.7 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Blue Planet Automation Software and Services segment. As of January 31, 2020, $65.7 million, $156.2 million and $89.0 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Networking Platforms, Platform Software and Services and Blue Planet Automation Software and Services segments, respectively. As of January 31, 2020, all of the maintenance spares, net, totaling $54.9 million, were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-20-000011:notes:171]
[same as prior period, unchanged from 0000936395-19-000040:notes:177]

[0000936395-20-000011:notes:172]
The table below sets forth Ciena’s segment revenue for the respective periods (in thousands):

[0000936395-20-000011:notes:173]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Revenue: |  |  |  |
| Networking Platforms |  |  |  |
| Converged Packet Optical | $ | 591,549 |  |  | $ | 548,997 |  |
| Packet Networking | 67,508 |  |  | 71,569 |  |
| Total Networking Platforms | 659,057 |  |  | 620,566 |  |
| Platform Software and Services | 51,888 |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | 15,466 |  |  | 14,974 |  |
| Global Services |  |  |  |
| Maintenance Support and Training | 61,793 |  |  | 61,277 |  |
| Installation and Deployment | 34,954 |  |  | 30,622 |  |
| Consulting and Network Design | 9,754 |  |  | 9,490 |  |
| Total Global Services | 106,501 |  |  | 101,389 |  |
| Consolidated revenue | $ | 832,912 |  |  | $ | 778,527 |  |

[0000936395-20-000011:notes:174]
Segment Profit (Loss)

[0000936395-20-000011:notes:175]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible

[0000936395-20-000011:notes:176]
assets; significant asset impairments and restructuring costs; acquisition and integration costs; interest and other income, net; interest expense; loss on extinguishment and modification of debt and provision for income taxes.

[0000936395-20-000011:notes:177]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income during the respective periods indicated (in thousands):

[0000936395-20-000011:notes:178]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Segment profit (loss): |  |  |  |
| Networking Platforms | $ | 168,270 |  |  | $ | 136,590 |  |
| Platform Software and Services | 28,951 |  |  | 20,464 |  |
| Blue Planet Automation Software and Services | (3,113 | ) |  | (2,047 | ) |
| Global Services | 45,527 |  |  | 39,701 |  |
| Total segment profit | 239,635 |  |  | 194,708 |  |
| Less: Non-performance operating expenses |  |  |  |
| Selling and marketing | 107,066 |  |  | 98,113 |  |
| General and administrative | 42,468 |  |  | 39,243 |  |
| Amortization of intangible assets | 5,853 |  |  | 5,528 |  |
| Significant asset impairments and restructuring costs | 4,472 |  |  | 2,273 |  |
| Acquisition and integration costs | 1,819 |  |  | 1,608 |  |
| Add: Other non-performance financial items |  |  |  |
| Interest expense and other income, net | (5,169 | ) |  | (5,188 | ) |
| Loss on extinguishment and modification of debt | (646 | ) |  | — |  |
| Less: Provision for income taxes | 9,814 |  |  | 9,139 |  |
| Consolidated net income | $ | 62,328 |  |  | $ | 33,616 |  |

[0000936395-20-000011:notes:179]
[same as prior period, unchanged from 0000936395-19-000040:notes:184]

[0000936395-20-000011:notes:180]
Ciena’s operating segments each engage in business across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”); and Asia-Pacific, Japan and India (“APAC”). Americas include activities in North America and South America (previously, Caribbean and Latin America (“CALA”)). The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-20-000011:notes:181]
|  |  | Quarter Ended January 31, |
|  |  | 2020 |  | 2019 |
| Americas |  | $ | 574,004 |  |  | $ | 516,481 |  |
| EMEA |  | 129,965 |  |  | 129,190 |  |
| APAC |  | 128,943 |  |  | 132,856 |  |
| Total |  | $ | 832,912 |  |  | $ | 778,527 |  |

[0000936395-20-000011:notes:182]
Ciena’s revenue includes $524.3 million and $464.1 million of United States revenue for the first quarter of fiscal 2020 and 2019, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-20-000011:notes:183]
[same as prior period, unchanged from 0000936395-19-000040:notes:186]

[0000936395-20-000011:notes:184]
|  | January 31, 2020 |  | October 31, 2019 |
| Canada | $ | 209,101 |  |  | $ | 211,901 |  |
| United States | 51,819 |  |  | 58,119 |  |
| Other International | 16,819 |  |  | 16,864 |  |
| Total | $ | 277,739 |  |  | $ | 286,884 |  |

[0000936395-20-000011:notes:185]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-20-000011:notes:186]
|  | Quarter Ended January 31, |
|  | 2020 |  | 2019 |
| Verizon | $ | 114,548 |  |  | $ | 88,775 |  |
| AT&T | 84,010 |  |  | 94,172 |  |
| Web-scale provider | n/a |  |  | 89,514 |  |
| Total | $ | 198,558 |  |  | $ | 272,461 |  |

[0000936395-20-000011:notes:187]
[same as prior period, unchanged from 0000936395-19-000040:notes:190]

[0000936395-20-000011:notes:188]
The Web-scale provider noted above contributed greater than 10% of total revenue for the first time in fiscal 2019 and purchased products from each of Ciena’s operating segments excluding Blue Planet Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-20-000011:notes:189]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-20-000011:notes:190]
COMMITMENTS AND CONTINGENCIES

[0000936395-20-000011:notes:191]
Canadian Grant

[0000936395-20-000011:notes:192]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.5 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2020, Ciena has recorded CAD$32.5 million (approximately $24.6 million) in cumulative benefits as a reduction in research and development expense of which CAD$3.6 million (approximately $2.7 million) was recorded in the first three months of fiscal 2020. As of January 31, 2020, amounts receivable from this grant were CAD$12.0 million (approximately $9.1 million).

[0000936395-20-000011:notes:193]
Tax Contingencies

[0000936395-20-000011:notes:194]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-20-000011:notes:195]
Litigation

[0000936395-20-000011:notes:196]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-20-000011:notes:197]
SUBSEQUENT EVENTS

[0000936395-20-000011:notes:198]
From the end of the first quarter of fiscal 2020 through March 6, 2020, Ciena repurchased an additional 443,958 shares of its common stock, for an aggregate purchase price of $18.6 million at an average price of $41.90 per share, inclusive of repurchases pending settlement. As of March 6, 2020, Ciena has repurchased an aggregate of 5,570,535 shares and has an aggregate of $280.6 million of authorized funds remaining under its stock repurchase program.
