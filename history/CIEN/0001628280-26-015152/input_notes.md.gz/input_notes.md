# CIEN notes — 0001628280-26-015152


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001628280-26-015152:notes:1]
[same as prior period, unchanged from 0000936395-25-000041:notes:1]

[0001628280-26-015152:notes:2]
[same as prior period, unchanged from 0000936395-25-000041:notes:2]

[0001628280-26-015152:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 1, 2025 was derived from audited financial statements but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 1, 2025 (the “2025 Annual Report”).

[0001628280-26-015152:notes:4]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2026 and Fiscal 2025 are each 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001628280-26-015152:notes:5]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in “Notes to Consolidated Financial Statements” in Item 8 of Part II of the 2025 Annual Report.

[0001628280-26-015152:notes:6]
[same as prior period, unchanged from 0000936395-25-000041:notes:5]

[0001628280-26-015152:notes:7]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures to decision makers. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, and will result in changes to certain income tax disclosures including substantially more information on a disaggregated basis, but it does not affect recognition or measurement of income taxes and therefore is not expected to have a material effect on our consolidated financial statements. The amendments are applied on a prospective basis; however, retrospective application is permitted.

[0001628280-26-015152:notes:8]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-015152:notes:9]
In July 2025, the FASB issued ASU No. 2025-05 (“ASU 2025-05”), Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, to introduce a practical expedient for all entities, which simplifies the calculation required for estimating credit losses and assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. ASU 2025-05 is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods; however, early adoption is permitted. ASU 2025-25 allows for adoption using a prospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-015152:notes:10]
In September 2025, the FASB issued ASU No. 2025-06 (“ASU 2025-06”), Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) to modernize the accounting for software costs that are accounted for under Subtopic 350-40 by shifting away from prescriptive and sequential software development stages to an incremental and iterative method when capitalizing software costs. ASU 2025-06 is effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0001628280-26-015152:notes:11]
In December 2025, the FASB issued ASU No. 2025-11 (“ASU 2025-11”), Interim Reporting (Topic 270): Narrow-Scope Improvements, to improve the navigability of required interim disclosures, clarify when that guidance applies, and provide additional guidance on what disclosures should be provided in interim reporting periods. ASU 2025-11 is effective for interim reporting periods with annual reporting periods beginning after December 15, 2027, early adoption is permitted. ASU 2025-11 allows for adoption using the prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its interim financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001628280-26-015152:notes:12]
[same as prior period, unchanged from 0000936395-25-000041:notes:10]

[0001628280-26-015152:notes:13]
[same as prior period, unchanged from 0000936395-25-000041:notes:11]

[0001628280-26-015152:notes:14]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

[0001628280-26-015152:notes:15]
|  | Quarter Ended January 31, 2026 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,023,162 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,023,162 |  |
| Routing and Switching | 126,006 |  |  | — |  |  | — |  |  | — |  |  | 126,006 |  |
| Platform Software and Services | — |  |  | 93,384 |  |  | — |  |  | — |  |  | 93,384 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,420 |  |  | — |  |  | 20,420 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 87,551 |  |  | 87,551 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 67,949 |  |  | 67,949 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 8,570 |  |  | 8,570 |  |
| Total revenue by product line | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,149,168 |  |  | $ | 29,183 |  |  | $ | 1,894 |  |  | $ | 16,887 |  |  | $ | 1,197,132 |  |
| Products and services transferred over time | — |  |  | 64,201 |  |  | 18,526 |  |  | 147,183 |  |  | 229,910 |  |
| Total revenue by timing of revenue recognition | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |

[0001628280-26-015152:notes:16]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Products and services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

[0001628280-26-015152:notes:17]
[same as prior period, unchanged from 0000936395-25-000041:notes:17]

[0001628280-26-015152:notes:18]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products. These products are often combined and sold as solutions that address network applications including cloud and AI networking, datacenter interconnect, long haul, metro, submarine connectivity, and managed optical fiber networks (MOFN).

[0001628280-26-015152:notes:19]
•Routing and Switching - includes the 3000 family of service delivery platforms and 5000 family of service aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and other routing and switching portfolio products. Ciena also uses certain of these products to create its out-of-band data center management (DCOM) solutions.

[0001628280-26-015152:notes:20]
[same as prior period, unchanged from 0000936395-25-000041:notes:20]

[0001628280-26-015152:notes:21]
[same as prior period, unchanged from 0000936395-25-000041:notes:21]

[0001628280-26-015152:notes:22]
[same as prior period, unchanged from 0000936395-25-000041:notes:22]

[0001628280-26-015152:notes:23]
•Platform Services - includes subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

[0001628280-26-015152:notes:24]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portion of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0001628280-26-015152:notes:25]
[same as prior period, unchanged from 0000936395-25-000041:notes:25]

[0001628280-26-015152:notes:26]
[same as prior period, unchanged from 0000936395-25-000041:notes:26]

[0001628280-26-015152:notes:27]
•Blue Planet Services - includes subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.

[0001628280-26-015152:notes:28]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from the services portion of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0001628280-26-015152:notes:29]
•Global Services revenue reflects sales of a broad range of Ciena’s services for advisory and enablement, implementation, and maintenance, support, and learning activities.

[0001628280-26-015152:notes:30]
[same as prior period, unchanged from 0000936395-25-000041:notes:30]

[0001628280-26-015152:notes:31]
[same as prior period, unchanged from 0000936395-25-000041:notes:31]

[0001628280-26-015152:notes:32]
[same as prior period, unchanged from 0000936395-25-000041:notes:32]

[0001628280-26-015152:notes:33]
[same as prior period, unchanged from 0000936395-25-000041:notes:33]

[0001628280-26-015152:notes:34]
[same as prior period, unchanged from 0000936395-25-000041:notes:34]

[0001628280-26-015152:notes:35]
•Revenue from professional services for customization, consulting, and design services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0001628280-26-015152:notes:36]
•Revenue from maintenance and support is recognized ratably over the period during which the services are performed.

[0001628280-26-015152:notes:37]
•Revenue from implementation services and advisory and enablement services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0001628280-26-015152:notes:38]
•Revenue from learning services is generally recognized at a point in time upon completion of the service.

[0001628280-26-015152:notes:39]
For additional information on Ciena’s revenue recognition policy, see “Notes to Consolidated Financial Statements” in Item 8 of Part II of the 2025 Annual Report.

[0001628280-26-015152:notes:40]
[same as prior period, unchanged from 0000936395-25-000041:notes:40]

[0001628280-26-015152:notes:41]
Ciena reports its sales geographically in the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0001628280-26-015152:notes:42]
[same as prior period, unchanged from 0000936395-25-000041:notes:42]

[0001628280-26-015152:notes:43]
|  |  | Quarter Ended |  |  |
|  |  | January 31, |  | February 1, |  |  |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,118,223 |  |  | $ | 795,632 |  |  |  |  |  |
| EMEA |  | 200,587 |  |  | 157,916 |  |  |  |  |  |
| APAC |  | 108,232 |  |  | 118,712 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  |  |

[0001628280-26-015152:notes:44]
Ciena’s revenue includes $1.08 billion and $752.5 million from the United States for the first quarter of fiscal 2026 and 2025, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0001628280-26-015152:notes:45]
For the periods indicated, the only customers that accounted for 10% or more of total revenue were as follows (in thousands):

[0001628280-26-015152:notes:46]
|  | Quarter Ended |
|  | January 31, |  | February 1, |
|  | 2026 |  | 2025 |
| Cloud provider A | $ | 330,981 |  |  | $ | 168,896 |  |
| Cloud provider B | 160,206 |  |  | n/a* |
| Service provider A | 185,804 |  |  | n/a* |
| Service provider B | n/a* |  | 111,024 |  |
| Total | $ | 676,991 |  |  | $ | 279,920 |  |

[0001628280-26-015152:notes:47]
*Denotes revenue representing less than 10% of total revenue for the indicated period

[0001628280-26-015152:notes:48]
Service provider A purchased products from each of Ciena’s operating segments for the periods presented. The other 10% customers included in the table above purchased products from Ciena’s Networking Platforms, Platform Software and Services, and Global Services operating segments for each of the periods presented.

[0001628280-26-015152:notes:49]
[same as prior period, unchanged from 0000936395-25-000041:notes:46]

[0001628280-26-015152:notes:50]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0001628280-26-015152:notes:51]
|  |  | Balance at |  | Balance at |
|  |  | January 31, 2026 |  | November 01, 2025 |
| Accounts receivable, net |  | $ | 967,408 |  |  | $ | 975,856 |  |
| Long-term accounts receivable |  | $ | 27,359 |  |  | $ | 28,610 |  |
| Deferred revenue |  | $ | 390,873 |  |  | $ | 303,786 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 146,208 |  |  | $ | 157,868 |  |

[0001628280-26-015152:notes:52]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to implementation and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets.

[0001628280-26-015152:notes:53]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $88.2 million and $74.5 million of revenue during the first three months of fiscal 2026 and 2025, respectively, that was included in the deferred revenue balance at November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 31, 2026 and February 1, 2025.

[0001628280-26-015152:notes:54]
[same as prior period, unchanged from 0000936395-25-000041:notes:51]

[0001628280-26-015152:notes:55]
|  | January 31,2026 |  | November 1,2025 |
| Products | $ | 97,509 |  |  | $ | 65,382 |  |
| Services | 293,364 |  |  | 238,404 |  |
| Total deferred revenue | 390,873 |  |  | 303,786 |  |
| Less current portion | (290,418) |  |  | (208,936) |  |
| Long-term deferred revenue | $ | 100,455 |  |  | $ | 94,850 |  |

[0001628280-26-015152:notes:56]
[same as prior period, unchanged from 0000936395-25-000041:notes:53]

[0001628280-26-015152:notes:57]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $32.9 million and $37.4 million as of January 31, 2026 and November 1, 2025, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $10.8 million and $8.5 million during the first three months of fiscal 2026 and 2025, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0001628280-26-015152:notes:58]
[same as prior period, unchanged from 0000936395-25-000041:notes:55]

[0001628280-26-015152:notes:59]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2026, the aggregate amount of RPO was $2.3 billion. As of January 31, 2026, Ciena expects approximately 85% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001628280-26-015152:notes:60]
[same as prior period, unchanged from 0000936395-25-000041:notes:57]

[0001628280-26-015152:notes:61]
Ciena regularly monitors its spending to optimize operating expenses and to ensure that its strategic investments are aligned with its highest-growth demand opportunities. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the three months ended January 31, 2026 (in thousands):

[0001628280-26-015152:notes:62]
|  | Workforce restructuring |  | Other restructuring activities |  | Total |
| Balance at November 1, 2025 | $ | 8,436 |  |  | $ | — |  |  | $ | 8,436 |  |
| Charges | 1,010 |  |  | 488 |  | (1) | 1,498 |  |
| Cash payments | (7,840) |  |  | (488) |  |  | (8,328) |  |
| Balance at January 31, 2026 | $ | 1,606 |  |  | $ | — |  |  | $ | 1,606 |  |
| Current restructuring liabilities | $ | 1,606 |  |  | $ | — |  |  | $ | 1,606 |  |

[0001628280-26-015152:notes:63]
[same as prior period, unchanged from 0000936395-25-000041:notes:60]

[0001628280-26-015152:notes:64]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the three months ended February 1, 2025 (in thousands):

[0001628280-26-015152:notes:65]
|  | Workforce restructuring |  | Other restructuring activities |  | Total |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Charges | 278 |  |  | 1,266 |  | (1) | 1,544 |  |
| Cash payments | (1,762) |  |  | (1,266) |  |  | (3,028) |  |
| Balance at February 1, 2025 | $ | 443 |  |  | $ | — |  |  | $ | 443 |  |
| Current restructuring liabilities | $ | 443 |  |  | $ | — |  |  | $ | 443 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0001628280-26-015152:notes:66]
[same as prior period, unchanged from 0000936395-25-000041:notes:65]

[0001628280-26-015152:notes:67]
|  | Quarter Ended |  |  |
|  | January 31, |  | February 1, |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Interest income | $ | 14,391 |  |  | $ | 13,710 |  |  |  |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts (1) | 942 |  |  | (2,873) |  |  |  |  |  |
| Foreign currency exchange gains (losses) (2) | (4,644) |  |  | 1,240 |  |  |  |  |  |
| Other | 2,268 |  |  | (499) |  |  |  |  |  |
| Interest and other income, net | $ | 12,957 |  |  | $ | 11,578 |  |  |  |  |  |

[0001628280-26-015152:notes:68]
[same as prior period, unchanged from 0000936395-25-000041:notes:67]

[0001628280-26-015152:notes:69]
[same as prior period, unchanged from 0000936395-25-000041:notes:68]


## us-gaap:IncomeTaxDisclosureTextBlock

[0001628280-26-015152:notes:70]
INCOME TAXES
The effective tax rate for the first quarter of fiscal 2026 was lower than the effective tax rate for the first quarter of fiscal 2025. The decrease was primarily due to an income tax benefit for share-based compensation expense and change in mix of earnings in jurisdictions with lower tax rates.

[0001628280-26-015152:notes:71]
The Organization for Economic Co-operation and Development (OECD) has introduced a framework to implement a global minimum tax of 15% for certain highly profitable multinational companies, referred to as Pillar Two or the minimum tax directive. While the Unites States has not enacted legislation to adopt Pillar Two, certain countries in which Ciena operates have enacted legislation and many aspects of Pillar Two were effective for Ciena beginning in fiscal 2025. Pillar Two taxes are considered an alternative minimum tax accounted for as a period cost that could impact the effective tax rate in the year the Pillar Two tax obligation arises. Therefore, deferred taxes will not be recognized for the estimated effects of future minimum taxes. Pillar Two does not have a material effect on Ciena’s effective tax rate, financial results or cash flows for fiscal 2026. 
On July 4, 2025, the One Big Beautiful Bill Act (the “OBBBA”) was enacted into law in the United States. The OBBBA includes provisions, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions such as bonus depreciation and expensing of domestic research and experimental expenditures. The legislation has multiple effective dates, with certain provisions taking effect in fiscal 2025 and fiscal 2026 and others to be implemented through fiscal 2027. Ciena expects future cash tax savings, but does not expect a material impact on its future effective tax rate. The legislation will not have a material impact on Ciena’s consolidated financial statements in fiscal 2026.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001628280-26-015152:notes:72]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0001628280-26-015152:notes:73]
|  | January 31, 2026 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 119,105 |  |  | $ | 244 |  |  | $ | — |  |  | $ | 119,349 |  |
| Corporate debt securities | 123,152 |  |  | 273 |  |  | — |  |  | 123,425 |  |
| Time deposits | 81,920 |  |  | 5 |  |  | — |  |  | 81,925 |  |
|  | $ | 324,177 |  |  | $ | 522 |  |  | $ | — |  |  | $ | 324,699 |  |
| Included in cash equivalents | $ | 78,508 |  |  | $ | — |  |  | $ | — |  |  | $ | 78,508 |  |
| Included in short-term investments | 175,988 |  |  | 327 |  |  | — |  |  | 176,315 |  |
| Included in long-term investments | 69,681 |  |  | 195 |  |  | — |  |  | 69,876 |  |
|  | $ | 324,177 |  |  | $ | 522 |  |  | $ | — |  |  | $ | 324,699 |  |

[0001628280-26-015152:notes:74]
|  | November 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 147,466 |  |  | $ | 304 |  |  | $ | — |  |  | $ | 147,770 |  |
| Corporate debt securities | 119,808 |  |  | 260 |  |  | — |  |  | 120,068 |  |
| Time deposits | 74,984 |  |  | 6 |  |  | — |  |  | 74,990 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |
| Included in cash equivalents | $ | 69,538 |  |  | $ | — |  |  | $ | — |  |  | $ | 69,538 |  |
| Included in short-term investments | 215,786 |  |  | 362 |  |  | — |  |  | 216,148 |  |
| Included in long-term investments | 56,934 |  |  | 208 |  |  | — |  |  | 57,142 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |

[0001628280-26-015152:notes:75]
The following table summarizes the legal maturities of debt investments as of January 31, 2026 (in thousands):

[0001628280-26-015152:notes:76]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 254,496 |  |  | $ | 254,823 |  |
| Due in 1-2 years | 69,681 |  |  | 69,876 |  |
|  | $ | 324,177 |  |  | $ | 324,699 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0001628280-26-015152:notes:77]
FAIR VALUE MEASUREMENTS
    As of the dates indicated, the following tables summarize the assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0001628280-26-015152:notes:78]
|  | January 31, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 665,777 |  |  | $ | — |  |  | $ | — |  |  | $ | 665,777 |  |
| Bond mutual fund | 119,119 |  |  | — |  |  | — |  |  | 119,119 |  |
| Time deposits | 81,925 |  |  | — |  |  | — |  |  | 81,925 |  |
| Deferred compensation plan assets | 24,823 |  |  | — |  |  | — |  |  | 24,823 |  |
| U.S. government obligations | — |  |  | 119,349 |  |  | — |  |  | 119,349 |  |
| Corporate debt securities | — |  |  | 123,425 |  |  | — |  |  | 123,425 |  |
| Foreign currency forward contracts | — |  |  | 9,888 |  |  | — |  |  | 9,888 |  |
| Interest rate swaps | — |  |  | 435 |  |  | — |  |  | 435 |  |
| Total assets measured at fair value | $ | 891,644 |  |  | $ | 253,097 |  |  | $ | — |  |  | $ | 1,144,741 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 5,060 |  |  | $ | — |  |  | $ | 5,060 |  |
| Interest rate swaps | — |  |  | 1,054 |  |  | — |  |  | 1,054 |  |
| Deferred compensation plan liabilities | 24,812 |  |  | — |  |  | — |  |  | 24,812 |  |
| Total liabilities measured at fair value | $ | 24,812 |  |  | $ | 6,114 |  |  | $ | — |  |  | $ | 30,926 |  |

[0001628280-26-015152:notes:79]
|  | November 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 713,707 |  |  | $ | — |  |  | $ | — |  |  | $ | 713,707 |  |
| Bond mutual fund | 117,931 |  |  | — |  |  | — |  |  | 117,931 |  |
| Time deposits | 74,990 |  |  | — |  |  | — |  |  | 74,990 |  |
| Deferred compensation plan assets | 21,179 |  |  | — |  |  | — |  |  | 21,179 |  |
| U.S. government obligations | — |  |  | 147,770 |  |  | — |  |  | 147,770 |  |
| Corporate debt securities | — |  |  | 120,068 |  |  | — |  |  | 120,068 |  |
| Foreign currency forward contracts | — |  |  | 3,236 |  |  | — |  |  | 3,236 |  |
| Total assets measured at fair value | $ | 927,807 |  |  | $ | 271,074 |  |  | $ | — |  |  | $ | 1,198,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 6,314 |  |  | $ | — |  |  | $ | 6,314 |  |
| Forward starting interest rate swaps | — |  |  | 1,345 |  |  | — |  |  | 1,345 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,659 |  |  | $ | — |  |  | $ | 7,659 |  |

[0001628280-26-015152:notes:80]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Condensed Consolidated Balance Sheets as follows (in thousands):

[0001628280-26-015152:notes:81]
|  | January 31, 2026 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 862,052 |  |  | $ | 1,352 |  |  | $ | — |  |  | $ | 863,404 |  |
| Short-term investments | 4,769 |  |  | 171,546 |  |  | — |  |  | 176,315 |  |
| Prepaid expenses and other | — |  |  | 9,888 |  |  | — |  |  | 9,888 |  |
| Long-term investments | — |  |  | 69,876 |  |  | — |  |  | 69,876 |  |
| Other long-term assets | 24,823 |  |  | 435 |  |  | — |  |  | 25,258 |  |
| Total assets measured at fair value | $ | 891,644 |  |  | $ | 253,097 |  |  | $ | — |  |  | $ | 1,144,741 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 5,060 |  |  | $ | — |  |  | $ | 5,060 |  |
| Other long-term obligations | 24,812 |  |  | 1,054 |  |  | — |  |  | 25,866 |  |
| Total liabilities measured at fair value | $ | 24,812 |  |  | $ | 6,114 |  |  | $ | — |  |  | $ | 30,926 |  |

[0001628280-26-015152:notes:82]
|  | November 1, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 901,077 |  |  | $ | 99 |  |  | $ | — |  |  | $ | 901,176 |  |
| Short-term investments | 5,551 |  |  | 210,597 |  |  | — |  |  | 216,148 |  |
| Prepaid expenses and other | — |  |  | 3,236 |  |  | — |  |  | 3,236 |  |
| Long-term investments | — |  |  | 57,142 |  |  | — |  |  | 57,142 |  |
| Other long-term assets | 21,179 |  |  | — |  |  | — |  |  | 21,179 |  |
| Total assets measured at fair value | $ | 927,807 |  |  | $ | 271,074 |  |  | $ | — |  |  | $ | 1,198,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 6,314 |  |  | $ | — |  |  | $ | 6,314 |  |
| Other long-term obligations | — |  |  | 1,345 |  |  | — |  |  | 1,345 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,659 |  |  | $ | — |  |  | $ | 7,659 |  |

[0001628280-26-015152:notes:83]
[same as prior period, unchanged from 0000936395-25-000041:notes:83]


## us-gaap:InventoryDisclosureTextBlock

[0001628280-26-015152:notes:84]
[same as prior period, unchanged from 0000936395-25-000041:notes:84]

[0001628280-26-015152:notes:85]
|  | January 31,2026 |  | November 1,2025 |
| Raw materials | $ | 596,008 |  |  | $ | 593,783 |  |
| Work-in-process | 33,998 |  |  | 35,051 |  |
| Finished goods | 318,547 |  |  | 286,050 |  |
| Deferred cost of goods sold | 43,213 |  |  | 40,759 |  |
| Gross inventories | 991,766 |  |  | 955,643 |  |
| Reserve for inventory excess and obsolescence | (145,943) |  |  | (129,408) |  |
| Inventories, net | $ | 845,823 |  |  | $ | 826,235 |  |

[0001628280-26-015152:notes:86]
During the first three months of fiscal 2026, Ciena recorded a provision for inventory excess and obsolescence of $21.8 million, primarily related to a decrease in the forecasted demand for certain products. Deductions from the reserve for excess and obsolete inventory relate primarily to sales and disposal activities.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0001628280-26-015152:notes:87]
OTHER BALANCE SHEET DETAILS

[0001628280-26-015152:notes:88]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0001628280-26-015152:notes:89]
|  | January 31,2026 |  | November 1,2025 |
| Compensation, payroll related tax and benefits (1) | $ | 152,223 |  |  | $ | 281,542 |  |
| Warranty | 58,084 |  |  | 55,533 |  |
| Vacation | 33,176 |  |  | 33,708 |  |
| Interest payable | 9,833 |  |  | 6,101 |  |
| Income taxes payable | 8,529 |  |  | 10,729 |  |
| Foreign currency forward contracts | 5,059 |  |  | 6,314 |  |
| Finance lease liabilities | 4,968 |  |  | 4,741 |  |
| Other | 124,009 |  |  | 132,413 |  |
|  | $ | 395,881 |  |  | $ | 531,081 |  |

[0001628280-26-015152:notes:90]
(1) Reduction is primarily due to the timing of payments related to incentive compensation.

[0001628280-26-015152:notes:91]
The following table summarizes the activity in Ciena’s accrued warranty for the periods indicated (in thousands):

[0001628280-26-015152:notes:92]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Three Months Ended February 1, 2025 |  | $ | 55,267 |  |  |  |  | 5,697 |  |  | (5,495) |  |  | $ | 55,469 |  |
| Three Months Ended January 31, 2026 |  | $ | 55,533 |  |  |  |  | 8,185 |  |  | (5,634) |  |  | $ | 58,084 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001628280-26-015152:notes:93]
[same as prior period, unchanged from 0000936395-25-000041:notes:87]

[0001628280-26-015152:notes:94]
Ciena conducts business globally and is exposed to foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0001628280-26-015152:notes:95]
As of January 31, 2026 and November 1, 2025, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $455.2 million and $431.4 million as of January 31, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0001628280-26-015152:notes:96]
As of January 31, 2026 and November 1, 2025, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $60.0 million and $62.0 million as of January 31, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0001628280-26-015152:notes:97]
As of January 31, 2026 and November 1, 2025, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $48.0 million and $175.7 million as of January 31, 2026 and November 1, 2025, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0001628280-26-015152:notes:98]
[same as prior period, unchanged from 0000936395-25-000041:notes:92]

[0001628280-26-015152:notes:99]
[same as prior period, unchanged from 0000936395-25-000041:notes:93]

[0001628280-26-015152:notes:100]
In January 2023, Ciena entered into interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of such swaps in effect was $350.0 million as of January 31, 2026 and November 1, 2025.

[0001628280-26-015152:notes:101]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028. The total notional amount of such swaps in effect was $350.0 million as of January 31, 2026 and November 1, 2025.

[0001628280-26-015152:notes:102]
[same as prior period, unchanged from 0000936395-25-000041:notes:97]

[0001628280-26-015152:notes:103]
[same as prior period, unchanged from 0000936395-25-000041:notes:98]


## us-gaap:DebtDisclosureTextBlock

[0001628280-26-015152:notes:104]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0001628280-26-015152:notes:105]
Refinanced 2030 Term Loan

[0001628280-26-015152:notes:106]
On January 17, 2025, Ciena entered into a Refinancing Amendment to its Credit Agreement under which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The Refinanced 2030 Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.6 million annually, with the remaining balance payable at maturity.

[0001628280-26-015152:notes:107]
The net carrying value of Ciena’s term loan was comprised of the following as of the date indicated (in thousands):

[0001628280-26-015152:notes:108]
|  |  | January 31, 2026 |  | November 1, 2025 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,146,720 |  |  | $ | (3,375) |  |  | $ | (4,313) |  |  | $ | 1,139,032 |  |  | $ | 1,138,619 |  |

[0001628280-26-015152:notes:109]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during both the first three months of fiscal 2026 and fiscal 2025.

[0001628280-26-015152:notes:110]
As of January 31, 2026, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0001628280-26-015152:notes:111]
Outstanding Senior Notes Payable

[0001628280-26-015152:notes:112]
2030 Notes

[0001628280-26-015152:notes:113]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0001628280-26-015152:notes:114]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0001628280-26-015152:notes:115]
|  |  | January 31, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,708) |  |  | $ | 397,292 |  |  | $ | 397,119 |  |  |  |

[0001628280-26-015152:notes:116]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first three months of fiscal 2026 and fiscal 2025.

[0001628280-26-015152:notes:117]
As of January 31, 2026, the estimated fair value of the 2030 Notes was $384.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0001628280-26-015152:notes:118]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 31, 2026 (in thousands):

[0001628280-26-015152:notes:119]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 1, 2025 | $ | 422 |  |  | $ | (3,803) |  |  |  |  | $ | (1,054) |  |  | $ | (50,600) |  |  | $ | (55,035) |  |
| Other comprehensive gain (loss) before reclassifications | (37) |  |  | 5,733 |  |  |  |  | 1,511 |  |  | 10,165 |  |  | 17,372 |  |
| Amounts reclassified from AOCI | — |  |  | (105) |  |  |  |  | (955) |  |  | — |  |  | (1,060) |  |
| Balance at January 31, 2026 | $ | 385 |  |  | $ | 1,825 |  |  |  |  | $ | (498) |  |  | $ | (40,435) |  |  | $ | (38,723) |  |

[0001628280-26-015152:notes:120]
The following table summarizes the changes in AOCI, net of tax, for the three months ended February 1, 2025 (in thousands):

[0001628280-26-015152:notes:121]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 2, 2024 | $ | 798 |  |  | $ | (4,880) |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications | (345) |  |  | (6,841) |  |  | 4,377 |  |  | (17,702) |  |  | (20,511) |  |
| Amounts reclassified from AOCI | — |  |  | 2,357 |  |  | (2,424) |  |  | — |  |  | (67) |  |
| Balance at February 1, 2025 | $ | 453 |  |  | $ | (9,364) |  |  | $ | 10,621 |  |  | $ | (68,999) |  |  | $ | (67,289) |  |

[0001628280-26-015152:notes:122]
[same as prior period, unchanged from 0000936395-25-000041:notes:129]


## us-gaap:EarningsPerShareTextBlock

[0001628280-26-015152:notes:123]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following unless the impact of the item is anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0001628280-26-015152:notes:124]
The following table presents the calculation of Basic and Diluted EPS for the periods indicated (in thousands, except per share amounts):

[0001628280-26-015152:notes:125]
|  | Quarter Ended |  |  |
|  | January 31, |  | February 1, |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Net income | $ | 150,283 |  |  | $ | 44,572 |  |  |  |  |  |
| Basic weighted average shares outstanding | 141,676 |  |  | 142,880 |  |  |  |  |  |
| Effect of dilutive potential common shares | 4,123 |  |  | 3,064 |  |  |  |  |  |
| Diluted weighted average shares outstanding | 145,799 |  |  | 145,944 |  |  |  |  |  |
| Basic EPS | $ | 1.06 |  |  | $ | 0.31 |  |  |  |  |  |
| Diluted EPS | $ | 1.03 |  |  | $ | 0.31 |  |  |  |  |  |
| Anti-dilutive stock unit awards, excluded | 22 |  |  | 989 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001628280-26-015152:notes:126]
[same as prior period, unchanged from 0000936395-25-000041:notes:133]

[0001628280-26-015152:notes:127]
[same as prior period, unchanged from 0000936395-25-000041:notes:134]

[0001628280-26-015152:notes:128]
During the first three months of fiscal 2026, Ciena repurchased approximately 0.4 million shares of its common stock for an aggregate purchase price of approximately $80.5 million, which equates to an average price of $216.43 per share. As of January 31, 2026, Ciena has (i) repurchased 4.3 million shares for an aggregate purchase price of $410.2 million at an average price of $94.83 per share and (ii) has an aggregate of $589.8 million authorized and remaining under its stock repurchase program. Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0001628280-26-015152:notes:129]
Stock Repurchases Related to Stock Unit Tax Withholdings

[0001628280-26-015152:notes:130]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $90.1 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2026 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001628280-26-015152:notes:131]
[same as prior period, unchanged from 0000936395-25-000041:notes:138]

[0001628280-26-015152:notes:132]
|  | Quarter Ended |  |  |
|  | January 31, |  | February 1, |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Products | $ | 1,822 |  |  | $ | 1,750 |  |  |  |  |  |
| Services | 4,025 |  |  | 3,405 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 5,847 |  |  | 5,155 |  |  |  |  |  |
| Research and development | 16,594 |  |  | 14,237 |  |  |  |  |  |
| Selling and marketing | 14,754 |  |  | 11,597 |  |  |  |  |  |
| General and administrative | 12,632 |  |  | 9,827 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 43,980 |  |  | 35,661 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net (1) | — |  |  | (10) |  |  |  |  |  |
| Total share-based compensation expense | $ | 49,827 |  |  | $ | 40,806 |  |  |  |  |  |

[0001628280-26-015152:notes:133]
(1) Effective the beginning of fiscal 2026, Ciena will no longer be calculating share-based compensation capitalized in inventory due to immateriality.

[0001628280-26-015152:notes:134]
As of January 31, 2026, total unrecognized share-based compensation expense was $443.7 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001628280-26-015152:notes:135]
SEGMENTS AND ENTITY-WIDE DISCLOSURES
Operating segments are defined as components of an enterprise that engage in business activities that earn revenue and incur expense for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker (“CODM”) for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Ciena’s CODM is its Chief Executive Officer, Gary Smith, who evaluates Ciena’s performance and allocates resources based on segment profit (loss) as compared to annual targets for these four operating segments.

[0001628280-26-015152:notes:136]
[same as prior period, unchanged from 0000936395-25-000041:notes:143]

[0001628280-26-015152:notes:137]
The table below sets forth Ciena’s segment profit (loss) and the reconciliations to consolidated net income for the respective periods indicated (in thousands). The CODM excludes the following items in his assessment of performance of the operating segments: selling and marketing costs; general and administrative costs, significant asset impairments and restructuring costs; share-based compensations expense, amortization of intangible assets; acquisition and integration costs; interest and other income, net; interest expense; loss on extinguishment and modification of debt; and provision for income taxes.

[0001628280-26-015152:notes:138]
|  | Quarter Ended |  |  |
|  | January 31, |  | February 1, |  |  |  |  |
|  | 2026 |  | 2025 |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 1,149,168 |  |  | $ | 821,142 |  |  |  |  |  |
| Platform Software and Services | 93,384 |  |  | 95,067 |  |  |  |  |  |
| Blue Planet Automation Software and Services | 20,420 |  |  | 26,032 |  |  |  |  |  |
| Global Services | 164,070 |  |  | 130,019 |  |  |  |  |  |
| Total revenue | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  |  |
| Segment gross profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 491,681 |  |  | $ | 334,982 |  |  |  |  |  |
| Platform Software and Services | 80,979 |  |  | 81,753 |  |  |  |  |  |
| Blue Planet Automation Software and Services | 5,577 |  |  | 14,789 |  |  |  |  |  |
| Global Services | 59,916 |  |  | 47,682 |  |  |  |  |  |
| Total segment gross profit | $ | 638,153 |  |  | $ | 479,206 |  |  |  |  |  |
| Research and development expense: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 175,050 |  |  | $ | 152,820 |  |  |  |  |  |
| Platform Software and Services | 19,261 |  |  | 16,330 |  |  |  |  |  |
| Blue Planet Automation Software and Services | 9,391 |  |  | 8,289 |  |  |  |  |  |
| Global Services | 1,162 |  |  | 985 |  |  |  |  |  |
| Total segment research and development expense | $ | 204,864 |  |  | $ | 178,424 |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 316,631 |  |  | $ | 182,162 |  |  |  |  |  |
| Platform Software and Services | 61,718 |  |  | 65,423 |  |  |  |  |  |
| Blue Planet Automation Software and Services | (3,814) |  |  | 6,500 |  |  |  |  |  |
| Global Services | 58,754 |  |  | 46,697 |  |  |  |  |  |
| Total segment profit | $ | 433,289 |  |  | $ | 300,782 |  |  |  |  |  |
| Less: Unallocated cost of goods sold | $ | 12,633 |  |  | $ | 7,385 |  |  |  |  |  |
| Less: Unallocated operating and non-operating expenses | 270,373 |  |  | 248,825 |  |  |  |  |  |
| Consolidated net income | $ | 150,283 |  |  | $ | 44,572 |  |  |  |  |  |

[0001628280-26-015152:notes:139]
[same as prior period, unchanged from 0000936395-25-000041:notes:147]

[0001628280-26-015152:notes:140]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets, goodwill, and maintenance spares, are not reviewed by Ciena's CODM for purposes of evaluating performance and allocating resources. As of January 31, 2026, equipment, building, furniture and fixtures, net, totaled $437.8 million, and operating ROU assets totaled $40.5 million, both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. The following table shows Ciena’s finite-lived intangible assets, goodwill, and maintenance spares allocated by segment and reconciled to total assets (in thousands):

[0001628280-26-015152:notes:141]
|  | January 31, 2026 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 212,689 |  |  | — |  |  | — |  |  | — |  |  | $ | 212,689 |  |
| Goodwill | $ | 276,472 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 521,712 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 96,973 |  |  | $ | 96,973 |  |
| Total assets assigned to segments |  |  |  |  |  |  |  |  | $ | 831,374 |  |
| Other unallocated assets |  |  |  |  |  |  |  |  | 5,060,985 |  |
| Total assets |  |  |  |  |  |  |  |  | $ | 5,892,359 |  |

[0001628280-26-015152:notes:142]
|  | November 1, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 224,210 |  |  | — |  |  | — |  |  | — |  |  | $ | 224,210 |  |
| Goodwill | $ | 275,964 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 521,204 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 92,392 |  |  | $ | 92,392 |  |
| Total assets assigned to segments |  |  |  |  |  |  |  |  | $ | 837,806 |  |
| Other unallocated assets |  |  |  |  |  |  |  |  | 5,026,861 |  |
| Total assets |  |  |  |  |  |  |  |  | $ | 5,864,667 |  |

[0001628280-26-015152:notes:143]
The following table shows Ciena’s geographic distribution of equipment, building, furniture and fixtures, net and operating ROU assets (in thousands):

[0001628280-26-015152:notes:144]
|  | January 31,2026 |  | November 1,2025 |
| Canada | $ | 379,882 |  |  | $ | 325,584 |  |
| United States | 41,042 |  |  | 44,634 |  |
| Other International (1) | 57,398 |  |  | 55,174 |  |
| Total | $ | 478,322 |  |  | $ | 425,392 |  |

[0001628280-26-015152:notes:145]
(1) Any country representing less than 10% of total is reflected in aggregate as “Other International.”


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001628280-26-015152:notes:146]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0001628280-26-015152:notes:147]
Ciena is subject to various tax contingencies arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these contingencies will have a material effect on its financial position or cash flows.

[0001628280-26-015152:notes:148]
Litigation

[0001628280-26-015152:notes:149]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property

[0001628280-26-015152:notes:150]
related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0001628280-26-015152:notes:151]
Purchase Order Obligations 
Ciena has certain advanced orders for supply of certain long lead time components. As of January 31, 2026, Ciena had $1.9 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust a portion of these orders.


## us-gaap:SubsequentEventsTextBlock

[0001628280-26-015152:notes:152]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0001628280-26-015152:notes:153]
From the end of the first quarter of fiscal 2026 through February 27, 2026, Ciena repurchased 83,510 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $300.29 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of February 27, 2026, Ciena has an aggregate of $564.7 million of authorized funds remaining under this repurchase program.

[0001628280-26-015152:notes:154]
U.S. Supreme Court Ruling on Tariffs

[0001628280-26-015152:notes:155]
On February 20, 2026, the U.S. Supreme Court ruled that a portion of the tariffs that Ciena has been subject to were invalid. Following this ruling, the U.S. Administration issued an executive order imposing a new global tariff. The ruling and the subsequent response by the U.S. Administration leave open a number of complex questions regarding the timing, mechanics and administration of tariff refunds by the U.S. government, if any. Ciena is evaluating the impact these events may have, if any, on its consolidated financial statements and related disclosures.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001628280-26-015152:notes:156]
The following table describes, for the first quarter of fiscal 2026, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0001628280-26-015152:notes:157]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Brodie Gage(Senior Vice President, Global Products & Supply Chain) | Modification (December 23, 2025) (1) | Rule 10b5-1 trading arrangement | Sales | Until December 31, 2026, or such earlier date upon which all transactions are completed or expire without execution (2) | Up to 15,800 shares of common stock (3) |

[0001628280-26-015152:notes:158]
(1)     On December 23, 2025, Mr. Gage modified the Rule 10b5-1 trading arrangement (as modified, the “Gage Modified Arrangement”) that he adopted on July 1, 2025 (the “Gage Original Arrangement”).

[0001628280-26-015152:notes:159]
(2)    The Gage Modified Arrangement changed the trading schedule and awards sold but not the duration of the arrangement. Sales under the Gage Modified Arrangement will not begin until March 24, 2026.
(3)    The aggregate number of shares of common stock to be sold pursuant to the Gage Original Arrangement was up to 7,150 shares of common stock.
