# CIEN note change history — 0000936395-25-000041 → 0001628280-26-015152


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:1]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property
  (was, 2025-09-04, similarity 0.6301):
[0000936395-25-000041:note_history:1]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

- added (2026-03-05):
[0001628280-26-015152:note_history:2]
related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

- added (2026-03-05):
[0001628280-26-015152:note_history:3]
Purchase Order Obligations 
Ciena has certain advanced orders for supply of certain long lead time components. As of January 31, 2026, Ciena had $1.9 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust a portion of these orders.

- removed (2026-03-05):
[0000936395-25-000041:note_history:4]
Purchase Obligations

- removed (2026-03-05):
[0000936395-25-000041:note_history:5]
Ciena has certain advanced commitments for supply of certain long lead time components. As of August 2, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:6]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 1, 2025 was derived from audited financial statements but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 1, 2025 (the “2025 Annual Report”).
  (was, 2025-09-04, similarity 0.8885):
[0000936395-25-000041:note_history:6]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.

- added (2026-03-05):
[0001628280-26-015152:note_history:7]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2026 and Fiscal 2025 are each 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:8]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in “Notes to Consolidated Financial Statements” in Item 8 of Part II of the 2025 Annual Report.
  (was, 2025-09-04, similarity 0.8689):
[0000936395-25-000041:note_history:8]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

- added (2026-03-05):
[0001628280-26-015152:note_history:9]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures to decision makers. ASU 2023-09 is effective for annual periods beginning after December 15, 2024, and will result in changes to certain income tax disclosures including substantially more information on a disaggregated basis, but it does not affect recognition or measurement of income taxes and therefore is not expected to have a material effect on our consolidated financial statements. The amendments are applied on a prospective basis; however, retrospective application is permitted.

- added (2026-03-05):
[0001628280-26-015152:note_history:10]
In September 2025, the FASB issued ASU No. 2025-06 (“ASU 2025-06”), Intangibles - Goodwill and Other - Internal-Use Software (Subtopic 350-40) to modernize the accounting for software costs that are accounted for under Subtopic 350-40 by shifting away from prescriptive and sequential software development stages to an incremental and iterative method when capitalizing software costs. ASU 2025-06 is effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- added (2026-03-05):
[0001628280-26-015152:note_history:11]
In December 2025, the FASB issued ASU No. 2025-11 (“ASU 2025-11”), Interim Reporting (Topic 270): Narrow-Scope Improvements, to improve the navigability of required interim disclosures, clarify when that guidance applies, and provide additional guidance on what disclosures should be provided in interim reporting periods. ASU 2025-11 is effective for interim reporting periods with annual reporting periods beginning after December 15, 2027, early adoption is permitted. ASU 2025-11 allows for adoption using the prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its interim financial statements and related disclosures.

- removed (2026-03-05):
[0000936395-25-000041:note_history:12]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

- removed (2026-03-05):
[0000936395-25-000041:note_history:13]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-03-05):
[0001628280-26-015152:note_history:14]
On January 17, 2025, Ciena entered into a Refinancing Amendment to its Credit Agreement under which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The Refinanced 2030 Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.6 million annually, with the remaining balance payable at maturity.

- changed (2026-03-05):
[0001628280-26-015152:note_history:15]
The net carrying value of Ciena’s term loan was comprised of the following as of the date indicated (in thousands):
  (was, 2025-09-04, similarity 0.9576):
[0000936395-25-000041:note_history:15]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):

- changed (2026-03-05):
[0001628280-26-015152:note_history:16]
|  |  | January 31, 2026 |  | November 1, 2025 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,146,720 |  |  | $ | (3,375) |  |  | $ | (4,313) |  |  | $ | 1,139,032 |  |  | $ | 1,138,619 |  |
  (was, 2025-09-04, similarity 0.8319):
[0000936395-25-000041:note_history:16]
|  |  | August 2, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,149,615 |  |  | $ | (3,738) |  |  | $ | (4,776) |  |  | $ | 1,141,101 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:17]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during both the first three months of fiscal 2026 and fiscal 2025.
  (was, 2025-09-04, similarity 0.9472):
[0000936395-25-000041:note_history:17]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.7 million during both the first nine months of fiscal 2025 and fiscal 2024.

- changed (2026-03-05):
[0001628280-26-015152:note_history:18]
As of January 31, 2026, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-09-04, similarity 0.9803):
[0000936395-25-000041:note_history:18]
As of August 2, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2026-03-05):
[0001628280-26-015152:note_history:19]
|  |  | January 31, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,708) |  |  | $ | 397,292 |  |  | $ | 397,119 |  |  |  |
  (was, 2025-09-04, similarity 0.9697):
[0000936395-25-000041:note_history:19]
|  |  | August 2, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,054) |  |  | $ | 396,946 |  |  | $ | 396,427 |  |  |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:20]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first three months of fiscal 2026 and fiscal 2025.
  (was, 2025-09-04, similarity 0.8531):
[0000936395-25-000041:note_history:20]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.5 million during both the first nine months of fiscal 2025 and fiscal 2024.

- changed (2026-03-05):
[0001628280-26-015152:note_history:21]
As of January 31, 2026, the estimated fair value of the 2030 Notes was $384.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-09-04, similarity 0.9789):
[0000936395-25-000041:note_history:21]
As of August 2, 2025, the estimated fair value of the 2030 Notes was $376.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2026-03-05):
[0000936395-25-000041:note_history:22]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained a senior secured term loan with an outstanding aggregate principal amount, as of January 17, 2025, of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

- removed (2026-03-05):
[0000936395-25-000041:note_history:23]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing

- removed (2026-03-05):
[0000936395-25-000041:note_history:24]
Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

- removed (2026-03-05):
[0000936395-25-000041:note_history:25]
•mature on October 24, 2030;

- removed (2026-03-05):
[0000936395-25-000041:note_history:26]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date, with the balance payable at maturity;

- removed (2026-03-05):
[0000936395-25-000041:note_history:27]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

- removed (2026-03-05):
[0000936395-25-000041:note_history:28]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

- removed (2026-03-05):
[0000936395-25-000041:note_history:29]
•be repayable at any time at Ciena’s election; and

- removed (2026-03-05):
[0000936395-25-000041:note_history:30]
•except as described above or otherwise set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

- removed (2026-03-05):
[0000936395-25-000041:note_history:31]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-03-05):
[0001628280-26-015152:note_history:32]
|  | January 31, 2026 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 119,105 |  |  | $ | 244 |  |  | $ | — |  |  | $ | 119,349 |  |
| Corporate debt securities | 123,152 |  |  | 273 |  |  | — |  |  | 123,425 |  |
| Time deposits | 81,920 |  |  | 5 |  |  | — |  |  | 81,925 |  |
|  | $ | 324,177 |  |  | $ | 522 |  |  | $ | — |  |  | $ | 324,699 |  |
| Included in cash equivalents | $ | 78,508 |  |  | $ | — |  |  | $ | — |  |  | $ | 78,508 |  |
| Included in short-term investments | 175,988 |  |  | 327 |  |  | — |  |  | 176,315 |  |
| Included in long-term investments | 69,681 |  |  | 195 |  |  | — |  |  | 69,876 |  |
|  | $ | 324,177 |  |  | $ | 522 |  |  | $ | — |  |  | $ | 324,699 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:33]
|  | November 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 147,466 |  |  | $ | 304 |  |  | $ | — |  |  | $ | 147,770 |  |
| Corporate debt securities | 119,808 |  |  | 260 |  |  | — |  |  | 120,068 |  |
| Time deposits | 74,984 |  |  | 6 |  |  | — |  |  | 74,990 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |
| Included in cash equivalents | $ | 69,538 |  |  | $ | — |  |  | $ | — |  |  | $ | 69,538 |  |
| Included in short-term investments | 215,786 |  |  | 362 |  |  | — |  |  | 216,148 |  |
| Included in long-term investments | 56,934 |  |  | 208 |  |  | — |  |  | 57,142 |  |
|  | $ | 342,258 |  |  | $ | 570 |  |  | $ | — |  |  | $ | 342,828 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:34]
The following table summarizes the legal maturities of debt investments as of January 31, 2026 (in thousands):
  (was, 2025-09-04, similarity 0.9302):
[0000936395-25-000041:note_history:34]
The following table summarizes the final legal maturities of debt investments as of August 2, 2025 (in thousands):

- removed (2026-03-05):
[0000936395-25-000041:note_history:35]
|  | August 2, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 208,174 |  |  | $ | 297 |  |  | $ | (3) |  |  | $ | 208,468 |  |
| Corporate debt securities | 120,919 |  |  | 207 |  |  | — |  |  | 121,126 |  |
| Time deposits | 92,547 |  |  | 2 |  |  | — |  |  | 92,549 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |
| Included in cash equivalents | $ | 87,366 |  |  | $ | — |  |  | $ | — |  |  | $ | 87,366 |  |
| Included in short-term investments | 270,085 |  |  | 298 |  |  | (3) |  |  | 270,380 |  |
| Included in long-term investments | 64,189 |  |  | 208 |  |  | — |  |  | 64,397 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:36]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:37]
The net carrying value of Ciena’s term loan was comprised of the following as of the date indicated (in thousands):
  (was, 2025-09-04, similarity 0.9576):
[0000936395-25-000041:note_history:37]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):

- changed (2026-03-05):
[0001628280-26-015152:note_history:38]
|  |  | January 31, 2026 |  | November 1, 2025 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,146,720 |  |  | $ | (3,375) |  |  | $ | (4,313) |  |  | $ | 1,139,032 |  |  | $ | 1,138,619 |  |
  (was, 2025-09-04, similarity 0.8319):
[0000936395-25-000041:note_history:38]
|  |  | August 2, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,149,615 |  |  | $ | (3,738) |  |  | $ | (4,776) |  |  | $ | 1,141,101 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:39]
|  |  | January 31, 2026 |  | November 1, 2025 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (2,708) |  |  | $ | 397,292 |  |  | $ | 397,119 |  |  |  |
  (was, 2025-09-04, similarity 0.9697):
[0000936395-25-000041:note_history:39]
|  |  | August 2, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,054) |  |  | $ | 396,946 |  |  | $ | 396,427 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:40]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2025-09-04, similarity 0.8934):
[0000936395-25-000041:note_history:40]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- added (2026-03-05):
[0001628280-26-015152:note_history:41]
|  | Quarter Ended January 31, 2026 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,023,162 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,023,162 |  |
| Routing and Switching | 126,006 |  |  | — |  |  | — |  |  | — |  |  | 126,006 |  |
| Platform Software and Services | — |  |  | 93,384 |  |  | — |  |  | — |  |  | 93,384 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,420 |  |  | — |  |  | 20,420 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 87,551 |  |  | 87,551 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 67,949 |  |  | 67,949 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 8,570 |  |  | 8,570 |  |
| Total revenue by product line | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,149,168 |  |  | $ | 29,183 |  |  | $ | 1,894 |  |  | $ | 16,887 |  |  | $ | 1,197,132 |  |
| Products and services transferred over time | — |  |  | 64,201 |  |  | 18,526 |  |  | 147,183 |  |  | 229,910 |  |
| Total revenue by timing of revenue recognition | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:42]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Products and services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:43]
|  |  | Quarter Ended |  |  |
|  |  | January 31, |  | February 1, |  |  |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,118,223 |  |  | $ | 795,632 |  |  |  |  |  |
| EMEA |  | 200,587 |  |  | 157,916 |  |  |  |  |  |
| APAC |  | 108,232 |  |  | 118,712 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  |  |
  (was, 2025-09-04, similarity 0.762):
[0000936395-25-000041:note_history:43]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 923,627 |  |  | $ | 718,605 |  |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |
| EMEA |  | 186,018 |  |  | 135,009 |  |  | 535,519 |  |  | 498,212 |  |
| APAC |  | 109,740 |  |  | 88,694 |  |  | 328,923 |  |  | 292,951 |  |
| Total revenue by geographic distribution |  | $ | 1,219,385 |  |  | $ | 942,308 |  |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:44]
For the periods indicated, the only customers that accounted for 10% or more of total revenue were as follows (in thousands):

- added (2026-03-05):
[0001628280-26-015152:note_history:45]
|  | Quarter Ended |
|  | January 31, |  | February 1, |
|  | 2026 |  | 2025 |
| Cloud provider A | $ | 330,981 |  |  | $ | 168,896 |  |
| Cloud provider B | 160,206 |  |  | n/a* |
| Service provider A | 185,804 |  |  | n/a* |
| Service provider B | n/a* |  | 111,024 |  |
| Total | $ | 676,991 |  |  | $ | 279,920 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:46]
*Denotes revenue representing less than 10% of total revenue for the indicated period

- removed (2026-03-05):
[0000936395-25-000041:note_history:47]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:48]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:49]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:50]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:51]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2025-09-04, similarity 0.8934):
[0000936395-25-000041:note_history:51]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- added (2026-03-05):
[0001628280-26-015152:note_history:52]
|  | Quarter Ended January 31, 2026 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,023,162 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,023,162 |  |
| Routing and Switching | 126,006 |  |  | — |  |  | — |  |  | — |  |  | 126,006 |  |
| Platform Software and Services | — |  |  | 93,384 |  |  | — |  |  | — |  |  | 93,384 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,420 |  |  | — |  |  | 20,420 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 87,551 |  |  | 87,551 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 67,949 |  |  | 67,949 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 8,570 |  |  | 8,570 |  |
| Total revenue by product line | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,149,168 |  |  | $ | 29,183 |  |  | $ | 1,894 |  |  | $ | 16,887 |  |  | $ | 1,197,132 |  |
| Products and services transferred over time | — |  |  | 64,201 |  |  | 18,526 |  |  | 147,183 |  |  | 229,910 |  |
| Total revenue by timing of revenue recognition | $ | 1,149,168 |  |  | $ | 93,384 |  |  | $ | 20,420 |  |  | $ | 164,070 |  |  | $ | 1,427,042 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:53]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance, Support, and Learning | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Implementation | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Advisory and Enablement | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Products and services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:54]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products. These products are often combined and sold as solutions that address network applications including cloud and AI networking, datacenter interconnect, long haul, metro, submarine connectivity, and managed optical fiber networks (MOFN).
  (was, 2025-09-04, similarity 0.6264):
[0000936395-25-000041:note_history:54]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® system, the 6500 Reconfigurable Line System (RLS), coherent pluggable transceivers, and other optical networking products.

- added (2026-03-05):
[0001628280-26-015152:note_history:55]
•Routing and Switching - includes the 3000 family of service delivery platforms and 5000 family of service aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and other routing and switching portfolio products. Ciena also uses certain of these products to create its out-of-band data center management (DCOM) solutions.

- changed (2026-03-05):
[0001628280-26-015152:note_history:56]
•Platform Services - includes subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.
  (was, 2025-09-04, similarity 0.9814):
[0000936395-25-000041:note_history:56]
•Platform Services - includes sales of subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

- changed (2026-03-05):
[0001628280-26-015152:note_history:57]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portion of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2025-09-04, similarity 0.9982):
[0000936395-25-000041:note_history:57]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2026-03-05):
[0001628280-26-015152:note_history:58]
•Blue Planet Services - includes subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.
  (was, 2025-09-04, similarity 0.9705):
[0000936395-25-000041:note_history:58]
•Blue Planet Services - includes sales of subscription, installation, support, consulting and design services related to the Blue Planet Automation Platform.

- changed (2026-03-05):
[0001628280-26-015152:note_history:59]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from the services portion of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2025-09-04, similarity 0.9982):
[0000936395-25-000041:note_history:59]
Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from the services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2026-03-05):
[0001628280-26-015152:note_history:60]
•Global Services revenue reflects sales of a broad range of Ciena’s services for advisory and enablement, implementation, and maintenance, support, and learning activities.
  (was, 2025-09-04, similarity 0.6759):
[0000936395-25-000041:note_history:60]
•Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities.

- changed (2026-03-05):
[0001628280-26-015152:note_history:61]
•Revenue from professional services for customization, consulting, and design services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2025-09-04, similarity 0.6733):
[0000936395-25-000041:note_history:61]
•Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Global Services are considered a distinct performance obligation where revenue is generally recognized over time.

- changed (2026-03-05):
[0001628280-26-015152:note_history:62]
•Revenue from maintenance and support is recognized ratably over the period during which the services are performed.
  (was, 2025-09-04, similarity 0.9825):
[0000936395-25-000041:note_history:62]
•Revenue from maintenance support is recognized ratably over the period during which the services are performed.

- added (2026-03-05):
[0001628280-26-015152:note_history:63]
•Revenue from implementation services and advisory and enablement services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2026-03-05):
[0001628280-26-015152:note_history:64]
•Revenue from learning services is generally recognized at a point in time upon completion of the service.
  (was, 2025-09-04, similarity 0.9717):
[0000936395-25-000041:note_history:64]
•Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2026-03-05):
[0001628280-26-015152:note_history:65]
For additional information on Ciena’s revenue recognition policy, see “Notes to Consolidated Financial Statements” in Item 8 of Part II of the 2025 Annual Report.
  (was, 2025-09-04, similarity 0.9937):
[0000936395-25-000041:note_history:65]
For additional information on Ciena’s revenue recognition policy, see Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

- changed (2026-03-05):
[0001628280-26-015152:note_history:66]
Ciena reports its sales geographically in the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2025-09-04, similarity 0.9867):
[0000936395-25-000041:note_history:66]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2026-03-05):
[0001628280-26-015152:note_history:67]
|  |  | Quarter Ended |  |  |
|  |  | January 31, |  | February 1, |  |  |  |  |
|  |  | 2026 |  | 2025 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,118,223 |  |  | $ | 795,632 |  |  |  |  |  |
| EMEA |  | 200,587 |  |  | 157,916 |  |  |  |  |  |
| APAC |  | 108,232 |  |  | 118,712 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  |  |
  (was, 2025-09-04, similarity 0.762):
[0000936395-25-000041:note_history:67]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 923,627 |  |  | $ | 718,605 |  |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |
| EMEA |  | 186,018 |  |  | 135,009 |  |  | 535,519 |  |  | 498,212 |  |
| APAC |  | 109,740 |  |  | 88,694 |  |  | 328,923 |  |  | 292,951 |  |
| Total revenue by geographic distribution |  | $ | 1,219,385 |  |  | $ | 942,308 |  |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:68]
Ciena’s revenue includes $1.08 billion and $752.5 million from the United States for the first quarter of fiscal 2026 and 2025, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- added (2026-03-05):
[0001628280-26-015152:note_history:69]
For the periods indicated, the only customers that accounted for 10% or more of total revenue were as follows (in thousands):

- added (2026-03-05):
[0001628280-26-015152:note_history:70]
|  | Quarter Ended |
|  | January 31, |  | February 1, |
|  | 2026 |  | 2025 |
| Cloud provider A | $ | 330,981 |  |  | $ | 168,896 |  |
| Cloud provider B | 160,206 |  |  | n/a* |
| Service provider A | 185,804 |  |  | n/a* |
| Service provider B | n/a* |  | 111,024 |  |
| Total | $ | 676,991 |  |  | $ | 279,920 |  |

- added (2026-03-05):
[0001628280-26-015152:note_history:71]
*Denotes revenue representing less than 10% of total revenue for the indicated period

- added (2026-03-05):
[0001628280-26-015152:note_history:72]
Service provider A purchased products from each of Ciena’s operating segments for the periods presented. The other 10% customers included in the table above purchased products from Ciena’s Networking Platforms, Platform Software and Services, and Global Services operating segments for each of the periods presented.

- changed (2026-03-05):
[0001628280-26-015152:note_history:73]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):
  (was, 2025-09-04, similarity 0.9244):
[0000936395-25-000041:note_history:73]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

- added (2026-03-05):
[0001628280-26-015152:note_history:74]
|  |  | Balance at |  | Balance at |
|  |  | January 31, 2026 |  | November 01, 2025 |
| Accounts receivable, net |  | $ | 967,408 |  |  | $ | 975,856 |  |
| Long-term accounts receivable |  | $ | 27,359 |  |  | $ | 28,610 |  |
| Deferred revenue |  | $ | 390,873 |  |  | $ | 303,786 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 146,208 |  |  | $ | 157,868 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:75]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to implementation and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets.
  (was, 2025-09-04, similarity 0.958):
[0000936395-25-000041:note_history:75]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

- changed (2026-03-05):
[0001628280-26-015152:note_history:76]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $88.2 million and $74.5 million of revenue during the first three months of fiscal 2026 and 2025, respectively, that was included in the deferred revenue balance at November 1, 2025 and November 2, 2024, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 31, 2026 and February 1, 2025.
  (was, 2025-09-04, similarity 0.9217):
[0000936395-25-000041:note_history:76]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $134.6 million and $130.5 million of revenue during the first nine months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 2, 2025 and July 27, 2024.

- changed (2026-03-05):
[0001628280-26-015152:note_history:77]
|  | January 31,2026 |  | November 1,2025 |
| Products | $ | 97,509 |  |  | $ | 65,382 |  |
| Services | 293,364 |  |  | 238,404 |  |
| Total deferred revenue | 390,873 |  |  | 303,786 |  |
| Less current portion | (290,418) |  |  | (208,936) |  |
| Long-term deferred revenue | $ | 100,455 |  |  | $ | 94,850 |  |
  (was, 2025-09-04, similarity 0.9759):
[0000936395-25-000041:note_history:77]
|  | August 2,2025 |  | November 2,2024 |
| Products | $ | 33,476 |  |  | $ | 19,017 |  |
| Services | 243,790 |  |  | 218,602 |  |
| Total deferred revenue | 277,266 |  |  | 237,619 |  |
| Less current portion | (196,209) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 81,057 |  |  | $ | 81,240 |  |

- changed (2026-03-05):
[0001628280-26-015152:note_history:78]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $32.9 million and $37.4 million as of January 31, 2026 and November 1, 2025, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $10.8 million and $8.5 million during the first three months of fiscal 2026 and 2025, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2025-09-04, similarity 0.9395):
[0000936395-25-000041:note_history:78]
Capitalized contract acquisition costs consist of deferred sales commissions and were $33.4 million and $28.4 million as of August 2, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $22.9 million during the first nine months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- added (2026-03-05):
[0001628280-26-015152:note_history:79]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2026, the aggregate amount of RPO was $2.3 billion. As of January 31, 2026, Ciena expects approximately 85% of the RPO to be recognized as revenue within the next 12 months.

- removed (2026-03-05):
[0000936395-25-000041:note_history:80]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:81]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:82]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:83]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:84]
•Routing and Switching - includes the 3000 and 5000 series of service delivery and aggregation platforms, the 8100 Coherent IP networking platforms, virtualization software, and passive optical network and other routing and switching portfolio products.

- removed (2026-03-05):
[0000936395-25-000041:note_history:85]
•Revenue from installation and deployment services and consulting and network design services is generally recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- removed (2026-03-05):
[0000936395-25-000041:note_history:86]
Ciena’s revenue includes $882.8 million and $676.0 million of U.S. revenue for the third quarter of fiscal 2025 and 2024, respectively. For the nine months ended August 2, 2025 and July 27, 2024, U.S. revenue was $2.4 billion and $2.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- removed (2026-03-05):
[0000936395-25-000041:note_history:87]
Ciena’s revenue from a cloud provider includes $218.0 million and $538.2 million for the third quarter and nine months ended August 2, 2025, respectively, and $137.2 million and $331.6 million for the third quarter and nine months ended July 27, 2024, respectively. Revenue also includes $133.0 million and $361.4 million from AT&T for the third quarter and nine months ended August 2, 2025, respectively, and $113.1 million and $324.8 million for the third quarter and nine months ended July 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

- removed (2026-03-05):
[0000936395-25-000041:note_history:88]
|  |  | Balance at August 2, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 1,025,563 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 164,326 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 277,266 |  |  | $ | 237,619 |  |

- removed (2026-03-05):
[0000936395-25-000041:note_history:89]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of August 2, 2025, the aggregate amount of RPO was $2.0 billion. As of August 2, 2025, Ciena expects approximately 82% of the RPO balance to be recognized as revenue within the next 12 months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2026-03-05):
[0001628280-26-015152:note_history:90]
From the end of the first quarter of fiscal 2026 through February 27, 2026, Ciena repurchased 83,510 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $300.29 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of February 27, 2026, Ciena has an aggregate of $564.7 million of authorized funds remaining under this repurchase program.
  (was, 2025-09-04, similarity 0.9524):
[0000936395-25-000041:note_history:90]
From the end of the third quarter of fiscal 2025 through August 29, 2025, Ciena repurchased 286,619 shares of its common stock for an aggregate purchase price of $26.4 million at an average price of $92.10 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of August 29, 2025, Ciena has an aggregate of $728.4 million of authorized funds remaining under this repurchase program.

- added (2026-03-05):
[0001628280-26-015152:note_history:91]
U.S. Supreme Court Ruling on Tariffs

- added (2026-03-05):
[0001628280-26-015152:note_history:92]
On February 20, 2026, the U.S. Supreme Court ruled that a portion of the tariffs that Ciena has been subject to were invalid. Following this ruling, the U.S. Administration issued an executive order imposing a new global tariff. The ruling and the subsequent response by the U.S. Administration leave open a number of complex questions regarding the timing, mechanics and administration of tariff refunds by the U.S. government, if any. Ciena is evaluating the impact these events may have, if any, on its consolidated financial statements and related disclosures.

- removed (2026-03-05):
[0000936395-25-000041:note_history:93]
Reallocation of Innovation Investment and Fiscal 2025 Restructuring Plan

- removed (2026-03-05):
[0000936395-25-000041:note_history:94]
On August 26, 2025, in order to align Ciena’s strategic investments with our highest-growth demand opportunities, its executive team determined to cease forward investment in certain broadband development initiatives, primarily 25G PON, within the routing and switching product line of the Network Platforms operating segment. Ciena intends to continue support and development of its 10G PON-based products.

- removed (2026-03-05):
[0000936395-25-000041:note_history:95]
Ciena’s executive team also approved a restructuring plan intended to deliver increased operating efficiencies and, as a result, commencing during the fourth quarter of fiscal 2025, Ciena is implementing a workforce reduction of approximately 4%

- removed (2026-03-05):
[0000936395-25-000041:note_history:96]
to 5% of its global headcount, which includes employees associated with the broadband development initiatives discussed above. 
The estimated cash cost related to these actions is approximately $20.0 million and represents employee severance and related costs. As such, we expect an expense of approximately $20.0 million to be incurred in the fourth quarter of fiscal 2025. In addition, Ciena anticipates that its decision to cease future investment in 25G PON will result in a non-cash charge in the fourth quarter of fiscal 2025 related to the abandonment of its in-process R&D intangible asset, which has a carrying value of $89.1 million as of August 2, 2025. During the fourth quarter of fiscal 2025, Ciena will also evaluate the impact of these actions on other assets including, but not limited to, inventory and fixed assets.
