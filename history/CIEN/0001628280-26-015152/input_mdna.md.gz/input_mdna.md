# CIEN MD&A — 0001628280-26-015152


## mdna

[0001628280-26-015152:mdna:1]
[same as prior period, unchanged from 0000936395-25-000041:mdna:1]

[0001628280-26-015152:mdna:2]
[same as prior period, unchanged from 0000936395-25-000041:mdna:2]

[0001628280-26-015152:mdna:3]
[same as prior period, unchanged from 0000936395-25-000041:mdna:3]

[0001628280-26-015152:mdna:4]
Reform Act of 1995. Unless the context requires otherwise, references in this report to “Ciena,” the “Company,” “we,” “us,” and “our” refer to Ciena Corporation and its consolidated subsidiaries.

[0001628280-26-015152:mdna:5]
[same as prior period, unchanged from 0000936395-25-000041:mdna:4]

[0001628280-26-015152:mdna:6]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, voice, video, data, and artificial intelligence (“AI”). Our network solutions are used globally by cloud providers, service providers, and other network operators across multiple industry verticals.

[0001628280-26-015152:mdna:7]
The markets into which we sell are dynamic and characterized by a high rate of change. Networks continue to experience strong demand for increased bandwidth due to traffic growth, which is being driven by a diverse set of services, technologies, and customer needs.

[0001628280-26-015152:mdna:8]
[same as prior period, unchanged from 0000936395-25-000041:mdna:10]

[0001628280-26-015152:mdna:9]
Our industry has been experiencing unprecedented increases in demand, in particular due to capital expenditures related to AI and other cloud-based applications. As a result, we experienced strong momentum and growth in fiscal 2025 that continued in the first quarter of fiscal 2026. As we grow disproportionately with cloud providers, we are seeing a small number of those customers become a larger portion of our business across multiple revenue segments. Our revenue increased by 33.1% to $1.4 billion in the first quarter of fiscal 2026 as compared to $1.1 billion in the first quarter of fiscal 2025, with orders for our products and services significantly exceeding our revenue. This dynamic, together with an industry-wide constrained supply environment, has resulted in historically high backlog.

[0001628280-26-015152:mdna:10]
Gross Margin Dynamics

[0001628280-26-015152:mdna:11]
Our gross margin decreased to 43.8% in the first quarter of fiscal 2026, compared to 44.0% in the first quarter of fiscal 2025, primarily due to lower services gross margin.

[0001628280-26-015152:mdna:12]
Operating Expense and Investment in Technology Innovation

[0001628280-26-015152:mdna:13]
Our operating expense grew from $391.2 million in the first quarter of fiscal 2025 to $436.1 million in the first quarter of fiscal 2026. During the first quarter of fiscal 2026, we invested $221.5 million in research and development activities, an increase of 15% compared to the first quarter of fiscal 2025. We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets, which requires considerable investment capacity and expenditures. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we continued to increase the performance of, and enhance the capabilities for our leading WaveLogicTM coherent modem technology, through which we seek to extend our leadership in optical networking, and leverage it to expand our addressable market, including inside and around the data center.

[0001628280-26-015152:mdna:14]
Capital Allocation Strategy

[0001628280-26-015152:mdna:15]
Our capital allocation strategy is focused on maintaining our significant innovation investment, investing in select transactions, and returning value to stockholders, while preserving our strategic and operational flexibility. We continuously work to improve our cash cycle and evaluate alternatives to manage our capital structure in order to enhance our liquidity. We ended the first quarter of fiscal 2026 with $1.4 billion of cash, cash equivalents, and investments. As of the end of the first quarter of fiscal 2026, cash generated from operations increased to $227.6 million as compared to $103.7 million as of the end of the first quarter of fiscal 2025. Consistent with our capital allocation priorities, during the first quarter of fiscal 2026, we invested $73.9 million in capital purchases, primarily for supply chain equipment and research and development , and $170.6 million to repurchase shares through our share buyback program and for tax withholding purposes associated with employee stock awards.

[0001628280-26-015152:mdna:16]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2025 Annual Report.

[0001628280-26-015152:mdna:17]
[same as prior period, unchanged from 0000936395-25-000041:mdna:18]

[0001628280-26-015152:mdna:18]
[same as prior period, unchanged from 0000936395-25-000041:mdna:19]

[0001628280-26-015152:mdna:19]
Our results of operations are presented based on our operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0001628280-26-015152:mdna:20]
[same as prior period, unchanged from 0000936395-25-000041:mdna:21]

[0001628280-26-015152:mdna:21]
As a result of the increased demand described above, our revenue increased by 33.1%, or $354.8 million, in the first quarter of fiscal 2026 as compared to the first quarter of fiscal 2025.

[0001628280-26-015152:mdna:22]
[same as prior period, unchanged from 0000936395-25-000041:mdna:23]

[0001628280-26-015152:mdna:23]
[same as prior period, unchanged from 0000936395-25-000041:mdna:24]

[0001628280-26-015152:mdna:24]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,023,162 |  |  | $ | 727,973 |  |  |  |  | 40.5 | % |  |  |  |  |  |  |  |  |
| %** | 71.7 | % |  | 67.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Routing and Switching | 126,006 |  |  | 93,169 |  |  |  |  | 35.2 | % |  |  |  |  |  |  |  |  |
| %** | 8.8 | % |  | 8.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Networking Platforms | 1,149,168 |  |  | 821,142 |  |  |  |  | 39.9 | % |  |  |  |  |  |  |  |  |
| %** | 80.5 | % |  | 76.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 93,384 |  |  | 95,067 |  |  |  |  | (1.8) | % |  |  |  |  |  |  |  |  |
| %** | 6.5 | % |  | 8.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | 20,420 |  |  | 26,032 |  |  |  |  | (21.6) | % |  |  |  |  |  |  |  |  |
| %** | 1.5 | % |  | 2.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning | 87,551 |  |  | 74,573 |  |  |  |  | 17.4 | % |  |  |  |  |  |  |  |  |
| %** | 6.1 | % |  | 7.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Implementation | 67,949 |  |  | 47,682 |  |  |  |  | 42.5 | % |  |  |  |  |  |  |  |  |
| %** | 4.8 | % |  | 4.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Advisory and Enablement | 8,570 |  |  | 7,764 |  |  |  |  | 10.4 | % |  |  |  |  |  |  |  |  |
| %** | 0.6 | % |  | 0.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Global Services | 164,070 |  |  | 130,019 |  |  |  |  | 26.2 | % |  |  |  |  |  |  |  |  |
| %** | 11.5 | % |  | 12.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  | 33.1 | % |  |  |  |  |  |  |  |  |

[0001628280-26-015152:mdna:25]
[same as prior period, unchanged from 0000936395-25-000041:mdna:26]

[0001628280-26-015152:mdna:26]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-015152:mdna:27]
[same as prior period, unchanged from 0000936395-25-000041:mdna:28]

[0001628280-26-015152:mdna:28]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:29]
•Networking Platforms segment revenue increased by $328.0 million.

[0001628280-26-015152:mdna:30]
•Optical Networking products revenue increased by $295.2 million, primarily driven by increases in sales of our Waveserver® system to service provider and cloud provider customers, and our 6500 Reconfigurable Line Systems (RLS) to cloud provider customers.

[0001628280-26-015152:mdna:31]
•Routing and Switching products revenue increased by $32.8 million, primarily driven by an increase in sales of our 3000 and 5000 series of service delivery and aggregation platforms, including our out-of-band data center management (DCOM) solution, to cloud provider and service provider customers.

[0001628280-26-015152:mdna:32]
•Platform Software and Services segment revenue decreased by $1.7 million, primarily reflecting a sales decrease of our software consulting services, partially offset by an increase in sales of our Navigator NCS software solution.

[0001628280-26-015152:mdna:33]
•Blue Planet Automation Software and Services segment revenue decreased by $5.6 million, primarily reflecting a sales decrease in our unified assurance and analytics software, partially offset by a sales increase in our inventory management software services.

[0001628280-26-015152:mdna:34]
•Global Services segment revenue increased by $34.1 million, primarily reflecting sales increases in our implementation services and maintenance, support, and learning services.

[0001628280-26-015152:mdna:35]
[same as prior period, unchanged from 0000936395-25-000041:mdna:43]

[0001628280-26-015152:mdna:36]
[same as prior period, unchanged from 0000936395-25-000041:mdna:44]

[0001628280-26-015152:mdna:37]
[same as prior period, unchanged from 0000936395-25-000041:mdna:45]

[0001628280-26-015152:mdna:38]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Americas | $ | 1,118,223 |  |  | $ | 795,632 |  |  |  |  | 40.5 | % |  |  |  |  |  |  |  |  |
| %** | 78.4 | % |  | 74.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA | 200,587 |  |  | 157,916 |  |  |  |  | 27.0 | % |  |  |  |  |  |  |  |  |
| %** | 14.0 | % |  | 14.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APAC | 108,232 |  |  | 118,712 |  |  |  |  | (8.8) | % |  |  |  |  |  |  |  |  |
| %** | 7.6 | % |  | 11.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,427,042 |  |  | $ | 1,072,260 |  |  |  |  | 33.1 | % |  |  |  |  |  |  |  |  |

[0001628280-26-015152:mdna:39]
[same as prior period, unchanged from 0000936395-25-000041:mdna:47]

[0001628280-26-015152:mdna:40]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-015152:mdna:41]
[same as prior period, unchanged from 0000936395-25-000041:mdna:49]

[0001628280-26-015152:mdna:42]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:43]
•Americas revenue increased by $322.6 million, primarily driven by increased sales to cloud providers and service providers in the United States.

[0001628280-26-015152:mdna:44]
•EMEA revenue increased by $42.7 million, primarily driven by increased sales to cloud providers in the Netherlands.

[0001628280-26-015152:mdna:45]
•APAC revenue decreased by $10.5 million, primarily driven by decreased sales in India, primarily to service providers, partially offset by increased sales in Singapore, primarily to cloud providers.

[0001628280-26-015152:mdna:46]
[same as prior period, unchanged from 0000936395-25-000041:mdna:58]

[0001628280-26-015152:mdna:47]
During the first quarter of fiscal 2026, approximately 8.3% of our revenue was non-U.S. Dollar-denominated. During the first quarter of fiscal 2026 as compared to the first quarter of fiscal 2025, the U.S. Dollar generally weakened against other currencies. These currency fluctuations had a positive effect on our revenue reported in U.S. Dollars of approximately $5.0 million, or 0.4%, as compared to the first quarter of fiscal 2025.

[0001628280-26-015152:mdna:48]
Gross Margin

[0001628280-26-015152:mdna:49]
Gross margin is calculated as revenue less cost of goods sold, divided by revenue.

[0001628280-26-015152:mdna:50]
•Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs, shipping, logistics, and tariff costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, any estimated losses on committed customer contracts.

[0001628280-26-015152:mdna:51]
•Service cost of goods sold consists primarily of direct and third-party costs associated with our provision of services, including implementation, maintenance, support, learning, advisory and enablement activities, and any estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0001628280-26-015152:mdna:52]
Gross margin can fluctuate due to a number of factors, including technology-based price compression, product and service mix, the lifecycle stage of our products and cost reductions.

[0001628280-26-015152:mdna:53]
The tables below set forth the changes in revenue and gross margin for the periods indicated (in thousands, except percentage data):

[0001628280-26-015152:mdna:54]
|  | Quarter Ended |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  |  |
|  | Revenue |  | Gross Margin (%) |  | Revenue |  | Gross Margin (%) |  | Revenue Change (%) |  | Gross Margin Change |
| Total | $ | 1,427,042 |  |  | 43.8 | % |  | $ | 1,072,260 |  |  | 44.0 | % |  | 33.1 | % |  | (0.2) | % |
| Products | $ | 1,179,870 |  |  | 43.5 | % |  | $ | 854,785 |  |  | 42.6 | % |  | 38.0 | % |  | 0.9 | % |
| Services | $ | 247,172 |  |  | 45.4 | % |  | $ | 217,475 |  |  | 49.6 | % |  | 13.7 | % |  | (4.2) | % |

[0001628280-26-015152:mdna:55]
[same as prior period, unchanged from 0000936395-25-000041:mdna:64]

[0001628280-26-015152:mdna:56]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:57]
•Gross margin decreased by 20 basis points from the first quarter of fiscal 2025 to the first quarter of fiscal 2026, primarily reflecting decreased services margin.

[0001628280-26-015152:mdna:58]
•Product gross margin increased by 90 basis points from the first quarter of fiscal 2025 to the first quarter of fiscal 2026. The increase was primarily due to product cost reductions and a more favorable product mix, partially offset by a one-time manufacturing efficiency benefit recognized in the first quarter of fiscal 2025, and increased inventory writedowns.

[0001628280-26-015152:mdna:59]
•Services gross margin decreased by 420 basis points from the first quarter of fiscal 2025 to the first quarter of fiscal 2026, primarily due to a less favorable services mix, partially offset by improved margins on deployment services.

[0001628280-26-015152:mdna:60]
[same as prior period, unchanged from 0000936395-25-000041:mdna:75]

[0001628280-26-015152:mdna:61]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Consolidated Results of Operations - Operating Expense” in Item 7 of Part II of our 2025 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0001628280-26-015152:mdna:62]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Research and development | $ | 221,458 |  |  | $ | 192,663 |  |  |  |  | 14.9 | % |  |  |  |  |  |  |  |  |
| %** | 15.5 | % |  | 18.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing | 148,867 |  |  | 136,504 |  |  |  |  | 9.1 | % |  |  |  |  |  |  |  |  |
| %** | 10.4 | % |  | 12.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | 59,243 |  |  | 53,902 |  |  |  |  | 9.9 | % |  |  |  |  |  |  |  |  |
| %** | 4.2 | % |  | 5.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,498 |  |  | 1,544 |  |  |  |  | (3.0) | % |  |  |  |  |  |  |  |  |
| %** | 0.1 | % |  | 0.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets | 4,736 |  |  | 6,545 |  |  |  |  | (27.6) | % |  |  |  |  |  |  |  |  |
| %** | 0.3 | % |  | 0.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition and integration costs | 306 |  |  | — |  |  |  |  | 100.0 | % |  |  |  |  |  |  |  |  |
| %** | — | % |  | — | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 436,108 |  |  | $ | 391,158 |  |  |  |  | 11.5 | % |  |  |  |  |  |  |  |  |
| %** | 30.6 | % |  | 36.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-26-015152:mdna:63]
[same as prior period, unchanged from 0000936395-25-000041:mdna:78]

[0001628280-26-015152:mdna:64]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-015152:mdna:65]
[same as prior period, unchanged from 0000936395-25-000041:mdna:66]

[0001628280-26-015152:mdna:66]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:67]
•Research and development expense increased by $28.8 million. Net of hedging, this primarily reflects higher employee headcount and related compensation costs, including our acquisition of Nubis Communications, and professional services expense.

[0001628280-26-015152:mdna:68]
•Selling and marketing expense increased by $12.4 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-015152:mdna:69]
•General and administrative expense increased by $5.3 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-015152:mdna:70]
[same as prior period, unchanged from 0000936395-25-000041:mdna:85]

[0001628280-26-015152:mdna:71]
•Amortization of intangible assets decreased by $1.8 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0001628280-26-015152:mdna:72]
•Acquisition and integration costs reflect financial, legal, and accounting advisory costs and certain employee-related costs related to our acquisition of Nubis Communications.

[0001628280-26-015152:mdna:73]
[same as prior period, unchanged from 0000936395-25-000041:mdna:93]

[0001628280-26-015152:mdna:74]
During the first quarter of fiscal 2026, approximately 50.6% of our operating expense was non-U.S. Dollar-denominated. During the first quarter of fiscal 2026, as compared to the first quarter of fiscal 2025, the U.S. Dollar generally weakened against other currencies. These currency fluctuations, net of hedging, had the effect of increasing our operating expense by approximately $4.8 million, or 1.1%, as compared to the first quarter of fiscal 2025.

[0001628280-26-015152:mdna:75]
[same as prior period, unchanged from 0000936395-25-000041:mdna:95]

[0001628280-26-015152:mdna:76]
[same as prior period, unchanged from 0000936395-25-000041:mdna:97]

[0001628280-26-015152:mdna:77]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 316,631 |  |  | $ | 182,162 |  |  |  |  | 73.8 | % |  |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 61,718 |  |  | $ | 65,423 |  |  |  |  | (5.7) | % |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | $ | (3,814) |  |  | $ | 6,500 |  |  |  |  | (158.7) | % |  |  |  |  |  |  |  |  |
| Global Services | $ | 58,754 |  |  | $ | 46,697 |  |  |  |  | 25.8 | % |  |  |  |  |  |  |  |  |

[0001628280-26-015152:mdna:78]
[same as prior period, unchanged from 0000936395-25-000041:mdna:99]

[0001628280-26-015152:mdna:79]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-015152:mdna:80]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:81]
•Networking Platforms segment profit increased by $134.5 million, primarily due to higher sales volume and improved gross margin as described above, partially offset by higher research and development costs.

[0001628280-26-015152:mdna:82]
•Platform Software and Services segment profit decreased by $3.7 million, primarily due to lower services sales volume as described above, and increased research and development costs.

[0001628280-26-015152:mdna:83]
•Blue Planet Automation Software and Services segment primarily reflects lower software sales volume as described above, reduced gross margins and increased research and development costs.

[0001628280-26-015152:mdna:84]
•Global Services segment profit increased by $12.1 million, primarily due to increased sales volume as described above.

[0001628280-26-015152:mdna:85]
[same as prior period, unchanged from 0000936395-25-000041:mdna:111]

[0001628280-26-015152:mdna:86]
[same as prior period, unchanged from 0000936395-25-000041:mdna:112]

[0001628280-26-015152:mdna:87]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 31, 2026 |  | February 1, 2025 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Interest and other income, net | $ | 12,957 |  |  | $ | 11,578 |  |  |  |  | 11.9 | % |  |  |  |  |  |  |  |  |
| %** | 0.9 | % |  | 1.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | 21,254 |  |  | $ | 22,918 |  |  |  |  | (7.3) | % |  |  |  |  |  |  |  |  |
| %** | 1.5 | % |  | 2.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | 729 |  |  |  |  | (100.0) | % |  |  |  |  |  |  |  |  |
| %** | — | % |  | 0.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | $ | 30,832 |  |  | $ | 24,022 |  |  |  |  | 28.3 | % |  |  |  |  |  |  |  |  |
| %** | 2.2 | % |  | 2.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0001628280-26-015152:mdna:88]
[same as prior period, unchanged from 0000936395-25-000041:mdna:114]

[0001628280-26-015152:mdna:89]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-015152:mdna:90]
[same as prior period, unchanged from 0000936395-25-000041:mdna:80]

[0001628280-26-015152:mdna:91]
Quarter ended January 31, 2026 as compared to the quarter ended February 1, 2025

[0001628280-26-015152:mdna:92]
•Interest and other income, net increased by $1.4 million, primarily reflecting the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0001628280-26-015152:mdna:93]
•Interest expense decreased by $1.7 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity.

[0001628280-26-015152:mdna:94]
•Loss on extinguishment and modification of debt reflects the refinancing of our 2030 Term Loan in the first quarter of fiscal 2025.

[0001628280-26-015152:mdna:95]
•Provision for income taxes increased by $6.8 million, primarily due to the increase in pre-tax book income.

[0001628280-26-015152:mdna:96]
[same as prior period, unchanged from 0000936395-25-000041:mdna:126]

[0001628280-26-015152:mdna:97]
We regularly evaluate our capital structure, liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and we will continue to consider capital raising and other market opportunities that may be available to us.

[0001628280-26-015152:mdna:98]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of January 31, 2026, totaled $1.4 billion, as well as our credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of January 31, 2026, letters of credit totaling $41.1 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of January 31, 2026.

[0001628280-26-015152:mdna:99]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $351.7 million as of January 31, 2026. Approximately $92.3 million of undistributed earnings from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0001628280-26-015152:mdna:100]
Stock Repurchases. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first three months of fiscal 2026, we repurchased $80.5 million of our common stock under the stock repurchase program, and $589.8 million remained under the current repurchase authorization as of January 31, 2026. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. During the first quarter of fiscal 2026, we also repurchased $90.1 million of our common stock in settlement of employee tax withholding obligations due upon the vesting of stock unit awards. See Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as “Issuer Purchases of Equity Securities” in Item 2 of Part II of this report.

[0001628280-26-015152:mdna:101]
[same as prior period, unchanged from 0000936395-25-000041:mdna:131]

[0001628280-26-015152:mdna:102]
[same as prior period, unchanged from 0000936395-25-000041:mdna:132]

[0001628280-26-015152:mdna:103]
|  | January 31,2026 |  | November 1,2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 1,123,413 |  |  | $ | 1,091,952 |  |  | $ | 31,461 |  |
| Short-term investments in marketable debt securities | 176,315 |  |  | 216,148 |  |  | (39,833) |  |
| Long-term investments in marketable debt securities | 69,876 |  |  | 57,142 |  |  | 12,734 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,369,604 |  |  | $ | 1,365,242 |  |  | $ | 4,362 |  |

[0001628280-26-015152:mdna:104]
Cash, cash equivalents and investments increased by $4.4 million during the first three months of fiscal 2026. Cash from operating activities generated $227.6 million, which was partially offset by the following: (i) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $90.1 million; (ii) cash used for stock repurchases under our stock repurchase program of $80.5 million; and (iii) cash used to fund our investing activities for capital expenditures totaling $73.9 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $17.2 million in cash during the three months ended January 31, 2026.

[0001628280-26-015152:mdna:105]
[same as prior period, unchanged from 0000936395-25-000041:mdna:135]

[0001628280-26-015152:mdna:106]
The following sections set forth the components of our $227.6 million of cash provided by operating activities during the first three months of fiscal 2026. Net income (adjusted for non-cash charges) provided cash of $265.3 million, offset by cash used in operating assets and liabilities of $37.7 million.

[0001628280-26-015152:mdna:107]
[same as prior period, unchanged from 0000936395-25-000041:mdna:137]

[0001628280-26-015152:mdna:108]
[same as prior period, unchanged from 0000936395-25-000041:mdna:138]

[0001628280-26-015152:mdna:109]
|  | Three Months Ended |
|  | January 31, 2026 |
| Net income | $ | 150,283 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 32,309 |  |
| Share-based compensation expense | 49,827 |  |
| Amortization of intangible assets | 11,521 |  |
| Deferred taxes | (7,043) |  |
| Provision for inventory excess and obsolescence | 21,832 |  |
| Provision for warranty | 8,185 |  |
| Other | (1,545) |  |
| Net income (adjusted for non-cash charges) | $ | 265,369 |  |

[0001628280-26-015152:mdna:110]
[same as prior period, unchanged from 0000936395-25-000041:mdna:140]

[0001628280-26-015152:mdna:111]
Operating asset and liability requirements increased by $37.7 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0001628280-26-015152:mdna:112]
|  | Three Months Ended |
|  | January 31, 2026 |
| Accounts receivable | $ | 9,406 |  |
| Inventories | (41,228) |  |
| Prepaid expenses and other | 40,024 |  |
| Accounts payable, accruals, and other obligations | (130,907) |  |
| Deferred revenue | 86,013 |  |
| Operating lease assets and liabilities, net | (1,032) |  |
| Total cash consumed by operating assets and liabilities | $ | (37,724) |  |

[0001628280-26-015152:mdna:113]
As compared to the end of fiscal 2025, for the first three months of fiscal 2026:

[0001628280-26-015152:mdna:114]
•The change in accounts receivable primarily reflects improved cash collections partially offset by increased sales volume;

[0001628280-26-015152:mdna:115]
•The change in inventories primarily reflects our strategy to mitigate supply chain volatility and ensure uninterrupted fulfillment of orders;

[0001628280-26-015152:mdna:116]
•The change in prepaid expenses and other primarily reflects lower prepaid value-added tax (VAT), lower contract assets for unbilled accounts receivable, and reduced refundable cash advances to a third-party contract manufacturer;

[0001628280-26-015152:mdna:117]
•The change in accounts payable, accruals, and other obligations primarily reflects the timing of payments associated with our annual incentive compensation plan partially offset by the timing of payments for payroll and higher payroll related costs;

[0001628280-26-015152:mdna:118]
[same as prior period, unchanged from 0000936395-25-000041:mdna:148]

[0001628280-26-015152:mdna:119]
[same as prior period, unchanged from 0000936395-25-000041:mdna:149]

[0001628280-26-015152:mdna:120]
[same as prior period, unchanged from 0000936395-25-000041:mdna:151]

[0001628280-26-015152:mdna:121]
[same as prior period, unchanged from 0000936395-25-000041:mdna:152]

[0001628280-26-015152:mdna:122]
|  | Three Months Ended |
|  | January 31, 2026 |
| Refinanced 2030 Term Loan due October 28, 2030(1) | 16,600 |  |
| 2030 Senior Notes due January 31, 2030(2) | — |  |
| Interest rate swaps(3) | (955) |  |
| Revolving Credit Facility(4) | 428 |  |
| Finance leases | 806 |  |
| Cash paid during period | $ | 16,879 |  |

[0001628280-26-015152:mdna:123]
(1) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the first quarter of fiscal 2026, the interest rate on the Refinanced 2030 Term Loan was 5.43%.

[0001628280-26-015152:mdna:124]
(2) The 2030 Notes bear interest at a rate of 4.00% per annum. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year.

[0001628280-26-015152:mdna:125]
(3) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loan at 3.47% through January 2028 and another $350.0 million of our Term Loan at 3.287% through December 2028.

[0001628280-26-015152:mdna:126]
(4) During the first three months of fiscal 2026, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0001628280-26-015152:mdna:127]
For additional information about our debt and interest rate swaps, see Notes 11 and 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0001628280-26-015152:mdna:128]
[same as prior period, unchanged from 0000936395-25-000041:mdna:160]

[0001628280-26-015152:mdna:129]
Our contractual obligations have not changed materially since November 1, 2025. For a summary of our contractual obligations, see “Liquidity and Capital Resources – Contractual Obligations” in Item 7 of Part II of our 2025 Annual Report.

[0001628280-26-015152:mdna:130]
[same as prior period, unchanged from 0000936395-25-000041:mdna:162]

[0001628280-26-015152:mdna:131]
Our critical accounting policies and estimates have not changed materially since November 1, 2025. For a discussion of our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” in Item 7 of Part II of our 2025 Annual Report.

[0001628280-26-015152:mdna:132]
[same as prior period, unchanged from 0000936395-25-000041:mdna:164]

[0001628280-26-015152:mdna:133]
[same as prior period, unchanged from 0000936395-25-000041:mdna:165]
