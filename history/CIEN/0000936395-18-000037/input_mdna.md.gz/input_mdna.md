# CIEN MD&A — 0000936395-18-000037


## mdna

[0000936395-18-000037:mdna:1]
[same as prior period, unchanged from 0000936395-18-000024:mdna:1]

[0000936395-18-000037:mdna:2]
[same as prior period, unchanged from 0000936395-18-000024:mdna:2]

[0000936395-18-000037:mdna:3]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and control of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including IT transitions or initiatives; the impact of the Tax Cuts and Jobs Act and provisional estimates with respect thereto; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-18-000037:mdna:4]
[same as prior period, unchanged from 0000936395-18-000024:mdna:4]

[0000936395-18-000037:mdna:5]
[same as prior period, unchanged from 0000936395-18-000024:mdna:5]

[0000936395-18-000037:mdna:6]
[same as prior period, unchanged from 0000936395-18-000024:mdna:6]

[0000936395-18-000037:mdna:7]
[same as prior period, unchanged from 0000936395-18-000024:mdna:7]

[0000936395-18-000037:mdna:8]
[same as prior period, unchanged from 0000936395-18-000024:mdna:8]

[0000936395-18-000037:mdna:9]
[same as prior period, unchanged from 0000936395-18-000024:mdna:9]

[0000936395-18-000037:mdna:10]
[same as prior period, unchanged from 0000936395-18-000024:mdna:10]

[0000936395-18-000037:mdna:11]
[same as prior period, unchanged from 0000936395-18-000024:mdna:11]

[0000936395-18-000037:mdna:12]
[same as prior period, unchanged from 0000936395-18-000024:mdna:12]

[0000936395-18-000037:mdna:13]
[same as prior period, unchanged from 0000936395-18-000024:mdna:13]

[0000936395-18-000037:mdna:14]
[same as prior period, unchanged from 0000936395-18-000024:mdna:14]

[0000936395-18-000037:mdna:15]
[same as prior period, unchanged from 0000936395-18-000024:mdna:15]

[0000936395-18-000037:mdna:16]
[same as prior period, unchanged from 0000936395-18-000024:mdna:16]

[0000936395-18-000037:mdna:17]
[same as prior period, unchanged from 0000936395-18-000024:mdna:17]

[0000936395-18-000037:mdna:18]
[same as prior period, unchanged from 0000936395-18-000024:mdna:18]

[0000936395-18-000037:mdna:19]
[same as prior period, unchanged from 0000936395-18-000024:mdna:19]

[0000936395-18-000037:mdna:20]
[same as prior period, unchanged from 0000936395-18-000024:mdna:20]

[0000936395-18-000037:mdna:21]
[same as prior period, unchanged from 0000936395-18-000024:mdna:21]

[0000936395-18-000037:mdna:22]
[same as prior period, unchanged from 0000936395-18-000024:mdna:22]

[0000936395-18-000037:mdna:23]
[same as prior period, unchanged from 0000936395-18-000024:mdna:23]

[0000936395-18-000037:mdna:24]
[same as prior period, unchanged from 0000936395-18-000024:mdna:24]

[0000936395-18-000037:mdna:25]
[same as prior period, unchanged from 0000936395-18-000024:mdna:25]

[0000936395-18-000037:mdna:26]
[same as prior period, unchanged from 0000936395-18-000024:mdna:26]

[0000936395-18-000037:mdna:27]
[same as prior period, unchanged from 0000936395-18-000024:mdna:27]

[0000936395-18-000037:mdna:28]
[same as prior period, unchanged from 0000936395-18-000024:mdna:28]

[0000936395-18-000037:mdna:29]
[same as prior period, unchanged from 0000936395-18-000024:mdna:29]

[0000936395-18-000037:mdna:30]
[same as prior period, unchanged from 0000936395-18-000024:mdna:30]

[0000936395-18-000037:mdna:31]
[same as prior period, unchanged from 0000936395-18-000024:mdna:31]

[0000936395-18-000037:mdna:32]
[same as prior period, unchanged from 0000936395-18-000024:mdna:32]

[0000936395-18-000037:mdna:33]
[same as prior period, unchanged from 0000936395-18-000024:mdna:33]

[0000936395-18-000037:mdna:34]
[same as prior period, unchanged from 0000936395-18-000024:mdna:34]

[0000936395-18-000037:mdna:35]
[same as prior period, unchanged from 0000936395-18-000024:mdna:35]

[0000936395-18-000037:mdna:36]
[same as prior period, unchanged from 0000936395-18-000024:mdna:36]

[0000936395-18-000037:mdna:37]
| • | adverse results in litigation matters. |

[0000936395-18-000037:mdna:38]
These are only some of the factors that may affect the forward-looking statements contained in this quarterly report. For a discussion identifying additional important factors that could cause actual results to vary materially from those anticipated in the forward-looking statements, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” in this quarterly report. For a more complete understanding of the risks associated with an investment in Ciena’s securities, you should review these risk factors and the rest of this quarterly report in combination with the more detailed description of our business and management’s discussion and analysis of financial condition and risk factors described in our annual report on Form 10-K for fiscal 2017, which we filed with the Securities and Exchange Commission (the “SEC”) on December 22, 2017. However, we operate in a very competitive and rapidly changing environment and new risks and uncertainties emerge, are identified or become apparent from time to time. We cannot predict all risks and uncertainties that could have an impact on the forward-looking statements contained in this quarterly report. You should be

[0000936395-18-000037:mdna:39]
[same as prior period, unchanged from 0000936395-18-000024:mdna:52]

[0000936395-18-000037:mdna:40]
[same as prior period, unchanged from 0000936395-18-000024:mdna:38]

[0000936395-18-000037:mdna:41]
[same as prior period, unchanged from 0000936395-18-000024:mdna:39]

[0000936395-18-000037:mdna:42]
Our solutions include a diverse set of Networking Platforms products, which are used by a broad range of network operator customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which can be applied from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware systems and components, we offer network management and domain control software platforms, along with advanced applications software, designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of services that help our customers design, optimize, integrate, deploy, manage, and maintain their networks.

[0000936395-18-000037:mdna:43]
Diversification of our business. We continue to diversify our customer base to include fast-growing customer segments, such as Web-scale providers, data center operators and emerging network operators, which have been increasingly important contributors to our overall growth and which are included among our largest customers by revenue. This diversification of our customer base can result in shifts in product mix, as evidenced by the increased sales of our Waveserver platform in recent periods. At the same time, a significant portion of our revenue and customer base continues to consist of sales to large service provider customers. Sales to AT&T were $263.5 million, or 12.0% of total revenue, during nine months ended July 31, 2018, and $324.9 million, or 15.8% of total revenue, during the nine months ended July 31, 2017. Our revenue growth has benefited from a go-to-market strategy focused on generating new customer wins, displacing competitors, and capturing additional opportunities with service providers in international markets, particularly in our Asia-Pacific and India regions. We believe that continued diversification of our business is important to address the dynamic industry environment in which we operate, to continue to grow our business, and to better withstand potential slowdowns which could adversely affect demand from particular geographies, markets, customers or customer segments.

[0000936395-18-000037:mdna:44]
Stock Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. For additional information, including our repurchase activities under the program, see Note 15 and Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-18-000037:mdna:45]
Impact of Tax Cuts and Jobs Act. Our results of operations for fiscal 2018 have been impacted by enactment of the Tax Cuts and Jobs Act (the “Tax Act”) in December 2017. Specifically, our results for fiscal 2018 include a provisional $476.9 million tax charge consisting of the following:

[0000936395-18-000037:mdna:46]
[same as prior period, unchanged from 0000936395-18-000024:mdna:46]

[0000936395-18-000037:mdna:47]
[same as prior period, unchanged from 0000936395-18-000024:mdna:47]

[0000936395-18-000037:mdna:48]
These amounts are provisional and reflect management’s current estimates and current interpretations of the Tax Act. These amounts may require adjustment in future periods as additional guidance under the Tax Act becomes available and analysis of its provisions is completed. See Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information related to the impact of the Tax Act.

[0000936395-18-000037:mdna:49]
Packet Design Acquisition. On July 2, 2018, we acquired privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. We expect the acquisition of Packet Design to help accelerate our Blue Planet software strategy by extending our intelligent automation capabilities beyond Layers 0-2 and into Internet Protocols with critical new capabilities to help customers optimize service delivery and maximize network utilization.

[0000936395-18-000037:mdna:50]
Available Information. Our quarterly reports on Form 10-Q, annual reports on Form 10-K, current reports on Form 8-K, and any amendments thereto filed or furnished with the SEC are available through the SEC’s website at www.sec.gov and are available free of charge on our website as soon as reasonably practicable after we file or furnish these documents. We routinely post the reports above, recent news and announcements, financial results and other information about Ciena that is important to investors in the “Investors” section of our website at www.ciena.com. Investors are encouraged to review the “Investors” section of our website because, as with the other disclosure channels that we use, from time to time we may post material information on that site that is not otherwise disseminated by us.

[0000936395-18-000037:mdna:51]
[same as prior period, unchanged from 0000936395-18-000024:mdna:51]

[0000936395-18-000037:mdna:52]
[same as prior period, unchanged from 0000936395-18-000024:mdna:79]

[0000936395-18-000037:mdna:53]
[same as prior period, unchanged from 0000936395-18-000024:mdna:53]

[0000936395-18-000037:mdna:54]
[same as prior period, unchanged from 0000936395-18-000024:mdna:54]

[0000936395-18-000037:mdna:55]
We have the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Software and Software-Related Services; and (iii) Global Services. As of the first quarter of fiscal 2018, sales of our Optical Transport products are reflected within the Converged Packet Optical product line of our Networking Platforms segment for all periods presented. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000037:mdna:56]
Quarter ended July 31, 2018 compared to the quarter ended July 31, 2017

[0000936395-18-000037:mdna:57]
[same as prior period, unchanged from 0000936395-18-000024:mdna:57]

[0000936395-18-000037:mdna:58]
During the third quarter of fiscal 2018, approximately 14.2% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, British Pounds, Indian Rupee and Argentina Pesos. During the third quarter of fiscal 2018, as compared to the third quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly decreased by approximately $1.9 million, net of hedging, or 0.2%, as compared to the third quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000037:mdna:59]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 592,892 |  |  | 72.5 |  | $ | 510,226 |  |  | 70.0 |  | $ | 82,666 |  |  | 16.2 |  |
| Packet Networking | 84,559 |  |  | 10.3 |  | 82,121 |  |  | 11.3 |  | 2,438 |  |  | 3.0 |  |
| Total Networking Platforms | 677,451 |  |  | 82.8 |  | 592,347 |  |  | 81.3 |  | 85,104 |  |  | 14.4 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 14,307 |  |  | 1.7 |  | 18,395 |  |  | 2.5 |  | (4,088 | ) |  | (22.2 | ) |
| Software-Related Services | 26,876 |  |  | 3.3 |  | 23,856 |  |  | 3.3 |  | 3,020 |  |  | 12.7 |  |
| Total Software and Software-Related Services | 41,183 |  |  | 5.0 |  | 42,251 |  |  | 5.8 |  | (1,068 | ) |  | (2.5 | ) |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 60,897 |  |  | 7.4 |  | 57,902 |  |  | 7.9 |  | 2,995 |  |  | 5.2 |  |
| Installation and Deployment | 31,262 |  |  | 3.8 |  | 27,397 |  |  | 3.8 |  | 3,865 |  |  | 14.1 |  |
| Consulting and Network Design | 8,024 |  |  | 1.0 |  | 8,822 |  |  | 1.2 |  | (798 | ) |  | (9.0 | ) |
| Total Global Services | 100,183 |  |  | 12.2 |  | 94,121 |  |  | 12.9 |  | 6,062 |  |  | 6.4 |  |
| Consolidated revenue | $ | 818,817 |  |  | 100.0 |  | $ | 728,719 |  |  | 100.0 |  | $ | 90,098 |  |  | 12.4 |  |

[0000936395-18-000037:mdna:60]
[same as prior period, unchanged from 0000936395-18-000024:mdna:60]

[0000936395-18-000037:mdna:61]
[same as prior period, unchanged from 0000936395-18-000024:mdna:61]

[0000936395-18-000037:mdna:62]
[same as prior period, unchanged from 0000936395-18-000024:mdna:62]

[0000936395-18-000037:mdna:63]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $82.7 million of our Converged Packet Optical products and $2.4 million of our Packet Networking products. |

[0000936395-18-000037:mdna:64]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $56.9 million of our Waveserver stackable interconnect system and $38.4 million of our 6500 Packet-Optical Platform. These increases were partially offset by a sales decrease of $10.3 million of our 5410/5430 Reconfigurable Switching Systems. The sales increase of our Waveserver stackable interconnect system is primarily due to increased sales to Web-scale providers, which, as we continue to diversify, represent a growing portion of our business. The sales increase of our 6500 Packet-Optical Platform is primarily due to increased sales to Web-scale providers and enterprise |

[0000936395-18-000037:mdna:65]
and government customers, partially offset by decreased sales to cable and multiservice operators, AT&T and other communications service providers.

[0000936395-18-000037:mdna:66]
| ◦ | Packet Networking sales primarily reflect sales increases of $15.2 million of our packet networking platform independent software and $3.8 million of our 8700 Packetwave Platform. These increases were partially offset by a sales decrease of $16.1 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to AT&T. |

[0000936395-18-000037:mdna:67]
| ◦ | Software and Software-Related Services segment revenue decreased, primarily reflecting a sales decrease of $4.1 million of our software platforms, partially offset by a sales increase of $3.0 million in our software-related services. The decrease in our software platforms is primarily related to reduced sales of $3.1 million of our Optical Suite Release and $2.7 million of our OneControl Unified Management System, partially offset by sales increases of $1.4 million of Ethernet Services Manager and $1.2 million of our Blue Planet MCP. The increase in our software-related services is primarily related to increased sales of $1.3 million of our software subscriptions and $1.3 million of services supporting our Blue Planet Intelligent Automation Platform. |

[0000936395-18-000037:mdna:68]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $3.9 million of our installation and deployment services and $3.0 million of our maintenance support and training services. |

[0000936395-18-000037:mdna:69]
Our operating segments engage in business and operations across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Caribbean and Latin America (“CALA”); and Asia and Pacific (“APAC”). Results for North America include only activities in the U.S. and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as the APAC region. We believe that this is an important part of our strategy, and that it is required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The revenue increase from our EMEA region for the third quarter of fiscal 2018 was primarily driven by increased sales to communications service provider and Web-scale customers. The revenue increase from our APAC region for the third quarter of fiscal 2018 was primarily driven by increased sales in India and continued execution of our strategy to capture new market share with communications service providers in the region. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000037:mdna:70]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| North America | $ | 497,004 |  |  | 60.7 |  | $ | 465,238 |  |  | 63.8 |  | $ | 31,766 |  |  | 6.8 |  |
| EMEA | 122,204 |  |  | 14.9 |  | 96,068 |  |  | 13.2 |  | 26,136 |  |  | 27.2 |  |
| CALA | 27,493 |  |  | 3.4 |  | 51,709 |  |  | 7.1 |  | (24,216 | ) |  | (46.8 | ) |
| APAC | 172,116 |  |  | 21.0 |  | 115,704 |  |  | 15.9 |  | 56,412 |  |  | 48.8 |  |
| Total | $ | 818,817 |  |  | 100.0 |  | $ | 728,719 |  |  | 100.0 |  | $ | 90,098 |  |  | 12.4 |  |

[0000936395-18-000037:mdna:71]
[same as prior period, unchanged from 0000936395-18-000024:mdna:71]

[0000936395-18-000037:mdna:72]
[same as prior period, unchanged from 0000936395-18-000024:mdna:72]

[0000936395-18-000037:mdna:73]
[same as prior period, unchanged from 0000936395-18-000024:mdna:73]

[0000936395-18-000037:mdna:74]
| • | North America revenue primarily reflects an increase of $33.7 million within our Networking Platforms segment partially offset by a revenue decrease of $1.4 million within our Software and Software-Related Services segment. |

[0000936395-18-000037:mdna:75]
| ◦ | Networking Platforms revenue primarily reflects product line increases of $29.4 million of Converged Packet Optical sales and $4.5 million of Packet Networking sales. |

[0000936395-18-000037:mdna:76]
| ▪ | The revenue increase within Converged Packet Optical sales primarily reflects an increase of $42.3 million in sales of our Waveserver stackable interconnect system, partially offset by revenue decreases in sales of $7.3 million of our 6500 Packet-Optical Platform and $5.3 million in sales of our 5410/5430 Reconfigurable Switching Systems. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. |

[0000936395-18-000037:mdna:77]
32

[0000936395-18-000037:mdna:78]
| ▪ | The revenue increase within Packet Networking primarily reflects an increase of $15.2 million of our packet networking platform independent software, partially offset by a decrease of $11.0 million in sales of our 3000 and 5000 families of service delivery and aggregation switches to AT&T. |

[0000936395-18-000037:mdna:79]
| • | EMEA revenue primarily reflects increases of $24.7 million within our Networking Platforms segment and $2.2 million within our Global Services segment. |

[0000936395-18-000037:mdna:80]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $24.2 million in Converged Packet Optical sales. The increase in Converged Packet Optical sales primarily reflects increases of $12.9 million in sales of our 6500 Packet-Optical Platform and $12.8 million in sales from our Waveserver stackable interconnect system. Both increases were primarily due to increased sales to Web-scale providers. |

[0000936395-18-000037:mdna:81]
| • | CALA revenue primarily reflects decreases of $23.4 million within our Networking Platforms segment and $1.4 million within our Global Services segment. |

[0000936395-18-000037:mdna:82]
| ◦ | Networking Platforms segment revenue primarily reflects product line decreases of $21.4 million in Converged Packet Optical sales and $2.0 million in Packet Networking sales. The decrease in Converged Packet Optical sales primarily reflects decreases of $18.1 million in sales of our 6500 Packet-Optical Platform and $2.6 million in sales from our 5410/5430 Reconfigurable Switching Systems. The decrease in sales of our 6500 Packet-Optical Platform is primarily due to decreased sales to a certain communications service provider in Brazil. |

[0000936395-18-000037:mdna:83]
| • | APAC revenue primarily reflects increases of $49.9 million within our Networking Platforms segment and $6.1 million within our Global Services segment. The increase in APAC revenue primarily represents increases in sales in India and Japan of $41.4 million and $10.6 million, respectively. |

[0000936395-18-000037:mdna:84]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $50.5 million in Converged Packet Optical sales primarily due to an increase of $50.9 in sales of our 6500 Packet-Optical Platform to government customers, communications service providers and submarine network operators. |

[0000936395-18-000037:mdna:85]
| ◦ | Global Services segment revenue primarily reflects sales increases of $4.7 million of our installation and deployment services and $1.2 million of our maintenance support and training services. Both increases were due to increased sales to communications service providers and submarine network operators. |

[0000936395-18-000037:mdna:86]
[same as prior period, unchanged from 0000936395-18-000024:mdna:86]

[0000936395-18-000037:mdna:87]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-18-000037:mdna:88]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-18-000037:mdna:89]
[same as prior period, unchanged from 0000936395-18-000024:mdna:89]

[0000936395-18-000037:mdna:90]
[same as prior period, unchanged from 0000936395-18-000024:mdna:90]

[0000936395-18-000037:mdna:91]
[same as prior period, unchanged from 0000936395-18-000024:mdna:91]

[0000936395-18-000037:mdna:92]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 818,817 |  |  | 100.0 |  | $ | 728,719 |  |  | 100.0 |  | $ | 90,098 |  |  | 12.4 |
| Total cost of goods sold | 467,274 |  |  | 57.1 |  | 400,643 |  |  | 55.0 |  | 66,631 |  |  | 16.6 |
| Gross profit | $ | 351,543 |  |  | 42.9 |  | $ | 328,076 |  |  | 45.0 |  | $ | 23,467 |  |  | 7.2 |

[0000936395-18-000037:mdna:93]
[same as prior period, unchanged from 0000936395-18-000024:mdna:93]

[0000936395-18-000037:mdna:94]
[same as prior period, unchanged from 0000936395-18-000024:mdna:94]

[0000936395-18-000037:mdna:95]
[same as prior period, unchanged from 0000936395-18-000024:mdna:95]

[0000936395-18-000037:mdna:96]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 691,758 |  |  | 100.0 |  | $ | 610,742 |  |  | 100.0 |  | $ | 81,016 |  |  | 13.3 |
| Product cost of goods sold | 399,886 |  |  | 57.8 |  | 341,197 |  |  | 55.9 |  | 58,689 |  |  | 17.2 |
| Product gross profit | $ | 291,872 |  |  | 42.2 |  | $ | 269,545 |  |  | 44.1 |  | $ | 22,327 |  |  | 8.3 |

[0000936395-18-000037:mdna:97]
[same as prior period, unchanged from 0000936395-18-000024:mdna:97]

[0000936395-18-000037:mdna:98]
[same as prior period, unchanged from 0000936395-18-000024:mdna:98]

[0000936395-18-000037:mdna:99]
[same as prior period, unchanged from 0000936395-18-000024:mdna:99]

[0000936395-18-000037:mdna:100]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 127,059 |  |  | 100.0 |  | $ | 117,977 |  |  | 100.0 |  | $ | 9,082 |  |  | 7.7 |
| Service cost of goods sold | 67,388 |  |  | 53.0 |  | 59,446 |  |  | 50.4 |  | 7,942 |  |  | 13.4 |
| Service gross profit | $ | 59,671 |  |  | 47.0 |  | $ | 58,531 |  |  | 49.6 |  | $ | 1,140 |  |  | 1.9 |

[0000936395-18-000037:mdna:101]
[same as prior period, unchanged from 0000936395-18-000024:mdna:101]

[0000936395-18-000037:mdna:102]
[same as prior period, unchanged from 0000936395-18-000024:mdna:102]

[0000936395-18-000037:mdna:103]
[same as prior period, unchanged from 0000936395-18-000024:mdna:103]

[0000936395-18-000037:mdna:104]
| • | Gross profit as a percentage of revenue reflects reduced product and services gross profit as described below. We have encountered and expect to continue to encounter fluctuations or reductions in quarterly gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Our success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and it may result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-18-000037:mdna:105]
| • | Gross profit on products as a percentage of product revenue decreased primarily as a result of our strategy to capture market share as described above and the impact of early stages of network deployments with service provider customers, including an increased concentration of lower margin “common” equipment sales and decreased sales of our software platforms, partially offset by higher margins from increased sales of our packet networking platform independent software and product cost reductions. |

[0000936395-18-000037:mdna:106]
| • | Gross profit on services as a percentage of services revenue decreased primarily due to reduced margins on our software-related services and maintenance services and increased sales of lower margin installation and deployment services. Reduced margins on software-related services are primarily due to increased costs related to developing resources to promote our growth strategy. Lower maintenance services margins reflect increased spares logistics costs. |

[0000936395-18-000037:mdna:107]
[same as prior period, unchanged from 0000936395-18-000024:mdna:107]

[0000936395-18-000037:mdna:108]
[same as prior period, unchanged from 0000936395-18-000024:mdna:109]

[0000936395-18-000037:mdna:109]
| • | Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs. |

[0000936395-18-000037:mdna:110]
| • | Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs. |

[0000936395-18-000037:mdna:111]
[same as prior period, unchanged from 0000936395-18-000024:mdna:112]

[0000936395-18-000037:mdna:112]
[same as prior period, unchanged from 0000936395-18-000024:mdna:114]

[0000936395-18-000037:mdna:113]
[same as prior period, unchanged from 0000936395-18-000024:mdna:113]

[0000936395-18-000037:mdna:114]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition of Packet Design. |

[0000936395-18-000037:mdna:115]
During the third quarter of fiscal 2018, approximately 51.1% of our operating expense was non-U.S. Dollar denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees, Euros, Brazilian Reais and Australian Dollars. During the third quarter of fiscal 2018 as compared to the third quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $2.1 million, or 0.8%, as compared to the third quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000037:mdna:116]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 121,133 |  |  | 14.8 |  | $ | 117,729 |  |  | 16.2 |  | $ | 3,404 |  |  | 2.9 |
| Selling and marketing | 95,395 |  |  | 11.7 |  | 86,739 |  |  | 11.9 |  | 8,656 |  |  | 10.0 |
| General and administrative | 38,212 |  |  | 4.7 |  | 35,569 |  |  | 4.9 |  | 2,643 |  |  | 7.4 |
| Significant asset impairments and restructuring costs | 6,359 |  |  | 0.8 |  | 2,203 |  |  | 0.3 |  | 4,156 |  |  | 188.7 |
| Amortization of intangible assets | 3,837 |  |  | 0.5 |  | 3,837 |  |  | 0.5 |  | — |  |  | — |
| Acquisition and integration costs | 1,333 |  |  | 0.2 |  | — |  |  | — |  | 1,333 |  |  | 100.0 |
| Total operating expenses | $ | 266,269 |  |  | 32.7 |  | $ | 246,077 |  |  | 33.8 |  | $ | 20,192 |  |  | 8.2 |

[0000936395-18-000037:mdna:117]
[same as prior period, unchanged from 0000936395-18-000024:mdna:117]

[0000936395-18-000037:mdna:118]
[same as prior period, unchanged from 0000936395-18-000024:mdna:118]

[0000936395-18-000037:mdna:119]
[same as prior period, unchanged from 0000936395-18-000024:mdna:119]

[0000936395-18-000037:mdna:120]
| • | Research and development expense increased by $1.7 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $3.4 million. This increase primarily reflects increases of $3.9 million in employee and compensation costs, $1.7 million in technology and related expenses and $1.0 million in facilities and information technology costs. Partially offsetting this increase was the benefit of $2.4 million in reimbursements from the ENCQOR grant. See Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information regarding this grant. Research and development expense also reflects a decrease of $1.1 million in prototype expense. |

[0000936395-18-000037:mdna:121]
[same as prior period, unchanged from 0000936395-18-000024:mdna:148]

[0000936395-18-000037:mdna:122]
| • | Selling and marketing expense increased by $8.7 million, primarily reflecting increases of $4.9 million in employee and compensation costs, $1.7 million in trade show and marketing program costs and $1.0 million in customer demonstration equipment. |

[0000936395-18-000037:mdna:123]
| • | General and administrative expense increased by $2.6 million, primarily reflecting a payment of $2.8 million associated with a commercial litigation dispute with a former vendor. |

[0000936395-18-000037:mdna:124]
[same as prior period, unchanged from 0000936395-18-000024:mdna:124]

[0000936395-18-000037:mdna:125]
| • | Amortization of intangible assets remained relatively unchanged. |

[0000936395-18-000037:mdna:126]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisition of Packet Design. |

[0000936395-18-000037:mdna:127]
[same as prior period, unchanged from 0000936395-18-000024:mdna:126]

[0000936395-18-000037:mdna:128]
[same as prior period, unchanged from 0000936395-18-000024:mdna:127]

[0000936395-18-000037:mdna:129]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (1,543 | ) |  | (0.2 | ) |  | $ | (848 | ) |  | (0.1 | ) |  | $ | (695 | ) |  | 82.0 |
| Interest expense | $ | 13,611 |  |  | 1.7 |  |  | $ | 13,415 |  |  | 1.8 |  |  | $ | 196 |  |  | 1.5 |
| Provision for income taxes | $ | 19,280 |  |  | 2.4 |  |  | $ | 7,726 |  |  | 1.1 |  |  | $ | 11,554 |  |  | 149.5 |

[0000936395-18-000037:mdna:130]
[same as prior period, unchanged from 0000936395-18-000024:mdna:129]

[0000936395-18-000037:mdna:131]
[same as prior period, unchanged from 0000936395-18-000024:mdna:130]

[0000936395-18-000037:mdna:132]
[same as prior period, unchanged from 0000936395-18-000024:mdna:131]

[0000936395-18-000037:mdna:133]
| • | Interest and other income (loss), net primarily reflects a $2.6 million unfavorable impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $1.8 million gain in interest income due to higher interest rates on our investments in the third quarter of fiscal 2018. |

[0000936395-18-000037:mdna:134]
[same as prior period, unchanged from 0000936395-18-000024:mdna:133]

[0000936395-18-000037:mdna:135]
[same as prior period, unchanged from 0000936395-18-000024:mdna:134]

[0000936395-18-000037:mdna:136]
Nine months ended July 31, 2018 compared to the nine months ended July 31, 2017

[0000936395-18-000037:mdna:137]
[same as prior period, unchanged from 0000936395-18-000024:mdna:136]

[0000936395-18-000037:mdna:138]
During the nine months ended July 31, 2018, approximately 17.6% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, British Pounds, Argentina Pesos, Indian Rupees, Emirati Dirham and Mexican Pesos. During the nine months ended July 31, 2018, as compared to the nine months ended July 31, 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $9.8 million, net of hedging, or 0.5%, as compared to the nine months ended July 31, 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000037:mdna:139]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,548,189 |  |  | 70.5 |  | $ | 1,433,137 |  |  | 69.7 |  | $ | 115,052 |  |  | 8.0 |  |
| Packet Networking | 216,977 |  |  | 9.9 |  | 220,641 |  |  | 10.7 |  | (3,664 | ) |  | (1.7 | ) |
| Total Networking Platforms | 1,765,166 |  |  | 80.4 |  | 1,653,778 |  |  | 80.4 |  | 111,388 |  |  | 6.7 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 56,427 |  |  | 2.6 |  | 48,587 |  |  | 2.4 |  | 7,840 |  |  | 16.1 |  |
| Software-Related Services | 76,988 |  |  | 3.5 |  | 70,760 |  |  | 3.4 |  | 6,228 |  |  | 8.8 |  |
| Total Software and Software-Related Services | 133,415 |  |  | 6.1 |  | 119,347 |  |  | 5.8 |  | 14,068 |  |  | 11.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 177,759 |  |  | 8.1 |  | 171,133 |  |  | 8.3 |  | 6,626 |  |  | 3.9 |  |
| Installation and Deployment | 89,487 |  |  | 4.1 |  | 84,011 |  |  | 4.1 |  | 5,476 |  |  | 6.5 |  |
| Consulting and Network Design | 29,103 |  |  | 1.3 |  | 28,969 |  |  | 1.4 |  | 134 |  |  | 0.5 |  |
| Total Global Services | 296,349 |  |  | 13.5 |  | 284,113 |  |  | 13.8 |  | 12,236 |  |  | 4.3 |  |
| Consolidated revenue | $ | 2,194,930 |  |  | 100.0 |  | $ | 2,057,238 |  |  | 100.0 |  | $ | 137,692 |  |  | 6.7 |  |

[0000936395-18-000037:mdna:140]
[same as prior period, unchanged from 0000936395-18-000024:mdna:139]

[0000936395-18-000037:mdna:141]
[same as prior period, unchanged from 0000936395-18-000024:mdna:140]

[0000936395-18-000037:mdna:142]
[same as prior period, unchanged from 0000936395-18-000024:mdna:141]

[0000936395-18-000037:mdna:143]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $115.1 million of our Converged Packet Optical products, partially offset by a product line decrease of $3.7 million of our Packet Networking products. |

[0000936395-18-000037:mdna:144]
| ◦ | Converged Packet Optical sales primarily reflect a sales increase of $181.7 million of our Waveserver stackable interconnect system, primarily due to increased sales to Web-scale providers, which, as we continue to diversify, represent a growing portion of our business. This increase was partially offset by sales decreases of $26.5 million of our 5410/5430 Reconfigurable Switching Systems, $23.1 million of our 6500 Packet-Optical Platform and $10.5 million of our Z-Series Packet-Optical Platform. The decrease in sales of our 5410/5430 Reconfigurable Switching Systems are primarily due to decreased sales to communications service providers and submarine network operators. The decrease in sales of our 6500 Packet-Optical Platform are primarily due to decreased sales to cable and multiservice operators, AT&T and government customers, partially offset by increased sales to Web-scale providers and sales through our strategic partnership with Ericsson. |

[0000936395-18-000037:mdna:145]
| ◦ | Packet Networking sales primarily reflect a sales decrease of $33.1 million of our 3000 and 5000 families of service delivery and aggregation switches, partially offset by sales increases of $15.2 million of our packet networking platform independent software and $11.7 million of our 8700 Packetwave Platform. The sales decrease of our 3000 and 5000 families primarily reflects decreased sales to AT&T, partially offset by increased sales to other communications service providers. |

[0000936395-18-000037:mdna:146]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $7.8 million of our software platforms and $6.2 million in our software-related services platforms. The increase in our software platform sales primarily reflects increases of $10.9 million in sales of our Blue Planet MCP software platform, $4.8 of our Blue Planet Intelligent Automation Platform and $1.3 million of our Ethernet Services Manager, partially offset by decreases of $3.8 million in sales of our OneControl Unified Management System and $3.2 in sales of our Optical Suite Release. The increase in our software-related services platforms primarily reflects sales increases of $2.8 million in our software subscriptions, $1.8 million in our software training services and $1.6 million in services supporting our Blue Planet Intelligent Automation Platform. |

[0000936395-18-000037:mdna:147]
37

[0000936395-18-000037:mdna:148]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $6.6 million of our maintenance support and training services and $5.5 million of our installation and deployment services. |

[0000936395-18-000037:mdna:149]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The revenue increase from our APAC region for the nine months ended July 31, 2018 was primarily driven by increased sales in India and Japan as well as our continued execution of our strategy to capture new market share with communications service providers in the region. The revenue increase from our EMEA region for the nine months ended July 31, 2018 was primarily driven by increased sales to communications service providers and Web-scale customers. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000037:mdna:150]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,331,148 |  |  | 60.6 |  | $ | 1,295,539 |  |  | 63.0 |  | $ | 35,609 |  |  | 2.7 |  |
| EMEA | 341,785 |  |  | 15.6 |  | 293,387 |  |  | 14.3 |  | 48,398 |  |  | 16.5 |  |
| CALA | 87,136 |  |  | 4.0 |  | 120,826 |  |  | 5.8 |  | (33,690 | ) |  | (27.9 | ) |
| APAC | 434,861 |  |  | 19.8 |  | 347,486 |  |  | 16.9 |  | 87,375 |  |  | 25.1 |  |
| Total | $ | 2,194,930 |  |  | 100.0 |  | $ | 2,057,238 |  |  | 100.0 |  | $ | 137,692 |  |  | 6.7 |  |

[0000936395-18-000037:mdna:151]
[same as prior period, unchanged from 0000936395-18-000024:mdna:151]

[0000936395-18-000037:mdna:152]
[same as prior period, unchanged from 0000936395-18-000024:mdna:152]

[0000936395-18-000037:mdna:153]
[same as prior period, unchanged from 0000936395-18-000024:mdna:153]

[0000936395-18-000037:mdna:154]
| • | North America revenue primarily reflects increases of $22.9 million within our Networking Platforms segment and $16.0 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $3.2 million within our Global Services segment. |

[0000936395-18-000037:mdna:155]
| ◦ | Networking Platforms revenue primarily reflects a product line increase of $44.3 million of Converged Packet Optical sales, partially offset by a product line decrease of $21.4 million of Packet Networking sales. |

[0000936395-18-000037:mdna:156]
| ▪ | The revenue increase within Converged Packet Optical sales primarily reflects an increase of $149.8 million in sales of our Waveserver stackable interconnect system, partially offset by decreases in sales of $81.1 million of our 6500 Packet-Optical Platform, $14.7 million of our 5410/5430 Reconfigurable Switching Systems and $7.1 million of our Z-Series Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. The decrease in sales of our 6500 Packet-Optical Platform are primarily due to decreased sales to communications services providers, cable and multiservice operators, AT&T and government customers, partially offset by increased sales to Web-scale providers and sales through our strategic partnership with Ericsson. The decrease in sales of our 5410/5430 Reconfigurable Switching Systems are primarily due to decreased sales to communications service providers, government customers and submarine network operators. |

[0000936395-18-000037:mdna:157]
| ▪ | The revenue decrease within Packet Networking primarily reflects a decrease of $36.0 million in sales of our 3000 and 5000 families of service delivery and aggregation switches, primarily reflecting reduced sales to AT&T. This decrease was partially offset by a revenue increase of $15.2 million in sales of our packet networking platform independent software. |

[0000936395-18-000037:mdna:158]
| ◦ | Software and Software-Related Services revenue primarily reflects increases of $11.8 million of our software platforms and $4.2 million in our software-related services platforms. The increase in our software platform sales primarily reflects an increase of $10.7 million in sales of our Blue Planet MCP software platform, $5.7 of our Blue Planet Intelligent Automation Platform and $0.8 million of our Ethernet Services Manager, partially offset by decreases of $1.5 million in sales of our OneControl Unified Management System and $2.9 in sales of our Optical Suite Release. The increase in our software-related services platforms primarily reflects sales increases of $1.6 million in services supporting our Blue Planet Intelligent Automation Platform, $1.4 million in our software subscriptions and $1.4 million in our software training services. |

[0000936395-18-000037:mdna:159]
| • | EMEA revenue primarily reflects increases of $36.9 million within our Networking Platforms segment and $14.2 million within our Global Services segment, partially offset by a revenue decrease of $2.7 million within our Software and Software-Related Services segment. |

[0000936395-18-000037:mdna:160]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $40.5 million in Converged Packet Optical sales partially offset by a product line decrease of $3.5 million in Packet Networking sales. The increase in Converged Packet Optical sales primarily reflects an increase of $26.2 million in sales from our Waveserver stackable interconnect system to Web-scale providers. The increase in Converged Packet Optical sales also reflects an increase of $15.0 million in sales from our 6500 Packet-Optical Platform to communications service providers and Web-scale providers. |

[0000936395-18-000037:mdna:161]
| ◦ | Global Services segment revenue primarily reflects increases of $7.0 million for our installation and deployment services and $6.4 million for our maintenance and training support services. These increases primarily reflect increased sales to communications service providers. |

[0000936395-18-000037:mdna:162]
| • | CALA revenue primarily reflects decreases of $31.3 million within our Networking Platforms segment and $3.5 million within our Global Services segment. These decreases were partially offset by a revenue increase of $1.1 million within our Software and Software-Related Services segment. The decrease in CALA revenue primarily relates to decreased sales to a certain cable and multiservice operator in Argentina and certain communications service providers in Brazil. |

[0000936395-18-000037:mdna:163]
| • | APAC revenue primarily reflects increases of $82.9 million within our Networking Platforms segment and $4.7 million within our Global Services segment. These revenue increases primarily represent increases in sales in India and Japan of $56.2 million and $30.4 million, respectively. |

[0000936395-18-000037:mdna:164]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $60.2 million in Converged Packet Optical sales and $22.8 million of Packet Networking sales. |

[0000936395-18-000037:mdna:165]
| ▪ | Converged Packet Optical revenue primarily reflects increases of $67.2 million in sales of our 6500 Packet-Optical Platform and $5.5 million in sales of our Waveserver stackable interconnect system. The increase in sales of our 6500 Packet-Optical Platform primarily reflect increased sales to certain communications service providers and government customers. The increase in sales of our Waveserver stackable interconnect system primarily reflect increased sales to certain communications service providers. These increases were partially offset by a revenue decrease of $8.7 million in sales of our 5410/5430 Reconfigurable Switching Systems primarily due to decreased sales to certain communications service providers. |

[0000936395-18-000037:mdna:166]
| ▪ | Packet Networking revenue primarily reflects increases of $12.5 million in sales of our 8700 Packetwave Platform and $10.2 million in sales of our 3000 and 5000 families of service delivery and aggregation switches primarily due to increased sales to a certain communication service provider in India. |

[0000936395-18-000037:mdna:167]
[same as prior period, unchanged from 0000936395-18-000024:mdna:167]

[0000936395-18-000037:mdna:168]
[same as prior period, unchanged from 0000936395-18-000024:mdna:168]

[0000936395-18-000037:mdna:169]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 2,194,930 |  |  | 100.0 |  | $ | 2,057,238 |  |  | 100.0 |  | $ | 137,692 |  |  | 6.7 |  |
| Total cost of goods sold | 1,278,315 |  |  | 58.2 |  | 1,137,137 |  |  | 55.3 |  | 141,178 |  |  | 12.4 |  |
| Gross profit | $ | 916,615 |  |  | 41.8 |  | $ | 920,101 |  |  | 44.7 |  | $ | (3,486 | ) |  | (0.4 | ) |

[0000936395-18-000037:mdna:170]
[same as prior period, unchanged from 0000936395-18-000024:mdna:170]

[0000936395-18-000037:mdna:171]
[same as prior period, unchanged from 0000936395-18-000024:mdna:171]

[0000936395-18-000037:mdna:172]
[same as prior period, unchanged from 0000936395-18-000024:mdna:172]

[0000936395-18-000037:mdna:173]
39

[0000936395-18-000037:mdna:174]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,821,593 |  |  | 100.0 |  | $ | 1,702,365 |  |  | 100.0 |  | $ | 119,228 |  |  | 7.0 |  |
| Product cost of goods sold | 1,085,574 |  |  | 59.6 |  | 955,303 |  |  | 56.1 |  | 130,271 |  |  | 13.6 |  |
| Product gross profit | $ | 736,019 |  |  | 40.4 |  | $ | 747,062 |  |  | 43.9 |  | $ | (11,043 | ) |  | (1.5 | ) |

[0000936395-18-000037:mdna:175]
[same as prior period, unchanged from 0000936395-18-000024:mdna:174]

[0000936395-18-000037:mdna:176]
[same as prior period, unchanged from 0000936395-18-000024:mdna:175]

[0000936395-18-000037:mdna:177]
[same as prior period, unchanged from 0000936395-18-000024:mdna:176]

[0000936395-18-000037:mdna:178]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 373,337 |  |  | 100.0 |  | $ | 354,873 |  |  | 100.0 |  | $ | 18,464 |  |  | 5.2 |
| Service cost of goods sold | 192,741 |  |  | 51.6 |  | 181,834 |  |  | 51.2 |  | 10,907 |  |  | 6.0 |
| Service gross profit | $ | 180,596 |  |  | 48.4 |  | $ | 173,039 |  |  | 48.8 |  | $ | 7,557 |  |  | 4.4 |

[0000936395-18-000037:mdna:179]
[same as prior period, unchanged from 0000936395-18-000024:mdna:178]

[0000936395-18-000037:mdna:180]
[same as prior period, unchanged from 0000936395-18-000024:mdna:179]

[0000936395-18-000037:mdna:181]
[same as prior period, unchanged from 0000936395-18-000024:mdna:180]

[0000936395-18-000037:mdna:182]
| • | Gross profit as a percentage of revenue reflects reduced product gross profit partially offset by improved services gross profit. We have encountered and expect to continue to encounter fluctuations or reductions in quarterly gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Our success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-18-000037:mdna:183]
| • | Gross profit on products as a percentage of product revenue decreased, primarily as a result of our strategy to capture market share as described above and the impact of early stages of international network deployments with communications service provider customers, including an increased concentration of lower margin “common” equipment sales and lower mix of higher margin packet networking sales, partially offset by increased sales of our higher margin software platforms and product cost reductions. |

[0000936395-18-000037:mdna:184]
| • | Gross profit on services as a percentage of services revenue slightly decreased, primarily as a result of reduced margins on our software-related services, which was primarily due to increased costs related to developing resources to promote our growth strategy. |

[0000936395-18-000037:mdna:185]
[same as prior period, unchanged from 0000936395-18-000024:mdna:184]

[0000936395-18-000037:mdna:186]
During the first nine months of fiscal 2018, approximately 50.8% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, British Pounds, Euros, Indian Rupees and Australian Dollars. During the first nine months of fiscal 2018 as compared to the first nine months of fiscal 2017, the U.S. Dollar fluctuated against these currencies.  Consequently, our operating expense reported in U.S. Dollars increased by approximately $15.1 million, or 1.9%, as compared to the first nine months of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000037:mdna:187]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 356,581 |  |  | 16.2 |  | $ | 356,221 |  |  | 17.3 |  | $ | 360 |  |  | 0.1 |  |
| Selling and marketing | 281,269 |  |  | 12.8 |  | 260,292 |  |  | 12.7 |  | 20,977 |  |  | 8.1 |  |
| General and administrative | 115,594 |  |  | 5.3 |  | 106,423 |  |  | 5.2 |  | 9,171 |  |  | 8.6 |  |
| Significant asset impairments and restructuring costs | 16,679 |  |  | 0.8 |  | 8,874 |  |  | 0.4 |  | 7,805 |  |  | 88.0 |  |
| Amortization of intangible assets | 11,083 |  |  | 0.5 |  | 29,368 |  |  | 1.4 |  | (18,285 | ) |  | (62.3 | ) |
| Acquisition and integration costs | 1,333 |  |  | 0.1 |  | — |  |  | — |  | 1,333 |  |  | 100.0 |  |
| Total operating expenses | $ | 782,539 |  |  | 35.7 |  | $ | 761,178 |  |  | 37.0 |  | $ | 21,361 |  |  | 2.8 |  |

[0000936395-18-000037:mdna:188]
[same as prior period, unchanged from 0000936395-18-000024:mdna:187]

[0000936395-18-000037:mdna:189]
[same as prior period, unchanged from 0000936395-18-000024:mdna:188]

[0000936395-18-000037:mdna:190]
[same as prior period, unchanged from 0000936395-18-000024:mdna:189]

[0000936395-18-000037:mdna:191]
| • | Research and development expense increased by $8.0 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $0.4 million. This increase primarily reflects increases of $9.1 million in employee and compensation costs, $2.5 million in technology and related costs, $1.6 million in depreciation expense and $1.3 million in professional services. These increases were partially offset by a benefit of $10.5 million for the ENCQOR grant reimbursement as discussed above, and decreases of $3.2 million in prototype expense and $1.2 million in facilities and information technology costs. |

[0000936395-18-000037:mdna:192]
| • | Selling and marketing expense increased by $6.2 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $21.0 million, primarily reflecting increases of $13.7 million in employee and compensation costs, $3.1 million in selling and marketing costs, $1.8 million in customer demonstration equipment and $1.6 million in travel and entertainment costs. |

[0000936395-18-000037:mdna:193]
| • | General and administrative expense increased by $9.2 million, primarily reflecting increases of $3.2 million in employee and compensation costs, $2.2 million in professional services and a payment of $2.8 million associated with a commercial litigation dispute with a former vendor. |

[0000936395-18-000037:mdna:194]
[same as prior period, unchanged from 0000936395-18-000024:mdna:194]

[0000936395-18-000037:mdna:195]
[same as prior period, unchanged from 0000936395-18-000024:mdna:123]

[0000936395-18-000037:mdna:196]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisition of Packet Design. |

[0000936395-18-000037:mdna:197]
[same as prior period, unchanged from 0000936395-18-000024:mdna:195]

[0000936395-18-000037:mdna:198]
[same as prior period, unchanged from 0000936395-18-000024:mdna:196]

[0000936395-18-000037:mdna:199]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 1,328 |  |  | 0.1 |  | $ | (3,396 | ) |  | (0.2 | ) |  | $ | 4,724 |  |  | 139.1 |  |
| Interest expense | $ | 40,376 |  |  | 1.8 |  | $ | 41,926 |  |  | 2.0 |  |  | $ | (1,550 | ) |  | (3.7 | ) |
| Provision for income taxes | $ | 503,695 |  |  | 22.9 |  | $ | 11,704 |  |  | 0.6 |  |  | $ | 491,991 |  |  | n/a |  |

[0000936395-18-000037:mdna:200]
[same as prior period, unchanged from 0000936395-18-000024:mdna:198]

[0000936395-18-000037:mdna:201]
[same as prior period, unchanged from 0000936395-18-000024:mdna:199]

[0000936395-18-000037:mdna:202]
[same as prior period, unchanged from 0000936395-18-000024:mdna:200]

[0000936395-18-000037:mdna:203]
[same as prior period, unchanged from 0000936395-18-000024:mdna:201]

[0000936395-18-000037:mdna:204]
| • | Interest and other income (loss), net primarily reflects a $4.7 million gain in interest income due to higher interest rates on our investments during fiscal 2018 and $2.9 million in debt modification expenses related to the 2022 Term Loan in the second quarter of fiscal 2017, partially offset by a $2.4 million unfavorable impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-18-000037:mdna:205]
[same as prior period, unchanged from 0000936395-18-000024:mdna:203]

[0000936395-18-000037:mdna:206]
| • | Provision for income taxes increased primarily due to the impact of significant additional tax expense resulting from the enactment of the Tax Act and reflects $431.3 million for the remeasurement of our net deferred tax assets and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. For additional information, see Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-18-000037:mdna:207]
[same as prior period, unchanged from 0000936395-18-000024:mdna:205]

[0000936395-18-000037:mdna:208]
[same as prior period, unchanged from 0000936395-18-000024:mdna:206]

[0000936395-18-000037:mdna:209]
|  | Quarter Ended July 31, |  |  |  |
|  | 2018 |  | 2017 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 181,603 |  |  | $ | 159,649 |  |  | $ | 21,954 |  |  | 13.8 |  |
| Software and Software-Related Services | $ | 9,305 |  |  | $ | 11,133 |  |  | $ | (1,828 | ) |  | (16.4 | ) |
| Global Services | $ | 39,502 |  |  | $ | 39,565 |  |  | $ | (63 | ) |  | (0.2 | ) |

[0000936395-18-000037:mdna:210]
[same as prior period, unchanged from 0000936395-18-000024:mdna:208]

[0000936395-18-000037:mdna:211]
[same as prior period, unchanged from 0000936395-18-000024:mdna:209]

[0000936395-18-000037:mdna:212]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, partially offset by reduced gross margin as described above, and higher research and development costs. |

[0000936395-18-000037:mdna:213]
| • | Software and Software-Related Services segment profit decreased, primarily due to lower software sales volume and reduced gross margin on software-related services, partially offset by lower research and development costs. |

[0000936395-18-000037:mdna:214]
[same as prior period, unchanged from 0000936395-18-000024:mdna:212]

[0000936395-18-000037:mdna:215]
|  | Nine Months Ended July 31, |  |  |  |  |
|  | 2018 |  | 2017 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 396,995 |  |  | $ | 423,859 |  |  | $ | (26,864 | ) |  | (6.3 | ) |
| Software and Software-Related Services | $ | 41,216 |  |  | $ | 23,384 |  |  | $ | 17,832 |  |  | 76.3 |  |
| Global Services | $ | 121,823 |  |  | $ | 116,637 |  |  | $ | 5,186 |  |  | 4.4 |  |

[0000936395-18-000037:mdna:216]
[same as prior period, unchanged from 0000936395-18-000024:mdna:214]

[0000936395-18-000037:mdna:217]
[same as prior period, unchanged from 0000936395-18-000024:mdna:215]

[0000936395-18-000037:mdna:218]
[same as prior period, unchanged from 0000936395-18-000024:mdna:216]

[0000936395-18-000037:mdna:219]
| • | Software and Software-Related Services segment profit increased, primarily due to higher sales volume and lower research and development costs, partially offset by reduced gross margin on software-related services. |

[0000936395-18-000037:mdna:220]
| • | Global Services segment profit increased, primarily due to higher sales volume. |

[0000936395-18-000037:mdna:221]
[same as prior period, unchanged from 0000936395-18-000024:mdna:219]

[0000936395-18-000037:mdna:222]
For the nine months ended July 31, 2018, we generated $161.2 million in cash to fund our operating needs, as our net loss (adjusted for non-cash charges) of $257.2 million exceeded our working capital requirements of $96.0 million. Our net loss (adjusted for non-cash charges) reflects a non-cash tax provision of $491.9 million primarily related to the enactment of the Tax Act. For additional information on the non-cash tax provision, see Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. For additional details on our cash from operations, see the discussion below entitled “Cash from Operations.”

[0000936395-18-000037:mdna:223]
Cash, cash equivalents and investments increased by $15.2 million during the first nine months of fiscal 2018. In addition to the cash from operations mentioned above, proceeds from issuance of equity under our employee stock purchase plans provided $22.7 million in cash during the nine months ended July 31, 2018. These provisions were sufficient to fund our investing activities for capital expenditures totaling $50.4 million and $40.4 million for our acquisition of Packet Design. For more information on this acquisition, see “Overview” above and Note 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provisions were also sufficient to fund our financing activities, including our new

[0000936395-18-000037:mdna:224]
stock repurchase program described below and in Note 15 and Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, which totaled $73.5 million in the period.

[0000936395-18-000037:mdna:225]
|  | July 31, 2018 |  | October 31, 2017 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 726,214 |  |  | $ | 640,513 |  |  | $ | 85,701 |  |
| Short-term investments in marketable debt securities | 228,940 |  |  | 279,133 |  |  | (50,193 | ) |
| Long-term investments in marketable debt securities | 29,465 |  |  | 49,783 |  |  | (20,318 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 984,619 |  |  | $ | 969,429 |  |  | $ | 15,190 |  |

[0000936395-18-000037:mdna:226]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of July 31, 2018 totaled $984.6 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 31, 2018, letters of credit totaling $62.9 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2018.

[0000936395-18-000037:mdna:227]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $62.9 million as of July 31, 2018. Our accumulated historical foreign earnings are generally held in either cash or short-term intercompany receivables, or have been used to fund investments in equipment, building, furniture and fixtures, or other assets and liabilities of our foreign operations. We currently intend to reinvest indefinitely our foreign earnings; however, we intend to study further the changes resulting from the enactment of the Tax Act, the costs of repatriation of such foreign earnings, and the current and future cash needs of our foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If we determine to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $23.0 million. See Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000037:mdna:228]
Intent to Cash Settle New 2018 Convertible Notes. Our $350 million in aggregate principal amount outstanding in 3.75% Convertible Senior Notes will mature on October 15, 2018. As more fully described in Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, following the settlement of an exchange offer on August 2, 2017, approximately $288.7 million in aggregate principal amount at maturity of 3.75% Convertible Senior Notes (Original) (“Original Notes”) were exchanged for 3.75% Convertible Senior Notes (New) (“New Notes”). The New Notes provide us with the option, at our election, to settle conversions for cash, shares of our common stock, or a combination of cash and shares. We have elected to settle any conversion of the New Notes prior to maturity in a combination of cash and shares, with the cash portion not to exceed an aggregate amount of approximately $400 million. Per the settlement provisions of the indenture governing conversion of the New Notes, an amount of $288.7 million (representing the aggregate principal amount) will be paid on October 15, 2018. To the extent our shares trade during the relevant settlement period in excess of the $20.17 per share conversion price, we will pay up to approximately $111.3 million of any amounts due in excess of the aggregate principal amount in cash, and any remaining amounts due will be settled in shares. These amounts will be settled during the first quarter of fiscal 2019.

[0000936395-18-000037:mdna:229]
Stock Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. As of August 31, 2018, an aggregate of $212.8 million of authorized funds remained under this repurchase program. For additional information, including our repurchase activities under the program, see Note 15 and Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-18-000037:mdna:230]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-18-000037:mdna:231]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations, including the settlement of the New Notes in a combination of cash and shares upon any conversions prior to maturity, as described above, and the repayment at maturity of the aggregate principal remaining outstanding on the Original Notes, as applicable, through at least the next 12 months.

[0000936395-18-000037:mdna:232]
[same as prior period, unchanged from 0000936395-18-000024:mdna:230]

[0000936395-18-000037:mdna:233]
The following sections set forth the components of our $161.2 million of cash generated from operating activities during the first nine months of fiscal 2018:

[0000936395-18-000037:mdna:234]
[same as prior period, unchanged from 0000936395-18-000024:mdna:232]

[0000936395-18-000037:mdna:235]
[same as prior period, unchanged from 0000936395-18-000024:mdna:233]

[0000936395-18-000037:mdna:236]
|  | Nine months ended |
|  | July 31, 2018 |
| Net loss | $ | (408,667 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 63,104 |  |
| Share-based compensation costs | 38,896 |  |
| Amortization of intangible assets | 18,196 |  |
| Deferred tax provision | 491,863 |  |
| Provision for inventory excess and obsolescence | 19,942 |  |
| Provision for warranty | 15,715 |  |
| Other | 18,164 |  |
| Net loss (adjusted for non-cash charges) | $ | 257,213 |  |

[0000936395-18-000037:mdna:237]
[same as prior period, unchanged from 0000936395-18-000024:mdna:235]

[0000936395-18-000037:mdna:238]
We used $96.0 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-18-000037:mdna:239]
|  | Nine months ended |
|  | July 31, 2018 |
| Cash used in accounts receivable | $ | (112,696 | ) |
| Cash provided by inventories | 17,751 |  |
| Cash used in prepaid expenses and other | (11,163 | ) |
| Cash provided by accounts payable, accruals and other obligations | 14,840 |  |
| Cash used in deferred revenue | (4,710 | ) |
| Total cash used for working capital | $ | (95,978 | ) |

[0000936395-18-000037:mdna:240]
[same as prior period, unchanged from 0000936395-18-000024:mdna:238]

[0000936395-18-000037:mdna:241]
| • | The $112.7 million of cash used by accounts receivable during the first nine months of fiscal 2018 reflects increased sales volume at the end of the third quarter of fiscal 2018; |

[0000936395-18-000037:mdna:242]
| • | The $17.8 million of cash provided by inventory during the first nine months of fiscal 2018 primarily reflects improved manufacturing efficiencies to meet customer delivery schedules; |

[0000936395-18-000037:mdna:243]
| • | The $11.2 million of cash used in prepaid expense and other during the first nine months of fiscal 2018 primarily reflects lower prepaid value added taxes partially offset by the ENCQOR grant reimbursement receivable which was recorded during fiscal 2018. For more information on the ENCQOR grant, see Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report; |

[0000936395-18-000037:mdna:244]
| • | The $14.8 million of cash provided by accounts payable, accruals and other obligations during the first nine months of fiscal 2018 primarily reflects increased inventory purchases at the end of the third quarter of fiscal 2018, partially offset by the timing of bonus payments to employees under our annual cash incentive compensation plan; and |

[0000936395-18-000037:mdna:245]
| • | The $4.7 million of cash used in deferred revenue during the first nine months of fiscal 2018 represents a decrease in advanced payments received from customers prior to revenue recognition. |

[0000936395-18-000037:mdna:246]
Our days sales outstanding (DSOs) for the first nine months of fiscal 2018 were 90 days, and our inventory turns for the first nine months of fiscal 2018 were 6.4.

[0000936395-18-000037:mdna:247]
[same as prior period, unchanged from 0000936395-18-000024:mdna:245]

[0000936395-18-000037:mdna:248]
[same as prior period, unchanged from 0000936395-18-000024:mdna:246]

[0000936395-18-000037:mdna:249]
|  | Nine months ended |
|  | July 31, 2018 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original)(1) | $ | 1,149 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New)(1) | 5,414 |  |
| 4.0% Convertible Senior Notes due December 15, 2020(2) | 7,500 |  |
| Term Loan due January 30, 2022 (3) | 12,483 |  |
| Interest rate swaps(4) | 270 |  |
| ABL Credit Facility(5) | 1,149 |  |
| Capital leases | 3,596 |  |
| Cash paid during period | $ | 31,561 |  |

[0000936395-18-000037:mdna:250]
| (1) | Interest on our outstanding Original Notes and our New Notes is payable on April 15 and October 15 of each year. |

[0000936395-18-000037:mdna:251]
| (2) | Interest on our outstanding 4.0% Convertible Senior Notes due December 15, 2020 is payable on June 15 and December 15 of each year. |

[0000936395-18-000037:mdna:252]
| (3) | Interest on the Term Loan due January 30, 2022 (the “2022 Term Loan”) is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of the third quarter of fiscal 2018, the interest rate on the 2022 Term Loan was 4.59%. |

[0000936395-18-000037:mdna:253]
| (4) | Our interest rate swaps fix 82% and 77% of the principal value of the 2022 Term Loan from July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during the periods described above will be 4.25% and 4.75%, respectively. |

[0000936395-18-000037:mdna:254]
| (5) | During the first nine months of fiscal 2018, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.1 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-18-000037:mdna:255]
[same as prior period, unchanged from 0000936395-18-000024:mdna:253]

[0000936395-18-000037:mdna:256]
[same as prior period, unchanged from 0000936395-18-000024:mdna:254]

[0000936395-18-000037:mdna:257]
[same as prior period, unchanged from 0000936395-18-000024:mdna:255]

[0000936395-18-000037:mdna:258]
[same as prior period, unchanged from 0000936395-18-000024:mdna:256]

[0000936395-18-000037:mdna:259]
[same as prior period, unchanged from 0000936395-18-000024:mdna:257]

[0000936395-18-000037:mdna:260]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-18-000037:mdna:261]
Our critical accounting policies and estimates have not changed materially since October 31, 2017, except for items listed below. For a discussion of our critical accounting policies and estimates, see Item 7 of Part II of our annual report on Form 10-K for the fiscal year ended October 31, 2017 (Management’s Discussion and Analysis of Financial Condition and Results of Operations).

[0000936395-18-000037:mdna:262]
[same as prior period, unchanged from 0000936395-18-000024:mdna:261]

[0000936395-18-000037:mdna:263]
[same as prior period, unchanged from 0000936395-18-000024:mdna:262]

[0000936395-18-000037:mdna:264]
The valuation allowance balance at July 31, 2018 was $144.9 million and the corresponding net deferred tax asset was $724.1 million. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending upon our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For example, the recently enacted Tax Act required us to write down our net deferred tax asset by approximately $431.3 million, due to the lower tax rate applied to the deferred tax asset. As this is a provisional estimate, it may be subject to change based upon availability of additional guidance and our continued assessment of the impact of the Tax Act on our business. As these amounts are finalized throughout fiscal 2018, our operating results may be materially adversely affected by a non-cash charge to reflect the change in value of these assets. For further discussion, see Note 6 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000037:mdna:265]
[same as prior period, unchanged from 0000936395-18-000024:mdna:264]

[0000936395-18-000037:mdna:266]
[same as prior period, unchanged from 0000936395-18-000024:mdna:265]

[0000936395-18-000037:mdna:267]
46
