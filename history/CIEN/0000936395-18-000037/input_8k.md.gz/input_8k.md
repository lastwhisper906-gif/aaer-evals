# CIEN 8-K — 0000936395-18-000031 filed 2018-08-30

## item codes, every 8-K on or before 2018-09-05

- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2018-09-05

- none on or before 2018-09-05

## item 2.02 — earnings release, exhibit 99.1

[0000936395-18-000031:8k_2_02:1]
EX-99.1
2
exhibit991-2018q3earningsp.htm
EXHIBIT 99.1

[0000936395-18-000031:8k_2_02:2]
Exhibit

[0000936395-18-000031:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-18-000031:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2018 Financial Results

[0000936395-18-000031:8k_2_02:5]
Year-over-year revenue growth of 12% reflects strong execution and another quarter of consistent performance

[0000936395-18-000031:8k_2_02:6]
HANOVER, Md. - August 30, 2018 - Ciena® Corporation (NYSE:  CIEN)

[0000936395-18-000031:8k_2_02:7]
| • | Q3 Revenue: $818.8 million, increasing 12.4% year over year |

[0000936395-18-000031:8k_2_02:8]
| • | Q3 Net Income per Share: $0.34 GAAP; $0.48 adjusted (non-GAAP) |

[0000936395-18-000031:8k_2_02:9]
| • | Share Repurchases: Repurchased approximately 1.4 million shares of common stock for an aggregate price of $35.6 million during the quarter |

[0000936395-18-000031:8k_2_02:10]
Ciena today announced unaudited financial results for its fiscal third quarter ended July 31, 2018.

[0000936395-18-000031:8k_2_02:11]
"The combination of continued execution against our strategy and robust, broad-based customer demand resulted in outstanding fiscal third quarter performance," said Gary B. Smith, president and CEO of Ciena. "With our diversification, global scale and innovation leadership, we remain confident in our business model and our ability to achieve our three-year financial targets.”

[0000936395-18-000031:8k_2_02:12]
For the fiscal third quarter 2018, Ciena reported revenue of $818.8 million as compared to $728.7 million for the fiscal third quarter 2017.

[0000936395-18-000031:8k_2_02:13]
Ciena's GAAP net income for the fiscal third quarter 2018 was $50.8 million, or $0.34 per diluted common share, which compares to a GAAP net income of $60.0 million, or $0.39 per diluted common share, for the fiscal third quarter 2017.

[0000936395-18-000031:8k_2_02:14]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2018 was $74.3 million, or $0.48 per diluted common share, which compares to an adjusted (non-GAAP) net income of $56.4 million, or $0.35 per diluted common share, for the fiscal third quarter 2017.

[0000936395-18-000031:8k_2_02:15]
Fiscal Third Quarter 2018 Performance Summary

[0000936395-18-000031:8k_2_02:16]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendix A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-18-000031:8k_2_02:17]
|  |  | GAAP Results |
|  |  | Q3 |  | Q3 |  | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 818.8 |  |  | $ | 728.7 |  |  | 12.4 | % |
| Gross margin |  | 42.9 | % |  | 45.0 | % |  | (2.1 | )% |
| Operating expense |  | $ | 266.3 |  |  | $ | 246.1 |  |  | 8.2 | % |
| Operating margin |  | 10.4 | % |  | 11.3 | % |  | (0.9 | )% |

[0000936395-18-000031:8k_2_02:18]
|  |  | Non-GAAP Results |
|  |  | Q3 |  | Q3 | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 818.8 |  |  | $ | 728.7 |  |  | 12.4 | % |
| Adj. gross margin |  | 43.4 | % |  | 45.5 | % |  | (2.1 | )% |
| Adj. operating expense |  | $ | 241.0 |  |  | $ | 229.3 |  |  | 5.1 | % |
| Adj. operating margin |  | 14.0 | % |  | 14.1 | % |  | (0.1 | )% |
| Adj. EBITDA |  | $ | 136.1 |  |  | $ | 122.8 |  |  | 10.8 | % |

[0000936395-18-000031:8k_2_02:19]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-18-000031:8k_2_02:20]
|  |  | Revenue by Segment |
|  |  | Q3 FY 2018 |  | Q3 FY 2017 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 592.8 |  |  | 72.5 |  | $ | 510.2 |  |  | 70.0 |
| Packet Networking |  | 84.6 |  |  | 10.3 |  | 82.1 |  |  | 11.3 |
| Total Networking Platforms |  | 677.4 |  |  | 82.8 |  | 592.3 |  |  | 81.3 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |
| Software Platforms |  | 14.3 |  |  | 1.7 |  | 18.4 |  |  | 2.5 |
| Software-Related Services |  | 26.9 |  |  | 3.3 |  | 23.9 |  |  | 3.3 |
| Total Software and Software-Related Services |  | 41.2 |  |  | 5.0 |  | 42.3 |  |  | 5.8 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 60.9 |  |  | 7.4 |  | 57.9 |  |  | 7.9 |
| Installation and Deployment |  | 31.3 |  |  | 3.8 |  | 27.4 |  |  | 3.8 |
| Consulting and Network Design |  | 8.0 |  |  | 1.0 |  | 8.8 |  |  | 1.2 |
| Total Global Services |  | 100.2 |  |  | 12.2 |  | 94.1 |  |  | 12.9 |
| Total |  | $ | 818.8 |  |  | 100.0 |  | $ | 728.7 |  |  | 100.0 |

[0000936395-18-000031:8k_2_02:21]
Additional Performance Metrics for Fiscal Third Quarter 2018

[0000936395-18-000031:8k_2_02:22]
|  |  | Revenue by Geographic Region |
|  |  | Q3 FY 2018 |  | Q3 FY 2017 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 497.0 |  |  | 60.7 |  | $ | 465.2 |  |  | 63.8 |
| Europe, Middle East and Africa |  | 122.2 |  |  | 14.9 |  | 96.1 |  |  | 13.2 |
| Caribbean and Latin America |  | 27.5 |  |  | 3.4 |  | 51.7 |  |  | 7.1 |
| Asia Pacific |  | 172.1 |  |  | 21.0 |  | 115.7 |  |  | 15.9 |
| Total |  | $ | 818.8 |  |  | 100.0 |  | $ | 728.7 |  |  | 100.0 |

[0000936395-18-000031:8k_2_02:23]
**  Denotes %  of total revenue

[0000936395-18-000031:8k_2_02:24]
| • | U.S. customers contributed 57.3% of total revenue |

[0000936395-18-000031:8k_2_02:25]
| • | Three customers accounted for greater than 10% of revenue and represented 33% of total revenue |

[0000936395-18-000031:8k_2_02:26]
| • | Cash and investments totaled $984.6 million |

[0000936395-18-000031:8k_2_02:27]
| • | Cash flow from operations totaled $88.1 million |

[0000936395-18-000031:8k_2_02:28]
| • | Free cash flow totaled $69.7 million |

[0000936395-18-000031:8k_2_02:29]
| • | Average days' sales outstanding (DSOs) were 80 |

[0000936395-18-000031:8k_2_02:30]
| • | Accounts receivable balance was $728.9 million |

[0000936395-18-000031:8k_2_02:31]
| • | Inventories totaled $227.9 million, including: |

[0000936395-18-000031:8k_2_02:32]
| ◦ | Raw materials: $54.0 million |

[0000936395-18-000031:8k_2_02:33]
| ◦ | Work in process: $11.1 million |

[0000936395-18-000031:8k_2_02:34]
| ◦ | Finished goods: $173.4 million |

[0000936395-18-000031:8k_2_02:35]
| ◦ | Deferred cost of sales: $38.5 million |

[0000936395-18-000031:8k_2_02:36]
| ◦ | Reserve for excess and obsolescence: $(49.1) million |

[0000936395-18-000031:8k_2_02:37]
| • | Product inventory turns were 7.0 |

[0000936395-18-000031:8k_2_02:38]
| • | Headcount totaled 5,889 |

[0000936395-18-000031:8k_2_02:39]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2018 Results

[0000936395-18-000031:8k_2_02:40]
Today, Thursday, August 30, 2018, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website supporting materials for its unaudited fiscal third quarter 2018 results.

[0000936395-18-000031:8k_2_02:41]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's fiscal third quarter outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-18-000031:8k_2_02:42]
Notes to Investors

[0000936395-18-000031:8k_2_02:43]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words

[0000936395-18-000031:8k_2_02:44]
such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "The combination of continued execution against our strategy and robust, broad-based customer demand resulted in outstanding fiscal third quarter performance."; "With our diversification, global scale and innovation leadership, we remain confident in our business model and our ability to achieve our three-year financial targets."

[0000936395-18-000031:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act, changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on June 6, 2018 and its Annual Report on Form 10-K filed with the SEC on December 22, 2017. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-18-000031:8k_2_02:46]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-18-000031:8k_2_02:47]
About Ciena.  Ciena (NYSE: CIEN) is a networking systems, services, and software company. We provide solutions that help our clients create more adaptive networks in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most sophisticated networks with automation and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-18-000031:8k_2_02:48]
CIENA CORPORATION

[0000936395-18-000031:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-18-000031:8k_2_02:50]
(in thousands, except per share data)

[0000936395-18-000031:8k_2_02:51]
(unaudited)

[0000936395-18-000031:8k_2_02:52]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 691,758 |  |  | $ | 610,742 |  |  | $ | 1,821,593 |  |  | $ | 1,702,365 |  |
| Services | 127,059 |  |  | 117,977 |  |  | 373,337 |  |  | 354,873 |  |
| Total revenue | 818,817 |  |  | 728,719 |  |  | 2,194,930 |  |  | 2,057,238 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 399,886 |  |  | 341,197 |  |  | 1,085,574 |  |  | 955,303 |  |
| Services | 67,388 |  |  | 59,446 |  |  | 192,741 |  |  | 181,834 |  |
| Total cost of goods sold | 467,274 |  |  | 400,643 |  |  | 1,278,315 |  |  | 1,137,137 |  |
| Gross profit | 351,543 |  |  | 328,076 |  |  | 916,615 |  |  | 920,101 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 121,133 |  |  | 117,729 |  |  | 356,581 |  |  | 356,221 |  |
| Selling and marketing | 95,395 |  |  | 86,739 |  |  | 281,269 |  |  | 260,292 |  |
| General and administrative | 38,212 |  |  | 35,569 |  |  | 115,594 |  |  | 106,423 |  |
| Significant asset impairments and restructuring costs | 6,359 |  |  | 2,203 |  |  | 16,679 |  |  | 8,874 |  |
| Amortization of intangible assets | 3,837 |  |  | 3,837 |  |  | 11,083 |  |  | 29,368 |  |
| Acquisition and integration costs | 1,333 |  |  | — |  |  | 1,333 |  |  | — |  |
| Total operating expenses | 266,269 |  |  | 246,077 |  |  | 782,539 |  |  | 761,178 |  |
| Income from operations | 85,274 |  |  | 81,999 |  |  | 134,076 |  |  | 158,923 |  |
| Interest and other income (loss), net | (1,543 | ) |  | (848 | ) |  | 1,328 |  |  | (3,396 | ) |
| Interest expense | (13,611 | ) |  | (13,415 | ) |  | (40,376 | ) |  | (41,926 | ) |
| Income before income taxes | 70,120 |  |  | 67,736 |  |  | 95,028 |  |  | 113,601 |  |
| Provision for income taxes 1 | 19,280 |  |  | 7,726 |  |  | 503,695 |  |  | 11,704 |  |
| Net income (loss) | $ | 50,840 |  |  | $ | 60,010 |  |  | $ | (408,667 | ) |  | $ | 101,897 |  |
| Net Income(loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income (loss) per common share | $ | 0.35 |  |  | $ | 0.42 |  |  | $ | (2.84 | ) |  | $ | 0.72 |  |
| Diluted net income (loss) per potential common share 2 | $ | 0.34 |  |  | $ | 0.39 |  |  | $ | (2.84 | ) |  | $ | 0.69 |  |
| Weighted average basic common shares outstanding | 143,400 |  |  | 142,464 |  |  | 143,766 |  |  | 141,631 |  |
| Weighted average dilutive potential common shares outstanding 3 | 159,998 |  |  | 172,112 |  |  | 143,766 |  |  | 164,431 |  |

[0000936395-18-000031:8k_2_02:53]
1.  The provision for income taxes for fiscal 2018 is primarily related to the enactment of the Tax Cuts and Jobs Act. These amounts are provisional and reflect management’s current estimates and current interpretations of the Tax Cuts and Jobs Act. These amounts may require adjustment in future periods as additional guidance under the Tax Cuts and Jobs Act becomes available and analysis of its provisions is completed. As of July 31, 2018, Ciena has net deferred tax assets of approximately $724.1 million, and consequently, over the near term, Ciena's cash taxes will continue to be primarily related to state taxes and tax expense of Ciena's foreign subsidiaries, which amounts have not historically been significant. Ciena's foreign and domestic income tax expense for the third quarter of fiscal 2018 and 2017 expected to be paid using cash was $8.8 million and $7.7 million, respectively. Ciena's foreign and domestic income tax expense for the nine months ended July 31, 2018 and 2017 expected to be paid using cash was $11.8 million and $11.7 million, respectively.

[0000936395-18-000031:8k_2_02:54]
2.  The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2018 requires adding back interest expense of approximately $0.5 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and approximately $2.6 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000031:8k_2_02:55]
The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2017 requires adding back interest expense of approximately $0.2 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $3.6 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and approximately $3.3 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000031:8k_2_02:56]
The calculation of GAAP diluted net income per common share for the first nine months of fiscal 2017 requires adding back interest expense of approximately $1.3 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, and approximately $10.8 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000031:8k_2_02:57]
3. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and restricted stock units, 3.0 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.0 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-18-000031:8k_2_02:58]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units, 1.7 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-18-000031:8k_2_02:59]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units, 4.0 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 and 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018.

[0000936395-18-000031:8k_2_02:60]
CIENA CORPORATION

[0000936395-18-000031:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-18-000031:8k_2_02:62]
(in thousands, except share data)

[0000936395-18-000031:8k_2_02:63]
(unaudited)

[0000936395-18-000031:8k_2_02:64]
|  | July 31, 2018 |  | October 31, 2017 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 726,214 |  |  | $ | 640,513 |  |
| Short-term investments | 228,940 |  |  | 279,133 |  |
| Accounts receivable, net | 728,940 |  |  | 622,183 |  |
| Inventories | 227,885 |  |  | 267,143 |  |
| Prepaid expenses and other | 192,497 |  |  | 197,339 |  |
| Total current assets | 2,104,476 |  |  | 2,006,311 |  |
| Long-term investments | 29,465 |  |  | 49,783 |  |
| Equipment, building, furniture and fixtures, net | 295,863 |  |  | 308,465 |  |
| Goodwill | 287,551 |  |  | 267,458 |  |
| Other intangible assets, net | 108,302 |  |  | 100,997 |  |
| Deferred tax asset, net | 724,087 |  |  | 1,155,104 |  |
| Other long-term assets | 72,951 |  |  | 63,593 |  |
| Total assets | $ | 3,622,695 |  |  | $ | 3,951,711 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 312,611 |  |  | $ | 260,098 |  |
| Accrued liabilities and other short-term obligations | 297,988 |  |  | 322,934 |  |
| Deferred revenue | 104,170 |  |  | 102,418 |  |
| Current portion of long-term debt | 353,669 |  |  | 352,293 |  |
| Total current liabilities | 1,068,438 |  |  | 1,037,743 |  |
| Long-term deferred revenue | 79,914 |  |  | 82,589 |  |
| Other long-term obligations | 108,884 |  |  | 111,349 |  |
| Long-term debt, net | 586,505 |  |  | 583,688 |  |
| Total liabilities | $ | 1,843,741 |  |  | $ | 1,815,369 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 143,050,180 and 143,043,227 shares issued and outstanding | 1,431 |  |  | 1,430 |  |
| Additional paid-in capital | 6,797,857 |  |  | 6,810,182 |  |
| Accumulated other comprehensive income (loss) | (8,705 | ) |  | (11,017 | ) |
| Accumulated deficit | (5,011,629 | ) |  | (4,664,253 | ) |
| Total stockholders’ equity | 1,778,954 |  |  | 2,136,342 |  |
| Total liabilities and stockholders’ equity | $ | 3,622,695 |  |  | $ | 3,951,711 |  |

[0000936395-18-000031:8k_2_02:65]
CIENA CORPORATION

[0000936395-18-000031:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-18-000031:8k_2_02:67]
(in thousands)

[0000936395-18-000031:8k_2_02:68]
(unaudited)

[0000936395-18-000031:8k_2_02:69]
|  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |
| Cash flows provided by operating activities: |  |  |  |
| Net income (loss) | $ | (408,667 | ) |  | $ | 101,897 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 63,104 |  |  | 55,873 |  |
| Share-based compensation costs | 38,896 |  |  | 36,843 |  |
| Amortization of intangible assets | 18,196 |  |  | 39,721 |  |
| Deferred taxes | 491,863 |  |  | — |  |
| Provision for inventory excess and obsolescence | 19,942 |  |  | 28,727 |  |
| Provision for warranty | 15,715 |  |  | 5,188 |  |
| Other | 18,164 |  |  | 21,076 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (112,696 | ) |  | (80,652 | ) |
| Inventories | 17,751 |  |  | (93,896 | ) |
| Prepaid expenses and other | (11,163 | ) |  | (26,450 | ) |
| Accounts payable, accruals and other obligations | 14,840 |  |  | (5,960 | ) |
| Deferred revenue | (4,710 | ) |  | 13,978 |  |
| Net cash provided by operating activities | 161,235 |  |  | 96,345 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (50,386 | ) |  | (76,004 | ) |
| Purchase of available for sale securities | (217,715 | ) |  | (189,802 | ) |
| Proceeds from maturities of available for sale securities | 290,000 |  |  | 260,003 |  |
| Settlement of foreign currency forward contracts, net | 4,759 |  |  | (1,619 | ) |
| Acquisition of business, net of cash acquired | (40,412 | ) |  | — |  |
| Purchase of cost method investment | (1,433 | ) |  | — |  |
| Net cash used in investing activities | (15,187 | ) |  | (7,422 | ) |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (3,000 | ) |  | (232,554 | ) |
| Payment for modification of term loans | — |  |  | (93,625 | ) |
| Payment of capital lease obligations | (2,811 | ) |  | (2,650 | ) |
| Repurchases of common stock-repurchase program | (73,512 | ) |  | — |  |
| Proceeds from issuance of common stock | 22,735 |  |  | 20,395 |  |
| Net cash used in financing activities | (56,588 | ) |  | (308,434 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (3,759 | ) |  | 1,436 |  |
| Net increase (decrease) in cash and cash equivalents | 85,701 |  |  | (218,075 | ) |
| Cash and cash equivalents at beginning of period | 640,513 |  |  | 777,615 |  |
| Cash and cash equivalents at end of period | $ | 726,214 |  |  | $ | 559,540 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 31,561 |  |  | $ | 33,861 |  |
| Cash paid during the period for income taxes, net | $ | 20,099 |  |  | $ | 26,793 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 5,677 |  |  | $ | 6,012 |  |
| Building subject to capital lease | $ | — |  |  | $ | 50,370 |  |
| Non-cash financing activities |  |  |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 1,275 |  |  | $ | — |  |

[0000936395-18-000031:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |
|  |  | Quarter Ended July 31, |
|  |  | 2018 |  | 2017 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 351,543 |  |  | $ | 328,076 |  |
| Share-based compensation-products |  | 783 |  |  | 709 |  |
| Share-based compensation-services |  | 618 |  |  | 619 |  |
| Amortization of intangible assets |  | 2,534 |  |  | 2,417 |  |
| Total adjustments related to gross profit |  | 3,935 |  |  | 3,745 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 355,478 |  |  | $ | 331,821 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.4 | % |  | 45.5 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 266,269 |  |  | $ | 246,077 |  |
| Share-based compensation-research and development |  | 3,082 |  |  | 3,139 |  |
| Share-based compensation-sales and marketing |  | 3,417 |  |  | 3,242 |  |
| Share-based compensation-general and administrative |  | 4,538 |  |  | 4,321 |  |
| Significant asset impairments and restructuring costs |  | 6,359 |  |  | 2,203 |  |
| Amortization of intangible assets |  | 3,837 |  |  | 3,837 |  |
| Acquisition and integration costs |  | 1,333 |  |  | — |  |
| Legal settlement |  | 2,753 |  |  | — |  |
| Total adjustments related to operating expense |  | 25,319 |  |  | 16,742 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 240,950 |  |  | $ | 229,335 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 85,274 |  |  | $ | 81,999 |  |
| Total adjustments related to gross profit |  | 3,935 |  |  | 3,745 |  |
| Total adjustments related to operating expense |  | 25,319 |  |  | 16,742 |  |
| Total adjustments related to income from operations |  | 29,254 |  |  | 20,487 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 114,528 |  |  | $ | 102,486 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 14.0 | % |  | 14.1 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 50,840 |  |  | $ | 60,010 |  |
| Exclude GAAP provision for income taxes |  | 19,280 |  |  | 7,726 |  |
| Income before income taxes |  | $ | 70,120 |  |  | $ | 67,736 |  |
| Total adjustments related to income from operations |  | 29,254 |  |  | 20,487 |  |
| Non-cash interest expense |  | 793 |  |  | 535 |  |
| Adjusted income before income taxes |  | $ | 100,167 |  |  | $ | 88,758 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 25,913 |  |  | 32,397 |  |
| Adjusted (non-GAAP) net income |  | $ | 74,254 |  |  | $ | 56,361 |  |
| Weighted average basic common shares outstanding |  | 143,400 |  |  | 142,464 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 159,998 |  |  | 172,112 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.34 |  |  | $ | 0.39 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.48 |  |  | $ | 0.35 |  |

[0000936395-18-000031:8k_2_02:71]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and restricted stock units, 3.0 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018, 3.0 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018, and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020. |

[0000936395-18-000031:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units, 1.7 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-18-000031:8k_2_02:73]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2018 requires adding back interest expense of approximately $0.5 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $2.1 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-18-000031:8k_2_02:74]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2017 requires adding back interest expense of approximately $0.2 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $2.2 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $1.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-18-000031:8k_2_02:75]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |
|  |  | Quarter Ended July 31, |
|  |  | 2018 |  | 2017 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 50,840 |  |  | $ | 60,010 |  |
| Add: Interest expense |  | 13,611 |  |  | 13,415 |  |
| Less: Interest and other income (loss), net |  | (1,543 | ) |  | (848 | ) |
| Add: Provision for income taxes |  | 19,280 |  |  | 7,726 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 21,704 |  |  | 20,325 |  |
| Add: Amortization of intangible assets |  | 6,371 |  |  | 6,254 |  |
| EBITDA |  | $ | 113,349 |  |  | $ | 108,578 |  |
| Add: Shared-based compensation cost |  | 12,337 |  |  | 12,013 |  |
| Add: Significant asset impairments and restructuring costs |  | 6,359 |  |  | 2,203 |  |
| Add: Acquisition and integration costs |  | 1,333 |  |  | — |  |
| Add: Legal settlement |  | 2,753 |  |  | — |  |
| Adjusted EBITDA |  | $ | 136,131 |  |  | $ | 122,794 |  |

[0000936395-18-000031:8k_2_02:76]
* * *

[0000936395-18-000031:8k_2_02:77]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-18-000031:8k_2_02:78]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-18-000031:8k_2_02:79]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-18-000031:8k_2_02:80]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-18-000031:8k_2_02:81]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors' costs and severance and other employment-related costs related to Ciena's recent acquisition of Packet Design. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-18-000031:8k_2_02:82]
| • | Legal settlement - costs incurred as a result of a settlement associated with a commercial dispute with a former vendor. |

[0000936395-18-000031:8k_2_02:83]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-18-000031:8k_2_02:84]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 25.87% for the third fiscal quarter of 2018, and 36.5% for the third fiscal quarter of 2017. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
