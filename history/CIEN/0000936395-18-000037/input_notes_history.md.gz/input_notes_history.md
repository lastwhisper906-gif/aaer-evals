# CIEN note change history — 0000936395-18-000024 → 0000936395-18-000037


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-09-05):
[0000936395-18-000037:note_history:1]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million ($45.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the nine months ended July 31,2018, Ciena recorded a CAD$13.5 million ($10.5 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to July 31, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants. As of July 31, 2018, amounts receivable from this grant were CAD$8.3 million ($6.3 million).

- changed (2018-09-05):
[0000936395-18-000037:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference was held before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2018-06-06, similarity 0.9948):
[0000936395-18-000024:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference is scheduled before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- changed (2018-09-05):
[0000936395-18-000037:note_history:3]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena’s Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.
  (was, 2018-06-06, similarity 0.9989):
[0000936395-18-000024:note_history:3]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena's Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

- removed (2018-09-05):
[0000936395-18-000024:note_history:4]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation ("ENCQOR") project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.0 million) in reimbursement by the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the second quarter of fiscal 2018, Ciena recorded a CAD$10.3 million (approximately $8.1 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to April 30, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:5]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2017 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.
  (was, 2018-06-06, similarity 0.9952):
[0000936395-18-000024:note_history:5]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the "SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2017 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:6]
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.
  (was, 2018-06-06, similarity 0.9951):
[0000936395-18-000024:note_history:6]
Except for the changes in certain policies described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.

- changed (2018-09-05):
[0000936395-18-000037:note_history:7]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 18 below.
  (was, 2018-06-06, similarity 0.8447):
[0000936395-18-000024:note_history:7]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 17 below.

- changed (2018-09-05):
[0000936395-18-000037:note_history:8]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-01 (“ASU 2017-01”), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.
  (was, 2018-06-06, similarity 0.9855):
[0000936395-18-000024:note_history:8]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

- changed (2018-09-05):
[0000936395-18-000037:note_history:9]
In August 2017, the FASB issued ASU No. 2017-12 (“ASU 2017-12”), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity’s risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena’s Condensed Consolidated Financial Statements.
  (was, 2018-06-06, similarity 0.9961):
[0000936395-18-000024:note_history:9]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

- changed (2018-09-05):
[0000936395-18-000037:note_history:10]
In March 2016, the FASB issued ASU No. 2016-09 (“ASU 2016-09”), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.
  (was, 2018-06-06, similarity 0.9983):
[0000936395-18-000024:note_history:10]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

- changed (2018-09-05):
[0000936395-18-000037:note_history:11]
In May 2014, the FASB issued ASU No. 2014-09 (“ASU 2014-09”), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.
  (was, 2018-06-06, similarity 0.9846):
[0000936395-18-000024:note_history:11]
In May 2014, the FASB issued ASU No. 2014-09 ("ASU 2014-09"), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

- changed (2018-09-05):
[0000936395-18-000037:note_history:12]
For multiple element software arrangements where vendor-specific objective evidence (“VSOE”) of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. The adoption of ASU 2014-09 will require Ciena to determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.
  (was, 2018-06-06, similarity 0.957):
[0000936395-18-000024:note_history:12]
For multiple element software arrangements where vendor-specific objective evidence ("VSOE") of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of ASU 2014-09 will require that it determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

- changed (2018-09-05):
[0000936395-18-000037:note_history:13]
Ciena has considered the impact of the guidance in Accounting Standards Codification (“ASC”) 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.
  (was, 2018-06-06, similarity 0.9928):
[0000936395-18-000024:note_history:13]
Ciena has considered the impact of the guidance in Accounting Standards Codification ("ASC") 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

- changed (2018-09-05):
[0000936395-18-000037:note_history:14]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.
  (was, 2018-06-06, similarity 0.9973):
[0000936395-18-000024:note_history:14]
In February 2016, the FASB issued ASU No. 2016-02 ("ASU 2016-02"), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

- added (2018-09-05):
[0000936395-18-000037:note_history:15]
In August 2018, the FASB issued ASU No. 2018-09 (“ASU 2018-09”), Codification Improvements which does not prescribe any new accounting guidance, but instead makes minor improvements and clarifications of several different FASB Accounting Standards Codification areas based on comments and suggestions made by various stakeholders. Certain updates are applicable immediately while others provide for a transition period to adopt as part of the next fiscal year beginning after December 15, 2018.  Ciena is currently evaluating this guidance to determine the impact it may have on the consolidated financial statements.

- added (2018-09-05):
[0000936395-18-000037:note_history:16]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

- added (2018-09-05):
[0000936395-18-000037:note_history:17]
In August 2018, the FASB issued ASU No. 2018-14 (“ASU 2018-14”), Compensation -Retirement Benefits - Defined Benefit Plans which modifies the disclosure requirements on company-sponsored defined benefit plans. ASU 2018-14 is effective for Ciena beginning in the first quarter of fiscal year 2021, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

- added (2018-09-05):
[0000936395-18-000037:note_history:18]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. ASU 2018-15 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:19]
The net carrying value of Ciena’s Term Loan due January 30, 2022 (the “2022 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-06-06, similarity 0.9811):
[0000936395-18-000024:note_history:19]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:20]
|  |  | July 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 392,972 |  |
  (was, 2018-06-06, similarity 0.963):
[0000936395-18-000024:note_history:20]
|  |  | April 30, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 392,972 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:21]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.6 million at July 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.5 million and $0.4 million during the first nine months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.
  (was, 2018-06-06, similarity 0.9866):
[0000936395-18-000024:note_history:21]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.7 million at April 30, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.4 million and$0.2 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.

- changed (2018-09-05):
[0000936395-18-000037:note_history:22]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of the 2022 Term Loan were as follows as of July 31, 2018 (in thousands):
  (was, 2018-06-06, similarity 0.9519):
[0000936395-18-000024:note_history:22]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of April 30, 2018 (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:23]
The following table sets forth the carrying value and the estimated fair value of the 2022 Term Loan (in thousands):
  (was, 2018-06-06, similarity 0.9652):
[0000936395-18-000024:note_history:23]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:24]
|  |  | July 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 396,481 |  |
  (was, 2018-06-06, similarity 0.9707):
[0000936395-18-000024:note_history:24]
|  |  | April 30, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 397,980 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:25]
| (1) | The 2022 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2018-06-06, similarity 0.9646):
[0000936395-18-000024:note_history:25]
| (1) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- changed (2018-09-05):
[0000936395-18-000037:note_history:26]
The net carrying values of Ciena’s outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-06-06, similarity 0.9934):
[0000936395-18-000024:note_history:26]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:27]
|  |  | July 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,435 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 194,717 |  |
|  |  | $ | 549,311 |  |  | $ | 543,009 |  |
  (was, 2018-06-06, similarity 0.9838):
[0000936395-18-000024:note_history:27]
|  |  | April 30, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,028 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 194,717 |  |
|  |  | $ | 547,180 |  |  | $ | 543,009 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:28]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $0.9 million at July 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.2 million during both the first nine months of fiscal 2018 and 2017. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.
  (was, 2018-06-06, similarity 0.9118):
[0000936395-18-000024:note_history:28]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.3 million at April 30, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.8 million and $1.0 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

- changed (2018-09-05):
[0000936395-18-000037:note_history:29]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of July 31, 2018 (in thousands):
  (was, 2018-06-06, similarity 0.9769):
[0000936395-18-000024:note_history:29]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of April 30, 2018 (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:30]
| (1) | Includes accretion of principal at a rate of 1.85% per year. |
  (was, 2018-06-06, similarity 0.9925):
[0000936395-18-000024:note_history:30]
| (1) | Includes accretion of principal at a rate of 1.85% per year |

- changed (2018-09-05):
[0000936395-18-000037:note_history:31]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2018:
  (was, 2018-06-06, similarity 0.9787):
[0000936395-18-000024:note_history:31]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2018:

- changed (2018-09-05):
[0000936395-18-000037:note_history:32]
|  |  | July 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 77,047 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,435 |  |  | 363,078 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 233,269 |  |
|  |  | $ | 549,311 |  |  | $ | 673,394 |  |
  (was, 2018-06-06, similarity 0.9855):
[0000936395-18-000024:note_history:32]
|  |  | April 30, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 80,907 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,028 |  |  | 381,268 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 265,125 |  |
|  |  | $ | 547,180 |  |  | $ | 727,300 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2018-09-05):
[0000936395-18-000037:note_history:33]
As of the dates indicated, investments are comprised of the following (in thousands):

- added (2018-09-05):
[0000936395-18-000037:note_history:34]
|  | July 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 199,415 |  |  | $ | — |  |  | (418 | ) |  | $ | 198,997 |  |
| Included in long-term investments | 29,538 |  |  | — |  |  | (73 | ) |  | 29,465 |  |
|  | $ | 228,953 |  |  | $ | — |  |  | $ | (491 | ) |  | $ | 228,462 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,941 |  |  | 2 |  |  | — |  |  | $ | 29,943 |  |
|  | $ | 29,941 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,943 |  |

- added (2018-09-05):
[0000936395-18-000037:note_history:35]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:36]
|  | July 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 199,415 |  |  | $ | — |  |  | (418 | ) |  | $ | 198,997 |  |
| Included in long-term investments | 29,538 |  |  | — |  |  | (73 | ) |  | 29,465 |  |
|  | $ | 228,953 |  |  | $ | — |  |  | $ | (491 | ) |  | $ | 228,462 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,941 |  |  | 2 |  |  | — |  |  | $ | 29,943 |  |
|  | $ | 29,941 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,943 |  |
  (was, 2018-06-06, similarity 0.9915):
[0000936395-18-000024:note_history:36]
|  | April 30, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,291 |  |  | $ | — |  |  | (601 | ) |  | $ | 238,690 |  |
| Included in long-term investments | 59,066 |  |  | — |  |  | (171 | ) |  | 58,895 |  |
|  | $ | 298,357 |  |  | $ | — |  |  | $ | (772 | ) |  | $ | 297,585 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,892 |  |  | 2 |  |  | — |  |  | $ | 29,894 |  |
|  | $ | 29,892 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,894 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:37]
The following table summarizes the final legal maturities of debt investments at July 31, 2018 (in thousands):
  (was, 2018-06-06, similarity 0.9668):
[0000936395-18-000024:note_history:37]
The following table summarizes the final legal maturities of debt investments at April 30, 2018 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:38]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2018:
  (was, 2018-06-06, similarity 0.9787):
[0000936395-18-000024:note_history:38]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2018:

- changed (2018-09-05):
[0000936395-18-000037:note_history:39]
|  |  | July 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 77,047 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,435 |  |  | 363,078 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 233,269 |  |
|  |  | $ | 549,311 |  |  | $ | 673,394 |  |
  (was, 2018-06-06, similarity 0.9855):
[0000936395-18-000024:note_history:39]
|  |  | April 30, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 80,907 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,028 |  |  | 381,268 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 265,125 |  |
|  |  | $ | 547,180 |  |  | $ | 727,300 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:40]
The net carrying values of Ciena’s outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-06-06, similarity 0.9934):
[0000936395-18-000024:note_history:40]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:41]
|  |  | July 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,435 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 194,717 |  |
|  |  | $ | 549,311 |  |  | $ | 543,009 |  |
  (was, 2018-06-06, similarity 0.9838):
[0000936395-18-000024:note_history:41]
|  |  | April 30, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,028 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 194,717 |  |
|  |  | $ | 547,180 |  |  | $ | 543,009 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:42]
The net carrying value of Ciena’s Term Loan due January 30, 2022 (the “2022 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-06-06, similarity 0.9811):
[0000936395-18-000024:note_history:42]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:43]
|  |  | July 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 392,972 |  |
  (was, 2018-06-06, similarity 0.963):
[0000936395-18-000024:note_history:43]
|  |  | April 30, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 392,972 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:44]
The following table sets forth the carrying value and the estimated fair value of the 2022 Term Loan (in thousands):
  (was, 2018-06-06, similarity 0.9652):
[0000936395-18-000024:note_history:44]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:45]
|  |  | July 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 396,481 |  |
  (was, 2018-06-06, similarity 0.9707):
[0000936395-18-000024:note_history:45]
|  |  | April 30, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 397,980 |  |

- changed (2018-09-05):
[0000936395-18-000037:note_history:46]
| (1) | The 2022 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2018-06-06, similarity 0.9646):
[0000936395-18-000024:note_history:46]
| (1) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:47]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of July 31, 2018 (in thousands):
  (was, 2018-06-06, similarity 0.9769):
[0000936395-18-000024:note_history:47]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of April 30, 2018 (in thousands):

- changed (2018-09-05):
[0000936395-18-000037:note_history:48]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of the 2022 Term Loan were as follows as of July 31, 2018 (in thousands):
  (was, 2018-06-06, similarity 0.9519):
[0000936395-18-000024:note_history:48]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of April 30, 2018 (in thousands):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-09-05):
[0000936395-18-000037:note_history:49]
From the end of the third quarter of fiscal 2018 through August 31, 2018, Ciena repurchased an additional 472,542 shares of its common stock, for an aggregate purchase price of $12.4 million at an average price of $26.25 per share, inclusive of repurchases pending settlement. As of August 31, 2018, Ciena has repurchased an aggregate of 3,500,660 shares and has an aggregate of $212.8 million of authorized funds remaining under its Stock Repurchase Program.
  (was, 2018-06-06, similarity 0.881):
[0000936395-18-000024:note_history:49]
From the end of the second quarter of fiscal 2018 through June 4, 2018, Ciena repurchased an additional 611,942 shares of its common stock, for an aggregate purchase price of $15.4 million at an average price of $25.15 per share, inclusive of repurchases pending settlement. As of June 4, 2018, Ciena has an aggregate of $245.5 million of authorized funds remaining under its Stock Repurchase Program.

- added (2018-09-05):
[0000936395-18-000037:note_history:50]
Stock Repurchases Related to Restricted Stock Unit Tax Withholding

- added (2018-09-05):
[0000936395-18-000037:note_history:51]
Historically, Ciena satisfied employee tax withholding obligations due upon the vesting of restricted stock units (RSUs) through directed open market sales to cover the employee tax obligations. Beginning in the fourth quarter of fiscal 2018, Ciena will change this practice to repurchase shares of common stock delivered with respect to such RSUs in settlement of employee tax withholding obligations due upon the vesting of RSUs. The purchase price for the shares of Ciena’s stock repurchased will be reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.

- added (2018-09-05):
[0000936395-18-000037:note_history:52]
Settlement of Conversions of New Notes

- added (2018-09-05):
[0000936395-18-000037:note_history:53]
Ciena has elected to settle any conversion of the New Notes prior to maturity in a combination of cash and shares, with the cash portion not to exceed an aggregate amount of approximately $400 million. Per the settlement provisions of the indenture governing conversion of the New Notes, an amount of $288.7 million (representing the aggregate principal amount) will be paid in cash on October 15, 2018. To the extent Ciena’s shares trade during the relevant settlement period in excess of the $20.17 per share conversion price, Ciena will pay up to approximately $111.3 million of any amounts due in excess of the aggregate principal amount in cash, and any remaining amounts due will be settled in shares. These amounts will be settled during the first quarter of fiscal 2019.

- changed (2018-09-05):
[0000936395-18-000037:note_history:54]
DonRiver Acquisition
  (was, 2018-06-06, similarity 0.6222):
[0000936395-18-000024:note_history:54]
Packet Design Acquisition

- added (2018-09-05):
[0000936395-18-000037:note_history:55]
On August 31, 2018, Ciena entered into a definitive agreement to acquire privately-held DonRiver Holdings, LLC, a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. The transaction is expected to close during Ciena’s fourth quarter of fiscal 2018 and is subject to customary closing conditions.

- removed (2018-09-05):
[0000936395-18-000024:note_history:56]
On May 30, 2018, Ciena entered into a definitive agreement to acquire privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. The transaction is expected to close during Ciena’s fiscal third quarter 2018 and is subject to customary closing conditions.
