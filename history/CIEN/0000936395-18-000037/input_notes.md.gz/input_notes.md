# CIEN notes — 0000936395-18-000037


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-18-000037:notes:1]
[same as prior period, unchanged from 0000936395-18-000024:notes:1]

[0000936395-18-000037:notes:2]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates.


## cien:ScheduleOfStockRepurchaseProgramTableTextBlock

[0000936395-18-000037:notes:3]
[same as prior period, unchanged from 0000936395-18-000024:notes:3]

[0000936395-18-000037:notes:4]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2017 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 3,028,118 |  |  | 24.70 |  |  | 74,787 |  |
| Cumulative balance at July 31, 2018 | 3,028,118 |  |  | $ | 24.70 |  |  | $ | 74,787 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-18-000037:notes:5]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-18-000037:notes:6]
Outstanding Term Loan Payable

[0000936395-18-000037:notes:7]
2022 Term Loan

[0000936395-18-000037:notes:8]
The net carrying value of Ciena’s Term Loan due January 30, 2022 (the “2022 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000037:notes:9]
|  |  | July 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 392,972 |  |

[0000936395-18-000037:notes:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.6 million at July 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.5 million and $0.4 million during the first nine months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.

[0000936395-18-000037:notes:11]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of the 2022 Term Loan were as follows as of July 31, 2018 (in thousands):

[0000936395-18-000037:notes:12]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 395,000 |  |  | $ | (1,580 | ) |  | $ | (2,557 | ) |  | $390,863 |

[0000936395-18-000037:notes:13]
The following table sets forth the carrying value and the estimated fair value of the 2022 Term Loan (in thousands):

[0000936395-18-000037:notes:14]
|  |  | July 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 396,481 |  |

[0000936395-18-000037:notes:15]
| (1) | The 2022 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-18-000037:notes:16]
Outstanding Convertible Notes Payable

[0000936395-18-000037:notes:17]
The net carrying values of Ciena’s outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000037:notes:18]
|  |  | July 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,435 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 194,717 |  |
|  |  | $ | 549,311 |  |  | $ | 543,009 |  |

[0000936395-18-000037:notes:19]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $0.9 million at July 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.2 million during both the first nine months of fiscal 2018 and 2017. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

[0000936395-18-000037:notes:20]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of July 31, 2018 (in thousands):

[0000936395-18-000037:notes:21]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (36 | ) |  | $ | 61,234 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (125 | ) |  | $ | (170 | ) |  | $ | 288,435 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 207,809 |  |  | $ | (7,437 | ) |  | $ | (730 | ) |  | $ | 199,642 |  |  | $ | 43,131 |  |

[0000936395-18-000037:notes:22]
| (1) | Includes accretion of principal at a rate of 1.85% per year. |

[0000936395-18-000037:notes:23]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2018:

[0000936395-18-000037:notes:24]
|  |  | July 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 77,047 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,435 |  |  | 363,078 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 233,269 |  |
|  |  | $ | 549,311 |  |  | $ | 673,394 |  |

[0000936395-18-000037:notes:25]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-18-000037:notes:26]
BUSINESS COMBINATIONS

[0000936395-18-000037:notes:27]
Packet Design, LLC Acquisition

[0000936395-18-000037:notes:28]
On July 2, 2018, Ciena acquired Packet Design, LLC (“Packet Design”), a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics, in a cash transaction for approximately $41 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-18-000037:notes:29]
During the third quarter of fiscal 2018, Ciena incurred approximately $1.3 million of acquisition-related costs associated with this transaction. These costs and expenses include fees associated with financial, legal and accounting advisors and severance and other employment-related costs, including payments to certain former Packet Design employees.

[0000936395-18-000037:notes:30]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-18-000037:notes:31]
|  | Amount |
| Cash and cash equivalents | $ | 642 |  |
| Accounts receivable | 1,525 |  |
| Prepaid expenses and other | 450 |  |
| Equipment, furniture and fixtures | 31 |  |
| Goodwill | 20,304 |  |
| Customer relationships and contracts | 2,200 |  |
| Developed technology | 21,900 |  |
| Accounts payable | (165 | ) |
| Accrued liabilities | (657 | ) |
| Deferred revenue | (5,176 | ) |
| Total purchase consideration | $ | 41,054 |  |

[0000936395-18-000037:notes:32]
Customer relationships and contracts represent agreements with existing Packet Design customers and have an estimated useful life of three years.

[0000936395-18-000037:notes:33]
Developed technology represents purchased technology that had reached technological feasibility and for which Packet Design had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-18-000037:notes:34]
The goodwill generated from the acquisition of Packet Design is primarily related to expected synergies. The total goodwill amount was recorded in the Software and Software-Related Services segment.

[0000936395-18-000037:notes:35]
Pro forma disclosures have not been included due to immateriality.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-18-000037:notes:36]
COMMITMENTS AND CONTINGENCIES

[0000936395-18-000037:notes:37]
Canadian Grant

[0000936395-18-000037:notes:38]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million ($45.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the nine months ended July 31,2018, Ciena recorded a CAD$13.5 million ($10.5 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to July 31, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants. As of July 31, 2018, amounts receivable from this grant were CAD$8.3 million ($6.3 million).

[0000936395-18-000037:notes:39]
Foreign Tax Contingencies

[0000936395-18-000037:notes:40]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-18-000037:notes:41]
Litigation

[0000936395-18-000037:notes:42]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference was held before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-18-000037:notes:43]
Internal Investigations

[0000936395-18-000037:notes:44]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena’s Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

[0000936395-18-000037:notes:45]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-18-000037:notes:46]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-18-000037:notes:47]
[same as prior period, unchanged from 0000936395-18-000024:notes:37]

[0000936395-18-000037:notes:48]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”) for the nine months ended July 31, 2018:

[0000936395-18-000037:notes:49]
|  | Unrealized |  | Unrealized Loss on |  | Unrealized Gain on |  | Cumulative Foreign Currency |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swap |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (59 | ) |  | (9 | ) |  | 5,330 |  |  | (2,161 | ) |  | 3,101 |  |
| Amounts reclassified from AOCI | — |  |  | (1,058 | ) |  | 269 |  |  | — |  |  | (789 | ) |
| Balance at July 31, 2018 | $ | (510 | ) |  | $ | (2,453 | ) |  | $ | 5,817 |  |  | $ | (11,559 | ) |  | $ | (8,705 | ) |

[0000936395-18-000037:notes:50]
The following table summarizes the changes in AOCI for the nine months ended July 31, 2017:

[0000936395-18-000037:notes:51]
|  | Unrealized Gain/(Loss) on |  | Unrealized Gain (Loss) on |  | Unrealized Gain on |  | Cumulative Foreign Currency |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swap |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (533 | ) |  | 896 |  |  | 4,838 |  |  | 11,891 |  |  | 17,092 |  |
| Amounts reclassified from AOCI | — |  |  | 2,010 |  |  | (268 | ) |  | — |  |  | 1,742 |  |
| Balance at July 31, 2017 | $ | (394 | ) |  | $ | 1,815 |  |  | $ | (1,397 | ) |  | $ | (5,519 | ) |  | $ | (5,495 | ) |

[0000936395-18-000037:notes:52]
[same as prior period, unchanged from 0000936395-18-000024:notes:42]


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0000936395-18-000037:notes:53]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-18-000037:notes:54]
|  | July 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 199,415 |  |  | $ | — |  |  | (418 | ) |  | $ | 198,997 |  |
| Included in long-term investments | 29,538 |  |  | — |  |  | (73 | ) |  | 29,465 |  |
|  | $ | 228,953 |  |  | $ | — |  |  | $ | (491 | ) |  | $ | 228,462 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,941 |  |  | 2 |  |  | — |  |  | $ | 29,943 |  |
|  | $ | 29,941 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,943 |  |

[0000936395-18-000037:notes:55]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-18-000037:notes:56]
[same as prior period, unchanged from 0000936395-18-000024:notes:43]

[0000936395-18-000037:notes:57]
[same as prior period, unchanged from 0000936395-18-000024:notes:44]

[0000936395-18-000037:notes:58]
As of July 31, 2018 and October 31, 2017, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, and its Euro denominated revenue. The notional amount of these contracts was approximately $134.6 million and $86.1 million as of July 31, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 18 months or less and have been designated as cash flow hedges.

[0000936395-18-000037:notes:59]
During the first nine months of fiscal 2018 and fiscal 2017, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $98.2 million and $83.4 million as of July 31, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-18-000037:notes:60]
[same as prior period, unchanged from 0000936395-18-000024:notes:47]

[0000936395-18-000037:notes:61]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 13 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix 82% and 77% of the principal value of the 2022 Term Loan from July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25% and 4.75%, respectively. The total notional amount of interest rate swaps in effect as of July 31, 2018 was $321.6 million. The total notional amount of interest rate swaps in effect as of October 31, 2017 was $389.6 million.

[0000936395-18-000037:notes:62]
[same as prior period, unchanged from 0000936395-18-000024:notes:49]

[0000936395-18-000037:notes:63]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 5 and Note 8 above.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-18-000037:notes:64]
[same as prior period, unchanged from 0000936395-18-000024:notes:51]

[0000936395-18-000037:notes:65]
[same as prior period, unchanged from 0000936395-18-000024:notes:52]

[0000936395-18-000037:notes:66]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Product costs | $ | 783 |  |  | $ | 709 |  |  | $ | 2,279 |  |  | $ | 1,978 |  |
| Service costs | 618 |  |  | 619 |  |  | 1,965 |  |  | 1,926 |  |
| Share-based compensation expense included in cost of sales | 1,401 |  |  | 1,328 |  |  | 4,244 |  |  | 3,904 |  |
| Research and development | 3,082 |  |  | 3,139 |  |  | 10,133 |  |  | 10,001 |  |
| Sales and marketing | 3,417 |  |  | 3,242 |  |  | 10,505 |  |  | 9,628 |  |
| General and administrative | 4,538 |  |  | 4,321 |  |  | 14,121 |  |  | 13,191 |  |
| Share-based compensation expense included in operating expense | 11,037 |  |  | 10,702 |  |  | 34,759 |  |  | 32,820 |  |
| Share-based compensation expense capitalized in inventory, net | (101 | ) |  | (17 | ) |  | (107 | ) |  | 119 |  |
| Total share-based compensation | $ | 12,337 |  |  | $ | 12,013 |  |  | $ | 38,896 |  |  | $ | 36,843 |  |

[0000936395-18-000037:notes:67]
As of July 31, 2018, total unrecognized share-based compensation expense was approximately $86.7 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerShareTextBlock

[0000936395-18-000037:notes:68]
[same as prior period, unchanged from 0000936395-18-000024:notes:55]

[0000936395-18-000037:notes:69]
[same as prior period, unchanged from 0000936395-18-000024:notes:56]

[0000936395-18-000037:notes:70]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income (loss) | $ | 50,840 |  |  | $ | 60,010 |  |  | $ | (408,667 | ) |  | $ | 101,897 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 (1) | — |  |  | 246 |  |  | — |  |  | 1,343 |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original) | 464 |  |  | 3,572 |  |  | — |  |  | 10,750 |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | 2,624 |  |  | 3,323 |  |  | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | 53,928 |  |  | $ | 67,151 |  |  | $ | (408,667 | ) |  | $ | 113,990 |  |

[0000936395-18-000037:notes:71]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Basic weighted average shares outstanding | 143,400 |  |  | 142,464 |  |  | 143,766 |  |  | 141,631 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 1,330 |  |  | 1,386 |  |  | — |  |  | 1,401 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 (1) | — |  |  | 1,708 |  |  | — |  |  | 4,043 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New) (2) | 3,032 |  |  | — |  |  | — |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original) | 3,038 |  |  | 17,356 |  |  | — |  |  | 17,356 |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | 9,198 |  |  | 9,198 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 159,998 |  |  | 172,112 |  |  | 143,766 |  |  | 164,431 |  |

[0000936395-18-000037:notes:72]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Basic EPS | $ | 0.35 |  |  | $ | 0.42 |  |  | $ | (2.84 | ) |  | $ | 0.72 |  |
| Diluted EPS | $ | 0.34 |  |  | $ | 0.39 |  |  | $ | (2.84 | ) |  | $ | 0.69 |  |

[0000936395-18-000037:notes:73]
[same as prior period, unchanged from 0000936395-18-000024:notes:60]

[0000936395-18-000037:notes:74]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Shares underlying stock options and restricted stock units | 318 |  |  | 682 |  |  | 2,183 |  |  | 988 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) | — |  |  | — |  |  | 3,038 |  |  | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) (2) | — |  |  | — |  |  | 2,125 |  |  | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | — |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 318 |  |  | 682 |  |  | 16,544 |  |  | 10,186 |  |

[0000936395-18-000037:notes:75]
(1)    Ciena’s 0.875% convertible senior notes were paid at maturity during the third quarter of fiscal 2017.

[0000936395-18-000037:notes:76]
(2)    Upon any conversion of the outstanding 3.75% Convertible Senior Notes due 2018 (New) (the “New Notes”), Ciena intends to settle the principal amount thereof in cash. See Note 19 below. Accordingly, Ciena uses the treasury stock method for calculating any potential dilutive effect of the conversion spread on diluted net income per share, if applicable. The 14.3 million shares underlying the New Notes will have a dilutive impact on diluted net income per share of common stock when the average market price of Ciena common stock for a given period exceeds the conversion price of $20.17 per share for the New Notes. During the third quarter of fiscal 2018, the average market price of Ciena common stock was $25.59. As a result, for the quarter ended July 31, 2018, the conversion spread for the New Notes of 3.0 million shares is included in the calculation of the denominator. For the nine months ended July 31, 2018, the conversion spread for the New Notes of 2.1 million shares is excluded from the calculation of the denominator as their inclusion would have had an anti-dilutive effect.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-18-000037:notes:77]
[same as prior period, unchanged from 0000936395-18-000024:notes:64]

[0000936395-18-000037:notes:78]
|  | July 31, 2018 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Money market funds | $ | 579,413 |  |  | $ | — |  |  | $ | 579,413 |  |
| U.S. government obligations | — |  |  | 228,462 |  |  | 228,462 |  |
| Commercial paper | — |  |  | 69,860 |  |  | 69,860 |  |
| Foreign currency forward contracts | — |  |  | 668 |  |  | 668 |  |
| Forward starting interest rate swaps | — |  |  | 6,667 |  |  | 6,667 |  |
| Total assets measured at fair value | $ | 579,413 |  |  | $ | 305,657 |  |  | $ | 885,070 |  |
| Liabilities: |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,968 |  |  | $ | 2,968 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,968 |  |  | $ | 2,968 |  |

[0000936395-18-000037:notes:79]
[same as prior period, unchanged from 0000936395-18-000024:notes:66]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-18-000037:notes:80]
[same as prior period, unchanged from 0000936395-18-000024:notes:67]

[0000936395-18-000037:notes:81]
|  | July 31, 2018 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Cash equivalents | $ | 579,413 |  |  | $ | 39,917 |  |  | $ | 619,330 |  |
| Short-term investments | — |  |  | 228,940 |  |  | 228,940 |  |
| Prepaid expenses and other | — |  |  | 668 |  |  | 668 |  |
| Long-term investments | — |  |  | 29,465 |  |  | 29,465 |  |
| Other long-term assets | — |  |  | 6,667 |  |  | 6,667 |  |
| Total assets measured at fair value | $ | 579,413 |  |  | $ | 305,657 |  |  | $ | 885,070 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,968 |  |  | $ | 2,968 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,968 |  |  | $ | 2,968 |  |

[0000936395-18-000037:notes:82]
[same as prior period, unchanged from 0000936395-18-000024:notes:69]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-18-000037:notes:83]
[same as prior period, unchanged from 0000936395-18-000024:notes:70]

[0000936395-18-000037:notes:84]
[same as prior period, unchanged from 0000936395-18-000024:notes:71]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-18-000037:notes:85]
[same as prior period, unchanged from 0000936395-18-000024:notes:72]

[0000936395-18-000037:notes:86]
On December 22, 2017, the Tax Cuts and Jobs Act (the “Tax Act”) was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries that were previously tax deferred. As a fiscal-year taxpayer, certain provisions of the Tax Act impact Ciena in fiscal 2018, including the change in the federal tax rate and the one-time transition tax, while other provisions will be effective at the beginning of fiscal 2019, including the implementation of a modified territorial tax system, other changes to how foreign earnings are subject to U.S. tax, and adoption of an alternative tax system.

[0000936395-18-000037:notes:87]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena has computed its income tax expense for the October 31, 2018 fiscal year using a blended federal tax rate of 23.4%. The 21% federal tax rate is expected to apply to Ciena’s fiscal year ending October 31, 2019 and each year thereafter. Ciena remeasured its deferred tax assets and liabilities (“DTA”) using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-18-000037:notes:88]
During the nine months ended July 31, 2018, Ciena recorded a provisional tax expense of $503.7 million, primarily related to the Tax Act and consisting of the following: a $431.3 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Act and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S.

[0000936395-18-000037:notes:89]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional amounts due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. Ciena has determined that the $45.6 million of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries and the $431.3 million of tax expense for DTA remeasurement were each provisional amounts and reasonable estimates as of July 31, 2018. Estimates used in the provisional amounts include the anticipated reversal pattern of the gross DTA plus the earnings and profits, cash position at the end of fiscal year 2018, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000936395-18-000037:notes:90]
Ciena currently intends to reinvest indefinitely its foreign earnings outside the U.S. However, Ciena intends to continue to study changes enacted by the Tax Act, costs of repatriation and the current and future cash needs of foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If Ciena determines to repatriate these earnings, the provisional amount of unrecognized deferred income tax liability related to these foreign withholding taxes would be approximately $23.0 million. There are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-18-000037:notes:91]
[same as prior period, unchanged from 0000936395-18-000024:notes:78]

[0000936395-18-000037:notes:92]
|  | July 31, |  | October 31, |
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 35,022 |  |  | $ | 56,597 |  |
| Depreciation and amortization | 317,526 |  |  | 451,385 |  |
| NOL and credit carry forward | 496,327 |  |  | 803,622 |  |
| Other | 20,077 |  |  | 29,398 |  |
| Gross deferred tax assets | 868,952 |  |  | 1,341,002 |  |
| Valuation allowance | (144,865 | ) |  | (185,898 | ) |
| Deferred tax asset, net of valuation allowance | $ | 724,087 |  |  | $ | 1,155,104 |  |

[0000936395-18-000037:notes:93]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. See Note 2 above and Note 15 below. As of July 31, 2018, Ciena continues to maintain a valuation allowance of $144.9 million. This valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-18-000037:notes:94]
[same as prior period, unchanged from 0000936395-18-000024:notes:81]

[0000936395-18-000037:notes:95]
[same as prior period, unchanged from 0000936395-18-000024:notes:82]

[0000936395-18-000037:notes:96]
|  | July 31, 2018 |  | October 31, 2017 |
| Raw materials | $ | 54,003 |  |  | $ | 52,898 |  |
| Work-in-process | 11,100 |  |  | 18,623 |  |
| Finished goods | 173,419 |  |  | 185,488 |  |
| Deferred cost of goods sold | 38,525 |  |  | 61,340 |  |
|  | 277,047 |  |  | 318,349 |  |
| Provision for excess and obsolescence | (49,162 | ) |  | (51,206 | ) |
|  | $ | 227,885 |  |  | $ | 267,143 |  |

[0000936395-18-000037:notes:97]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2018, Ciena recorded a provision for excess and obsolescence of $19.9 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-18-000037:notes:98]
The following table summarizes the final legal maturities of debt investments at July 31, 2018 (in thousands):

[0000936395-18-000037:notes:99]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 229,356 |  |  | $ | 228,940 |  |
| Due in 1-2 years | 29,538 |  |  | 29,465 |  |
|  | $ | 258,894 |  |  | $ | 258,405 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-18-000037:notes:100]
SHORT-TERM AND LONG-TERM INVESTMENTS


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-18-000037:notes:101]
Newly Issued Accounting Standards - Effective

[0000936395-18-000037:notes:102]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-01 (“ASU 2017-01”), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

[0000936395-18-000037:notes:103]
In August 2017, the FASB issued ASU No. 2017-12 (“ASU 2017-12”), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity’s risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena’s Condensed Consolidated Financial Statements.

[0000936395-18-000037:notes:104]
In March 2016, the FASB issued ASU No. 2016-09 (“ASU 2016-09”), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

[0000936395-18-000037:notes:105]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-18-000037:notes:106]
In May 2014, the FASB issued ASU No. 2014-09 (“ASU 2014-09”), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

[0000936395-18-000037:notes:107]
For multiple element software arrangements where vendor-specific objective evidence (“VSOE”) of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. The adoption of ASU 2014-09 will require Ciena to determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-18-000037:notes:108]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-18-000037:notes:109]
Ciena has considered the impact of the guidance in Accounting Standards Codification (“ASC”) 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-18-000037:notes:110]
Ciena expects to implement ASU 2014-09 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-18-000037:notes:111]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-18-000037:notes:112]
In August 2018, the FASB issued ASU No. 2018-09 (“ASU 2018-09”), Codification Improvements which does not prescribe any new accounting guidance, but instead makes minor improvements and clarifications of several different FASB Accounting Standards Codification areas based on comments and suggestions made by various stakeholders. Certain updates are applicable immediately while others provide for a transition period to adopt as part of the next fiscal year beginning after December 15, 2018.  Ciena is currently evaluating this guidance to determine the impact it may have on the consolidated financial statements.

[0000936395-18-000037:notes:113]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

[0000936395-18-000037:notes:114]
In August 2018, the FASB issued ASU No. 2018-14 (“ASU 2018-14”), Compensation -Retirement Benefits - Defined Benefit Plans which modifies the disclosure requirements on company-sponsored defined benefit plans. ASU 2018-14 is effective for Ciena beginning in the first quarter of fiscal year 2021, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

[0000936395-18-000037:notes:115]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. ASU 2018-15 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-18-000037:notes:116]
[same as prior period, unchanged from 0000936395-18-000024:notes:102]

[0000936395-18-000037:notes:117]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2017 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000037:notes:118]
[same as prior period, unchanged from 0000936395-18-000024:notes:104]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-18-000037:notes:119]
[same as prior period, unchanged from 0000936395-18-000024:notes:105]

[0000936395-18-000037:notes:120]
[same as prior period, unchanged from 0000936395-18-000024:notes:106]

[0000936395-18-000037:notes:121]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest income | $ | 3,620 |  |  | $ | 1,820 |  |  | $ | 9,276 |  |  | $ | 4,609 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 2,182 |  |  | 834 |  |  | 4,351 |  |  | (891 | ) |
| Foreign currency exchange loss | (6,879 | ) |  | (2,946 | ) |  | (11,670 | ) |  | (4,071 | ) |
| Modification of term loan | — |  |  | — |  |  | — |  |  | (2,924 | ) |
| Other | (466 | ) |  | (556 | ) |  | (629 | ) |  | (119 | ) |
| Interest and other income (loss), net | $ | (1,543 | ) |  | $ | (848 | ) |  | $ | 1,328 |  |  | $ | (3,396 | ) |

[0000936395-18-000037:notes:122]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $11.7 million and $4.1 million in foreign currency exchange rate losses during the first nine months of fiscal 2018 and fiscal 2017, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the remeasurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. For the first nine months of fiscal 2018, the majority of the foreign currency exchange rate losses relate to Ciena’s Argentinian and Brazilian subsidiaries owing U.S. Dollars to Ciena Corporation. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. During the first nine months of fiscal 2018, Ciena recorded gains of $4.4 million from non-hedge designated foreign currency forward contracts. During the first nine months of fiscal 2017, Ciena recorded losses of $0.9 million from non-hedge designated foreign currency forward contracts.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-18-000037:notes:123]
[same as prior period, unchanged from 0000936395-18-000024:notes:109]

[0000936395-18-000037:notes:124]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 181,603 |  |  | $ | 159,649 |  |  | $ | 396,995 |  |  | $ | 423,859 |  |
| Software and Software-Related Services | 9,305 |  |  | 11,133 |  |  | 41,216 |  |  | 23,384 |  |
| Global Services | 39,502 |  |  | 39,565 |  |  | 121,823 |  |  | 116,637 |  |
| Total segment profit | 230,410 |  |  | 210,347 |  |  | 560,034 |  |  | 563,880 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 95,395 |  |  | 86,739 |  |  | 281,269 |  |  | 260,292 |  |
| General and administrative | 38,212 |  |  | 35,569 |  |  | 115,594 |  |  | 106,423 |  |
| Significant asset impairments and restructuring costs | 6,359 |  |  | 2,203 |  |  | 16,679 |  |  | 8,874 |  |
| Amortization of intangible assets | 3,837 |  |  | 3,837 |  |  | 11,083 |  |  | 29,368 |  |
| Acquisition and integration costs | 1,333 |  |  | — |  |  | 1,333 |  |  | — |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (15,154 | ) |  | (14,263 | ) |  | (39,048 | ) |  | (45,322 | ) |
| Less: Provision for income taxes | 19,280 |  |  | 7,726 |  |  | 503,695 |  |  | 11,704 |  |
| Consolidated net income (loss) | $ | 50,840 |  |  | $ | 60,010 |  |  | $ | (408,667 | ) |  | $ | 101,897 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-18-000037:notes:125]
[same as prior period, unchanged from 0000936395-18-000024:notes:111]

[0000936395-18-000037:notes:126]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 592,892 |  |  | $ | 510,226 |  |  | $ | 1,548,189 |  |  | $ | 1,433,137 |  |
| Packet Networking | 84,559 |  |  | 82,121 |  |  | 216,977 |  |  | 220,641 |  |
| Total Networking Platforms | 677,451 |  |  | 592,347 |  |  | 1,765,166 |  |  | 1,653,778 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 14,307 |  |  | 18,395 |  |  | 56,427 |  |  | 48,587 |  |
| Software-Related Services | 26,876 |  |  | 23,856 |  |  | 76,988 |  |  | 70,760 |  |
| Total Software and Software-Related Services | 41,183 |  |  | 42,251 |  |  | 133,415 |  |  | 119,347 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 60,897 |  |  | 57,902 |  |  | 177,759 |  |  | 171,133 |  |
| Installation and Deployment | 31,262 |  |  | 27,397 |  |  | 89,487 |  |  | 84,011 |  |
| Consulting and Network Design | 8,024 |  |  | 8,822 |  |  | 29,103 |  |  | 28,969 |  |
| Total Global Services | 100,183 |  |  | 94,121 |  |  | 296,349 |  |  | 284,113 |  |
| Consolidated revenue | $ | 818,817 |  |  | $ | 728,719 |  |  | $ | 2,194,930 |  |  | $ | 2,057,238 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-18-000037:notes:127]
[same as prior period, unchanged from 0000936395-18-000024:notes:113]

[0000936395-18-000037:notes:128]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2018 (in thousands):

[0000936395-18-000037:notes:129]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 12,876 |  | (1) | 3,803 |  | (2) | 16,679 |  |
| Cash payments | (10,987 | ) |  | (3,084 | ) |  | (14,071 | ) |
| Balance at July 31, 2018 | $ | 3,180 |  |  | $ | 2,367 |  |  | $ | 5,547 |  |
| Current restructuring liabilities | $ | 3,180 |  |  | $ | 1,076 |  |  | $ | 4,256 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,291 |  |  | $ | 1,291 |  |

[0000936395-18-000037:notes:130]
| (1) | Reflects a global workforce reduction of approximately 230 employees during fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-18-000037:notes:131]
| (2) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and in Gurgaon, India. |

[0000936395-18-000037:notes:132]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2017 (in thousands):

[0000936395-18-000037:notes:133]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 3,967 |  | (1) | 4,907 |  | (2) | 8,874 |  |
| Cash payments | (3,370 | ) |  | (2,679 | ) |  | (6,049 | ) |
| Balance at July 31, 2017 | $ | 1,465 |  |  | $ | 4,198 |  |  | $ | 5,663 |  |
| Current restructuring liabilities | $ | 1,465 |  |  | $ | 4,198 |  |  | $ | 5,663 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-18-000037:notes:134]
| (1) | Reflects a global workforce reduction of approximately 60 employees during fiscal 2017 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes and systems. |

[0000936395-18-000037:notes:135]
| (2) | Reflects unfavorable lease commitments and relocation costs incurred during fiscal 2017 in connection with the facility transition from Ciena’s existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-18-000037:notes:136]
[same as prior period, unchanged from 0000936395-18-000024:notes:122]

[0000936395-18-000037:notes:137]
|  | July 31, 2018 |  | October 31, 2017 |
| Compensation, payroll related tax and benefits | $ | 99,740 |  |  | $ | 113,272 |  |
| Warranty | 44,150 |  |  | 42,456 |  |
| Vacation | 40,747 |  |  | 39,778 |  |
| Capital lease obligations | 3,773 |  |  | 3,772 |  |
| Interest payable | 4,991 |  |  | 3,612 |  |
| Other | 104,587 |  |  | 120,044 |  |
|  | $ | 297,988 |  |  | $ | 322,934 |  |


## us-gaap:ScheduleOfDebtTableTextBlock

[0000936395-18-000037:notes:138]
| (1) | Includes accretion of principal at a rate of 1.85% per year |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-18-000037:notes:139]
[same as prior period, unchanged from 0000936395-18-000024:notes:125]

[0000936395-18-000037:notes:140]
| Nine Months Ended July 31, |  | Beginning Balance |  | Current Period Provisions (1) |  | Settlements |  | Ending Balance |
| 2017 |  | $ | 52,324 |  |  | 5,188 |  |  | (13,216 | ) |  | $ | 44,296 |  |
| 2018 |  | $ | 42,456 |  |  | 15,715 |  |  | (14,021 | ) |  | $ | 44,150 |  |

[0000936395-18-000037:notes:141]
(1) As a result of lower than expected actual failure rates, Ciena adjusted its fiscal 2017 provision for warranty. This adjustment had the effect of reducing warranty provision by $8.0 million for the nine months ended July 31, 2017.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-18-000037:notes:142]
For the periods below, Verizon, AT&T and a Web-scale provider were the only customers that accounted for at least 10% of Ciena’s revenue as follows (in thousands):

[0000936395-18-000037:notes:143]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Verizon | $ | 97,103 |  |  | $ | 82,918 |  |  | $ | 221,475 |  |  | $ | 206,272 |  |
| AT&T | 87,389 |  |  | 120,931 |  |  | 263,453 |  |  | 324,900 |  |
| Web-scale provider | 86,364 |  |  | n/a |  |  | n/a |  |  | n/a |  |
| Total | $ | 270,856 |  |  | $ | 203,849 |  |  | $ | 484,928 |  |  | $ | 531,172 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-18-000037:notes:144]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-18-000037:notes:145]
|  | July 31, 2018 |  | October 31, 2017 |
| Canada | $ | 197,057 |  |  | $ | 203,491 |  |
| United States | 79,243 |  |  | 90,482 |  |
| Other International | 19,563 |  |  | 14,492 |  |
| Total | $ | 295,863 |  |  | $ | 308,465 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-18-000037:notes:146]
[same as prior period, unchanged from 0000936395-18-000024:notes:132]

[0000936395-18-000037:notes:147]
[same as prior period, unchanged from 0000936395-18-000024:notes:133]

[0000936395-18-000037:notes:148]
[same as prior period, unchanged from 0000936395-18-000024:notes:134]

[0000936395-18-000037:notes:149]
[same as prior period, unchanged from 0000936395-18-000024:notes:135]

[0000936395-18-000037:notes:150]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. As of the first quarter of fiscal 2018, sales of Optical Transport products are also reflected within the Converged Packet Optical product line for all periods presented. |

[0000936395-18-000037:notes:151]
| ◦ | Packet Networking — includes the 3000 family of service delivery switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave® Platform and the Ethernet packet configuration for the 5410 Service Aggregation Switch. |

[0000936395-18-000037:notes:152]
[same as prior period, unchanged from 0000936395-18-000024:notes:138]

[0000936395-18-000037:notes:153]
| • | Software and Software-Related Services reflects sales of Ciena’s software platforms and software-related services. |

[0000936395-18-000037:notes:154]
Software platforms includes:

[0000936395-18-000037:notes:155]
| ◦ | Ciena’s Blue Planet Intelligent Automation Platform, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Intelligent Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA) and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design. |

[0000936395-18-000037:notes:156]
| ◦ | Ciena’s management software, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s management software consists of Blue Planet Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks adoption of its Blue Planet MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other management software solutions. |

[0000936395-18-000037:notes:157]
Software-related services includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms.

[0000936395-18-000037:notes:158]
[same as prior period, unchanged from 0000936395-18-000024:notes:142]

[0000936395-18-000037:notes:159]
[same as prior period, unchanged from 0000936395-18-000024:notes:143]

[0000936395-18-000037:notes:160]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2018, equipment, building, furniture and fixtures, net totaled $295.9 million primarily supporting asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and supporting Ciena’s unallocated selling and general and administrative activities. As of July 31, 2018, $32.1 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Networking Platforms segment and $76.2 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of July 31, 2018, all of the maintenance spares, net, totaling $43.7 million, were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-18-000037:notes:161]
[same as prior period, unchanged from 0000936395-18-000024:notes:145]

[0000936395-18-000037:notes:162]
[same as prior period, unchanged from 0000936395-18-000024:notes:146]

[0000936395-18-000037:notes:163]
Segment profit is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income (loss), net; interest expense; and provision for income taxes.

[0000936395-18-000037:notes:164]
[same as prior period, unchanged from 0000936395-18-000024:notes:148]

[0000936395-18-000037:notes:165]
Ciena’s revenue includes $469.2 million and $438.1 million of United States revenue for the third quarter of fiscal 2018 and 2017, respectively. Ciena’s revenue also includes $83.6 million of India revenue for the third quarter of fiscal 2018. For the nine months ended July 31, 2018 and 2017, United States revenue was $1,245.3 million and $1,209.8 million, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-18-000037:notes:166]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-18-000037:notes:167]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-18-000037:notes:168]
The customers identified above purchased products and services from each of Ciena’s operating segments.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-18-000037:notes:169]
[same as prior period, unchanged from 0000936395-18-000024:notes:152]

[0000936395-18-000037:notes:170]
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000037:notes:171]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 18 below.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-18-000037:notes:172]
STOCKHOLDERS’ EQUITY

[0000936395-18-000037:notes:173]
Adoption of ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting

[0000936395-18-000037:notes:174]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Ciena also elected to recognize forfeitures of stock awards when they occur, rather than estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the period of adoption.

[0000936395-18-000037:notes:175]
[same as prior period, unchanged from 0000936395-18-000024:notes:158]

[0000936395-18-000037:notes:176]
[same as prior period, unchanged from 0000936395-18-000024:notes:159]

[0000936395-18-000037:notes:177]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.


## us-gaap:SubsequentEventsTextBlock

[0000936395-18-000037:notes:178]
SUBSEQUENT EVENTS

[0000936395-18-000037:notes:179]
From the end of the third quarter of fiscal 2018 through August 31, 2018, Ciena repurchased an additional 472,542 shares of its common stock, for an aggregate purchase price of $12.4 million at an average price of $26.25 per share, inclusive of repurchases pending settlement. As of August 31, 2018, Ciena has repurchased an aggregate of 3,500,660 shares and has an aggregate of $212.8 million of authorized funds remaining under its Stock Repurchase Program.

[0000936395-18-000037:notes:180]
Stock Repurchases Related to Restricted Stock Unit Tax Withholding

[0000936395-18-000037:notes:181]
Historically, Ciena satisfied employee tax withholding obligations due upon the vesting of restricted stock units (RSUs) through directed open market sales to cover the employee tax obligations. Beginning in the fourth quarter of fiscal 2018, Ciena will change this practice to repurchase shares of common stock delivered with respect to such RSUs in settlement of employee tax withholding obligations due upon the vesting of RSUs. The purchase price for the shares of Ciena’s stock repurchased will be reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.

[0000936395-18-000037:notes:182]
Settlement of Conversions of New Notes

[0000936395-18-000037:notes:183]
Ciena has elected to settle any conversion of the New Notes prior to maturity in a combination of cash and shares, with the cash portion not to exceed an aggregate amount of approximately $400 million. Per the settlement provisions of the indenture governing conversion of the New Notes, an amount of $288.7 million (representing the aggregate principal amount) will be paid in cash on October 15, 2018. To the extent Ciena’s shares trade during the relevant settlement period in excess of the $20.17 per share conversion price, Ciena will pay up to approximately $111.3 million of any amounts due in excess of the aggregate principal amount in cash, and any remaining amounts due will be settled in shares. These amounts will be settled during the first quarter of fiscal 2019.

[0000936395-18-000037:notes:184]
DonRiver Acquisition

[0000936395-18-000037:notes:185]
On August 31, 2018, Ciena entered into a definitive agreement to acquire privately-held DonRiver Holdings, LLC, a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. The transaction is expected to close during Ciena’s fourth quarter of fiscal 2018 and is subject to customary closing conditions.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-18-000037:notes:186]
[same as prior period, unchanged from 0000936395-18-000024:notes:165]
