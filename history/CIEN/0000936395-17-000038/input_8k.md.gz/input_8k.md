# CIEN 8-K — 0000936395-17-000033 filed 2017-06-01

## item codes, every 8-K on or before 2017-06-07

- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2017-06-07

- none on or before 2017-06-07

## item 2.02 — earnings release, exhibit 99.1

[0000936395-17-000033:8k_2_02:1]
EX-99.1
2
exhibit991-2017q2earningsp.htm
EXHIBIT 99.1

[0000936395-17-000033:8k_2_02:2]
Exhibit

[0000936395-17-000033:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-17-000033:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2017 Financial Results

[0000936395-17-000033:8k_2_02:5]
Delivers 10% revenue growth year-over-year

[0000936395-17-000033:8k_2_02:6]
HANOVER, Md. - June 1, 2017 - Ciena® Corporation (NYSE:  CIEN), a network strategy and technology company, today announced unaudited financial results for its fiscal second quarter ended April 30, 2017.

[0000936395-17-000033:8k_2_02:7]
For the fiscal second quarter 2017, Ciena reported revenue of $707.0 million as compared to $640.7 million for the fiscal second quarter 2016.

[0000936395-17-000033:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal second quarter 2017 was $38.0 million, or $0.25 per diluted common share, which compares to a GAAP net income of $14.0 million, or $0.10 per diluted common share, for the fiscal second quarter 2016.

[0000936395-17-000033:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2017 was $72.3 million, or $0.45 per diluted common share, which compares to an adjusted (non-GAAP) net income of $52.4 million, or $0.34 per diluted common share, for the fiscal second quarter 2016.

[0000936395-17-000033:8k_2_02:10]
“We delivered outstanding second quarter performance across all financial metrics, underpinned by positive market dynamics and a growing competitive advantage, " said Gary B. Smith, president and CEO, Ciena. "We continue to win as an innovation powerhouse with global scale and deep customer relationships across a broad set of applications and market segments."

[0000936395-17-000033:8k_2_02:11]
Fiscal Second Quarter 2017 Performance Summary

[0000936395-17-000033:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-17-000033:8k_2_02:13]
|  |  | GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 707.0 |  |  | $ | 621.5 |  |  | $ | 640.7 |  |  | 13.8 | % |  | 10.3 | % |
| Gross margin |  | 45.0 | % |  | 44.1 | % |  | 44.2 | % |  | 0.9 | % |  | 0.8 | % |
| Operating expense |  | $ | 260.4 |  |  | $ | 254.7 |  |  | $ | 254.9 |  |  | 2.2 | % |  | 2.2 | % |
| Operating margin |  | 8.2 | % |  | 3.1 | % |  | 4.4 | % |  | 5.1 | % |  | 3.8 | % |

[0000936395-17-000033:8k_2_02:14]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2017 |  | FY 2017 |  | FY 2016 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 707.0 |  |  | $ | 621.5 |  |  | $ | 640.7 |  |  | 13.8 | % |  | 10.3 | % |
| Adj. gross margin |  | 45.7 | % |  | 44.9 | % |  | 45.1 | % |  | 0.8 | % |  | 0.6 | % |
| Adj. operating expense |  | $ | 234.6 |  |  | $ | 226.2 |  |  | $ | 222.6 |  |  | 3.7 | % |  | 5.4 | % |
| Adj. operating margin |  | 12.5 | % |  | 8.5 | % |  | 10.3 | % |  | 4.0 | % |  | 2.2 | % |

[0000936395-17-000033:8k_2_02:15]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-17-000033:8k_2_02:16]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2017 |  | Q1 FY 2017 |  | Q2 FY 2016 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 502.1 |  |  | 71.0 |  | $ | 412.7 |  |  | 66.4 |  | $ | 435.2 |  |  | 67.9 |
| Packet Networking |  | 66.4 |  |  | 9.4 |  | 72.2 |  |  | 11.6 |  | 68.5 |  |  | 10.7 |
| Optical Transport |  | 3.0 |  |  | 0.4 |  | 5.1 |  |  | 0.8 |  | 8.5 |  |  | 1.3 |
| Total Networking Platforms |  | 571.5 |  |  | 80.8 |  | 490.0 |  |  | 78.8 |  | 512.2 |  |  | 79.9 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms |  | 13.1 |  |  | 1.9 |  | 17.0 |  |  | 2.7 |  | 11.8 |  |  | 1.9 |
| Software-Related Services |  | 24.6 |  |  | 3.5 |  | 22.3 |  |  | 3.6 |  | 18.7 |  |  | 2.9 |
| Total Software and Software-Related Services |  | 37.7 |  |  | 5.4 |  | 39.3 |  |  | 6.3 |  | 30.5 |  |  | 4.8 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 58.2 |  |  | 8.2 |  | 55.0 |  |  | 8.9 |  | 57.1 |  |  | 8.9 |
| Installation and Deployment |  | 28.7 |  |  | 4.1 |  | 27.9 |  |  | 4.5 |  | 30.2 |  |  | 4.7 |
| Consulting and Network Design |  | 10.9 |  |  | 1.5 |  | 9.3 |  |  | 1.5 |  | 10.7 |  |  | 1.7 |
| Total Global Services |  | 97.8 |  |  | 13.8 |  | 92.2 |  |  | 14.9 |  | 98.0 |  |  | 15.3 |
| Total |  | $ | 707.0 |  |  | 100.0 |  | $ | 621.5 |  |  | 100.0 |  | $ | 640.7 |  |  | 100.0 |

[0000936395-17-000033:8k_2_02:17]
Additional Performance Metrics for Fiscal Second Quarter 2017

[0000936395-17-000033:8k_2_02:18]
|  |  | Revenue by Geographic Region |
|  |  | Q2 FY 2017 |  | Q1 FY 2017 |  | Q2 FY 2016 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 424.4 |  |  | 60.0 |  | $ | 405.9 |  |  | 65.3 |  | $ | 395.5 |  |  | 61.7 |
| Europe, Middle East and Africa |  | 105.8 |  |  | 15.0 |  | 91.5 |  |  | 14.7 |  | 96.2 |  |  | 15.0 |
| Caribbean and Latin America |  | 33.9 |  |  | 4.8 |  | 35.2 |  |  | 5.7 |  | 57.9 |  |  | 9.0 |
| Asia Pacific |  | 142.9 |  |  | 20.2 |  | 88.9 |  |  | 14.3 |  | 91.1 |  |  | 14.3 |
| Total |  | $ | 707.0 |  |  | 100.0 |  | $ | 621.5 |  |  | 100.0 |  | $ | 640.7 |  |  | 100.0 |

[0000936395-17-000033:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-17-000033:8k_2_02:20]
| • | U.S. customers contributed 55.4% of total revenue |

[0000936395-17-000033:8k_2_02:21]
| • | One customer accounted for greater than 10% of revenue and represented 15% of total revenue |

[0000936395-17-000033:8k_2_02:22]
| • | Cash and investments totaled $993.3 million |

[0000936395-17-000033:8k_2_02:23]
| • | Cash flow from operations totaled $72.0 million |

[0000936395-17-000033:8k_2_02:24]
| • | Average days' sales outstanding (DSOs) were 72 |

[0000936395-17-000033:8k_2_02:25]
| • | Accounts receivable balance was $564.9 million |

[0000936395-17-000033:8k_2_02:26]
| • | Inventories totaled $287.1 million, including: |

[0000936395-17-000033:8k_2_02:27]
| ◦ | Raw materials: $43.9 million |

[0000936395-17-000033:8k_2_02:28]
| ◦ | Work in process: $12.9 million |

[0000936395-17-000033:8k_2_02:29]
| ◦ | Finished goods: $204.4 million |

[0000936395-17-000033:8k_2_02:30]
| ◦ | Deferred cost of sales: $85.1 million |

[0000936395-17-000033:8k_2_02:31]
| ◦ | Reserve for excess and obsolescence: $(59.2) million |

[0000936395-17-000033:8k_2_02:32]
| • | Product inventory turns were 4.6 |

[0000936395-17-000033:8k_2_02:33]
| • | Headcount totaled 5,663 |

[0000936395-17-000033:8k_2_02:34]
Business Outlook for Fiscal Third Quarter 2017

[0000936395-17-000033:8k_2_02:35]
Ciena expects fiscal third quarter 2017 financial performance to include:

[0000936395-17-000033:8k_2_02:36]
| • | Revenue in the range of $710 to $740 million |

[0000936395-17-000033:8k_2_02:37]
| • | Adjusted (non-GAAP) gross margin in the mid-40s percentage range |

[0000936395-17-000033:8k_2_02:38]
| • | Adjusted (non-GAAP) operating expense of approximately $235 million |

[0000936395-17-000033:8k_2_02:39]
Live Web Broadcast of Unaudited Fiscal Second Quarter 2017 Results

[0000936395-17-000033:8k_2_02:40]
Ciena will host a discussion of its unaudited fiscal second quarter 2017 results with investors and financial analysts today, Thursday, June 1, 2017 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-17-000033:8k_2_02:41]
Notes to Investors

[0000936395-17-000033:8k_2_02:42]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “We delivered outstanding second quarter performance across all financial metrics, underpinned by positive market dynamics and a growing competitive advantage"; "We continue to win as an innovation powerhouse with global scale and deep customer relationships across a broad set of applications and market segments"; "Ciena expects fiscal third quarter 2017 financial performance to include: Revenue in the range of $710 to $740 million; Adjusted (non-GAAP) gross margin in the mid-40s percentage range; Adjusted (non-GAAP) operating expense of approximately $235 million."

[0000936395-17-000033:8k_2_02:43]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on March 8, 2017. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-17-000033:8k_2_02:44]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-17-000033:8k_2_02:45]
With respect to Ciena’s expectations under “Business Outlook for Fiscal Third Quarter 2017” above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin and adjusted (non-GAAP) operating expense guidance measures to the corresponding gross profit and gross profit percentage, and operating expense GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty.  For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0000936395-17-000033:8k_2_02:46]
About Ciena

[0000936395-17-000033:8k_2_02:47]
Ciena (NYSE: CIEN) is a network strategy and technology company. We translate best-in-class technology into value through a high-touch, consultative business model - with a relentless drive to create exceptional experiences measured by outcomes. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-17-000033:8k_2_02:48]
CIENA CORPORATION

[0000936395-17-000033:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-17-000033:8k_2_02:50]
(in thousands, except per share data)

[0000936395-17-000033:8k_2_02:51]
(unaudited)

[0000936395-17-000033:8k_2_02:52]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 584,630 |  |  | $ | 523,978 |  |  | $ | 1,091,623 |  |  | $ | 981,567 |  |
| Services | 122,392 |  |  | 116,739 |  |  | 236,896 |  |  | 232,265 |  |
| Total revenue | 707,022 |  |  | 640,717 |  |  | 1,328,519 |  |  | 1,213,832 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 327,295 |  |  | 291,778 |  |  | 614,106 |  |  | 552,260 |  |
| Services | 61,487 |  |  | 65,846 |  |  | 122,388 |  |  | 127,029 |  |
| Total cost of goods sold | 388,782 |  |  | 357,624 |  |  | 736,494 |  |  | 679,289 |  |
| Gross profit | 318,240 |  |  | 283,093 |  |  | 592,025 |  |  | 534,543 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 121,623 |  |  | 114,603 |  |  | 238,492 |  |  | 222,649 |  |
| Selling and marketing | 88,551 |  |  | 86,668 |  |  | 173,553 |  |  | 169,146 |  |
| General and administrative | 34,990 |  |  | 35,203 |  |  | 70,854 |  |  | 66,345 |  |
| Amortization of intangible assets | 10,980 |  |  | 15,566 |  |  | 25,531 |  |  | 32,428 |  |
| Acquisition and integration costs | — |  |  | 2,285 |  |  | — |  |  | 3,584 |  |
| Restructuring costs | 4,276 |  |  | 535 |  |  | 6,671 |  |  | 919 |  |
| Total operating expenses | 260,420 |  |  | 254,860 |  |  | 515,101 |  |  | 495,071 |  |
| Income from operations | 57,820 |  |  | 28,233 |  |  | 76,924 |  |  | 39,472 |  |
| Interest and other income (loss), net | (2,918 | ) |  | 967 |  |  | (2,548 | ) |  | (7,809 | ) |
| Interest expense | (13,308 | ) |  | (12,608 | ) |  | (28,511 | ) |  | (25,318 | ) |
| Income before income taxes | 41,594 |  |  | 16,592 |  |  | 45,865 |  |  | 6,345 |  |
| Provision for income taxes | 3,568 |  |  | 2,595 |  |  | 3,978 |  |  | 3,894 |  |
| Net income | $ | 38,026 |  |  | $ | 13,997 |  |  | $ | 41,887 |  |  | $ | 2,451 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.27 |  |  | $ | 0.10 |  |  | $ | 0.30 |  |  | $ | 0.02 |  |
| Diluted net income per potential common share1 | $ | 0.25 |  |  | $ | 0.10 |  |  | $ | 0.29 |  |  | $ | 0.02 |  |
| Weighted average basic common shares outstanding | 141,743 |  |  | 137,950 |  |  | 141,223 |  |  | 137,313 |  |
| Weighted average dilutive potential common shares outstanding2 | 165,273 |  |  | 138,889 |  |  | 147,842 |  |  | 138,693 |  |

[0000936395-17-000033:8k_2_02:53]
| 1. | The calculation of GAAP diluted net income per common share for the second quarter of fiscal 2017 requires adding back interest expense of approximately $0.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, and approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 to the GAAP net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-17-000033:8k_2_02:54]
The calculation of GAAP diluted net income per common share for the first six months of fiscal 2017 requires adding back interest expense of approximately $1.1 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-17-000033:8k_2_02:55]
| 2. | Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2017 includes 1.3 million shares underlying certain stock options and restricted stock |

[0000936395-17-000033:8k_2_02:56]
units, 4.9 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017 and 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018.

[0000936395-17-000033:8k_2_02:57]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first six months of fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units and 5.2 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017 .

[0000936395-17-000033:8k_2_02:58]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2016 includes 0.9 million shares underlying certain stock options and restricted stock units.

[0000936395-17-000033:8k_2_02:59]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first six months of fiscal 2016 includes 1.4 million shares underlying certain stock options and restricted stock units.

[0000936395-17-000033:8k_2_02:60]
CIENA CORPORATION

[0000936395-17-000033:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-17-000033:8k_2_02:62]
(in thousands, except share data)

[0000936395-17-000033:8k_2_02:63]
(unaudited)

[0000936395-17-000033:8k_2_02:64]
|  | April 30, 2017 |  | October 31, 2016 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 628,623 |  |  | $ | 777,615 |  |
| Short-term investments | 274,779 |  |  | 275,248 |  |
| Accounts receivable, net | 564,856 |  |  | 576,235 |  |
| Inventories | 287,073 |  |  | 211,251 |  |
| Prepaid expenses and other | 186,919 |  |  | 172,843 |  |
| Total current assets | 1,942,250 |  |  | 2,013,192 |  |
| Long-term investments | 89,852 |  |  | 90,172 |  |
| Equipment, building, furniture and fixtures, net | 299,792 |  |  | 288,406 |  |
| Goodwill | 266,773 |  |  | 266,974 |  |
| Other intangible assets, net | 113,245 |  |  | 146,711 |  |
| Other long-term assets | 65,191 |  |  | 68,120 |  |
| Total assets | $ | 2,777,103 |  |  | $ | 2,873,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 249,556 |  |  | $ | 235,942 |  |
| Accrued liabilities and other short-term obligations | 262,482 |  |  | 310,353 |  |
| Deferred revenue | 105,514 |  |  | 109,009 |  |
| Current portion of long-term debt | 189,221 |  |  | 236,241 |  |
| Total current liabilities | 806,773 |  |  | 891,545 |  |
| Long-term deferred revenue | 81,349 |  |  | 73,854 |  |
| Other long-term obligations | 113,254 |  |  | 124,394 |  |
| Long-term debt, net | 929,182 |  |  | 1,017,441 |  |
| Total liabilities | $ | 1,930,558 |  |  | $ | 2,107,234 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 141,768,448 and 139,767,627 shares issued and outstanding | 1,418 |  |  | 1,398 |  |
| Additional paid-in capital | 6,750,632 |  |  | 6,715,478 |  |
| Accumulated other comprehensive loss | (21,186 | ) |  | (24,329 | ) |
| Accumulated deficit | (5,884,319 | ) |  | (5,926,206 | ) |
| Total stockholders’ equity | 846,545 |  |  | 766,341 |  |
| Total liabilities and stockholders’ equity | $ | 2,777,103 |  |  | $ | 2,873,575 |  |

[0000936395-17-000033:8k_2_02:65]
CIENA CORPORATION

[0000936395-17-000033:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-17-000033:8k_2_02:67]
(in thousands)

[0000936395-17-000033:8k_2_02:68]
(unaudited)

[0000936395-17-000033:8k_2_02:69]
|  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 41,887 |  |  | $ | 2,451 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 35,548 |  |  | 30,237 |  |
| Share-based compensation costs | 24,830 |  |  | 29,210 |  |
| Amortization of intangible assets | 33,466 |  |  | 40,488 |  |
| Provision for inventory excess and obsolescence | 19,623 |  |  | 20,104 |  |
| Provision for warranty | 2,347 |  |  | 9,563 |  |
| Other | 10,416 |  |  | 8,578 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 9,381 |  |  | (4,865 | ) |
| Inventories | (95,554 | ) |  | (19,022 | ) |
| Prepaid expenses and other | (15,054 | ) |  | (7,670 | ) |
| Accounts payable, accruals and other obligations | (24,974 | ) |  | (29,400 | ) |
| Deferred revenue | 3,832 |  |  | (3,992 | ) |
| Net cash provided by operating activities | 45,748 |  |  | 75,682 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (60,328 | ) |  | (53,050 | ) |
| Purchase of available for sale securities | (179,833 | ) |  | (199,994 | ) |
| Proceeds from maturities of available for sale securities | 180,000 |  |  | 110,000 |  |
| Settlement of foreign currency forward contracts, net | (2,965 | ) |  | (4,834 | ) |
| Acquisition of business, net of cash acquired | — |  |  | (32,000 | ) |
| Net cash used in investing activities | (63,126 | ) |  | (179,878 | ) |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | — |  |  | 248,750 |  |
| Payment of long term debt | (47,296 | ) |  | (15,264 | ) |
| Proceeds from modification of term loan | 399,500 |  |  | — |  |
| Payment for modification of term loans | (493,125 | ) |  | — |  |
| Payment of debt issuance costs | — |  |  | (3,778 | ) |
| Payment of capital lease obligations | (1,528 | ) |  | (3,769 | ) |
| Proceeds from issuance of common stock | 10,345 |  |  | 9,968 |  |
| Net cash provided by (used in) financing activities | (132,104 | ) |  | 235,907 |  |
| Effect of exchange rate changes on cash and cash equivalents | 490 |  |  | (649 | ) |
| Net increase (decrease) in cash and cash equivalents | (148,992 | ) |  | 131,062 |  |
| Cash and cash equivalents at beginning of period | 777,615 |  |  | 790,971 |  |
| Cash and cash equivalents at end of period | $ | 628,623 |  |  | $ | 922,033 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 23,439 |  |  | $ | 20,432 |  |
| Cash paid during the period for income taxes, net | $ | 11,379 |  |  | $ | 6,991 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 3,818 |  |  | $ | 11,437 |  |
| Equipment acquired under capital lease | $ | — |  |  | $ | 3,012 |  |
| Building subject to capital lease | $ | 20,695 |  |  | $ | 8,993 |  |
| Construction in progress subject to build-to-suit lease | $ | — |  |  | $ | 21,606 |  |

[0000936395-17-000033:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |  |  |
|  |  | Quarter Ended April 30, |
|  |  | 2017 |  | 2016 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 318,240 |  |  | $ | 283,093 |  |
| Share-based compensation-products |  | 708 |  |  | 629 |  |
| Share-based compensation-services |  | 679 |  |  | 693 |  |
| Amortization of intangible assets |  | 3,623 |  |  | 4,315 |  |
| Total adjustments related to gross profit |  | 5,010 |  |  | 5,637 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 323,250 |  |  | $ | 288,730 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 45.7 | % |  | 45.1 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 260,420 |  |  | $ | 254,860 |  |
| Share-based compensation-research and development |  | 3,653 |  |  | 3,791 |  |
| Share-based compensation-sales and marketing |  | 3,513 |  |  | 3,923 |  |
| Share-based compensation-general and administrative |  | 3,417 |  |  | 4,968 |  |
| Share-based compensation-acquisition and integration |  | — |  |  | 697 |  |
| Acquisition and integration costs, excluding share-based compensation |  | — |  |  | 1,588 |  |
| Amortization of intangible assets |  | 10,980 |  |  | 15,566 |  |
| Restructuring costs |  | 4,276 |  |  | 535 |  |
| Settlement of patent litigation |  | — |  |  | 1,200 |  |
| Total adjustments related to operating expense |  | 25,839 |  |  | 32,268 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 234,581 |  |  | $ | 222,592 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 57,820 |  |  | $ | 28,233 |  |
| Total adjustments related to gross profit |  | 5,010 |  |  | 5,637 |  |
| Total adjustments related to operating expense |  | 25,839 |  |  | 32,268 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 88,669 |  |  | $ | 66,138 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 12.5 | % |  | 10.3 | % |
| Net Income Reconciliation |  |  |  |  |
| GAAP net income |  | $ | 38,026 |  |  | $ | 13,997 |  |
| Total adjustments related to gross profit |  | 5,010 |  |  | 5,637 |  |
| Total adjustments related to operating expense |  | 25,839 |  |  | 32,268 |  |
| Non-cash interest expense |  | 526 |  |  | 460 |  |
| Modification of debt |  | 2,924 |  |  | — |  |
| Adjusted (non-GAAP) net income |  | $ | 72,325 |  |  | $ | 52,362 |  |
| Weighted average basic common shares outstanding |  | 141,743 |  |  | 137,950 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 174,471 |  |  | 178,026 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.25 |  |  | $ | 0.10 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.45 |  |  | $ | 0.34 |  |

[0000936395-17-000033:8k_2_02:71]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2017 includes 1.3 million shares underlying certain stock options and restricted stock units, 4.9 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020. |

[0000936395-17-000033:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2016 includes 0.9 million shares underlying certain stock options and restricted stock units, 12.6 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-17-000033:8k_2_02:73]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2017 requires adding back interest expense of approximately $0.5 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-17-000033:8k_2_02:74]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2016 requires adding back interest expense of approximately $1.3 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-17-000033:8k_2_02:75]
* * *

[0000936395-17-000033:8k_2_02:76]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-17-000033:8k_2_02:77]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-17-000033:8k_2_02:78]
| • | Acquisition and integration costs - consist of expenses for financial, legal and accounting advisors and severance and other employee related costs, associated with our acquisition of Cyan, Inc. on August 3, 2015 and our acquisition of certain high-speed photonic component assets from TeraXion, Inc. on February 1, 2016. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-17-000033:8k_2_02:79]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-17-000033:8k_2_02:80]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-17-000033:8k_2_02:81]
| • | Settlement of Patent Litigation - included in general and administrative expense is a $1.2 million patent litigation settlement during the second quarter of fiscal 2016. |

[0000936395-17-000033:8k_2_02:82]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-17-000033:8k_2_02:83]
| • | Modification of debt - costs incurred as a result of modification of debt to refinance term loans. |
