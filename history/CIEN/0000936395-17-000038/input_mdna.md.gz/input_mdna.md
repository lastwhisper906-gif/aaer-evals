# CIEN MD&A — 0000936395-17-000038


## mdna

[0000936395-17-000038:mdna:1]
[same as prior period, unchanged from 0000936395-17-000020:mdna:1]

[0000936395-17-000038:mdna:2]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” "projects," "targets," or  “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, adoption of next-generation network technology and software programmability and control of networks; our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; our corporate strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business;  expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including real estate and IT transitions or initiatives; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-17-000038:mdna:3]
[same as prior period, unchanged from 0000936395-17-000020:mdna:3]

[0000936395-17-000038:mdna:4]
[same as prior period, unchanged from 0000936395-17-000020:mdna:4]

[0000936395-17-000038:mdna:5]
[same as prior period, unchanged from 0000936395-17-000020:mdna:5]

[0000936395-17-000038:mdna:6]
[same as prior period, unchanged from 0000936395-17-000020:mdna:6]

[0000936395-17-000038:mdna:7]
[same as prior period, unchanged from 0000936395-17-000020:mdna:7]

[0000936395-17-000038:mdna:8]
[same as prior period, unchanged from 0000936395-17-000020:mdna:8]

[0000936395-17-000038:mdna:9]
[same as prior period, unchanged from 0000936395-17-000020:mdna:9]

[0000936395-17-000038:mdna:10]
[same as prior period, unchanged from 0000936395-17-000020:mdna:10]

[0000936395-17-000038:mdna:11]
[same as prior period, unchanged from 0000936395-17-000020:mdna:11]

[0000936395-17-000038:mdna:12]
[same as prior period, unchanged from 0000936395-17-000020:mdna:12]

[0000936395-17-000038:mdna:13]
[same as prior period, unchanged from 0000936395-17-000020:mdna:13]

[0000936395-17-000038:mdna:14]
[same as prior period, unchanged from 0000936395-17-000020:mdna:14]

[0000936395-17-000038:mdna:15]
[same as prior period, unchanged from 0000936395-17-000020:mdna:15]

[0000936395-17-000038:mdna:16]
[same as prior period, unchanged from 0000936395-17-000020:mdna:16]

[0000936395-17-000038:mdna:17]
[same as prior period, unchanged from 0000936395-17-000020:mdna:17]

[0000936395-17-000038:mdna:18]
[same as prior period, unchanged from 0000936395-17-000020:mdna:18]

[0000936395-17-000038:mdna:19]
[same as prior period, unchanged from 0000936395-17-000020:mdna:19]

[0000936395-17-000038:mdna:20]
[same as prior period, unchanged from 0000936395-17-000020:mdna:20]

[0000936395-17-000038:mdna:21]
[same as prior period, unchanged from 0000936395-17-000020:mdna:21]

[0000936395-17-000038:mdna:22]
| • | our new distribution relationships under which we will make available certain technology as a component; |

[0000936395-17-000038:mdna:23]
[same as prior period, unchanged from 0000936395-17-000020:mdna:22]

[0000936395-17-000038:mdna:24]
[same as prior period, unchanged from 0000936395-17-000020:mdna:23]

[0000936395-17-000038:mdna:25]
[same as prior period, unchanged from 0000936395-17-000020:mdna:24]

[0000936395-17-000038:mdna:26]
[same as prior period, unchanged from 0000936395-17-000020:mdna:25]

[0000936395-17-000038:mdna:27]
[same as prior period, unchanged from 0000936395-17-000020:mdna:26]

[0000936395-17-000038:mdna:28]
[same as prior period, unchanged from 0000936395-17-000020:mdna:27]

[0000936395-17-000038:mdna:29]
[same as prior period, unchanged from 0000936395-17-000020:mdna:28]

[0000936395-17-000038:mdna:30]
[same as prior period, unchanged from 0000936395-17-000020:mdna:29]

[0000936395-17-000038:mdna:31]
[same as prior period, unchanged from 0000936395-17-000020:mdna:30]

[0000936395-17-000038:mdna:32]
[same as prior period, unchanged from 0000936395-17-000020:mdna:31]

[0000936395-17-000038:mdna:33]
[same as prior period, unchanged from 0000936395-17-000020:mdna:32]

[0000936395-17-000038:mdna:34]
[same as prior period, unchanged from 0000936395-17-000020:mdna:33]

[0000936395-17-000038:mdna:35]
| • | adverse results in litigation matters. |

[0000936395-17-000038:mdna:36]
[same as prior period, unchanged from 0000936395-17-000020:mdna:36]

[0000936395-17-000038:mdna:37]
[same as prior period, unchanged from 0000936395-17-000020:mdna:37]

[0000936395-17-000038:mdna:38]
[same as prior period, unchanged from 0000936395-17-000020:mdna:38]

[0000936395-17-000038:mdna:39]
[same as prior period, unchanged from 0000936395-17-000020:mdna:39]

[0000936395-17-000038:mdna:40]
[same as prior period, unchanged from 0000936395-17-000020:mdna:40]

[0000936395-17-000038:mdna:41]
36

[0000936395-17-000038:mdna:42]
[same as prior period, unchanged from 0000936395-17-000020:mdna:41]

[0000936395-17-000038:mdna:43]
[same as prior period, unchanged from 0000936395-17-000020:mdna:42]

[0000936395-17-000038:mdna:44]
The markets in which we compete are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to gain or retain market share. The markets for our solutions are both highly competitive and fragmented, as we regularly compete with number of large, multi-national vendors with greater financial, operational and marketing resources, and significantly broader product offerings. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, higher-capacity, higher-speed network solutions with improved reach, spectral efficiency, automation, power consumption and cost per bit. We expect the competitive landscape in which we operate to continue to broaden and to remain challenging and dynamic. As we have expanded our solutions offerings to include our 8700 Packetwave Platform and Waveserver DCI platform, our solutions have become increasingly competitive with IP router vendors, data center switch providers, and other IT suppliers or integrators. Separately, as we seek increased customer adoption of our Blue Planet software platform, we expect to compete more directly with additional software vendors and information technology vendors or integrators of these solutions.

[0000936395-17-000038:mdna:45]
In addition to the above dynamics, many network operators are continuing to consider a variety of “consumption models,” or approaches to the design and procurement of their network infrastructure. While broader adoption of the consumption models involving disaggregation in the procurement of hardware and software remains uncertain, we expect that the potential for different models will require us and other system vendors to assess and possibly broaden our existing commercial models over time. We may also face competition from component vendors, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware. Further, some of our competitors are not vertically integrated in their packet optical supply chain and therefore sell a set of networking solutions that rely upon coherent modem technology developed by and procured from third party “merchant” providers. In connection with consumption models involving greater disaggregation, the continued use of such third party modem technology by these competitors and/or the availability of such technology in the market may increase overall pricing pressure in this space and may negatively impact our ability to derive higher gross margins for Converged Packet Optical solutions.

[0000936395-17-000038:mdna:46]
Given this dynamic competitive landscape and the market-based price erosion for our products that we regularly encounter, we expect that, in order to achieve sustained revenue growth, we will be required to continue to increase our volume of product shipments, continue to diversify our business and customer base, introduce new solutions that address evolving service and network demands, and accommodate multiple consumption models. In addition, in order to maintain incumbency with key customers and to secure new opportunities, we are often required to agree to aggressive pricing, incur significant costs early in network deployment, or make significant commercial concessions. These terms have adversely affected our results of operations in the past, have contributed to fluctuations in our financial results, and may do so again in the future.

[0000936395-17-000038:mdna:47]
[same as prior period, unchanged from 0000936395-17-000020:mdna:47]

[0000936395-17-000038:mdna:48]
[same as prior period, unchanged from 0000936395-17-000020:mdna:48]

[0000936395-17-000038:mdna:49]
Promote Choice and Openness through our OPn Philosophy. We previously introduced our OPn Architecture as a focused approach to next-generation networks through scalability, programmability and network level applications. Today, OPn has evolved and expanded from an architecture into our governing philosophy and broader belief system, which is rooted in enabling choice in the market through openness. Choice is an increasingly important element of our customers’ efforts to keep pace with bandwidth demands and emerging service offerings, the shift to more automated and programmable networks, and the need to manage network costs. We believe that the best way to enable choice for our customers is by developing and providing network technologies and strategies that facilitate openness through innovation, virtualization, automation and collaboration. We also believe that we are well-positioned in this regard to offer an expansive range of choice to the market.

[0000936395-17-000038:mdna:50]
Our OPn belief system shapes the operation of our business in a number of ways. It guides our research and development strategy and solutions offerings, including our focus on coherent modem leadership, packet-optical convergence, and on multi-vendor network orchestration, management and control through our Blue Planet software platform. By embracing design principles that leverage open application programming interfaces (APIs), including those found in our Waveserver platform, we believe we facilitate openness and choice. By offering collaborative tools and environments, including our Emulation Cloud and DevOps Toolkit, we enable the development, testing and customization of services and applications. Our OPn belief system also influences our go-to-market approach, as we expect to partner increasingly with an ecosystem of solutions vendors and virtual network function providers, and to integrate services and applications across multi-vendor and multi-domain networks. We intend to offer solutions and pursue opportunities across a range of customer consumption models in order to drive the evolution of next-generation network infrastructures and accelerate the realization of our OPn philosophy.

[0000936395-17-000038:mdna:51]
Extend Technology Leadership and Expand Application of our Solutions. Our product development strategy is focused on maintaining our leading technology offerings and expanding our role and the application of our solutions in customer networks. Our research and development efforts seek to advance and extend our coherent modem technology leadership, including our WaveLogic coherent optical processor and high-speed indium phosphide and silicon photonics technologies (HSPC) acquired from TeraXion during fiscal 2016. We are also focused on introducing terabit per second and greater transmission speeds, and expanding the high-capacity and operationally-efficient service delivery capabilities in our Packet Networking and Converged Packet Optical products for access and metro networks, data center interconnect, submarine networks, and other WAN applications. In addition, we are seeking to increase software programmability of networks and to enable network operators to automate and accelerate the creation and delivery of new, cloud-based services. These efforts include investments in our Blue Planet software platform — which is designed to automate, orchestrate, and manage physical network resources and virtualized services across data centers and the WAN — and its integration across our portfolio and with additional third party network resources.

[0000936395-17-000038:mdna:52]
As part of our strategy to expand the application of our solutions and capitalize on the evolving market dynamics and different consumption models described above, on March 20, 2017, we announced global distribution relationships with leading component vendors Lumentum, NeoPhotonics and Oclaro. Through this new distribution channel, we intend to supply our WaveLogic Ai coherent optical technology for use as a component of a Ciena-designed optical module to be manufactured, marketed and sold by the component vendors. Once these modules are available, Lumentum, NeoPhotonics and Oclaro will each have the ability to sell such modules to customers on a non-exclusive basis. We believe that potential customers for optical modules through this distribution channel may include a variety of market participants, including certain of our customers, other system vendors, and network operators or vendors who plan to build or use “white box” hardware. In addition, we intend to work together with these component vendors to contribute to the establishment of specifications, both independently and within relevant industry forums, for 400G pluggable technology solutions focused on data center interconnect requirements for greater scale and power efficiency and lower cost. We believe that this distribution channel will further our efforts to continue to diversify our business and expand our addressable market to include new geographies and market segments, while enabling greater choice for network operators in offering an alternative to “merchant” modems. No revenue was generated through this distribution channel in the second quarter of fiscal 2017. We expect the results of operations related to this distribution channel to be reflected within our Networking Platforms segment.

[0000936395-17-000038:mdna:53]
Increase Diversification of our Business. The continued diversification of our business is a key element of our strategy to address the dynamic environment of our industry. We believe this diversification positions us to continue to grow our business and to better withstand potential slowdowns adversely affecting particular geographies, markets, customer segments and applications. We intend to pursue initiatives that broaden sales to existing customers across our solutions portfolio and also to secure additional relationships with a diverse set of network operators in high-growth customer segments and geographies.

[0000936395-17-000038:mdna:54]
[same as prior period, unchanged from 0000936395-17-000020:mdna:53]

[0000936395-17-000038:mdna:55]
We also intend to target important growth markets, including key customer market segments and geographies. Our go-to-market strategy is focused on further diversifying our customer base by penetrating additional internet content providers, data center operators and other emerging network operators that form the “Web-scale” marketplace. We are also focused on securing additional customers within our traditional base of communications service providers, particularly in higher growth markets, including our Asia-Pacific region and India. We intend to use our direct and indirect sales channels to target, and to expand our

[0000936395-17-000038:mdna:56]
38

[0000936395-17-000038:mdna:57]
sales with, several other market verticals, including cable and multiservice operators, submarine network operators, enterprise customers and in the government and R&E markets. For example, we intend to gain greater reach providing network solutions to submarine network operators, particularly in the new cable build market, in part through our recently announced supply partnership with TE SubCom. To leverage the geographic reach of our direct sales resources and expand sales into key geographies, we have pursued channel and distribution opportunities, including our strategic relationship with Ericsson, that enable sales through third parties, including service providers, systems integrators and value-added resellers.

[0000936395-17-000038:mdna:58]
[same as prior period, unchanged from 0000936395-17-000020:mdna:55]

[0000936395-17-000038:mdna:59]
[same as prior period, unchanged from 0000936395-17-000020:mdna:58]

[0000936395-17-000038:mdna:60]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing term loan in the aggregate principal amount of $250 million, maturing on July 15, 2019 (the "2019 Term Loan") and its existing term loan in the aggregate principal amount of $250 million, maturing on April 25, 2021 (the "2021 Term Loan") into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. As a result, we used $93.6 million in cash, representing the original discount on the 2022 Term Loan and the repayment of $93.1 million of the outstanding principal under the 2019 Term Loan and 2021 Term Loan. The remaining balances under the 2019 Term Loan and 2021 Term Loan were refinanced and replaced by the 2022 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1 million on a quarterly basis. This arrangement was accounted for as a modification of debt. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this quarterly report for more information relating to our term loan refinancing.

[0000936395-17-000038:mdna:61]
Maturity of 0.875% Convertible Senior Notes due June 15, 2017

[0000936395-17-000038:mdna:62]
Our $185.3 million in aggregate principal amount outstanding in 0.875% convertible senior notes will mature on June 15, 2017. Subject to the conversion rights of the holders thereof, we expect to repay any then remaining amount outstanding in cash at maturity.

[0000936395-17-000038:mdna:63]
Financial Results for Second Quarter of Fiscal 2017 and Sequential Comparison

[0000936395-17-000038:mdna:64]
Revenue for the second quarter of fiscal 2017 was $707.0 million, representing a sequential increase of 13.8% from $621.5 million in the first quarter of fiscal 2017, during which we typically experience seasonal reductions in revenue. Revenue-related details reflecting sequential changes from the first quarter of fiscal 2017 include:

[0000936395-17-000038:mdna:65]
| • | Product revenue for the second quarter of fiscal 2017 increased by $77.6 million, primarily reflecting revenue increases in Converged Packet Optical within our Networking Platforms segment. |

[0000936395-17-000038:mdna:66]
| • | Service revenue for the second quarter of fiscal 2017 increased by $7.9 million. |

[0000936395-17-000038:mdna:67]
| • | North America revenue for the second quarter of fiscal 2017 was $424.4 million, an increase from $405.9 million in the first quarter of fiscal 2017. This primarily reflects revenue increases of $20.8 million within our Networking Platforms segment and $2.2 million within our Global Services segment. These increases were partially offset by a revenue decrease of $4.5 million within our Software and Software-Related Services segment. |

[0000936395-17-000038:mdna:68]
| • | Europe, Middle East and Africa ("EMEA") revenue for the second quarter of fiscal 2017 was $105.8 million, an increase from $91.5 million in the first quarter of fiscal 2017. This primarily reflects revenue increases of $10.4 million within our Networking Platforms segment, $2.6 million within our Global Services segment and $1.2 million within our Software and Software-Related Services segment. |

[0000936395-17-000038:mdna:69]
| • | Caribbean and Latin America ("CALA") revenue for the second quarter of fiscal 2017 was $33.9 million, a decrease from $35.2 million in the first quarter of fiscal 2017. This primarily reflects revenue decreases of $1.9 million within our Global Services segment, partially offset by a revenue increase of $1.0 million within our Networking Platforms segment. |

[0000936395-17-000038:mdna:70]
| • | Asia Pacific ("APAC") revenue for the second quarter of fiscal 2017 was $142.9 million, an increase from $88.9 million in the first quarter of fiscal 2017. This primarily reflects revenue increases of $49.5 million within our Networking Platforms segment, $2.7 million within our Global Services segment and $1.8 million within our Software and Software-Related Services segment. |

[0000936395-17-000038:mdna:71]
| • | For the second quarter of fiscal 2017, AT&T accounted for 15.2% of total revenue. AT&T accounted for 15.5% of total revenue and Verizon accounted for 11.8% in the first quarter of fiscal 2017. |

[0000936395-17-000038:mdna:72]
Gross margin for the second quarter of fiscal 2017 was 45.0%, an increase from 44.1% in the first quarter of fiscal 2017. Improved gross margin for the second quarter of fiscal 2017 primarily reflects product cost reductions and lower warranty expense, partially offset by market-based price erosion and an increased provision for excess and obsolete inventory.

[0000936395-17-000038:mdna:73]
Operating expense was $260.4 million for the second quarter of fiscal 2017, an increase from $254.7 million in the first quarter of fiscal 2017. Second quarter fiscal 2017 operating expense primarily reflects increases of $4.8 million in research and development expense and $3.5 million in selling and marketing expense, partially offset by a decrease of $3.6 million in amortization of intangibles expense.

[0000936395-17-000038:mdna:74]
Income from operations for the second quarter of fiscal 2017 was $57.8 million, compared to income from operations of $19.1 million during the first quarter of fiscal 2017. Our net income for the second quarter of fiscal 2017 was $38.0 million, or $0.25 per diluted common share, compared to a net income of $3.9 million or $0.03 per diluted common share, for the first quarter of fiscal 2017.

[0000936395-17-000038:mdna:75]
We generated cash from operations of $72.0 million during the second quarter of fiscal 2017, compared to $26.3 million of cash used by operations during the first quarter of fiscal 2017. As of April 30, 2017, we had $628.6 million in cash and cash equivalents, $274.8 million of short-term investments in U.S. treasury securities and commercial paper and $89.9 million of long-term investments in U.S. treasury securities. This compares to $693.9 million in cash and cash equivalents, $250.1 million of short-term investments in U.S. treasury securities and commercial paper and $109.9 million of long-term investments in U.S. treasury securities, at January 31, 2017.

[0000936395-17-000038:mdna:76]
As of April 30, 2017, we had 5,663 employees, which reflects an increase from 5,555 at October 31, 2016 and an increase from 5,418 at April 30, 2016.

[0000936395-17-000038:mdna:77]
40

[0000936395-17-000038:mdna:78]
[same as prior period, unchanged from 0000936395-17-000020:mdna:77]

[0000936395-17-000038:mdna:79]
[same as prior period, unchanged from 0000936395-17-000020:mdna:78]

[0000936395-17-000038:mdna:80]
[same as prior period, unchanged from 0000936395-17-000020:mdna:79]

[0000936395-17-000038:mdna:81]
Quarter ended April 30, 2017 compared to the quarter ended April 30, 2016

[0000936395-17-000038:mdna:82]
[same as prior period, unchanged from 0000936395-17-000020:mdna:81]

[0000936395-17-000038:mdna:83]
During the second quarter of fiscal 2017, approximately 19.0% of our revenue was non-U.S. Dollar denominated, including sales in Euro, Canadian Dollar, Japanese Yen, British Pound, Argentina Peso, and Brazilian Real. During the second quarter of fiscal 2017 as compared to the second quarter of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $2.7 million, or 0.4%, as compared to the second quarter of fiscal 2016. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000038:mdna:84]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 502,131 |  |  | 71.0 |  | $ | 435,173 |  |  | 67.9 |  | $ | 66,958 |  |  | 15.4 |  |
| Packet Networking | 66,326 |  |  | 9.4 |  | 68,582 |  |  | 10.7 |  | (2,256 | ) |  | (3.3 | ) |
| Optical Transport | 3,030 |  |  | 0.4 |  | 8,451 |  |  | 1.3 |  | (5,421 | ) |  | (64.1 | ) |
| Total Networking Platforms | 571,487 |  |  | 80.8 |  | 512,206 |  |  | 79.9 |  | 59,281 |  |  | 11.6 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 13,143 |  |  | 1.9 |  | 11,772 |  |  | 1.9 |  | 1,371 |  |  | 11.6 |  |
| Software-Related Services | 24,573 |  |  | 3.5 |  | 18,701 |  |  | 2.9 |  | 5,872 |  |  | 31.4 |  |
| Total Software and Software-Related Services | 37,716 |  |  | 5.4 |  | 30,473 |  |  | 4.8 |  | 7,243 |  |  | 23.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 58,241 |  |  | 8.2 |  | 57,069 |  |  | 8.9 |  | 1,172 |  |  | 2.1 |  |
| Installation and Deployment | 28,695 |  |  | 4.1 |  | 30,232 |  |  | 4.7 |  | (1,537 | ) |  | (5.1 | ) |
| Consulting and Network Design | 10,883 |  |  | 1.5 |  | 10,737 |  |  | 1.7 |  | 146 |  |  | 1.4 |  |
| Total Global Services | 97,819 |  |  | 13.8 |  | 98,038 |  |  | 15.3 |  | (219 | ) |  | (0.2 | ) |
| Consolidated revenue | $ | 707,022 |  |  | 100.0 |  | $ | 640,717 |  |  | 100.0 |  | $ | 66,305 |  |  | 10.3 |  |

[0000936395-17-000038:mdna:85]
[same as prior period, unchanged from 0000936395-17-000020:mdna:84]

[0000936395-17-000038:mdna:86]
[same as prior period, unchanged from 0000936395-17-000020:mdna:85]

[0000936395-17-000038:mdna:87]
[same as prior period, unchanged from 0000936395-17-000020:mdna:86]

[0000936395-17-000038:mdna:88]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $67.0 million of our Converged Packet Optical products, partially offset by decreases of $5.4 million in sales of our Optical Transport products and $2.3 million in sales of our Packet Networking products. |

[0000936395-17-000038:mdna:89]
| ◦ | Converged Packet Optical sales reflect increases of $33.9 million of our 6500 Packet-Optical Platform, $18.5 million of our 5430 Reconfigurable Switching System, $18.3 million of our Waveserver stackable interconnect system and $3.7 million of our OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by sales decreases of $5.9 million of our Z-Series Packet-Optical Platform and $1.5 million of our CoreDirector® Multiservice Optical Switches. |

[0000936395-17-000038:mdna:90]
| ◦ | Packet Networking sales primarily reflects a decrease of $4.1 million of our 8700 Packetwave Platform, partially offset by a sales increase of $1.8 million of our 3000 and 5000 families of service delivery and aggregation switches. |

[0000936395-17-000038:mdna:91]
[same as prior period, unchanged from 0000936395-17-000020:mdna:90]

[0000936395-17-000038:mdna:92]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $5.9 million in software-related services and $1.4 million of our software platforms. The increase in software-related services is primarily due to sales increases of $4.2 million of software subscription services and $1.5 million of services supporting our Blue Planet software platform and advance software applications. The increase in software platform sales primarily reflects an increase of $1.1 million in sales of our OneControl Unified Management System. |

[0000936395-17-000038:mdna:93]
| • | Global Services segment revenue decreased slightly, primarily reflecting a sales decrease of $1.5 million of our installation and deployment services offset by a sales increase of $1.2 million of our maintenance support and training. |

[0000936395-17-000038:mdna:94]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as India. We believe that this is an important part of our strategy, and that it is required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-17-000038:mdna:95]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| North America | $ | 424,373 |  |  | 60.0 |  | $ | 395,505 |  |  | 61.7 |  | $ | 28,868 |  |  | 7.3 |  |
| EMEA | 105,776 |  |  | 15.0 |  | 96,175 |  |  | 15.0 |  | 9,601 |  |  | 10.0 |  |
| CALA | 33,971 |  |  | 4.8 |  | 57,896 |  |  | 9.0 |  | (23,925 | ) |  | (41.3 | ) |
| APAC | 142,902 |  |  | 20.2 |  | 91,141 |  |  | 14.3 |  | 51,761 |  |  | 56.8 |  |
| Total | $ | 707,022 |  |  | 100.0 |  | $ | 640,717 |  |  | 100.0 |  | $ | 66,305 |  |  | 10.3 |  |

[0000936395-17-000038:mdna:96]
[same as prior period, unchanged from 0000936395-17-000020:mdna:95]

[0000936395-17-000038:mdna:97]
[same as prior period, unchanged from 0000936395-17-000020:mdna:96]

[0000936395-17-000038:mdna:98]
[same as prior period, unchanged from 0000936395-17-000020:mdna:97]

[0000936395-17-000038:mdna:99]
| • | North America revenue primarily reflects increases of $27.2 million within our Networking Platforms segment and $2.9 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $1.2 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects a product line increase of $31.0 million of Converged Packet Optical sales, partially offset by product line decreases of $2.7 million of Packet Networking sales and $1.1 million in Optical Transport sales. The revenue increase within Converged Packet Optical primarily reflects increases of $15.2 million in sales of our Waveserver stackable interconnect system and $13.3 million in sales of our 6500 Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. The revenue increase for our 6500 Packet-Optical Platform primarily reflects increased sales to communications service providers, partially offset by decreases in sales to AT&T and to a certain cable and multiservice operator who was acquired during the third quarter of 2016. The increase within our Software and Software-Related Services segment primarily reflects a sales increase of $3.3 million of our software subscription services. |

[0000936395-17-000038:mdna:100]
| • | EMEA revenue primarily reflects increases of $10.9 million within our Networking Platforms segment and $1.7 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $3.0 million within our Global Services segment. Our Networking Platforms segment revenue primarily reflects a product line increase of $9.6 million in Converged Packet Optical sales, primarily due to increases of $6.4 million of sales for |

[0000936395-17-000038:mdna:101]
42

[0000936395-17-000038:mdna:102]
our 6500 Packet-Optical Platform to certain communications service providers and $3.1 million of sales of our Waveserver stackable interconnect system to Web-scale providers and communications service providers.

[0000936395-17-000038:mdna:103]
| • | CALA revenue primarily reflects a decrease of $24.4 million within our Networking Platforms segment. The revenue decrease within our Networking Platforms segment primarily reflects product line decreases of $23.1 million of Converged Packet Optical sales and $1.6 million in Optical Transport sales. The revenue decrease within Converged Packet Optical primarily reflects decreases of $12.2 million in sales of our 5430 Reconfigurable Switching System and $9.4 million in sales of our 6500 Packet-Optical Platform. The decrease in CALA revenue primarily relates to decreased sales to certain communications service providers in Brazil. |

[0000936395-17-000038:mdna:104]
| • | APAC revenue primarily reflects increases of $45.6 million within our Networking Platforms segment, $3.5 million within our Global Services segment and $2.6 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects a product line increase of $49.5 million of Converged Packet Optical sales, partially offset by product line decreases of $2.9 million of Packet Networking sales and $1.0 million in Optical Transport sales. The revenue increase within Converged Packet Optical reflects an increase of $25.3 million in sales of our 5430 Reconfigurable Switching System, primarily due to increased sales to Reliance Jio Infocomm, a communications service provider in India. In addition, this product line reflects a revenue increase of $23.6 million in sales of our 6500 Packet-Optical Platform, primarily related to sales through our strategic relationship with Ericsson in Australia, communication service providers, Web-scale providers and submarine network operators in Singapore, and sales to Reliance Jio Infocomm in India. APAC revenue has increased meaningfully in recent periods reflecting in part significant revenue growth in India, where we have benefited from initiatives to gain subscribers and unprecedented subscriber growth and related network projects. Changes in spending and the timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-17-000038:mdna:105]
[same as prior period, unchanged from 0000936395-17-000020:mdna:103]

[0000936395-17-000038:mdna:106]
[same as prior period, unchanged from 0000936395-17-000020:mdna:104]

[0000936395-17-000038:mdna:107]
[same as prior period, unchanged from 0000936395-17-000020:mdna:105]

[0000936395-17-000038:mdna:108]
[same as prior period, unchanged from 0000936395-17-000020:mdna:106]

[0000936395-17-000038:mdna:109]
[same as prior period, unchanged from 0000936395-17-000020:mdna:107]

[0000936395-17-000038:mdna:110]
[same as prior period, unchanged from 0000936395-17-000020:mdna:108]

[0000936395-17-000038:mdna:111]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 707,022 |  |  | 100.0 |  | $ | 640,717 |  |  | 100.0 |  | $ | 66,305 |  |  | 10.3 |
| Total cost of goods sold | 388,782 |  |  | 55.0 |  | 357,624 |  |  | 55.8 |  | 31,158 |  |  | 8.7 |
| Gross profit | $ | 318,240 |  |  | 45.0 |  | $ | 283,093 |  |  | 44.2 |  | $ | 35,147 |  |  | 12.4 |

[0000936395-17-000038:mdna:112]
[same as prior period, unchanged from 0000936395-17-000020:mdna:110]

[0000936395-17-000038:mdna:113]
[same as prior period, unchanged from 0000936395-17-000020:mdna:111]

[0000936395-17-000038:mdna:114]
[same as prior period, unchanged from 0000936395-17-000020:mdna:112]

[0000936395-17-000038:mdna:115]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 584,630 |  |  | 100.0 |  | $ | 523,978 |  |  | 100.0 |  | $ | 60,652 |  |  | 11.6 |
| Product cost of goods sold | 327,295 |  |  | 56.0 |  | 291,778 |  |  | 55.7 |  | 35,517 |  |  | 12.2 |
| Product gross profit | $ | 257,335 |  |  | 44.0 |  | $ | 232,200 |  |  | 44.3 |  | $ | 25,135 |  |  | 10.8 |

[0000936395-17-000038:mdna:116]
[same as prior period, unchanged from 0000936395-17-000020:mdna:114]

[0000936395-17-000038:mdna:117]
[same as prior period, unchanged from 0000936395-17-000020:mdna:115]

[0000936395-17-000038:mdna:118]
[same as prior period, unchanged from 0000936395-17-000020:mdna:116]

[0000936395-17-000038:mdna:119]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 122,392 |  |  | 100.0 |  | $ | 116,739 |  |  | 100.0 |  | $ | 5,653 |  |  | 4.8 |  |
| Service cost of goods sold | 61,487 |  |  | 50.2 |  | 65,846 |  |  | 56.4 |  | (4,359 | ) |  | (6.6 | ) |
| Service gross profit | $ | 60,905 |  |  | 49.8 |  | $ | 50,893 |  |  | 43.6 |  | $ | 10,012 |  |  | 19.7 |  |

[0000936395-17-000038:mdna:120]
[same as prior period, unchanged from 0000936395-17-000020:mdna:118]

[0000936395-17-000038:mdna:121]
[same as prior period, unchanged from 0000936395-17-000020:mdna:119]

[0000936395-17-000038:mdna:122]
[same as prior period, unchanged from 0000936395-17-000020:mdna:120]

[0000936395-17-000038:mdna:123]
| • | Gross profit as a percentage of revenue reflects improved services gross profit partially offset by reduced product gross profit. |

[0000936395-17-000038:mdna:124]
| • | Gross profit on products as a percentage of product revenue decreased slightly as a result of market-based price erosion partially offset by product cost reductions, lower warranty expense and improved manufacturing efficiencies. |

[0000936395-17-000038:mdna:125]
| • | Gross profit on services as a percentage of services revenue increased primarily due to sales of higher margin software subscription services and improved margin on installation and professional services. |

[0000936395-17-000038:mdna:126]
[same as prior period, unchanged from 0000936395-17-000020:mdna:124]

[0000936395-17-000038:mdna:127]
[same as prior period, unchanged from 0000936395-17-000020:mdna:125]

[0000936395-17-000038:mdna:128]
[same as prior period, unchanged from 0000936395-17-000020:mdna:126]

[0000936395-17-000038:mdna:129]
[same as prior period, unchanged from 0000936395-17-000020:mdna:127]

[0000936395-17-000038:mdna:130]
[same as prior period, unchanged from 0000936395-17-000020:mdna:128]

[0000936395-17-000038:mdna:131]
[same as prior period, unchanged from 0000936395-17-000020:mdna:129]

[0000936395-17-000038:mdna:132]
[same as prior period, unchanged from 0000936395-17-000020:mdna:131]

[0000936395-17-000038:mdna:133]
[same as prior period, unchanged from 0000936395-17-000020:mdna:130]

[0000936395-17-000038:mdna:134]
[same as prior period, unchanged from 0000936395-17-000020:mdna:132]

[0000936395-17-000038:mdna:135]
[same as prior period, unchanged from 0000936395-17-000020:mdna:133]

[0000936395-17-000038:mdna:136]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 121,623 |  |  | 17.2 |  | $ | 114,603 |  |  | 17.9 |  | $ | 7,020 |  |  | 6.1 |  |
| Selling and marketing | 88,551 |  |  | 12.5 |  | 86,668 |  |  | 13.5 |  | 1,883 |  |  | 2.2 |  |
| General and administrative | 34,990 |  |  | 4.9 |  | 35,203 |  |  | 5.5 |  | (213 | ) |  | (0.6 | ) |
| Amortization of intangible assets | 10,980 |  |  | 1.6 |  | 15,566 |  |  | 2.4 |  | (4,586 | ) |  | (29.5 | ) |
| Acquisition and integration costs | — |  |  | — |  | 2,285 |  |  | 0.4 |  | (2,285 | ) |  | (100.0 | ) |
| Restructuring costs | 4,276 |  |  | 0.6 |  | 535 |  |  | 0.1 |  | 3,741 |  |  | 699.3 |  |
| Total operating expenses | $ | 260,420 |  |  | 36.8 |  | $ | 254,860 |  |  | 39.8 |  | $ | 5,560 |  |  | 2.2 |  |

[0000936395-17-000038:mdna:137]
[same as prior period, unchanged from 0000936395-17-000020:mdna:135]

[0000936395-17-000038:mdna:138]
[same as prior period, unchanged from 0000936395-17-000020:mdna:136]

[0000936395-17-000038:mdna:139]
[same as prior period, unchanged from 0000936395-17-000020:mdna:137]

[0000936395-17-000038:mdna:140]
| • | Research and development expense increased by $7.0 million. This change reflects increases of $4.0 million in employee and compensation costs and $3.0 million in facilities and information technology costs. |

[0000936395-17-000038:mdna:141]
| • | Selling and marketing expense increased by $1.9 million, primarily reflecting increases of $0.6 million in employee and compensation costs and $0.6 million in facilities and information technology costs. |

[0000936395-17-000038:mdna:142]
| • | General and administrative expense remained relatively unchanged. |

[0000936395-17-000038:mdna:143]
[same as prior period, unchanged from 0000936395-17-000020:mdna:142]

[0000936395-17-000038:mdna:144]
[same as prior period, unchanged from 0000936395-17-000020:mdna:141]

[0000936395-17-000038:mdna:145]
| • | Restructuring costs increased primarily reflecting unfavorable lease commitments and relocation costs incurred in connection with the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000038:mdna:146]
[same as prior period, unchanged from 0000936395-17-000020:mdna:144]

[0000936395-17-000038:mdna:147]
[same as prior period, unchanged from 0000936395-17-000020:mdna:145]

[0000936395-17-000038:mdna:148]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,918 | ) |  | (0.4 | ) |  | $ | 967 |  |  | 0.2 |  | $ | (3,885 | ) |  | 401.8 |
| Interest expense | $ | 13,308 |  |  | 1.9 |  |  | $ | 12,608 |  |  | 2.0 |  | $ | 700 |  |  | 5.6 |
| Provision for income taxes | $ | 3,568 |  |  | 0.5 |  |  | $ | 2,595 |  |  | 0.4 |  | $ | 973 |  |  | 37.5 |

[0000936395-17-000038:mdna:149]
[same as prior period, unchanged from 0000936395-17-000020:mdna:147]

[0000936395-17-000038:mdna:150]
[same as prior period, unchanged from 0000936395-17-000020:mdna:148]

[0000936395-17-000038:mdna:151]
[same as prior period, unchanged from 0000936395-17-000020:mdna:149]

[0000936395-17-000038:mdna:152]
| • | Interest and other income (loss), net primarily reflects $2.9 million in debt modification expenses related to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017. For additional information about our term loans, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000038:mdna:153]
| • | Interest expense increased primarily due to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017 and the 2021 Term Loan that was entered into in the second quarter of fiscal 2016. For additional information about our term loans, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000038:mdna:154]
| • | Provision for income taxes increased primarily due to foreign and state tax expense. |

[0000936395-17-000038:mdna:155]
Six months ended April 30, 2017 compared to the six months ended April 30, 2016

[0000936395-17-000038:mdna:156]
Revenue

[0000936395-17-000038:mdna:157]
During the first six months of fiscal 2017, approximately 18.7% of our revenue was non-U.S. Dollar denominated, including sales in Euro, Canadian Dollar, Japanese Yen, Brazilian Real, British Pound and Argentina Peso. During the first six months of fiscal 2017 as compared to the first six months of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $4.9 million or 0.4%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000038:mdna:158]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 914,783 |  |  | 68.9 |  | $ | 824,341 |  |  | 68.0 |  | $ | 90,442 |  |  | 11.0 |  |
| Packet Networking | 138,520 |  |  | 10.4 |  | 116,779 |  |  | 9.6 |  | 21,741 |  |  | 18.6 |  |
| Optical Transport | 8,128 |  |  | 0.6 |  | 20,596 |  |  | 1.7 |  | (12,468 | ) |  | (60.5 | ) |
| Total Networking Platforms | 1,061,431 |  |  | 79.9 |  | 961,716 |  |  | 79.3 |  | 99,715 |  |  | 10.4 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 30,192 |  |  | 2.3 |  | 19,851 |  |  | 1.6 |  | 10,341 |  |  | 52.1 |  |
| Software-Related Services | 46,904 |  |  | 3.5 |  | 36,048 |  |  | 3.0 |  | 10,856 |  |  | 30.1 |  |
| Total Software and Software-Related Services | 77,096 |  |  | 5.8 |  | 55,899 |  |  | 4.6 |  | 21,197 |  |  | 37.9 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 113,231 |  |  | 8.5 |  | 113,127 |  |  | 9.3 |  | 104 |  |  | 0.1 |  |
| Installation and Deployment | 56,614 |  |  | 4.3 |  | 61,072 |  |  | 5.0 |  | (4,458 | ) |  | (7.3 | ) |
| Consulting and Network Design | 20,147 |  |  | 1.5 |  | 22,018 |  |  | 1.8 |  | (1,871 | ) |  | (8.5 | ) |
| Total Global Services | 189,992 |  |  | 14.3 |  | 196,217 |  |  | 16.1 |  | (6,225 | ) |  | (3.2 | ) |
| Consolidated revenue | $ | 1,328,519 |  |  | 100.0 |  | $ | 1,213,832 |  |  | 100.0 |  | $ | 114,687 |  |  | 9.4 |  |

[0000936395-17-000038:mdna:159]
_____________________________

[0000936395-17-000038:mdna:160]
*    Denotes % of total revenue

[0000936395-17-000038:mdna:161]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:162]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $90.5 million of our Converged Packet Optical products and $21.7 million of our Packet Networking products, partially offset by a decrease of $12.5 million in sales of our Optical Transport products. |

[0000936395-17-000038:mdna:163]
| ◦ | Converged Packet Optical sales primarily reflect increases of $66.3 million of our 6500 Packet-Optical Platform, $30.7 million of our Waveserver stackable interconnect system, $13.6 million of our 5430 Reconfigurable Switching System and $3.8 million of our OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by sales decreases of $18.0 million of our Z-Series Packet-Optical Platform and $5.8 million of our CoreDirector® Multiservice Optical Switches. |

[0000936395-17-000038:mdna:164]
| ◦ | Packet Networking sales primarily reflect increases of $20.5 million of our 3000 and 5000 families of service delivery and aggregation switches and $1.0 million of our 8700 Packetwave Platform. |

[0000936395-17-000038:mdna:165]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-17-000038:mdna:166]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $10.9 million in software-related services and $10.3 million of our software platforms. The increase in software-related services is primarily due to sales increases of $7.3 million of software subscription services, $2.4 million of services supporting our Blue Planet software platform and advance software applications and $1.1 million of software-enabled services. The increase in software platform sales reflects increases of $6.9 million in sales of our Blue Planet software platform and advanced software applications and $3.4 million in sales of our other legacy software platforms. |

[0000936395-17-000038:mdna:167]
| • | Global Services segment revenue decreased, primarily reflecting sales decreases of $4.5 million of our installation and deployment services and $1.9 million of our consulting and network design services. |

[0000936395-17-000038:mdna:168]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-17-000038:mdna:169]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| North America | $ | 830,301 |  |  | 62.5 |  | $ | 788,209 |  |  | 64.9 |  | $ | 42,092 |  |  | 5.3 |  |
| EMEA | 197,319 |  |  | 14.9 |  | 176,897 |  |  | 14.6 |  | 20,422 |  |  | 11.5 |  |
| CALA | 69,117 |  |  | 5.2 |  | 101,706 |  |  | 8.4 |  | (32,589 | ) |  | (32.0 | ) |
| APAC | 231,782 |  |  | 17.4 |  | 147,020 |  |  | 12.1 |  | 84,762 |  |  | 57.7 |  |
| Total | $ | 1,328,519 |  |  | 100.0 |  | $ | 1,213,832 |  |  | 100.0 |  | $ | 114,687 |  |  | 9.4 |  |

[0000936395-17-000038:mdna:170]
[same as prior period, unchanged from 0000936395-17-000020:mdna:156]

[0000936395-17-000038:mdna:171]
*    Denotes % of total revenue

[0000936395-17-000038:mdna:172]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:173]
| • | North America revenue primarily reflects increases of $33.3 million within our Networking Platforms segment and$15.5 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $6.7 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $25.6 million of Converged Packet Optical sales and $10.6 million of Packet Networking sales, partially offset by a product line decrease of $2.9 million in Optical Transport sales. The revenue increase within Converged Packet Optical sales primarily reflects increases of $26.1 million in sales of our Waveserver stackable interconnect system and $12.7 million in sales of our 6500 Packet-Optical Platform, partially offset by a decrease of $16.7 million in sales of our Z-Series Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. The revenue increase for our 6500 Packet-Optical Platform primarily reflecting increased sales to service providers, partially offset by decreases in sales to AT&T and to a certain cable and multiservice operator who was acquired during the third quarter of 2016. The revenue increase within Packet Networking primarily reflects an increase of $12.2 million in sales of our 3000 and 5000 families of service delivery and aggregation switches to AT&T and other communication service providers. The revenue increase within our Software and Software-Related Services segment primarily reflects sales increases of $6.5 million of our software subscription services, $4.3 million in sales of our Blue Planet software platform, $2.4 million of our other legacy software platforms and $2.3 million of other software related services. |

[0000936395-17-000038:mdna:174]
| • | EMEA revenue primarily reflects increases of $22.9 million within our Networking Platforms segment and $2.5 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $5.0 million within our Global Services segment. Our Networking Platforms segment revenue reflects a product line |

[0000936395-17-000038:mdna:175]
[same as prior period, unchanged from 0000936395-17-000020:mdna:192]

[0000936395-17-000038:mdna:176]
increase of $22.8 million in Converged Packet Optical sales, primarily due to increased sales of the 6500 Packet-Optical Platform to certain communication service providers.

[0000936395-17-000038:mdna:177]
| • | CALA revenue primarily reflects a decrease of $35.2 million within our Networking Platforms segment partially offset by a revenue increase of $2.4 million within our Global Services segment. The revenue decrease within our Networking Platforms segment primarily reflects product line decreases of $33.3 million of Converged Packet Optical sales and $3.3 million in Optical Transport sales partially offset by a product line increase of $1.4 million of Packet Networking sales. The revenue decrease within Converged Packet Optical primarily reflects decreases of $15.9 million in sales of our 6500 Packet-Optical Platform and $15.2 million in sales of our 5430 Reconfigurable Switching System. The decrease in CALA revenue primarily relates to decreased sales in Brazil and Mexico. |

[0000936395-17-000038:mdna:178]
| • | APAC revenue primarily reflects increases of $78.7 million within our Networking Platforms segment, $3.1 million within our Global Services segment and $2.9 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects product line increases of $75.5 million of Converged Packet Optical sales and $4.9 million of Packet Networking sales, partially offset by a product line decrease of $1.7 million in Optical Transport sales. The revenue increase within Converged Packet Optical reflects an increase of $48.3 million in sales of our 6500 Packet-Optical Platform primarily due to increased sales to Reliance Jio Infocomm in India, sales through our strategic relationship with Ericsson in Australia, communication service providers, Web-scale providers and submarine network operators in Singapore and communication service providers in Japan. The revenue increase within Converged Packet Optical also reflects an increase of $26.4 million of our 5430 Reconfigurable Switching System sales primarily due to increased sales to Reliance Jio Infocomm in India. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-17-000038:mdna:179]
Cost of Goods Sold and Gross Profit

[0000936395-17-000038:mdna:180]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-17-000038:mdna:181]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,328,519 |  |  | 100.0 |  | $ | 1,213,832 |  |  | 100.0 |  | $ | 114,687 |  |  | 9.4 |
| Total cost of goods sold | 736,494 |  |  | 55.4 |  | 679,289 |  |  | 56.0 |  | 57,205 |  |  | 8.4 |
| Gross profit | $ | 592,025 |  |  | 44.6 |  | $ | 534,543 |  |  | 44.0 |  | $ | 57,482 |  |  | 10.8 |

[0000936395-17-000038:mdna:182]
[same as prior period, unchanged from 0000936395-17-000020:mdna:201]

[0000936395-17-000038:mdna:183]
*    Denotes % of total revenue

[0000936395-17-000038:mdna:184]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:185]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,091,623 |  |  | 100.0 |  | $ | 981,567 |  |  | 100.0 |  | $ | 110,056 |  |  | 11.2 |
| Product cost of goods sold | 614,106 |  |  | 56.3 |  | 552,260 |  |  | 56.3 |  | 61,846 |  |  | 11.2 |
| Product gross profit | $ | 477,517 |  |  | 43.7 |  | $ | 429,307 |  |  | 43.7 |  | $ | 48,210 |  |  | 11.2 |

[0000936395-17-000038:mdna:186]
_____________________________________

[0000936395-17-000038:mdna:187]
*    Denotes % of product revenue

[0000936395-17-000038:mdna:188]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:189]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 236,896 |  |  | 100.0 |  | $ | 232,265 |  |  | 100.0 |  | $ | 4,631 |  |  | 2.0 |  |
| Service cost of goods sold | 122,388 |  |  | 51.7 |  | 127,029 |  |  | 54.7 |  | (4,641 | ) |  | (3.7 | ) |
| Service gross profit | $ | 114,508 |  |  | 48.3 |  | $ | 105,236 |  |  | 45.3 |  | $ | 9,272 |  |  | 8.8 |  |

[0000936395-17-000038:mdna:190]
_____________________________________

[0000936395-17-000038:mdna:191]
*    Denotes % of services revenue

[0000936395-17-000038:mdna:192]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:193]
| • | Gross profit as a percentage of revenue reflects improved services gross profit. |

[0000936395-17-000038:mdna:194]
| • | Gross profit on products as a percentage of product revenue reflects a lower warranty provision and product cost reductions offset by market-based price erosion. |

[0000936395-17-000038:mdna:195]
| • | Gross profit on services as a percentage of services revenue increased primarily due to sales of higher margin software subscription services and improved margin on installation and professional services. |

[0000936395-17-000038:mdna:196]
Operating Expense

[0000936395-17-000038:mdna:197]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-17-000038:mdna:198]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 238,492 |  |  | 18.0 |  | $ | 222,649 |  |  | 18.3 |  | $ | 15,843 |  |  | 7.1 |  |
| Selling and marketing | 173,553 |  |  | 13.1 |  | 169,146 |  |  | 13.9 |  | 4,407 |  |  | 2.6 |  |
| General and administrative | 70,854 |  |  | 5.3 |  | 66,345 |  |  | 5.5 |  | 4,509 |  |  | 6.8 |  |
| Amortization of intangible assets | 25,531 |  |  | 1.9 |  | 32,428 |  |  | 2.7 |  | (6,897 | ) |  | (21.3 | ) |
| Acquisition and integration costs | — |  |  | — |  | 3,584 |  |  | 0.3 |  | (3,584 | ) |  | (100.0 | ) |
| Restructuring costs | 6,671 |  |  | 0.5 |  | 919 |  |  | 0.1 |  | 5,752 |  |  | 625.9 |  |
| Total operating expenses | $ | 515,101 |  |  | 38.8 |  | $ | 495,071 |  |  | 40.8 |  | $ | 20,030 |  |  | 4.0 |  |

[0000936395-17-000038:mdna:199]
_____________________________________

[0000936395-17-000038:mdna:200]
*    Denotes % of total revenue

[0000936395-17-000038:mdna:201]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:202]
| • | Research and development expense was adversely affected by $2.0 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $15.8 million. This change primarily reflects increases of $8.7 million in employee and compensation costs and $8.1 million in facilities and information technology costs. |

[0000936395-17-000038:mdna:203]
| • | Selling and marketing expense increased by $4.4 million, primarily reflecting increases of $1.7 million in employee and compensation costs, $1.2 million in facilities and information technology costs and $1.0 million in selling and marketing related costs. |

[0000936395-17-000038:mdna:204]
| • | General and administrative expense increased by $4.5 million, primarily reflecting increases $2.3 million for professional services and legal fees and $1.1 million for facilities and information technology costs. |

[0000936395-17-000038:mdna:205]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-17-000038:mdna:206]
| • | Acquisition and integration costs incurred during fiscal 2016 reflects expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-17-000038:mdna:207]
| • | Restructuring costs increased primarily reflecting unfavorable lease commitments and relocation costs incurred in connection with the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. Also contributing to the increase was a global workforce reduction of approximately 50 employees in the first quarter of fiscal 2017 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. |

[0000936395-17-000038:mdna:208]
Other items

[0000936395-17-000038:mdna:209]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-17-000038:mdna:210]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (2,548 | ) |  | (0.2 | ) |  | $ | (7,809 | ) |  | (0.6 | ) |  | $ | 5,261 |  |  | 67.4 |
| Interest expense | $ | 28,511 |  |  | 2.1 |  |  | $ | 25,318 |  |  | 2.1 |  |  | $ | 3,193 |  |  | 12.6 |
| Provision for income taxes | $ | 3,978 |  |  | 0.3 |  |  | $ | 3,894 |  |  | 0.3 |  |  | $ | 84 |  |  | 2.2 |

[0000936395-17-000038:mdna:211]
_____________________________________

[0000936395-17-000038:mdna:212]
*    Denotes % of total revenue

[0000936395-17-000038:mdna:213]
**    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:214]
| • | Interest and other income (loss), net primarily reflects the improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by $2.9 million in debt modification expenses related to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017. For additional information about our term loans, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000038:mdna:215]
| • | Interest expense increased primarily due to the 2022 Term Loan that was entered into in the second quarter of fiscal 2017 and the 2021 Term Loan that was entered into in the second quarter of fiscal 2016. For additional information about our term loans, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000038:mdna:216]
| • | Provision for income taxes slightly increased primarily due to increased state tax expense. |

[0000936395-17-000038:mdna:217]
[same as prior period, unchanged from 0000936395-17-000020:mdna:153]

[0000936395-17-000038:mdna:218]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-17-000038:mdna:219]
|  | Quarter Ended April 30, |  |  |  |
|  | 2017 |  | 2016 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 150,464 |  |  | $ | 132,606 |  |  | $ | 17,858 |  |  | 13.5 |  |
| Software and Software-Related Services | $ | 4,551 |  |  | $ | 192 |  |  | $ | 4,359 |  |  | (2,270.3 | ) |
| Global Services | $ | 41,602 |  |  | $ | 35,692 |  |  | $ | 5,910 |  |  | 16.6 |  |

[0000936395-17-000038:mdna:220]
_____________________________________

[0000936395-17-000038:mdna:221]
[same as prior period, unchanged from 0000936395-17-000020:mdna:157]

[0000936395-17-000038:mdna:222]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, resulting in increased gross profits, partially offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs as a result of the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000038:mdna:223]
| • | Software and Software-Related Services segment profit increased primarily due to higher sales volume, as described above, resulting in increased gross profits, partially offset by increased research and development costs. Research and development costs primarily reflect increased expense relating to the continued development of our Blue Planet software platform. |

[0000936395-17-000038:mdna:224]
| • | Global Services segment profit increased, primarily due to improved gross margin on installation and deployment services and consulting and network design services. |

[0000936395-17-000038:mdna:225]
[same as prior period, unchanged from 0000936395-17-000020:mdna:154]

[0000936395-17-000038:mdna:226]
|  | Six Months Ended April 30, |  |  |  |  |
|  | 2017 |  | 2016 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 264,210 |  |  | $ | 239,588 |  |  | $ | 24,622 |  |  | 10.3 |
| Software and Software-Related Services | $ | 12,252 |  |  | $ | (3,382 | ) |  | $ | 15,634 |  |  | 462.3 |
| Global Services | $ | 77,071 |  |  | $ | 75,688 |  |  | $ | 1,383 |  |  | 1.8 |

[0000936395-17-000038:mdna:227]
_____________________________________

[0000936395-17-000038:mdna:228]
*    Denotes % change from 2016 to 2017

[0000936395-17-000038:mdna:229]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, partially offset by increased research and development costs and reduced gross margin. The reduced gross margin primarily reflects market-based price erosion partially offset by product cost reductions and lower warranty expense. Research and development costs primarily reflect increased expenses relating to the continued development of our coherent modem technology, including our WaveLogic Ai coherent optical chipset, and relocation costs as a result of the facility transition from our existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000038:mdna:230]
[same as prior period, unchanged from 0000936395-17-000020:mdna:159]

[0000936395-17-000038:mdna:231]
| • | Global Services segment profit increased, primarily due to improved gross margin, as described above, partially offset by lower sales volume. |

[0000936395-17-000038:mdna:232]
[same as prior period, unchanged from 0000936395-17-000020:mdna:161]

[0000936395-17-000038:mdna:233]
For the six months ended April 30, 2017, we generated $45.7 million in cash to fund our operating needs, as our net income (adjusted for non-cash charges) of $168.1 million exceeded our working capital requirements of $122.4 million. The increase in working capital was primarily driven by inventory increases of $95.6 million. For additional details, see the discussion below entitled “Cash from Operations.”

[0000936395-17-000038:mdna:234]
Despite our cash generated from operations, our total cash, cash equivalents and investments decreased by $149.8 million during the first six months of fiscal 2017. This decrease principally reflects the refinancing of our existing 2019 Term Loan and 2021 Term Loan into a new 2022 Term Loan, which reflects the receipt of a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and the payment of $493.1 million toward the aggregate principal amount outstanding of the 2019 Term Loan and 2021 Term Loan. As a result, we used $93.6 million in cash, representing the original discount on the 2022 Term Loan and the repayment of $93.1 million of the outstanding principal under the 2019 Term Loan and 2021 Term Loan. The remaining balances under the 2019 Term Loan and 2021 Term Loan were refinanced and replaced by the 2022 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information relating to this refinancing transaction. The decrease also reflects cash used in investing activities for capital expenditures totaling $60.3 million, use of cash to fund the repurchase of $46.3 million in outstanding 0.875% Convertible Senior Notes due June 15, 2017, and our settlement of certain foreign currency forward contracts of $3.0 million. Proceeds from the issuance of equity under our employee stock purchase plans provided approximately $10.3 million in cash during the period. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-17-000038:mdna:235]
|  | April 30, 2017 |  | October 31, 2016 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 628,623 |  |  | $ | 777,615 |  |  | $ | (148,992 | ) |
| Short-term investments in marketable debt securities | 274,779 |  |  | 275,248 |  |  | (469 | ) |
| Long-term investments in marketable debt securities | 89,852 |  |  | 90,172 |  |  | (320 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 993,254 |  |  | $ | 1,143,035 |  |  | $ | (149,781 | ) |

[0000936395-17-000038:mdna:236]
Our principal sources of liquidity on hand include our cash and investments, which as of April 30, 2017 totaled $993.3 million, as well as our ABL Credit Facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of

[0000936395-17-000038:mdna:237]
51

[0000936395-17-000038:mdna:238]
December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of April 30, 2017, letters of credit totaling $72.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2017.

[0000936395-17-000038:mdna:239]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $53.1 million as of April 30, 2017. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-17-000038:mdna:240]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-17-000038:mdna:241]
Based on past performance and current expectations, we believe that cash from operations, cash and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, the repayment at maturity of the remaining $185.3 million in aggregate principal remaining outstanding on our 0.875% convertible senior notes due June 15, 2017, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-17-000038:mdna:242]
[same as prior period, unchanged from 0000936395-17-000020:mdna:170]

[0000936395-17-000038:mdna:243]
The following sections set forth the components of our $45.7 million of cash generated operating activities during the first six months of fiscal 2017:

[0000936395-17-000038:mdna:244]
[same as prior period, unchanged from 0000936395-17-000020:mdna:172]

[0000936395-17-000038:mdna:245]
[same as prior period, unchanged from 0000936395-17-000020:mdna:173]

[0000936395-17-000038:mdna:246]
|  | Six months ended |
|  | April 30, 2017 |
| Net income | $ | 41,887 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 35,548 |  |
| Share-based compensation costs | 24,830 |  |
| Amortization of intangible assets | 33,466 |  |
| Provision for inventory excess and obsolescence | 19,623 |  |
| Provision for warranty | 2,347 |  |
| Other | 10,416 |  |
| Net income (adjusted for non-cash charges) | $ | 168,117 |  |

[0000936395-17-000038:mdna:247]
[same as prior period, unchanged from 0000936395-17-000020:mdna:175]

[0000936395-17-000038:mdna:248]
We used $122.4 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-17-000038:mdna:249]
|  | Six months ended |
|  | April 30, 2017 |
| Cash provided by accounts receivable | $ | 9,381 |  |
| Cash used in inventories | (95,554 | ) |
| Cash used in prepaid expenses and other | (15,054 | ) |
| Cash used in accounts payable, accruals and other obligations | (24,974 | ) |
| Cash provided by deferred revenue | 3,832 |  |
| Total cash used for working capital | $ | (122,369 | ) |

[0000936395-17-000038:mdna:250]
[same as prior period, unchanged from 0000936395-17-000020:mdna:178]

[0000936395-17-000038:mdna:251]
| • | The $9.4 million of cash provided by accounts receivable during the first six months of fiscal 2017 reflects increased sales volume and improved collections as of the end of the second quarter of fiscal 2017; |

[0000936395-17-000038:mdna:252]
| • | The $95.6 million of cash used in inventory during the first six months of fiscal 2017 primarily reflects increases in finished goods to meet customer delivery schedules and deferred costs of sales awaiting customer acceptance; |

[0000936395-17-000038:mdna:253]
| • | Cash used in prepaid expense and other during the first six months of fiscal 2017 was $15.1 million, primarily reflecting higher prepaid value added taxes and product demonstration equipment; |

[0000936395-17-000038:mdna:254]
| • | The $25.0 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2017 primarily reflects the timing of bonus payments to employees under our annual cash incentive compensation plan; and |

[0000936395-17-000038:mdna:255]
| • | The $3.8 million of cash provided by deferred revenue during the first six months of fiscal 2017 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-17-000038:mdna:256]
Our days sales outstanding (DSOs) for the first six months of fiscal 2017 were 77 days and our inventory turns for the first six months of fiscal 2017 were 4.3.

[0000936395-17-000038:mdna:257]
[same as prior period, unchanged from 0000936395-17-000020:mdna:185]

[0000936395-17-000038:mdna:258]
[same as prior period, unchanged from 0000936395-17-000020:mdna:186]

[0000936395-17-000038:mdna:259]
|  | Six months ended |
|  | April 30, 2017 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 1,013 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | 6,562 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 3,750 |  |
| Term Loan due July 15, 2019(4) | 2,342 |  |
| Term Loan due April 25, 2021(5) | 2,702 |  |
| Term Loan due January 30, 2022 (6) | 2,983 |  |
| Interest rate swaps(7) | 2,058 |  |
| ABL Credit Facility(8) | 813 |  |
| Capital leases | 1,216 |  |
| Cash paid during period | $ | 23,439 |  |

[0000936395-17-000038:mdna:260]
[same as prior period, unchanged from 0000936395-17-000020:mdna:188]

[0000936395-17-000038:mdna:261]
[same as prior period, unchanged from 0000936395-17-000020:mdna:189]

[0000936395-17-000038:mdna:262]
[same as prior period, unchanged from 0000936395-17-000020:mdna:190]

[0000936395-17-000038:mdna:263]
| (4) | Interest on the 2019 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bore interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. On the first day of our second quarter of fiscal 2017, we refinanced and replaced this term loan with the 2022 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information. |

[0000936395-17-000038:mdna:264]
| (5) | Interest on the 2021 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2021 Term Loan bore interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. On the first day of our second quarter of fiscal 2017, we refinanced and replaced this term loan with the 2022 Term Loan. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information. |

[0000936395-17-000038:mdna:265]
| (6) | Interest on the 2022 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of the second quarter of fiscal 2017 the interest rate on the 2022 Term Loan was 3.49%. |

[0000936395-17-000038:mdna:266]
| (7) | Prior to the term loan refinancing, payments on our interest rate swaps were variable and effectively fixed the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan |

[0000936395-17-000038:mdna:267]
53

[0000936395-17-000038:mdna:268]
at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. In connection with the refinancing of the 2019 and 2021 Term Loans into the 2022 Term Loan, in order to align our interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, we reduced the total outstanding value of our interest rate swaps and also entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020 and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during the periods described above will be 4.25%, 4.25% and 4.51%, respectively.

[0000936395-17-000038:mdna:269]
| (8) | During the first six months of fiscal 2017, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.8 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-17-000038:mdna:270]
For additional information about our convertible notes and term loans (including the refinancing of our 2019 and 2021 Term Loans into the 2022 Term Loan), ABL Credit Facility and interest rate swaps, see Notes 14, 16 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-17-000038:mdna:271]
[same as prior period, unchanged from 0000936395-17-000020:mdna:198]

[0000936395-17-000038:mdna:272]
The following is a summary of our future minimum payments under contractual obligations as of April 30, 2017 (in thousands):

[0000936395-17-000038:mdna:273]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 752,385 |  |  | $ | 185,258 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on Term Loan due January 30, 2022 (2) | 399,000 |  |  | 4,000 |  |  | 8,000 |  |  | 8,000 |  |  | 379,000 |  |
| Interest due on convertible notes | 50,498 |  |  | 21,436 |  |  | 21,562 |  |  | 7,500 |  |  | — |  |
| Interest due on Term Loan due January 30, 2022 (2) | 66,082 |  |  | 14,081 |  |  | 27,778 |  |  | 24,223 |  |  | — |  |
| Payments due under interest rate swaps (2) | 10,643 |  |  | 2,984 |  |  | 5,032 |  |  | 2,627 |  |  | — |  |
| Operating leases (3) | 143,135 |  |  | 16,843 |  |  | 47,780 |  |  | 33,527 |  |  | 44,985 |  |
| Purchase obligations (4) | 280,645 |  |  | 280,645 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 4,015 |  |  | 1,759 |  |  | 2,256 |  |  | — |  |  | — |  |
| Capital leases— buildings (5) | 118,679 |  |  | 7,041 |  |  | 14,143 |  |  | 14,507 |  |  | 82,988 |  |
| Other obligations | 2,340 |  |  | 1,015 |  |  | 1,325 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,827,422 |  |  | $ | 535,062 |  |  | $ | 477,876 |  |  | $ | 307,511 |  |  | $ | 506,973 |  |

[0000936395-17-000038:mdna:274]
_____________________________________

[0000936395-17-000038:mdna:275]
[same as prior period, unchanged from 0000936395-17-000020:mdna:202]

[0000936395-17-000038:mdna:276]
| (2) | Interest on the 2022 Term Loan and payments due under the interest rate swaps is variable and calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 14 and 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000038:mdna:277]
[same as prior period, unchanged from 0000936395-17-000020:mdna:204]

[0000936395-17-000038:mdna:278]
[same as prior period, unchanged from 0000936395-17-000020:mdna:205]

[0000936395-17-000038:mdna:279]
[same as prior period, unchanged from 0000936395-17-000020:mdna:206]

[0000936395-17-000038:mdna:280]
| (6) | As of April 30, 2017, we also had approximately $14.0 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-17-000038:mdna:281]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of April 30, 2017 (in thousands):

[0000936395-17-000038:mdna:282]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 77,681 |  |  | $ | 36,511 |  |  | $ | 18,455 |  |  | $ | 12,542 |  |  | $ | 10,173 |  |

[0000936395-17-000038:mdna:283]
[same as prior period, unchanged from 0000936395-17-000020:mdna:210]

[0000936395-17-000038:mdna:284]
[same as prior period, unchanged from 0000936395-17-000020:mdna:211]

[0000936395-17-000038:mdna:285]
[same as prior period, unchanged from 0000936395-17-000020:mdna:212]

[0000936395-17-000038:mdna:286]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-17-000038:mdna:287]
[same as prior period, unchanged from 0000936395-17-000020:mdna:214]

[0000936395-17-000038:mdna:288]
[same as prior period, unchanged from 0000936395-17-000020:mdna:215]

[0000936395-17-000038:mdna:289]
[same as prior period, unchanged from 0000936395-17-000020:mdna:216]

[0000936395-17-000038:mdna:290]
[same as prior period, unchanged from 0000936395-17-000020:mdna:217]

[0000936395-17-000038:mdna:291]
[same as prior period, unchanged from 0000936395-17-000020:mdna:218]

[0000936395-17-000038:mdna:292]
[same as prior period, unchanged from 0000936395-17-000020:mdna:219]

[0000936395-17-000038:mdna:293]
[same as prior period, unchanged from 0000936395-17-000020:mdna:220]

[0000936395-17-000038:mdna:294]
Our total deferred revenue for products was $49.9 million and $45.2 million as of April 30, 2017 and October 31, 2016, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $137.0 million and $137.7 million as of April 30, 2017 and October 31, 2016, respectively.

[0000936395-17-000038:mdna:295]
[same as prior period, unchanged from 0000936395-17-000020:mdna:222]

[0000936395-17-000038:mdna:296]
[same as prior period, unchanged from 0000936395-17-000020:mdna:223]

[0000936395-17-000038:mdna:297]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 19 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of April 30, 2017, total unrecognized compensation expense was $84.6 million: (i) $0.3 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.2 years; and (ii) $84.3 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-17-000038:mdna:298]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

[0000936395-17-000038:mdna:299]
[same as prior period, unchanged from 0000936395-17-000020:mdna:227]

[0000936395-17-000038:mdna:300]
[same as prior period, unchanged from 0000936395-17-000020:mdna:228]

[0000936395-17-000038:mdna:301]
For fiscal 2017, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon

[0000936395-17-000038:mdna:302]
the achievement of certain financial and operational goals for fiscal 2017. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for cash incentive compensation in any interim period in fiscal 2017 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $29.5 million of expense in the first six months of fiscal 2017 associated with our cash incentive bonus plan for fiscal 2017.

[0000936395-17-000038:mdna:303]
[same as prior period, unchanged from 0000936395-17-000020:mdna:230]

[0000936395-17-000038:mdna:304]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $19.6 million and $20.1 million in the first six months of fiscal 2017 and 2016, respectively. The charges in fiscal 2017 primarily were related to a decrease in the forecasted demand for certain Networking Platform products. Our inventory net of allowance for excess and obsolescence was $287.1 million and $211.3 million as of April 30, 2017 and October 31, 2016, respectively.

[0000936395-17-000038:mdna:305]
[same as prior period, unchanged from 0000936395-17-000020:mdna:232]

[0000936395-17-000038:mdna:306]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $564.9 million and $576.2 million as of April 30, 2017 and October 31, 2016, respectively. Our allowance for doubtful accounts was $4.5 million and  $4.0 million as of April 30, 2017 and October 31, 2016, respectively.

[0000936395-17-000038:mdna:307]
[same as prior period, unchanged from 0000936395-17-000020:mdna:234]

[0000936395-17-000038:mdna:308]
[same as prior period, unchanged from 0000936395-17-000020:mdna:235]

[0000936395-17-000038:mdna:309]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, which we adopted in the first quarter in fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of April 30, 2017 and October 31, 2016, the goodwill balance was $266.8 million and $267.0 million, respectively.

[0000936395-17-000038:mdna:310]
[same as prior period, unchanged from 0000936395-17-000020:mdna:237]

[0000936395-17-000038:mdna:311]
Our long-lived assets include: equipment, building, furniture and fixtures; finite-lived intangible assets; in-process research and development; and maintenance spares. As of April 30, 2017 and October 31, 2016, these assets totaled $461.5 million and $484.7 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-17-000038:mdna:312]
[same as prior period, unchanged from 0000936395-17-000020:mdna:239]

[0000936395-17-000038:mdna:313]
We provide a valuation allowance for our deferred tax assets in excess of deferred tax liabilities because we have concluded that it is more likely than not that such deferred tax assets will ultimately not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. We assess available positive and negative evidence regarding our ability to realize our deferred tax assets and record a valuation allowance when it is more likely than not that deferred tax assets will not be realized. To form a conclusion, management considers our recent financial results and trends and makes judgments and estimates related to projections of profitability, the timing and extent of the use of net operating loss carryforwards, and tax planning strategies. At April 30, 2017, we were not in a three-year cumulative loss position. However, management determined that a valuation allowance is still necessary, due to, among other things, the relatively low level of cumulative pre-tax income during this period — cumulative 12-quarter profit was only recently achieved in the second half of fiscal 2016  — and our lengthy history of operating losses. We will continue to evaluate future financial performance to determine whether such profitability is both sustainable and significant enough to provide sufficient evidence to support reversal of all or a portion of the valuation allowance. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements. The valuation allowance balance at April 30, 2017 was $1.5 billion.

[0000936395-17-000038:mdna:314]
[same as prior period, unchanged from 0000936395-17-000020:mdna:241]

[0000936395-17-000038:mdna:315]
Our liability for product warranties, included in other accrued liabilities, was $46.0 million and $52.3 million as of April 30, 2017 and October 31, 2016, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $2.3 million and $9.6 million for the first six months of fiscal 2017 and 2016, respectively. See Note 13 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
