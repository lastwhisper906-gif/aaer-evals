# CIEN notes — 0000936395-17-000038


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-17-000038:notes:1]
ABL CREDIT FACILITY

[0000936395-17-000038:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-17-000038:notes:3]
As of April 30, 2017, letters of credit totaling $72.4 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2017.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-17-000038:notes:4]
[same as prior period, unchanged from 0000936395-17-000020:notes:4]

[0000936395-17-000038:notes:5]
[same as prior period, unchanged from 0000936395-17-000020:notes:5]

[0000936395-17-000038:notes:6]
[same as prior period, unchanged from 0000936395-17-000020:notes:6]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-17-000038:notes:7]
[same as prior period, unchanged from 0000936395-17-000020:notes:7]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-17-000038:notes:8]
[same as prior period, unchanged from 0000936395-17-000020:notes:8]

[0000936395-17-000038:notes:9]
[same as prior period, unchanged from 0000936395-17-000020:notes:9]

[0000936395-17-000038:notes:10]
|  | April 30, 2017 |  | October 31, 2016 |
| Prepaid VAT and other taxes | $ | 86,572 |  |  | $ | 77,474 |  |
| Product demonstration equipment, net | 48,897 |  |  | 42,259 |  |
| Deferred deployment expense | 23,482 |  |  | 19,138 |  |
| Prepaid expenses | 23,996 |  |  | 25,659 |  |
| Other non-trade receivables | 3,145 |  |  | 4,398 |  |
| Financing receivable | — |  |  | 3,740 |  |
| Derivative assets | 827 |  |  | 175 |  |
|  | $ | 186,919 |  |  | $ | 172,843 |  |

[0000936395-17-000038:notes:11]
Depreciation of product demonstration equipment was $4.9 million and $5.2 million for the first six months of fiscal 2017 and 2016, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-17-000038:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-17-000038:notes:13]
Outstanding Term Loan Payable

[0000936395-17-000038:notes:14]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000038:notes:15]
|  |  | April 30, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,377 |  |  | — |  |
|  |  | $ | 393,377 |  |  | $ | 486,303 |  |

[0000936395-17-000038:notes:16]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.5 million at April 30, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.5 million and $0.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.

[0000936395-17-000038:notes:17]
2022 Term Loan

[0000936395-17-000038:notes:18]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed and the aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.

[0000936395-17-000038:notes:19]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2022 Term Loan will, among other things:

[0000936395-17-000038:notes:20]
| • | be subject to mandatory prepayment on the same basis as under the Term Loan Credit Agreement; |

[0000936395-17-000038:notes:21]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

[0000936395-17-000038:notes:22]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

[0000936395-17-000038:notes:23]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-17-000038:notes:24]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability components of our 2022 Term Loan were as follows as of April 30, 2017 (in thousands):

[0000936395-17-000038:notes:25]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,153 | ) |  | $ | (3,470 | ) |  | $393,377 |

[0000936395-17-000038:notes:26]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loan (in thousands):

[0000936395-17-000038:notes:27]
|  |  | April 30, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022(1) |  | $ | 393,377 |  |  | $ | 401,494 |  |

[0000936395-17-000038:notes:28]
| (1) | Includes unamortized debt discount and debt issuance costs. |

[0000936395-17-000038:notes:29]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-17-000038:notes:30]
Prior Term Loans

[0000936395-17-000038:notes:31]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000038:notes:32]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000038:notes:33]
Outstanding Convertible Notes Payable

[0000936395-17-000038:notes:34]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000038:notes:35]
|  |  | April 30, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 188,509 |  |
|  |  | $ | 725,026 |  |  | $ | 767,379 |  |

[0000936395-17-000038:notes:36]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.9 million at April 30, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.0 million and $1.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.

[0000936395-17-000038:notes:37]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our Ciena's outstanding issues of convertible notes were as follows as of April 30, 2017 (in thousands):

[0000936395-17-000038:notes:38]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 0.875% Convertible Senior Notes due June 15, 2017 | $ | 185,258 |  |  | $ | — |  |  | $ | (37 | ) |  | $185,221 |  | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,752 | ) |  | $348,248 |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,093 |  |  | $ | (10,428 | ) |  | $ | (1,108 | ) |  | $191,557 |  | $ | 43,131 |  |

[0000936395-17-000038:notes:39]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2017:

[0000936395-17-000038:notes:40]
|  |  | April 30, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 185,085 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 449,313 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 254,925 |  |
|  |  | $ | 725,026 |  |  | $ | 889,323 |  |

[0000936395-17-000038:notes:41]
| (1) | Includes unamortized debt discount, accretion of principal and debt issuance costs. |

[0000936395-17-000038:notes:42]
| (2) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-17-000038:notes:43]
[same as prior period, unchanged from 0000936395-17-000020:notes:34]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-17-000038:notes:44]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in either other current assets or other long-term assets depending upon the duration of the restriction.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-17-000038:notes:45]
COMMITMENTS AND CONTINGENCIES

[0000936395-17-000038:notes:46]
Foreign Tax Contingencies

[0000936395-17-000038:notes:47]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-17-000038:notes:48]
Litigation

[0000936395-17-000038:notes:49]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.

[0000936395-17-000038:notes:50]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. On November 18, 2016, the parties each filed motions for summary judgment. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-17-000038:notes:51]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the ‘673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-17-000038:notes:52]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-17-000038:notes:53]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-17-000038:notes:54]
[same as prior period, unchanged from 0000936395-17-000020:notes:45]

[0000936395-17-000038:notes:55]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the six months ended April 30, 2017:

[0000936395-17-000038:notes:56]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (527 | ) |  | 4,897 |  |  | (815 | ) |  | (1,753 | ) |  | 1,802 |  |
| Amounts reclassified from AOCI | — |  |  | — |  |  | 1,341 |  |  | — |  |  | 1,341 |  |
| Balance at April 30, 2017 | $ | (388 | ) |  | $ | 3,806 |  |  | $ | (5,441 | ) |  | $ | (19,163 | ) |  | $ | (21,186 | ) |

[0000936395-17-000038:notes:57]
The following table summarizes the changes in AOCI for the six months ended April 30, 2016:

[0000936395-17-000038:notes:58]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 256 |  |  | 760 |  |  | (1,478 | ) |  | 4,693 |  |  | 4,231 |  |
| Amounts reclassified from AOCI | — |  |  | 704 |  |  | 1,572 |  |  | — |  |  | 2,276 |  |
| Balance at April 30, 2016 | $ | 178 |  |  | $ | 1,196 |  |  | $ | (5,428 | ) |  | $ | (11,565 | ) |  | $ | (15,619 | ) |

[0000936395-17-000038:notes:59]
[same as prior period, unchanged from 0000936395-17-000020:notes:50]


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-17-000038:notes:60]
[same as prior period, unchanged from 0000936395-17-000020:notes:51]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-17-000038:notes:61]
[same as prior period, unchanged from 0000936395-17-000020:notes:52]

[0000936395-17-000038:notes:62]
|  | April 30, 2017 |  | October 31, 2016 |
| Products | $ | 49,909 |  |  | $ | 45,216 |  |
| Services | 136,954 |  |  | 137,647 |  |
|  | 186,863 |  |  | 182,863 |  |
| Less current portion | (105,514 | ) |  | (109,009 | ) |
| Long-term deferred revenue | $ | 81,349 |  |  | $ | 73,854 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-17-000038:notes:63]
[same as prior period, unchanged from 0000936395-17-000020:notes:54]

[0000936395-17-000038:notes:64]
[same as prior period, unchanged from 0000936395-17-000020:notes:55]

[0000936395-17-000038:notes:65]
As of April 30, 2017 and October 31, 2016, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $55.7 million and $107.6 million as of April 30, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-17-000038:notes:66]
During the first six months of fiscal 2017 and fiscal 2016, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $62.0 million and $59.6 million as of April 30, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-17-000038:notes:67]
[same as prior period, unchanged from 0000936395-17-000020:notes:58]

[0000936395-17-000038:notes:68]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). During the second quarter of fiscal 2017, Ciena refinanced its existing 2019 and 2021 Term Loans into a new 2022 Term Loan, thereby reducing the aggregate outstanding principal to $400 million and extending the maturity to January 2022 (see Note 16 below). In order to align its interest rate hedges to the reduced 2022 Term Loan principal value and later maturity date, Ciena also reduced the total outstanding value of its interest rate swaps, as described below, and entered into new forward starting interest rate swaps in January 2017 and February 2017, respectively. The interest rate swaps, as adjusted, fix 98%, 82% and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020, and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25%, 4.25% and 4.51%, respectively. The total notional amount of these interest rate swaps in effect as of April 30, 2017 was $391.6 million.

[0000936395-17-000038:notes:69]
During fiscal 2014, Ciena entered into interest rate swaps that fixed the interest rate under the 2019 Term Loan (as defined in Note 16) at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of October 31, 2016 was $244.4 million. In May 2016, Ciena entered into interest rate swaps that fixed the total interest rate under the 2021 Term Loan (as defined in Note 16) at 4.62% to 4.87%, depending on the applicable margin, for the period commencing on June 20, 2016 through June 22, 2020. The total notional amount of these derivatives as of October 31, 2016 was $248.8 million.

[0000936395-17-000038:notes:70]
[same as prior period, unchanged from 0000936395-17-000020:notes:61]

[0000936395-17-000038:notes:71]
[same as prior period, unchanged from 0000936395-17-000020:notes:62]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-17-000038:notes:72]
[same as prior period, unchanged from 0000936395-17-000020:notes:63]

[0000936395-17-000038:notes:73]
[same as prior period, unchanged from 0000936395-17-000020:notes:65]

[0000936395-17-000038:notes:74]
[same as prior period, unchanged from 0000936395-17-000020:notes:64]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-17-000038:notes:75]
[same as prior period, unchanged from 0000936395-17-000020:notes:66]

[0000936395-17-000038:notes:76]
Ciena has outstanding equity awards issued under its 2008 Omnibus Incentive Plan (the "2008 Plan"), certain legacy equity plans, equity plans assumed as a result of previous acquisitions, and its 2017 Omnibus Incentive Plan (the "2017 Plan"), which was approved by Ciena's stockholders on March 23, 2017. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under its Amended and Restated 2003 Employee Stock Purchase Plan (the "ESPP"). Each of the 2017 Plan and the ESPP are described below.

[0000936395-17-000038:notes:77]
2017 Plan

[0000936395-17-000038:notes:78]
The 2017 Plan has a ten year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-17-000038:notes:79]
The 2017 Plan authorizes and reserves 8.9 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena's prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of April 30, 2017, approximately 10.5 million shares remained available for issuance under the 2017 Plan.

[0000936395-17-000038:notes:80]
[same as prior period, unchanged from 0000936395-17-000020:notes:70]

[0000936395-17-000038:notes:81]
Ciena did not grant any stock options during the first six months of fiscal 2017 or fiscal 2016. Outstanding stock option awards granted to employees in prior periods or assumed as a result of acquisitions are generally subject to service-based vesting conditions and vest incrementally over a four-year period. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-17-000038:notes:82]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2016 | 1,387 |  |  | $ | 26.90 |  |
| Exercised | (167 | ) |  | — |  |
| Canceled | (225 | ) |  | — |  |
| Balance at April 30, 2017 | 995 |  |  | $ | 29.55 |  |

[0000936395-17-000038:notes:83]
The total intrinsic value of options exercised during the first six months of fiscal 2017 and fiscal 2016 was $2.4 million and $2.5 million, respectively.

[0000936395-17-000038:notes:84]
The following table summarizes information with respect to stock options outstanding at April 30, 2017, based on Ciena’s closing stock price on the last trading day of Ciena’s second fiscal quarter of 2017 (shares and intrinsic value in thousands):

[0000936395-17-000038:notes:85]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | April 30, 2017 |  | April 30, 2017 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 1.88 |  |  | — |  |  | $ | 10.18 |  |  | 83 |  |  | 2.67 |  | $ | 8.16 |  |  | $ | 1,229 |  |  | 82 |  |  | 2.61 |  | $ | 8.14 |  |  | $ | 1,216 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 207 |  |  | 4.91 |  | 13.42 |  |  | 1,964 |  |  | 198 |  |  | 4.80 |  | 13.34 |  |  | 1,893 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.46 |  |  | 145 |  |  | 1.97 |  | 25.66 |  |  | 167 |  |  | 135 |  |  | 1.55 |  | 26.20 |  |  | 121 |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 323 |  |  | 1.85 |  | 35.19 |  |  | — |  |  | 323 |  |  | 1.85 |  | 35.19 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 237 |  |  | 4.07 |  | 45.89 |  |  | — |  |  | 231 |  |  | 4.02 |  | 45.91 |  |  | — |  |
| $ | 1.88 |  |  | — |  |  | $ | 55.63 |  |  | 995 |  |  | 3.10 |  | $ | 29.55 |  |  | $ | 3,360 |  |  | 969 |  |  | 2.99 |  | $ | 29.73 |  |  | $ | 3,230 |  |

[0000936395-17-000038:notes:86]
[same as prior period, unchanged from 0000936395-17-000020:notes:76]

[0000936395-17-000038:notes:87]
[same as prior period, unchanged from 0000936395-17-000020:notes:77]

[0000936395-17-000038:notes:88]
[same as prior period, unchanged from 0000936395-17-000020:notes:78]

[0000936395-17-000038:notes:89]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-17-000038:notes:90]
[same as prior period, unchanged from 0000936395-17-000020:notes:80]

[0000936395-17-000038:notes:91]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2016 | 4,280 |  |  | $ | 19.96 |  |  | $ | 83,511 |  |
| Granted | 2,092 |  |  |  |  |  |
| Vested | (1,306 | ) |  |  |  |  |
| Canceled or forfeited | (433 | ) |  |  |  |  |
| Balance at April 30, 2017 | 4,633 |  |  | $ | 21.22 |  |  | $ | 106,143 |  |

[0000936395-17-000038:notes:92]
The total fair value of restricted stock units that vested and were converted into common stock during the first six months of fiscal 2017 and fiscal 2016 was $31.9 million and $33.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first six months of fiscal 2017 and fiscal 2016 was $23.22 and $19.73 respectively.

[0000936395-17-000038:notes:93]
[same as prior period, unchanged from 0000936395-17-000020:notes:83]

[0000936395-17-000038:notes:94]
[same as prior period, unchanged from 0000936395-17-000020:notes:84]

[0000936395-17-000038:notes:95]
Share-based expense for performance-based restricted stock unit awards, net of estimated forfeitures, is recognized ratably over the performance period based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal, and to the extent previously recognized, compensation expense is reversed.

[0000936395-17-000038:notes:96]
[same as prior period, unchanged from 0000936395-17-000020:notes:86]

[0000936395-17-000038:notes:97]
[same as prior period, unchanged from 0000936395-17-000020:notes:87]

[0000936395-17-000038:notes:98]
[same as prior period, unchanged from 0000936395-17-000020:notes:88]

[0000936395-17-000038:notes:99]
During the first six months of fiscal 2017, Ciena issued 0.5 million shares under the ESPP. At April 30, 2017, 5.9 million shares remained available for issuance under the ESPP.

[0000936395-17-000038:notes:100]
[same as prior period, unchanged from 0000936395-17-000020:notes:90]

[0000936395-17-000038:notes:101]
[same as prior period, unchanged from 0000936395-17-000020:notes:91]

[0000936395-17-000038:notes:102]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Product costs | $ | 708 |  |  | $ | 629 |  |  | $ | 1,269 |  |  | $ | 1,200 |  |
| Service costs | 679 |  |  | 693 |  |  | 1,307 |  |  | 1,285 |  |
| Share-based compensation expense included in cost of sales | 1,387 |  |  | 1,322 |  |  | 2,576 |  |  | 2,485 |  |
| Research and development | 3,653 |  |  | 3,791 |  |  | 6,862 |  |  | 7,219 |  |
| Sales and marketing | 3,513 |  |  | 3,923 |  |  | 6,386 |  |  | 8,658 |  |
| General and administrative | 3,417 |  |  | 4,968 |  |  | 8,870 |  |  | 10,097 |  |
| Acquisition and integration costs | — |  |  | 697 |  |  | — |  |  | 714 |  |
| Share-based compensation expense included in operating expense | 10,583 |  |  | 13,379 |  |  | 22,118 |  |  | 26,688 |  |
| Share-based compensation expense capitalized in inventory, net | 35 |  |  | 32 |  |  | 136 |  |  | 37 |  |
| Total share-based compensation | $ | 12,005 |  |  | $ | 14,733 |  |  | $ | 24,830 |  |  | $ | 29,210 |  |

[0000936395-17-000038:notes:103]
As of April 30, 2017, total unrecognized share-based compensation expense was approximately $84.6 million: (i) $0.3 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.2 years; and (ii) $84.3 million,which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-17-000038:notes:104]
[same as prior period, unchanged from 0000936395-17-000020:notes:94]


## us-gaap:EarningsPerShareTextBlock

[0000936395-17-000038:notes:105]
EARNINGS PER SHARE CALCULATION

[0000936395-17-000038:notes:106]
[same as prior period, unchanged from 0000936395-17-000020:notes:96]

[0000936395-17-000038:notes:107]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Net income | $ | 38,026 |  |  | $ | 13,997 |  |  | $ | 41,887 |  |  | $ | 2,451 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | 495 |  |  | — |  |  | 1,097 |  |  | — |  |
| Add: Interest expense associated with 3.75% convertible senior notes due 2018 | 3,588 |  |  | — |  |  | — |  |  | — |  |
| Net income used to calculate Diluted EPS | $ | 42,109 |  |  | $ | 13,997 |  |  | $ | 42,984 |  |  | $ | 2,451 |  |

[0000936395-17-000038:notes:108]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Basic weighted average shares outstanding | 141,743 |  |  | 137,950 |  |  | 141,223 |  |  | 137,313 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 1,317 |  |  | 939 |  |  | 1,409 |  |  | 1,380 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | 4,857 |  |  | — |  |  | 5,210 |  |  | — |  |
| Add: Shares underlying 3.75% convertible senior notes due 2018 | 17,356 |  |  | — |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 165,273 |  |  | 138,889 |  |  | 147,842 |  |  | 138,693 |  |

[0000936395-17-000038:notes:109]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Basic EPS | $ | 0.27 |  |  | $ | 0.10 |  |  | $ | 0.30 |  |  | $ | 0.02 |  |
| Diluted EPS | $ | 0.25 |  |  | $ | 0.10 |  |  | $ | 0.29 |  |  | $ | 0.02 |  |

[0000936395-17-000038:notes:110]
[same as prior period, unchanged from 0000936395-17-000020:notes:100]

[0000936395-17-000038:notes:111]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Shares underlying stock options and restricted stock units | 725 |  |  | 2,439 |  |  | 1,141 |  |  | 2,092 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | 12,583 |  |  | — |  |  | 12,748 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | — |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 9,923 |  |  | 41,576 |  |  | 27,695 |  |  | 41,394 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-17-000038:notes:112]
[same as prior period, unchanged from 0000936395-17-000020:notes:102]

[0000936395-17-000038:notes:113]
|  | April 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 474,476 |  |  | $ | — |  |  | $ | — |  |  | $ | 474,476 |  |
| U.S. government obligations | — |  |  | 344,661 |  |  | — |  |  | 344,661 |  |
| Commercial paper | — |  |  | 79,917 |  |  | — |  |  | 79,917 |  |
| Foreign currency forward contracts | — |  |  | 827 |  |  | — |  |  | 827 |  |
| Total assets measured at fair value | $ | 474,476 |  |  | $ | 425,405 |  |  | $ | — |  |  | $ | 899,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,811 |  |  | $ | — |  |  | $ | 1,811 |  |
| Forward starting interest rate swap | — |  |  | 1,070 |  |  | — |  |  | 1,070 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | 2,881 |  |

[0000936395-17-000038:notes:114]
[same as prior period, unchanged from 0000936395-17-000020:notes:104]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-17-000038:notes:115]
[same as prior period, unchanged from 0000936395-17-000020:notes:105]

[0000936395-17-000038:notes:116]
|  | April 30, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 474,476 |  |  | $ | 59,947 |  |  | $ | — |  |  | $ | 534,423 |  |
| Short-term investments | — |  |  | 274,779 |  |  | — |  |  | 274,779 |  |
| Prepaid expenses and other | — |  |  | 827 |  |  | — |  |  | 827 |  |
| Long-term investments | — |  |  | 89,852 |  |  | — |  |  | 89,852 |  |
| Total assets measured at fair value | $ | 474,476 |  |  | $ | 425,405 |  |  | $ | — |  |  | $ | 899,881 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,811 |  |  | $ | — |  |  | $ | 1,811 |  |
| Other long-term obligations | — |  |  | 1,070 |  |  | — |  |  | 1,070 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,881 |  |  | $ | — |  |  | $ | 2,881 |  |

[0000936395-17-000038:notes:117]
[same as prior period, unchanged from 0000936395-17-000020:notes:107]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-17-000038:notes:118]
[same as prior period, unchanged from 0000936395-17-000020:notes:108]

[0000936395-17-000038:notes:119]
[same as prior period, unchanged from 0000936395-17-000020:notes:109]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-17-000038:notes:120]
[same as prior period, unchanged from 0000936395-17-000020:notes:110]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-17-000038:notes:121]
[same as prior period, unchanged from 0000936395-17-000020:notes:111]

[0000936395-17-000038:notes:122]
[same as prior period, unchanged from 0000936395-17-000020:notes:112]

[0000936395-17-000038:notes:123]
|  |  | Balance at October 31, 2016 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at April 30, 2017 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 65,546 |  |  | — |  |  | — |  |  | (201 | ) |  | 65,345 |  |
| Total |  | $ | 266,974 |  |  | $ | — |  |  | $ | — |  |  | $ | (201 | ) |  | $ | 266,773 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-17-000038:notes:124]
[same as prior period, unchanged from 0000936395-17-000020:notes:114]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-17-000038:notes:125]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-17-000038:notes:126]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-17-000038:notes:127]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.

[0000936395-17-000038:notes:128]
[same as prior period, unchanged from 0000936395-17-000020:notes:118]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-17-000038:notes:129]
[same as prior period, unchanged from 0000936395-17-000020:notes:119]

[0000936395-17-000038:notes:130]
[same as prior period, unchanged from 0000936395-17-000020:notes:120]

[0000936395-17-000038:notes:131]
|  | April 30, 2017 |  | October 31, 2016 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 347,727 |  |  | $ | (267,663 | ) |  | $ | 80,064 |  |  | $ | 347,727 |  |  | $ | (248,128 | ) |  | $ | 99,599 |  |
| In-process research and development | 4,200 |  |  | — |  |  | 4,200 |  |  | 4,200 |  |  | — |  |  | 4,200 |  |
| Patents and licenses | 7,165 |  |  | (6,410 | ) |  | 755 |  |  | 7,165 |  |  | (6,285 | ) |  | 880 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 358,648 |  |  | (330,422 | ) |  | 28,226 |  |  | 358,647 |  |  | (316,615 | ) |  | 42,032 |  |
| Total other intangible assets | $ | 717,740 |  |  | $ | (604,495 | ) |  | $ | 113,245 |  |  | $ | 717,739 |  |  | $ | (571,028 | ) |  | $ | 146,711 |  |

[0000936395-17-000038:notes:132]
The aggregate amortization expense of intangible assets was $33.5 million and $40.5 million for the first six months of fiscal 2017 and 2016, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-17-000038:notes:133]
| Period ended October 31, |  |  |
| 2017 (remaining six months) | $ | 11,895 |  |  |
| 2018 | 22,680 |  |  |
| 2019 | 22,133 |  |  |
| 2020 | 21,106 |  |  |
| 2021 | 18,172 |  |  |
| Thereafter | 13,059 |  |  |
|  | $ | 109,045 |  | (1) |

[0000936395-17-000038:notes:134]
[same as prior period, unchanged from 0000936395-17-000020:notes:124]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-17-000038:notes:135]
[same as prior period, unchanged from 0000936395-17-000020:notes:125]

[0000936395-17-000038:notes:136]
[same as prior period, unchanged from 0000936395-17-000020:notes:126]

[0000936395-17-000038:notes:137]
|  | April 30, 2017 |  | October 31, 2016 |
| Raw materials | $ | 43,905 |  |  | $ | 44,644 |  |
| Work-in-process | 12,859 |  |  | 12,852 |  |
| Finished goods | 204,376 |  |  | 156,402 |  |
| Deferred cost of goods sold | 85,164 |  |  | 59,856 |  |
|  | 346,304 |  |  | 273,754 |  |
| Provision for excess and obsolescence | (59,231 | ) |  | (62,503 | ) |
|  | $ | 287,073 |  |  | $ | 211,251 |  |

[0000936395-17-000038:notes:138]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2017, Ciena recorded a provision for excess and obsolescence of $19.6 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-17-000038:notes:139]
[same as prior period, unchanged from 0000936395-17-000020:notes:129]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-17-000038:notes:140]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that a decline in the fair value of any investment below its cost basis is other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-17-000038:notes:141]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-17-000038:notes:142]
The following table summarizes the final legal maturities of debt investments at April 30, 2017 (in thousands):

[0000936395-17-000038:notes:143]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 275,012 |  |  | $ | 274,779 |  |
| Due in 1-2 years | 89,987 |  |  | 89,852 |  |
|  | $ | 364,999 |  |  | $ | 364,631 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-17-000038:notes:144]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-17-000038:notes:145]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-17-000038:notes:146]
|  | April 30, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 255,042 |  |  | $ | — |  |  | (233 | ) |  | $ | 254,809 |  |
| Included in long-term investments | 89,987 |  |  | — |  |  | (135 | ) |  | 89,852 |  |
|  | $ | 345,029 |  |  | $ | — |  |  | $ | (368 | ) |  | $ | 344,661 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,970 |  |  | — |  |  | — |  |  | $ | 19,970 |  |
|  | $ | 19,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,970 |  |

[0000936395-17-000038:notes:147]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | — |  |  | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-17-000038:notes:148]
Ciena expenses legal costs associated with litigation as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-17-000038:notes:149]
[same as prior period, unchanged from 0000936395-17-000020:notes:139]

[0000936395-17-000038:notes:150]
As of April 30, 2017, no single customer accounted for greater than 10.0% of Ciena's net accounts receivable. As of October 31, 2016, one customer accounted for 10.4% of Ciena's net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The allowance for doubtful accounts was $4.5 million and $4.0 million as of April 30, 2017 and October 31, 2016, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-17-000038:notes:151]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $6.4 million at April 30, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.

[0000936395-17-000038:notes:152]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

[0000936395-17-000038:notes:153]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-17-000038:notes:154]
In May 2014, FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require Ciena to determine the stand alone selling price for each of the elements at the contract inception and consequently Ciena expects certain software deliverables will be recognized at a point in time rather than over a period of time. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures, as well as the transition method.

[0000936395-17-000038:notes:155]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000038:notes:156]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard.

[0000936395-17-000038:notes:157]
In January 2017, the FASB issued ASU No. 2017-1, Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-17-000038:notes:158]
[same as prior period, unchanged from 0000936395-17-000020:notes:147]

[0000936395-17-000038:notes:159]
[same as prior period, unchanged from 0000936395-17-000020:notes:148]

[0000936395-17-000038:notes:160]
[same as prior period, unchanged from 0000936395-17-000020:notes:149]


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-17-000038:notes:161]
[same as prior period, unchanged from 0000936395-17-000020:notes:150]

[0000936395-17-000038:notes:162]
|  | April 30, 2017 |  | October 31, 2016 |
| Construction liability | $ | 33,157 |  |  | $ | 57,602 |  |
| Capital lease obligations | 42,197 |  |  | 24,298 |  |
| Income tax liability | 14,001 |  |  | 14,122 |  |
| Deferred tenant allowance | 8,663 |  |  | 9,164 |  |
| Straight-line rent | 7,277 |  |  | 6,406 |  |
| Forward starting interest rate swap | 1,070 |  |  | 5,967 |  |
| Other | 6,889 |  |  | 6,835 |  |
|  | $ | 113,254 |  |  | $ | 124,394 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-17-000038:notes:163]
[same as prior period, unchanged from 0000936395-17-000020:notes:152]

[0000936395-17-000038:notes:164]
[same as prior period, unchanged from 0000936395-17-000020:notes:153]

[0000936395-17-000038:notes:165]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Interest income | $ | 1,507 |  |  | $ | 982 |  |  | $ | 2,789 |  |  | $ | 1,668 |  |
| Losses on non-hedge designated foreign currency forward contracts | (2,749 | ) |  | (10,600 | ) |  | (1,725 | ) |  | (15,213 | ) |
| Foreign currency exchange gain (loss) | 1,292 |  |  | 10,506 |  |  | (1,125 | ) |  | 6,130 |  |
| Modification of term loan | (2,924 | ) |  | — |  |  | (2,924 | ) |  | — |  |
| Other | (44 | ) |  | 79 |  |  | 437 |  |  | (394 | ) |
| Interest and other income (loss), net | $ | (2,918 | ) |  | $ | 967 |  |  | $ | (2,548 | ) |  | $ | (7,809 | ) |

[0000936395-17-000038:notes:166]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first six months of fiscal 2017  Ciena recorded $1.1 million in foreign currency exchange rate losses, and during the first six months of fiscal 2016, Ciena recorded $6.1 million in foreign currency exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first six months of fiscal 2017 and fiscal 2016, Ciena recorded losses of $1.7 million and $15.2 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-17-000038:notes:167]
[same as prior period, unchanged from 0000936395-17-000020:notes:156]

[0000936395-17-000038:notes:168]
[same as prior period, unchanged from 0000936395-17-000020:notes:157]

[0000936395-17-000038:notes:169]
|  | April 30, 2017 |  | October 31, 2016 |
| Equipment, furniture and fixtures | $ | 468,630 |  |  | $ | 451,029 |  |
| Building subject to capital lease | 42,347 |  |  | 22,529 |  |
| Construction in progress subject to build-to-suit lease | 33,157 |  |  | 57,602 |  |
| Leasehold improvements | 78,136 |  |  | 60,011 |  |
|  | 622,270 |  |  | 591,171 |  |
| Accumulated depreciation and amortization | (322,478 | ) |  | (302,765 | ) |
|  | $ | 299,792 |  |  | $ | 288,406 |  |

[0000936395-17-000038:notes:170]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease, two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of the first day of Ciena's second quarter of fiscal 2017, occupancy of one of the office buildings was complete, and, as such, Ciena recorded a capital lease of $20.7 million for this building which will be depreciated over the lease term. This occupancy also reduced the build-to-suit construction in progress asset and the corresponding long-term liability. As of April 30, 2017, total costs remaining under this build-to-suit arrangement were $33.2 million. The remaining build-to-suit arrangement is expected to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful lives or the lease term.

[0000936395-17-000038:notes:171]
The total of the depreciation of equipment, furniture and fixtures and the amortization of leasehold improvements was $30.6 million and $24.8 million for the first six months of fiscal 2017 and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-17-000038:notes:172]
[same as prior period, unchanged from 0000936395-17-000020:notes:161]

[0000936395-17-000038:notes:173]
[same as prior period, unchanged from 0000936395-17-000020:notes:162]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-17-000038:notes:174]
[same as prior period, unchanged from 0000936395-17-000020:notes:163]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-17-000038:notes:175]
[same as prior period, unchanged from 0000936395-17-000020:notes:164]

[0000936395-17-000038:notes:176]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 150,464 |  |  | $ | 132,606 |  |  | $ | 264,210 |  |  | $ | 239,588 |  |
| Software and Software-Related Services | 4,551 |  |  | 192 |  |  | 12,252 |  |  | (3,382 | ) |
| Global Services | 41,602 |  |  | 35,692 |  |  | 77,071 |  |  | 75,688 |  |
| Total segment profit | 196,617 |  |  | 168,490 |  |  | 353,533 |  |  | 311,894 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 88,551 |  |  | 86,668 |  |  | 173,553 |  |  | 169,146 |  |
| General and administrative | 34,990 |  |  | 35,203 |  |  | 70,854 |  |  | 66,345 |  |
| Amortization of intangible assets | 10,980 |  |  | 15,566 |  |  | 25,531 |  |  | 32,428 |  |
| Acquisition and integration costs | — |  |  | 2,285 |  |  | — |  |  | 3,584 |  |
| Restructuring costs | 4,276 |  |  | 535 |  |  | 6,671 |  |  | 919 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (16,226 | ) |  | (11,641 | ) |  | (31,059 | ) |  | (33,127 | ) |
| Less: Provision for income taxes | 3,568 |  |  | 2,595 |  |  | 3,978 |  |  | 3,894 |  |
| Consolidated net income | $ | 38,026 |  |  | $ | 13,997 |  |  | $ | 41,887 |  |  | $ | 2,451 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-17-000038:notes:177]
[same as prior period, unchanged from 0000936395-17-000020:notes:166]

[0000936395-17-000038:notes:178]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 502,131 |  |  | $ | 435,173 |  |  | $ | 914,783 |  |  | $ | 824,341 |  |
| Packet Networking | 66,326 |  |  | 68,582 |  |  | 138,520 |  |  | 116,779 |  |
| Optical Transport | 3,030 |  |  | 8,451 |  |  | 8,128 |  |  | 20,596 |  |
| Total Networking Platforms | 571,487 |  |  | 512,206 |  |  | 1,061,431 |  |  | 961,716 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 13,143 |  |  | 11,772 |  |  | 30,192 |  |  | 19,851 |  |
| Software-Related Services | 24,573 |  |  | 18,701 |  |  | 46,904 |  |  | 36,048 |  |
| Total Software and Software-Related Services | 37,716 |  |  | 30,473 |  |  | 77,096 |  |  | 55,899 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 58,241 |  |  | 57,069 |  |  | 113,231 |  |  | 113,127 |  |
| Installation and Deployment | 28,695 |  |  | 30,232 |  |  | 56,614 |  |  | 61,072 |  |
| Consulting and Network Design | 10,883 |  |  | 10,737 |  |  | 20,147 |  |  | 22,018 |  |
| Total Global Services | 97,819 |  |  | 98,038 |  |  | 189,992 |  |  | 196,217 |  |
| Consolidated revenue | $ | 707,022 |  |  | $ | 640,717 |  |  | $ | 1,328,519 |  |  | $ | 1,213,832 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-17-000038:notes:179]
[same as prior period, unchanged from 0000936395-17-000020:notes:168]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-17-000038:notes:180]
[same as prior period, unchanged from 0000936395-17-000020:notes:169]

[0000936395-17-000038:notes:181]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2017 (in thousands):

[0000936395-17-000038:notes:182]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 2,369 |  | (1) | 4,302 |  | (2) | 6,671 |  |
| Cash payments | (3,084 | ) |  | (1,133 | ) |  | (4,217 | ) |
| Balance at April 30, 2017 | $ | 153 |  |  | $ | 5,139 |  |  | $ | 5,292 |  |
| Current restructuring liabilities | $ | 153 |  |  | $ | 4,928 |  |  | $ | 5,081 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 211 |  |  | $ | 211 |  |

[0000936395-17-000038:notes:183]
| (1) | Reflects a global workforce reduction of approximately 50 employees during the first quarter of fiscal 2017 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes and systems. |

[0000936395-17-000038:notes:184]
| (2) | Reflects unfavorable lease commitments and relocation costs incurred during the second quarter of fiscal 2017 in connection with the facility transition from Ciena's existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |

[0000936395-17-000038:notes:185]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2016 (in thousands):

[0000936395-17-000038:notes:186]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 929 |  |  | — |  |  | 929 |  |
| Adjustment to previous estimates | — |  |  | (10 | ) |  | (10 | ) |
| Cash payments | (823 | ) |  | (203 | ) |  | (1,026 | ) |
| Balance at April 30, 2016 | $ | 697 |  |  | $ | 475 |  |  | $ | 1,172 |  |
| Current restructuring liabilities | $ | 697 |  |  | $ | 309 |  |  | $ | 1,006 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 166 |  |  | $ | 166 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-17-000038:notes:187]
[same as prior period, unchanged from 0000936395-17-000020:notes:174]

[0000936395-17-000038:notes:188]
[same as prior period, unchanged from 0000936395-17-000020:notes:175]

[0000936395-17-000038:notes:189]
[same as prior period, unchanged from 0000936395-17-000020:notes:176]

[0000936395-17-000038:notes:190]
[same as prior period, unchanged from 0000936395-17-000020:notes:177]

[0000936395-17-000038:notes:191]
[same as prior period, unchanged from 0000936395-17-000020:notes:178]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-17-000038:notes:192]
[same as prior period, unchanged from 0000936395-17-000020:notes:179]

[0000936395-17-000038:notes:193]
|  | April 30, 2017 |  | October 31, 2016 |
| Compensation, payroll related tax and benefits | $ | 71,567 |  |  | $ | 106,687 |  |
| Warranty | 46,025 |  |  | 52,324 |  |
| Vacation | 40,317 |  |  | 36,112 |  |
| Capital lease obligations | 2,716 |  |  | 2,321 |  |
| Interest payable | 4,312 |  |  | 4,649 |  |
| Other | 97,545 |  |  | 108,260 |  |
|  | $ | 262,482 |  |  | $ | 310,353 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-17-000038:notes:194]
The following is a schedule by fiscal year of future minimum lease payments under capital leases and the present value of minimum lease payments as of April 30, 2017 (in thousands):

[0000936395-17-000038:notes:195]
| Period ended October 31, |  |
| 2017 (remaining six months) | $ | 2,966 |  |
| 2018 | 5,796 |  |
| 2019 | 5,378 |  |
| 2020 | 4,399 |  |
| 2021 | 4,292 |  |
| Thereafter | 51,284 |  |
| Net minimum capital lease payments | 74,115 |  |
| Less: Amount representing interest | (29,202 | ) |
| Present value of minimum lease payments | 44,913 |  |
| Less: Current portion of present value of minimum lease payments | (2,716 | ) |
| Long-term portion of present value of minimum lease payments | $ | 42,197 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-17-000038:notes:196]
[same as prior period, unchanged from 0000936395-17-000020:notes:183]

[0000936395-17-000038:notes:197]
|  | April 30, 2017 |  | October 31, 2016 |
| Maintenance spares, net | $ | 48,447 |  |  | $ | 49,535 |  |
| Deferred debt issuance costs, net (1) | 1,202 |  |  | 1,363 |  |
| Financing receivable | — |  |  | 1,870 |  |
| Other | 15,542 |  |  | 15,352 |  |
|  | $ | 65,191 |  |  | $ | 68,120 |  |

[0000936395-17-000038:notes:198]
(1) As described in Note 2 above, in connection with Ciena's adoption of ASU 2015-03 effective January 31, 2017, deferred debt issuance costs associated with its convertible notes and term loans were retrospectively reclassified from other long-term assets to current portion of long-term debt and long-term debt, net on the Condensed Consolidated Balance Sheets. The deferred debt issuance costs reflected relate to Ciena's ABL Credit Facility (described in Note 17 below). The amortization of deferred debt issuance costs for Ciena's ABL Credit Facility is included in interest expense, and was $0.2 million and $0.3 million during the first six months of fiscal 2017 and 2016, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-17-000038:notes:199]
[same as prior period, unchanged from 0000936395-17-000020:notes:186]

[0000936395-17-000038:notes:200]
| Six months ended |  | Beginning |  |  |  |  |  | Ending |
| April 30, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2016 |  | $ | 56,654 |  |  | 9,563 |  |  | (10,196 | ) |  | $ | 56,021 |  |
| 2017 |  | $ | 52,324 |  |  | 2,347 |  |  | (8,646 | ) |  | $ | 46,025 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-17-000038:notes:201]
For the periods below, one customer accounted for at least 10% of Ciena’s revenue, as follows (in thousands):

[0000936395-17-000038:notes:202]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| AT&T | $ | 107,532 |  |  | $ | 116,014 |  |  | $ | 203,969 |  |  | $ | 242,614 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-17-000038:notes:203]
[same as prior period, unchanged from 0000936395-17-000020:notes:192]

[0000936395-17-000038:notes:204]
|  | April 30, 2017 |  | October 31, 2016 |
| United States | $ | 99,694 |  |  | $ | 103,018 |  |
| Canada | 188,804 |  |  | 173,885 |  |
| Other International | 11,294 |  |  | 11,503 |  |
| Total | $ | 299,792 |  |  | $ | 288,406 |  |

[0000936395-17-000038:notes:205]
[same as prior period, unchanged from 0000936395-17-000020:notes:194]

[0000936395-17-000038:notes:206]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2017 |  | 2016 |  | 2017 |  | 2016 |
| North America | $ | 424,373 |  |  | $ | 395,505 |  |  | $ | 830,301 |  |  | $ | 788,209 |  |
| EMEA | 105,776 |  |  | 96,175 |  |  | 197,319 |  |  | 176,897 |  |
| CALA | 33,971 |  |  | 57,896 |  |  | 69,117 |  |  | 101,706 |  |
| APAC | 142,902 |  |  | 91,141 |  |  | 231,782 |  |  | 147,020 |  |
| Total | $ | 707,022 |  |  | $ | 640,717 |  |  | $ | 1,328,519 |  |  | $ | 1,213,832 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-17-000038:notes:207]
[same as prior period, unchanged from 0000936395-17-000020:notes:196]

[0000936395-17-000038:notes:208]
[same as prior period, unchanged from 0000936395-17-000020:notes:197]

[0000936395-17-000038:notes:209]
[same as prior period, unchanged from 0000936395-17-000020:notes:198]

[0000936395-17-000038:notes:210]
[same as prior period, unchanged from 0000936395-17-000020:notes:199]

[0000936395-17-000038:notes:211]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include the Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-17-000038:notes:212]
[same as prior period, unchanged from 0000936395-17-000020:notes:201]

[0000936395-17-000038:notes:213]
[same as prior period, unchanged from 0000936395-17-000020:notes:202]

[0000936395-17-000038:notes:214]
[same as prior period, unchanged from 0000936395-17-000020:notes:203]

[0000936395-17-000038:notes:215]
[same as prior period, unchanged from 0000936395-17-000020:notes:204]

[0000936395-17-000038:notes:216]
[same as prior period, unchanged from 0000936395-17-000020:notes:205]

[0000936395-17-000038:notes:217]
| ◦ | This segment includes Ciena’s Blue Planet network virtualization, service orchestration and network management software platform. Ciena's Blue Planet platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), and Ciena's manage, control and plan (MCP) solution, SDN Multilayer Controller and V-WAN application. |

[0000936395-17-000038:notes:218]
[same as prior period, unchanged from 0000936395-17-000020:notes:207]

[0000936395-17-000038:notes:219]
[same as prior period, unchanged from 0000936395-17-000020:notes:208]

[0000936395-17-000038:notes:220]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2017, equipment, building, furniture and fixtures, net totaled $299.8 million primarily supporting asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supporting Ciena's unallocated selling and general and administrative activities. As of April 30, 2017, $43.1 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Networking Platforms segment and $70.1 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of April 30, 2017, all of the maintenance spares, net, totaling $48.4 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-17-000038:notes:221]
[same as prior period, unchanged from 0000936395-17-000020:notes:210]

[0000936395-17-000038:notes:222]
[same as prior period, unchanged from 0000936395-17-000020:notes:211]

[0000936395-17-000038:notes:223]
Segment profit (loss) is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; acquisition and integration costs; restructuring costs; interest and other income (loss), net; interest expense; and provisions for income taxes.

[0000936395-17-000038:notes:224]
[same as prior period, unchanged from 0000936395-17-000020:notes:213]

[0000936395-17-000038:notes:225]
Ciena's operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia Pacific (“APAC”); and Caribbean and Latin America (“CALA”). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena's delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-17-000038:notes:226]
North America includes $392.0 million and $367.1 million of United States revenue for fiscal quarters ended April 30, 2017 and 2016, respectively. For the six months ended April 30, 2017 and 2016, United States revenue was $771.7 million and $732.3 million, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-17-000038:notes:227]
[same as prior period, unchanged from 0000936395-17-000020:notes:216]

[0000936395-17-000038:notes:228]
AT&T purchased products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-17-000038:notes:229]
[same as prior period, unchanged from 0000936395-17-000020:notes:218]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-17-000038:notes:230]
[same as prior period, unchanged from 0000936395-17-000020:notes:219]

[0000936395-17-000038:notes:231]
[same as prior period, unchanged from 0000936395-17-000020:notes:220]

[0000936395-17-000038:notes:232]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to  allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-17-000038:notes:233]
[same as prior period, unchanged from 0000936395-17-000020:notes:222]

[0000936395-17-000038:notes:234]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-17-000038:notes:235]
[same as prior period, unchanged from 0000936395-17-000020:notes:224]

[0000936395-17-000038:notes:236]
[same as prior period, unchanged from 0000936395-17-000020:notes:225]

[0000936395-17-000038:notes:237]
[same as prior period, unchanged from 0000936395-17-000020:notes:226]

[0000936395-17-000038:notes:238]
[same as prior period, unchanged from 0000936395-17-000020:notes:227]

[0000936395-17-000038:notes:239]
[same as prior period, unchanged from 0000936395-17-000020:notes:228]

[0000936395-17-000038:notes:240]
[same as prior period, unchanged from 0000936395-17-000020:notes:229]

[0000936395-17-000038:notes:241]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-17-000038:notes:242]
[same as prior period, unchanged from 0000936395-17-000020:notes:231]

[0000936395-17-000038:notes:243]
[same as prior period, unchanged from 0000936395-17-000020:notes:232]

[0000936395-17-000038:notes:244]
[same as prior period, unchanged from 0000936395-17-000020:notes:233]

[0000936395-17-000038:notes:245]
[same as prior period, unchanged from 0000936395-17-000020:notes:234]

[0000936395-17-000038:notes:246]
[same as prior period, unchanged from 0000936395-17-000020:notes:235]

[0000936395-17-000038:notes:247]
[same as prior period, unchanged from 0000936395-17-000020:notes:236]

[0000936395-17-000038:notes:248]
[same as prior period, unchanged from 0000936395-17-000020:notes:237]

[0000936395-17-000038:notes:249]
[same as prior period, unchanged from 0000936395-17-000020:notes:238]

[0000936395-17-000038:notes:250]
[same as prior period, unchanged from 0000936395-17-000020:notes:239]

[0000936395-17-000038:notes:251]
[same as prior period, unchanged from 0000936395-17-000020:notes:240]

[0000936395-17-000038:notes:252]
[same as prior period, unchanged from 0000936395-17-000020:notes:241]

[0000936395-17-000038:notes:253]
[same as prior period, unchanged from 0000936395-17-000020:notes:242]

[0000936395-17-000038:notes:254]
[same as prior period, unchanged from 0000936395-17-000020:notes:243]

[0000936395-17-000038:notes:255]
[same as prior period, unchanged from 0000936395-17-000020:notes:244]

[0000936395-17-000038:notes:256]
[same as prior period, unchanged from 0000936395-17-000020:notes:245]

[0000936395-17-000038:notes:257]
[same as prior period, unchanged from 0000936395-17-000020:notes:246]

[0000936395-17-000038:notes:258]
[same as prior period, unchanged from 0000936395-17-000020:notes:247]

[0000936395-17-000038:notes:259]
[same as prior period, unchanged from 0000936395-17-000020:notes:248]

[0000936395-17-000038:notes:260]
[same as prior period, unchanged from 0000936395-17-000020:notes:249]

[0000936395-17-000038:notes:261]
Loss Contingencies

[0000936395-17-000038:notes:262]
[same as prior period, unchanged from 0000936395-17-000020:notes:251]

[0000936395-17-000038:notes:263]
[same as prior period, unchanged from 0000936395-17-000020:notes:252]

[0000936395-17-000038:notes:264]
[same as prior period, unchanged from 0000936395-17-000020:notes:253]

[0000936395-17-000038:notes:265]
[same as prior period, unchanged from 0000936395-17-000020:notes:254]

[0000936395-17-000038:notes:266]
[same as prior period, unchanged from 0000936395-17-000020:notes:255]

[0000936395-17-000038:notes:267]
[same as prior period, unchanged from 0000936395-17-000020:notes:256]

[0000936395-17-000038:notes:268]
[same as prior period, unchanged from 0000936395-17-000020:notes:257]

[0000936395-17-000038:notes:269]
[same as prior period, unchanged from 0000936395-17-000020:notes:258]

[0000936395-17-000038:notes:270]
[same as prior period, unchanged from 0000936395-17-000020:notes:259]

[0000936395-17-000038:notes:271]
[same as prior period, unchanged from 0000936395-17-000020:notes:260]

[0000936395-17-000038:notes:272]
[same as prior period, unchanged from 0000936395-17-000020:notes:261]

[0000936395-17-000038:notes:273]
[same as prior period, unchanged from 0000936395-17-000020:notes:262]

[0000936395-17-000038:notes:274]
[same as prior period, unchanged from 0000936395-17-000020:notes:263]

[0000936395-17-000038:notes:275]
[same as prior period, unchanged from 0000936395-17-000020:notes:264]

[0000936395-17-000038:notes:276]
[same as prior period, unchanged from 0000936395-17-000020:notes:265]

[0000936395-17-000038:notes:277]
[same as prior period, unchanged from 0000936395-17-000020:notes:266]

[0000936395-17-000038:notes:278]
[same as prior period, unchanged from 0000936395-17-000020:notes:267]

[0000936395-17-000038:notes:279]
[same as prior period, unchanged from 0000936395-17-000020:notes:268]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-17-000038:notes:280]
[same as prior period, unchanged from 0000936395-17-000020:notes:278]

[0000936395-17-000038:notes:281]
The decrease in warranty provisions during fiscal 2017 was primarily due to lower failure rates and reduced costs due to efficiencies.

[0000936395-17-000038:notes:282]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner during the construction period for accounting purposes. As of the first day of Ciena's second quarter of fiscal 2017, occupancy of one office building was complete, and, as such, Ciena recorded a capital lease for this building which will be depreciated over the lease term. This occupancy also reduced the build-to-suit construction in progress asset and the corresponding long-term liability. See Note 10 for more details regarding this arrangement.
