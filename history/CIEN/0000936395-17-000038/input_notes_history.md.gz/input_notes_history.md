# CIEN note change history — 0000936395-17-000020 → 0000936395-17-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:1]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. On May 11, 2017, the Court of Chancery granted the defendants' motion to dismiss the third amended complaint with prejudice.
  (was, 2017-03-08, similarity 0.9422):
[0000936395-17-000020:note_history:1]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:2]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.
  (was, 2017-03-08, similarity 0.9831):
[0000936395-17-000020:note_history:2]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:3]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in either other current assets or other long-term assets depending upon the duration of the restriction.
  (was, 2017-03-08, similarity 0.9088):
[0000936395-17-000020:note_history:3]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending upon the duration of the restriction.

- changed (2017-06-07):
[0000936395-17-000038:note_history:4]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that a decline in the fair value of any investment below its cost basis is other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.
  (was, 2017-03-08, similarity 0.9497):
[0000936395-17-000020:note_history:4]
Ciena's investments are classified as available-for-sale and are reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena's cost basis, and Ciena's intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

- changed (2017-06-07):
[0000936395-17-000038:note_history:5]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.
  (was, 2017-03-08, similarity 0.9929):
[0000936395-17-000020:note_history:5]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.

- changed (2017-06-07):
[0000936395-17-000038:note_history:6]
Ciena expenses legal costs associated with litigation as incurred.
  (was, 2017-03-08, similarity 0.9429):
[0000936395-17-000020:note_history:6]
Ciena expenses legal costs associated with litigation defense as incurred.

- added (2017-06-07):
[0000936395-17-000038:note_history:7]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

- changed (2017-06-07):
[0000936395-17-000038:note_history:8]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2012) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.
  (was, 2017-03-08, similarity 0.997):
[0000936395-17-000020:note_history:8]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2010) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

- changed (2017-06-07):
[0000936395-17-000038:note_history:9]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.
  (was, 2017-03-08, similarity 0.982):
[0000936395-17-000020:note_history:9]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements. See Note 21 below.

- changed (2017-06-07):
[0000936395-17-000038:note_history:10]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.
  (was, 2017-03-08, similarity 0.9831):
[0000936395-17-000020:note_history:10]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

- changed (2017-06-07):
[0000936395-17-000038:note_history:11]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $6.4 million at April 30, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.
  (was, 2017-03-08, similarity 0.9969):
[0000936395-17-000020:note_history:11]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $7.9 million at January 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.

- changed (2017-06-07):
[0000936395-17-000038:note_history:12]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.
  (was, 2017-03-08, similarity 0.9973):
[0000936395-17-000020:note_history:12]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena has elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

- added (2017-06-07):
[0000936395-17-000038:note_history:13]
In January 2017, the FASB issued ASU No. 2017-1, Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. ASU 2017-01 is effective for Ciena beginning first quarter of fiscal 2018. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal.

- removed (2017-06-07):
[0000936395-17-000020:note_history:14]
Ciena accounts for income taxes using an asset and liability approach that recognizes deferred tax assets and liabilities for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based upon the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-06-07):
[0000936395-17-000038:note_history:15]
Outstanding Term Loan Payable

- changed (2017-06-07):
[0000936395-17-000038:note_history:16]
|  |  | April 30, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,377 |  |  | — |  |
|  |  | $ | 393,377 |  |  | $ | 486,303 |  |
  (was, 2017-03-08, similarity 0.835):
[0000936395-17-000020:note_history:16]
|  |  | January 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | 241,635 |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | 245,158 |  |  | 244,944 |  |
|  |  | $ | 486,793 |  |  | $ | 486,303 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:17]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $3.5 million at April 30, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.5 million and $0.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.
  (was, 2017-03-08, similarity 0.9865):
[0000936395-17-000020:note_history:17]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $4.6 million at January 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.3 million and $0.2 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.

- changed (2017-06-07):
[0000936395-17-000038:note_history:18]
2022 Term Loan
  (was, 2017-03-08, similarity 0.8571):
[0000936395-17-000020:note_history:18]
Term Loans

- added (2017-06-07):
[0000936395-17-000038:note_history:19]
On January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its existing 2019 Term Loan and 2021 Term Loan (as described under "Prior Term Loans" below) into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena received a loan in the amount of $399.5 million, net of original discount, from the 2022 Term Loan and repaid $493.1 million of outstanding principal under the 2019 Term Loan and 2021 Term Loan. The 2022 Term Loan requires Ciena to make installment payments of approximately $1 million on a quarterly basis. This arrangement was accounted for as a modification of debt and, as such, $2.9 million of debt issuance costs associated with the 2022 Term Loan were expensed and the aggregate balance of $3.5 million of debt issuance costs and approximately $1.7 million of original discount from the 2019 Term Loan and the 2021 Term Loan, and approximately $0.5 million of original discount from the 2022 Term Loan, are included in the carrying value of the 2022 Term Loan. See table below.

- added (2017-06-07):
[0000936395-17-000038:note_history:20]
The Refinancing Agreement amends the Term Loan Credit Agreement (as defined below) and provides that the 2022 Term Loan will, among other things:

- added (2017-06-07):
[0000936395-17-000038:note_history:21]
| • | be subject to mandatory prepayment on the same basis as under the Term Loan Credit Agreement; |

- added (2017-06-07):
[0000936395-17-000038:note_history:22]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

- added (2017-06-07):
[0000936395-17-000038:note_history:23]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

- added (2017-06-07):
[0000936395-17-000038:note_history:24]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

- changed (2017-06-07):
[0000936395-17-000038:note_history:25]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability components of our 2022 Term Loan were as follows as of April 30, 2017 (in thousands):
  (was, 2017-03-08, similarity 0.9054):
[0000936395-17-000020:note_history:25]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our 2020 notes were as follows as of January 31, 2017 (in thousands):

- changed (2017-06-07):
[0000936395-17-000038:note_history:26]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,153 | ) |  | $ | (3,470 | ) |  | $393,377 |
  (was, 2017-03-08, similarity 0.6793):
[0000936395-17-000020:note_history:26]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 202,160 |  |  | $ | (10,954 | ) |  | $ | (1,183 | ) |  | $190,023 |  | $ | 43,131 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:27]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loan (in thousands):
  (was, 2017-03-08, similarity 0.9957):
[0000936395-17-000020:note_history:27]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loans (in thousands):

- added (2017-06-07):
[0000936395-17-000038:note_history:28]
|  |  | April 30, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022(1) |  | $ | 393,377 |  |  | $ | 401,494 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:29]
| (1) | Includes unamortized debt discount and debt issuance costs. |
  (was, 2017-03-08, similarity 0.9565):
[0000936395-17-000020:note_history:29]
| (1) | Includes unamortized bond discount and debt issuance costs. |

- changed (2017-06-07):
[0000936395-17-000038:note_history:30]
| (2) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2017-03-08, similarity 0.9823):
[0000936395-17-000020:note_history:30]
| (2) | Ciena's term loans are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loans using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2017-06-07):
[0000936395-17-000038:note_history:31]
Prior Term Loans

- changed (2017-06-07):
[0000936395-17-000038:note_history:32]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.
  (was, 2017-03-08, similarity 0.8873):
[0000936395-17-000020:note_history:32]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis. At the beginning of the second quarter of fiscal 2017, Ciena refinanced the 2019 Term Loan and the 2021 Term Loan. See Note 22 below.

- changed (2017-06-07):
[0000936395-17-000038:note_history:33]
|  |  | April 30, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 188,509 |  |
|  |  | $ | 725,026 |  |  | $ | 767,379 |  |
  (was, 2017-03-08, similarity 0.8525):
[0000936395-17-000020:note_history:33]
|  |  | January 31, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 184,563 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 471,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 264,759 |  |
|  |  | $ | 723,084 |  |  | $ | 920,510 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:34]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $2.9 million at April 30, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.0 million and $1.4 million during the first six months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.
  (was, 2017-03-08, similarity 0.9872):
[0000936395-17-000020:note_history:34]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $3.4 million at January 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.5 million and $0.7 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.

- added (2017-06-07):
[0000936395-17-000038:note_history:35]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our Ciena's outstanding issues of convertible notes were as follows as of April 30, 2017 (in thousands):

- added (2017-06-07):
[0000936395-17-000038:note_history:36]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 0.875% Convertible Senior Notes due June 15, 2017 | $ | 185,258 |  |  | $ | — |  |  | $ | (37 | ) |  | $185,221 |  | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,752 | ) |  | $348,248 |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,093 |  |  | $ | (10,428 | ) |  | $ | (1,108 | ) |  | $191,557 |  | $ | 43,131 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:37]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2017:
  (was, 2017-03-08, similarity 0.9753):
[0000936395-17-000020:note_history:37]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2017:

- added (2017-06-07):
[0000936395-17-000038:note_history:38]
|  |  | April 30, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 185,085 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 449,313 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 254,925 |  |
|  |  | $ | 725,026 |  |  | $ | 889,323 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:39]
| (1) | Includes unamortized debt discount, accretion of principal and debt issuance costs. |
  (was, 2017-03-08, similarity 0.9724):
[0000936395-17-000020:note_history:39]
| (1) | Includes unamortized discount, accretion of principal and debt issuance costs. |

- removed (2017-06-07):
[0000936395-17-000020:note_history:40]
|  |  | January 31, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019 (1) |  | $ | 241,635 |  |  | $ | 244,375 |  |
| Term Loan Payable due April 25, 2021(1) |  | 245,158 |  |  | 248,750 |  |
|  |  | $ | 486,793 |  |  | $ | 493,125 |  |

- removed (2017-06-07):
[0000936395-17-000020:note_history:41]
During the first three months of fiscal 2017, Ciena entered into a private transaction to repurchase $46.3 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for an aggregate purchase price of $46.3 million.

- removed (2017-06-07):
[0000936395-17-000020:note_history:42]
|  |  | January 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 188,509 |  |
|  |  | $ | 723,084 |  |  | $ | 767,379 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:43]
|  | April 30, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 255,042 |  |  | $ | — |  |  | (233 | ) |  | $ | 254,809 |  |
| Included in long-term investments | 89,987 |  |  | — |  |  | (135 | ) |  | 89,852 |  |
|  | $ | 345,029 |  |  | $ | — |  |  | $ | (368 | ) |  | $ | 344,661 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,970 |  |  | — |  |  | — |  |  | $ | 19,970 |  |
|  | $ | 19,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,970 |  |
  (was, 2017-03-08, similarity 0.6252):
[0000936395-17-000020:note_history:43]
|  | January 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 230,090 |  |  | $ | 60 |  |  | (46 | ) |  | $ | 230,104 |  |
| Included in long-term investments | 110,035 |  |  | 5 |  |  | (106 | ) |  | 109,934 |  |
|  | $ | 340,125 |  |  | $ | 65 |  |  | $ | (152 | ) |  | $ | 340,038 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,952 |  |  | — |  |  | — |  |  | $ | 19,952 |  |
|  | $ | 19,952 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,952 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:44]
The following table summarizes the final legal maturities of debt investments at April 30, 2017 (in thousands):
  (was, 2017-03-08, similarity 0.9626):
[0000936395-17-000020:note_history:44]
The following table summarizes the final legal maturities of debt investments at January 31, 2017 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:45]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2017:
  (was, 2017-03-08, similarity 0.9753):
[0000936395-17-000020:note_history:45]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2017:

- changed (2017-06-07):
[0000936395-17-000038:note_history:46]
|  |  | April 30, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 185,085 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 449,313 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 254,925 |  |
|  |  | $ | 725,026 |  |  | $ | 889,323 |  |
  (was, 2017-03-08, similarity 0.9239):
[0000936395-17-000020:note_history:46]
|  |  | January 31, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 184,563 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 471,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 264,759 |  |
|  |  | $ | 723,084 |  |  | $ | 920,510 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:47]
| (1) | Includes unamortized debt discount, accretion of principal and debt issuance costs. |
  (was, 2017-03-08, similarity 0.9724):
[0000936395-17-000020:note_history:47]
| (1) | Includes unamortized discount, accretion of principal and debt issuance costs. |

- changed (2017-06-07):
[0000936395-17-000038:note_history:48]
|  |  | April 30, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | — |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | — |  |  | 244,944 |  |
| Term Loan Payable due January 30, 2022 |  | 393,377 |  |  | — |  |
|  |  | $ | 393,377 |  |  | $ | 486,303 |  |
  (was, 2017-03-08, similarity 0.835):
[0000936395-17-000020:note_history:48]
|  |  | January 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | 241,635 |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | 245,158 |  |  | 244,944 |  |
|  |  | $ | 486,793 |  |  | $ | 486,303 |  |

- added (2017-06-07):
[0000936395-17-000038:note_history:49]
|  |  | April 30, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,221 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 348,248 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 191,557 |  |  | 188,509 |  |
|  |  | $ | 725,026 |  |  | $ | 767,379 |  |

- changed (2017-06-07):
[0000936395-17-000038:note_history:50]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loan (in thousands):
  (was, 2017-03-08, similarity 0.9957):
[0000936395-17-000020:note_history:50]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loans (in thousands):

- added (2017-06-07):
[0000936395-17-000038:note_history:51]
|  |  | April 30, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due January 30, 2022(1) |  | $ | 393,377 |  |  | $ | 401,494 |  |

- removed (2017-06-07):
[0000936395-17-000020:note_history:52]
|  |  | January 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 188,509 |  |
|  |  | $ | 723,084 |  |  | $ | 767,379 |  |

- removed (2017-06-07):
[0000936395-17-000020:note_history:53]
|  |  | January 31, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019 (1) |  | $ | 241,635 |  |  | $ | 244,375 |  |
| Term Loan Payable due April 25, 2021(1) |  | 245,158 |  |  | 248,750 |  |
|  |  | $ | 486,793 |  |  | $ | 493,125 |  |

- removed (2017-06-07):
[0000936395-17-000020:note_history:54]
| (1) | Includes unamortized bond discount and debt issuance costs. |

- removed (2017-06-07):
[0000936395-17-000020:note_history:55]
| (2) | Ciena's term loans are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loans using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-06-07):
[0000936395-17-000038:note_history:56]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability components of our 2022 Term Loan were as follows as of April 30, 2017 (in thousands):
  (was, 2017-03-08, similarity 0.9054):
[0000936395-17-000020:note_history:56]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our 2020 notes were as follows as of January 31, 2017 (in thousands):

- changed (2017-06-07):
[0000936395-17-000038:note_history:57]
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |
| Term Loan Payable due January 30, 2022 | $ | 399,000 |  |  | $ | (2,153 | ) |  | $ | (3,470 | ) |  | $393,377 |
  (was, 2017-03-08, similarity 0.6793):
[0000936395-17-000020:note_history:57]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 202,160 |  |  | $ | (10,954 | ) |  | $ | (1,183 | ) |  | $190,023 |  | $ | 43,131 |  |

- added (2017-06-07):
[0000936395-17-000038:note_history:58]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our Ciena's outstanding issues of convertible notes were as follows as of April 30, 2017 (in thousands):

- added (2017-06-07):
[0000936395-17-000038:note_history:59]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 0.875% Convertible Senior Notes due June 15, 2017 | $ | 185,258 |  |  | $ | — |  |  | $ | (37 | ) |  | $185,221 |  | $ | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | $ | 350,000 |  |  | $ | — |  |  | $ | (1,752 | ) |  | $348,248 |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 203,093 |  |  | $ | (10,428 | ) |  | $ | (1,108 | ) |  | $191,557 |  | $ | 43,131 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2017-06-07):
[0000936395-17-000020:note_history:60]
SUBSEQUENT EVENT

- removed (2017-06-07):
[0000936395-17-000020:note_history:61]
Under the Term Loan Credit Agreement, Ciena had two existing term loan tranches, the 2019 Term Loan, with an outstanding aggregate principal amount of $244.4 million, and the 2021 Term Loan, with an outstanding aggregate principal amount of $248.8 million (together, the “Existing Term Loans”).

- removed (2017-06-07):
[0000936395-17-000020:note_history:62]
Following the end of our first quarter of fiscal 2017, on January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced the Existing Term Loans into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena repaid $93.1 million of outstanding principal under the Existing Term Loans, and the remaining balances under the Existing Term Loans were refinanced and replaced by the 2022 Term Loan. The Refinancing Agreement amends the Term Loan Credit Agreement and provides that the 2022 Term Loan will, among other things:

- removed (2017-06-07):
[0000936395-17-000020:note_history:63]
| • | mature on January 30, 2022; |

- removed (2017-06-07):
[0000936395-17-000020:note_history:64]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2022 Term Loan as of January 30, 2017, with the balance payable at maturity; |

- removed (2017-06-07):
[0000936395-17-000020:note_history:65]
| • | be subject to mandatory prepayment on the same basis as the Existing Term Loans under the Term Loan Credit Agreement; |

- removed (2017-06-07):
[0000936395-17-000020:note_history:66]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

- removed (2017-06-07):
[0000936395-17-000020:note_history:67]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

- removed (2017-06-07):
[0000936395-17-000020:note_history:68]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.
