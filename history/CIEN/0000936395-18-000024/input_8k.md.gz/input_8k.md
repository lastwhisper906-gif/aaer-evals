# CIEN 8-K — 0000936395-18-000021 filed 2018-05-31

## item codes, every 8-K on or before 2018-06-06

- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2018-06-06

- none on or before 2018-06-06

## item 2.02 — earnings release, exhibit 99.1

[0000936395-18-000021:8k_2_02:1]
EX-99.1
2
exhibit991-2018q2earningsp.htm
EXHIBIT 99.1

[0000936395-18-000021:8k_2_02:2]
Exhibit

[0000936395-18-000021:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-18-000021:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2018 Financial Results

[0000936395-18-000021:8k_2_02:5]
Announces Intent to Acquire Packet Design to Accelerate Automation Software Strategy

[0000936395-18-000021:8k_2_02:6]
HANOVER, Md. - May 31, 2018 - Ciena® Corporation (NYSE:  CIEN)

[0000936395-18-000021:8k_2_02:7]
| • | Q2 Revenue: $730.0 million, increasing 3% year over year |

[0000936395-18-000021:8k_2_02:8]
| • | Q2 Net Income per Share: $0.09 GAAP; $0.23 adjusted (non-GAAP) |

[0000936395-18-000021:8k_2_02:9]
| • | Share Repurchases: Repurchased approximately 1.4 million shares of common stock for an aggregate price of $33.4 million during the quarter |

[0000936395-18-000021:8k_2_02:10]
Ciena, a network strategy and technology company, today announced unaudited financial results for its fiscal second quarter ended April 30, 2018.

[0000936395-18-000021:8k_2_02:11]
Ciena President and CEO Gary B. Smith remarked: "We delivered strong revenue and record order flow in the second quarter as we continue to broaden our leadership and capture market share. Gross margin was impacted by several new, international service provider deployments in their early stages; however, we are confident in our ability to return to our normalized gross margin levels. We anticipate strong revenue growth in the second half of fiscal 2018 and we remain confident in our three-year financial targets."

[0000936395-18-000021:8k_2_02:12]
For the fiscal second quarter 2018, Ciena reported revenue of $730.0 million as compared to $707.0 million for the fiscal second quarter 2017.

[0000936395-18-000021:8k_2_02:13]
Ciena's GAAP net income for the fiscal second quarter 2018 was $13.9 million, or $0.09 per diluted common share, which compares to a GAAP net income of $38.0 million, or $0.25 per diluted common share, for the fiscal second quarter 2017.

[0000936395-18-000021:8k_2_02:14]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2018 was $33.8 million, or $0.23 per diluted common share, which compares to an adjusted (non-GAAP) net income of $48.2 million, or $0.30 per diluted common share, for the fiscal second quarter 2017.

[0000936395-18-000021:8k_2_02:15]
Fiscal Second Quarter 2018 Performance Summary

[0000936395-18-000021:8k_2_02:16]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendix A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-18-000021:8k_2_02:17]
|  |  | GAAP Results |
|  |  | Q2 |  | Q2 | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 730.0 |  |  | $ | 707.0 |  |  | 3.3 | % |
| Gross margin |  | 40.2 | % |  | 45.0 | % |  | (4.8 | )% |
| Operating expense |  | $ | 261.2 |  |  | $ | 260.4 |  |  | 0.3 | % |
| Operating margin |  | 4.4 | % |  | 8.2 | % |  | (3.8 | )% |

[0000936395-18-000021:8k_2_02:18]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q2 | Period Change |
|  |  | FY 2018 |  | FY 2017 |  | Y-T-Y* |
| Revenue |  | $ | 730.0 |  |  | $ | 707.0 |  |  | 3.3 | % |
| Adj. gross margin |  | 40.7 | % |  | 45.7 | % |  | (5.0 | )% |
| Adj. operating expense |  | $ | 240.6 |  |  | $ | 234.6 |  |  | 2.6 | % |
| Adj. operating margin |  | 7.7 | % |  | 12.5 | % |  | (4.8 | )% |
| Adj. EBITDA |  | $ | 77.1 |  |  | $ | 107.6 |  |  | (28.3 | )% |

[0000936395-18-000021:8k_2_02:19]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-18-000021:8k_2_02:20]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2018 |  | Q2 FY 2017 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 527.9 |  |  | 72.4 |  | $ | 505.2 |  |  | 71.4 |
| Packet Networking |  | 63.8 |  |  | 8.7 |  | 66.3 |  |  | 9.4 |
| Total Networking Platforms |  | 591.7 |  |  | 81.1 |  | 571.5 |  |  | 80.8 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |
| Software Platforms |  | 12.5 |  |  | 1.7 |  | 13.1 |  |  | 1.9 |
| Software-Related Services |  | 26.2 |  |  | 3.6 |  | 24.6 |  |  | 3.5 |
| Total Software and Software-Related Services |  | 38.7 |  |  | 5.3 |  | 37.7 |  |  | 5.4 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 60.9 |  |  | 8.3 |  | 58.2 |  |  | 8.2 |
| Installation and Deployment |  | 28.2 |  |  | 3.9 |  | 28.7 |  |  | 4.1 |
| Consulting and Network Design |  | 10.5 |  |  | 1.4 |  | 10.9 |  |  | 1.5 |
| Total Global Services |  | 99.6 |  |  | 13.6 |  | 97.8 |  |  | 13.8 |
| Total |  | $ | 730.0 |  |  | 100.0 |  | $ | 707.0 |  |  | 100.0 |

[0000936395-18-000021:8k_2_02:21]
Additional Performance Metrics for Fiscal Second Quarter 2018

[0000936395-18-000021:8k_2_02:22]
|  |  | Revenue by Geographic Region |
|  |  | Q2 FY 2018 |  | Q2 FY 2017 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 431.2 |  |  | 59.1 |  | $ | 424.4 |  |  | 60.0 |
| Europe, Middle East and Africa |  | 121.7 |  |  | 16.7 |  | 105.8 |  |  | 15.0 |
| Caribbean and Latin America |  | 25.1 |  |  | 3.4 |  | 33.9 |  |  | 4.8 |
| Asia Pacific |  | 152.0 |  |  | 20.8 |  | 142.9 |  |  | 20.2 |
| Total |  | $ | 730.0 |  |  | 100.0 |  | $ | 707.0 |  |  | 100.0 |

[0000936395-18-000021:8k_2_02:23]
**  Denotes %  of total revenue

[0000936395-18-000021:8k_2_02:24]
| • | U.S. customers contributed 53.8% of total revenue |

[0000936395-18-000021:8k_2_02:25]
| • | One customer accounted for greater than 10% of revenue and represented 12% of total revenue |

[0000936395-18-000021:8k_2_02:26]
| • | Cash and investments totaled $979.6 million |

[0000936395-18-000021:8k_2_02:27]
| • | Cash flow from operations totaled $37.4 million |

[0000936395-18-000021:8k_2_02:28]
| • | Free cash flow totaled $31.1 million |

[0000936395-18-000021:8k_2_02:29]
| • | Average days' sales outstanding (DSOs) were 80 |

[0000936395-18-000021:8k_2_02:30]
| • | Accounts receivable balance was $647.4 million |

[0000936395-18-000021:8k_2_02:31]
| • | Inventories totaled $231.3 million, including: |

[0000936395-18-000021:8k_2_02:32]
| ◦ | Raw materials: $48.4 million |

[0000936395-18-000021:8k_2_02:33]
| ◦ | Work in process: $13.2 million |

[0000936395-18-000021:8k_2_02:34]
| ◦ | Finished goods: $165.7 million |

[0000936395-18-000021:8k_2_02:35]
| ◦ | Deferred cost of sales: $55.2 million |

[0000936395-18-000021:8k_2_02:36]
| ◦ | Reserve for excess and obsolescence: $(51.2) million |

[0000936395-18-000021:8k_2_02:37]
| • | Product inventory turns were 6.4 |

[0000936395-18-000021:8k_2_02:38]
| • | Headcount totaled 5,688 |

[0000936395-18-000021:8k_2_02:39]
Acquisition of Packet Design

[0000936395-18-000021:8k_2_02:40]
Ciena also announced today that it has entered into a definitive agreement to acquire privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. The acquisition is intended to accelerate Ciena's Blue Planet software strategy, extending its intelligent automation capabilities into IP with critical new features that help customers optimize service delivery and maximize network utilization.

[0000936395-18-000021:8k_2_02:41]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Second Quarter 2018 Results

[0000936395-18-000021:8k_2_02:42]
Today, Thursday, May 31, 2018, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website supporting materials for its unaudited fiscal second quarter 2018 results.

[0000936395-18-000021:8k_2_02:43]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's fiscal third quarter outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-18-000021:8k_2_02:44]
Notes to Investors

[0000936395-18-000021:8k_2_02:45]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered strong revenue and record order flow in the second quarter as we continue to broaden our leadership and capture market share."; "Gross margin was impacted by several new, international service provider deployments in their early stages; however, we are confident in our ability to return to our normalized gross margin levels."; "We anticipate strong revenue growth in the second half of fiscal 2018 and we remain confident in our three-year financial targets."

[0000936395-18-000021:8k_2_02:46]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act, changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on March 7, 2018 and its Annual Report on Form 10-K filed with the SEC on December 22, 2017. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-18-000021:8k_2_02:47]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-18-000021:8k_2_02:48]
About Ciena.  Ciena (NYSE: CIEN) is a network strategy and technology company. We translate best-in-class technology into value through a high-touch, consultative business model - with a relentless drive to create exceptional experiences measured by outcomes. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-18-000021:8k_2_02:49]
CIENA CORPORATION

[0000936395-18-000021:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-18-000021:8k_2_02:51]
(in thousands, except per share data)

[0000936395-18-000021:8k_2_02:52]
(unaudited)

[0000936395-18-000021:8k_2_02:53]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 604,226 |  |  | $ | 584,630 |  |  | $ | 1,129,835 |  |  | $ | 1,091,623 |  |
| Services | 125,752 |  |  | 122,392 |  |  | 246,278 |  |  | 236,896 |  |
| Total revenue | 729,978 |  |  | 707,022 |  |  | 1,376,113 |  |  | 1,328,519 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 372,568 |  |  | 327,295 |  |  | 685,688 |  |  | 614,106 |  |
| Services | 64,103 |  |  | 61,487 |  |  | 125,353 |  |  | 122,388 |  |
| Total cost of goods sold | 436,671 |  |  | 388,782 |  |  | 811,041 |  |  | 736,494 |  |
| Gross profit | 293,307 |  |  | 318,240 |  |  | 565,072 |  |  | 592,025 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 116,924 |  |  | 121,623 |  |  | 235,448 |  |  | 238,492 |  |
| Selling and marketing | 97,359 |  |  | 88,551 |  |  | 185,874 |  |  | 173,553 |  |
| General and administrative | 38,976 |  |  | 34,990 |  |  | 77,382 |  |  | 70,854 |  |
| Amortization of intangible assets | 3,623 |  |  | 10,980 |  |  | 7,246 |  |  | 25,531 |  |
| Significant asset impairments and restructuring costs | 4,359 |  |  | 4,276 |  |  | 10,320 |  |  | 6,671 |  |
| Total operating expenses | 261,241 |  |  | 260,420 |  |  | 516,270 |  |  | 515,101 |  |
| Income from operations | 32,066 |  |  | 57,820 |  |  | 48,802 |  |  | 76,924 |  |
| Interest and other income (loss), net | 1,296 |  |  | (2,918 | ) |  | 2,871 |  |  | (2,548 | ) |
| Interest expense | (13,031 | ) |  | (13,308 | ) |  | (26,765 | ) |  | (28,511 | ) |
| Income before income taxes | 20,331 |  |  | 41,594 |  |  | 24,908 |  |  | 45,865 |  |
| Provision for income taxes 1 | 6,475 |  |  | 3,568 |  |  | 484,415 |  |  | 3,978 |  |
| Net income (loss) | $ | 13,856 |  |  | $ | 38,026 |  |  | $ | (459,507 | ) |  | $ | 41,887 |  |
| Net Income(loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income(loss) per common share | $ | 0.10 |  |  | $ | 0.27 |  |  | $ | (3.19 | ) |  | $ | 0.30 |  |
| Diluted net income(loss) per potential common share 2 | $ | 0.09 |  |  | $ | 0.25 |  |  | $ | (3.19 | ) |  | $ | 0.29 |  |
| Weighted average basic common shares outstanding | 143,975 |  |  | 141,743 |  |  | 143,948 |  |  | 141,223 |  |
| Weighted average dilutive potential common shares outstanding 3 | 147,973 |  |  | 165,273 |  |  | 143,948 |  |  | 147,842 |  |

[0000936395-18-000021:8k_2_02:54]
1.  The provision for income taxes for fiscal 2018 is primarily related to the enactment of the Tax Cuts and Jobs Act. These amounts are provisional and reflect management’s current estimates and current interpretations of the Tax Cuts and Jobs Act. These amounts may require adjustment in future periods as additional guidance under the Tax Cuts and Jobs Act becomes available and analysis of its provisions is completed. As of April 30, 2018, Ciena has net deferred tax assets of approximately $734.8 million, and consequently, over the near term, Ciena's cash taxes will continue to be primarily related to state taxes and tax expense of Ciena's foreign subsidiaries, which amounts have not historically been significant. Ciena's foreign and domestic income tax expense for the second quarter of fiscal 2018 and 2017 expected to be paid using cash was $2.0 million and $3.6 million, respectively. Ciena's foreign and domestic income tax expense for the six months ended April 30, 2018 and 2017 expected to be paid using cash was $3.0 million and $4.0 million, respectively.

[0000936395-18-000021:8k_2_02:55]
2. The calculation of GAAP diluted net income per common share for the second quarter of fiscal 2017 requires adding back interest expense of approximately $0.5 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, and approximately $3.6 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000021:8k_2_02:56]
The calculation of GAAP diluted net income per common share for the first six months of fiscal 2017 requires adding back interest expense of approximately $1.1 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-18-000021:8k_2_02:57]
3. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and restricted stock units and 2.7 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018.

[0000936395-18-000021:8k_2_02:58]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2017 includes 1.3 million shares underlying certain stock options and restricted stock units, 4.9 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017 and 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018.

[0000936395-18-000021:8k_2_02:59]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first six months of fiscal 2017 includes 1.4 million shares underlying certain stock options and restricted stock units and 5.2 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017.

[0000936395-18-000021:8k_2_02:60]
CIENA CORPORATION

[0000936395-18-000021:8k_2_02:61]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-18-000021:8k_2_02:62]
(in thousands, except share data)

[0000936395-18-000021:8k_2_02:63]
(unaudited)

[0000936395-18-000021:8k_2_02:64]
|  | April 30, 2018 |  | October 31, 2017 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 652,096 |  |  | $ | 640,513 |  |
| Short-term investments | 268,584 |  |  | 279,133 |  |
| Accounts receivable, net | 647,380 |  |  | 622,183 |  |
| Inventories | 231,338 |  |  | 267,143 |  |
| Prepaid expenses and other | 186,024 |  |  | 197,339 |  |
| Total current assets | 1,985,422 |  |  | 2,006,311 |  |
| Long-term investments | 58,895 |  |  | 49,783 |  |
| Equipment, building, furniture and fixtures, net | 298,631 |  |  | 308,465 |  |
| Goodwill | 267,442 |  |  | 267,458 |  |
| Other intangible assets, net | 90,573 |  |  | 100,997 |  |
| Deferred tax asset, net | 734,824 |  |  | 1,155,104 |  |
| Other long-term assets | 70,767 |  |  | 63,593 |  |
| Total assets | $ | 3,506,554 |  |  | $ | 3,951,711 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 264,398 |  |  | $ | 260,098 |  |
| Accrued liabilities and other short-term obligations | 270,231 |  |  | 322,934 |  |
| Deferred revenue | 101,918 |  |  | 102,418 |  |
| Current portion of long-term debt | 353,208 |  |  | 352,293 |  |
| Total current liabilities | 989,755 |  |  | 1,037,743 |  |
| Long-term deferred revenue | 76,725 |  |  | 82,589 |  |
| Other long-term obligations | 110,417 |  |  | 111,349 |  |
| Long-term debt, net | 585,538 |  |  | 583,688 |  |
| Total liabilities | $ | 1,762,435 |  |  | $ | 1,815,369 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 143,427,976 and 143,043,227 shares issued and outstanding | 1,434 |  |  | 1,430 |  |
| Additional paid-in capital | 6,810,226 |  |  | 6,810,182 |  |
| Accumulated other comprehensive income (loss) | (5,072 | ) |  | (11,017 | ) |
| Accumulated deficit | (5,062,469 | ) |  | (4,664,253 | ) |
| Total stockholders’ equity | 1,744,119 |  |  | 2,136,342 |  |
| Total liabilities and stockholders’ equity | $ | 3,506,554 |  |  | $ | 3,951,711 |  |

[0000936395-18-000021:8k_2_02:65]
CIENA CORPORATION

[0000936395-18-000021:8k_2_02:66]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-18-000021:8k_2_02:67]
(in thousands)

[0000936395-18-000021:8k_2_02:68]
(unaudited)

[0000936395-18-000021:8k_2_02:69]
|  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |
| Cash flows provided by operating activities: |  |  |  |
| Net income (loss) | $ | (459,507 | ) |  | $ | 41,887 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 41,400 |  |  | 35,548 |  |
| Share-based compensation costs | 26,559 |  |  | 24,830 |  |
| Amortization of intangible assets | 11,824 |  |  | 33,466 |  |
| Deferred taxes | 481,401 |  |  | — |  |
| Provision for inventory excess and obsolescence | 14,977 |  |  | 19,623 |  |
| Provision for warranty | 10,565 |  |  | 2,347 |  |
| Other | 12,645 |  |  | 10,416 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (28,055 | ) |  | 9,381 |  |
| Inventories | 20,420 |  |  | (95,554 | ) |
| Prepaid expenses and other | 2,623 |  |  | (15,054 | ) |
| Accounts payable, accruals and other obligations | (55,986 | ) |  | (24,974 | ) |
| Deferred revenue | (5,736 | ) |  | 3,832 |  |
| Net cash provided by operating activities | 73,130 |  |  | 45,748 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (31,946 | ) |  | (60,328 | ) |
| Restricted cash | 54 |  |  | — |  |
| Purchase of available for sale securities | (198,026 | ) |  | (179,833 | ) |
| Proceeds from maturities of available for sale securities | 200,000 |  |  | 180,000 |  |
| Settlement of foreign currency forward contracts, net | 132 |  |  | (2,965 | ) |
| Purchase of cost method investment | (767 | ) |  | — |  |
| Net cash used in investing activities | (30,553 | ) |  | (63,126 | ) |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (2,000 | ) |  | (47,296 | ) |
| Payment for modification of term loans | — |  |  | (93,625 | ) |
| Payment of capital lease obligations | (1,868 | ) |  | (1,528 | ) |
| Repurchases of common stock-repurchase program | (38,036 | ) |  | — |  |
| Proceeds from issuance of common stock | 11,804 |  |  | 10,345 |  |
| Net cash used in financing activities | (30,100 | ) |  | (132,104 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (894 | ) |  | 490 |  |
| Net increase (decrease) in cash and cash equivalents | 11,583 |  |  | (148,992 | ) |
| Cash and cash equivalents at beginning of period | 640,513 |  |  | 777,615 |  |
| Cash and cash equivalents at end of period | $ | 652,096 |  |  | $ | 628,623 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 21,843 |  |  | $ | 23,439 |  |
| Cash paid during the period for income taxes, net | $ | 15,136 |  |  | $ | 11,379 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 3,226 |  |  | $ | 3,818 |  |
| Building subject to capital lease | $ | — |  |  | $ | 20,695 |  |
| Non-cash financing activities |  |  |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 1,111 |  |  | $ | — |  |

[0000936395-18-000021:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures (unaudited) |  |  |
|  |  | Quarter Ended April 30, |
|  |  | 2018 |  | 2017 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 293,307 |  |  | $ | 318,240 |  |
| Share-based compensation-products |  | 824 |  |  | 708 |  |
| Share-based compensation-services |  | 722 |  |  | 679 |  |
| Amortization of intangible assets |  | 2,289 |  |  | 3,623 |  |
| Total adjustments related to gross profit |  | 3,835 |  |  | 5,010 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 297,142 |  |  | $ | 323,250 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 40.7 | % |  | 45.7 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 261,241 |  |  | $ | 260,420 |  |
| Share-based compensation-research and development |  | 3,796 |  |  | 3,653 |  |
| Share-based compensation-sales and marketing |  | 3,760 |  |  | 3,513 |  |
| Share-based compensation-general and administrative |  | 5,109 |  |  | 3,417 |  |
| Amortization of intangible assets |  | 3,623 |  |  | 10,980 |  |
| Significant asset impairments and restructuring costs |  | 4,359 |  |  | 4,276 |  |
| Total adjustments related to operating expense |  | 20,647 |  |  | 25,839 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 240,594 |  |  | $ | 234,581 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 32,066 |  |  | $ | 57,820 |  |
| Total adjustments related to gross profit |  | 3,835 |  |  | 5,010 |  |
| Total adjustments related to operating expense |  | 20,647 |  |  | 25,839 |  |
| Total adjustments related to income from operations |  | 24,482 |  |  | 30,849 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 56,548 |  |  | $ | 88,669 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 7.7 | % |  | 12.5 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 13,856 |  |  | $ | 38,026 |  |
| Exclude GAAP provision for income taxes |  | 6,475 |  |  | 3,568 |  |
| Income before income taxes |  | $ | 20,331 |  |  | $ | 41,594 |  |
| Total adjustments related to income from operations |  | 24,482 |  |  | 30,849 |  |
| Non-cash interest expense |  | 759 |  |  | 526 |  |
| Modification of debt |  | — |  |  | 2,924 |  |
| Adjusted income before income taxes |  | $ | 45,572 |  |  | $ | 75,893 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 11,789 |  |  | 27,701 |  |
| Adjusted (non-GAAP) net income |  | $ | 33,783 |  |  | $ | 48,192 |  |
| Weighted average basic common shares outstanding |  | 143,975 |  |  | 141,743 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 151,011 |  |  | 174,471 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.09 |  |  | $ | 0.25 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.23 |  |  | $ | 0.30 |  |

[0000936395-18-000021:8k_2_02:71]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2018 includes 1.3 million shares underlying certain stock options and restricted stock units, 2.7 million shares underlying Ciena's "New" 3.75% convertible senior notes, due October 15, 2018 and 3.0 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018. |

[0000936395-18-000021:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2017 includes 1.3 million shares underlying certain stock options and restricted stock units, 4.9 million shares underlying Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, 17.4 million shares underlying Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-18-000021:8k_2_02:73]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2018 requires adding back interest expense of approximately $0.5 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-18-000021:8k_2_02:74]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2017 requires adding back interest expense of approximately $0.3 million associated with Ciena's 0.875% convertible senior notes, which were paid at maturity during the third quarter of fiscal 2017, approximately $2.3 million associated with Ciena's "Original" 3.75% convertible senior notes, due October 15, 2018 and approximately $1.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020  to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-18-000021:8k_2_02:75]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |  |  |
|  |  | Quarter Ended April 30, |
|  |  | 2018 |  | 2017 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 13,856 |  |  | $ | 38,026 |  |
| Add: Interest expense |  | 13,031 |  |  | 13,308 |  |
| Less: Interest and other income (loss), net |  | 1,296 |  |  | (2,918 | ) |
| Add: Provision for income taxes |  | 6,475 |  |  | 3,568 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 20,567 |  |  | 18,849 |  |
| Add: Amortization of intangible assets |  | 5,912 |  |  | 14,602 |  |
| EBITDA |  | $ | 58,545 |  |  | $ | 91,271 |  |
| Add: Shared-based compensation cost |  | 14,166 |  |  | 12,005 |  |
| Add: Significant asset impairments and restructuring costs |  | 4,359 |  |  | 4,276 |  |
| Adjusted EBITDA |  | $ | 77,070 |  |  | $ | 107,552 |  |

[0000936395-18-000021:8k_2_02:76]
* * *

[0000936395-18-000021:8k_2_02:77]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-18-000021:8k_2_02:78]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-18-000021:8k_2_02:79]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-18-000021:8k_2_02:80]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-18-000021:8k_2_02:81]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-18-000021:8k_2_02:82]
| • | Modification of debt - costs incurred as a result of the modification of debt to refinance then existing term loans. |

[0000936395-18-000021:8k_2_02:83]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 25.87% for the second fiscal quarter of 2018, and 36.5% for the second fiscal quarter of 2017. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
