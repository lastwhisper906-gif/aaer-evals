# CIEN note change history — 0000936395-18-000013 → 0000936395-18-000024


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2018-06-06):
[0000936395-18-000024:note_history:1]
Canadian Grant

- added (2018-06-06):
[0000936395-18-000024:note_history:2]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation ("ENCQOR") project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.0 million) in reimbursement by the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the second quarter of fiscal 2018, Ciena recorded a CAD$10.3 million (approximately $8.1 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to April 30, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants.

- changed (2018-06-06):
[0000936395-18-000024:note_history:3]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference is scheduled before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2018-03-07, similarity 0.8287):
[0000936395-18-000013:note_history:3]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. On November 18, 2016, the Superior Court stayed the case pending the outcome of the Supreme Court’s decision. Oral argument was heard by the Supreme Court on this matter on November 28, 2017. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:4]
SIGNIFICANT ACCOUNTING POLICIES
  (was, 2018-03-07, similarity 0.6349):
[0000936395-18-000013:note_history:4]
RECENT ACCOUNTING PRONOUNCEMENTS

- changed (2018-06-06):
[0000936395-18-000024:note_history:5]
Except for the changes in certain policies described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.
  (was, 2018-03-07, similarity 0.9442):
[0000936395-18-000013:note_history:5]
Except for the changes in certain policies related to adoption of the accounting standards described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.

- added (2018-06-06):
[0000936395-18-000024:note_history:6]
Government Grants

- added (2018-06-06):
[0000936395-18-000024:note_history:7]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 17 below.

- changed (2018-06-06):
[0000936395-18-000024:note_history:8]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.
  (was, 2018-03-07, similarity 0.9773):
[0000936395-18-000013:note_history:8]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

- added (2018-06-06):
[0000936395-18-000024:note_history:9]
Ciena expects to implement ASU 2014-09 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- removed (2018-06-06):
[0000936395-18-000013:note_history:10]
Ciena expects to implement this standard using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:11]
|  |  | April 30, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 392,972 |  |
  (was, 2018-03-07, similarity 0.9583):
[0000936395-18-000013:note_history:11]
|  |  | January 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 392,972 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:12]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.7 million at April 30, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.4 million and$0.2 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.
  (was, 2018-03-07, similarity 0.8316):
[0000936395-18-000013:note_history:12]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.7 million at January 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.4 million and $0.5 million during the first three months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

- changed (2018-06-06):
[0000936395-18-000024:note_history:13]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of April 30, 2018 (in thousands):
  (was, 2018-03-07, similarity 0.9701):
[0000936395-18-000013:note_history:13]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of January 31, 2018 (in thousands):

- changed (2018-06-06):
[0000936395-18-000024:note_history:14]
|  |  | April 30, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 397,980 |  |
  (was, 2018-03-07, similarity 0.9669):
[0000936395-18-000013:note_history:14]
|  |  | January 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 397,993 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:15]
|  |  | April 30, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,028 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 194,717 |  |
|  |  | $ | 547,180 |  |  | $ | 543,009 |  |
  (was, 2018-03-07, similarity 0.9821):
[0000936395-18-000013:note_history:15]
|  |  | January 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,627 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 194,717 |  |
|  |  | $ | 545,085 |  |  | $ | 543,009 |  |

- added (2018-06-06):
[0000936395-18-000024:note_history:16]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.3 million at April 30, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.8 million and $1.0 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

- changed (2018-06-06):
[0000936395-18-000024:note_history:17]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of April 30, 2018 (in thousands):
  (was, 2018-03-07, similarity 0.975):
[0000936395-18-000013:note_history:17]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of January 31, 2018 (in thousands):

- changed (2018-06-06):
[0000936395-18-000024:note_history:18]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2018:
  (was, 2018-03-07, similarity 0.9759):
[0000936395-18-000013:note_history:18]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2018:

- changed (2018-06-06):
[0000936395-18-000024:note_history:19]
|  |  | April 30, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 80,907 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,028 |  |  | 381,268 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 265,125 |  |
|  |  | $ | 547,180 |  |  | $ | 727,300 |  |
  (was, 2018-03-07, similarity 0.9807):
[0000936395-18-000013:note_history:19]
|  |  | January 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 71,778 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 287,627 |  |  | 338,247 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 246,281 |  |
|  |  | $ | 545,085 |  |  | $ | 656,306 |  |

- removed (2018-06-06):
[0000936395-18-000013:note_history:20]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.9 million at January 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2018. There was no recorded amortization of deferred debt issuance costs for the 2022 Term Loan included in interest expense during the first three months of fiscal 2017. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:21]
|  | April 30, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,291 |  |  | $ | — |  |  | (601 | ) |  | $ | 238,690 |  |
| Included in long-term investments | 59,066 |  |  | — |  |  | (171 | ) |  | 58,895 |  |
|  | $ | 298,357 |  |  | $ | — |  |  | $ | (772 | ) |  | $ | 297,585 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,892 |  |  | 2 |  |  | — |  |  | $ | 29,894 |  |
|  | $ | 29,892 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,894 |  |
  (was, 2018-03-07, similarity 0.9887):
[0000936395-18-000013:note_history:21]
|  | January 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,404 |  |  | $ | — |  |  | (530 | ) |  | $ | 238,874 |  |
| Included in long-term investments | 59,313 |  |  | — |  |  | (162 | ) |  | 59,151 |  |
|  | $ | 298,717 |  |  | $ | — |  |  | $ | (692 | ) |  | $ | 298,025 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 39,868 |  |  | 1 |  |  | — |  |  | $ | 39,869 |  |
|  | $ | 39,868 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 39,869 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:22]
The following table summarizes the final legal maturities of debt investments at April 30, 2018 (in thousands):
  (was, 2018-03-07, similarity 0.9626):
[0000936395-18-000013:note_history:22]
The following table summarizes the final legal maturities of debt investments at January 31, 2018 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:23]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2018:
  (was, 2018-03-07, similarity 0.9759):
[0000936395-18-000013:note_history:23]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2018:

- changed (2018-06-06):
[0000936395-18-000024:note_history:24]
|  |  | April 30, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 80,907 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,028 |  |  | 381,268 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 265,125 |  |
|  |  | $ | 547,180 |  |  | $ | 727,300 |  |
  (was, 2018-03-07, similarity 0.9807):
[0000936395-18-000013:note_history:24]
|  |  | January 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 71,778 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 287,627 |  |  | 338,247 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 246,281 |  |
|  |  | $ | 545,085 |  |  | $ | 656,306 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:25]
|  |  | April 30, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 392,972 |  |
  (was, 2018-03-07, similarity 0.9583):
[0000936395-18-000013:note_history:25]
|  |  | January 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 392,972 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:26]
|  |  | April 30, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 397,980 |  |
  (was, 2018-03-07, similarity 0.9669):
[0000936395-18-000013:note_history:26]
|  |  | January 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 392,269 |  |  | $ | 397,993 |  |

- changed (2018-06-06):
[0000936395-18-000024:note_history:27]
|  |  | April 30, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,028 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 194,717 |  |
|  |  | $ | 547,180 |  |  | $ | 543,009 |  |
  (was, 2018-03-07, similarity 0.9821):
[0000936395-18-000013:note_history:27]
|  |  | January 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,125 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 287,627 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 196,333 |  |  | 194,717 |  |
|  |  | $ | 545,085 |  |  | $ | 543,009 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:28]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of April 30, 2018 (in thousands):
  (was, 2018-03-07, similarity 0.9701):
[0000936395-18-000013:note_history:28]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of January 31, 2018 (in thousands):

- changed (2018-06-06):
[0000936395-18-000024:note_history:29]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of April 30, 2018 (in thousands):
  (was, 2018-03-07, similarity 0.975):
[0000936395-18-000013:note_history:29]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of January 31, 2018 (in thousands):


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2018-06-06):
[0000936395-18-000024:note_history:30]
SUBSEQUENT EVENTS
  (was, 2018-03-07, similarity 0.9697):
[0000936395-18-000013:note_history:30]
SUBSEQUENT EVENT

- changed (2018-06-06):
[0000936395-18-000024:note_history:31]
From the end of the second quarter of fiscal 2018 through June 4, 2018, Ciena repurchased an additional 611,942 shares of its common stock, for an aggregate purchase price of $15.4 million at an average price of $25.15 per share, inclusive of repurchases pending settlement. As of June 4, 2018, Ciena has an aggregate of $245.5 million of authorized funds remaining under its Stock Repurchase Program.
  (was, 2018-03-07, similarity 0.9502):
[0000936395-18-000013:note_history:31]
From the end of the first quarter of fiscal 2018 through March 5, 2018, Ciena repurchased an additional 611,514 shares of its common stock, for an aggregate purchase price of  $13.8 million at an average price of $22.52 per share, including of repurchases pending settlement. As of March 5, 2018, Ciena has an aggregate of $280.5 million of authorized funds remaining under its Stock Repurchase Program.

- added (2018-06-06):
[0000936395-18-000024:note_history:32]
Packet Design Acquisition

- added (2018-06-06):
[0000936395-18-000024:note_history:33]
On May 30, 2018, Ciena entered into a definitive agreement to acquire privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. The transaction is expected to close during Ciena’s fiscal third quarter 2018 and is subject to customary closing conditions.
