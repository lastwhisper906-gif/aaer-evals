# CIEN notes — 0000936395-18-000024


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-18-000024:notes:1]
Government Grants

[0000936395-18-000024:notes:2]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates.


## cien:ScheduleOfStockRepurchaseProgramTableTextBlock

[0000936395-18-000024:notes:3]
[same as prior period, unchanged from 0000936395-18-000013:notes:1]

[0000936395-18-000024:notes:4]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2017 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 1,627,233 |  |  | 24.06 |  |  | 39,147 |  |
| Cumulative balance at April 30, 2018 | 1,627,233 |  |  | $ | 24.06 |  |  | $ | 39,147 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-18-000024:notes:5]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-18-000024:notes:6]
Outstanding Term Loan Payable

[0000936395-18-000024:notes:7]
2022 Term Loan

[0000936395-18-000024:notes:8]
The net carrying value of Ciena's Term Loan due January 30, 2022 (the "2022 Term Loan") was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000024:notes:9]
|  |  | April 30, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 392,972 |  |

[0000936395-18-000024:notes:10]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.7 million at April 30, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.4 million and$0.2 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.

[0000936395-18-000024:notes:11]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of Ciena's 2022 Term Loan were as follows as of April 30, 2018 (in thousands):

[0000936395-18-000024:notes:12]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 396,000 |  |  | $ | (1,694 | ) |  | $ | (2,740 | ) |  | $391,566 |

[0000936395-18-000024:notes:13]
The following table sets forth the carrying value and the estimated fair value of Ciena's 2022 Term Loan (in thousands):

[0000936395-18-000024:notes:14]
|  |  | April 30, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 391,566 |  |  | $ | 397,980 |  |

[0000936395-18-000024:notes:15]
| (1) | Ciena's term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-18-000024:notes:16]
Outstanding Convertible Notes Payable

[0000936395-18-000024:notes:17]
The net carrying values of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-18-000024:notes:18]
|  |  | April 30, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,028 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 194,717 |  |
|  |  | $ | 547,180 |  |  | $ | 543,009 |  |

[0000936395-18-000024:notes:19]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $1.3 million at April 30, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.8 million and $1.0 million during the first six months of fiscal 2018 and 2017, respectively. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

[0000936395-18-000024:notes:20]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena's outstanding issues of convertible notes were as follows as of April 30, 2018 (in thousands):

[0000936395-18-000024:notes:21]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (90 | ) |  | $ | 61,180 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (277 | ) |  | $ | (425 | ) |  | $ | 288,028 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 206,857 |  |  | $ | (8,079 | ) |  | $ | (806 | ) |  | $ | 197,972 |  |  | $ | 43,131 |  |

[0000936395-18-000024:notes:22]
| (1) | Includes accretion of principal at a rate of 1.85% per year |

[0000936395-18-000024:notes:23]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of April 30, 2018:

[0000936395-18-000024:notes:24]
|  |  | April 30, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,180 |  |  | $ | 80,907 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,028 |  |  | 381,268 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 197,972 |  |  | 265,125 |  |
|  |  | $ | 547,180 |  |  | $ | 727,300 |  |

[0000936395-18-000024:notes:25]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-18-000024:notes:26]
COMMITMENTS AND CONTINGENCIES

[0000936395-18-000024:notes:27]
Canadian Grant

[0000936395-18-000024:notes:28]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation ("ENCQOR") project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $45.0 million) in reimbursement by the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the second quarter of fiscal 2018, Ciena recorded a CAD$10.3 million (approximately $8.1 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to April 30, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants.

[0000936395-18-000024:notes:29]
Foreign Tax Contingencies

[0000936395-18-000024:notes:30]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-18-000024:notes:31]
Litigation

[0000936395-18-000024:notes:32]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference is scheduled before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-18-000024:notes:33]
Internal Investigations

[0000936395-18-000024:notes:34]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena's Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

[0000936395-18-000024:notes:35]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-18-000024:notes:36]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-18-000024:notes:37]
[same as prior period, unchanged from 0000936395-18-000013:notes:33]

[0000936395-18-000024:notes:38]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the six months ended April 30, 2018:

[0000936395-18-000024:notes:39]
|  | Unrealized Loss on |  | Unrealized Gain (Loss) on |  | Unrealized Gain on Forward |  | Cumulative Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (337 | ) |  | (440 | ) |  | 4,725 |  |  | 1,069 |  |  | 5,017 |  |
| Amounts reclassified from AOCI | — |  |  | 405 |  |  | 523 |  |  | — |  |  | 928 |  |
| Balance at April 30, 2018 | $ | (788 | ) |  | $ | (1,421 | ) |  | $ | 5,466 |  |  | $ | (8,329 | ) |  | $ | (5,072 | ) |

[0000936395-18-000024:notes:40]
The following table summarizes the changes in AOCI for the six months ended April 30, 2017:

[0000936395-18-000024:notes:41]
|  | Unrealized Gain/(Loss) on |  | Unrealized Gain (Loss) on |  | Unrealized Gain (Loss) on Forward |  | Cumulative Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (527 | ) |  | 52 |  |  | 3,556 |  |  | (1,753 | ) |  | 1,328 |  |
| Amounts reclassified from AOCI | — |  |  | 474 |  |  | 1,341 |  |  | — |  |  | 1,815 |  |
| Balance at April 30, 2017 | $ | (388 | ) |  | $ | (565 | ) |  | $ | (1,070 | ) |  | $ | (19,163 | ) |  | $ | (21,186 | ) |

[0000936395-18-000024:notes:42]
[same as prior period, unchanged from 0000936395-18-000013:notes:38]


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-18-000024:notes:43]
[same as prior period, unchanged from 0000936395-18-000013:notes:39]

[0000936395-18-000024:notes:44]
[same as prior period, unchanged from 0000936395-18-000013:notes:40]

[0000936395-18-000024:notes:45]
As of April 30, 2018 and October 31, 2017, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities, and its Euro denominated revenue. The notional amount of these contracts was approximately $114.2 million and $86.1 million as of April 30, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-18-000024:notes:46]
During the first six months of fiscal 2018 and fiscal 2017, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $92.5 million and $83.4 million as of April 30, 2018 and October 31, 2017, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-18-000024:notes:47]
[same as prior period, unchanged from 0000936395-18-000013:notes:43]

[0000936395-18-000024:notes:48]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 12 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements ("interest rate swaps"). The interest rate swaps fix 98%, 82%, and 77% of the principal value of the 2022 Term Loan from February 2017 through July 2018, July 2018 through June 2020, and June 2020 through January 2021, respectively. The fixed rate on the amounts hedged during these periods will be 4.25%, 4.25% and 4.75%, respectively. The total notional amount of these interest rate swaps in effect as of April 30, 2018 was $387.6 million. The total notional amount of these interest rate swaps in effect as of October 31, 2017 was $389.6 million.

[0000936395-18-000024:notes:49]
[same as prior period, unchanged from 0000936395-18-000013:notes:45]

[0000936395-18-000024:notes:50]
[same as prior period, unchanged from 0000936395-18-000013:notes:46]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-18-000024:notes:51]
[same as prior period, unchanged from 0000936395-18-000013:notes:47]

[0000936395-18-000024:notes:52]
[same as prior period, unchanged from 0000936395-18-000013:notes:48]

[0000936395-18-000024:notes:53]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Product costs | $ | 824 |  |  | $ | 708 |  |  | $ | 1,496 |  |  | $ | 1,269 |  |
| Service costs | 722 |  |  | 679 |  |  | 1,346 |  |  | 1,307 |  |
| Share-based compensation expense included in cost of sales | 1,546 |  |  | 1,387 |  |  | 2,842 |  |  | 2,576 |  |
| Research and development | 3,796 |  |  | 3,653 |  |  | 7,052 |  |  | 6,862 |  |
| Sales and marketing | 3,760 |  |  | 3,513 |  |  | 7,088 |  |  | 6,386 |  |
| General and administrative | 5,109 |  |  | 3,417 |  |  | 9,583 |  |  | 8,870 |  |
| Share-based compensation expense included in operating expense | 12,665 |  |  | 10,583 |  |  | 23,723 |  |  | 22,118 |  |
| Share-based compensation expense capitalized in inventory, net | (45 | ) |  | 35 |  |  | (6 | ) |  | 136 |  |
| Total share-based compensation | $ | 14,166 |  |  | $ | 12,005 |  |  | $ | 26,559 |  |  | $ | 24,830 |  |

[0000936395-18-000024:notes:54]
As of April 30, 2018, total unrecognized share-based compensation expense was approximately $93.0 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerShareTextBlock

[0000936395-18-000024:notes:55]
[same as prior period, unchanged from 0000936395-18-000013:notes:51]

[0000936395-18-000024:notes:56]
[same as prior period, unchanged from 0000936395-18-000013:notes:52]

[0000936395-18-000024:notes:57]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Net income (loss) | $ | 13,856 |  |  | $ | 38,026 |  |  | $ | (459,507 | ) |  | $ | 41,887 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 (1) | — |  |  | 495 |  |  | — |  |  | 1,097 |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original) | — |  |  | 3,588 |  |  | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | 13,856 |  |  | $ | 42,109 |  |  | $ | (459,507 | ) |  | $ | 42,984 |  |

[0000936395-18-000024:notes:58]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Basic weighted average shares outstanding | 143,975 |  |  | 141,743 |  |  | 143,948 |  |  | 141,223 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 1,345 |  |  | 1,317 |  |  | — |  |  | 1,409 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 (1) | — |  |  | 4,857 |  |  | — |  |  | 5,210 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New) (2) | 2,653 |  |  | — |  |  | — |  |  | — |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original) | — |  |  | 17,356 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 147,973 |  |  | 165,273 |  |  | 143,948 |  |  | 147,842 |  |

[0000936395-18-000024:notes:59]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Basic EPS | $ | 0.10 |  |  | $ | 0.27 |  |  | $ | (3.19 | ) |  | $ | 0.30 |  |
| Diluted EPS | $ | 0.09 |  |  | $ | 0.25 |  |  | $ | (3.19 | ) |  | $ | 0.29 |  |

[0000936395-18-000024:notes:60]
[same as prior period, unchanged from 0000936395-18-000013:notes:56]

[0000936395-18-000024:notes:61]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Shares underlying stock options and restricted stock units | 304 |  |  | 725 |  |  | 2,496 |  |  | 1,141 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) | 3,038 |  |  | — |  |  | 3,038 |  |  | 17,356 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) (2) | — |  |  | — |  |  | 1,672 |  |  | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 12,540 |  |  | 9,923 |  |  | 16,404 |  |  | 27,695 |  |

[0000936395-18-000024:notes:62]
(1)    Ciena's 0.875% convertible senior notes were paid at maturity during the third quarter of fiscal 2017.

[0000936395-18-000024:notes:63]
(2)    Upon any conversion of the outstanding 3.75% Convertible Senior Notes due 2018 ("New Notes"), Ciena intends to settle the principal amount thereof in cash. Accordingly, Ciena uses the treasury stock method for calculating any potential dilutive effect of the conversion spread on diluted net income per share, if applicable. The 14.3 million shares underlying the New Notes will have a dilutive impact on diluted net income per share of common stock when the average market price of Ciena common stock for a given period exceeds the conversion price of $20.17 per share for the New Notes. During the second quarter of fiscal 2018, the average market price of Ciena common stock was $24.76. As a result, for the quarter ended April 30, 2018, the conversion spread for the New Notes is 2.7 million shares and included in the calculation of the denominator. For the six months ended April 30, 2018, the conversion spread for the New Notes is 1.7 million shares; however, these shares were excluded from the calculation of the denominator as their inclusion would have had an anti-dilutive effect.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-18-000024:notes:64]
[same as prior period, unchanged from 0000936395-18-000013:notes:59]

[0000936395-18-000024:notes:65]
|  | April 30, 2018 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Money market funds | $ | 476,187 |  |  | $ | — |  |  | $ | 476,187 |  |
| U.S. government obligations | — |  |  | 297,585 |  |  | 297,585 |  |
| Commercial paper | — |  |  | 99,745 |  |  | 99,745 |  |
| Foreign currency forward contracts | — |  |  | 97 |  |  | 97 |  |
| Forward starting interest rate swaps | — |  |  | 6,333 |  |  | 6,333 |  |
| Total assets measured at fair value | $ | 476,187 |  |  | $ | 403,760 |  |  | $ | 879,947 |  |
| Liabilities: |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,317 |  |  | $ | 1,317 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,317 |  |  | $ | 1,317 |  |

[0000936395-18-000024:notes:66]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Money market funds | $ | 511,355 |  |  | $ | — |  |  | $ | 511,355 |  |
| U.S. government obligations | — |  |  | 298,976 |  |  | 298,976 |  |
| Commercial paper | — |  |  | 89,865 |  |  | 89,865 |  |
| Foreign currency forward contracts | — |  |  | 227 |  |  | 227 |  |
| Forward starting interest rate swaps | — |  |  | 218 |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 2,129 |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | 2,129 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-18-000024:notes:67]
[same as prior period, unchanged from 0000936395-18-000013:notes:62]

[0000936395-18-000024:notes:68]
|  | April 30, 2018 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Cash equivalents | $ | 476,187 |  |  | $ | 69,851 |  |  | $ | 546,038 |  |
| Short-term investments | — |  |  | 268,584 |  |  | 268,584 |  |
| Prepaid expenses and other | — |  |  | 97 |  |  | 97 |  |
| Long-term investments | — |  |  | 58,895 |  |  | 58,895 |  |
| Other long-term assets | — |  |  | 6,333 |  |  | 6,333 |  |
| Total assets measured at fair value | $ | 476,187 |  |  | $ | 403,760 |  |  | $ | 879,947 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,317 |  |  | $ | 1,317 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,317 |  |  | $ | 1,317 |  |

[0000936395-18-000024:notes:69]
|  | October 31, 2017 |
|  | Level 1 |  | Level 2 |  | Total |
| Assets: |  |  |  |  |  |
| Cash equivalents | $ | 511,355 |  |  | $ | 59,925 |  |  | $ | 571,280 |  |
| Short-term investments | — |  |  | 279,133 |  |  | 279,133 |  |
| Prepaid expenses and other | — |  |  | 227 |  |  | 227 |  |
| Long-term investments | — |  |  | 49,783 |  |  | 49,783 |  |
| Other long-term assets | — |  |  | 218 |  |  | 218 |  |
| Total assets measured at fair value | $ | 511,355 |  |  | $ | 389,286 |  |  | $ | 900,641 |  |
| Liabilities: |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 2,129 |  |  | $ | 2,129 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 2,129 |  |  | $ | 2,129 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-18-000024:notes:70]
[same as prior period, unchanged from 0000936395-18-000013:notes:65]

[0000936395-18-000024:notes:71]
[same as prior period, unchanged from 0000936395-18-000013:notes:66]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-18-000024:notes:72]
[same as prior period, unchanged from 0000936395-18-000013:notes:67]

[0000936395-18-000024:notes:73]
[same as prior period, unchanged from 0000936395-18-000013:notes:68]

[0000936395-18-000024:notes:74]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena has computed its income tax expense for the October 31, 2018 fiscal year using a blended federal tax rate of 23.4%. The 21% federal tax rate is expected to apply to Ciena’s fiscal year ending October 31, 2019 and each year thereafter. Ciena remeasured its deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-18-000024:notes:75]
During the six months ended April 30, 2018, Ciena recorded a provisional tax expense of $484.4 million, primarily related to the Tax Act and consisted of the following: a $431.3 million charge related to the remeasurement of U.S. net deferred tax assets at the lower statutory rate under the Tax Act and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and its deemed repatriation to the U.S.

[0000936395-18-000024:notes:76]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional amounts due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. Ciena has determined that the $45.6 million of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries and the $431.3 million of tax expense for DTA remeasurement were each provisional amounts and reasonable estimates as of April 30, 2018. Estimates used in the provisional amounts include the anticipated reversal pattern of the gross DTA plus the earnings and profits, cash position at the end of fiscal year 2018, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000936395-18-000024:notes:77]
Ciena currently intends to reinvest indefinitely its foreign earnings outside the U.S. However, Ciena intends to further study changes enacted by the Tax Act, costs of repatriation and the current and future cash needs of foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If Ciena determines to repatriate these earnings, the provisional amount of unrecognized deferred income tax liability related to these foreign withholding taxes would be approximately $24.0 million. There are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-18-000024:notes:78]
[same as prior period, unchanged from 0000936395-18-000013:notes:73]

[0000936395-18-000024:notes:79]
|  | April 30, |  | October 31, |
|  | 2018 |  | 2017 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 36,115 |  |  | $ | 56,597 |  |
| Depreciation and amortization | 288,145 |  |  | 451,385 |  |
| NOL and credit carry forward | 538,869 |  |  | 803,622 |  |
| Other | 18,706 |  |  | 29,398 |  |
| Gross deferred tax assets | 881,835 |  |  | 1,341,002 |  |
| Valuation allowance | (147,011 | ) |  | (185,898 | ) |
| Deferred tax asset, net of valuation allowance | $ | 734,824 |  |  | $ | 1,155,104 |  |

[0000936395-18-000024:notes:80]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. See Note 2 above and Note 14 below. As of April 30, 2018, Ciena continues to maintain a valuation allowance of $147.0 million. This valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-18-000024:notes:81]
[same as prior period, unchanged from 0000936395-18-000013:notes:76]

[0000936395-18-000024:notes:82]
[same as prior period, unchanged from 0000936395-18-000013:notes:77]

[0000936395-18-000024:notes:83]
|  | April 30, 2018 |  | October 31, 2017 |
| Raw materials | $ | 48,356 |  |  | $ | 52,898 |  |
| Work-in-process | 13,253 |  |  | 18,623 |  |
| Finished goods | 165,733 |  |  | 185,488 |  |
| Deferred cost of goods sold | 55,161 |  |  | 61,340 |  |
|  | 282,503 |  |  | 318,349 |  |
| Provision for excess and obsolescence | (51,165 | ) |  | (51,206 | ) |
|  | $ | 231,338 |  |  | $ | 267,143 |  |

[0000936395-18-000024:notes:84]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2018, Ciena recorded a provision for excess and obsolescence of $15.0 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-18-000024:notes:85]
The following table summarizes the final legal maturities of debt investments at April 30, 2018 (in thousands):

[0000936395-18-000024:notes:86]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 269,183 |  |  | $ | 268,584 |  |
| Due in 1-2 years | 59,066 |  |  | 58,895 |  |
|  | $ | 328,249 |  |  | $ | 327,479 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-18-000024:notes:87]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-18-000024:notes:88]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-18-000024:notes:89]
|  | April 30, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 239,291 |  |  | $ | — |  |  | (601 | ) |  | $ | 238,690 |  |
| Included in long-term investments | 59,066 |  |  | — |  |  | (171 | ) |  | 58,895 |  |
|  | $ | 298,357 |  |  | $ | — |  |  | $ | (772 | ) |  | $ | 297,585 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,892 |  |  | 2 |  |  | — |  |  | $ | 29,894 |  |
|  | $ | 29,892 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,894 |  |

[0000936395-18-000024:notes:90]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-18-000024:notes:91]
Newly Issued Accounting Standards - Effective

[0000936395-18-000024:notes:92]
In January 2017, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2017-01 ("ASU 2017-01"), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

[0000936395-18-000024:notes:93]
In August 2017, the FASB issued ASU No. 2017-12 ("ASU 2017-12"), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity's risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity's risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

[0000936395-18-000024:notes:94]
In March 2016, the FASB issued ASU No. 2016-09 ("ASU 2016-09"), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

[0000936395-18-000024:notes:95]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-18-000024:notes:96]
In May 2014, the FASB issued ASU No. 2014-09 ("ASU 2014-09"), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

[0000936395-18-000024:notes:97]
For multiple element software arrangements where vendor-specific objective evidence ("VSOE") of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of ASU 2014-09 will require that it determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

[0000936395-18-000024:notes:98]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-18-000024:notes:99]
Ciena has considered the impact of the guidance in Accounting Standards Codification ("ASC") 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

[0000936395-18-000024:notes:100]
Ciena expects to implement ASU 2014-09 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-18-000024:notes:101]
In February 2016, the FASB issued ASU No. 2016-02 ("ASU 2016-02"), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-18-000024:notes:102]
[same as prior period, unchanged from 0000936395-18-000013:notes:97]

[0000936395-18-000024:notes:103]
[same as prior period, unchanged from 0000936395-18-000013:notes:98]

[0000936395-18-000024:notes:104]
[same as prior period, unchanged from 0000936395-18-000013:notes:99]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-18-000024:notes:105]
[same as prior period, unchanged from 0000936395-18-000013:notes:100]

[0000936395-18-000024:notes:106]
[same as prior period, unchanged from 0000936395-18-000013:notes:101]

[0000936395-18-000024:notes:107]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Interest income | $ | 3,212 |  |  | $ | 1,507 |  |  | $ | 5,656 |  |  | $ | 2,789 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 2,868 |  |  | (2,749 | ) |  | 2,169 |  |  | (1,725 | ) |
| Foreign currency exchange gain (loss) | (4,804 | ) |  | 1,292 |  |  | (4,791 | ) |  | (1,125 | ) |
| Modification of term loan | — |  |  | (2,924 | ) |  | — |  |  | (2,924 | ) |
| Other | 20 |  |  | (44 | ) |  | (163 | ) |  | 437 |  |
| Interest and other income (loss), net | $ | 1,296 |  |  | $ | (2,918 | ) |  | $ | 2,871 |  |  | $ | (2,548 | ) |

[0000936395-18-000024:notes:108]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $4.8 million and $1.1 million in foreign currency exchange rate losses during the first six months of fiscal 2018 and fiscal 2017, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the remeasurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statements of Operations. During the first six months of fiscal 2018, Ciena recorded gains of $2.2 million from non-hedge designated foreign currency forward contracts. During the first six months of fiscal 2017, Ciena recorded losses of $1.7 million from non-hedge designated foreign currency forward contracts.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-18-000024:notes:109]
[same as prior period, unchanged from 0000936395-18-000013:notes:104]

[0000936395-18-000024:notes:110]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 126,823 |  |  | $ | 150,464 |  |  | $ | 215,392 |  |  | $ | 264,210 |  |
| Software and Software-Related Services | 8,276 |  |  | 4,551 |  |  | 31,911 |  |  | 12,252 |  |
| Global Services | 41,284 |  |  | 41,602 |  |  | 82,321 |  |  | 77,071 |  |
| Total segment profit | 176,383 |  |  | 196,617 |  |  | 329,624 |  |  | 353,533 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 97,359 |  |  | 88,551 |  |  | 185,874 |  |  | 173,553 |  |
| General and administrative | 38,976 |  |  | 34,990 |  |  | 77,382 |  |  | 70,854 |  |
| Amortization of intangible assets | 3,623 |  |  | 10,980 |  |  | 7,246 |  |  | 25,531 |  |
| Significant asset impairments and restructuring costs | 4,359 |  |  | 4,276 |  |  | 10,320 |  |  | 6,671 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (11,735 | ) |  | (16,226 | ) |  | (23,894 | ) |  | (31,059 | ) |
| Less: Provision for income taxes | 6,475 |  |  | 3,568 |  |  | 484,415 |  |  | 3,978 |  |
| Consolidated net income (loss) | $ | 13,856 |  |  | $ | 38,026 |  |  | $ | (459,507 | ) |  | $ | 41,887 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-18-000024:notes:111]
[same as prior period, unchanged from 0000936395-18-000013:notes:106]

[0000936395-18-000024:notes:112]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 527,867 |  |  | $ | 505,161 |  |  | $ | 955,297 |  |  | $ | 922,911 |  |
| Packet Networking | 63,815 |  |  | 66,326 |  |  | 132,418 |  |  | 138,520 |  |
| Total Networking Platforms | 591,682 |  |  | 571,487 |  |  | 1,087,715 |  |  | 1,061,431 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 12,544 |  |  | 13,143 |  |  | 42,120 |  |  | 30,192 |  |
| Software-Related Services | 26,201 |  |  | 24,573 |  |  | 50,112 |  |  | 46,904 |  |
| Total Software and Software-Related Services | 38,745 |  |  | 37,716 |  |  | 92,232 |  |  | 77,096 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 60,904 |  |  | 58,241 |  |  | 116,862 |  |  | 113,231 |  |
| Installation and Deployment | 28,209 |  |  | 28,695 |  |  | 58,225 |  |  | 56,614 |  |
| Consulting and Network Design | 10,438 |  |  | 10,883 |  |  | 21,079 |  |  | 20,147 |  |
| Total Global Services | 99,551 |  |  | 97,819 |  |  | 196,166 |  |  | 189,992 |  |
| Consolidated revenue | $ | 729,978 |  |  | $ | 707,022 |  |  | $ | 1,376,113 |  |  | $ | 1,328,519 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-18-000024:notes:113]
[same as prior period, unchanged from 0000936395-18-000013:notes:108]

[0000936395-18-000024:notes:114]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2018 (in thousands):

[0000936395-18-000024:notes:115]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 8,232 |  | (1) | 2,088 |  | (2) | 10,320 |  |
| Cash payments | (8,211 | ) |  | (1,896 | ) |  | (10,107 | ) |
| Balance at April 30, 2018 | $ | 1,312 |  |  | $ | 1,840 |  |  | $ | 3,152 |  |
| Current restructuring liabilities | $ | 1,312 |  |  | $ | 865 |  |  | $ | 2,177 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 975 |  |  | $ | 975 |  |

[0000936395-18-000024:notes:116]
| (1) | Reflects a global workforce reduction of approximately 150 employees during fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-18-000024:notes:117]
[same as prior period, unchanged from 0000936395-18-000013:notes:112]

[0000936395-18-000024:notes:118]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2017 (in thousands):

[0000936395-18-000024:notes:119]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 2,369 |  | (1) | 4,302 |  | (2) | 6,671 |  |
| Cash payments | (3,084 | ) |  | (1,133 | ) |  | (4,217 | ) |
| Balance at April 30, 2017 | $ | 153 |  |  | $ | 5,139 |  |  | $ | 5,292 |  |
| Current restructuring liabilities | $ | 153 |  |  | $ | 4,928 |  |  | $ | 5,081 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 211 |  |  | $ | 211 |  |

[0000936395-18-000024:notes:120]
| (1) | Reflects a global workforce reduction of approximately 50 employees during the first quarter of fiscal 2017 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes and systems. |

[0000936395-18-000024:notes:121]
| (2) | Reflects unfavorable lease commitments and relocation costs incurred during the second quarter of fiscal 2017 in connection with the facility transition from Ciena's existing research and development center located at Lab 10 on the former Nortel Carling Campus to a new campus facility in Ottawa, Canada. |


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-18-000024:notes:122]
[same as prior period, unchanged from 0000936395-18-000013:notes:115]

[0000936395-18-000024:notes:123]
|  | April 30, 2018 |  | October 31, 2017 |
| Compensation, payroll related tax and benefits(1) | $ | 78,744 |  |  | $ | 113,272 |  |
| Warranty | 43,392 |  |  | 42,456 |  |
| Vacation | 42,744 |  |  | 39,778 |  |
| Capital lease obligations | 3,828 |  |  | 3,772 |  |
| Interest payable | 3,602 |  |  | 3,612 |  |
| Other | 97,921 |  |  | 120,044 |  |
|  | $ | 270,231 |  |  | $ | 322,934 |  |

[0000936395-18-000024:notes:124]
[same as prior period, unchanged from 0000936395-18-000013:notes:117]


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-18-000024:notes:125]
[same as prior period, unchanged from 0000936395-18-000013:notes:118]

[0000936395-18-000024:notes:126]
| Six Months Ended April 30, |  | Beginning Balance |  | Current Period Provisions (1) |  | Settlements |  | Ending Balance |
| 2017 |  | $ | 52,324 |  |  | 2,347 |  |  | (8,646 | ) |  | $ | 46,025 |  |
| 2018 |  | $ | 42,456 |  |  | 10,565 |  |  | (9,629 | ) |  | $ | 43,392 |  |

[0000936395-18-000024:notes:127]
(1) As a result of lower than expected actual failure rates, Ciena adjusted its fiscal 2017 provision for warranty. This adjustment had the effect of reducing warranty provision by $6.3 million for the six months ended April 30, 2017.


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-18-000024:notes:128]
For the periods below, AT&T was the only customer that accounted for at least 10% of Ciena’s revenue as follows (in thousands):

[0000936395-18-000024:notes:129]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2018 |  | 2017 |  | 2018 |  | 2017 |
| AT&T | $ | 85,419 |  |  | $ | 107,532 |  |  | $ | 176,065 |  |  | $ | 203,969 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-18-000024:notes:130]
[same as prior period, unchanged from 0000936395-18-000013:notes:123]

[0000936395-18-000024:notes:131]
|  | April 30, 2018 |  | October 31, 2017 |
| Canada | $ | 197,632 |  |  | $ | 203,491 |  |
| United States | 81,051 |  |  | 90,482 |  |
| Other International | 19,948 |  |  | 14,492 |  |
| Total | $ | 298,631 |  |  | $ | 308,465 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-18-000024:notes:132]
[same as prior period, unchanged from 0000936395-18-000013:notes:125]

[0000936395-18-000024:notes:133]
[same as prior period, unchanged from 0000936395-18-000013:notes:126]

[0000936395-18-000024:notes:134]
Ciena manages its business, measures its performance and allocates its resources based on the following operating segments:

[0000936395-18-000024:notes:135]
[same as prior period, unchanged from 0000936395-18-000013:notes:128]

[0000936395-18-000024:notes:136]
| ◦ | Converged Packet Optical — includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. As of the first quarter of fiscal 2018, sales of Optical Transport products are also reflected within the Converged Packet Optical product line for all periods presented. |

[0000936395-18-000024:notes:137]
[same as prior period, unchanged from 0000936395-18-000013:notes:130]

[0000936395-18-000024:notes:138]
[same as prior period, unchanged from 0000936395-18-000013:notes:131]

[0000936395-18-000024:notes:139]
[same as prior period, unchanged from 0000936395-18-000013:notes:132]

[0000936395-18-000024:notes:140]
| ◦ | This segment includes Ciena’s Blue Planet network virtualization, service orchestration and network management software platform. Ciena's Blue Planet platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), and Ciena's manage, control and plan (MCP) domain controller solution, SDN Multilayer Controller and V-WAN application. |

[0000936395-18-000024:notes:141]
[same as prior period, unchanged from 0000936395-18-000013:notes:134]

[0000936395-18-000024:notes:142]
[same as prior period, unchanged from 0000936395-18-000013:notes:135]

[0000936395-18-000024:notes:143]
[same as prior period, unchanged from 0000936395-18-000013:notes:136]

[0000936395-18-000024:notes:144]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2018, equipment, building, furniture and fixtures, net totaled $298.6 million primarily supporting asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supporting Ciena's unallocated selling and general and administrative activities. As of April 30, 2018, $34.5 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Networking Platforms segment and $56.1 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of April 30, 2018, all of the maintenance spares, net, totaling $43.2 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-18-000024:notes:145]
[same as prior period, unchanged from 0000936395-18-000013:notes:138]

[0000936395-18-000024:notes:146]
[same as prior period, unchanged from 0000936395-18-000013:notes:139]

[0000936395-18-000024:notes:147]
Segment profit is determined based on internal performance measures used by Ciena's chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; significant asset impairments and restructuring costs; interest and other income (loss), net; interest expense; and provision for income taxes.

[0000936395-18-000024:notes:148]
[same as prior period, unchanged from 0000936395-18-000013:notes:141]

[0000936395-18-000024:notes:149]
Ciena's revenue includes $392.8 million and $392.0 million of United States revenue for the second quarter of fiscal 2018 and 2017, respectively. Ciena's revenue includes $79.4 million of India revenue for the second quarter of fiscal 2018. For the six months ended April 30, 2018 and 2017, United States revenue was $776.1 million and $771.7 million, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-18-000024:notes:150]
[same as prior period, unchanged from 0000936395-18-000013:notes:143]

[0000936395-18-000024:notes:151]
AT&T purchased products and services from each of Ciena's operating segments.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-18-000024:notes:152]
SIGNIFICANT ACCOUNTING POLICIES

[0000936395-18-000024:notes:153]
Except for the changes in certain policies described below, there have been no material changes to Ciena's significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena's annual report on Form 10-K for the fiscal year ended October 31, 2017.

[0000936395-18-000024:notes:154]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 17 below.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-18-000024:notes:155]
[same as prior period, unchanged from 0000936395-18-000013:notes:147]

[0000936395-18-000024:notes:156]
Adoption of ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting

[0000936395-18-000024:notes:157]
In connection with the adoption of ASU 2016-09, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Ciena also elected to recognize forfeitures of stock awards when they occur, rather than estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the period of adoption.

[0000936395-18-000024:notes:158]
[same as prior period, unchanged from 0000936395-18-000013:notes:150]

[0000936395-18-000024:notes:159]
On December 7, 2017, Ciena announced that its Board of Directors authorized a program to repurchase up to $300 million of Ciena’s common stock through the end of fiscal 2020. Ciena may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors, including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-18-000024:notes:160]
[same as prior period, unchanged from 0000936395-18-000013:notes:152]


## us-gaap:SubsequentEventsTextBlock

[0000936395-18-000024:notes:161]
SUBSEQUENT EVENTS

[0000936395-18-000024:notes:162]
From the end of the second quarter of fiscal 2018 through June 4, 2018, Ciena repurchased an additional 611,942 shares of its common stock, for an aggregate purchase price of $15.4 million at an average price of $25.15 per share, inclusive of repurchases pending settlement. As of June 4, 2018, Ciena has an aggregate of $245.5 million of authorized funds remaining under its Stock Repurchase Program.

[0000936395-18-000024:notes:163]
Packet Design Acquisition

[0000936395-18-000024:notes:164]
On May 30, 2018, Ciena entered into a definitive agreement to acquire privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. The transaction is expected to close during Ciena’s fiscal third quarter 2018 and is subject to customary closing conditions.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-18-000024:notes:165]
[same as prior period, unchanged from 0000936395-18-000013:notes:155]
