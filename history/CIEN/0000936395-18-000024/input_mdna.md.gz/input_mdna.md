# CIEN MD&A — 0000936395-18-000024


## mdna

[0000936395-18-000024:mdna:1]
[same as prior period, unchanged from 0000936395-18-000013:mdna:1]

[0000936395-18-000024:mdna:2]
[same as prior period, unchanged from 0000936395-18-000013:mdna:2]

[0000936395-18-000024:mdna:3]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” "projects," "targets," or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, our competitive landscape; market conditions and growth opportunities; factors impacting our industry; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and control of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including IT transitions or initiatives; the impact of the Tax Cuts and Jobs Act and provisional estimates with respect thereto; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-18-000024:mdna:4]
[same as prior period, unchanged from 0000936395-18-000013:mdna:4]

[0000936395-18-000024:mdna:5]
[same as prior period, unchanged from 0000936395-18-000013:mdna:5]

[0000936395-18-000024:mdna:6]
[same as prior period, unchanged from 0000936395-18-000013:mdna:6]

[0000936395-18-000024:mdna:7]
[same as prior period, unchanged from 0000936395-18-000013:mdna:7]

[0000936395-18-000024:mdna:8]
[same as prior period, unchanged from 0000936395-18-000013:mdna:8]

[0000936395-18-000024:mdna:9]
[same as prior period, unchanged from 0000936395-18-000013:mdna:9]

[0000936395-18-000024:mdna:10]
[same as prior period, unchanged from 0000936395-18-000013:mdna:10]

[0000936395-18-000024:mdna:11]
[same as prior period, unchanged from 0000936395-18-000013:mdna:11]

[0000936395-18-000024:mdna:12]
[same as prior period, unchanged from 0000936395-18-000013:mdna:12]

[0000936395-18-000024:mdna:13]
[same as prior period, unchanged from 0000936395-18-000013:mdna:13]

[0000936395-18-000024:mdna:14]
[same as prior period, unchanged from 0000936395-18-000013:mdna:14]

[0000936395-18-000024:mdna:15]
[same as prior period, unchanged from 0000936395-18-000013:mdna:15]

[0000936395-18-000024:mdna:16]
[same as prior period, unchanged from 0000936395-18-000013:mdna:16]

[0000936395-18-000024:mdna:17]
[same as prior period, unchanged from 0000936395-18-000013:mdna:17]

[0000936395-18-000024:mdna:18]
[same as prior period, unchanged from 0000936395-18-000013:mdna:18]

[0000936395-18-000024:mdna:19]
[same as prior period, unchanged from 0000936395-18-000013:mdna:19]

[0000936395-18-000024:mdna:20]
[same as prior period, unchanged from 0000936395-18-000013:mdna:20]

[0000936395-18-000024:mdna:21]
[same as prior period, unchanged from 0000936395-18-000013:mdna:21]

[0000936395-18-000024:mdna:22]
[same as prior period, unchanged from 0000936395-18-000013:mdna:22]

[0000936395-18-000024:mdna:23]
[same as prior period, unchanged from 0000936395-18-000013:mdna:23]

[0000936395-18-000024:mdna:24]
[same as prior period, unchanged from 0000936395-18-000013:mdna:24]

[0000936395-18-000024:mdna:25]
[same as prior period, unchanged from 0000936395-18-000013:mdna:25]

[0000936395-18-000024:mdna:26]
[same as prior period, unchanged from 0000936395-18-000013:mdna:26]

[0000936395-18-000024:mdna:27]
[same as prior period, unchanged from 0000936395-18-000013:mdna:27]

[0000936395-18-000024:mdna:28]
[same as prior period, unchanged from 0000936395-18-000013:mdna:28]

[0000936395-18-000024:mdna:29]
[same as prior period, unchanged from 0000936395-18-000013:mdna:29]

[0000936395-18-000024:mdna:30]
[same as prior period, unchanged from 0000936395-18-000013:mdna:30]

[0000936395-18-000024:mdna:31]
[same as prior period, unchanged from 0000936395-18-000013:mdna:31]

[0000936395-18-000024:mdna:32]
[same as prior period, unchanged from 0000936395-18-000013:mdna:32]

[0000936395-18-000024:mdna:33]
[same as prior period, unchanged from 0000936395-18-000013:mdna:33]

[0000936395-18-000024:mdna:34]
[same as prior period, unchanged from 0000936395-18-000013:mdna:34]

[0000936395-18-000024:mdna:35]
[same as prior period, unchanged from 0000936395-18-000013:mdna:35]

[0000936395-18-000024:mdna:36]
[same as prior period, unchanged from 0000936395-18-000013:mdna:36]

[0000936395-18-000024:mdna:37]
| • | adverse results in litigation matters. |

[0000936395-18-000024:mdna:38]
[same as prior period, unchanged from 0000936395-18-000013:mdna:38]

[0000936395-18-000024:mdna:39]
[same as prior period, unchanged from 0000936395-18-000013:mdna:39]

[0000936395-18-000024:mdna:40]
Our solutions include a diverse set of Networking Platforms products, which are used by a broad range of network operator customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which can be applied from the network core to network access points, allow

[0000936395-18-000024:mdna:41]
[same as prior period, unchanged from 0000936395-18-000013:mdna:41]

[0000936395-18-000024:mdna:42]
network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware systems and components, we offer network management and domain control software platforms, along with advanced applications software, designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. To complement our hardware and software solutions, we offer a broad range of services that help our customers design, optimize, integrate, deploy, manage, and maintain their networks.

[0000936395-18-000024:mdna:43]
Diversification of our business. We continue to diversify our customer base to include fast-growing customer segments, such as Web-scale providers, data center operators and emerging network operators, which have been important contributors to our overall growth and which are included among our largest customers by revenue. This diversification of our customer base can result in shifts in product mix, as evidenced by the increased sales of our WaveServer platform in recent periods. At the same time, a significant portion of our revenue and customer base continues to consist of sales to large service provider customers. Sales to AT&T were $176.1 million, or 12.8% of total revenue, during the first six months of fiscal 2018, and $204.0 million, or 15.4% of total revenue, during the first six months of fiscal 2017. Our revenue growth has benefited from a go-to-market strategy focused on generating new customer wins, displacing competitors, and capturing additional opportunities with service providers in international markets, particularly in our Asia-Pacific and India regions. We believe that continued diversification of our business is important to address the dynamic industry environment in which we operate, to continue to grow our business, and to better withstand potential slowdowns adversely affecting particular geographies, markets, customers or customer segments.

[0000936395-18-000024:mdna:44]
[same as prior period, unchanged from 0000936395-18-000013:mdna:42]

[0000936395-18-000024:mdna:45]
Impact of Tax Cuts and Jobs Act. Our results of operations for fiscal 2018 have been impacted by enactment of the Tax Cuts and Jobs Act (the "Tax Act") in December 2017. Specifically, our results for fiscal 2018 include a provisional $476.9 million tax charge consisting of the following:

[0000936395-18-000024:mdna:46]
[same as prior period, unchanged from 0000936395-18-000013:mdna:44]

[0000936395-18-000024:mdna:47]
[same as prior period, unchanged from 0000936395-18-000013:mdna:45]

[0000936395-18-000024:mdna:48]
[same as prior period, unchanged from 0000936395-18-000013:mdna:46]

[0000936395-18-000024:mdna:49]
Packet Design Acquisition. On May 30, 2018, we entered into a definitive agreement to acquire privately-held Packet Design, LLC, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics. We expect the acquisition of Packet Design to help accelerate our Blue Planet software strategy by extending our intelligent automation capabilities beyond Layers 0-2 and into Internet Protocols with critical new capabilities to help customers optimize service delivery and maximize network utilization. The transaction is expected to close during our fiscal third quarter 2018 and is subject to customary closing conditions.

[0000936395-18-000024:mdna:50]
[same as prior period, unchanged from 0000936395-18-000013:mdna:47]

[0000936395-18-000024:mdna:51]
[same as prior period, unchanged from 0000936395-18-000013:mdna:48]

[0000936395-18-000024:mdna:52]
28

[0000936395-18-000024:mdna:53]
[same as prior period, unchanged from 0000936395-18-000013:mdna:49]

[0000936395-18-000024:mdna:54]
[same as prior period, unchanged from 0000936395-18-000013:mdna:50]

[0000936395-18-000024:mdna:55]
[same as prior period, unchanged from 0000936395-18-000013:mdna:51]

[0000936395-18-000024:mdna:56]
Quarter ended April 30, 2018 compared to the quarter ended April 30, 2017

[0000936395-18-000024:mdna:57]
[same as prior period, unchanged from 0000936395-18-000013:mdna:53]

[0000936395-18-000024:mdna:58]
During the second quarter of fiscal 2018, approximately 20.3% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, Emirati Dirham and British Pounds. During the second quarter of fiscal 2018, as compared to the second quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $7.8 million, net of hedging, or 1.1%, as compared to the second quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000024:mdna:59]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 527,867 |  |  | 72.4 |  | $ | 505,161 |  |  | 71.4 |  | $ | 22,706 |  |  | 4.5 |  |
| Packet Networking | 63,815 |  |  | 8.7 |  | 66,326 |  |  | 9.4 |  | (2,511 | ) |  | (3.8 | ) |
| Total Networking Platforms | 591,682 |  |  | 81.1 |  | 571,487 |  |  | 80.8 |  | 20,195 |  |  | 3.5 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 12,544 |  |  | 1.7 |  | 13,143 |  |  | 1.9 |  | (599 | ) |  | (4.6 | ) |
| Software-Related Services | 26,201 |  |  | 3.6 |  | 24,573 |  |  | 3.5 |  | 1,628 |  |  | 6.6 |  |
| Total Software and Software-Related Services | 38,745 |  |  | 5.3 |  | 37,716 |  |  | 5.4 |  | 1,029 |  |  | 2.7 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 60,904 |  |  | 8.3 |  | 58,241 |  |  | 8.2 |  | 2,663 |  |  | 4.6 |  |
| Installation and Deployment | 28,209 |  |  | 3.9 |  | 28,695 |  |  | 4.1 |  | (486 | ) |  | (1.7 | ) |
| Consulting and Network Design | 10,438 |  |  | 1.4 |  | 10,883 |  |  | 1.5 |  | (445 | ) |  | (4.1 | ) |
| Total Global Services | 99,551 |  |  | 13.6 |  | 97,819 |  |  | 13.8 |  | 1,732 |  |  | 1.8 |  |
| Consolidated revenue | $ | 729,978 |  |  | 100.0 |  | $ | 707,022 |  |  | 100.0 |  | $ | 22,956 |  |  | 3.2 |  |

[0000936395-18-000024:mdna:60]
[same as prior period, unchanged from 0000936395-18-000013:mdna:56]

[0000936395-18-000024:mdna:61]
[same as prior period, unchanged from 0000936395-18-000013:mdna:57]

[0000936395-18-000024:mdna:62]
[same as prior period, unchanged from 0000936395-18-000013:mdna:58]

[0000936395-18-000024:mdna:63]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $22.7 million of our Converged Packet Optical products, partially offset by a product line sales decrease of $2.5 million of our Packet Networking products. |

[0000936395-18-000024:mdna:64]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $74.5 million of our Waveserver stackable interconnect system, primarily due to increased sales to Web-scale providers, which, as we continue to diversify, represent a growing portion of our business. These increases were partially offset by sales decreases of $28.1 million of our 6500 Packet-Optical Platform and $25.1 million of our 5410/5430 Reconfigurable Switching Systems. The decrease in sales of our 6500 Packet-Optical Platform is primarily due to decreased |

[0000936395-18-000024:mdna:65]
sales to cable and multiservice operators, government customers and AT&T. The decrease in sales of our 5410/5430 Reconfigurable Switching Systems is primarily due to decreased sales to a certain communications service provider in the APAC region.

[0000936395-18-000024:mdna:66]
| ◦ | Packet Networking sales primarily reflects a sales decrease of $11.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to AT&T, partially offset by increased sales to other communications service providers. This decrease was partially offset by a sales increase of $7.7 million of our 8700 Packetwave Platform. |

[0000936395-18-000024:mdna:67]
| • | Software and Software-Related Services segment revenue slightly increased, primarily reflecting a sales increase of $1.6 million in software-related services. |

[0000936395-18-000024:mdna:68]
| • | Global Services segment revenue slightly increased, primarily reflecting a sales increase of $2.7 million of our maintenance support and training services. |

[0000936395-18-000024:mdna:69]
Our operating segments each engage in business and operations across four geographic regions: North America; Europe, Middle East and Africa ("EMEA"); Caribbean and Latin America (“CALA”); and Asia and Pacific ("APAC"). Results for North America include only activities in the U.S. and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as the APAC region. We believe that this is an important part of our strategy, and that it is required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The revenue increase from our EMEA region for the second quarter of fiscal 2018 was primarily driven by increased sales to communications service provider and Web-scale customers. The revenue increase from our APAC region for the second quarter of fiscal 2018 was primarily driven by increased sales in India and continued execution of our strategy to capture new market share with communications service providers in the region. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000024:mdna:70]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| North America | $ | 431,235 |  |  | 59.1 |  | $ | 424,373 |  |  | 60.0 |  | $ | 6,862 |  |  | 1.6 |  |
| EMEA | 121,747 |  |  | 16.7 |  | 105,776 |  |  | 15.0 |  | 15,971 |  |  | 15.1 |  |
| CALA | 25,080 |  |  | 3.4 |  | 33,971 |  |  | 4.8 |  | (8,891 | ) |  | (26.2 | ) |
| APAC | 151,916 |  |  | 20.8 |  | 142,902 |  |  | 20.2 |  | 9,014 |  |  | 6.3 |  |
| Total | $ | 729,978 |  |  | 100.0 |  | $ | 707,022 |  |  | 100.0 |  | $ | 22,956 |  |  | 3.2 |  |

[0000936395-18-000024:mdna:71]
[same as prior period, unchanged from 0000936395-18-000013:mdna:67]

[0000936395-18-000024:mdna:72]
[same as prior period, unchanged from 0000936395-18-000013:mdna:68]

[0000936395-18-000024:mdna:73]
[same as prior period, unchanged from 0000936395-18-000013:mdna:69]

[0000936395-18-000024:mdna:74]
| • | North America revenue primarily reflects increases of $5.9 million within our Networking Platforms segment and $3.9 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $3.0 million within our Global Services segment. |

[0000936395-18-000024:mdna:75]
| ◦ | Networking Platforms revenue primarily reflects a product line increase of $26.4 million of Converged Packet Optical sales, partially offset by a product line decrease of $20.5 million of Packet Networking sales. |

[0000936395-18-000024:mdna:76]
| ▪ | The revenue increase within Converged Packet Optical sales primarily reflects an increase of $65.0 million in sales of our Waveserver stackable interconnect system, partially offset by a revenue decrease in sales of $34.1 million of our 6500 Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. |

[0000936395-18-000024:mdna:77]
| ▪ | The revenue decrease within Packet Networking primarily reflects a decrease of $19.6 million in sales of our 3000 and 5000 families of service delivery and aggregation switches. Packet Networking sales primarily reflect reduced sales to AT&T. |

[0000936395-18-000024:mdna:78]
| • | EMEA revenue primarily reflects increases of $10.4 million within our Networking Platforms segment and $7.5 million within our Global Services segment, partially offset by a revenue decrease of $1.9 million within our Software and Software-Related Services segment. |

[0000936395-18-000024:mdna:79]
30

[0000936395-18-000024:mdna:80]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $12.6 million in Converged Packet Optical sales. The increase in Converged Packet Optical sales primarily reflects an increase of $6.8 million in sales from our Waveserver stackable interconnect system, primarily due to increased sales to Web-scale providers, and $3.4 million in sales of our 6500 Packet-Optical Platform which was primarily due to increased sales to communications service providers. |

[0000936395-18-000024:mdna:81]
| • | CALA revenue primarily reflects decreases of $8.3 million within our Networking Platforms segment and $1.0 million within our Global Services segment. The decrease in CALA revenue primarily relates to decreased sales to a certain cable and multiservice operator in Argentina. |

[0000936395-18-000024:mdna:82]
| • | APAC revenue primarily reflects an increase of $12.2 million within our Networking Platforms segment, partially offset by revenue decreases of $1.7 million within our Global Services segment and $1.5 million within our Software and Software-Related Services segment. |

[0000936395-18-000024:mdna:83]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $19.8 million of Packet Networking sales, partially offset by a product line decrease of $7.6 million in Converged Packet Optical sales. |

[0000936395-18-000024:mdna:84]
| ▪ | Converged Packet Optical revenue primarily reflects a decrease of $20.2 million in sales of our 5410/5430 Reconfigurable Switching Systems primarily due to decreased sales to a certain communications service provider in India. This decrease was partially offset by a revenue increase of $10.7 million in sales of our 6500 Packet-Optical Platform to communications service providers. |

[0000936395-18-000024:mdna:85]
| ▪ | Packet Networking revenue primarily reflects increases of $11.2 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $8.6 million in sales of our 8700 Packetwave Platform primarily due to increased sales to a certain communication service provider in India. |

[0000936395-18-000024:mdna:86]
[same as prior period, unchanged from 0000936395-18-000013:mdna:70]

[0000936395-18-000024:mdna:87]
[same as prior period, unchanged from 0000936395-18-000013:mdna:71]

[0000936395-18-000024:mdna:88]
[same as prior period, unchanged from 0000936395-18-000013:mdna:72]

[0000936395-18-000024:mdna:89]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending upon our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. When we have success in taking share and winning new business, it can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. These early stages often include an increased concentration of lower margin “common” equipment sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms for existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-18-000024:mdna:90]
[same as prior period, unchanged from 0000936395-18-000013:mdna:75]

[0000936395-18-000024:mdna:91]
[same as prior period, unchanged from 0000936395-18-000013:mdna:76]

[0000936395-18-000024:mdna:92]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 729,978 |  |  | 100.0 |  | $ | 707,022 |  |  | 100.0 |  | $ | 22,956 |  |  | 3.2 |  |
| Total cost of goods sold | 436,671 |  |  | 59.8 |  | 388,782 |  |  | 55.0 |  | 47,889 |  |  | 12.3 |  |
| Gross profit | $ | 293,307 |  |  | 40.2 |  | $ | 318,240 |  |  | 45.0 |  | $ | (24,933 | ) |  | (7.8 | ) |

[0000936395-18-000024:mdna:93]
[same as prior period, unchanged from 0000936395-18-000013:mdna:78]

[0000936395-18-000024:mdna:94]
[same as prior period, unchanged from 0000936395-18-000013:mdna:79]

[0000936395-18-000024:mdna:95]
[same as prior period, unchanged from 0000936395-18-000013:mdna:80]

[0000936395-18-000024:mdna:96]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 604,226 |  |  | 100.0 |  | $ | 584,630 |  |  | 100.0 |  | $ | 19,596 |  |  | 3.4 |  |
| Product cost of goods sold | 372,568 |  |  | 61.7 |  | 327,295 |  |  | 56.0 |  | 45,273 |  |  | 13.8 |  |
| Product gross profit | $ | 231,658 |  |  | 38.3 |  | $ | 257,335 |  |  | 44.0 |  | $ | (25,677 | ) |  | (10.0 | ) |

[0000936395-18-000024:mdna:97]
[same as prior period, unchanged from 0000936395-18-000013:mdna:82]

[0000936395-18-000024:mdna:98]
[same as prior period, unchanged from 0000936395-18-000013:mdna:83]

[0000936395-18-000024:mdna:99]
[same as prior period, unchanged from 0000936395-18-000013:mdna:84]

[0000936395-18-000024:mdna:100]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 125,752 |  |  | 100.0 |  | $ | 122,392 |  |  | 100.0 |  | $ | 3,360 |  |  | 2.7 |
| Service cost of goods sold | 64,103 |  |  | 51.0 |  | 61,487 |  |  | 50.2 |  | 2,616 |  |  | 4.3 |
| Service gross profit | $ | 61,649 |  |  | 49.0 |  | $ | 60,905 |  |  | 49.8 |  | $ | 744 |  |  | 1.2 |

[0000936395-18-000024:mdna:101]
[same as prior period, unchanged from 0000936395-18-000013:mdna:86]

[0000936395-18-000024:mdna:102]
[same as prior period, unchanged from 0000936395-18-000013:mdna:87]

[0000936395-18-000024:mdna:103]
[same as prior period, unchanged from 0000936395-18-000013:mdna:88]

[0000936395-18-000024:mdna:104]
| • | Gross profit as a percentage of revenue reflects reduced product and services gross profit as described below. We expect to encounter fluctuations or reductions in quarterly gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Our success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-18-000024:mdna:105]
| • | Gross profit on products as a percentage of product revenue decreased primarily as a result of the share capture strategy as described above and the impact of early stages of network deployments with service provider customers, including an increased concentration of lower margin “common” equipment sales, partially offset by product cost reductions and a lower provision for inventory excess and obsolescence. |

[0000936395-18-000024:mdna:106]
| • | Gross profit on services as a percentage of services revenue slightly decreased primarily due to reduced margin on deployment sales. |

[0000936395-18-000024:mdna:107]
[same as prior period, unchanged from 0000936395-18-000013:mdna:93]

[0000936395-18-000024:mdna:108]
[same as prior period, unchanged from 0000936395-18-000013:mdna:94]

[0000936395-18-000024:mdna:109]
[same as prior period, unchanged from 0000936395-18-000013:mdna:95]

[0000936395-18-000024:mdna:110]
[same as prior period, unchanged from 0000936395-18-000013:mdna:96]

[0000936395-18-000024:mdna:111]
[same as prior period, unchanged from 0000936395-18-000013:mdna:97]

[0000936395-18-000024:mdna:112]
[same as prior period, unchanged from 0000936395-18-000013:mdna:98]

[0000936395-18-000024:mdna:113]
[same as prior period, unchanged from 0000936395-18-000013:mdna:99]

[0000936395-18-000024:mdna:114]
| • | Significant asset impairments and restructuring costs primarily reflect actions we have taken to better align our workforce, facilities, and operating costs with perceived market opportunities, business strategies, changes in market and business conditions and significant impairments of assets. |

[0000936395-18-000024:mdna:115]
During the second quarter of fiscal 2018, approximately 48.0% of our operating expense was non-U.S. Dollar denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees, Euros, and Brazilian Reais. During the second quarter of fiscal 2018 as compared to the second quarter of fiscal 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $6.6 million, or 2.5%, as compared to the second quarter of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000024:mdna:116]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 116,924 |  |  | 16.0 |  | $ | 121,623 |  |  | 17.2 |  | $ | (4,699 | ) |  | (3.9 | ) |
| Selling and marketing | 97,359 |  |  | 13.3 |  | 88,551 |  |  | 12.5 |  | 8,808 |  |  | 9.9 |  |
| General and administrative | 38,976 |  |  | 5.3 |  | 34,990 |  |  | 4.9 |  | 3,986 |  |  | 11.4 |  |
| Amortization of intangible assets | 3,623 |  |  | 0.5 |  | 10,980 |  |  | 1.6 |  | (7,357 | ) |  | (67.0 | ) |
| Significant asset impairments and restructuring costs | 4,359 |  |  | 0.6 |  | 4,276 |  |  | 0.6 |  | 83 |  |  | 1.9 |  |
| Total operating expenses | $ | 261,241 |  |  | 35.7 |  | $ | 260,420 |  |  | 36.8 |  | $ | 821 |  |  | 0.3 |  |

[0000936395-18-000024:mdna:117]
[same as prior period, unchanged from 0000936395-18-000013:mdna:103]

[0000936395-18-000024:mdna:118]
[same as prior period, unchanged from 0000936395-18-000013:mdna:104]

[0000936395-18-000024:mdna:119]
[same as prior period, unchanged from 0000936395-18-000013:mdna:105]

[0000936395-18-000024:mdna:120]
| • | Research and development expense was adversely affected by $2.9 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses decreased by $4.7 million. This decrease primarily reflects the benefit of $8.1 million in reimbursements from the ENCQOR grant. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information regarding this grant and Ciena's expectations of a reduction in the quarterly benefit to research and development expense as compared to the second quarter of fiscal 2018. Research and development expense also reflects a decrease of $2.9 million in prototype expense. These decreases were partially offset by increases of $2.6 million in employee and compensation costs and $2.6 million in professional services. |

[0000936395-18-000024:mdna:121]
| • | Selling and marketing expense was adversely affected by $3.1 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, selling and marketing expenses increased by $8.8 million, primarily reflecting increases of $7.0 million in employee and compensation costs and $1.3 million in customer demonstration equipment. |

[0000936395-18-000024:mdna:122]
| • | General and administrative expense increased by $4.0 million, primarily reflecting increases of $2.6 million of employee and compensation costs and $1.0 million of professional services and legal fees. |

[0000936395-18-000024:mdna:123]
[same as prior period, unchanged from 0000936395-18-000013:mdna:109]

[0000936395-18-000024:mdna:124]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. |

[0000936395-18-000024:mdna:125]
33

[0000936395-18-000024:mdna:126]
[same as prior period, unchanged from 0000936395-18-000013:mdna:111]

[0000936395-18-000024:mdna:127]
[same as prior period, unchanged from 0000936395-18-000013:mdna:112]

[0000936395-18-000024:mdna:128]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 1,296 |  |  | 0.2 |  | $ | (2,918 | ) |  | (0.4 | ) |  | $ | 4,214 |  |  | (144.4 | ) |
| Interest expense | $ | 13,031 |  |  | 1.8 |  | $ | 13,308 |  |  | 1.9 |  |  | $ | (277 | ) |  | (2.1 | ) |
| Provision for income taxes | $ | 6,475 |  |  | 0.9 |  | $ | 3,568 |  |  | 0.5 |  |  | $ | 2,907 |  |  | 81.5 |  |

[0000936395-18-000024:mdna:129]
[same as prior period, unchanged from 0000936395-18-000013:mdna:114]

[0000936395-18-000024:mdna:130]
[same as prior period, unchanged from 0000936395-18-000013:mdna:115]

[0000936395-18-000024:mdna:131]
[same as prior period, unchanged from 0000936395-18-000013:mdna:116]

[0000936395-18-000024:mdna:132]
| • | Interest and other income (loss), net primarily reflects $2.9 million in debt modification expenses related to the 2022 Term Loan in the second quarter of fiscal 2017 and a $1.7 million gain in interest income due to higher interest rates on our investments in the second quarter of fiscal 2018. |

[0000936395-18-000024:mdna:133]
| • | Interest expense remained relatively unchanged. |

[0000936395-18-000024:mdna:134]
| • | Provision for income taxes increased primarily due to higher U.S. federal income tax. |

[0000936395-18-000024:mdna:135]
Six months ended April 30, 2018 compared to the six months ended April 30, 2017

[0000936395-18-000024:mdna:136]
Revenue

[0000936395-18-000024:mdna:137]
During the six months ended April 30, 2018, approximately 19.7% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Canadian Dollars, Japanese Yen, Brazilian Reais, British Pounds, Emirati Dirham, Argentina Pesos, Indian Rupees and Mexican Pesos. During the six months ended April 30, 2018, as compared to the six months ended April 30, 2017, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $11.4 million, net of hedging, or 0.8%, as compared to the six months ended April 30, 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-18-000024:mdna:138]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 955,297 |  |  | 69.4 |  | $ | 922,911 |  |  | 69.5 |  | $ | 32,386 |  |  | 3.5 |  |
| Packet Networking | 132,418 |  |  | 9.6 |  | 138,520 |  |  | 10.4 |  | (6,102 | ) |  | (4.4 | ) |
| Total Networking Platforms | 1,087,715 |  |  | 79.0 |  | 1,061,431 |  |  | 79.9 |  | 26,284 |  |  | 2.5 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 42,120 |  |  | 3.1 |  | 30,192 |  |  | 2.3 |  | 11,928 |  |  | 39.5 |  |
| Software-Related Services | 50,112 |  |  | 3.6 |  | 46,904 |  |  | 3.5 |  | 3,208 |  |  | 6.8 |  |
| Total Software and Software-Related Services | 92,232 |  |  | 6.7 |  | 77,096 |  |  | 5.8 |  | 15,136 |  |  | 19.6 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 116,862 |  |  | 8.5 |  | 113,231 |  |  | 8.5 |  | 3,631 |  |  | 3.2 |  |
| Installation and Deployment | 58,225 |  |  | 4.2 |  | 56,614 |  |  | 4.3 |  | 1,611 |  |  | 2.8 |  |
| Consulting and Network Design | 21,079 |  |  | 1.6 |  | 20,147 |  |  | 1.5 |  | 932 |  |  | 4.6 |  |
| Total Global Services | 196,166 |  |  | 14.3 |  | 189,992 |  |  | 14.3 |  | 6,174 |  |  | 3.2 |  |
| Consolidated revenue | $ | 1,376,113 |  |  | 100.0 |  | $ | 1,328,519 |  |  | 100.0 |  | $ | 47,594 |  |  | 3.6 |  |

[0000936395-18-000024:mdna:139]
_____________________________

[0000936395-18-000024:mdna:140]
*    Denotes % of total revenue

[0000936395-18-000024:mdna:141]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:142]
| • | Networking Platforms segment revenue increased, primarily reflecting a product line sales increase of $32.4 million of our Converged Packet Optical products partially offset by a product line decrease of $6.1 million of our Packet Networking products. |

[0000936395-18-000024:mdna:143]
| ◦ | Converged Packet Optical sales primarily reflect a sales increase of $124.8 million of our Waveserver stackable interconnect system, primarily due to increased sales to Web-scale providers, which, as we continue to diversify, represent a growing portion of our business. This increase was partially offset by sales decreases of $61.5 million of our 6500 Packet-Optical Platform, $16.2 million of our 5410/5430 Reconfigurable Switching Systems and $10.0 million of our Z-Series Packet-Optical Platform. The decreases in sales of our 6500 Packet-Optical Platform are primarily due to decreased sales to cable and multiservice operators, AT&T and government customers. |

[0000936395-18-000024:mdna:144]
| ◦ | Packet Networking sales primarily reflect a sales decrease of $17.0 million of our 3000 and 5000 families of service delivery and aggregation switches, partially offset by a sales increase of $7.9 million of our 8700 Packetwave Platform. |

[0000936395-18-000024:mdna:145]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $11.9 million of our software platforms and $3.2 million in software-related services platforms. The increase in software platform sales primarily reflects increases of $13.9 million in sales of our Blue Planet software platform and advanced software applications. |

[0000936395-18-000024:mdna:146]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $3.6 million of our maintenance support and training services, $1.6 million of our installation and deployment services and $0.9 million of our consulting and network design services. |

[0000936395-18-000024:mdna:147]
The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The revenue increase from our APAC

[0000936395-18-000024:mdna:148]
35

[0000936395-18-000024:mdna:149]
region for the six months ended April 30, 2018 was primarily driven by increased sales in India and Japan and our continued execution of our strategy to capture new market share with communications service providers in the region. The revenue increase from our EMEA region for the six months ended April 30, 2018 was primarily driven by increased sales to communications service provider and Web-scale customers. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-18-000024:mdna:150]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| North America | $ | 834,144 |  |  | 60.6 |  | $ | 830,301 |  |  | 62.5 |  | $ | 3,843 |  |  | 0.5 |  |
| EMEA | 219,581 |  |  | 16.0 |  | 197,319 |  |  | 14.9 |  | 22,262 |  |  | 11.3 |  |
| CALA | 59,643 |  |  | 4.3 |  | 69,117 |  |  | 5.2 |  | (9,474 | ) |  | (13.7 | ) |
| APAC | 262,745 |  |  | 19.1 |  | 231,782 |  |  | 17.4 |  | 30,963 |  |  | 13.4 |  |
| Total | $ | 1,376,113 |  |  | 100.0 |  | $ | 1,328,519 |  |  | 100.0 |  | $ | 47,594 |  |  | 3.6 |  |

[0000936395-18-000024:mdna:151]
[same as prior period, unchanged from 0000936395-18-000013:mdna:124]

[0000936395-18-000024:mdna:152]
*    Denotes % of total revenue

[0000936395-18-000024:mdna:153]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:154]
| • | North America revenue primarily reflects an increase of $17.3 million within our Software and Software-Related Services segment, partially offset by revenue decreases of $11.0 million within our Networking Platforms segment and $2.4 million within our Global Services segment. |

[0000936395-18-000024:mdna:155]
| ◦ | Networking Platforms revenue primarily reflects a product line decrease of $25.9 million of Packet Networking sales, partially offset by a product line increase of $14.9 million of Converged Packet Optical sales. |

[0000936395-18-000024:mdna:156]
| ▪ | The revenue increase within Converged Packet Optical sales primarily reflects an increase of $107.5 million in sales of our Waveserver stackable interconnect system, partially offset by decreases in sales of $73.8 million of our 6500 Packet-Optical Platform, $9.4 million of our 5410/5430 Reconfigurable Switching Systems and $7.5 million of our Z-Series Packet-Optical Platform. The revenue increase for our Waveserver stackable interconnect system primarily reflects increased sales to Web-scale providers. |

[0000936395-18-000024:mdna:157]
| ▪ | The revenue decrease within Packet Networking primarily reflects a decrease of $25.0 million in sales of our 3000 and 5000 families of service delivery and aggregation switches. Packet Networking sales primarily reflect reduced sales to AT&T. |

[0000936395-18-000024:mdna:158]
| • | EMEA revenue primarily reflects increases of $12.3 million within our Networking Platforms segment and $12.0 million within our Global Services segment, partially offset by a revenue decrease of $2.0 million within our Software and Software-Related Services segment. |

[0000936395-18-000024:mdna:159]
| ◦ | Networking Platforms segment revenue primarily reflects a product line increase of $16.3 million in Converged Packet Optical sales. The increase in Converged Packet Optical sales primarily reflects an increase of $13.4 million in sales from our Waveserver stackable interconnect system to Web-scale providers. |

[0000936395-18-000024:mdna:160]
| ◦ | Global Services segment revenue primarily reflects increases of $6.2 million for our installation and deployment services and $4.8 million for our maintenance and training support services. These increases reflect increased sales to communications service providers. |

[0000936395-18-000024:mdna:161]
| • | CALA revenue primarily reflects decreases of $8.0 million within our Networking Platforms segment and $2.1 million within our Global Services segment. The decrease in CALA revenue primarily relates to decreased sales to a certain cable and multiservice operator in Argentina and certain communications service providers in Mexico. |

[0000936395-18-000024:mdna:162]
| • | APAC revenue primarily reflects an increase of $33.0 million within our Networking Platforms segment, partially offset by a revenue decrease of $1.3 million within our Global Services segment. |

[0000936395-18-000024:mdna:163]
| ◦ | Networking Platforms segment revenue primarily reflects product line increases of $23.3 million of Packet Networking sales and $9.7 million in Converged Packet Optical sales. |

[0000936395-18-000024:mdna:164]
| ▪ | Converged Packet Optical revenue primarily reflects increases of $16.4 million in sales of our 6500 Packet-Optical Platform and $3.9 million in sales of our Waveserver stackable interconnect system, both reflecting increased sales to communications service providers. These increases were partially |

[0000936395-18-000024:mdna:165]
offset by a revenue decrease of $7.6 million in sales of our 5410/5430 Reconfigurable Switching Systems primarily due to decreased sales to certain communications service providers.

[0000936395-18-000024:mdna:166]
| ▪ | Packet Networking revenue primarily reflects increases of $13.0 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $9.9 million in sales of our 8700 Packetwave Platform primarily due to increased sales to a certain communication service provider in India. |

[0000936395-18-000024:mdna:167]
Cost of Goods Sold and Gross Profit

[0000936395-18-000024:mdna:168]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-18-000024:mdna:169]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,376,113 |  |  | 100.0 |  | $ | 1,328,519 |  |  | 100.0 |  | $ | 47,594 |  |  | 3.6 |  |
| Total cost of goods sold | 811,041 |  |  | 58.9 |  | 736,494 |  |  | 55.4 |  | 74,547 |  |  | 10.1 |  |
| Gross profit | $ | 565,072 |  |  | 41.1 |  | $ | 592,025 |  |  | 44.6 |  | $ | (26,953 | ) |  | (4.6 | ) |

[0000936395-18-000024:mdna:170]
_____________________________________

[0000936395-18-000024:mdna:171]
*    Denotes % of total revenue

[0000936395-18-000024:mdna:172]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:173]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,129,835 |  |  | 100.0 |  | $ | 1,091,623 |  |  | 100.0 |  | $ | 38,212 |  |  | 3.5 |  |
| Product cost of goods sold | 685,688 |  |  | 60.7 |  | 614,106 |  |  | 56.3 |  | 71,582 |  |  | 11.7 |  |
| Product gross profit | $ | 444,147 |  |  | 39.3 |  | $ | 477,517 |  |  | 43.7 |  | $ | (33,370 | ) |  | (7.0 | ) |

[0000936395-18-000024:mdna:174]
_____________________________________

[0000936395-18-000024:mdna:175]
*    Denotes % of product revenue

[0000936395-18-000024:mdna:176]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:177]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 246,278 |  |  | 100.0 |  | $ | 236,896 |  |  | 100.0 |  | $ | 9,382 |  |  | 4.0 |
| Service cost of goods sold | 125,353 |  |  | 50.9 |  | 122,388 |  |  | 51.7 |  | 2,965 |  |  | 2.4 |
| Service gross profit | $ | 120,925 |  |  | 49.1 |  | $ | 114,508 |  |  | 48.3 |  | $ | 6,417 |  |  | 5.6 |

[0000936395-18-000024:mdna:178]
_____________________________________

[0000936395-18-000024:mdna:179]
*    Denotes % of services revenue

[0000936395-18-000024:mdna:180]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:181]
| • | Gross profit as a percentage of revenue reflects reduced product gross profit partially offset by improved services gross profit. We expect to encounter fluctuations or reductions in quarterly gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. Our success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-18-000024:mdna:182]
| • | Gross profit on products as a percentage of product revenue decreased, primarily as a result of the share capture strategy as described above and the impact of early stages of international network deployments with communications service provider customers, including an increased concentration of lower margin “common” equipment sales, partially offset by product cost reductions and increased software platform sales. |

[0000936395-18-000024:mdna:183]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to sales of higher margin maintenance support services. |

[0000936395-18-000024:mdna:184]
Operating Expense

[0000936395-18-000024:mdna:185]
During the first six months of fiscal 2018, approximately 50.7% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, British Pounds, Euros, Indian Rupees and Australian Dollars. During the first six months of fiscal 2018 as compared to the first six months of fiscal 2017, the U.S. Dollar fluctuated against these currencies.  Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $12.8 million, or 2.5%, as compared to the first six months of fiscal 2017, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-18-000024:mdna:186]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 235,448 |  |  | 17.1 |  | $ | 238,492 |  |  | 18.0 |  | $ | (3,044 | ) |  | (1.3 | ) |
| Selling and marketing | 185,874 |  |  | 13.5 |  | 173,553 |  |  | 13.1 |  | 12,321 |  |  | 7.1 |  |
| General and administrative | 77,382 |  |  | 5.6 |  | 70,854 |  |  | 5.3 |  | 6,528 |  |  | 9.2 |  |
| Amortization of intangible assets | 7,246 |  |  | 0.5 |  | 25,531 |  |  | 1.9 |  | (18,285 | ) |  | (71.6 | ) |
| Significant asset impairments and restructuring costs | 10,320 |  |  | 0.7 |  | 6,671 |  |  | 0.5 |  | 3,649 |  |  | 54.7 |  |
| Total operating expenses | $ | 516,270 |  |  | 37.4 |  | $ | 515,101 |  |  | 38.8 |  | $ | 1,169 |  |  | 0.2 |  |

[0000936395-18-000024:mdna:187]
_____________________________________

[0000936395-18-000024:mdna:188]
*    Denotes % of total revenue

[0000936395-18-000024:mdna:189]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:190]
| • | Research and development expense was adversely affected by $6.3 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses decreased by $3.0 million. This decrease primarily reflects a benefit of $8.1 million for the ENCQOR grant reimbursement as discussed above and a decrease of $2.1 million in prototype expense. These decreases were partially offset by increases of $5.8 million in employee and compensation costs and $1.6 million in professional services. |

[0000936395-18-000024:mdna:191]
| • | Selling and marketing expense was adversely affected by $5.5 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $12.3 million, primarily reflecting increases of $8.8 million in employee and compensation costs, $1.3 million in selling and marketing costs, $1.3 million in travel and entertainment expenses and $1.0 million in customer demonstration equipment. |

[0000936395-18-000024:mdna:192]
| • | General and administrative expense increased by $6.5 million, primarily reflecting increases of $2.7 million in employee and compensation costs and $2.9 million for professional services and legal fees. |

[0000936395-18-000024:mdna:193]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-18-000024:mdna:194]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes. |

[0000936395-18-000024:mdna:195]
Other items

[0000936395-18-000024:mdna:196]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-18-000024:mdna:197]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2018 |  | %* |  | 2017 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 2,871 |  |  | 0.2 |  | $ | (2,548 | ) |  | (0.2 | ) |  | $ | 5,419 |  |  | 212.7 |  |
| Interest expense | $ | 26,765 |  |  | 1.9 |  | $ | 28,511 |  |  | 2.1 |  |  | $ | (1,746 | ) |  | (6.1 | ) |
| Provision for income taxes | $ | 484,415 |  |  | 35.2 |  | $ | 3,978 |  |  | 0.3 |  |  | $ | 480,437 |  |  | n/a |  |

[0000936395-18-000024:mdna:198]
_____________________________________

[0000936395-18-000024:mdna:199]
*    Denotes % of total revenue

[0000936395-18-000024:mdna:200]
**    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:201]
n/a           Not meaningful

[0000936395-18-000024:mdna:202]
| • | Interest and other income (loss), net primarily reflects a $2.9 million gain in interest income due to higher interest rates on our investments in the second quarter of fiscal 2018 and $2.9 million in debt modification expenses related to the 2022 Term Loan in the second quarter of fiscal 2017. |

[0000936395-18-000024:mdna:203]
[same as prior period, unchanged from 0000936395-18-000013:mdna:119]

[0000936395-18-000024:mdna:204]
[same as prior period, unchanged from 0000936395-18-000013:mdna:120]

[0000936395-18-000024:mdna:205]
[same as prior period, unchanged from 0000936395-18-000013:mdna:121]

[0000936395-18-000024:mdna:206]
[same as prior period, unchanged from 0000936395-18-000013:mdna:122]

[0000936395-18-000024:mdna:207]
|  | Quarter Ended April 30, |  |  |  |
|  | 2018 |  | 2017 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 126,823 |  |  | $ | 150,464 |  |  | $ | (23,641 | ) |  | (15.7 | ) |
| Software and Software-Related Services | $ | 8,276 |  |  | $ | 4,551 |  |  | $ | 3,725 |  |  | 81.9 |  |
| Global Services | $ | 41,284 |  |  | $ | 41,602 |  |  | $ | (318 | ) |  | (0.8 | ) |

[0000936395-18-000024:mdna:208]
_____________________________________

[0000936395-18-000024:mdna:209]
[same as prior period, unchanged from 0000936395-18-000013:mdna:125]

[0000936395-18-000024:mdna:210]
| • | Networking Platforms segment profit decreased, primarily due to reduced gross margin as described above, partially offset by higher sales volume. |

[0000936395-18-000024:mdna:211]
| • | Software and Software-Related Services segment profit increased, primarily due to lower research and development costs. |

[0000936395-18-000024:mdna:212]
| • | Global Services segment profit remained relatively unchanged. |

[0000936395-18-000024:mdna:213]
|  | Six Months Ended April 30, |  |  |  |  |
|  | 2018 |  | 2017 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 215,392 |  |  | $ | 264,210 |  |  | $ | (48,818 | ) |  | (18.5 | ) |
| Software and Software-Related Services | $ | 31,911 |  |  | $ | 12,252 |  |  | $ | 19,659 |  |  | 160.5 |  |
| Global Services | $ | 82,321 |  |  | $ | 77,071 |  |  | $ | 5,250 |  |  | 6.8 |  |

[0000936395-18-000024:mdna:214]
_____________________________________

[0000936395-18-000024:mdna:215]
*    Denotes % change from 2017 to 2018

[0000936395-18-000024:mdna:216]
[same as prior period, unchanged from 0000936395-18-000013:mdna:126]

[0000936395-18-000024:mdna:217]
| • | Software and Software-Related Services segment profit increased, primarily due to higher sales volume, as described above, and lower research and development costs. |

[0000936395-18-000024:mdna:218]
| • | Global Services segment profit increased, primarily due to increased sales of higher margin maintenance support services. |

[0000936395-18-000024:mdna:219]
[same as prior period, unchanged from 0000936395-18-000013:mdna:129]

[0000936395-18-000024:mdna:220]
For the six months ended April 30, 2018, we generated $73.1 million in cash to fund our operating needs, as our net loss (adjusted for non-cash charges) of $139.8 million exceeded our working capital requirements of $66.7 million. Our net loss (adjusted for non-cash charges) reflects a non-cash tax provision of $481.4 million primarily related to the enactment of the Tax Act. For additional information on the non-cash tax provision, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. For additional details on our cash from operations, see the discussion below entitled “Cash from Operations.”

[0000936395-18-000024:mdna:221]
Cash, cash equivalents and investments increased by $10.1 million during the first six months of fiscal 2018. In addition to the cash from operations mentioned above, proceeds from issuance of equity under our employee stock purchase plans provided $11.8 million in cash during the period. These provisions were sufficient to fund our investing activities for capital expenditures totaling $31.9 million and our other financing activities, including our new stock repurchase program described below and in Note 14 and Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, which totaled $38.0 million in the period.

[0000936395-18-000024:mdna:222]
|  | April 30, 2018 |  | October 31, 2017 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 652,096 |  |  | $ | 640,513 |  |  | $ | 11,583 |  |
| Short-term investments in marketable debt securities | 268,584 |  |  | 279,133 |  |  | (10,549 | ) |
| Long-term investments in marketable debt securities | 58,895 |  |  | 49,783 |  |  | 9,112 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 979,575 |  |  | $ | 969,429 |  |  | $ | 10,146 |  |

[0000936395-18-000024:mdna:223]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of April 30, 2018 totaled $979.6 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the "ABL Credit Facility"). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of April 30, 2018, letters of credit totaling $61.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2018.

[0000936395-18-000024:mdna:224]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $56.9 million as of April 30, 2018. Our accumulated historical foreign earnings are generally held in either cash or short-term intercompany receivables, or have been used to fund investments in equipment, building, furniture and fixtures, or other assets and liabilities of our foreign operations. We currently intend to reinvest indefinitely our foreign earnings, however, we intend to study further the changes resulting from the enactment of the Tax Act, the costs of repatriation of such foreign earnings, and the current and future cash needs of our foreign operations to determine whether there is an opportunity to repatriate these earnings in the future on a tax-efficient basis. If we determine to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $24.0 million. See Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000024:mdna:225]
Intent to Cash Settle New 2018 Convertible Notes. Our $350 million in aggregate principal amount outstanding in 3.75% Convertible Senior Notes will mature on October 15, 2018. As more fully described in Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, following the settlement of an exchange offer on August 2, 2017, approximately $288.7 million in aggregate principal amount at maturity of Original Notes were exchanged for New Notes, which provide us with the option, at our election, to settle conversions for cash, shares of our common stock, or a combination of cash and shares. It is our current intent that upon any conversion of the New Notes we will settle the principal amount thereof in cash.

[0000936395-18-000024:mdna:226]
Stock Repurchase Authorization. On December 7, 2017, we announced that our Board of Directors authorized a program to repurchase up to $300 million of our outstanding common stock through the end of fiscal 2020. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. As of June 4, 2018 an aggregate of $245.5 million of authorized funds remained under this repurchase program. For additional information, including our repurchase activities under the program, see Note 14 and Note 18 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-18-000024:mdna:227]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We

[0000936395-18-000024:mdna:228]
regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-18-000024:mdna:229]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations, including the settlement of the principal amount of the New Notes in cash upon any conversions prior to maturity, and the repayment at maturity of the $350 million in aggregate principal remaining outstanding on our 3.75% convertible senior notes due October 15, 2018, through at least the next 12 months.

[0000936395-18-000024:mdna:230]
[same as prior period, unchanged from 0000936395-18-000013:mdna:140]

[0000936395-18-000024:mdna:231]
The following sections set forth the components of our $73.1 million of cash generated from operating activities during the first six months of fiscal 2018:

[0000936395-18-000024:mdna:232]
[same as prior period, unchanged from 0000936395-18-000013:mdna:142]

[0000936395-18-000024:mdna:233]
[same as prior period, unchanged from 0000936395-18-000013:mdna:143]

[0000936395-18-000024:mdna:234]
|  | Six months ended |
|  | April 30, 2018 |
| Net loss | $ | (459,507 | ) |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 41,400 |  |
| Share-based compensation costs | 26,559 |  |
| Amortization of intangible assets | 11,824 |  |
| Deferred tax provision | 481,401 |  |
| Provision for inventory excess and obsolescence | 14,977 |  |
| Provision for warranty | 10,565 |  |
| Other | 12,645 |  |
| Net loss (adjusted for non-cash charges) | $ | 139,864 |  |

[0000936395-18-000024:mdna:235]
[same as prior period, unchanged from 0000936395-18-000013:mdna:145]

[0000936395-18-000024:mdna:236]
We used $66.7 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-18-000024:mdna:237]
|  | Six months ended |
|  | April 30, 2018 |
| Cash used in accounts receivable | $ | (28,055 | ) |
| Cash provided by inventories | 20,420 |  |
| Cash provided by prepaid expenses and other | 2,623 |  |
| Cash used in accounts payable, accruals and other obligations | (55,986 | ) |
| Cash used in deferred revenue | (5,736 | ) |
| Total cash used for working capital | $ | (66,734 | ) |

[0000936395-18-000024:mdna:238]
[same as prior period, unchanged from 0000936395-18-000013:mdna:148]

[0000936395-18-000024:mdna:239]
| • | The $28.1 million of cash used by accounts receivable during the first six months of fiscal 2018 reflects increased sales volume at the end of the second quarter of fiscal 2018; |

[0000936395-18-000024:mdna:240]
| • | The $20.4 million of cash provided by inventory during the first six months of fiscal 2018 primarily reflects improved manufacturing efficiencies to meet customer delivery schedules; |

[0000936395-18-000024:mdna:241]
| • | The $2.6 million of cash provided by prepaid expense and other during the first six months of fiscal 2018 primarily reflects lower prepaid value added taxes partially offset by the ENQCOR grant reimbursement receivable which was recorded in the second quarter of fiscal 2018. For more information on the ENQCOR grant, see Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report; |

[0000936395-18-000024:mdna:242]
| • | The $56.0 million of cash used in accounts payable, accruals and other obligations during the first six months of fiscal 2018 primarily reflects the timing of bonus payments to employees under our annual cash incentive compensation plan and payments for U.S. federal income taxes; and |

[0000936395-18-000024:mdna:243]
| • | The $5.7 million of cash used in deferred revenue during the first six months of fiscal 2018 represents a decrease in advanced payments received from customers prior to revenue recognition. |

[0000936395-18-000024:mdna:244]
Our days sales outstanding (DSOs) for the first six months of fiscal 2018 were 85 days, and our inventory turns for the first six months of fiscal 2018 were 5.9.

[0000936395-18-000024:mdna:245]
[same as prior period, unchanged from 0000936395-18-000013:mdna:155]

[0000936395-18-000024:mdna:246]
[same as prior period, unchanged from 0000936395-18-000013:mdna:156]

[0000936395-18-000024:mdna:247]
|  | Six months ended |
|  | April 30, 2018 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original)(1) | $ | 1,149 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New)(1) | 5,414 |  |
| 4.0% Convertible Senior Notes due December 15, 2020(2) | 3,750 |  |
| Term Loan due January 30, 2022 (3) | 8,015 |  |
| Interest rate swaps(4) | 523 |  |
| ABL Credit Facility(5) | 778 |  |
| Capital leases | 2,214 |  |
| Cash paid during period | $ | 21,843 |  |

[0000936395-18-000024:mdna:248]
| (1) | Interest on our outstanding 3.75% Convertible Senior Notes due October 15, 2018 (Original) and our outstanding 3.75% Convertible Senior Notes due October 15, 2018 (New) is payable on April 15 and October 15 of each year. |

[0000936395-18-000024:mdna:249]
| (2) | Interest on our outstanding 4.0% Convertible Senior Notes due December 15, 2020 is payable on June 15 and December 15 of each year. |

[0000936395-18-000024:mdna:250]
| (3) | Interest on the Term Loan due January 30, 2022 (the "2022 Term Loan") is payable periodically based on the underlying market index rate selected for borrowing. The 2022 Term Loan bears interest at LIBOR plus a spread of 2.5% subject to a minimum LIBOR rate of 0.75%. As of the end of the second quarter of fiscal 2018, the interest rate on the 2022 Term Loan was 4.40%. |

[0000936395-18-000024:mdna:251]
[same as prior period, unchanged from 0000936395-18-000013:mdna:161]

[0000936395-18-000024:mdna:252]
| (5) | During the first six months of fiscal 2018, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.8 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-18-000024:mdna:253]
[same as prior period, unchanged from 0000936395-18-000013:mdna:163]

[0000936395-18-000024:mdna:254]
[same as prior period, unchanged from 0000936395-18-000013:mdna:164]

[0000936395-18-000024:mdna:255]
[same as prior period, unchanged from 0000936395-18-000013:mdna:165]

[0000936395-18-000024:mdna:256]
[same as prior period, unchanged from 0000936395-18-000013:mdna:166]

[0000936395-18-000024:mdna:257]
[same as prior period, unchanged from 0000936395-18-000013:mdna:167]

[0000936395-18-000024:mdna:258]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the

[0000936395-18-000024:mdna:259]
circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-18-000024:mdna:260]
[same as prior period, unchanged from 0000936395-18-000013:mdna:170]

[0000936395-18-000024:mdna:261]
[same as prior period, unchanged from 0000936395-18-000013:mdna:171]

[0000936395-18-000024:mdna:262]
[same as prior period, unchanged from 0000936395-18-000013:mdna:172]

[0000936395-18-000024:mdna:263]
The valuation allowance balance at April 30, 2018 was $147.0 million and the corresponding net deferred tax asset was $734.8 million. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending upon our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For example, the recently enacted Tax Act required us to write down our net deferred tax asset by approximately $431.3 million. As this is a provisional estimate, it may be subject to change based upon availability of additional guidance and our continued assessment of the impact of the Tax Act on our business. As these amounts are finalized throughout fiscal 2018, our operating results may be materially adversely affected by a non-cash charge to reflect the change in value of these assets. For further discussion, see Note 5 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-18-000024:mdna:264]
[same as prior period, unchanged from 0000936395-18-000013:mdna:174]

[0000936395-18-000024:mdna:265]
[same as prior period, unchanged from 0000936395-18-000013:mdna:175]
