# CIEN 8-K — 0000936395-23-000030 filed 2023-08-31

## item codes, every 8-K on or before 2023-09-06

- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2023-09-06

- none on or before 2023-09-06

## item 2.02 — earnings release, exhibit 99.1

[0000936395-23-000030:8k_2_02:1]
EX-99.1
2
ex9912023q3earningspressre.htm
EX-99.1

[0000936395-23-000030:8k_2_02:2]
Document

[0000936395-23-000030:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-23-000030:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2023 Financial Results

[0000936395-23-000030:8k_2_02:5]
Revenue increased 23% year-over-year

[0000936395-23-000030:8k_2_02:6]
HANOVER, Md. - August 31, 2023 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal third quarter ended July 29, 2023.

[0000936395-23-000030:8k_2_02:7]
•Q3 Revenue: $1.07 billion

[0000936395-23-000030:8k_2_02:8]
•Q3 Net Income per Share: $0.20 GAAP; $0.59 adjusted (non-GAAP)

[0000936395-23-000030:8k_2_02:9]
•Share Repurchases: Repurchased approximately 1.4 million shares of common stock for an aggregate price of $61.2 million during the quarter.

[0000936395-23-000030:8k_2_02:10]
"We delivered excellent results for the fiscal third quarter with strength across all regions," said Gary Smith, president and CEO of Ciena. "We are encouraged by increased customer activity that, when combined with our elevated backlog, market leadership and expanding addressable market, we believe will drive growth and market share gains going forward."

[0000936395-23-000030:8k_2_02:11]
For fiscal third quarter 2023, Ciena reported revenue of $1.07 billion as compared to $868.0 million for the fiscal third quarter 2022.

[0000936395-23-000030:8k_2_02:12]
Ciena's GAAP net income for the fiscal third quarter 2023 was $29.7 million, or $0.20 per diluted common share, which compares to a GAAP net income of $10.5 million, or $0.07 per diluted common share, for the fiscal third quarter 2022.

[0000936395-23-000030:8k_2_02:13]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2023 was $89.1 million, or $0.59 per diluted common share, which compares to an adjusted (non-GAAP) net income of $49.0 million, or $0.33 per diluted common share, for the fiscal third quarter 2022.

[0000936395-23-000030:8k_2_02:14]
Fiscal Third Quarter 2023 Performance Summary

[0000936395-23-000030:8k_2_02:15]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-23-000030:8k_2_02:16]
|  |  | GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,067.9 |  |  | $ | 868.0 |  |  | 23.0 | % |  |  |  |  |  |  |
| Gross margin |  | 42.0 | % |  | 39.3 | % |  | 2.7 | % |  |  |  |  |  |  |
| Operating expense |  | $ | 370.7 |  |  | $ | 313.7 |  |  | 18.2 | % |  |  |  |  |  |  |
| Operating margin |  | 7.3 | % |  | 3.1 | % |  | 4.2 | % |  |  |  |  |  |  |

[0000936395-23-000030:8k_2_02:17]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |  |  |
|  |  | FY 2023 |  | FY 2022 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,067.9 |  |  | $ | 868.0 |  |  | 23.0 | % |  |  |  |  |  |  |
| Adj. gross margin |  | 42.7 | % |  | 40.0 | % |  | 2.7 | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 327.9 |  |  | $ | 273.1 |  |  | 20.1 | % |  |  |  |  |  |  |
| Adj. operating margin |  | 12.0 | % |  | 8.5 | % |  | 3.5 | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 151.3 |  |  | $ | 96.0 |  |  | 57.6 | % |  |  |  |  |  |  |

[0000936395-23-000030:8k_2_02:18]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-23-000030:8k_2_02:19]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q3 FY 2023 |  | Q3 FY 2022 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 719.0 |  |  | 67.3 |  |  | $ | 563.9 |  |  | 65.0 |  |
| Routing and Switching |  | 127.6 |  |  | 11.9 |  |  | 100.7 |  |  | 11.6 |  |
| Total Networking Platforms |  | 846.6 |  |  | 79.2 |  |  | 664.6 |  |  | 76.6 |  |
| Platform Software and Services |  | 78.9 |  |  | 7.4 |  |  | 63.5 |  |  | 7.3 |  |
| Blue Planet Automation Software and Services |  | 13.1 |  |  | 1.3 |  |  | 17.3 |  |  | 2.0 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 72.9 |  |  | 6.8 |  |  | 72.8 |  |  | 8.4 |  |
| Installation and Deployment |  | 46.8 |  |  | 4.4 |  |  | 38.7 |  |  | 4.4 |  |
| Consulting and Network Design |  | 9.6 |  |  | 0.9 |  |  | 11.1 |  |  | 1.3 |  |
| Total Global Services |  | 129.3 |  |  | 12.1 |  |  | 122.6 |  |  | 14.1 |  |
| Total |  | $ | 1,067.9 |  |  | 100.0 |  |  | $ | 868.0 |  |  | 100.0 |  |

[0000936395-23-000030:8k_2_02:20]
**  Denotes %  of total revenue

[0000936395-23-000030:8k_2_02:21]
Additional Performance Metrics for Fiscal Third Quarter 2023

[0000936395-23-000030:8k_2_02:22]
2

[0000936395-23-000030:8k_2_02:23]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q3 FY 2023 |  | Q3 FY 2022 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 749.5 |  |  | 70.2 |  |  | $ | 617.4 |  |  | 71.1 |  |
| Europe, Middle East and Africa |  | 152.8 |  |  | 14.3 |  |  | 124.2 |  |  | 14.3 |  |
| Asia Pacific |  | 165.6 |  |  | 15.5 |  |  | 126.4 |  |  | 14.6 |  |
| Total |  | $ | 1,067.9 |  |  | 100.0 |  |  | $ | 868.0 |  |  | 100.0 |  |

[0000936395-23-000030:8k_2_02:24]
**  Denotes %  of total revenue

[0000936395-23-000030:8k_2_02:25]
•One customer represented 10%-plus of revenue for a total of 11.7% of revenue

[0000936395-23-000030:8k_2_02:26]
•Cash and investments totaled $1.28 billion

[0000936395-23-000030:8k_2_02:27]
•Cash flow from operations totaled $8.7 million

[0000936395-23-000030:8k_2_02:28]
•Average days' sales outstanding (DSOs) were 96

[0000936395-23-000030:8k_2_02:29]
•Accounts receivable, net balance was $997.4 million

[0000936395-23-000030:8k_2_02:30]
•Unbilled contract assets, net balance was $142.3 million

[0000936395-23-000030:8k_2_02:31]
•Inventories totaled $1.19 billion, including:

[0000936395-23-000030:8k_2_02:32]
◦Raw materials: $772.0 million

[0000936395-23-000030:8k_2_02:33]
◦Work in process: $51.8 million

[0000936395-23-000030:8k_2_02:34]
◦Finished goods: $333.5 million

[0000936395-23-000030:8k_2_02:35]
◦Deferred cost of sales: $77.5 million

[0000936395-23-000030:8k_2_02:36]
◦Reserve for excess and obsolescence: $(42.3) million

[0000936395-23-000030:8k_2_02:37]
•Product inventory turns were 1.7

[0000936395-23-000030:8k_2_02:38]
•Headcount totaled 8,623

[0000936395-23-000030:8k_2_02:39]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2023 Results

[0000936395-23-000030:8k_2_02:40]
Today, Thursday, August 31, 2023, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal third quarter 2023 results.

[0000936395-23-000030:8k_2_02:41]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-23-000030:8k_2_02:42]
Notes to Investors

[0000936395-23-000030:8k_2_02:43]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered excellent results for the fiscal third quarter with strength across all regions. We are encouraged by

[0000936395-23-000030:8k_2_02:44]
increased customer activity that, when combined with our elevated backlog, market leadership and expanding addressable market, we believe will drive growth and market share gains going forward."

[0000936395-23-000030:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the impact of supply chain constraints or disruptions; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical events, including but not limited to the ongoing conflict between Ukraine and Russia, and public health emergencies; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including Ciena’s Annual Report on Form 10-K filed with the SEC on December 16, 2022 and included in its Quarterly Report on Form 10-Q for the third quarter of fiscal 2023 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-23-000030:8k_2_02:46]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-23-000030:8k_2_02:47]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-23-000030:8k_2_02:48]
4

[0000936395-23-000030:8k_2_02:49]
CIENA CORPORATION

[0000936395-23-000030:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-23-000030:8k_2_02:51]
(in thousands, except per share data)

[0000936395-23-000030:8k_2_02:52]
(unaudited)

[0000936395-23-000030:8k_2_02:53]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 865,197 |  |  | $ | 684,284 |  |  | $ | 2,678,242 |  |  | $ | 2,109,239 |  |
| Services | 202,689 |  |  | 183,697 |  |  | 578,820 |  |  | 552,412 |  |
| Total revenue | 1,067,886 |  |  | 867,981 |  |  | 3,257,062 |  |  | 2,661,651 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 516,900 |  |  | 434,756 |  |  | 1,559,120 |  |  | 1,259,378 |  |
| Services | 102,045 |  |  | 92,446 |  |  | 305,372 |  |  | 275,526 |  |
| Total cost of goods sold | 618,945 |  |  | 527,202 |  |  | 1,864,492 |  |  | 1,534,904 |  |
| Gross profit | 448,941 |  |  | 340,779 |  |  | 1,392,570 |  |  | 1,126,747 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 189,392 |  |  | 150,025 |  |  | 561,115 |  |  | 457,758 |  |
| Selling and marketing | 118,266 |  |  | 105,880 |  |  | 367,156 |  |  | 344,700 |  |
| General and administrative | 49,349 |  |  | 41,121 |  |  | 151,184 |  |  | 131,191 |  |
| Significant asset impairments and restructuring costs | 4,174 |  |  | 7,692 |  |  | 16,625 |  |  | 20,203 |  |
| Amortization of intangible assets | 9,487 |  |  | 8,919 |  |  | 26,773 |  |  | 26,757 |  |
| Acquisition and integration costs | 59 |  |  | 35 |  |  | 3,474 |  |  | 598 |  |
| Total operating expenses | 370,727 |  |  | 313,672 |  |  | 1,126,327 |  |  | 981,207 |  |
| Income from operations | 78,214 |  |  | 27,107 |  |  | 266,243 |  |  | 145,540 |  |
| Interest and other income, net | 10,187 |  |  | 366 |  |  | 50,711 |  |  | 4,860 |  |
| Interest expense | (24,060) |  |  | (12,642) |  |  | (63,819) |  |  | (33,275) |  |
| Income before income taxes | 64,341 |  |  | 14,831 |  |  | 253,135 |  |  | 117,125 |  |
| Provision for income taxes | 34,608 |  |  | 4,319 |  |  | 89,507 |  |  | 21,868 |  |
| Net income | $ | 29,733 |  |  | $ | 10,512 |  |  | $ | 163,628 |  |  | $ | 95,257 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |  | $ | 0.63 |  |
| Diluted net income per potential common share | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |  | $ | 0.62 |  |
| Weighted average basic common shares outstanding | 149,690 |  |  | 149,862 |  |  | 149,472 |  |  | 152,083 |  |
| Weighted average dilutive potential common shares outstanding 1 | 149,977 |  |  | 150,463 |  |  | 149,867 |  |  | 153,209 |  |

[0000936395-23-000030:8k_2_02:54]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.3 million and 0.4 million shares for the third quarter and first nine months of fiscal 2023, respectively; and (ii) 0.6 million and 1.1 million shares for the third quarter and first nine months of fiscal 2022, respectively.

[0000936395-23-000030:8k_2_02:55]
CIENA CORPORATION

[0000936395-23-000030:8k_2_02:56]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-23-000030:8k_2_02:57]
(in thousands, except share data)

[0000936395-23-000030:8k_2_02:58]
(unaudited)

[0000936395-23-000030:8k_2_02:59]
|  | July 29,2023 |  | October 29,2022 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,117,922 |  |  | $ | 994,352 |  |
| Short-term investments | 141,843 |  |  | 153,989 |  |
| Accounts receivable, net | 997,373 |  |  | 920,772 |  |
| Inventories | 1,192,522 |  |  | 946,730 |  |
| Prepaid expenses and other | 361,692 |  |  | 370,053 |  |
| Total current assets | 3,811,352 |  |  | 3,385,896 |  |
| Long-term investments | 21,098 |  |  | 35,385 |  |
| Equipment, building, furniture and fixtures, net | 287,455 |  |  | 267,779 |  |
| Operating lease right-of-use assets | 40,482 |  |  | 45,108 |  |
| Goodwill | 446,596 |  |  | 328,322 |  |
| Other intangible assets, net | 219,085 |  |  | 69,517 |  |
| Deferred tax asset, net | 792,299 |  |  | 824,008 |  |
| Other long-term assets | 104,847 |  |  | 113,617 |  |
| Total assets | $ | 5,723,214 |  |  | $ | 5,069,632 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 393,144 |  |  | $ | 516,047 |  |
| Accrued liabilities and other short-term obligations | 355,622 |  |  | 360,782 |  |
| Deferred revenue | 188,104 |  |  | 137,899 |  |
| Operating lease liabilities | 16,941 |  |  | 18,925 |  |
| Current portion of long-term debt | 11,930 |  |  | 6,930 |  |
| Total current liabilities | 965,741 |  |  | 1,040,583 |  |
| Long-term deferred revenue | 71,873 |  |  | 62,336 |  |
| Other long-term obligations | 156,893 |  |  | 150,335 |  |
| Long-term operating lease liabilities | 37,800 |  |  | 42,392 |  |
| Long-term debt, net | 1,543,900 |  |  | 1,061,125 |  |
| Total liabilities | 2,776,207 |  |  | 2,356,771 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 148,772,513 and 148,412,943 shares issued and outstanding | 1,488 |  |  | 1,484 |  |
| Additional paid-in capital | 6,425,899 |  |  | 6,390,252 |  |
| Accumulated other comprehensive loss | (11,778) |  |  | (46,645) |  |
| Accumulated deficit | (3,468,602) |  |  | (3,632,230) |  |
| Total stockholders’ equity | 2,947,007 |  |  | 2,712,861 |  |
| Total liabilities and stockholders’ equity | $ | 5,723,214 |  |  | $ | 5,069,632 |  |

[0000936395-23-000030:8k_2_02:60]
6

[0000936395-23-000030:8k_2_02:61]
CIENA CORPORATION

[0000936395-23-000030:8k_2_02:62]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-23-000030:8k_2_02:63]
(in thousands) (unaudited)

[0000936395-23-000030:8k_2_02:64]
|  | Nine Months Ended |
|  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |
| Cash flows used in operating activities: |  |  |  |
| Net income | $ | 163,628 |  |  | $ | 95,257 |  |
| Adjustments to reconcile net income to net cash used in operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 69,213 |  |  | 68,280 |  |
| Share-based compensation expense | 95,405 |  |  | 77,827 |  |
| Amortization of intangible assets | 36,274 |  |  | 36,521 |  |
| Deferred taxes | (64,005) |  |  | (19,824) |  |
| Provision for inventory excess and obsolescence | 18,767 |  |  | 12,038 |  |
| Provision for warranty | 18,860 |  |  | 12,416 |  |
| Gain on cost method equity investments, net | (26,368) |  |  | (4,120) |  |
| Other | 13,694 |  |  | 3,678 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (80,399) |  |  | 74,478 |  |
| Inventories | (262,345) |  |  | (464,664) |  |
| Prepaid expenses and other | 72,062 |  |  | (39,805) |  |
| Operating lease right-of-use assets | 11,003 |  |  | 12,504 |  |
| Accounts payable, accruals and other obligations | (133,880) |  |  | (37,587) |  |
| Deferred revenue | 57,547 |  |  | 34,949 |  |
| Short and long-term operating lease liabilities | (16,596) |  |  | (15,197) |  |
| Net cash used in operating activities | (27,140) |  |  | (153,249) |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (83,422) |  |  | (66,908) |  |
| Purchases of investments | (119,240) |  |  | (614,333) |  |
| Proceeds from sales and maturities of investments | 150,646 |  |  | 460,000 |  |
| Settlement of foreign currency forward contracts, net | (3,272) |  |  | 4,450 |  |
| Purchase of cost method equity investments | — |  |  | (8,000) |  |
| Acquisition of business, net of cash acquired | (230,048) |  |  | (62,043) |  |
| Net cash used in investing activities | (285,336) |  |  | (286,834) |  |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Proceeds from issuance of senior notes | — |  |  | 400,000 |  |
| Proceeds from issuance of term loan, net | 497,500 |  |  | — |  |
| Payment of long term debt | (6,448) |  |  | (3,465) |  |
| Payment of debt issuance costs | (5,422) |  |  | (5,159) |  |
| Payment of finance lease obligations | (2,830) |  |  | (2,555) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (29,794) |  |  | (41,280) |  |
| Repurchases of common stock - repurchase program | (57,736) |  |  | (487,792) |  |
| Proceeds from issuance of common stock | 31,276 |  |  | 30,224 |  |
| Net cash provided by (used in) financing activities | 426,546 |  |  | (110,027) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 9,501 |  |  | (12,780) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 123,571 |  |  | (562,890) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 994,378 |  |  | 1,422,604 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,117,949 |  |  | $ | 859,714 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 56,709 |  |  | $ | 24,823 |  |
| Cash paid during the period for income taxes, net | $ | 68,058 |  |  | $ | 28,593 |  |
| Operating lease payments | $ | 18,038 |  |  | $ | 16,342 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,579 |  |  | $ | 9,320 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 3,500 |  |  | $ | 5,000 |  |
| Operating right-of-use assets subject to lease liability | $ | 9,771 |  |  | $ | 8,226 |  |
| Gain on cost method equity investments, net | $ | 26,368 |  |  | $ | 4,120 |  |

[0000936395-23-000030:8k_2_02:65]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | July 29, |  | July 30, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 448,941 |  |  | $ | 340,779 |  |  |  |  |  |
| Share-based compensation-products |  | 1,118 |  |  | 1,002 |  |  |  |  |  |
| Share-based compensation-services |  | 2,687 |  |  | 1,940 |  |  |  |  |  |
| Amortization of intangible assets |  | 3,187 |  |  | 3,140 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 6,992 |  |  | 6,082 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 455,933 |  |  | $ | 346,861 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 42.7 | % |  | 40.0 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 370,727 |  |  | $ | 313,672 |  |  |  |  |  |
| Share-based compensation-research and development |  | 10,954 |  |  | 8,233 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 8,770 |  |  | 8,075 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 9,377 |  |  | 7,579 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 4,174 |  |  | 7,692 |  |  |  |  |  |
| Amortization of intangible assets |  | 9,487 |  |  | 8,919 |  |  |  |  |  |
| Acquisition and integration costs |  | 59 |  |  | 35 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 42,821 |  |  | 40,533 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 327,906 |  |  | $ | 273,139 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 78,214 |  |  | $ | 27,107 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 6,992 |  |  | 6,082 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 42,821 |  |  | 40,533 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 49,813 |  |  | 46,615 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 128,027 |  |  | $ | 73,722 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 12.0 | % |  | 8.5 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 29,733 |  |  | $ | 10,512 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 34,608 |  |  | 4,319 |  |  |  |  |  |
| Income before income taxes |  | 64,341 |  |  | 14,831 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 49,813 |  |  | 46,615 |  |  |  |  |  |
| Loss on cost method equity investment |  | 87 |  |  | — |  |  |  |  |  |
| Adjusted income before income taxes |  | 114,241 |  |  | 61,446 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 25,133 |  |  | 12,412 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 89,108 |  |  | $ | 49,034 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 149,690 |  | 149,862 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 149,977 |  | 150,463 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.20 |  |  | $ | 0.07 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.59 |  |  | $ | 0.33 |  |  |  |  |  |

[0000936395-23-000030:8k_2_02:66]
8

[0000936395-23-000030:8k_2_02:67]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.3 million for the third quarter of fiscal 2023; and (ii) 0.6 million for the third quarter of fiscal 2022.

[0000936395-23-000030:8k_2_02:68]
9

[0000936395-23-000030:8k_2_02:69]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | July 29, |  | July 30, |  |  |  |  |
|  |  | 2023 |  | 2022 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 29,733 |  |  | $ | 10,512 |  |  |  |  |  |
| Add: Interest expense |  | 24,060 |  |  | 12,642 |  |  |  |  |  |
| Less: Interest and other income, net |  | 10,187 |  |  | 366 |  |  |  |  |  |
| Add: Provision for income taxes |  | 34,608 |  |  | 4,319 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 23,310 |  |  | 22,250 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 12,674 |  |  | 12,059 |  |  |  |  |  |
| EBITDA |  | $ | 114,198 |  |  | $ | 61,416 |  |  |  |  |  |
| Add: Share-based compensation cost |  | 32,906 |  |  | 26,857 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 4,174 |  |  | 7,692 |  |  |  |  |  |
| Add: Acquisition and integration costs |  | 59 |  |  | 35 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 151,337 |  |  | $ | 96,000 |  |  |  |  |  |

[0000936395-23-000030:8k_2_02:70]
* * *

[0000936395-23-000030:8k_2_02:71]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-23-000030:8k_2_02:72]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-23-000030:8k_2_02:73]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, and the redesign of business processes including restructuring certain real estate facilities.

[0000936395-23-000030:8k_2_02:74]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-23-000030:8k_2_02:75]
•Acquisition and integration costs - primarily consist of financial, legal and accounting advisors' costs and employment-related costs related to Ciena's acquisitions in fiscal 2022 and fiscal 2023.

[0000936395-23-000030:8k_2_02:76]
•Loss on cost method equity investment - reflects changes in the carrying value of a certain cost method equity investment due to triggering events.

[0000936395-23-000030:8k_2_02:77]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for the third fiscal quarter of 2023 and 20.2% for the third fiscal quarter of 2022. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.

## item 5.02 — body, verbatim

[0000936395-23-000030:8k_body:1]
ITEM 5.02 - DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0000936395-23-000030:8k_body:2]
(d) Effective August 30, 2023, the Board of Directors (the “Board”) of Ciena increased the size of the Board to ten directors and appointed Mary G. Puma to fill the newly created vacancy in Class II of the Board. The term of office for Class II directors does not expire until the 2026 Annual Meeting of Stockholders. However, in accordance with Ciena’s Amended and Restated Bylaws, Ms. Puma will stand for election at the 2024 Annual Meeting of stockholders to serve the remainder of the Class II term, or until her successor is duly elected and qualified. Also effective August 30, 2023, Ms. Puma was appointed to serve on the Audit Committee of the Board.

[0000936395-23-000030:8k_body:3]
Ms. Puma, age 65, has served as Executive Chairperson of the board of directors of Axcelis Technologies, Inc. (“Axcelis”), a publicly traded company engaged in the supply of capital equipment for the semiconductor chip manufacturing industry, since May 2023. Ms. Puma previously served at Axcelis as President and Chief Executive Officer from January 2002 to May 2023, as President and Chief Operating Officer from July 2000 to January 2002, and as Chairperson of the Board from 2005 to 2015. In 1998, Ms. Puma became General Manager and Vice President of Axcelis’s predecessor, the Implant Systems Division of Eaton Corporation. Prior to joining Eaton Corporation in 1996, Ms. Puma spent 15 years in various marketing and general management positions at General Electric. Ms. Puma also currently serves on the boards of directors of Nordson Corporation and SMART Global Holdings, both publicly traded companies. She also serves on the board of directors of SEMI, a global industry association serving the manufacturing supply chain for the micro- and nano-electronics industries, where she has served as Chairperson of the Board since December 2022. Ms. Puma holds a Bachelor of Arts degree in economics from Tufts University and a Master of Science degree from the MIT Sloan School of Management.

[0000936395-23-000030:8k_body:4]
The Board also approved the grant, effective as of September 1, 2023, of a restricted stock unit award to Ms. Puma representing shares of Ciena common stock with a target delivered value of approximately $130,685. The amount of the award reflects Ciena's standard compensation program for initial equity awards to new directors, pro-rated based on the date of appointment to the Board. Provided Ms. Puma continues her service on the Board, the restricted stock unit award will vest in its entirety on September 20, 2024. In connection with her service on the Board, Ms. Puma will also be entitled to the standard non-employee director compensation arrangements as set forth under the heading “Director Compensation” in Ciena’s most recent proxy statement filed with the Securities and Exchange Commission.

[0000936395-23-000030:8k_body:5]
A copy of the press release announcing the appointment of Ms. Puma to the Board is furnished as Exhibit 99.3.
