# CIEN note change history — 0000936395-23-000027 → 0000936395-23-000034


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-09-06):
[0000936395-23-000034:note_history:1]
|  |  | July 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 670,478 |  |  | $ | (687) |  |  | $ | (1,286) |  |  | $ | 668,505 |  |  | $ | 673,010 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:2]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.3 million as of July 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was approximately $0.5 million during the first nine months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2023-06-07, similarity 0.7412):
[0000936395-23-000027:note_history:2]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.4 million as of April 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2023-09-06):
[0000936395-23-000034:note_history:3]
As of July 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-06-07, similarity 0.986):
[0000936395-23-000027:note_history:3]
As of April 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2023-09-06):
[0000936395-23-000034:note_history:4]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.
  (was, 2023-06-07, similarity 0.7038):
[0000936395-23-000027:note_history:4]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of

- added (2023-09-06):
[0000936395-23-000034:note_history:5]
|  |  | July 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 498,750 |  |  | $ | (2,308) |  |  | $ | (4,679) |  |  | $ | 491,763 |  |  |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:6]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of July 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.4 million during the first nine months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2023-06-07, similarity 0.9858):
[0000936395-23-000027:note_history:6]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of April 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.2 million during the first six months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2023-09-06):
[0000936395-23-000034:note_history:7]
As of July 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-06-07, similarity 0.986):
[0000936395-23-000027:note_history:7]
As of April 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2023-09-06):
[0000936395-23-000034:note_history:8]
|  |  | July 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,438) |  |  | $ | 395,562 |  |  | $ | 395,045 |  |  |  |

- added (2023-09-06):
[0000936395-23-000034:note_history:9]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.4 million as of July 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.5 million and $0.4 million during the first nine months of fiscal 2023 and fiscal 2022, respectively.

- changed (2023-09-06):
[0000936395-23-000034:note_history:10]
As of July 29, 2023, the estimated fair value of the 2030 Notes was $350.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.
  (was, 2023-06-07, similarity 0.6743):
[0000936395-23-000027:note_history:10]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.6 million as of April 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.3 million during the first six months of fiscal 2023 and was $0.2 million during the first six months of fiscal 2022. 
As of April 29, 2023, the estimated fair value of the 2030 Notes was $349.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.

- removed (2023-09-06):
[0000936395-23-000027:note_history:11]
|  |  | April 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 672,210 |  |  | $ | (767) |  |  | $ | (1,436) |  |  | $ | 670,007 |  |  | $ | 673,010 |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:12]
senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.7 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

- removed (2023-09-06):
[0000936395-23-000027:note_history:13]
|  |  | April 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,400) |  |  | $ | (4,667) |  |  | $ | 492,933 |  |  |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:14]
|  |  | April 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,610) |  |  | $ | 395,390 |  |  | $ | 395,045 |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0000936395-23-000034:note_history:15]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2023-06-07, similarity 0.9964):
[0000936395-23-000027:note_history:15]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

- changed (2023-09-06):
[0000936395-23-000034:note_history:16]
|  | July 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 94,715 |  |  | $ | 1 |  |  | $ | (976) |  |  | $ | 93,740 |  |
| Corporate debt securities | 63,401 |  |  | 2 |  |  | (155) |  |  | 63,248 |  |
| Time deposits | 80,854 |  |  | 1 |  |  | (12) |  |  | 80,843 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |
| Included in cash equivalents | $ | 74,890 |  |  | $ | — |  |  | $ | — |  |  | $ | 74,890 |  |
| Included in short-term investments | 142,743 |  |  | 4 |  |  | (904) |  |  | 141,843 |  |
| Included in long-term investments | 21,337 |  |  | — |  |  | (239) |  |  | 21,098 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |
  (was, 2023-06-07, similarity 0.9912):
[0000936395-23-000027:note_history:16]
|  | April 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 120,628 |  |  | $ | 39 |  |  | $ | (1,620) |  |  | $ | 119,047 |  |
| Corporate debt securities | 57,707 |  |  | 41 |  |  | (90) |  |  | 57,658 |  |
| Time deposits | 91,454 |  |  | 2 |  |  | (5) |  |  | 91,451 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |
| Included in cash equivalents | $ | 92,455 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,455 |  |
| Included in short-term investments | 152,105 |  |  | 38 |  |  | (1,679) |  |  | 150,464 |  |
| Included in long-term investments | 25,229 |  |  | 44 |  |  | (36) |  |  | 25,237 |  |
|  | $ | 269,789 |  |  | $ | 82 |  |  | $ | (1,715) |  |  | $ | 268,156 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:17]
The following table summarizes the final legal maturities of debt investments as of July 29, 2023 (in thousands):
  (was, 2023-06-07, similarity 0.9677):
[0000936395-23-000027:note_history:17]
The following table summarizes the final legal maturities of debt investments as of April 29, 2023 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-09-06):
[0000936395-23-000034:note_history:18]
|  |  | July 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 670,478 |  |  | $ | (687) |  |  | $ | (1,286) |  |  | $ | 668,505 |  |  | $ | 673,010 |  |

- added (2023-09-06):
[0000936395-23-000034:note_history:19]
|  |  | July 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 498,750 |  |  | $ | (2,308) |  |  | $ | (4,679) |  |  | $ | 491,763 |  |  |  |

- added (2023-09-06):
[0000936395-23-000034:note_history:20]
|  |  | July 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,438) |  |  | $ | 395,562 |  |  | $ | 395,045 |  |  |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:21]
|  |  | April 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 672,210 |  |  | $ | (767) |  |  | $ | (1,436) |  |  | $ | 670,007 |  |  | $ | 673,010 |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:22]
|  |  | April 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 500,000 |  |  | $ | (2,400) |  |  | $ | (4,667) |  |  | $ | 492,933 |  |  |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:23]
|  |  | April 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,610) |  |  | $ | 395,390 |  |  | $ | 395,045 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0000936395-23-000034:note_history:24]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
  (was, 2023-06-07, similarity 0.9961):
[0000936395-23-000027:note_history:24]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:25]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
  (was, 2023-06-07, similarity 0.9961):
[0000936395-23-000027:note_history:25]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | $ | 773,728 |  |
| Services transferred over time | — |  |  | 47,414 |  |  | 12,845 |  |  | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:26]
|  | Nine Months Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
  (was, 2023-06-07, similarity 0.9932):
[0000936395-23-000027:note_history:26]
|  | Six Months Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:27]
|  | Nine months ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
  (was, 2023-06-07, similarity 0.9932):
[0000936395-23-000027:note_history:27]
|  | Six months ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:28]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2023-06-07, similarity 0.9388):
[0000936395-23-000027:note_history:28]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2023-09-06):
[0000936395-23-000034:note_history:29]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 749,479 |  |  | $ | 617,366 |  |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |
| EMEA |  | 152,834 |  |  | 124,185 |  |  | 479,053 |  |  | 420,075 |  |
| APAC |  | 165,573 |  |  | 126,430 |  |  | 469,075 |  |  | 328,226 |  |
| Total revenue by geographic distribution |  | $ | 1,067,886 |  |  | $ | 867,981 |  |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |
  (was, 2023-06-07, similarity 0.9041):
[0000936395-23-000027:note_history:29]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 794,359 |  |  | $ | 700,840 |  |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |
| EMEA |  | 173,414 |  |  | 145,106 |  |  | 326,218 |  |  | 295,891 |  |
| APAC |  | 164,882 |  |  | 103,281 |  |  | 303,503 |  |  | 201,795 |  |
| Total revenue by geographic distribution |  | $ | 1,132,655 |  |  | $ | 949,227 |  |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:30]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2023-06-07, similarity 0.952):
[0000936395-23-000027:note_history:30]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2023-09-06):
[0000936395-23-000034:note_history:31]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 124,897 |  |  | n/a |  | $ | 369,678 |  |  | n/a |
| AT&T | n/a |  | 100,293 |  |  | $ | 357,382 |  |  | 314,358 |  |
| Verizon | n/a |  | 108,495 |  |  | n/a |  | 273,158 |  |
| Total | $ | 124,897 |  |  | $ | 208,788 |  |  | $ | 727,060 |  |  | $ | 587,516 |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:32]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 123,452 |  |  | n/a |  | $ | 244,779 |  |  | n/a |
| AT&T | n/a |  | 103,189 |  |  | 251,329 |  |  | 214,065 |  |
| Total | $ | 123,452 |  |  | $ | 103,189 |  |  | $ | 496,108 |  |  | $ | 214,065 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-09-06):
[0000936395-23-000034:note_history:33]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
  (was, 2023-06-07, similarity 0.9961):
[0000936395-23-000027:note_history:33]
|  | Quarter Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 784,549 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 784,549 |  |
| Routing and Switching | 130,310 |  |  | — |  |  | — |  |  | — |  |  | 130,310 |  |
| Platform Software and Services | — |  |  | 69,443 |  |  | — |  |  | — |  |  | 69,443 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 20,567 |  |  | — |  |  | 20,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 73,160 |  |  | 73,160 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,486 |  |  | 39,486 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 15,140 |  |  | 15,140 |  |
| Total revenue by product line | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 914,859 |  |  | $ | 13,447 |  |  | $ | 7,329 |  |  | $ | 15,412 |  |  | $ | 951,047 |  |
| Services transferred over time | — |  |  | 55,996 |  |  | 13,238 |  |  | 112,374 |  |  | 181,608 |  |
| Total revenue by timing of revenue recognition | $ | 914,859 |  |  | $ | 69,443 |  |  | $ | 20,567 |  |  | $ | 127,786 |  |  | $ | 1,132,655 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:34]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
  (was, 2023-06-07, similarity 0.9961):
[0000936395-23-000027:note_history:34]
|  | Quarter Ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 625,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 625,294 |  |
| Routing and Switching | 109,186 |  |  | — |  |  | — |  |  | — |  |  | 109,186 |  |
| Platform Software and Services | — |  |  | 69,157 |  |  | — |  |  | — |  |  | 69,157 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,881 |  |  | — |  |  | 16,881 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,019 |  |  | 74,019 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 41,430 |  |  | 41,430 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,260 |  |  | 13,260 |  |
| Total revenue by product line | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 734,480 |  |  | $ | 21,743 |  |  | $ | 4,036 |  |  | $ | 13,469 |  |  | $ | 773,728 |  |
| Services transferred over time | — |  |  | 47,414 |  |  | 12,845 |  |  | 115,240 |  |  | 175,499 |  |
| Total revenue by timing of revenue recognition | $ | 734,480 |  |  | $ | 69,157 |  |  | $ | 16,881 |  |  | $ | 128,709 |  |  | $ | 949,227 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:35]
|  | Nine Months Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
  (was, 2023-06-07, similarity 0.9932):
[0000936395-23-000027:note_history:35]
|  | Six Months Ended April 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,520,183 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,520,183 |  |
| Routing and Switching | 249,814 |  |  | — |  |  | — |  |  | — |  |  | 249,814 |  |
| Platform Software and Services | — |  |  | 142,888 |  |  | — |  |  | — |  |  | 142,888 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 35,973 |  |  | — |  |  | 35,973 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 141,051 |  |  | 141,051 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 74,061 |  |  | 74,061 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,206 |  |  | 25,206 |  |
| Total revenue by product line | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,769,997 |  |  | $ | 32,311 |  |  | $ | 11,312 |  |  | $ | 24,667 |  |  | $ | 1,838,287 |  |
| Services transferred over time | — |  |  | 110,577 |  |  | 24,661 |  |  | 215,651 |  |  | 350,889 |  |
| Total revenue by timing of revenue recognition | $ | 1,769,997 |  |  | $ | 142,888 |  |  | $ | 35,973 |  |  | $ | 240,318 |  |  | $ | 2,189,176 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:36]
|  | Nine months ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
  (was, 2023-06-07, similarity 0.9932):
[0000936395-23-000027:note_history:36]
|  | Six months ended April 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,166,230 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,166,230 |  |
| Routing and Switching | 194,896 |  |  | — |  |  | — |  |  | — |  |  | 194,896 |  |
| Platform Software and Services | — |  |  | 142,074 |  |  | — |  |  | — |  |  | 142,074 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 37,992 |  |  | — |  |  | 37,992 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 146,509 |  |  | 146,509 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 81,800 |  |  | 81,800 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 24,169 |  |  | 24,169 |  |
| Total revenue by product line | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,361,126 |  |  | $ | 51,424 |  |  | $ | 12,810 |  |  | $ | 21,960 |  |  | $ | 1,447,320 |  |
| Services transferred over time | — |  |  | 90,650 |  |  | 25,182 |  |  | 230,518 |  |  | 346,350 |  |
| Total revenue by timing of revenue recognition | $ | 1,361,126 |  |  | $ | 142,074 |  |  | $ | 37,992 |  |  | $ | 252,478 |  |  | $ | 1,793,670 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:37]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2023-06-07, similarity 0.9565):
[0000936395-23-000027:note_history:37]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2023-09-06):
[0000936395-23-000034:note_history:38]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2023-06-07, similarity 0.9388):
[0000936395-23-000027:note_history:38]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2023-09-06):
[0000936395-23-000034:note_history:39]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 749,479 |  |  | $ | 617,366 |  |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |
| EMEA |  | 152,834 |  |  | 124,185 |  |  | 479,053 |  |  | 420,075 |  |
| APAC |  | 165,573 |  |  | 126,430 |  |  | 469,075 |  |  | 328,226 |  |
| Total revenue by geographic distribution |  | $ | 1,067,886 |  |  | $ | 867,981 |  |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |
  (was, 2023-06-07, similarity 0.9041):
[0000936395-23-000027:note_history:39]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 794,359 |  |  | $ | 700,840 |  |  | $ | 1,559,455 |  |  | $ | 1,295,984 |  |
| EMEA |  | 173,414 |  |  | 145,106 |  |  | 326,218 |  |  | 295,891 |  |
| APAC |  | 164,882 |  |  | 103,281 |  |  | 303,503 |  |  | 201,795 |  |
| Total revenue by geographic distribution |  | $ | 1,132,655 |  |  | $ | 949,227 |  |  | $ | 2,189,176 |  |  | $ | 1,793,670 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:40]
Ciena’s revenue includes $685.8 million and $574.3 million of United States revenue for the third quarter of fiscal 2023 and 2022, respectively. For the nine months ended July 29, 2023 and July 30, 2022, United States revenue was $2.1 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.
  (was, 2023-06-07, similarity 0.9086):
[0000936395-23-000027:note_history:40]
Ciena’s revenue includes $722.6 million and $642.2 million of United States revenue for the second quarter of fiscal 2023 and 2022, respectively. For the six months ended April 29, 2023 and April 30, 2022, United States revenue was $1.4 billion and $1.2 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented in the above table.

- changed (2023-09-06):
[0000936395-23-000034:note_history:41]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2023-06-07, similarity 0.952):
[0000936395-23-000027:note_history:41]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2023-09-06):
[0000936395-23-000034:note_history:42]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 124,897 |  |  | n/a |  | $ | 369,678 |  |  | n/a |
| AT&T | n/a |  | 100,293 |  |  | $ | 357,382 |  |  | 314,358 |  |
| Verizon | n/a |  | 108,495 |  |  | n/a |  | 273,158 |  |
| Total | $ | 124,897 |  |  | $ | 208,788 |  |  | $ | 727,060 |  |  | $ | 587,516 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:43]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.
  (was, 2023-06-07, similarity 0.8799):
[0000936395-23-000027:note_history:43]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for each of the periods presented.

- changed (2023-09-06):
[0000936395-23-000034:note_history:44]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023. This product line also includes Ciena’s WaveRouter® product, which was introduced during the second quarter of fiscal 2023, for which there have been no sales to date.
  (was, 2023-06-07, similarity 0.8435):
[0000936395-23-000027:note_history:44]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and Vyatta virtual routing and switching products. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023.

- changed (2023-09-06):
[0000936395-23-000034:note_history:45]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more
  (was, 2023-06-07, similarity 0.6705):
[0000936395-23-000027:note_history:45]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as

- added (2023-09-06):
[0000936395-23-000034:note_history:46]
proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2023-09-06):
[0000936395-23-000034:note_history:47]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):
  (was, 2023-06-07, similarity 0.927):
[0000936395-23-000027:note_history:47]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- changed (2023-09-06):
[0000936395-23-000034:note_history:48]
|  |  | Balance at July 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 997,373 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 142,305 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 259,977 |  |  | $ | 200,235 |  |
  (was, 2023-06-07, similarity 0.9808):
[0000936395-23-000027:note_history:48]
|  |  | Balance at April 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 1,036,688 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 180,020 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 270,625 |  |  | $ | 200,235 |  |

- changed (2023-09-06):
[0000936395-23-000034:note_history:49]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $119.8 million and $98.9 million of revenue during the first nine months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 29, 2023 and July 30, 2022.
  (was, 2023-06-07, similarity 0.9269):
[0000936395-23-000027:note_history:49]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $100.1 million and $82.0 million of revenue during the first six months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended April 29, 2023 and April 30, 2022.

- changed (2023-09-06):
[0000936395-23-000034:note_history:50]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $31.4 million and $39.7 million as of July 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $20.5 million during the first nine months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2023-06-07, similarity 0.9848):
[0000936395-23-000027:note_history:50]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $36.6 million and $39.7 million as of April 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $16.2 million and $14.1 million during the first six months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2023-09-06):
[0000936395-23-000034:note_history:51]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 29, 2023, the aggregate amount of RPO was $2.1 billion. As of July 29, 2023, Ciena expects approximately 84% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2023-06-07, similarity 0.6015):
[0000936395-23-000027:note_history:51]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of April 29, 2023, the aggregate amount of RPO was $2.4 billion. As of April 29, 2023, Ciena expects approximately 86% of the RPO to be recognized as revenue within the next 12 months.

- removed (2023-09-06):
[0000936395-23-000027:note_history:52]
|  | Quarter Ended |  | Six Months Ended |
|  | April 29, |  | April 30, |  | April 29, |  | April 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 123,452 |  |  | n/a |  | $ | 244,779 |  |  | n/a |
| AT&T | n/a |  | 103,189 |  |  | 251,329 |  |  | 214,065 |  |
| Total | $ | 123,452 |  |  | $ | 103,189 |  |  | $ | 496,108 |  |  | $ | 214,065 |  |

- removed (2023-09-06):
[0000936395-23-000027:note_history:53]
planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2023-09-06):
[0000936395-23-000034:note_history:54]
SUBSEQUENT EVENTSStock Repurchase ProgramFrom the end of the third quarter of fiscal 2023 through September 1, 2023, Ciena repurchased an additional 0.9 million shares of its common stock, for an aggregate purchase price of $38.8 million at an average price of $41.67 per share, inclusive of repurchases pending settlement. As of September 1, 2023, Ciena has repurchased an aggregate of 10.8 million shares and has an aggregate of $400.0 million of authorized funds remaining under its stock repurchase program.
