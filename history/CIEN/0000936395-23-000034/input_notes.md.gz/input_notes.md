# CIEN notes — 0000936395-23-000034


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-23-000034:notes:1]
[same as prior period, unchanged from 0000936395-23-000027:notes:1]

[0000936395-23-000034:notes:2]
[same as prior period, unchanged from 0000936395-23-000027:notes:2]

[0000936395-23-000034:notes:3]
[same as prior period, unchanged from 0000936395-23-000027:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-23-000034:notes:4]
[same as prior period, unchanged from 0000936395-23-000027:notes:4]

[0000936395-23-000034:notes:5]
[same as prior period, unchanged from 0000936395-23-000027:notes:5]

[0000936395-23-000034:notes:6]
In October 2021, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-23-000034:notes:7]
[same as prior period, unchanged from 0000936395-23-000027:notes:7]

[0000936395-23-000034:notes:8]
[same as prior period, unchanged from 0000936395-23-000027:notes:8]

[0000936395-23-000034:notes:9]
[same as prior period, unchanged from 0000936395-23-000027:notes:9]

[0000936395-23-000034:notes:10]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

[0000936395-23-000034:notes:11]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

[0000936395-23-000034:notes:12]
|  | Nine Months Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

[0000936395-23-000034:notes:13]
|  | Nine months ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

[0000936395-23-000034:notes:14]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-23-000034:notes:15]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-23-000034:notes:16]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 749,479 |  |  | $ | 617,366 |  |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |
| EMEA |  | 152,834 |  |  | 124,185 |  |  | 479,053 |  |  | 420,075 |  |
| APAC |  | 165,573 |  |  | 126,430 |  |  | 469,075 |  |  | 328,226 |  |
| Total revenue by geographic distribution |  | $ | 1,067,886 |  |  | $ | 867,981 |  |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |

[0000936395-23-000034:notes:17]
Ciena’s revenue includes $685.8 million and $574.3 million of United States revenue for the third quarter of fiscal 2023 and 2022, respectively. For the nine months ended July 29, 2023 and July 30, 2022, United States revenue was $2.1 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0000936395-23-000034:notes:18]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-23-000034:notes:19]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 124,897 |  |  | n/a |  | $ | 369,678 |  |  | n/a |
| AT&T | n/a |  | 100,293 |  |  | $ | 357,382 |  |  | 314,358 |  |
| Verizon | n/a |  | 108,495 |  |  | n/a |  | 273,158 |  |
| Total | $ | 124,897 |  |  | $ | 208,788 |  |  | $ | 727,060 |  |  | $ | 587,516 |  |

[0000936395-23-000034:notes:20]
[same as prior period, unchanged from 0000936395-23-000027:notes:20]

[0000936395-23-000034:notes:21]
[same as prior period, unchanged from 0000936395-23-000027:notes:21]

[0000936395-23-000034:notes:22]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

[0000936395-23-000034:notes:23]
[same as prior period, unchanged from 0000936395-23-000027:notes:23]

[0000936395-23-000034:notes:24]
[same as prior period, unchanged from 0000936395-23-000027:notes:24]

[0000936395-23-000034:notes:25]
[same as prior period, unchanged from 0000936395-23-000027:notes:25]

[0000936395-23-000034:notes:26]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023. This product line also includes Ciena’s WaveRouter® product, which was introduced during the second quarter of fiscal 2023, for which there have been no sales to date.

[0000936395-23-000034:notes:27]
[same as prior period, unchanged from 0000936395-23-000027:notes:27]

[0000936395-23-000034:notes:28]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more

[0000936395-23-000034:notes:29]
proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-23-000034:notes:30]
[same as prior period, unchanged from 0000936395-23-000027:notes:30]

[0000936395-23-000034:notes:31]
[same as prior period, unchanged from 0000936395-23-000027:notes:31]

[0000936395-23-000034:notes:32]
[same as prior period, unchanged from 0000936395-23-000027:notes:32]

[0000936395-23-000034:notes:33]
[same as prior period, unchanged from 0000936395-23-000027:notes:33]

[0000936395-23-000034:notes:34]
[same as prior period, unchanged from 0000936395-23-000027:notes:34]

[0000936395-23-000034:notes:35]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

[0000936395-23-000034:notes:36]
|  |  | Balance at July 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 997,373 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 142,305 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 259,977 |  |  | $ | 200,235 |  |

[0000936395-23-000034:notes:37]
[same as prior period, unchanged from 0000936395-23-000027:notes:37]

[0000936395-23-000034:notes:38]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $119.8 million and $98.9 million of revenue during the first nine months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 29, 2023 and July 30, 2022.

[0000936395-23-000034:notes:39]
[same as prior period, unchanged from 0000936395-23-000027:notes:39]

[0000936395-23-000034:notes:40]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $31.4 million and $39.7 million as of July 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $20.5 million during the first nine months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-23-000034:notes:41]
[same as prior period, unchanged from 0000936395-23-000027:notes:41]

[0000936395-23-000034:notes:42]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 29, 2023, the aggregate amount of RPO was $2.1 billion. As of July 29, 2023, Ciena expects approximately 84% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-23-000034:notes:43]
[same as prior period, unchanged from 0000936395-23-000027:notes:43]

[0000936395-23-000034:notes:44]
|  | July 29,2023 |  | October 29,2022 |
| Products | $ | 34,102 |  |  | $ | 19,814 |  |
| Services | 225,875 |  |  | 180,421 |  |
| Total deferred revenue | 259,977 |  |  | 200,235 |  |
| Less current portion | (188,104) |  |  | (137,899) |  |
| Long-term deferred revenue | $ | 71,873 |  |  | $ | 62,336 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-23-000034:notes:45]
[same as prior period, unchanged from 0000936395-23-000027:notes:45]

[0000936395-23-000034:notes:46]
[same as prior period, unchanged from 0000936395-23-000027:notes:46]

[0000936395-23-000034:notes:47]
[same as prior period, unchanged from 0000936395-23-000027:notes:47]

[0000936395-23-000034:notes:48]
[same as prior period, unchanged from 0000936395-23-000027:notes:48]

[0000936395-23-000034:notes:49]
[same as prior period, unchanged from 0000936395-23-000027:notes:49]

[0000936395-23-000034:notes:50]
[same as prior period, unchanged from 0000936395-23-000027:notes:50]

[0000936395-23-000034:notes:51]
[same as prior period, unchanged from 0000936395-23-000027:notes:51]

[0000936395-23-000034:notes:52]
[same as prior period, unchanged from 0000936395-23-000027:notes:52]

[0000936395-23-000034:notes:53]
[same as prior period, unchanged from 0000936395-23-000027:notes:53]

[0000936395-23-000034:notes:54]
[same as prior period, unchanged from 0000936395-23-000027:notes:54]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-23-000034:notes:55]
[same as prior period, unchanged from 0000936395-23-000027:notes:55]

[0000936395-23-000034:notes:56]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the nine months ended July 29, 2023 (in thousands):

[0000936395-23-000034:notes:57]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 4,509 |  | (1) | 12,116 |  | (2) | 16,625 |  |
| Cash payments | (4,920) |  |  | (16,736) |  |  | (21,656) |  |
| Balance at July 29, 2023 | $ | 804 |  |  | $ | — |  |  | $ | 804 |  |
| Current restructuring liabilities | $ | 804 |  |  | $ | — |  |  | $ | 804 |  |

[0000936395-23-000034:notes:58]
(1) Reflects employee costs associated with workforce reductions during the nine months ended July 29, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-23-000034:notes:59]
[same as prior period, unchanged from 0000936395-23-000027:notes:59]

[0000936395-23-000034:notes:60]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended July 30, 2022 (in thousands):

[0000936395-23-000034:notes:61]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 30, 2021 | $ | 781 |  |  | $ | — |  |  | $ | 781 |  |
| Charges | 2,224 |  | (1) | 13,992 |  | (2) | 16,216 |  |
| Cash payments | (2,423) |  |  | (13,115) |  |  | (15,538) |  |
| Balance at July 30, 2022 | $ | 582 |  |  | $ | 877 |  |  | $ | 1,459 |  |
| Current restructuring liabilities | $ | 582 |  |  | $ | 877 |  |  | $ | 1,459 |  |

[0000936395-23-000034:notes:62]
(1) Reflects employee costs associated with workforce reductions during the nine months ended July 30, 2022 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-23-000034:notes:63]
[same as prior period, unchanged from 0000936395-23-000027:notes:63]

[0000936395-23-000034:notes:64]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Interest income | $ | 12,835 |  |  | $ | 2,774 |  |  | $ | 30,365 |  |  | $ | 4,962 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 1,679 |  |  | (985) |  |  | (2,885) |  |  | (2,911) |  |
| Foreign currency exchange gains (losses) | (4,031) |  |  | (788) |  |  | (2,927) |  |  | 2,711 |  |
| Gain (loss) on cost method equity investments, net | (87) |  |  | — |  |  | 26,368 |  |  | 4,120 |  |
| Other | (209) |  |  | (635) |  |  | (210) |  |  | (4,022) |  |
| Interest and other income, net | $ | 10,187 |  |  | $ | 366 |  |  | $ | 50,711 |  |  | $ | 4,860 |  |

[0000936395-23-000034:notes:65]
During the first quarter of fiscal 2023, the acquisition of Tibit triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million. See Note 4 above. 
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. During the first nine months of fiscal 2023, Ciena recorded $2.9 million in foreign currency exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. During the first nine months of fiscal 2022, Ciena recorded $2.7 million in foreign currency exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During each of the first nine months of fiscal 2023 and 2022, Ciena recorded losses of $2.9 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-23-000034:notes:66]
INCOME TAXES
The effective tax rate for the quarter and nine months ended July 29, 2023 was higher than the effective tax rate for the

[0000936395-23-000034:notes:67]
quarter and nine months ended July 30, 2022, primarily due to the mandatory capitalization of research and development expenses in the third quarter and nine months ended July 29, 2023, in response to changes in U.S. tax policy.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-23-000034:notes:68]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-23-000034:notes:69]
|  | July 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 94,715 |  |  | $ | 1 |  |  | $ | (976) |  |  | $ | 93,740 |  |
| Corporate debt securities | 63,401 |  |  | 2 |  |  | (155) |  |  | 63,248 |  |
| Time deposits | 80,854 |  |  | 1 |  |  | (12) |  |  | 80,843 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |
| Included in cash equivalents | $ | 74,890 |  |  | $ | — |  |  | $ | — |  |  | $ | 74,890 |  |
| Included in short-term investments | 142,743 |  |  | 4 |  |  | (904) |  |  | 141,843 |  |
| Included in long-term investments | 21,337 |  |  | — |  |  | (239) |  |  | 21,098 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |

[0000936395-23-000034:notes:70]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

[0000936395-23-000034:notes:71]
The following table summarizes the final legal maturities of debt investments as of July 29, 2023 (in thousands):

[0000936395-23-000034:notes:72]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 217,633 |  |  | $ | 216,733 |  |
| Due in 1-2 years | 21,337 |  |  | 21,098 |  |
|  | $ | 238,970 |  |  | $ | 237,831 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-23-000034:notes:73]
FAIR VALUE MEASUREMENTS    As of the dates indicated, the following tables summarize the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-23-000034:notes:74]
|  | July 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 767,668 |  |  | $ | — |  |  | $ | — |  |  | $ | 767,668 |  |
| Bond mutual fund | 102,715 |  |  | — |  |  | — |  |  | 102,715 |  |
| Time deposits | 80,843 |  |  | — |  |  | — |  |  | 80,843 |  |
| Deferred compensation plan assets | 12,203 |  |  | — |  |  | — |  |  | 12,203 |  |
| U.S. government obligations | — |  |  | 93,740 |  |  | — |  |  | 93,740 |  |
| Corporate debt securities | — |  |  | 63,248 |  |  | — |  |  | 63,248 |  |
| Foreign currency forward contracts | — |  |  | 2,574 |  |  | — |  |  | 2,574 |  |
| Interest rate swaps | — |  |  | 19,528 |  |  | — |  |  | 19,528 |  |
| Total assets measured at fair value | $ | 963,429 |  |  | $ | 179,090 |  |  | $ | — |  |  | $ | 1,142,519 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 4,691 |  |  | $ | — |  |  | $ | 4,691 |  |
| Interest rate swaps | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4,723 |  |  | $ | — |  |  | $ | 4,723 |  |

[0000936395-23-000034:notes:75]
[same as prior period, unchanged from 0000936395-23-000027:notes:75]

[0000936395-23-000034:notes:76]
[same as prior period, unchanged from 0000936395-23-000027:notes:76]

[0000936395-23-000034:notes:77]
|  | July 29, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 944,714 |  |  | $ | 559 |  |  | $ | — |  |  | $ | 945,273 |  |
| Short-term investments | 6,512 |  |  | 135,331 |  |  | — |  |  | 141,843 |  |
| Prepaid expenses and other | — |  |  | 2,574 |  |  | — |  |  | 2,574 |  |
| Long-term investments | — |  |  | 21,098 |  |  | — |  |  | 21,098 |  |
| Other long-term assets | 12,203 |  |  | 19,528 |  |  | — |  |  | 31,731 |  |
| Total assets measured at fair value | $ | 963,429 |  |  | $ | 179,090 |  |  | $ | — |  |  | $ | 1,142,519 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 4,691 |  |  | $ | — |  |  | $ | 4,691 |  |
| Other long-term obligations | — |  |  | 32 |  |  | — |  |  | 32 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4,723 |  |  | $ | — |  |  | $ | 4,723 |  |

[0000936395-23-000034:notes:78]
[same as prior period, unchanged from 0000936395-23-000027:notes:78]

[0000936395-23-000034:notes:79]
[same as prior period, unchanged from 0000936395-23-000027:notes:79]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-23-000034:notes:80]
[same as prior period, unchanged from 0000936395-23-000027:notes:80]

[0000936395-23-000034:notes:81]
|  | July 29,2023 |  | October 29,2022 |
| Raw materials | $ | 771,955 |  |  | $ | 664,916 |  |
| Work-in-process | 51,763 |  |  | 18,232 |  |
| Finished goods | 333,544 |  |  | 258,584 |  |
| Deferred cost of goods sold | 77,521 |  |  | 41,084 |  |
| Gross inventories | 1,234,783 |  |  | 982,816 |  |
| Reserve for inventory excess and obsolescence | (42,261) |  |  | (36,086) |  |
| Inventories, net | $ | 1,192,522 |  |  | $ | 946,730 |  |

[0000936395-23-000034:notes:82]
The increase in raw materials inventory is related to the steps Ciena has taken to mitigate the impact of supply chain constraints on its business and customers in recent prior periods and a global market shortage of semiconductor components. The increase in finished goods inventories resulted primarily from planned fulfillment of customer advance orders for which some deliveries have been rescheduled.

[0000936395-23-000034:notes:83]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, 
which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first nine months of fiscal 2023, Ciena recorded a provision for inventory excess and obsolescence of $18.8 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-23-000034:notes:84]
[same as prior period, unchanged from 0000936395-23-000027:notes:83]

[0000936395-23-000034:notes:85]
|  | July 29,2023 |  | October 29,2022 |
| Contract assets for unbilled accounts receivable, net | $ | 142,305 |  |  | $ | 156,039 |  |
| Prepaid VAT and other taxes | 75,637 |  |  | 63,975 |  |
| Prepaid expenses | 55,997 |  |  | 55,440 |  |
| Product demonstration equipment, net | 41,691 |  |  | 35,929 |  |
| Capitalized contract acquisition costs | 24,349 |  |  | 33,516 |  |
| Other non-trade receivables | 17,734 |  |  | 24,026 |  |
| Foreign currency forward contracts | 2,574 |  |  | 251 |  |
| Deferred deployment expense | 1,405 |  |  | 877 |  |
|  | $ | 361,692 |  |  | $ | 370,053 |  |

[0000936395-23-000034:notes:86]
Depreciation of product demonstration equipment was $5.9 million during the first nine months of fiscal 2023 and $6.8 million during the first nine months of fiscal 2022.

[0000936395-23-000034:notes:87]
[same as prior period, unchanged from 0000936395-23-000027:notes:86]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-23-000034:notes:88]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-23-000034:notes:89]
|  | July 29, 2023 |  | October 29, 2022 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 503,618 |  |  | $ | (408,090) |  |  | $ | 95,528 |  |  | $ | 428,218 |  |  | $ | (386,300) |  |  | $ | 41,918 |  |
| In-process technology | 89,100 |  |  | — |  |  | 89,100 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 8,795 |  |  | (4,967) |  |  | 3,828 |  |  | 8,415 |  |  | (4,228) |  |  | 4,187 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 411,384 |  |  | (380,755) |  |  | 30,629 |  |  | 390,271 |  |  | (366,859) |  |  | 23,412 |  |
| Total intangible assets | $ | 1,012,897 |  |  | $ | (793,812) |  |  | $ | 219,085 |  |  | $ | 826,904 |  |  | $ | (757,387) |  |  | $ | 69,517 |  |

[0000936395-23-000034:notes:90]
The aggregate amortization expense of intangible assets was $36.3 million during the first nine months of fiscal 2023 and $36.5 million during the first nine months of fiscal 2022. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-23-000034:notes:91]
| Fiscal Year | Amount |  |  |
| Remaining fiscal 2023 | $ | 14,170 |  |  |  |
| 2024 | 39,836 |  |  |  |
| 2025 | 34,635 |  |  |  |
| 2026 | 23,348 |  |  |  |
| 2027 | 15,843 |  |  |  |
| Thereafter | 2,153 |  |  |  |
|  | $ | 129,985 |  | (1) |  |

[0000936395-23-000034:notes:92]
[same as prior period, unchanged from 0000936395-23-000027:notes:91]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-23-000034:notes:93]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of July 29, 2023 and October 29, 2022, as well as the changes to goodwill during the first nine months of fiscal 2023 (in thousands):

[0000936395-23-000034:notes:94]
|  |  | Balance at October 29, 2022 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at July 29, 2023 |
| Platform Software and Services |  | $ | 156,191 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services |  | 89,049 |  |  | — |  |  | — |  |  | — |  |  | 89,049 |  |
| Networking Platforms |  | 83,082 |  |  | 117,997 |  |  | — |  |  | 277 |  |  | 201,356 |  |
| Total |  | $ | 328,322 |  |  | $ | 117,997 |  |  | $ | — |  |  | $ | 277 |  |  | $ | 446,596 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-23-000034:notes:95]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-23-000034:notes:96]
|  | July 29,2023 |  | October 29,2022 |
| Compensation, payroll related tax and benefits | $ | 104,303 |  |  | $ | 126,338 |  |
| Warranty | 49,504 |  |  | 45,503 |  |
| Income taxes payable | 34,577 |  |  | 11,472 |  |
| Vacation | 30,344 |  |  | 26,396 |  |
| Foreign currency forward contracts | 4,691 |  |  | 15,604 |  |
| Interest payable | 9,779 |  |  | 4,793 |  |
| Finance lease liabilities | 4,063 |  |  | 3,758 |  |
| Other | 118,361 |  |  | 126,918 |  |
|  | $ | 355,622 |  |  | $ | 360,782 |  |

[0000936395-23-000034:notes:97]
[same as prior period, unchanged from 0000936395-23-000027:notes:96]

[0000936395-23-000034:notes:98]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Nine Months Ended July 30, 2022 |  | $ | 48,019 |  |  |  |  | 12,416 |  |  | (14,746) |  |  | $ | 45,689 |  |
| Nine Months Ended July 29, 2023 |  | $ | 45,503 |  |  |  |  | 18,860 |  |  | (14,859) |  |  | $ | 49,504 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-23-000034:notes:99]
DERIVATIVE INSTRUMENTSForeign Currency Derivatives 
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-23-000034:notes:100]
As of July 29, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $291.4 million and $272.2 million as of July 29, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-23-000034:notes:101]
In May 2023, Ciena entered into forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $48.6 million as of July 29, 2023. These foreign exchange contracts have maturities of 24 months or less and have been designated as net investment hedges.

[0000936395-23-000034:notes:102]
As of July 29, 2023 and October 29, 2022, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $255.9 million and $108.0 million as of July 29, 2023 and October 29, 2022, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-23-000034:notes:103]
[same as prior period, unchanged from 0000936395-23-000027:notes:102]

[0000936395-23-000034:notes:104]
[same as prior period, unchanged from 0000936395-23-000027:notes:103]

[0000936395-23-000034:notes:105]
Prior to amending the 2025 Term Loan (as defined in Note 16 below) to replace LIBOR with the Secured Overnight Financing Rate (“SOFR”), Ciena was exposed to floating rates of LIBOR interest on its 2025 Term Loan borrowings. Ciena hedged this risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023. In January 2023, Ciena entered into a LIBOR to SOFR basis swap (“basis swap”) to hedge its exposure to SOFR rate. The basis swap offsets the LIBOR exposure risk of the interest rate swaps and effectively fixes the SOFR rate for $350.0 million of the 2025 Term Loan at 2.883% through September 2023. The total notional amount of these swaps in effect was $350.0 million as of July 29, 2023 and October 29, 2022. In April 2022, Ciena entered into floating to fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the SOFR for $350.0 million of the 2025 Term Loan at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350.0 million as of July 29, 2023.

[0000936395-23-000034:notes:106]
In January 2023, Ciena entered into floating-to-fixed interest rate swap arrangements (“2028 interest rate swaps”). The 2028 interest rate swaps fix the SOFR rate of approximately $350.0 million of the principal amount of the 2030 Term Loan (as defined in Note 16 below) at 3.47% through January 2028. The total notional amount of these interest rate swaps in effect as of July 29, 2023 was $350.0 million.

[0000936395-23-000034:notes:107]
[same as prior period, unchanged from 0000936395-23-000027:notes:107]

[0000936395-23-000034:notes:108]
[same as prior period, unchanged from 0000936395-23-000027:notes:108]


## us-gaap:DebtDisclosureTextBlock

[0000936395-23-000034:notes:109]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loans Payable

[0000936395-23-000034:notes:110]
2025 Term Loan

[0000936395-23-000034:notes:111]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-23-000034:notes:112]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform.

[0000936395-23-000034:notes:113]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000034:notes:114]
|  |  | July 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 670,478 |  |  | $ | (687) |  |  | $ | (1,286) |  |  | $ | 668,505 |  |  | $ | 673,010 |  |

[0000936395-23-000034:notes:115]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.3 million as of July 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was approximately $0.5 million during the first nine months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000034:notes:116]
As of July 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000034:notes:117]
2030 Term Loan

[0000936395-23-000034:notes:118]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

[0000936395-23-000034:notes:119]
The Incremental Agreement amends the Credit Agreement and provides that the 2030 Term Loan will, among other things:

[0000936395-23-000034:notes:120]
•mature on January 19, 2030;

[0000936395-23-000034:notes:121]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

[0000936395-23-000034:notes:122]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-23-000034:notes:123]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

[0000936395-23-000034:notes:124]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

[0000936395-23-000034:notes:125]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-23-000034:notes:126]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-23-000034:notes:127]
|  |  | July 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 498,750 |  |  | $ | (2,308) |  |  | $ | (4,679) |  |  | $ | 491,763 |  |  |  |

[0000936395-23-000034:notes:128]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of July 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.4 million during the first nine months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-23-000034:notes:129]
As of July 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-23-000034:notes:130]
Outstanding Senior Notes Payable

[0000936395-23-000034:notes:131]
2030 Notes

[0000936395-23-000034:notes:132]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-23-000034:notes:133]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-23-000034:notes:134]
|  |  | July 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,438) |  |  | $ | 395,562 |  |  | $ | 395,045 |  |  |  |

[0000936395-23-000034:notes:135]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.4 million as of July 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.5 million and $0.4 million during the first nine months of fiscal 2023 and fiscal 2022, respectively.

[0000936395-23-000034:notes:136]
As of July 29, 2023, the estimated fair value of the 2030 Notes was $350.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-23-000034:notes:137]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended July 29, 2023 (in thousands):

[0000936395-23-000034:notes:138]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain before reclassifications | 2,075 |  |  | 17,070 |  |  |  |  | 11,763 |  |  | 17,981 |  |  | 48,889 |  |
| Amounts reclassified from AOCI | — |  |  | (7,756) |  |  |  |  | (6,266) |  |  | — |  |  | (14,022) |  |
| Balance at July 29, 2023 | $ | (890) |  |  | $ | (883) |  |  |  |  | $ | 14,894 |  |  | $ | (24,899) |  |  | $ | (11,778) |  |

[0000936395-23-000034:notes:139]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended July 30, 2022 (in thousands):

[0000936395-23-000034:notes:140]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 30, 2021 | $ | (164) |  |  | $ | 6,216 |  |  | $ | (12,179) |  |  | $ | 6,566 |  |  | $ | 439 |  |
| Other comprehensive gain (loss) before reclassifications | (2,184) |  |  | (5,207) |  |  | 2,786 |  |  | (22,783) |  |  | (27,388) |  |
| Amounts reclassified from AOCI | — |  |  | (1,569) |  |  | 6,639 |  |  | — |  |  | 5,070 |  |
| Balance at July 30, 2022 | $ | (2,348) |  |  | $ | (560) |  |  | $ | (2,754) |  |  | $ | (16,217) |  |  | $ | (21,879) |  |

[0000936395-23-000034:notes:141]
[same as prior period, unchanged from 0000936395-23-000027:notes:141]


## us-gaap:EarningsPerShareTextBlock

[0000936395-23-000034:notes:142]
[same as prior period, unchanged from 0000936395-23-000027:notes:142]

[0000936395-23-000034:notes:143]
[same as prior period, unchanged from 0000936395-23-000027:notes:143]

[0000936395-23-000034:notes:144]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Net income | $ | 29,733 |  |  | $ | 10,512 |  |  | $ | 163,628 |  |  | $ | 95,257 |  |
| Basic weighted average shares outstanding | 149,690 |  |  | 149,862 |  |  | 149,472 |  |  | 152,083 |  |
| Effect of dilutive potential common shares | 287 |  |  | 601 |  |  | 395 |  |  | 1,126 |  |
| Diluted weighted average shares | 149,977 |  |  | 150,463 |  |  | 149,867 |  |  | 153,209 |  |
| Basic EPS | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |  | $ | 0.63 |  |
| Diluted EPS | $ | 0.20 |  |  | $ | 0.07 |  |  | $ | 1.09 |  |  | $ | 0.62 |  |
| Antidilutive employee share-based awards, excluded | 3,383 |  |  | 1,640 |  |  | 2,567 |  |  | 1,264 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-23-000034:notes:145]
[same as prior period, unchanged from 0000936395-23-000027:notes:145]

[0000936395-23-000034:notes:146]
[same as prior period, unchanged from 0000936395-23-000027:notes:146]

[0000936395-23-000034:notes:147]
During the third quarter of fiscal 2023, Ciena repurchased an additional 1.4 million shares of its common stock for an aggregate purchase price of $61.2 million at an average price of $42.48 per share. As of July 29, 2023, Ciena (i) has repurchased 9.9 million shares for an aggregate purchase price of $561.2 million at an average price of $56.83 per share, and (ii) has an aggregate of $438.8 million authorized and remaining under its stock repurchase program. The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-23-000034:notes:148]
[same as prior period, unchanged from 0000936395-23-000027:notes:148]

[0000936395-23-000034:notes:149]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $29.8 million for the shares of Ciena’s stock repurchased during the first nine months of 
fiscal 2023 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-23-000034:notes:150]
[same as prior period, unchanged from 0000936395-23-000027:notes:150]

[0000936395-23-000034:notes:151]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Products | $ | 1,118 |  |  | $ | 1,002 |  |  | $ | 3,324 |  |  | $ | 2,960 |  |
| Services | 2,687 |  |  | 1,940 |  |  | 7,643 |  |  | 5,467 |  |
| Share-based compensation expense included in cost of goods sold | 3,805 |  |  | 2,942 |  |  | 10,967 |  |  | 8,427 |  |
| Research and development | 10,954 |  |  | 8,233 |  |  | 30,919 |  |  | 23,372 |  |
| Selling and marketing | 8,770 |  |  | 8,075 |  |  | 25,949 |  |  | 23,196 |  |
| General and administrative | 9,377 |  |  | 7,579 |  |  | 27,313 |  |  | 22,825 |  |
| Share-based compensation expense included in operating expense | 29,101 |  |  | 23,887 |  |  | 84,181 |  |  | 69,393 |  |
| Share-based compensation expense capitalized in inventory, net | 127 |  |  | 28 |  |  | 257 |  |  | 7 |  |
| Total share-based compensation expense | $ | 33,033 |  |  | $ | 26,857 |  |  | $ | 95,405 |  |  | $ | 77,827 |  |

[0000936395-23-000034:notes:152]
As of July 29, 2023, total unrecognized share-based compensation expense was approximately $231.5 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.45 years.

[0000936395-23-000034:notes:153]
Stock Unit Awards
Beginning in December 2022, Ciena introduced a benefit, under which, upon completion of ten years of service and reaching age 60, executive officers who are residents of the United States, the United Kingdom, or Canada and who provide 12 months’ notice of their retirement will receive continued vesting of all of their granted but unvested restricted stock unit (“RSU”) awards and a pro-rated amount of their performance stock unit awards and market stock unit awards. Other employees in these countries will be subject to the same eligibility and notice requirements, but will receive acceleration of their granted but unvested RSU awards upon retirement. This program accelerates the recognition of share-based compensation expense.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-23-000034:notes:154]
[same as prior period, unchanged from 0000936395-23-000027:notes:153]

[0000936395-23-000034:notes:155]
[same as prior period, unchanged from 0000936395-23-000027:notes:154]

[0000936395-23-000034:notes:156]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 29, 2023, equipment, building, furniture and fixtures, net, totaled $287.5 million, and operating ROU assets totaled $40.5 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of July 29, 2023, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-23-000034:notes:157]
|  | July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 198,937 |  |  | — |  |  | 20,148 |  |  | — |  |  | $ | 219,085 |  |
| Goodwill | $ | 201,356 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 446,596 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 48,165 |  |  | $ | 48,165 |  |

[0000936395-23-000034:notes:158]
[same as prior period, unchanged from 0000936395-23-000027:notes:157]

[0000936395-23-000034:notes:159]
[same as prior period, unchanged from 0000936395-23-000027:notes:158]

[0000936395-23-000034:notes:160]
[same as prior period, unchanged from 0000936395-23-000027:notes:159]

[0000936395-23-000034:notes:161]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 171,380 |  |  | $ | 108,282 |  |  | $ | 588,281 |  |  | $ | 395,176 |  |
| Platform Software and Services | 49,691 |  |  | 39,646 |  |  | 136,028 |  |  | 132,698 |  |
| Blue Planet Automation Software and Services | (12,072) |  |  | (10,139) |  |  | (30,044) |  |  | (17,693) |  |
| Global Services | 50,550 |  |  | 52,965 |  |  | 137,190 |  |  | 158,808 |  |
| Total segment profit | 259,549 |  |  | 190,754 |  |  | 831,455 |  |  | 668,989 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 118,266 |  |  | 105,880 |  |  | 367,156 |  |  | 344,700 |  |
| General and administrative | 49,349 |  |  | 41,121 |  |  | 151,184 |  |  | 131,191 |  |
| Significant asset impairments and restructuring costs | 4,174 |  |  | 7,692 |  |  | 16,625 |  |  | 20,203 |  |
| Amortization of intangible assets | 9,487 |  |  | 8,919 |  |  | 26,773 |  |  | 26,757 |  |
| Acquisition and integration costs | 59 |  |  | 35 |  |  | 3,474 |  |  | 598 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 10,187 |  |  | 366 |  |  | 50,711 |  |  | 4,860 |  |
| Interest expense | (24,060) |  |  | (12,642) |  |  | (63,819) |  |  | (33,275) |  |
| Less: Provision for income taxes | 34,608 |  |  | 4,319 |  |  | 89,507 |  |  | 21,868 |  |
| Net income | $ | 29,733 |  |  | $ | 10,512 |  |  | $ | 163,628 |  |  | $ | 95,257 |  |

[0000936395-23-000034:notes:162]
[same as prior period, unchanged from 0000936395-23-000027:notes:161]

[0000936395-23-000034:notes:163]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods indicated, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-23-000034:notes:164]
|  | July 29,2023 |  | October 29,2022 |
| Canada | $ | 241,416 |  |  | $ | 226,451 |  |
| United States | 46,936 |  |  | 47,515 |  |
| Other International | 39,585 |  |  | 38,921 |  |
| Total | $ | 327,937 |  |  | $ | 312,887 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-23-000034:notes:165]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-23-000034:notes:166]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-23-000034:notes:167]
Litigation

[0000936395-23-000034:notes:168]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-23-000034:notes:169]
SUBSEQUENT EVENTSStock Repurchase ProgramFrom the end of the third quarter of fiscal 2023 through September 1, 2023, Ciena repurchased an additional 0.9 million shares of its common stock, for an aggregate purchase price of $38.8 million at an average price of $41.67 per share, inclusive of repurchases pending settlement. As of September 1, 2023, Ciena has repurchased an aggregate of 10.8 million shares and has an aggregate of $400.0 million of authorized funds remaining under its stock repurchase program.
