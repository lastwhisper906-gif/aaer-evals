# CIEN MD&A — 0000936395-23-000034


## mdna

[0000936395-23-000034:mdna:1]
[same as prior period, unchanged from 0000936395-23-000027:mdna:1]

[0000936395-23-000034:mdna:2]
[same as prior period, unchanged from 0000936395-23-000027:mdna:2]

[0000936395-23-000034:mdna:3]
[same as prior period, unchanged from 0000936395-23-000027:mdna:3]

[0000936395-23-000034:mdna:4]
[same as prior period, unchanged from 0000936395-23-000027:mdna:4]

[0000936395-23-000034:mdna:5]
[same as prior period, unchanged from 0000936395-23-000027:mdna:5]

[0000936395-23-000034:mdna:6]
We are a networking systems, services, and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and

[0000936395-23-000034:mdna:7]
access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that are informed by analytics and intelligence. Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Manage, Control and Plan (“MCP”) applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software we also enable complete service lifecycle management automation with productized open source software (OSS) and service assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-23-000034:mdna:8]
[same as prior period, unchanged from 0000936395-23-000027:mdna:7]

[0000936395-23-000034:mdna:9]
From the second quarter of fiscal 2021 through the third quarter of fiscal 2022, we received an unprecedented volume of orders for our products and services. Our quarterly order volumes during this period significantly exceeded our revenue and historical order volumes, with concentration of orders among certain existing Web-scale and North America-based service provider customers. We believe some portion of these orders reflected customer acceleration of future orders due to lengthened lead times or the implementation of security of supply strategies to address the supply constraints described below. We also believe some portion of these orders reflected pre-pandemic design wins for which orders were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022. We have continued to experience reduced orders relative to revenue in the first nine months of fiscal 2023 and order volumes lower than those received during the second quarter of fiscal 2021 through the third quarter of fiscal 2022. We believe this reduction has been in part due to customers no longer needing to place significant advanced orders as supply chain conditions and lead times have improved. However, over the longer term, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term opportunities for our business.

[0000936395-23-000034:mdna:10]
[same as prior period, unchanged from 0000936395-23-000027:mdna:10]

[0000936395-23-000034:mdna:11]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and was therefore less predictable and subject to fluctuation. As a result of elevated order volumes in recent prior periods and the supply chain constraints described below, however, we generated a significant backlog of customer orders, and, more recently, our revenue has been more significantly impacted by availability of supply, as well as customer delivery deferrals of existing backlog. Our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. As supply chain conditions have begun to improve and we have been able to increase shipment volumes and reduce lead times, our backlog has decreased during the first nine months of fiscal 2023. We expect our backlog to continue to reduce during the remainder of fiscal 2023 as supply chain conditions improve and customers place fewer advanced orders. As that happens, we expect our reliance upon securing quarterly book to revenue orders to grow and those orders to represent a more typical composition of our quarterly revenue over time.

[0000936395-23-000034:mdna:12]
The timing and degree to which we fulfill our backlog will have a significant impact on our rate of revenue growth and can be affected by factors outside of our control, including the supply chain conditions and availability of components described below, and customer readiness and willingness to receive shipment against existing orders. During the first nine months of fiscal 2023, certain customers, including communications service providers and cable and multiservice operators in North America and Web-scale providers, that had earlier placed significant advanced orders, rescheduled deliveries for a portion of such orders, including in some cases until after the end of fiscal 2023. We believe that this was the result of a number of factors, including their significant order levels during a period of supply chain constraints, the recent, rapid improvement in our delivery lead times, and their inventory levels. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See the risk factors captioned “Our backlog may not be an accurate indicator of our level and timing of future revenues.” and “Our revenue, gross margin, and operating results can fluctuate significantly and unpredictably from quarter to quarter.” in Item 1A of Part II of this report for further discussion of risks related to our backlog and order delivery timing.

[0000936395-23-000034:mdna:13]
[same as prior period, unchanged from 0000936395-23-000027:mdna:13]

[0000936395-23-000034:mdna:14]
In the face of demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits, and other electronic components used in most of our products, experienced

[0000936395-23-000034:mdna:15]
substantial constraint and disruption in recent prior periods. As a result, we experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. While reliability of supply has improved, and the majority of our suppliers have been able to deliver by their promised, though extended, lead times, we have in the past experienced and could in the future experience volatility from suppliers of integrated circuit components that represent a small fraction of our overall materials, but which are essential for delivering finished products. This volatility can result in receiving fewer components than expected in a given period, which can adversely impact our revenue. We expect that the extended lead times and elevated supply chain costs we have experienced will persist at least through the first half of fiscal 2024. We expect these supply conditions to continue to impact our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. It is unclear when the supply environment will become less volatile and what impacts it will have on our business and results of operations in future periods.

[0000936395-23-000034:mdna:16]
To mitigate the impact of these supply conditions on our business and customers, we have placed advanced orders for inventory and accumulating components that are in available supply. We believe that this approach positions us to produce finished goods more quickly when supply constraints ease for those components in shorter supply. As a result of these measures, as well as the rescheduling of deliveries by some of our customers as discussed above, our inventory increased from $946.7 million at the end of fiscal 2022 to $1.2 billion at the end of the third quarter of fiscal 2023. We have also implemented additional mitigation strategies, including expanding manufacturing capacity, implementing multi-sourcing activities, qualifying alternative parts, and redesigning products, and expect, over time, to realize certain benefits of these activities. Together with increased costs of supply, these mitigation strategies have impacted, and we expect them to continue to impact, our result of operations and cash from operations. See “Risk Factors” in Item 1A of Part II of this report for further discussion of risks related to our supply chain and our mitigation activities.

[0000936395-23-000034:mdna:17]
[same as prior period, unchanged from 0000936395-23-000027:mdna:19]

[0000936395-23-000034:mdna:18]
[same as prior period, unchanged from 0000936395-23-000027:mdna:20]

[0000936395-23-000034:mdna:19]
[same as prior period, unchanged from 0000936395-23-000027:mdna:21]

[0000936395-23-000034:mdna:20]
[same as prior period, unchanged from 0000936395-23-000027:mdna:22]

[0000936395-23-000034:mdna:21]
[same as prior period, unchanged from 0000936395-23-000027:mdna:23]

[0000936395-23-000034:mdna:22]
[same as prior period, unchanged from 0000936395-23-000027:mdna:24]

[0000936395-23-000034:mdna:23]
During the third quarter and first nine months of fiscal 2023, approximately 14.2% and 15.0% of our revenue was non-U.S. Dollar-denominated, respectively, primarily including sales in Euros, Canadian Dollars, and British Pounds. During the third quarter of fiscal 2023 as compared to the third quarter of fiscal 2022, and the first nine months of fiscal 2023 as compared to the first nine months of fiscal 2022, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $1.1 million, or 0.1%, as compared to the third quarter of fiscal 2022, and our revenue reported in U.S. Dollars was adversely impacted by approximately $5.6 million, or 0.2%, as compared to the first nine months of fiscal 2022.

[0000936395-23-000034:mdna:24]
[same as prior period, unchanged from 0000936395-23-000027:mdna:26]

[0000936395-23-000034:mdna:25]
[same as prior period, unchanged from 0000936395-23-000027:mdna:27]

[0000936395-23-000034:mdna:26]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | 563,837 |  |  |  |  | 27.5 | % |  | $ | 2,239,180 |  |  | $ | 1,730,066 |  |  |  |  | 29.4 | % |
| %** | 67.3 | % |  | 65.0 | % |  |  |  |  |  | 68.7 | % |  | 65.0 | % |  |  |  |  |
| Routing and Switching | 127,563 |  |  | 100,741 |  |  |  |  | 26.6 | % |  | 377,378 |  |  | 295,638 |  |  |  |  | 27.6 | % |
| %** | 12.0 | % |  | 11.6 | % |  |  |  |  |  | 11.6 | % |  | 11.1 | % |  |  |  |  |
| Total Networking Platforms | 846,560 |  |  | 664,578 |  |  |  |  | 27.4 | % |  | 2,616,558 |  |  | 2,025,704 |  |  |  |  | 29.2 | % |
| %** | 79.3 | % |  | 76.6 | % |  |  |  |  |  | 80.3 | % |  | 76.1 | % |  |  |  |  |
| Platform Software and Services | 78,880 |  |  | 63,483 |  |  |  |  | 24.3 | % |  | 221,768 |  |  | 205,557 |  |  |  |  | 7.9 | % |
| %** | 7.4 | % |  | 7.3 | % |  |  |  |  |  | 6.8 | % |  | 7.7 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 13,167 |  |  | 17,342 |  |  |  |  | (24.1) | % |  | 49,139 |  |  | 55,334 |  |  |  |  | (11.2) | % |
| %** | 1.2 | % |  | 2.0 | % |  |  |  |  |  | 1.5 | % |  | 2.1 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 72,887 |  |  | 72,760 |  |  |  |  | 0.2 | % |  | 213,938 |  |  | 219,270 |  |  |  |  | (2.4) | % |
| %** | 6.8 | % |  | 8.4 | % |  |  |  |  |  | 6.6 | % |  | 8.3 | % |  |  |  |  |
| Installation and Deployment | 46,840 |  |  | 38,704 |  |  |  |  | 21.0 | % |  | 120,901 |  |  | 120,504 |  |  |  |  | 0.3 | % |
| %** | 4.4 | % |  | 4.4 | % |  |  |  |  |  | 3.7 | % |  | 4.5 | % |  |  |  |  |
| Consulting and Network Design | 9,552 |  |  | 11,114 |  |  |  |  | (14.1) | % |  | 34,758 |  |  | 35,282 |  |  |  |  | (1.5) | % |
| %** | 0.9 | % |  | 1.3 | % |  |  |  |  |  | 1.1 | % |  | 1.3 | % |  |  |  |  |
| Total Global Services | 129,279 |  |  | 122,578 |  |  |  |  | 5.5 | % |  | 369,597 |  |  | 375,056 |  |  |  |  | (1.5) | % |
| %** | 12.1 | % |  | 14.1 | % |  |  |  |  |  | 11.4 | % |  | 14.1 | % |  |  |  |  |
| Total revenue | $ | 1,067,886 |  |  | $ | 867,981 |  |  |  |  | 23.0 | % |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |  |  |  | 22.4 | % |

[0000936395-23-000034:mdna:27]
[same as prior period, unchanged from 0000936395-23-000027:mdna:29]

[0000936395-23-000034:mdna:28]
[same as prior period, unchanged from 0000936395-23-000027:mdna:30]

[0000936395-23-000034:mdna:29]
[same as prior period, unchanged from 0000936395-23-000027:mdna:31]

[0000936395-23-000034:mdna:30]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:31]
•Networking Platforms segment revenue increased by $182.0 million, reflecting product line sales increases of $155.2 million of our Converged Packet Optical products and $26.8 million of our Routing and Switching products.

[0000936395-23-000034:mdna:32]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $120.0 million of our 6500 Reconfigurable Line System (RLS) products, primarily to Web-scale providers and $61.8 million of our 6500 Packet-Optical Platform, primarily to enterprise customers and communications service providers, partially offset by a sales decrease of $27.4 million of our Waveserver® products, primarily to Web-scale providers.

[0000936395-23-000034:mdna:33]
•Routing and Switching sales increased, primarily reflecting sales increases of $29.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, enterprise customers and communications service providers, and $6.8 million of our 8100 Coherent IP networking platforms, primarily to communications service providers, partially offset by a sales decrease of $16.5 million of our virtualization software primarily to communications service providers.

[0000936395-23-000034:mdna:34]
•Platform Software and Services segment revenue increased by $15.4 million, primarily reflecting a sales increase of $14.8 million in our software maintenance services, primarily for our MCP software platform, to communications service providers.

[0000936395-23-000034:mdna:35]
•Blue Planet Automation Software and Services segment revenue decreased by $4.2 million reflecting sales decreases of $2.5 million in professional software services and $1.7 million in software platforms, both primarily to communications service providers.

[0000936395-23-000034:mdna:36]
•Global Services segment revenue increased by $6.7 million, primarily reflecting a sales increase of $8.1 million of our installation and deployment services, partially offset by a sales decrease of $1.6 million of our consulting and network design services.

[0000936395-23-000034:mdna:37]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:38]
•Networking Platforms segment revenue increased by $590.8 million, reflecting product line sales increases of $509.1 million of our Converged Packet Optical products and $81.7 million of our Routing and Switching products.

[0000936395-23-000034:mdna:39]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $245.5 million of our 6500

[0000936395-23-000034:mdna:40]
Packet-Optical Platform, primarily to communications service providers and enterprise customers, $240.3 million of our 6500 RLS products, primarily to Web-scale providers, and $19.7 million of our Waveserver® products, primarily to enterprise customers and communications service providers, partially offset by decreased sales to cable and multiservice operators.

[0000936395-23-000034:mdna:41]
◦Routing and Switching sales increased, primarily reflecting sales increases of $42.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators and enterprise customers, $16.0 million of our virtualization software and $14.3 million of our 8100 Coherent IP networking platforms, both primarily to communications service providers.

[0000936395-23-000034:mdna:42]
•Platform Software and Services segment revenue increased by $16.2 million, primarily reflecting a sales increase of $34.8 million in our software maintenance services, primarily for our MCP software platform, to communications service providers, partially offset by a sales decrease of $18.6 million in sales of software platforms, primarily due to decreased sales of our MCP software platform.

[0000936395-23-000034:mdna:43]
•Blue Planet Automation Software and Services segment revenue decreased by $6.2 million, primarily reflecting sales decreases of $3.3 million in software platform sales and $2.9 million in professional software services.

[0000936395-23-000034:mdna:44]
•Global Services segment revenue decreased by $5.5 million, primarily reflecting a sales decrease of $5.3 million of our maintenance support and training.

[0000936395-23-000034:mdna:45]
[same as prior period, unchanged from 0000936395-23-000027:mdna:48]

[0000936395-23-000034:mdna:46]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for the quarter and nine months ended July 29, 2023 was primarily driven by increased sales in the United States. The increase in our APAC region revenue for the quarter and nine months ended July 29, 2023 was primarily driven by increased sales in India and Australia. The increase in our EMEA region revenue for the quarter and nine months ended July 29, 2023 was primarily driven by increased sales in the Netherlands.

[0000936395-23-000034:mdna:47]
[same as prior period, unchanged from 0000936395-23-000027:mdna:50]

[0000936395-23-000034:mdna:48]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Americas | $ | 749,479 |  |  | $ | 617,366 |  |  |  |  | 21.4 | % |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |  |  |  | 20.7 | % |
| %** | 70.2 | % |  | 71.1 | % |  |  |  |  |  | 70.9 | % |  | 71.9 | % |  |  |  |  |
| EMEA | 152,834 |  |  | 124,185 |  |  |  |  | 23.1 | % |  | 479,053 |  |  | 420,075 |  |  |  |  | 14.0 | % |
| %** | 14.3 | % |  | 14.3 | % |  |  |  |  |  | 14.7 | % |  | 15.8 | % |  |  |  |  |
| APAC | 165,573 |  |  | 126,430 |  |  |  |  | 31.0 | % |  | 469,075 |  |  | 328,226 |  |  |  |  | 42.9 | % |
| %** | 15.5 | % |  | 14.6 | % |  |  |  |  |  | 14.4 | % |  | 12.3 | % |  |  |  |  |
| Total | $ | 1,067,886 |  |  | $ | 867,981 |  |  |  |  | 23.0 | % |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |  |  |  | 22.4 | % |

[0000936395-23-000034:mdna:49]
[same as prior period, unchanged from 0000936395-23-000027:mdna:52]

[0000936395-23-000034:mdna:50]
[same as prior period, unchanged from 0000936395-23-000027:mdna:53]

[0000936395-23-000034:mdna:51]
[same as prior period, unchanged from 0000936395-23-000027:mdna:54]

[0000936395-23-000034:mdna:52]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:53]
•Americas revenue increased by $132.1 million, primarily reflecting sales increases of $124.1 million within our Networking Platforms segment and $10.6 million within our Platform Software and Services segment. These sales increases were partially offset by a sales decrease of $3.6 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment reflects product line sales increases of $115.8 million of our Converged Packet Optical products and $8.3 million of our Routing and Switching products. The increase within our Converged Packet Optical product line was primarily related to sales increases of $97.7 million of our 6500 RLS products, primarily to Web-scale providers, and $36.0 million of our 6500 Packet-Optical Platform primarily to communications service providers. These increases were offset by a sales decrease of $16.1 million of our Waveserver® products, primarily to Web-scale providers. The increase within our Routing and Switching product line reflected sales increases of $14.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to enterprise customers and cable and multiservice operators, and $6.6 million of our 8100 Coherent IP networking platforms, primarily to communications service providers. These increases were partially offset by a sales decrease of $16.5 million of our virtualization software, primarily to communications service providers.

[0000936395-23-000034:mdna:54]
•EMEA revenue increased by $28.6 million, reflecting sales increases of $19.3 million within our

[0000936395-23-000034:mdna:55]
Networking Platforms segment, $4.3 million within our Global Services segment, $3.7 million within our Platform Software and Services segment, and $1.3 million within our Blue Planet Automation Software and Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $14.9 million of our Routing and Switching product line, primarily related to a sales increase of $13.8 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communications service providers.

[0000936395-23-000034:mdna:56]
•APAC revenue increased by $39.1 million, primarily reflecting a sales increase of $38.6 million within our

[0000936395-23-000034:mdna:57]
Networking Platforms segment. The increase within our Networking Platforms segment primarily reflects a product line sales increase of $35.0 million of Converged Packet Optical products, which includes a sales increase of $27.5 million of our 6500 Packet-Optical Platform, primarily to enterprise customers.

[0000936395-23-000034:mdna:58]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:59]
•Americas revenue increased by $395.6 million, primarily reflecting sales increases of $400.4 million within our Networking Platforms segment and $10.4 million within our Platform Software and Services segment. These sales increases were partially offset by sales decreases of $9.9 million within our Blue Planet Automation Software and Services segment and $5.4 million within our Global Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $344.4 million of Converged Packet Optical products and $56.0 million of Routing and Switching products. Our Converged Packet Optical revenue primarily reflects sales increases of $192.9 million of our 6500 RLS products, primarily to Web-scale providers and $138.9 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers. Routing and Switching product line sales primarily reflect sales increases of $22.3 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators and enterprise customers, $16.0 million of our virtualization software, and $13.1 million of our 8100 Coherent IP networking platforms, both primarily to communications service providers.

[0000936395-23-000034:mdna:60]
•EMEA revenue increased by $59.0 million, primarily reflecting sales increases of $45.1 million within our Networking Platforms segment, $8.2 million within our Blue Planet Automation Software and Services segment, and $5.2 million within our Platform Software and Services segment. Our Networking Platforms segment revenue increase primarily reflects product line sales increases of $25.7 million of Converged Packet Optical products and $19.4 million of our Routing and Switching products. Converged Packet Optical revenue primarily reflects a sales increase of $42.9 million of our 6500 RLS products, primarily to Web-scale providers, partially offset by a sales decrease of $15.6 million of our Waveserver® products, primarily to Web-scale providers. Routing and Switching product line sales primarily reflect a sales increase of $16.7 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communications service providers.

[0000936395-23-000034:mdna:61]
•APAC revenue increased by $140.8 million, primarily reflecting a sales increase of $145.4 million within our

[0000936395-23-000034:mdna:62]
Networking Platforms segment. This sales increase was partially offset by a sales decrease of $4.5 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase primarily reflects a product line sales increase of $139.1 million of Converged Packet Optical products, including a sales increase of $108.0 million of our 6500 Packet-Optical Platform, primarily to communications service providers and enterprise customers.

[0000936395-23-000034:mdna:63]
[same as prior period, unchanged from 0000936395-23-000027:mdna:66]

[0000936395-23-000034:mdna:64]
[same as prior period, unchanged from 0000936395-23-000027:mdna:67]

[0000936395-23-000034:mdna:65]
[same as prior period, unchanged from 0000936395-23-000027:mdna:68]

[0000936395-23-000034:mdna:66]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Total revenue | $ | 1,067,886 |  |  | $ | 867,981 |  |  |  |  | 23.0 | % |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |  |  |  | 22.4 | % |
| Total cost of goods sold | 618,945 |  |  | 527,202 |  |  |  |  | 17.4 | % |  | 1,864,492 |  |  | 1,534,904 |  |  |  |  | 21.5 | % |
| Gross profit | $ | 448,941 |  |  | $ | 340,779 |  |  |  |  | 31.7 | % |  | $ | 1,392,570 |  |  | $ | 1,126,747 |  |  |  |  | 23.6 | % |
| %** | 42.0 | % |  | 39.3 | % |  |  |  |  |  | 42.8 | % |  | 42.3 | % |  |  |  |  |

[0000936395-23-000034:mdna:67]
[same as prior period, unchanged from 0000936395-23-000027:mdna:70]

[0000936395-23-000034:mdna:68]
[same as prior period, unchanged from 0000936395-23-000027:mdna:71]

[0000936395-23-000034:mdna:69]
[same as prior period, unchanged from 0000936395-23-000027:mdna:72]

[0000936395-23-000034:mdna:70]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Product revenue | $ | 865,197 |  |  | $ | 684,284 |  |  |  |  | 26.4 | % |  | $ | 2,678,242 |  |  | $ | 2,109,239 |  |  |  |  | 27.0 | % |
| Product cost of goods sold | 516,900 |  |  | 434,756 |  |  |  |  | 18.9 | % |  | 1,559,120 |  |  | 1,259,378 |  |  |  |  | 23.8 | % |
| Product gross profit | $ | 348,297 |  |  | $ | 249,528 |  |  |  |  | 39.6 | % |  | $ | 1,119,122 |  |  | $ | 849,861 |  |  |  |  | 31.7 | % |
| %** | 40.3 | % |  | 36.5 | % |  |  |  |  |  | 41.8 | % |  | 40.3 | % |  |  |  |  |

[0000936395-23-000034:mdna:71]
[same as prior period, unchanged from 0000936395-23-000027:mdna:74]

[0000936395-23-000034:mdna:72]
[same as prior period, unchanged from 0000936395-23-000027:mdna:75]

[0000936395-23-000034:mdna:73]
[same as prior period, unchanged from 0000936395-23-000027:mdna:76]

[0000936395-23-000034:mdna:74]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Services revenue | $ | 202,689 |  |  | $ | 183,697 |  |  |  |  | 10.3 | % |  | $ | 578,820 |  |  | $ | 552,412 |  |  |  |  | 4.8 | % |
| Services cost of goods sold | 102,045 |  |  | 92,446 |  |  |  |  | 10.4 | % |  | 305,372 |  |  | 275,526 |  |  |  |  | 10.8 | % |
| Services gross profit | $ | 100,644 |  |  | $ | 91,251 |  |  |  |  | 10.3 | % |  | $ | 273,448 |  |  | $ | 276,886 |  |  |  |  | (1.2) | % |
| % ** | 49.7 | % |  | 49.7 | % |  |  |  |  |  | 47.2 | % |  | 50.1 | % |  |  |  |  |

[0000936395-23-000034:mdna:75]
[same as prior period, unchanged from 0000936395-23-000027:mdna:78]

[0000936395-23-000034:mdna:76]
[same as prior period, unchanged from 0000936395-23-000027:mdna:79]

[0000936395-23-000034:mdna:77]
[same as prior period, unchanged from 0000936395-23-000027:mdna:80]

[0000936395-23-000034:mdna:78]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:79]
•Gross profit increased by $108.2 million. Gross margin increased by 270 basis points, primarily due to improved manufacturing efficiencies and lower product costs, partially offset by a higher concentration of lower margin “common” equipment and photonics sales.

[0000936395-23-000034:mdna:80]
•Gross profit on products increased by $98.8 million. Product gross margin increased by 380 basis points, primarily due to improved manufacturing efficiencies and lower product costs, partially offset by a higher concentration of lower margin product mix as described above.

[0000936395-23-000034:mdna:81]
•Gross profit on services increased by $9.4 million. Services gross margin remained relatively unchanged.

[0000936395-23-000034:mdna:82]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:83]
•Gross profit increased by $265.8 million. Gross margin slightly increased by 50 basis points, primarily due to improved manufacturing efficiencies and lower product costs, partially offset by a higher concentration of lower margin “common” equipment and photonics sales, and lower services margins.

[0000936395-23-000034:mdna:84]
•Gross profit on products increased by $269.3 million. Product gross margin increased by 150 basis points, primarily due to improved manufacturing efficiencies and lower product costs, partially offset by a higher concentration of lower margin product mix as described above.

[0000936395-23-000034:mdna:85]
•Gross profit on services decreased by $3.4 million. Services gross margin decreased by 290 basis points, primarily due to lower maintenance support and training revenue, lower margin on certain installation and deployment projects, and losses incurred on certain Blue Planet software service projects. These decreases were partially offset by increased Platform Software services revenue.

[0000936395-23-000034:mdna:86]
[same as prior period, unchanged from 0000936395-23-000027:mdna:89]

[0000936395-23-000034:mdna:87]
[same as prior period, unchanged from 0000936395-23-000027:mdna:90]

[0000936395-23-000034:mdna:88]
Approximately 51.8% and 50.1% of our operating expense was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2023, respectively, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the third quarter of fiscal 2023, as compared to the third quarter of fiscal 2022, and during the first nine months of fiscal 2023, as compared to the first nine months of fiscal 2022, the U.S. Dollar primarily strengthened against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars slightly decreased by approximately $2.8 million, or 0.8%, and $24.6 million, or 2.2%, respectively.

[0000936395-23-000034:mdna:89]
[same as prior period, unchanged from 0000936395-23-000027:mdna:92]

[0000936395-23-000034:mdna:90]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Research and development | $ | 189,392 |  |  | $ | 150,025 |  |  |  |  | 26.2 | % |  | $ | 561,115 |  |  | $ | 457,758 |  |  |  |  | 22.6 | % |
| %** | 17.7 | % |  | 17.3 | % |  |  |  |  |  | 17.2 | % |  | 17.2 | % |  |  |  |  |
| Selling and marketing | 118,266 |  |  | 105,880 |  |  |  |  | 11.7 | % |  | 367,156 |  |  | 344,700 |  |  |  |  | 6.5 | % |
| %** | 11.1 | % |  | 12.2 | % |  |  |  |  |  | 11.4 | % |  | 13.0 | % |  |  |  |  |
| General and administrative | 49,349 |  |  | 41,121 |  |  |  |  | 20.0 | % |  | 151,184 |  |  | 131,191 |  |  |  |  | 15.2 | % |
| %** | 4.6 | % |  | 4.7 | % |  |  |  |  |  | 4.6 | % |  | 4.9 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,174 |  |  | 7,692 |  |  |  |  | (45.7) | % |  | 16,625 |  |  | 20,203 |  |  |  |  | (17.7) | % |
| %** | 0.4 | % |  | 0.9 | % |  |  |  |  |  | 0.5 | % |  | 0.8 | % |  |  |  |  |
| Amortization of intangible assets | 9,487 |  |  | 8,919 |  |  |  |  | 6.4 | % |  | 26,773 |  |  | 26,757 |  |  |  |  | 0.1 | % |
| %** | 0.9 | % |  | 1.0 | % |  |  |  |  |  | 0.8 | % |  | 1.0 | % |  |  |  |  |
| Acquisition and integration costs | 59 |  |  | 35 |  |  |  |  | 68.6 | % |  | 3,474 |  |  | 598 |  |  |  |  | 480.9 | % |
| %** | — | % |  | — | % |  |  |  |  |  | 0.1 | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 370,727 |  |  | $ | 313,672 |  |  |  |  | 18.2 | % |  | $ | 1,126,327 |  |  | $ | 981,207 |  |  |  |  | 14.8 | % |
| %** | 34.7 | % |  | 36.1 | % |  |  |  |  |  | 34.6 | % |  | 36.9 | % |  |  |  |  |

[0000936395-23-000034:mdna:91]
[same as prior period, unchanged from 0000936395-23-000027:mdna:94]

[0000936395-23-000034:mdna:92]
[same as prior period, unchanged from 0000936395-23-000027:mdna:95]

[0000936395-23-000034:mdna:93]
[same as prior period, unchanged from 0000936395-23-000027:mdna:96]

[0000936395-23-000034:mdna:94]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:95]
•Research and development expense benefited from $2.9 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $39.4 million. This increase

[0000936395-23-000034:mdna:96]
[same as prior period, unchanged from 0000936395-23-000027:mdna:99]

[0000936395-23-000034:mdna:97]
•Selling and marketing expense increased by $12.4 million. This increase primarily reflects increases in employee headcount and related compensation costs.

[0000936395-23-000034:mdna:98]
•General and administrative expense increased by $8.2 million. This increase primarily reflects increases in employee headcount and related compensation costs.

[0000936395-23-000034:mdna:99]
[same as prior period, unchanged from 0000936395-23-000027:mdna:103]

[0000936395-23-000034:mdna:100]
[same as prior period, unchanged from 0000936395-23-000027:mdna:112]

[0000936395-23-000034:mdna:101]
[same as prior period, unchanged from 0000936395-23-000027:mdna:105]

[0000936395-23-000034:mdna:102]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:103]
•Research and development expense benefited from $16.6 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $103.4 million. This increase primarily reflects increases in employee headcount and related compensation costs, professional services, and technology and related costs. The increase in employee headcount was partially due to our acquisitions of Benu and Tibit. This increase also reflects the effect of a $4.4 million decrease in benefit from the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (ENCQOR) project grant reimbursement program.

[0000936395-23-000034:mdna:104]
•Selling and marketing expense benefited from $6.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased by $22.5 million. This increase primarily reflects an increase in professional services, employee headcount and related compensation costs, and travel and entertainment costs.

[0000936395-23-000034:mdna:105]
•General and administrative expense benefited from $1.9 million as a result of foreign exchange rates, primarily due

[0000936395-23-000034:mdna:106]
to a stronger U.S. Dollar in relation to the Canadian Dollar and Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $20.0 million. This increase primarily reflects increases in employee headcount and related compensation costs, professional services, and bad debt expense.

[0000936395-23-000034:mdna:107]
[same as prior period, unchanged from 0000936395-23-000027:mdna:111]

[0000936395-23-000034:mdna:108]
•Amortization of intangible assets reflects certain intangible assets having reached the end of their economic lives, partially offset by additional intangibles acquired in connection with our acquisitions of Benu and Tibit during the first quarter of fiscal 2023.

[0000936395-23-000034:mdna:109]
[same as prior period, unchanged from 0000936395-23-000027:mdna:113]

[0000936395-23-000034:mdna:110]
[same as prior period, unchanged from 0000936395-23-000027:mdna:114]

[0000936395-23-000034:mdna:111]
[same as prior period, unchanged from 0000936395-23-000027:mdna:115]

[0000936395-23-000034:mdna:112]
[same as prior period, unchanged from 0000936395-23-000027:mdna:116]

[0000936395-23-000034:mdna:113]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Interest and other income, net | $ | 10,187 |  |  | $ | 366 |  |  |  |  | 2,683.3 | % |  | $ | 50,711 |  |  | $ | 4,860 |  |  |  |  | 943.4 | % |
| %** | 1.0 | % |  | — | % |  |  |  |  |  | 1.6 | % |  | 0.2 | % |  |  |  |  |
| Interest expense | $ | 24,060 |  |  | $ | 12,642 |  |  |  |  | 90.3 | % |  | $ | 63,819 |  |  | $ | 33,275 |  |  |  |  | 91.8 | % |
| %** | 2.3 | % |  | 1.5 | % |  |  |  |  |  | 2.0 | % |  | 1.3 | % |  |  |  |  |
| Provision for income taxes | $ | 34,608 |  |  | $ | 4,319 |  |  |  |  | 701.3 | % |  | $ | 89,507 |  |  | $ | 21,868 |  |  |  |  | 309.3 | % |
| %** | 3.2 | % |  | 0.5 | % |  |  |  |  |  | 2.7 | % |  | 0.8 | % |  |  |  |  |

[0000936395-23-000034:mdna:114]
35

[0000936395-23-000034:mdna:115]
[same as prior period, unchanged from 0000936395-23-000027:mdna:118]

[0000936395-23-000034:mdna:116]
[same as prior period, unchanged from 0000936395-23-000027:mdna:119]

[0000936395-23-000034:mdna:117]
[same as prior period, unchanged from 0000936395-23-000027:mdna:120]

[0000936395-23-000034:mdna:118]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:119]
•Interest and other income, net increased by $9.8 million, primarily resulting from higher interest income on our investments.

[0000936395-23-000034:mdna:120]
•Interest expense increased by $11.4 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000034:mdna:121]
•Provision for income taxes increased by $30.3 million, and the effective tax rate for the third quarter of fiscal 2023 was higher than the effective tax rate for the third quarter of fiscal 2022, both primarily due to the mandatory capitalization of research and development expenses in the third quarter of fiscal 2023, in response to changes in U.S. tax policy.

[0000936395-23-000034:mdna:122]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:123]
•Interest and other income, net increased by $45.9 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, which resulted in a gain on our cost method equity investment of $26.5 million, and higher interest income on our investments. These increases were partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. For more information on our acquisitions, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000034:mdna:124]
•Interest expense increased by $30.5 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity, and additional outstanding indebtedness, including our 2030 Notes issued in the first quarter of fiscal 2022 and the 2030 Term Loan incurred in the first quarter of fiscal 2023. For more information on our short-term and long-term debt, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000034:mdna:125]
•Provision for income taxes increased by $67.6 million, and the effective tax rate for the first nine months of fiscal 2023 was higher than the effective tax rate for the first nine months of fiscal 2022, both primarily due to the mandatory capitalization of research and development expenses in the first nine months of fiscal 2023, in response to changes in U.S. tax policy.

[0000936395-23-000034:mdna:126]
[same as prior period, unchanged from 0000936395-23-000027:mdna:129]

[0000936395-23-000034:mdna:127]
[same as prior period, unchanged from 0000936395-23-000027:mdna:130]

[0000936395-23-000034:mdna:128]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |  | July 29, 2023 |  | July 30, 2022 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 171,380 |  |  | $ | 108,282 |  |  |  |  | 58.3 | % |  | $ | 588,281 |  |  | $ | 395,176 |  |  |  |  | 48.9 | % |
| Platform Software and Services | $ | 49,691 |  |  | $ | 39,646 |  |  |  |  | 25.3 | % |  | $ | 136,028 |  |  | $ | 132,698 |  |  |  |  | 2.5 | % |
| Blue Planet Automation Software and Services | $ | (12,072) |  |  | $ | (10,139) |  |  |  |  | (19.1) | % |  | $ | (30,044) |  |  | $ | (17,693) |  |  |  |  | (69.8) | % |
| Global Services | $ | 50,550 |  |  | $ | 52,965 |  |  |  |  | (4.6) | % |  | $ | 137,190 |  |  | $ | 158,808 |  |  |  |  | (13.6) | % |

[0000936395-23-000034:mdna:129]
[same as prior period, unchanged from 0000936395-23-000027:mdna:132]

[0000936395-23-000034:mdna:130]
[same as prior period, unchanged from 0000936395-23-000027:mdna:133]

[0000936395-23-000034:mdna:131]
Quarter ended July 29, 2023 as compared to the quarter ended July 30, 2022

[0000936395-23-000034:mdna:132]
•Networking Platforms segment profit increased by $63.1 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by increased research and development costs.

[0000936395-23-000034:mdna:133]
•Platform Software and Services segment profit increased by $10.0 million, primarily due to higher sales volume as described above, partially offset by increased research and development costs.

[0000936395-23-000034:mdna:134]
•Blue Planet Automation Software and Services segment loss increased by $1.9 million, primarily due to lower sales volume as described above and increased research and development costs.

[0000936395-23-000034:mdna:135]
•Global Services segment profit decreased by $2.4 million, primarily due to lower gross margin, partially offset by higher sales volume as described above.

[0000936395-23-000034:mdna:136]
Nine months ended July 29, 2023 as compared to the nine months ended July 30, 2022

[0000936395-23-000034:mdna:137]
•Networking Platforms segment profit increased by $193.1 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by increased research and development costs.

[0000936395-23-000034:mdna:138]
•Platform Software and Services segment profit increased by $3.3 million, primarily due to higher software-related services sales volume as described above, partially offset by lower software sales volume, increased research and development costs, and lower gross margin on software-related services.

[0000936395-23-000034:mdna:139]
•Blue Planet Automation Software and Services segment loss increased by $12.4 million, primarily due to lower gross margin on software-related services, lower sales volume, and increased research and development costs.

[0000936395-23-000034:mdna:140]
•Global Services segment profit decreased by $21.6 million, primarily due to lower maintenance support and training revenue and lower gross margin on certain installation and deployment projects as described above.

[0000936395-23-000034:mdna:141]
[same as prior period, unchanged from 0000936395-23-000027:mdna:144]

[0000936395-23-000034:mdna:142]
Overview. For the nine months ended July 29, 2023, we used $27.1 million of cash in operating activities as our working capital requirements of approximately $352.6 million exceeded our net income (adjusted for non-cash charges) of approximately $325.5 million. For additional details, see “Cash Used In Operating Activities” below.

[0000936395-23-000034:mdna:143]
Despite our cash used in operations, our total cash, cash equivalents, and investments increased by $97.1 million during the first nine months of fiscal 2023. This increase principally reflects proceeds from the issuance of the 2030 Term Loan, which provided $492.5 million in cash, net of paid debt issuance costs, and proceeds from the issuance of equity under our employee stock purchase plan which provided $31.3 million in cash during the nine months ended July 29, 2023. In addition to the cash used in operations, uses of cash also included the following items: (i) cash used for the acquisition of businesses of $230.0 million; (ii) cash used to fund our investing activities for capital expenditures totaling $83.4 million; (iii) cash used for stock repurchases under our stock repurchase program of $57.7 million; and (iv) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $29.8 million.

[0000936395-23-000034:mdna:144]
[same as prior period, unchanged from 0000936395-23-000027:mdna:147]

[0000936395-23-000034:mdna:145]
[same as prior period, unchanged from 0000936395-23-000027:mdna:148]

[0000936395-23-000034:mdna:146]
|  | July 29,2023 |  | October 29,2022 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,117,922 |  |  | $ | 994,352 |  |  | $ | 123,570 |  |
| Short-term investments in marketable debt securities | 141,843 |  |  | 153,989 |  |  | (12,146) |  |
| Long-term investments in marketable debt securities | 21,098 |  |  | 35,385 |  |  | (14,287) |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,280,863 |  |  | $ | 1,183,726 |  |  | $ | 97,137 |  |

[0000936395-23-000034:mdna:147]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of July 29, 2023 totaled $1.3 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of September 28, 2025, as modified on February 10, 2023. See Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 29, 2023, letters of credit totaling $68.2 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 29, 2023.

[0000936395-23-000034:mdna:148]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $287.8 million as of July 29, 2023. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate the accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $36.0 million.

[0000936395-23-000034:mdna:149]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the third quarter of fiscal 2023, we repurchased an additional $61.2 million of our common stock under the stock repurchase program, and $438.8 million remained under the current repurchase authorization as of July 29, 2023. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000034:mdna:150]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-23-000034:mdna:151]
[same as prior period, unchanged from 0000936395-23-000027:mdna:154]

[0000936395-23-000034:mdna:152]
The following sections set forth the components of our $27.1 million of cash used in operating activities during the first nine months of fiscal 2023:

[0000936395-23-000034:mdna:153]
[same as prior period, unchanged from 0000936395-23-000027:mdna:156]

[0000936395-23-000034:mdna:154]
[same as prior period, unchanged from 0000936395-23-000027:mdna:157]

[0000936395-23-000034:mdna:155]
|  | Nine Months Ended |
|  | July 29, 2023 |
| Net income | $ | 163,628 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 69,213 |  |
| Share-based compensation expenses | 95,405 |  |
| Amortization of intangible assets | 36,274 |  |
| Deferred taxes | (64,005) |  |
| Provision for inventory excess and obsolescence | 18,767 |  |
| Provision for warranty | 18,860 |  |
| Gain on cost method equity investments, net | (26,368) |  |
| Other | 13,694 |  |
| Net income (adjusted for non-cash charges) | $ | 325,468 |  |

[0000936395-23-000034:mdna:156]
[same as prior period, unchanged from 0000936395-23-000027:mdna:159]

[0000936395-23-000034:mdna:157]
We used $352.6 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-23-000034:mdna:158]
|  | Nine Months Ended |
|  | July 29, 2023 |
| Cash used in accounts receivable | $ | (80,399) |  |
| Cash used in inventories | (262,345) |  |
| Cash provided by prepaid expenses and other | 72,062 |  |
| Cash used in accounts payable, accruals, and other obligations | (133,880) |  |
| Cash provided by deferred revenue | 57,547 |  |
| Cash used in operating lease assets and liabilities, net | (5,593) |  |
| Total cash used for working capital | $ | (352,608) |  |

[0000936395-23-000034:mdna:159]
[same as prior period, unchanged from 0000936395-23-000027:mdna:162]

[0000936395-23-000034:mdna:160]
•The $80.4 million of cash used in accounts receivable during the first nine months of fiscal 2023 reflects increased sales volume at the end of the third quarter of fiscal 2023;

[0000936395-23-000034:mdna:161]
•The $262.3 million of cash used in inventories during the first nine months of fiscal 2023 primarily related to increases in (i) raw materials to mitigate the impact on our business and customers from supply chain constraints in recent prior periods and a global market shortage of semiconductor components and (ii) finished goods inventories from planned fulfillment of customer advance orders for which some deliveries have since been rescheduled as described in “Overview” above;

[0000936395-23-000034:mdna:162]
•The $72.1 million of cash provided by prepaid expense and other during the first nine months of fiscal 2023 primarily reflects lower contract assets for unbilled receivables, lower capitalized contract acquisition costs, and other non-trade receivables;

[0000936395-23-000034:mdna:163]
•The $133.9 million of cash used in accounts payable, accruals, and other obligations during the first nine months of fiscal 2023 primarily reflects the timing of payments to suppliers;

[0000936395-23-000034:mdna:164]
•The $57.5 million of cash provided by deferred revenue during the first nine months of fiscal 2023 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-23-000034:mdna:165]
•The $5.6 million of cash used in operating lease assets and liabilities, net, during the first nine months of fiscal 2023 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-23-000034:mdna:166]
Our days sales outstanding (“DSOs”) decreased from 97 for the first nine months of fiscal 2022 to 94 for the first nine months of fiscal 2023. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 2.0 for the first nine months of fiscal 2022 to 1.7 for the first nine months of fiscal 2023 due to the increases in inventory as described in “Overview” above.

[0000936395-23-000034:mdna:167]
[same as prior period, unchanged from 0000936395-23-000027:mdna:170]

[0000936395-23-000034:mdna:168]
[same as prior period, unchanged from 0000936395-23-000027:mdna:171]

[0000936395-23-000034:mdna:169]
|  | Nine Months Ended |
|  | July 29, 2023 |
| Term Loan due September 28, 2025(1) | $ | 31,913 |  |
| Term Loan due January 31, 2030(2) | 18,448 |  |
| Senior Notes due January 31, 2030(3) | 8,000 |  |
| Interest rate swaps(4) | (6,266) |  |
| ABL Credit Facility(5) | 1,532 |  |
| Finance leases | 3,082 |  |
| Cash paid during period | $ | 56,709 |  |

[0000936395-23-000034:mdna:170]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bore interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00% through its amendment on January 19, 2023. The 2025 Term loan now bears interest at SOFR for the chosen borrowing

[0000936395-23-000034:mdna:171]
period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the third quarter of fiscal 2023, the interest rate on the 2025 Term Loan was 7.00%.

[0000936395-23-000034:mdna:172]
(2) Interest on the 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.50% subject to a minimum SOFR rate of 0.00%. At the end of the third quarter of fiscal 2023, the interest rate on the 2030 Term Loan was 7.75%.

[0000936395-23-000034:mdna:173]
[same as prior period, unchanged from 0000936395-23-000027:mdna:175]

[0000936395-23-000034:mdna:174]
[same as prior period, unchanged from 0000936395-23-000027:mdna:176]

[0000936395-23-000034:mdna:175]
(5) During the first nine months of fiscal 2023, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.5 million in commitment fees, interest expense, and other administrative charges relating to the ABL Credit Facility.

[0000936395-23-000034:mdna:176]
For additional information about our debt, ABL Credit Facility and interest rate swaps, see Notes 15, 16 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-23-000034:mdna:177]
[same as prior period, unchanged from 0000936395-23-000027:mdna:179]

[0000936395-23-000034:mdna:178]
[same as prior period, unchanged from 0000936395-23-000027:mdna:180]

[0000936395-23-000034:mdna:179]
Purchase Order Obligations. As of July 29, 2023 we had $1.7 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-23-000034:mdna:180]
Debt. As of July 29, 2023, we had $498.8 million outstanding principal associated with our 2030 Term Loan, with $5.0 million payable within 12 months. Interest on the 2030 Term Loan and payments due under the interest rate swaps are variable and calculated using the rate in effect on the balance sheet date. Future interest payments associated with the 2030 Term Loan total $246.8 million, with $39.3 million payable within 12 months. For additional information about the 2030 Term Loan, see Note 16 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-23-000034:mdna:181]
[same as prior period, unchanged from 0000936395-23-000027:mdna:183]

[0000936395-23-000034:mdna:182]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue, and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-23-000034:mdna:183]
[same as prior period, unchanged from 0000936395-23-000027:mdna:186]

[0000936395-23-000034:mdna:184]
[same as prior period, unchanged from 0000936395-23-000027:mdna:187]

[0000936395-23-000034:mdna:185]
[same as prior period, unchanged from 0000936395-23-000027:mdna:188]
