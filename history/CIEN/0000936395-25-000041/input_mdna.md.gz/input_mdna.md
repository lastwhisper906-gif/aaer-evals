# CIEN MD&A — 0000936395-25-000041


## mdna

[0000936395-25-000041:mdna:1]
[same as prior period, unchanged from 0000936395-25-000025:mdna:1]

[0000936395-25-000041:mdna:2]
[same as prior period, unchanged from 0000936395-25-000025:mdna:2]

[0000936395-25-000041:mdna:3]
[same as prior period, unchanged from 0000936395-25-000025:mdna:3]

[0000936395-25-000041:mdna:4]
[same as prior period, unchanged from 0000936395-25-000025:mdna:4]

[0000936395-25-000041:mdna:5]
[same as prior period, unchanged from 0000936395-25-000025:mdna:5]

[0000936395-25-000041:mdna:6]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, video, data, artificial intelligence (“AI”), and voice. Our network solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network™, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking portfolio and our Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, to increase transmission speeds, to allocate traffic efficiently, and to adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator Network Control Software (NCS) and advanced applications that deliver multi-layer domain control and operations for network operators. Through our Blue Planet Automation Software, we also enable complete service lifecycle management automation with productized operational support systems, including inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments. In addition to our systems and software, we also offer a broad range of services that help our customers build, operate, and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, network operations center (NOC) management, learning, and optimization services.

[0000936395-25-000041:mdna:7]
[same as prior period, unchanged from 0000936395-25-000025:mdna:8]

[0000936395-25-000041:mdna:8]
[same as prior period, unchanged from 0000936395-25-000025:mdna:9]

[0000936395-25-000041:mdna:9]
We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures, and research and development spending represented 18.1% of our revenue in the first nine months of fiscal 2025. During the first nine months of fiscal 2025, we invested $619.4 million in research and development activities, an increase of 8.4% compared to the first nine months of fiscal 2024. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we have continued to innovate, increase the performance of, and enhance the capabilities for our leading WaveLogicTM coherent modem technology in multiple form factors. Through this innovation, we seek to extend our leadership in our core business and leverage this to expand our addressable market into complementary and adjacent network applications, including inside and around the data center.

[0000936395-25-000041:mdna:10]
[same as prior period, unchanged from 0000936395-25-000025:mdna:11]

[0000936395-25-000041:mdna:11]
The optical component industry has been experiencing increased demand, in particular as a result of cloud provider expenditures related to AI and other applications. This increased demand has led to an industry-wide constrained supply environment with extended lead times, resulting in some customers accelerating future orders.

[0000936395-25-000041:mdna:12]
During the third quarter of fiscal 2025, we continued to experience broad-based business momentum, with orders for our products and services significantly exceeding our revenue, resulting in increased backlog. We believe some portion of this order growth was impacted by the industry dynamics described above. We experienced year-over-year order growth in our major customer segments, particularly with cloud provider customers and large communications service provider customers, with a single cloud provider customer continuing to provide a significant volume of orders. As a result, our revenue increased by 29.4% to $1.2 billion in the third quarter of fiscal 2025 as compared to $942.3 million in the third quarter of fiscal 2024. Two of our top five customers by revenue for the third quarter of fiscal 2025 were cloud providers. Although our business remains subject to quarterly fluctuations due to customer purchasing patterns and supply chain dynamics, we continue to believe that certain trends and shifts in business and consumer behaviors and the drivers of bandwidth demand described above under the heading “Overview - Market Opportunity and Investment in Technology Innovation” in this Item 2 represent long-term opportunities for our business.

[0000936395-25-000041:mdna:13]
Reallocation of Innovation Investment and Fiscal 2025 Restructuring Plan

[0000936395-25-000041:mdna:14]
During the fourth quarter of fiscal 2025, in order to align our strategic investments with our highest-growth demand opportunities, our executive team determined to cease forward investment in certain broadband development initiatives, primarily 25G PON, within the routing and switching product line of the Network Platforms operating segment. We intend to continue support and development of our 10G PON-based products.

[0000936395-25-000041:mdna:15]
Our executive team also approved a restructuring plan intended to deliver increased operating efficiencies and, as a result, commencing during the fourth quarter of fiscal 2025, we are implementing a workforce reduction of approximately 4% to 5% of our global headcount, which includes employees associated with the broadband development initiatives discussed above.

[0000936395-25-000041:mdna:16]
For additional information on the expected impact of these decisions on our financial results, see Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000041:mdna:17]
[same as prior period, unchanged from 0000936395-25-000025:mdna:13]

[0000936395-25-000041:mdna:18]
[same as prior period, unchanged from 0000936395-25-000025:mdna:14]

[0000936395-25-000041:mdna:19]
[same as prior period, unchanged from 0000936395-25-000025:mdna:15]

[0000936395-25-000041:mdna:20]
[same as prior period, unchanged from 0000936395-25-000025:mdna:16]

[0000936395-25-000041:mdna:21]
[same as prior period, unchanged from 0000936395-25-000025:mdna:17]

[0000936395-25-000041:mdna:22]
Our revenue increased by 29.4%, or $277.1 million in the third quarter of fiscal 2025 as compared to the third quarter of fiscal 2024, and 18.2%, or $526.7 million in the first nine months of fiscal 2025 as compared to the first nine months of fiscal 2024.

[0000936395-25-000041:mdna:23]
[same as prior period, unchanged from 0000936395-25-000025:mdna:19]

[0000936395-25-000041:mdna:24]
[same as prior period, unchanged from 0000936395-25-000025:mdna:20]

[0000936395-25-000041:mdna:25]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | 606,845 |  |  |  |  | 34.4 | % |  | $ | 2,317,062 |  |  | $ | 1,862,917 |  |  |  |  | 24.4 | % |
| %** | 66.9 | % |  | 64.4 | % |  |  |  |  |  | 67.8 | % |  | 64.4 | % |  |  |  |  |
| Routing and Switching | 125,857 |  |  | 92,692 |  |  |  |  | 35.8 | % |  | 311,749 |  |  | 320,113 |  |  |  |  | (2.6) | % |
| %** | 10.3 | % |  | 9.8 | % |  |  |  |  |  | 9.1 | % |  | 11.1 | % |  |  |  |  |
| Total Networking Platforms | 941,354 |  |  | 699,537 |  |  |  |  | 34.6 | % |  | 2,628,811 |  |  | 2,183,030 |  |  |  |  | 20.4 | % |
| %** | 77.2 | % |  | 74.2 | % |  |  |  |  |  | 76.9 | % |  | 75.5 | % |  |  |  |  |
| Platform Software and Services | 89,961 |  |  | 83,212 |  |  |  |  | 8.1 | % |  | 270,469 |  |  | 258,402 |  |  |  |  | 4.7 | % |
| %** | 7.4 | % |  | 8.9 | % |  |  |  |  |  | 7.9 | % |  | 8.9 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 27,805 |  |  | 25,791 |  |  |  |  | 7.8 | % |  | 81,787 |  |  | 54,167 |  |  |  |  | 51.0 | % |
| %** | 2.3 | % |  | 2.7 | % |  |  |  |  |  | 2.4 | % |  | 1.9 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 80,743 |  |  | 74,344 |  |  |  |  | 8.6 | % |  | 234,758 |  |  | 225,869 |  |  |  |  | 3.9 | % |
| %** | 6.6 | % |  | 7.9 | % |  |  |  |  |  | 6.9 | % |  | 7.8 | % |  |  |  |  |
| Installation and Deployment | 65,878 |  |  | 46,484 |  |  |  |  | 41.7 | % |  | 171,735 |  |  | 132,993 |  |  |  |  | 29.1 | % |
| %** | 5.4 | % |  | 4.9 | % |  |  |  |  |  | 5.0 | % |  | 4.6 | % |  |  |  |  |
| Consulting and Network Design | 13,644 |  |  | 12,940 |  |  |  |  | 5.4 | % |  | 29,963 |  |  | 36,382 |  |  |  |  | (17.6) | % |
| %** | 1.1 | % |  | 1.4 | % |  |  |  |  |  | 0.9 | % |  | 1.3 | % |  |  |  |  |
| Total Global Services | 160,265 |  |  | 133,768 |  |  |  |  | 19.8 | % |  | 436,456 |  |  | 395,244 |  |  |  |  | 10.4 | % |
| %** | 13.1 | % |  | 14.2 | % |  |  |  |  |  | 12.8 | % |  | 13.7 | % |  |  |  |  |
| Total revenue | $ | 1,219,385 |  |  | $ | 942,308 |  |  |  |  | 29.4 | % |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |  |  |  | 18.2 | % |

[0000936395-25-000041:mdna:26]
[same as prior period, unchanged from 0000936395-25-000025:mdna:22]

[0000936395-25-000041:mdna:27]
[same as prior period, unchanged from 0000936395-25-000025:mdna:23]

[0000936395-25-000041:mdna:28]
[same as prior period, unchanged from 0000936395-25-000025:mdna:24]

[0000936395-25-000041:mdna:29]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:30]
•Networking Platforms segment revenue increased by $241.9 million.

[0000936395-25-000041:mdna:31]
•Optical Networking products revenue increased by $208.7 million, primarily driven by increases in sales of our 6500 Reconfigurable Line Systems (“RLS”), as well as increases in sales of our Waveserver® system and our coherent pluggables, in each case primarily to cloud provider customers. These sales were partially offset by a sales decrease of our 6500 Packet-Optical Platform, primarily to enterprise customers.

[0000936395-25-000041:mdna:32]
•Routing and Switching products revenue increased by $33.2 million, primarily driven by an increase in sales of our 3000 and 5000 series of service delivery and aggregation platforms to communications service providers and cloud provider customers, partially offset by a decrease in sales of our virtualization software to communications service providers.

[0000936395-25-000041:mdna:33]
•Platform Software and Services segment revenue increased by $6.7 million, primarily reflecting sales increases of our Navigator Network Control SuiteTM domain controller solution.

[0000936395-25-000041:mdna:34]
•Blue Planet Automation Software and Services segment revenue increased by $2.0 million, primarily reflecting sales increases in our orchestration software and inventory management software services, partially offset by sales decreases of our inventory management software.

[0000936395-25-000041:mdna:35]
•Global Services segment revenue increased by $26.5 million, primarily reflecting a sales increase in our installation and deployment and maintenance support and training services.

[0000936395-25-000041:mdna:36]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:37]
•Networking Platforms segment revenue increased by $445.8 million.

[0000936395-25-000041:mdna:38]
•Optical Networking sales increased by $454.1 million, primarily driven by increases in sales of our RLS as well as increases in sales of our coherent pluggables, both primarily to cloud provider customers, and our 6500 Packet-Optical Platforms, primarily to communications service provider customers.

[0000936395-25-000041:mdna:39]
•Routing and Switching sales decreased by $8.3 million, primarily driven by decreases in sales of other software.

[0000936395-25-000041:mdna:40]
•Platform Software and Services segment revenue increased by $12.1 million, primarily reflecting sales increases of our software consulting services and our software maintenance services.

[0000936395-25-000041:mdna:41]
•Blue Planet Automation Software and Services segment revenue increased by $27.6 million, primarily reflecting sales increases in our unified assurance and analytics software, orchestration software, and our inventory management software services.

[0000936395-25-000041:mdna:42]
•Global Services segment revenue increased by $41.2 million, primarily reflecting sales increases in our installation and deployment and maintenance support and training services, partially offset by a sales decrease in our consulting and network design services.

[0000936395-25-000041:mdna:43]
[same as prior period, unchanged from 0000936395-25-000025:mdna:39]

[0000936395-25-000041:mdna:44]
[same as prior period, unchanged from 0000936395-25-000025:mdna:40]

[0000936395-25-000041:mdna:45]
[same as prior period, unchanged from 0000936395-25-000025:mdna:41]

[0000936395-25-000041:mdna:46]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Americas | $ | 923,627 |  |  | $ | 718,605 |  |  |  |  | 28.5 | % |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |  |  |  | 21.6 | % |
| %** | 75.7 | % |  | 76.3 | % |  |  |  |  |  | 74.7 | % |  | 72.6 | % |  |  |  |  |
| EMEA | 186,018 |  |  | 135,009 |  |  |  |  | 37.8 | % |  | 535,519 |  |  | 498,212 |  |  |  |  | 7.5 | % |
| %** | 15.3 | % |  | 14.3 | % |  |  |  |  |  | 15.7 | % |  | 17.3 | % |  |  |  |  |
| APAC | 109,740 |  |  | 88,694 |  |  |  |  | 23.7 | % |  | 328,923 |  |  | 292,951 |  |  |  |  | 12.3 | % |
| %** | 9.0 | % |  | 9.4 | % |  |  |  |  |  | 9.6 | % |  | 10.1 | % |  |  |  |  |
| Total | $ | 1,219,385 |  |  | $ | 942,308 |  |  |  |  | 29.4 | % |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |  |  |  | 18.2 | % |

[0000936395-25-000041:mdna:47]
[same as prior period, unchanged from 0000936395-25-000025:mdna:43]

[0000936395-25-000041:mdna:48]
[same as prior period, unchanged from 0000936395-25-000025:mdna:44]

[0000936395-25-000041:mdna:49]
[same as prior period, unchanged from 0000936395-25-000025:mdna:45]

[0000936395-25-000041:mdna:50]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:51]
•Americas revenue increased by $205.0 million, primarily driven by increased sales to cloud providers in the United States.

[0000936395-25-000041:mdna:52]
•EMEA revenue increased by $51.0 million, primarily driven by increased sales to cloud providers in the Netherlands.

[0000936395-25-000041:mdna:53]
•APAC revenue increased by $21.1 million, primarily driven by increased sales to communications service providers and cloud providers, partially offset by decreased sales to enterprise customers.

[0000936395-25-000041:mdna:54]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:55]
•Americas revenue increased by $453.4 million, primarily driven by increased sales to cloud providers as well as increased sales to communications service providers, each primarily in the United States.

[0000936395-25-000041:mdna:56]
•EMEA revenue increased by $37.3 million, primarily driven by increased sales to cloud providers and communications service providers partially offset by decreased sales to submarine network operators.

[0000936395-25-000041:mdna:57]
•APAC revenue increased by $36.0 million, primarily driven by increased sales to communications service providers in India and Japan, partially offset by decreased sales to enterprise customers in Australia and Vietnam.

[0000936395-25-000041:mdna:58]
[same as prior period, unchanged from 0000936395-25-000025:mdna:54]

[0000936395-25-000041:mdna:59]
During the third quarter and first nine months of fiscal 2025, approximately 13.3% and 13.8% of our revenue was non-U.S. Dollar-denominated, respectively. During the third quarter of fiscal 2025 as compared to the third quarter of fiscal 2024, the U.S. Dollar generally weakened against other currencies, and during the first nine months of fiscal 2025 as compared to the first nine months of fiscal 2024, the U.S. Dollar generally strengthened against other currencies. These currency fluctuations had a positive effect on our revenue reported in U.S. Dollars of approximately $3.6 million, or 0.3%, as compared to the third quarter of fiscal 2024, and had an adverse effect on our revenue reported in U.S Dollars of approximately $5.6 million, or 0.2%, as compared to the first nine months of fiscal 2024.

[0000936395-25-000041:mdna:60]
[same as prior period, unchanged from 0000936395-25-000025:mdna:56]

[0000936395-25-000041:mdna:61]
[same as prior period, unchanged from 0000936395-25-000025:mdna:57]

[0000936395-25-000041:mdna:62]
[same as prior period, unchanged from 0000936395-25-000025:mdna:58]

[0000936395-25-000041:mdna:63]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Total revenue | $ | 1,219,385 |  |  | $ | 942,308 |  |  |  |  | 29.4 | % |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |  |  |  | 18.2 | % |
| Total cost of goods sold | 716,306 |  |  | 538,363 |  |  |  |  | 33.1 | % |  | 1,989,785 |  |  | 1,631,275 |  |  |  |  | 22.0 | % |
| Gross profit | $ | 503,079 |  |  | $ | 403,945 |  |  |  |  | 24.5 | % |  | $ | 1,427,738 |  |  | $ | 1,259,568 |  |  |  |  | 13.4 | % |
| %** | 41.3 | % |  | 42.9 | % |  |  |  |  |  | 41.8 | % |  | 43.6 | % |  |  |  |  |

[0000936395-25-000041:mdna:64]
[same as prior period, unchanged from 0000936395-25-000025:mdna:60]

[0000936395-25-000041:mdna:65]
[same as prior period, unchanged from 0000936395-25-000025:mdna:61]

[0000936395-25-000041:mdna:66]
[same as prior period, unchanged from 0000936395-25-000025:mdna:62]

[0000936395-25-000041:mdna:67]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:68]
•Gross profit increased by $99.1 million. Gross margin decreased by 160 basis points, primarily reflecting decreased services margins.

[0000936395-25-000041:mdna:69]
•Gross profit on products increased by $100.8 million from $296.0 million for the third quarter of fiscal 2024 to $396.8 million for the third quarter of fiscal 2025. Product gross margin of 40.6% did not change for the third quarter of fiscal 2025 as compared to the third quarter of fiscal 2024. However, in the third quarter of fiscal 2025, we experienced unfavorable product mix partially offset by improved manufacturing efficiencies and product cost reductions, as compared to the third quarter of fiscal 2024.

[0000936395-25-000041:mdna:70]
•Gross profit on services decreased by $1.7 million from $108.0 million for the third quarter of fiscal 2024 to $106.3 million for the third quarter of fiscal 2025. Services gross margin decreased by 690 basis points, from 50.7% for the third quarter of fiscal 2024 to 43.8% for the third quarter of fiscal 2025, primarily due to increased costs related to delivering maintenance arrangements.

[0000936395-25-000041:mdna:71]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:72]
•Gross profit increased by $168.2 million. Gross margin decreased by 180 basis points, reflecting decreased products and services margin.

[0000936395-25-000041:mdna:73]
•Gross profit on products increased by $158.5 million from $950.9 million for the first nine months of fiscal 2024 to $1.11 billion for the first nine months of fiscal 2025. Product gross margin decreased by 140 basis points, from 42.0% for the first nine months of fiscal 2024 to 40.6% for the first nine months of fiscal 2025, primarily due to unfavorable product mix, partially offset by manufacturing efficiencies.

[0000936395-25-000041:mdna:74]
•Gross profit on services increased by $9.7 million from $308.7 million for the first nine months of fiscal 2024 to $318.4 million for the first nine months of fiscal 2025. Services gross margin decreased by 320 basis points, from 49.5% for the first nine months of fiscal 2024 to 46.3% for the first nine months of fiscal 2025, primarily due to increased costs related to delivering maintenance arrangements.

[0000936395-25-000041:mdna:75]
[same as prior period, unchanged from 0000936395-25-000025:mdna:71]

[0000936395-25-000041:mdna:76]
[same as prior period, unchanged from 0000936395-25-000025:mdna:72]

[0000936395-25-000041:mdna:77]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Research and development | $ | 211,898 |  |  | $ | 188,888 |  |  |  |  | 12.2 | % |  | $ | 619,429 |  |  | $ | 571,537 |  |  |  |  | 8.4 | % |
| %** | 17.4 | % |  | 20.0 | % |  |  |  |  |  | 18.1 | % |  | 19.8 | % |  |  |  |  |
| Selling and marketing | 148,724 |  |  | 121,520 |  |  |  |  | 22.4 | % |  | 424,911 |  |  | 373,749 |  |  |  |  | 13.7 | % |
| %** | 12.2 | % |  | 12.9 | % |  |  |  |  |  | 12.4 | % |  | 12.9 | % |  |  |  |  |
| General and administrative | 60,596 |  |  | 58,248 |  |  |  |  | 4.0 | % |  | 171,450 |  |  | 162,504 |  |  |  |  | 5.5 | % |
| %** | 5.0 | % |  | 6.2 | % |  |  |  |  |  | 5.0 | % |  | 5.6 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,770 |  |  | 1,361 |  |  |  |  | 30.1 | % |  | 5,262 |  |  | 21,987 |  |  |  |  | (76.1) | % |
| %** | 0.1 | % |  | 0.1 | % |  |  |  |  |  | 0.2 | % |  | 0.8 | % |  |  |  |  |
| Amortization of intangible assets | 6,556 |  |  | 7,185 |  |  |  |  | (8.8) | % |  | 19,646 |  |  | 22,384 |  |  |  |  | (12.2) | % |
| %** | 0.5 | % |  | 0.8 | % |  |  |  |  |  | 0.6 | % |  | 0.8 | % |  |  |  |  |
| Total operating expenses | $ | 429,544 |  |  | $ | 377,202 |  |  |  |  | 13.9 | % |  | $ | 1,240,698 |  |  | $ | 1,152,161 |  |  |  |  | 7.7 | % |
| %** | 35.2 | % |  | 40.0 | % |  |  |  |  |  | 36.3 | % |  | 39.9 | % |  |  |  |  |

[0000936395-25-000041:mdna:78]
[same as prior period, unchanged from 0000936395-25-000025:mdna:74]

[0000936395-25-000041:mdna:79]
[same as prior period, unchanged from 0000936395-25-000025:mdna:75]

[0000936395-25-000041:mdna:80]
[same as prior period, unchanged from 0000936395-25-000025:mdna:76]

[0000936395-25-000041:mdna:81]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:82]
•Research and development expense increased by $23.0 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, partially offset by lower prototype expense.

[0000936395-25-000041:mdna:83]
•Selling and marketing expense increased by $27.2 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation.

[0000936395-25-000041:mdna:84]
•General and administrative expense increased by $2.3 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, partially offset by lower legal fees.

[0000936395-25-000041:mdna:85]
•Significant asset impairments and restructuring costs remained relatively unchanged.

[0000936395-25-000041:mdna:86]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-25-000041:mdna:87]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:88]
•Research and development expense increased by $47.9 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, and professional services related to design engineering, fabrication and production of ASIC chips, partially offset by lower prototype expense.

[0000936395-25-000041:mdna:89]
•Selling and marketing expense increased by $51.2 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, and increases in travel and entertainment costs.

[0000936395-25-000041:mdna:90]
•General and administrative expense increased by $8.9 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, partially offset by lower legal fees and bad debt expense.

[0000936395-25-000041:mdna:91]
•Significant asset impairments and restructuring costs decreased by $16.7 million primarily due to a reduction in restructuring activities. For more information on our restructuring costs, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000041:mdna:92]
•Amortization of intangible assets decreased by $2.7 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-25-000041:mdna:93]
[same as prior period, unchanged from 0000936395-25-000025:mdna:89]

[0000936395-25-000041:mdna:94]
During the third quarter and first nine months of fiscal 2025, approximately 47.7% and 48.2% of our operating expense was non-U.S. Dollar-denominated, respectively. During the third quarter and first nine months of fiscal 2025, as compared to the third quarter and first nine months of fiscal 2024, the U.S. Dollar fluctuated against other currencies. These currency fluctuations, net of hedging, had the effect of reducing our operating expense by a negligible amount as compared to the third quarter of fiscal 2024, and $12.3 million, or 1.0% as compared to the first nine months of fiscal 2024.

[0000936395-25-000041:mdna:95]
[same as prior period, unchanged from 0000936395-25-000025:mdna:91]

[0000936395-25-000041:mdna:96]
[same as prior period, unchanged from 0000936395-25-000025:mdna:92]

[0000936395-25-000041:mdna:97]
[same as prior period, unchanged from 0000936395-25-000025:mdna:93]

[0000936395-25-000041:mdna:98]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 181,993 |  |  | $ | 106,870 |  |  |  |  | 70.3 | % |  | $ | 482,784 |  |  | $ | 387,211 |  |  |  |  | 24.7 | % |
| Platform Software and Services | $ | 54,529 |  |  | $ | 53,131 |  |  |  |  | 2.6 | % |  | $ | 168,077 |  |  | $ | 165,171 |  |  |  |  | 1.8 | % |
| Blue Planet Automation Software and Services | $ | 4,192 |  |  | $ | 4,705 |  |  |  |  | (10.9) | % |  | $ | 13,059 |  |  | $ | (10,127) |  |  |  |  | 229.0 | % |
| Global Services | $ | 50,467 |  |  | $ | 50,351 |  |  |  |  | 0.2 | % |  | $ | 144,389 |  |  | $ | 145,776 |  |  |  |  | (1.0) | % |

[0000936395-25-000041:mdna:99]
[same as prior period, unchanged from 0000936395-25-000025:mdna:95]

[0000936395-25-000041:mdna:100]
[same as prior period, unchanged from 0000936395-25-000025:mdna:96]

[0000936395-25-000041:mdna:101]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:102]
•Networking Platforms segment profit increased by $75.1 million, primarily due to higher sales volume as described above, partially offset by higher research and development costs.

[0000936395-25-000041:mdna:103]
•Platform Software and Services segment profit increased by $1.4 million, primarily due to higher sales volume as described above, partially offset by reduced services margin as described above, and increased research and development costs.

[0000936395-25-000041:mdna:104]
•Blue Planet Automation Software and Services segment profit slightly decreased, primarily due to reduced services margin, partially offset by higher sales volume as described above.

[0000936395-25-000041:mdna:105]
•Global Services segment profit slightly increased, primarily due to increased sales volume as described above, partially offset by reduced services margin also described above.

[0000936395-25-000041:mdna:106]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:107]
•Networking Platforms segment profit increased by $95.6 million, primarily due to higher sales volume, partially offset by reduced product margin as described above, and higher research and development costs.

[0000936395-25-000041:mdna:108]
•Platform Software and Services segment profit increased by $2.9 million, primarily due to higher services sales volume, partially offset by increased research and development costs and reduced margins as described above.

[0000936395-25-000041:mdna:109]
•Blue Planet Automation Software and Services segment profit increased by $23.2 million, primarily due to higher sales volume as described above, improved margins, and lower research and development costs.

[0000936395-25-000041:mdna:110]
•Global Services segment profit slightly decreased by $1.4 million, primarily due to reduced services margins as described above, partially offset by increased sales volume also described above.

[0000936395-25-000041:mdna:111]
[same as prior period, unchanged from 0000936395-25-000025:mdna:107]

[0000936395-25-000041:mdna:112]
[same as prior period, unchanged from 0000936395-25-000025:mdna:108]

[0000936395-25-000041:mdna:113]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |  | August 2, 2025 |  | July 27, 2024 |  |  |  | %* |
| Interest and other income, net | $ | 15,090 |  |  | $ | 14,013 |  |  |  |  | 7.7 | % |  | $ | 34,539 |  |  | $ | 36,460 |  |  |  |  | (5.3) | % |
| %** | 1.2 | % |  | 1.5 | % |  |  |  |  |  | 1.0 | % |  | 1.3 | % |  |  |  |  |
| Interest expense | $ | 22,806 |  |  | $ | 24,401 |  |  |  |  | (6.5) | % |  | $ | 67,421 |  |  | $ | 72,038 |  |  |  |  | (6.4) | % |
| %** | 1.9 | % |  | 2.6 | % |  |  |  |  |  | 2.0 | % |  | 2.5 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | — |  |  |  |  | — | % |  | $ | 729 |  |  | $ | — |  |  |  |  | 100.0 | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Provision for income taxes | $ | 15,511 |  |  | $ | 2,125 |  |  |  |  | 629.9 | % |  | $ | 49,580 |  |  | $ | 24,901 |  |  |  |  | 99.1 | % |
| %** | 1.3 | % |  | 0.2 | % |  |  |  |  |  | 1.5 | % |  | 0.9 | % |  |  |  |  |

[0000936395-25-000041:mdna:114]
[same as prior period, unchanged from 0000936395-25-000025:mdna:110]

[0000936395-25-000041:mdna:115]
[same as prior period, unchanged from 0000936395-25-000025:mdna:111]

[0000936395-25-000041:mdna:116]
[same as prior period, unchanged from 0000936395-25-000025:mdna:112]

[0000936395-25-000041:mdna:117]
Quarter ended August 2, 2025 as compared to the quarter ended July 27, 2024

[0000936395-25-000041:mdna:118]
•Interest and other income, net remained relatively unchanged.

[0000936395-25-000041:mdna:119]
•Interest expense decreased by $1.6 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity. For more information on our short-term and long-term debt, see Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000041:mdna:120]
•Provision for income taxes increased by $13.4 million, primarily due to the increase in income before income taxes.

[0000936395-25-000041:mdna:121]
Nine months ended August 2, 2025 as compared to the nine months ended July 27, 2024

[0000936395-25-000041:mdna:122]
•Interest and other income, net decreased by $1.9 million, primarily resulting from lower interest income on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-25-000041:mdna:123]
•Interest expense decreased by $4.6 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity. For more information on our short-term and long-term debt, see Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000041:mdna:124]
[same as prior period, unchanged from 0000936395-25-000025:mdna:120]

[0000936395-25-000041:mdna:125]
•Provision for income taxes increased by $24.7 million, primarily due to the increase in income before income taxes.

[0000936395-25-000041:mdna:126]
[same as prior period, unchanged from 0000936395-25-000025:mdna:122]

[0000936395-25-000041:mdna:127]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility (as defined below), will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our capital structure, liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans or increase our strategic flexibility, and we will continue to consider capital raising and other market opportunities.

[0000936395-25-000041:mdna:128]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of August 2, 2025, totaled $1.4 billion, as well as the unused portion of our senior secured revolving credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of August 2, 2025, letters of credit totaling $52.1 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of August 2, 2025.

[0000936395-25-000041:mdna:129]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $539.5 million as of August 2, 2025. Approximately $92.1 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-25-000041:mdna:130]
Stock Repurchase Authorization. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first nine months of fiscal 2025, we repurchased $245.2 million of our common stock under the stock repurchase program, and $754.8 million remained under the current repurchase authorization as of August 2, 2025. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as Item 2 of Part II of this report.

[0000936395-25-000041:mdna:131]
[same as prior period, unchanged from 0000936395-25-000025:mdna:127]

[0000936395-25-000041:mdna:132]
[same as prior period, unchanged from 0000936395-25-000025:mdna:128]

[0000936395-25-000041:mdna:133]
|  | August 2,2025 |  | November 2,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 1,055,976 |  |  | $ | 934,863 |  |  | $ | 121,113 |  |
| Short-term investments in marketable debt securities | 270,380 |  |  | 316,343 |  |  | (45,963) |  |
| Long-term investments in marketable debt securities | 64,397 |  |  | 80,920 |  |  | (16,523) |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,390,753 |  |  | $ | 1,332,126 |  |  | $ | 58,627 |  |

[0000936395-25-000041:mdna:134]
Cash, cash equivalents and investments increased by $58.6 million during the first nine months of fiscal 2025. Cash from operating activities generated $435.0 million which was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $250.0 million; (ii) cash used to fund our investing activities for capital expenditures totaling $95.4 million; (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $60.0 million; and (iv) cash used for payments on our term loan due October 28, 2030 of $8.7 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $35.9 million in cash during the nine months ended August 2, 2025.

[0000936395-25-000041:mdna:135]
[same as prior period, unchanged from 0000936395-25-000025:mdna:131]

[0000936395-25-000041:mdna:136]
The following sections set forth the components of our $435.0 million of cash provided by operating activities during the first nine months of fiscal 2025. Net income (adjusted for non-cash charges) provided cash of approximately $369.5 million and cash provided by operating assets and liabilities was approximately $65.5 million.

[0000936395-25-000041:mdna:137]
[same as prior period, unchanged from 0000936395-25-000025:mdna:133]

[0000936395-25-000041:mdna:138]
[same as prior period, unchanged from 0000936395-25-000025:mdna:134]

[0000936395-25-000041:mdna:139]
|  | Nine Months Ended |
|  | August 2, 2025 |
| Net income | $ | 103,849 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 76,637 |  |
| Share-based compensation expense | 135,696 |  |
| Amortization of intangible assets | 26,343 |  |
| Deferred taxes | (21,709) |  |
| Provision for inventory excess and obsolescence | 34,185 |  |
| Provision for warranty | 16,302 |  |
| Other | (1,838) |  |
| Net income (adjusted for non-cash charges) | $ | 369,465 |  |

[0000936395-25-000041:mdna:140]
[same as prior period, unchanged from 0000936395-25-000025:mdna:136]

[0000936395-25-000041:mdna:141]
Operating asset and liability requirements decreased by $65.5 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0000936395-25-000041:mdna:142]
|  | Nine Months Ended |
|  | August 2, 2025 |
| Accounts receivable | $ | (116,887) |  |
| Inventories | (73,493) |  |
| Prepaid expenses and other | 137,440 |  |
| Accounts payable, accruals, and other obligations | 83,354 |  |
| Deferred revenue | 38,246 |  |
| Operating lease assets and liabilities, net | (3,109) |  |
| Total cash provided by operating assets and liabilities | $ | 65,551 |  |

[0000936395-25-000041:mdna:143]
As compared to the end of fiscal 2024, for the first nine months of fiscal 2025:

[0000936395-25-000041:mdna:144]
•The change in accounts receivable primarily reflects the timing of cash collections from customers and increased sales volume;

[0000936395-25-000041:mdna:145]
[same as prior period, unchanged from 0000936395-25-000025:mdna:141]

[0000936395-25-000041:mdna:146]
•The change in prepaid expenses and other primarily reflects reduced refundable cash advances to a third-party contract manufacturer partially offset by increased contract assets for unbilled accounts receivable;

[0000936395-25-000041:mdna:147]
•The change in accounts payable, accruals, and other obligations primarily reflects a higher accrual associated with our annual incentive compensation plan, the timing of payments to suppliers and the timing of payments for payroll, partially offset by timing of payments for income taxes;

[0000936395-25-000041:mdna:148]
•The change in deferred revenue primarily represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-25-000041:mdna:149]
[same as prior period, unchanged from 0000936395-25-000025:mdna:145]

[0000936395-25-000041:mdna:150]
Our days sales outstanding (“DSOs”) decreased from 97 for the first nine months of fiscal 2024 to 94 for the first nine months of fiscal 2025. The calculation of DSOs includes accounts receivables, net, and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 1.9 for the first nine months of fiscal 2024 to 2.5 for the first nine months of fiscal 2025.

[0000936395-25-000041:mdna:151]
[same as prior period, unchanged from 0000936395-25-000025:mdna:147]

[0000936395-25-000041:mdna:152]
[same as prior period, unchanged from 0000936395-25-000025:mdna:148]

[0000936395-25-000041:mdna:153]
|  | Nine Months Ended |
|  | August 2, 2025 |
| 2030 Term Loan terminated January 17, 2025(1) | $ | 18,639 |  |
| Refinanced 2030 Term Loan due October 28, 2030(2) | 35,991 |  |
| 2030 Senior Notes due January 31, 2030(3) | 16,000 |  |
| Interest rate swaps(4) | (6,284) |  |
| Revolving Credit Facility(5) | 1,364 |  |
| Finance leases | 2,533 |  |
| Cash paid during period | $ | 68,243 |  |

[0000936395-25-000041:mdna:154]
[same as prior period, unchanged from 0000936395-25-000025:mdna:150]

[0000936395-25-000041:mdna:155]
(2) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the third quarter of fiscal 2025, the interest rate on the Refinanced 2030 Term Loan was 6.10%.

[0000936395-25-000041:mdna:156]
[same as prior period, unchanged from 0000936395-25-000025:mdna:152]

[0000936395-25-000041:mdna:157]
[same as prior period, unchanged from 0000936395-25-000025:mdna:153]

[0000936395-25-000041:mdna:158]
(5) During the first nine months of fiscal 2025, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-25-000041:mdna:159]
[same as prior period, unchanged from 0000936395-25-000025:mdna:155]

[0000936395-25-000041:mdna:160]
[same as prior period, unchanged from 0000936395-25-000025:mdna:156]

[0000936395-25-000041:mdna:161]
[same as prior period, unchanged from 0000936395-25-000025:mdna:157]

[0000936395-25-000041:mdna:162]
[same as prior period, unchanged from 0000936395-25-000025:mdna:158]

[0000936395-25-000041:mdna:163]
[same as prior period, unchanged from 0000936395-25-000025:mdna:159]

[0000936395-25-000041:mdna:164]
[same as prior period, unchanged from 0000936395-25-000025:mdna:160]

[0000936395-25-000041:mdna:165]
[same as prior period, unchanged from 0000936395-25-000025:mdna:161]
