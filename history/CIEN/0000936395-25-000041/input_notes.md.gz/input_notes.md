# CIEN notes — 0000936395-25-000041


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-25-000041:notes:1]
[same as prior period, unchanged from 0000936395-25-000025:notes:1]

[0000936395-25-000041:notes:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected.

[0000936395-25-000041:notes:3]
[same as prior period, unchanged from 0000936395-25-000025:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-25-000041:notes:4]
[same as prior period, unchanged from 0000936395-25-000025:notes:4]

[0000936395-25-000041:notes:5]
[same as prior period, unchanged from 0000936395-25-000025:notes:5]

[0000936395-25-000041:notes:6]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

[0000936395-25-000041:notes:7]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-25-000041:notes:8]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-25-000041:notes:9]
In July 2025, the FASB issued ASU No. 2025-05 (“ASU 2025-05”), Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, to introduce a practical expedient for all entities, which simplifies the calculation required for estimating credit losses and assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. ASU 2025-05 is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods; however, early adoption is permitted. ASU 2025-25 allows for adoption using a prospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-25-000041:notes:10]
[same as prior period, unchanged from 0000936395-25-000025:notes:9]

[0000936395-25-000041:notes:11]
[same as prior period, unchanged from 0000936395-25-000025:notes:10]

[0000936395-25-000041:notes:12]
[same as prior period, unchanged from 0000936395-25-000025:notes:11]

[0000936395-25-000041:notes:13]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |

[0000936395-25-000041:notes:14]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |

[0000936395-25-000041:notes:15]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |

[0000936395-25-000041:notes:16]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |

[0000936395-25-000041:notes:17]
[same as prior period, unchanged from 0000936395-25-000025:notes:16]

[0000936395-25-000041:notes:18]
[same as prior period, unchanged from 0000936395-25-000025:notes:17]

[0000936395-25-000041:notes:19]
[same as prior period, unchanged from 0000936395-25-000025:notes:18]

[0000936395-25-000041:notes:20]
[same as prior period, unchanged from 0000936395-25-000025:notes:19]

[0000936395-25-000041:notes:21]
[same as prior period, unchanged from 0000936395-25-000025:notes:20]

[0000936395-25-000041:notes:22]
[same as prior period, unchanged from 0000936395-25-000025:notes:21]

[0000936395-25-000041:notes:23]
•Platform Services - includes sales of subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

[0000936395-25-000041:notes:24]
[same as prior period, unchanged from 0000936395-25-000025:notes:23]

[0000936395-25-000041:notes:25]
[same as prior period, unchanged from 0000936395-25-000025:notes:24]

[0000936395-25-000041:notes:26]
[same as prior period, unchanged from 0000936395-25-000025:notes:25]

[0000936395-25-000041:notes:27]
[same as prior period, unchanged from 0000936395-25-000025:notes:26]

[0000936395-25-000041:notes:28]
[same as prior period, unchanged from 0000936395-25-000025:notes:27]

[0000936395-25-000041:notes:29]
[same as prior period, unchanged from 0000936395-25-000025:notes:28]

[0000936395-25-000041:notes:30]
[same as prior period, unchanged from 0000936395-25-000025:notes:29]

[0000936395-25-000041:notes:31]
[same as prior period, unchanged from 0000936395-25-000025:notes:30]

[0000936395-25-000041:notes:32]
[same as prior period, unchanged from 0000936395-25-000025:notes:31]

[0000936395-25-000041:notes:33]
[same as prior period, unchanged from 0000936395-25-000025:notes:32]

[0000936395-25-000041:notes:34]
[same as prior period, unchanged from 0000936395-25-000025:notes:33]

[0000936395-25-000041:notes:35]
[same as prior period, unchanged from 0000936395-25-000025:notes:34]

[0000936395-25-000041:notes:36]
[same as prior period, unchanged from 0000936395-25-000025:notes:35]

[0000936395-25-000041:notes:37]
[same as prior period, unchanged from 0000936395-25-000025:notes:36]

[0000936395-25-000041:notes:38]
[same as prior period, unchanged from 0000936395-25-000025:notes:37]

[0000936395-25-000041:notes:39]
[same as prior period, unchanged from 0000936395-25-000025:notes:38]

[0000936395-25-000041:notes:40]
[same as prior period, unchanged from 0000936395-25-000025:notes:39]

[0000936395-25-000041:notes:41]
[same as prior period, unchanged from 0000936395-25-000025:notes:40]

[0000936395-25-000041:notes:42]
[same as prior period, unchanged from 0000936395-25-000025:notes:41]

[0000936395-25-000041:notes:43]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 923,627 |  |  | $ | 718,605 |  |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |
| EMEA |  | 186,018 |  |  | 135,009 |  |  | 535,519 |  |  | 498,212 |  |
| APAC |  | 109,740 |  |  | 88,694 |  |  | 328,923 |  |  | 292,951 |  |
| Total revenue by geographic distribution |  | $ | 1,219,385 |  |  | $ | 942,308 |  |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |

[0000936395-25-000041:notes:44]
Ciena’s revenue includes $882.8 million and $676.0 million of U.S. revenue for the third quarter of fiscal 2025 and 2024, respectively. For the nine months ended August 2, 2025 and July 27, 2024, U.S. revenue was $2.4 billion and $2.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0000936395-25-000041:notes:45]
Ciena’s revenue from a cloud provider includes $218.0 million and $538.2 million for the third quarter and nine months ended August 2, 2025, respectively, and $137.2 million and $331.6 million for the third quarter and nine months ended July 27, 2024, respectively. Revenue also includes $133.0 million and $361.4 million from AT&T for the third quarter and nine months ended August 2, 2025, respectively, and $113.1 million and $324.8 million for the third quarter and nine months ended July 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

[0000936395-25-000041:notes:46]
[same as prior period, unchanged from 0000936395-25-000025:notes:45]

[0000936395-25-000041:notes:47]
[same as prior period, unchanged from 0000936395-25-000025:notes:46]

[0000936395-25-000041:notes:48]
|  |  | Balance at August 2, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 1,025,563 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 164,326 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 277,266 |  |  | $ | 237,619 |  |

[0000936395-25-000041:notes:49]
[same as prior period, unchanged from 0000936395-25-000025:notes:48]

[0000936395-25-000041:notes:50]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $134.6 million and $130.5 million of revenue during the first nine months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 2, 2025 and July 27, 2024.

[0000936395-25-000041:notes:51]
[same as prior period, unchanged from 0000936395-25-000025:notes:50]

[0000936395-25-000041:notes:52]
|  | August 2,2025 |  | November 2,2024 |
| Products | $ | 33,476 |  |  | $ | 19,017 |  |
| Services | 243,790 |  |  | 218,602 |  |
| Total deferred revenue | 277,266 |  |  | 237,619 |  |
| Less current portion | (196,209) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 81,057 |  |  | $ | 81,240 |  |

[0000936395-25-000041:notes:53]
[same as prior period, unchanged from 0000936395-25-000025:notes:52]

[0000936395-25-000041:notes:54]
Capitalized contract acquisition costs consist of deferred sales commissions and were $33.4 million and $28.4 million as of August 2, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $22.9 million during the first nine months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-25-000041:notes:55]
[same as prior period, unchanged from 0000936395-25-000025:notes:54]

[0000936395-25-000041:notes:56]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of August 2, 2025, the aggregate amount of RPO was $2.0 billion. As of August 2, 2025, Ciena expects approximately 82% of the RPO balance to be recognized as revenue within the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-25-000041:notes:57]
[same as prior period, unchanged from 0000936395-25-000025:notes:56]

[0000936395-25-000041:notes:58]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended August 2, 2025 (in thousands):

[0000936395-25-000041:notes:59]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Charges | 1,996 |  |  | 3,266 |  | (1) | 5,262 |  |
| Cash payments | (3,389) |  |  | (3,266) |  |  | (6,655) |  |
| Balance at August 2, 2025 | $ | 534 |  |  | $ | — |  |  | $ | 534 |  |
| Current restructuring liabilities | $ | 534 |  |  | $ | — |  |  | $ | 534 |  |

[0000936395-25-000041:notes:60]
[same as prior period, unchanged from 0000936395-25-000025:notes:59]

[0000936395-25-000041:notes:61]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the nine months ended July 27, 2024 (in thousands):

[0000936395-25-000041:notes:62]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 13,708 |  | (1) | 8,279 |  | (2) | 21,987 |  |
| Cash payments | (14,379) |  |  | (8,279) |  |  | (22,658) |  |
| Balance at July 27, 2024 | $ | 1,242 |  |  | $ | — |  |  | $ | 1,242 |  |
| Current restructuring liabilities | $ | 1,242 |  |  | $ | — |  |  | $ | 1,242 |  |

[0000936395-25-000041:notes:63]
(1) Reflects a global workforce reduction of approximately 390 employees during the nine months ended July 27, 2024 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-25-000041:notes:64]
[same as prior period, unchanged from 0000936395-25-000025:notes:63]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-25-000041:notes:65]
[same as prior period, unchanged from 0000936395-25-000025:notes:64]

[0000936395-25-000041:notes:66]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income | $ | 16,173 |  |  | $ | 15,876 |  |  | $ | 43,318 |  |  | $ | 46,309 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts(1) | 744 |  |  | 519 |  |  | (1,593) |  |  | 2,517 |  |
| Foreign currency exchange losses(2) | (1,796) |  |  | (1,611) |  |  | (4,799) |  |  | (11,215) |  |
| Other | (31) |  |  | (771) |  |  | (2,387) |  |  | (1,151) |  |
| Interest and other income, net | $ | 15,090 |  |  | $ | 14,013 |  |  | $ | 34,539 |  |  | $ | 36,460 |  |

[0000936395-25-000041:notes:67]
[same as prior period, unchanged from 0000936395-25-000025:notes:66]

[0000936395-25-000041:notes:68]
[same as prior period, unchanged from 0000936395-25-000025:notes:67]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-25-000041:notes:69]
INCOME TAXES
The effective tax rate for the third quarter of fiscal 2025 was higher than the effective tax rate for the third quarter of fiscal 2024, primarily due to the settlement of uncertain tax positions in the prior year.

[0000936395-25-000041:notes:70]
The effective tax rate for the first nine months of fiscal 2025 was lower than the effective tax rate for the first nine months of fiscal 2024, primarily due to an income tax benefit for share-based compensation expense.

[0000936395-25-000041:notes:71]
For the nine months ended August 2, 2025, the impact of the 15% global minimum tax, referred to as Pillar Two, was not material to Ciena’s consolidated financial statements. 
On July 4, 2025, the One Big Beautiful Bill Act (“OBBBA”) was enacted into law in the United States. The OBBBA includes significant provisions, such as the permanent extension of certain expiring provisions of the Tax Cuts and Jobs Act, modifications to the international tax framework and the restoration of favorable tax treatment for certain business provisions. The legislation has multiple effective dates, with certain provisions taking effect in fiscal 2025 and others to be implemented through fiscal 2027. The legislation will not have a material impact on Ciena’s consolidated financial statements in fiscal 2025.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-25-000041:notes:72]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-25-000041:notes:73]
|  | August 2, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 208,174 |  |  | $ | 297 |  |  | $ | (3) |  |  | $ | 208,468 |  |
| Corporate debt securities | 120,919 |  |  | 207 |  |  | — |  |  | 121,126 |  |
| Time deposits | 92,547 |  |  | 2 |  |  | — |  |  | 92,549 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |
| Included in cash equivalents | $ | 87,366 |  |  | $ | — |  |  | $ | — |  |  | $ | 87,366 |  |
| Included in short-term investments | 270,085 |  |  | 298 |  |  | (3) |  |  | 270,380 |  |
| Included in long-term investments | 64,189 |  |  | 208 |  |  | — |  |  | 64,397 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |

[0000936395-25-000041:notes:74]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

[0000936395-25-000041:notes:75]
The following table summarizes the final legal maturities of debt investments as of August 2, 2025 (in thousands):

[0000936395-25-000041:notes:76]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 357,451 |  |  | $ | 357,746 |  |
| Due in 1-2 years | 64,189 |  |  | 64,397 |  |
|  | $ | 421,640 |  |  | $ | 422,143 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-25-000041:notes:77]
[same as prior period, unchanged from 0000936395-25-000025:notes:75]

[0000936395-25-000041:notes:78]
|  | August 2, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 658,774 |  |  | $ | — |  |  | $ | — |  |  | $ | 658,774 |  |
| Bond mutual fund | 116,537 |  |  | — |  |  | — |  |  | 116,537 |  |
| Time deposits | 92,549 |  |  | — |  |  | — |  |  | 92,549 |  |
| Deferred compensation plan assets | 19,359 |  |  | — |  |  | — |  |  | 19,359 |  |
| U.S. government obligations | — |  |  | 208,468 |  |  | — |  |  | 208,468 |  |
| Corporate debt securities | — |  |  | 121,126 |  |  | — |  |  | 121,126 |  |
| Foreign currency forward contracts | — |  |  | 5,685 |  |  | — |  |  | 5,685 |  |
| Interest rate swaps | — |  |  | 671 |  |  | — |  |  | 671 |  |
| Total assets measured at fair value | $ | 887,219 |  |  | $ | 335,950 |  |  | $ | — |  |  | $ | 1,223,169 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,228 |  |  | $ | — |  |  | $ | 3,228 |  |
| Interest rate swaps | — |  |  | 1,220 |  |  | — |  |  | 1,220 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4,448 |  |  | $ | — |  |  | $ | 4,448 |  |

[0000936395-25-000041:notes:79]
[same as prior period, unchanged from 0000936395-25-000025:notes:77]

[0000936395-25-000041:notes:80]
[same as prior period, unchanged from 0000936395-25-000025:notes:78]

[0000936395-25-000041:notes:81]
|  | August 2, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 862,021 |  |  | $ | 656 |  |  | $ | — |  |  | $ | 862,677 |  |
| Short-term investments | 5,839 |  |  | 264,541 |  |  | — |  |  | 270,380 |  |
| Prepaid expenses and other | — |  |  | 5,685 |  |  | — |  |  | 5,685 |  |
| Long-term investments | — |  |  | 64,397 |  |  | — |  |  | 64,397 |  |
| Other long-term assets | 19,359 |  |  | 671 |  |  | — |  |  | 20,030 |  |
| Total assets measured at fair value | $ | 887,219 |  |  | $ | 335,950 |  |  | $ | — |  |  | $ | 1,223,169 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 3,228 |  |  | $ | — |  |  | $ | 3,228 |  |
| Other long-term obligations | — |  |  | 1,220 |  |  | — |  |  | 1,220 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 4,448 |  |  | $ | — |  |  | $ | 4,448 |  |

[0000936395-25-000041:notes:82]
[same as prior period, unchanged from 0000936395-25-000025:notes:80]

[0000936395-25-000041:notes:83]
[same as prior period, unchanged from 0000936395-25-000025:notes:81]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-25-000041:notes:84]
[same as prior period, unchanged from 0000936395-25-000025:notes:82]

[0000936395-25-000041:notes:85]
|  | August 2,2025 |  | November 2,2024 |
| Raw materials | $ | 642,706 |  |  | $ | 542,785 |  |
| Work-in-process | 35,611 |  |  | 32,219 |  |
| Finished goods | 261,732 |  |  | 324,697 |  |
| Deferred cost of goods sold | 41,831 |  |  | 27,902 |  |
| Gross inventories | 981,880 |  |  | 927,603 |  |
| Reserve for inventory excess and obsolescence | (121,477) |  |  | (107,173) |  |
| Inventories, net | $ | 860,403 |  |  | $ | 820,430 |  |

[0000936395-25-000041:notes:86]
During the first nine months of fiscal 2025, Ciena recorded a provision for inventory excess and obsolescence of $34.2 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the reserve for excess and obsolete inventory relate primarily to sales and disposal activities.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-25-000041:notes:87]
[same as prior period, unchanged from 0000936395-25-000025:notes:85]

[0000936395-25-000041:notes:88]
[same as prior period, unchanged from 0000936395-25-000025:notes:86]

[0000936395-25-000041:notes:89]
As of August 2, 2025 and November 2, 2024, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $325.3 million and $257.0 million as of August 2, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-25-000041:notes:90]
As of August 2, 2025 and November 2, 2024, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $63.0 million and $65.4 million as of August 2, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0000936395-25-000041:notes:91]
As of August 2, 2025 and November 2, 2024, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $138.5 million and $201.2 million as of August 2, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-25-000041:notes:92]
[same as prior period, unchanged from 0000936395-25-000025:notes:90]

[0000936395-25-000041:notes:93]
[same as prior period, unchanged from 0000936395-25-000025:notes:91]

[0000936395-25-000041:notes:94]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest rate swaps was $350.0 million as of August 2, 2025 and November 2, 2024.

[0000936395-25-000041:notes:95]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of these interest rate swaps was $350.0 million as of August 2, 2025 and November 2, 2024.

[0000936395-25-000041:notes:96]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of August 2, 2025 and November 2, 2024.

[0000936395-25-000041:notes:97]
[same as prior period, unchanged from 0000936395-25-000025:notes:95]

[0000936395-25-000041:notes:98]
[same as prior period, unchanged from 0000936395-25-000025:notes:96]


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-25-000041:notes:99]
[same as prior period, unchanged from 0000936395-25-000025:notes:97]

[0000936395-25-000041:notes:100]
|  | Classification |  | Balance at August 2, 2025 |  | Balance at November 2, 2024 |
| Operating leases: |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 40,347 |  |  | $ | 27,417 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 49,192 |  |  | $ | 39,562 |  |

[0000936395-25-000041:notes:101]
Ciena added two new 10-year operating leases to its portfolio in the second quarter of fiscal 2025. The addition of these operating leases increased both operating right-of-use (“ROU”) assets and lease liabilities for fiscal 2025.


## us-gaap:DebtDisclosureTextBlock

[0000936395-25-000041:notes:102]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-25-000041:notes:103]
Refinanced 2030 Term Loan

[0000936395-25-000041:notes:104]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained a senior secured term loan with an outstanding aggregate principal amount, as of January 17, 2025, of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

[0000936395-25-000041:notes:105]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing

[0000936395-25-000041:notes:106]
Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

[0000936395-25-000041:notes:107]
•mature on October 24, 2030;

[0000936395-25-000041:notes:108]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date, with the balance payable at maturity;

[0000936395-25-000041:notes:109]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-25-000041:notes:110]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

[0000936395-25-000041:notes:111]
•be repayable at any time at Ciena’s election; and

[0000936395-25-000041:notes:112]
•except as described above or otherwise set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

[0000936395-25-000041:notes:113]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-25-000041:notes:114]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):

[0000936395-25-000041:notes:115]
|  |  | August 2, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,149,615 |  |  | $ | (3,738) |  |  | $ | (4,776) |  |  | $ | 1,141,101 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

[0000936395-25-000041:notes:116]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.7 million during both the first nine months of fiscal 2025 and fiscal 2024.

[0000936395-25-000041:notes:117]
As of August 2, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-25-000041:notes:118]
Outstanding Senior Notes Payable

[0000936395-25-000041:notes:119]
2030 Notes

[0000936395-25-000041:notes:120]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-25-000041:notes:121]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-25-000041:notes:122]
|  |  | August 2, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,054) |  |  | $ | 396,946 |  |  | $ | 396,427 |  |  |  |

[0000936395-25-000041:notes:123]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.5 million during both the first nine months of fiscal 2025 and fiscal 2024.

[0000936395-25-000041:notes:124]
As of August 2, 2025, the estimated fair value of the 2030 Notes was $376.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-25-000041:notes:125]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended August 2, 2025 (in thousands):

[0000936395-25-000041:notes:126]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 2, 2024 | $ | 798 |  |  | $ | (4,880) |  |  |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications | (430) |  |  | 2,871 |  |  |  |  | (2,826) |  |  | 5,619 |  |  | 5,234 |  |
| Amounts reclassified from AOCI | — |  |  | 2,932 |  |  |  |  | (6,284) |  |  | — |  |  | (3,352) |  |
| Balance at August 2, 2025 | $ | 368 |  |  | $ | 923 |  |  |  |  | $ | (442) |  |  | $ | (45,678) |  |  | $ | (44,829) |  |

[0000936395-25-000041:notes:127]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended July 27, 2024 (in thousands):

[0000936395-25-000041:notes:128]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications | 493 |  |  | (112) |  |  | 1,728 |  |  | 2,961 |  |  | 5,070 |  |
| Amounts reclassified from AOCI | — |  |  | 3,848 |  |  | (11,343) |  |  | — |  |  | (7,495) |  |
| Balance at July 27, 2024 | $ | 121 |  |  | $ | (4,420) |  |  | $ | 9,347 |  |  | $ | (45,240) |  |  | $ | (40,192) |  |

[0000936395-25-000041:notes:129]
[same as prior period, unchanged from 0000936395-25-000025:notes:127]


## us-gaap:EarningsPerShareTextBlock

[0000936395-25-000041:notes:130]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan, using the treasury stock method.

[0000936395-25-000041:notes:131]
[same as prior period, unchanged from 0000936395-25-000025:notes:129]

[0000936395-25-000041:notes:132]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income | $ | 50,308 |  |  | $ | 14,230 |  |  | $ | 103,849 |  |  | $ | 46,928 |  |
| Basic weighted average shares outstanding | 141,846 |  |  | 144,394 |  |  | 142,437 |  |  | 144,876 |  |
| Effect of dilutive potential common shares | 2,653 |  |  | 967 |  |  | 2,721 |  |  | 919 |  |
| Diluted weighted average shares | 144,499 |  |  | 145,361 |  |  | 145,158 |  |  | 145,795 |  |
| Basic EPS | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | 0.73 |  |  | $ | 0.32 |  |
| Diluted EPS | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | 0.72 |  |  | $ | 0.32 |  |
| Antidilutive employee share-based awards, excluded | 1,371 |  |  | 690 |  |  | 1,330 |  |  | 1,286 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-25-000041:notes:133]
[same as prior period, unchanged from 0000936395-25-000025:notes:131]

[0000936395-25-000041:notes:134]
[same as prior period, unchanged from 0000936395-25-000025:notes:132]

[0000936395-25-000041:notes:135]
During the first nine months of fiscal 2025, Ciena repurchased approximately 3.3 million shares of its common stock for an aggregate purchase price of approximately $245.2 million, which equates to an average price of $75.02 per share. As of August 2, 2025, Ciena has an aggregate of $754.8 million authorized and remaining under its stock repurchase program. Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0000936395-25-000041:notes:136]
[same as prior period, unchanged from 0000936395-25-000025:notes:134]

[0000936395-25-000041:notes:137]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $60.0 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2025 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-25-000041:notes:138]
[same as prior period, unchanged from 0000936395-25-000025:notes:136]

[0000936395-25-000041:notes:139]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Products | $ | 2,027 |  |  | $ | 1,660 |  |  | $ | 5,810 |  |  | $ | 4,738 |  |
| Services | 3,941 |  |  | 3,122 |  |  | 11,327 |  |  | 9,486 |  |
| Share-based compensation expense included in cost of goods sold | 5,968 |  |  | 4,782 |  |  | 17,137 |  |  | 14,224 |  |
| Research and development | 16,749 |  |  | 13,118 |  |  | 48,007 |  |  | 40,064 |  |
| Selling and marketing | 13,277 |  |  | 10,315 |  |  | 38,523 |  |  | 31,786 |  |
| General and administrative | 11,008 |  |  | 9,257 |  |  | 32,176 |  |  | 29,211 |  |
| Share-based compensation expense included in operating expense | 41,034 |  |  | 32,690 |  |  | 118,706 |  |  | 101,061 |  |
| Share-based compensation expense capitalized in inventory, net | (74) |  |  | (114) |  |  | (147) |  |  | 148 |  |
| Total share-based compensation expense | $ | 46,928 |  |  | $ | 37,358 |  |  | $ | 135,696 |  |  | $ | 115,433 |  |

[0000936395-25-000041:notes:140]
As of August 2, 2025, total unrecognized share-based compensation expense was approximately $284.0 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-25-000041:notes:141]
[same as prior period, unchanged from 0000936395-25-000025:notes:139]

[0000936395-25-000041:notes:142]
[same as prior period, unchanged from 0000936395-25-000025:notes:140]

[0000936395-25-000041:notes:143]
[same as prior period, unchanged from 0000936395-25-000025:notes:141]

[0000936395-25-000041:notes:144]
[same as prior period, unchanged from 0000936395-25-000025:notes:142]

[0000936395-25-000041:notes:145]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to net income for the periods presented (in thousands):

[0000936395-25-000041:notes:146]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 181,993 |  |  | $ | 106,870 |  |  | $ | 482,784 |  |  | $ | 387,211 |  |
| Platform Software and Services | 54,529 |  |  | 53,131 |  |  | 168,077 |  |  | 165,171 |  |
| Blue Planet Automation Software and Services | 4,192 |  |  | 4,705 |  |  | 13,059 |  |  | (10,127) |  |
| Global Services | 50,467 |  |  | 50,351 |  |  | 144,389 |  |  | 145,776 |  |
| Total segment profit | 291,181 |  |  | 215,057 |  |  | 808,309 |  |  | 688,031 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 148,724 |  |  | 121,520 |  |  | 424,911 |  |  | 373,749 |  |
| General and administrative | 60,596 |  |  | 58,248 |  |  | 171,450 |  |  | 162,504 |  |
| Significant asset impairments and restructuring costs | 1,770 |  |  | 1,361 |  |  | 5,262 |  |  | 21,987 |  |
| Amortization of intangible assets | 6,556 |  |  | 7,185 |  |  | 19,646 |  |  | 22,384 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 15,090 |  |  | 14,013 |  |  | 34,539 |  |  | 36,460 |  |
| Interest expense | (22,806) |  |  | (24,401) |  |  | (67,421) |  |  | (72,038) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (729) |  |  | — |  |
| Less: Provision for income taxes | 15,511 |  |  | 2,125 |  |  | 49,580 |  |  | 24,901 |  |
| Net income | $ | 50,308 |  |  | $ | 14,230 |  |  | $ | 103,849 |  |  | $ | 46,928 |  |

[0000936395-25-000041:notes:147]
[same as prior period, unchanged from 0000936395-25-000025:notes:145]

[0000936395-25-000041:notes:148]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of August 2, 2025, equipment, building, furniture and fixtures, net, totaled $368.3 million, and operating ROU assets totaled $40.3 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of August 2, 2025, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-25-000041:notes:149]
|  | August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 137,558 |  |  | — |  |  | 1,115 |  |  | — |  |  | $ | 138,673 |  |
| Goodwill | $ | 199,588 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 444,828 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 86,431 |  |  | $ | 86,431 |  |

[0000936395-25-000041:notes:150]
[same as prior period, unchanged from 0000936395-25-000025:notes:148]

[0000936395-25-000041:notes:151]
|  | August 2,2025 |  | November 2,2024 |
| Canada | $ | 311,313 |  |  | $ | 283,760 |  |
| United States | 44,432 |  |  | 49,195 |  |
| Other International | 52,950 |  |  | 32,184 |  |
| Total | $ | 408,695 |  |  | $ | 365,139 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-25-000041:notes:152]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-25-000041:notes:153]
Ciena is subject to various tax contingencies arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these contingencies will have a material effect on its financial position or cash flows.

[0000936395-25-000041:notes:154]
Litigation

[0000936395-25-000041:notes:155]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-25-000041:notes:156]
Purchase Obligations

[0000936395-25-000041:notes:157]
Ciena has certain advanced commitments for supply of certain long lead time components. As of August 2, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-25-000041:notes:158]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-25-000041:notes:159]
From the end of the third quarter of fiscal 2025 through August 29, 2025, Ciena repurchased 286,619 shares of its common stock for an aggregate purchase price of $26.4 million at an average price of $92.10 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of August 29, 2025, Ciena has an aggregate of $728.4 million of authorized funds remaining under this repurchase program.

[0000936395-25-000041:notes:160]
Reallocation of Innovation Investment and Fiscal 2025 Restructuring Plan

[0000936395-25-000041:notes:161]
On August 26, 2025, in order to align Ciena’s strategic investments with our highest-growth demand opportunities, its executive team determined to cease forward investment in certain broadband development initiatives, primarily 25G PON, within the routing and switching product line of the Network Platforms operating segment. Ciena intends to continue support and development of its 10G PON-based products.

[0000936395-25-000041:notes:162]
Ciena’s executive team also approved a restructuring plan intended to deliver increased operating efficiencies and, as a result, commencing during the fourth quarter of fiscal 2025, Ciena is implementing a workforce reduction of approximately 4%

[0000936395-25-000041:notes:163]
to 5% of its global headcount, which includes employees associated with the broadband development initiatives discussed above. 
The estimated cash cost related to these actions is approximately $20.0 million and represents employee severance and related costs. As such, we expect an expense of approximately $20.0 million to be incurred in the fourth quarter of fiscal 2025. In addition, Ciena anticipates that its decision to cease future investment in 25G PON will result in a non-cash charge in the fourth quarter of fiscal 2025 related to the abandonment of its in-process R&D intangible asset, which has a carrying value of $89.1 million as of August 2, 2025. During the fourth quarter of fiscal 2025, Ciena will also evaluate the impact of these actions on other assets including, but not limited to, inventory and fixed assets.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000936395-25-000041:notes:164]
The following table describes, for the third quarter of fiscal 2025, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0000936395-25-000041:notes:165]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Dino DiPerna(Senior Vice President, Global Research & Development) | Adoption (July 11, 2025) | Rule 10b5-1 trading arrangement | Sales | Until July 24, 2026, or such earlier date upon which all transactions are completed or expire without execution (1) | (2) |
| Brodie Gage(Senior Vice President, Global Products & Supply Chain) | Adoption (July 1, 2025) | Rule 10b5-1 trading arrangement | Sales | Until December 31, 2026, or such earlier date upon which all transactions are completed or expire without execution (3) | Up to 7,150 shares of common stock |

[0000936395-25-000041:notes:166]
(1)    Sales under this arrangement will not begin until November 17, 2025, following expiration of Mr. DiPerna’s existing Rule 10b5-1 trading arrangement.

[0000936395-25-000041:notes:167]
(2)    The aggregate number of shares of common stock to be sold pursuant to Mr. DiPerna’s arrangement is up to (i) 6,391 shares of common stock, plus (ii) up to 50% of the net after-tax shares of common stock to be received as a result of the vesting on December 20, 2025 of an aggregate of (a) 2,616 earned performance stock units, (b) performance stock units that have not yet been earned, the actual number of which depends on performance and ranges from 0% to 200% of the 3,829 shares subject to the award at the target level of performance, and (c) 3,965 restricted stock units, plus (iii) up to 50% of the net after-tax shares of common stock to be received as a result of the vesting on March 20, 2026 of an aggregate of up to 3,368 restricted stock units, plus (iv) up to 50% of the net after-tax shares of common stock to be received as a result of the vesting on June 20, 2026 of an aggregate of 3,370 restricted stock units. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.

[0000936395-25-000041:notes:168]
(3)    Sales under this arrangement will not begin until December 15, 2025, following expiration of Mr. Gage’s existing Rule 10b5-1 trading arrangement.
