# CIEN 8-K — 0000936395-25-000037 filed 2025-09-04

## item codes, every 8-K on or before 2025-09-04

- 2025-09-04 0000936395-25-000037 — 2.02, 9.01
- 2025-06-18 0000936395-25-000029 — 5.02, 7.01, 9.01
- 2025-06-05 0000936395-25-000023 — 2.02, 9.01
- 2025-04-01 0000936395-25-000015 — 5.07
- 2025-03-11 0000936395-25-000005 — 2.02, 9.01
- 2025-01-21 0001193125-25-009588 — 1.01, 2.03, 9.01
- 2024-12-12 0000936395-24-000037 — 2.02, 5.02, 5.03, 7.01, 9.01
- 2024-10-02 0000936395-24-000035 — 8.01, 9.01
- 2024-09-04 0000936395-24-000030 — 2.02, 5.02, 9.01
- 2024-06-06 0000936395-24-000022 — 2.02, 9.01
- 2024-04-23 0000936395-24-000014 — 5.02
- 2024-03-26 0000936395-24-000012 — 5.01, 5.02, 9.01
- 2024-03-07 0000936395-24-000006 — 2.02, 9.01
- 2023-12-07 0000936395-23-000041 — 2.02, 9.01
- 2023-10-25 0001193125-23-263172 — 1.01, 1.02, 2.03, 9.01
- 2023-10-03 0000936395-23-000037 — 5.02, 7.01, 9.01
- 2023-08-31 0000936395-23-000030 — 2.02, 5.02, 9.01
- 2023-06-06 0000936395-23-000024 — 2.02, 9.01
- 2023-04-06 0001193125-23-093438 — 7.01, 9.01
- 2023-04-03 0000936395-23-000018 — 5.07
- 2023-03-06 0000936395-23-000009 — 2.02, 9.01
- 2023-02-15 0001193125-23-040339 — 1.01, 9.01
- 2023-01-27 0001193125-23-017784 — 5.03, 9.01
- 2023-01-24 0000936395-23-000003 — 5.02
- 2023-01-23 0001193125-23-012175 — 1.01, 2.03, 9.01
- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2025-09-04

- none on or before 2025-09-04

## item 2.02 — earnings release, exhibit 99.1

[0000936395-25-000037:8k_2_02:1]
EX-99.1
2
ex9912025q3earningspressre.htm
EX-99.1

[0000936395-25-000037:8k_2_02:2]
Document

[0000936395-25-000037:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-25-000037:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2025 Financial Results

[0000936395-25-000037:8k_2_02:5]
HANOVER, Md. - September 4, 2025 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal third quarter ended August 2, 2025.

[0000936395-25-000037:8k_2_02:6]
•Q3 Revenue: $1.22 billion

[0000936395-25-000037:8k_2_02:7]
•Q3 Net Income per Share: $0.35 GAAP; $0.67 adjusted (non-GAAP)

[0000936395-25-000037:8k_2_02:8]
•Share Repurchases: Repurchased approximately 1.0 million shares of common stock for an aggregate price of $81.8 million during the quarter

[0000936395-25-000037:8k_2_02:9]
"We delivered another strong quarterly performance that reflects our leadership in high-speed connectivity and ongoing accelerated customer demand as the network becomes fundamental to the underpinning, growth, and monetization of AI," said Gary Smith, president and CEO, Ciena. "With visibility well into fiscal year 2026, we are confident in the continued momentum of our business and remain focused on further expanding our operating leverage as we continue to grow."

[0000936395-25-000037:8k_2_02:10]
For the fiscal third quarter 2025, Ciena reported revenue of $1.22 billion as compared to $942.3 million for the fiscal third quarter 2024.

[0000936395-25-000037:8k_2_02:11]
Ciena's GAAP net income for the fiscal third quarter 2025 was $50.3 million, or $0.35 per diluted common share, which compares to a GAAP net income of $14.2 million, or $0.10 per diluted common share, for the fiscal third quarter 2024.

[0000936395-25-000037:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2025 was $96.2 million, or $0.67 per diluted common share, which compares to an adjusted (non-GAAP) net income of $50.8 million, or $0.35 per diluted common share, for the fiscal third quarter 2024.

[0000936395-25-000037:8k_2_02:13]
Fiscal Third Quarter 2025 Performance Summary

[0000936395-25-000037:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-25-000037:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |
|  |  | FY 2025 |  | FY 2024 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,219.4 |  |  | $ | 942.3 |  |  | 29.4 | % |  |  |  |  |  |  |
| Gross margin |  | 41.3 | % |  | 42.9 | % |  | (1.6) | % |  |  |  |  |  |  |
| Operating expense |  | $ | 429.5 |  |  | $ | 377.2 |  |  | 13.9 | % |  |  |  |  |  |  |
| Operating margin |  | 6.1 | % |  | 2.9 | % |  | 3.2 | % |  |  |  |  |  |  |

[0000936395-25-000037:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Q3 |  | Q3 |  | Period Change |  |  |  |  |
|  |  | FY 2025 |  | FY 2024 |  | Y-T-Y* |  |  |  |  |  |  |
| Revenue |  | $ | 1,219.4 |  |  | $ | 942.3 |  |  | 29.4 | % |  |  |  |  |  |  |
| Adj. gross margin |  | 41.9 | % |  | 43.7 | % |  | (1.8) | % |  |  |  |  |  |  |
| Adj. operating expense |  | $ | 380.2 |  |  | $ | 336.0 |  |  | 13.2 | % |  |  |  |  |  |  |
| Adj. operating margin |  | 10.7 | % |  | 8.0 | % |  | 2.7 | % |  |  |  |  |  |  |
| Adj. EBITDA |  | $ | 158.0 |  |  | $ | 98.5 |  |  | 60.4 | % |  |  |  |  |  |  |

[0000936395-25-000037:8k_2_02:17]
*  Denotes % change, or in the case of margin, absolute change

[0000936395-25-000037:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Q3 FY 2025 |  | Q3 FY 2024 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Optical Networking |  | $ | 815.5 |  |  | 66.9 |  |  | $ | 606.8 |  |  | 64.4 |  |
| Routing and Switching |  | 125.9 |  |  | 10.3 |  |  | 92.7 |  |  | 9.8 |  |
| Total Networking Platforms |  | 941.4 |  |  | 77.2 |  |  | 699.5 |  |  | 74.2 |  |
| Platform Software and Services |  | 90.0 |  |  | 7.4 |  |  | 83.2 |  |  | 8.9 |  |
| Blue Planet Automation Software and Services |  | 27.8 |  |  | 2.3 |  |  | 25.8 |  |  | 2.7 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 80.7 |  |  | 6.6 |  |  | 74.4 |  |  | 7.9 |  |
| Installation and Deployment |  | 65.9 |  |  | 5.4 |  |  | 46.5 |  |  | 4.9 |  |
| Consulting and Network Design |  | 13.6 |  |  | 1.1 |  |  | 12.9 |  |  | 1.4 |  |
| Total Global Services |  | 160.2 |  |  | 13.1 |  |  | 133.8 |  |  | 14.2 |  |
| Total |  | $ | 1,219.4 |  |  | 100.0 |  |  | $ | 942.3 |  |  | 100.0 |  |

[0000936395-25-000037:8k_2_02:19]
**  Denotes % of total revenue

[0000936395-25-000037:8k_2_02:20]
2

[0000936395-25-000037:8k_2_02:21]
Additional Performance Metrics for Fiscal Third Quarter 2025

[0000936395-25-000037:8k_2_02:22]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Q3 FY 2025 |  | Q3 FY 2024 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 923.6 |  |  | 75.7 |  |  | $ | 718.6 |  |  | 76.3 |  |
| Europe, Middle East and Africa |  | 186.0 |  |  | 15.3 |  |  | 135.0 |  |  | 14.3 |  |
| Asia Pacific |  | 109.8 |  |  | 9.0 |  |  | 88.7 |  |  | 9.4 |  |
| Total |  | $ | 1,219.4 |  |  | 100.0 |  |  | $ | 942.3 |  |  | 100.0 |  |

[0000936395-25-000037:8k_2_02:23]
**  Denotes % of total revenue

[0000936395-25-000037:8k_2_02:24]
•Two customers represented 10%-plus of revenue combining for a total of 28.8% of revenue

[0000936395-25-000037:8k_2_02:25]
•Cash and investments totaled $1.39 billion

[0000936395-25-000037:8k_2_02:26]
•Cash flow from operations totaled $174.3 million

[0000936395-25-000037:8k_2_02:27]
•Average days' sales outstanding (DSOs) were 88

[0000936395-25-000037:8k_2_02:28]
•Accounts receivable, net balance was $1.03 billion

[0000936395-25-000037:8k_2_02:29]
•Unbilled contract asset, net balance was $164.3 million

[0000936395-25-000037:8k_2_02:30]
•Inventories totaled $860.4 million, including:

[0000936395-25-000037:8k_2_02:31]
◦Raw materials: $642.7 million

[0000936395-25-000037:8k_2_02:32]
◦Work in process: $35.6 million

[0000936395-25-000037:8k_2_02:33]
◦Finished goods: $261.8 million

[0000936395-25-000037:8k_2_02:34]
◦Deferred cost of sales: $41.8 million

[0000936395-25-000037:8k_2_02:35]
◦Reserve for excess and obsolescence: $(121.5) million

[0000936395-25-000037:8k_2_02:36]
•Product inventory turns were 2.7

[0000936395-25-000037:8k_2_02:37]
•Headcount totaled 9,213

[0000936395-25-000037:8k_2_02:38]
Business Outlook for Fiscal Fourth Quarter 2025

[0000936395-25-000037:8k_2_02:39]
Ciena expects fiscal fourth quarter 2025 financial performance to include:

[0000936395-25-000037:8k_2_02:40]
• Revenue in the range of $1.24 billion to $1.32 billion

[0000936395-25-000037:8k_2_02:41]
• Adjusted (non-GAAP) gross margin between 42% to 43%

[0000936395-25-000037:8k_2_02:42]
• Adjusted (non-GAAP) operating expense in a range of $390 million to $400 million

[0000936395-25-000037:8k_2_02:43]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2025 Results

[0000936395-25-000037:8k_2_02:44]
Today, Thursday, September 4, 2025, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal third quarter 2025 results.

[0000936395-25-000037:8k_2_02:45]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com. An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-25-000037:8k_2_02:46]
Notes to Investors

[0000936395-25-000037:8k_2_02:47]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered another strong quarterly performance that reflects our leadership in high-speed connectivity and ongoing accelerated customer demand as the network becomes fundamental to the underpinning, growth, and monetization of AI. With visibility well into fiscal year 2026, we are confident in the continued momentum of our business and remain focused on further expanding our operating leverage as we continue to grow."

[0000936395-25-000037:8k_2_02:48]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers, their spending and their businesses and markets; our ability to execute our business and growth strategies; the impact of macroeconomic conditions and global supply chain constraints or disruptions including increased supply costs and lead times; the impact of the introduction of new technologies by us or our competitors;  the timing and size of customer orders, their delivery dates and our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical tensions or events, including but not limited to the ongoing conflicts between Ukraine and Russia, and Israel and Hamas, and public health emergencies or epidemics and pandemics; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; cyberattacks, data breaches or other security incidents involving our enterprise network environment or our products; regulatory changes, litigation involving our intellectual property or government investigations; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Annual Report on Form 10-K filed with the SEC on December 20, 2024 and included in its Quarterly Report on Form 10-Q for the third quarter of fiscal 2025 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-25-000037:8k_2_02:49]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-25-000037:8k_2_02:50]
With respect to Ciena’s expectations under “Business Outlook for Fiscal Fourth Quarter 2025” above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin and adjusted (non-GAAP) operating expense guidance measures to the corresponding gross profit and gross profit percentage, and operating

[0000936395-25-000037:8k_2_02:51]
4

[0000936395-25-000037:8k_2_02:52]
expense GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty. For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0000936395-25-000037:8k_2_02:53]
About Ciena. Ciena (NYSE: CIEN) is a global leader in networking systems, services, and software. We build the most adaptive networks in the industry, enabling customers to anticipate and meet ever-increasing digital demands. For three-plus decades, Ciena has brought our humanity to our relentless pursuit of innovation. Prioritizing collaborative relationships with our customers, partners, and communities, we create flexible, open, and sustainable networks that better serve all users—today and into the future. For updates on Ciena, follow us on LinkedIn, X, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-25-000037:8k_2_02:54]
CIENA CORPORATION

[0000936395-25-000037:8k_2_02:55]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-25-000037:8k_2_02:56]
(in thousands, except per share data)

[0000936395-25-000037:8k_2_02:57]
(unaudited)

[0000936395-25-000037:8k_2_02:58]
|  | Quarter Ended |  | Nine Months Ended |
|  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 976,801 |  |  | $ | 729,503 |  |  | $ | 2,730,167 |  |  | $ | 2,266,596 |  |
| Services | 242,584 |  |  | 212,805 |  |  | 687,356 |  |  | 624,247 |  |
| Total revenue | 1,219,385 |  |  | 942,308 |  |  | 3,417,523 |  |  | 2,890,843 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 580,028 |  |  | 433,533 |  |  | 1,620,816 |  |  | 1,315,737 |  |
| Services | 136,278 |  |  | 104,830 |  |  | 368,969 |  |  | 315,538 |  |
| Total cost of goods sold | 716,306 |  |  | 538,363 |  |  | 1,989,785 |  |  | 1,631,275 |  |
| Gross profit | 503,079 |  |  | 403,945 |  |  | 1,427,738 |  |  | 1,259,568 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 211,898 |  |  | 188,888 |  |  | 619,429 |  |  | 571,537 |  |
| Selling and marketing | 148,724 |  |  | 121,520 |  |  | 424,911 |  |  | 373,749 |  |
| General and administrative | 60,596 |  |  | 58,248 |  |  | 171,450 |  |  | 162,504 |  |
| Significant asset impairments and restructuring costs | 1,770 |  |  | 1,361 |  |  | 5,262 |  |  | 21,987 |  |
| Amortization of intangible assets | 6,556 |  |  | 7,185 |  |  | 19,646 |  |  | 22,384 |  |
| Total operating expenses | 429,544 |  |  | 377,202 |  |  | 1,240,698 |  |  | 1,152,161 |  |
| Income from operations | 73,535 |  |  | 26,743 |  |  | 187,040 |  |  | 107,407 |  |
| Interest and other income, net | 15,090 |  |  | 14,013 |  |  | 34,539 |  |  | 36,460 |  |
| Interest expense | (22,806) |  |  | (24,401) |  |  | (67,421) |  |  | (72,038) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (729) |  |  | — |  |
| Income before income taxes | 65,819 |  |  | 16,355 |  |  | 153,429 |  |  | 71,829 |  |
| Provision for income taxes | 15,511 |  |  | 2,125 |  |  | 49,580 |  |  | 24,901 |  |
| Net income | $ | 50,308 |  |  | $ | 14,230 |  |  | $ | 103,849 |  |  | $ | 46,928 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | 0.73 |  |  | $ | 0.32 |  |
| Diluted net income per potential common share | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | 0.72 |  |  | $ | 0.32 |  |
| Weighted average basic common shares outstanding | 141,846 |  |  | 144,394 |  |  | 142,437 |  |  | 144,876 |  |
| Weighted average dilutive potential common shares outstanding1 | 144,499 |  |  | 145,361 |  |  | 145,158 |  |  | 145,795 |  |

[0000936395-25-000037:8k_2_02:59]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 2.7 million for both the third quarter and first nine months of fiscal 2025; and (ii) 1.0 million and 0.9 million for the third quarter and first nine months of fiscal 2024, respectively.

[0000936395-25-000037:8k_2_02:60]
6

[0000936395-25-000037:8k_2_02:61]
CIENA CORPORATION

[0000936395-25-000037:8k_2_02:62]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-25-000037:8k_2_02:63]
(in thousands, except share data)

[0000936395-25-000037:8k_2_02:64]
(unaudited)

[0000936395-25-000037:8k_2_02:65]
|  | August 2,2025 |  | November 2,2024 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,055,976 |  |  | $ | 934,863 |  |
| Short-term investments | 270,380 |  |  | 316,343 |  |
| Accounts receivable, net | 1,025,563 |  |  | 908,597 |  |
| Inventories, net | 860,403 |  |  | 820,430 |  |
| Prepaid expenses and other | 473,901 |  |  | 564,183 |  |
| Total current assets | 3,686,223 |  |  | 3,544,416 |  |
| Long-term investments | 64,397 |  |  | 80,920 |  |
| Equipment, building, furniture and fixtures, net | 368,348 |  |  | 337,722 |  |
| Operating right-of-use assets | 40,347 |  |  | 27,417 |  |
| Goodwill | 444,828 |  |  | 444,707 |  |
| Other intangible assets, net | 138,673 |  |  | 165,020 |  |
| Deferred tax asset, net | 851,903 |  |  | 886,441 |  |
| Other long-term assets | 154,059 |  |  | 154,694 |  |
| Total assets | $ | 5,748,778 |  |  | $ | 5,641,337 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 464,684 |  |  | $ | 423,401 |  |
| Accrued liabilities and other short-term obligations | 436,312 |  |  | 393,905 |  |
| Deferred revenue | 196,209 |  |  | 156,379 |  |
| Operating lease liabilities | 14,694 |  |  | 14,455 |  |
| Current portion of long-term debt | 11,580 |  |  | 11,700 |  |
| Total current liabilities | 1,123,479 |  |  | 999,840 |  |
| Long-term deferred revenue | 81,057 |  |  | 81,240 |  |
| Other long-term obligations | 195,976 |  |  | 185,938 |  |
| Long-term operating lease liabilities | 34,498 |  |  | 25,107 |  |
| Long-term debt, net | 1,526,467 |  |  | 1,533,074 |  |
| Total liabilities | 2,961,477 |  |  | 2,825,199 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 141,342,527 and 142,656,116 shares issued and outstanding | 1,413 |  |  | 1,427 |  |
| Additional paid-in capital | 6,020,315 |  |  | 6,154,869 |  |
| Accumulated other comprehensive loss | (44,829) |  |  | (46,711) |  |
| Accumulated deficit | (3,189,598) |  |  | (3,293,447) |  |
| Total stockholders’ equity | 2,787,301 |  |  | 2,816,138 |  |
| Total liabilities and stockholders’ equity | $ | 5,748,778 |  |  | $ | 5,641,337 |  |

[0000936395-25-000037:8k_2_02:66]
CIENA CORPORATION

[0000936395-25-000037:8k_2_02:67]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-25-000037:8k_2_02:68]
(in thousands)

[0000936395-25-000037:8k_2_02:69]
(unaudited)

[0000936395-25-000037:8k_2_02:70]
|  | Nine Months Ended |
|  | August 2, |  | July 27, |
|  | 2025 |  | 2024 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 103,849 |  |  | $ | 46,928 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 76,637 |  |  | 68,997 |  |
| Share-based compensation expense | 135,696 |  |  | 115,433 |  |
| Amortization of intangible assets | 26,343 |  |  | 30,675 |  |
| Deferred taxes | (21,709) |  |  | (19,909) |  |
| Provision for inventory excess and obsolescence | 34,185 |  |  | 35,400 |  |
| Provision for warranty | 16,302 |  |  | 14,708 |  |
| Other | (1,838) |  |  | 11,968 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (116,887) |  |  | 92,421 |  |
| Inventories | (73,493) |  |  | 78,220 |  |
| Prepaid expenses and other | 137,440 |  |  | (221,823) |  |
| Operating lease right-of-use assets | 8,759 |  |  | 8,963 |  |
| Accounts payable, accruals and other obligations | 83,354 |  |  | (112,352) |  |
| Deferred revenue | 38,246 |  |  | 28,833 |  |
| Short and long-term operating lease liabilities | (11,868) |  |  | (13,290) |  |
| Net cash provided by operating activities | 435,016 |  |  | 165,172 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, and fixtures | (95,373) |  |  | (53,098) |  |
| Purchases of investments | (191,335) |  |  | (197,303) |  |
| Proceeds from sales and maturities of investments | 261,611 |  |  | 114,899 |  |
| Settlement of foreign currency forward contracts, net | (2,635) |  |  | (362) |  |
| Purchase of equity investments | — |  |  | (21,682) |  |
| Net cash used in investing activities | (27,732) |  |  | (157,546) |  |
| Cash flows used in financing activities: |  |  |  |
| Proceeds for modification of debt, net | 19,175 |  |  | — |  |
| Cash paid for extinguishment of debt | (19,175) |  |  | — |  |
| Payment of long term debt | (8,685) |  |  | (5,850) |  |
| Payment of debt issuance costs | (12) |  |  | (2,554) |  |
| Payment of finance lease obligations | (3,244) |  |  | (3,004) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (60,043) |  |  | (33,450) |  |
| Repurchases of common stock - repurchase program, net | (250,035) |  |  | (125,816) |  |
| Proceeds from issuance of common stock | 35,874 |  |  | 34,292 |  |
| Net cash used in financing activities | (286,145) |  |  | (136,382) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 60 |  |  | 1,499 |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 121,199 |  |  | (127,257) |  |
| Cash, cash equivalents and restricted cash at beginning of period | 935,026 |  |  | 1,010,786 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,056,225 |  |  | $ | 883,529 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest, net | $ | 68,243 |  |  | $ | 64,999 |  |
| Cash paid during the period for income taxes, net | $ | 84,898 |  |  | $ | 41,736 |  |
| Operating lease payments | $ | 13,246 |  |  | $ | 14,672 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 14,819 |  |  | $ | 35,316 |  |
| Repurchase of common stock in accrued liabilities from repurchase program, net | $ | 2,231 |  |  | $ | 1,762 |  |
| Operating right-of-use assets subject to lease liability | $ | 21,850 |  |  | $ | 5,326 |  |

[0000936395-25-000037:8k_2_02:71]
8

[0000936395-25-000037:8k_2_02:72]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | August 2, |  | July 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 503,079 |  |  | $ | 403,945 |  |  |  |  |  |
| Share-based compensation-products |  | 2,027 |  |  | 1,660 |  |  |  |  |  |
| Share-based compensation-services |  | 3,942 |  |  | 3,122 |  |  |  |  |  |
| Amortization of intangible assets |  | 2,232 |  |  | 2,764 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 8,201 |  |  | 7,546 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit |  | $ | 511,280 |  |  | $ | 411,491 |  |  |  |  |  |
| Adjusted (non-GAAP) gross profit percentage |  | 41.9 | % |  | 43.7 | % |  |  |  |  |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 429,544 |  |  | $ | 377,202 |  |  |  |  |  |
| Share-based compensation-research and development |  | 16,749 |  |  | 13,118 |  |  |  |  |  |
| Share-based compensation-sales and marketing |  | 13,277 |  |  | 10,315 |  |  |  |  |  |
| Share-based compensation-general and administrative |  | 11,008 |  |  | 9,257 |  |  |  |  |  |
| Significant asset impairments and restructuring costs |  | 1,770 |  |  | 1,361 |  |  |  |  |  |
| Amortization of intangible assets |  | 6,556 |  |  | 7,185 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 49,360 |  |  | 41,236 |  |  |  |  |  |
| Adjusted (non-GAAP) operating expense |  | $ | 380,184 |  |  | $ | 335,966 |  |  |  |  |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 73,535 |  |  | $ | 26,743 |  |  |  |  |  |
| Total adjustments related to gross profit |  | 8,201 |  |  | 7,546 |  |  |  |  |  |
| Total adjustments related to operating expense |  | 49,360 |  |  | 41,236 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 57,561 |  |  | 48,782 |  |  |  |  |  |
| Adjusted (non-GAAP) income from operations |  | $ | 131,096 |  |  | $ | 75,525 |  |  |  |  |  |
| Adjusted (non-GAAP) operating margin percentage |  | 10.7 | % |  | 8.0 | % |  |  |  |  |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 50,308 |  |  | $ | 14,230 |  |  |  |  |  |
| Exclude GAAP provision for income taxes |  | 15,511 |  |  | 2,125 |  |  |  |  |  |
| Income before income taxes |  | 65,819 |  |  | 16,355 |  |  |  |  |  |
| Total adjustments related to income from operations |  | 57,561 |  |  | 48,782 |  |  |  |  |  |
| Adjusted income before income taxes |  | 123,380 |  |  | 65,137 |  |  |  |  |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 27,144 |  |  | 14,330 |  |  |  |  |  |
| Adjusted (non-GAAP) net income |  | $ | 96,236 |  |  | $ | 50,807 |  |  |  |  |  |
| Weighted average basic common shares outstanding |  | 141,846 |  | 144,394 |  |  |  |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 144,499 |  | 145,361 |  |  |  |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.35 |  |  | $ | 0.10 |  |  |  |  |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.67 |  |  | $ | 0.35 |  |  |  |  |  |

[0000936395-25-000037:8k_2_02:73]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 2.7 million for the third quarter of fiscal 2025; and (ii) 1.0 million for the third quarter of fiscal 2024.

[0000936395-25-000037:8k_2_02:74]
9

[0000936395-25-000037:8k_2_02:75]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  |  |
|  |  | August 2, |  | July 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 50,308 |  |  | $ | 14,230 |  |  |  |  |  |
| Add: Interest expense |  | 22,806 |  |  | 24,401 |  |  |  |  |  |
| Less: Interest and other income, net |  | 15,090 |  |  | 14,013 |  |  |  |  |  |
| Add: Provision for income taxes |  | 15,511 |  |  | 2,125 |  |  |  |  |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 26,866 |  |  | 22,981 |  |  |  |  |  |
| Add: Amortization of intangible assets |  | 8,788 |  |  | 9,949 |  |  |  |  |  |
| EBITDA |  | $ | 109,189 |  |  | $ | 59,673 |  |  |  |  |  |
| Add: Share-based compensation expense |  | 47,003 |  |  | 37,472 |  |  |  |  |  |
| Add: Significant asset impairments and restructuring costs |  | 1,770 |  |  | 1,361 |  |  |  |  |  |
| Adjusted EBITDA |  | $ | 157,962 |  |  | $ | 98,506 |  |  |  |  |  |

[0000936395-25-000037:8k_2_02:76]
* * *

[0000936395-25-000037:8k_2_02:77]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-25-000037:8k_2_02:78]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-25-000037:8k_2_02:79]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes and restructuring certain real estate facilities.

[0000936395-25-000037:8k_2_02:80]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over an expected useful life.

[0000936395-25-000037:8k_2_02:81]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 22.0% for both the third quarter of fiscal 2025 and fiscal 2024. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
