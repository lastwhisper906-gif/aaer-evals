# CIEN note change history — 0000936395-25-000025 → 0000936395-25-000041


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:1]
Ciena has certain advanced commitments for supply of certain long lead time components. As of August 2, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.
  (was, 2025-06-05, similarity 0.9894):
[0000936395-25-000025:note_history:1]
Ciena has certain advanced commitments for supply of certain long lead time components. As of May 3, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected.
  (was, 2025-06-05, similarity 0.9927):
[0000936395-25-000025:note_history:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:3]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Ciena is currently evaluating the impact of this ASU on its segment disclosures.
  (was, 2025-06-05, similarity 0.7991):
[0000936395-25-000025:note_history:3]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

- changed (2025-09-04):
[0000936395-25-000041:note_history:4]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.
  (was, 2025-06-05, similarity 0.9597):
[0000936395-25-000025:note_history:4]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

- added (2025-09-04):
[0000936395-25-000041:note_history:5]
In July 2025, the FASB issued ASU No. 2025-05 (“ASU 2025-05”), Financial Instruments - Credit Losses (Topic 326): Measurement of Credit Losses for Accounts Receivable and Contract Assets, to introduce a practical expedient for all entities, which simplifies the calculation required for estimating credit losses and assumes that current conditions as of the balance sheet date do not change for the remaining life of the asset. ASU 2025-05 is effective for annual reporting periods beginning after December 15, 2025, and interim reporting periods within those annual reporting periods; however, early adoption is permitted. ASU 2025-25 allows for adoption using a prospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-09-04):
[0000936395-25-000041:note_history:6]
•be repayable at any time at Ciena’s election; and

- added (2025-09-04):
[0000936395-25-000041:note_history:7]
|  |  | August 2, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,149,615 |  |  | $ | (3,738) |  |  | $ | (4,776) |  |  | $ | 1,141,101 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:8]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.7 million during both the first nine months of fiscal 2025 and fiscal 2024.
  (was, 2025-06-05, similarity 0.9905):
[0000936395-25-000025:note_history:8]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.5 million during both the first six months of fiscal 2025 and fiscal 2024.

- changed (2025-09-04):
[0000936395-25-000041:note_history:9]
As of August 2, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.15 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-06-05, similarity 0.9863):
[0000936395-25-000025:note_history:9]
As of May 3, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.14 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2025-09-04):
[0000936395-25-000041:note_history:10]
|  |  | August 2, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,054) |  |  | $ | 396,946 |  |  | $ | 396,427 |  |  |  |
  (was, 2025-06-05, similarity 0.9788):
[0000936395-25-000025:note_history:10]
|  |  | May 3, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,227) |  |  | $ | 396,773 |  |  | $ | 396,427 |  |  |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:11]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.5 million during both the first nine months of fiscal 2025 and fiscal 2024.
  (was, 2025-06-05, similarity 0.9018):
[0000936395-25-000025:note_history:11]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.3 million during both the first six months of fiscal 2025 and fiscal 2024.

- changed (2025-09-04):
[0000936395-25-000041:note_history:12]
As of August 2, 2025, the estimated fair value of the 2030 Notes was $376.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-06-05, similarity 0.9853):
[0000936395-25-000025:note_history:12]
As of May 3, 2025, the estimated fair value of the 2030 Notes was $370.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2025-09-04):
[0000936395-25-000025:note_history:13]
•be repayable at any time at Ciena’s election, provided that repayment of the Refinanced 2030 Term Loan with proceeds of certain indebtedness prior to July 17, 2025 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and

- removed (2025-09-04):
[0000936395-25-000025:note_history:14]
|  |  | May 3, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,152,510 |  |  | $ | (3,921) |  |  | $ | (5,006) |  |  | $ | 1,143,583 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-09-04):
[0000936395-25-000041:note_history:15]
|  | August 2, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 208,174 |  |  | $ | 297 |  |  | $ | (3) |  |  | $ | 208,468 |  |
| Corporate debt securities | 120,919 |  |  | 207 |  |  | — |  |  | 121,126 |  |
| Time deposits | 92,547 |  |  | 2 |  |  | — |  |  | 92,549 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |
| Included in cash equivalents | $ | 87,366 |  |  | $ | — |  |  | $ | — |  |  | $ | 87,366 |  |
| Included in short-term investments | 270,085 |  |  | 298 |  |  | (3) |  |  | 270,380 |  |
| Included in long-term investments | 64,189 |  |  | 208 |  |  | — |  |  | 64,397 |  |
|  | $ | 421,640 |  |  | $ | 506 |  |  | $ | (3) |  |  | $ | 422,143 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:16]
The following table summarizes the final legal maturities of debt investments as of August 2, 2025 (in thousands):
  (was, 2025-06-05, similarity 0.9677):
[0000936395-25-000025:note_history:16]
The following table summarizes the final legal maturities of debt investments as of May 3, 2025 (in thousands):

- removed (2025-09-04):
[0000936395-25-000025:note_history:17]
|  | May 3, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 272,552 |  |  | $ | 500 |  |  | $ | (28) |  |  | $ | 273,024 |  |
| Corporate debt securities | 122,049 |  |  | 130 |  |  | (58) |  |  | 122,121 |  |
| Time deposits | 125,479 |  |  | 1 |  |  | (2) |  |  | 125,478 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |
| Included in cash equivalents | $ | 124,325 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,325 |  |
| Included in short-term investments | 303,798 |  |  | 412 |  |  | (33) |  |  | 304,177 |  |
| Included in long-term investments | 91,957 |  |  | 219 |  |  | (55) |  |  | 92,121 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-09-04):
[0000936395-25-000041:note_history:18]
|  |  | August 2, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,149,615 |  |  | $ | (3,738) |  |  | $ | (4,776) |  |  | $ | 1,141,101 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:19]
|  |  | August 2, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,054) |  |  | $ | 396,946 |  |  | $ | 396,427 |  |  |  |
  (was, 2025-06-05, similarity 0.9788):
[0000936395-25-000025:note_history:19]
|  |  | May 3, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,227) |  |  | $ | 396,773 |  |  | $ | 396,427 |  |  |  |

- removed (2025-09-04):
[0000936395-25-000025:note_history:20]
|  |  | May 3, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,152,510 |  |  | $ | (3,921) |  |  | $ | (5,006) |  |  | $ | 1,143,583 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:21]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
  (was, 2025-06-05, similarity 0.9961):
[0000936395-25-000025:note_history:21]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:22]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
  (was, 2025-06-05, similarity 0.9961):
[0000936395-25-000025:note_history:22]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:23]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
  (was, 2025-06-05, similarity 0.9931):
[0000936395-25-000025:note_history:23]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:24]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
  (was, 2025-06-05, similarity 0.9931):
[0000936395-25-000025:note_history:24]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:25]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 923,627 |  |  | $ | 718,605 |  |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |
| EMEA |  | 186,018 |  |  | 135,009 |  |  | 535,519 |  |  | 498,212 |  |
| APAC |  | 109,740 |  |  | 88,694 |  |  | 328,923 |  |  | 292,951 |  |
| Total revenue by geographic distribution |  | $ | 1,219,385 |  |  | $ | 942,308 |  |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |
  (was, 2025-06-05, similarity 0.9215):
[0000936395-25-000025:note_history:25]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 833,822 |  |  | $ | 662,877 |  |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |
| EMEA |  | 191,585 |  |  | 155,791 |  |  | 349,501 |  |  | 363,203 |  |
| APAC |  | 100,471 |  |  | 92,158 |  |  | 219,183 |  |  | 204,257 |  |
| Total revenue by geographic distribution |  | $ | 1,125,878 |  |  | $ | 910,826 |  |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:26]
|  | Quarter Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 815,497 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 815,497 |  |
| Routing and Switching | 125,857 |  |  | — |  |  | — |  |  | — |  |  | 125,857 |  |
| Platform Software and Services | — |  |  | 89,961 |  |  | — |  |  | — |  |  | 89,961 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,805 |  |  | — |  |  | 27,805 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 80,743 |  |  | 80,743 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 65,878 |  |  | 65,878 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,644 |  |  | 13,644 |  |
| Total revenue by product line | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 941,354 |  |  | $ | 24,281 |  |  | $ | 11,909 |  |  | $ | 9,806 |  |  | $ | 987,350 |  |
| Services transferred over time | — |  |  | 65,680 |  |  | 15,896 |  |  | 150,459 |  |  | 232,035 |  |
| Total revenue by timing of revenue recognition | $ | 941,354 |  |  | $ | 89,961 |  |  | $ | 27,805 |  |  | $ | 160,265 |  |  | $ | 1,219,385 |  |
  (was, 2025-06-05, similarity 0.9961):
[0000936395-25-000025:note_history:26]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:27]
|  | Quarter Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 606,845 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 606,845 |  |
| Routing and Switching | 92,692 |  |  | — |  |  | — |  |  | — |  |  | 92,692 |  |
| Platform Software and Services | — |  |  | 83,212 |  |  | — |  |  | — |  |  | 83,212 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 25,791 |  |  | — |  |  | 25,791 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,344 |  |  | 74,344 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,484 |  |  | 46,484 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 12,940 |  |  | 12,940 |  |
| Total revenue by product line | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 699,537 |  |  | $ | 18,766 |  |  | $ | 11,614 |  |  | $ | 9,833 |  |  | $ | 739,750 |  |
| Services transferred over time | — |  |  | 64,446 |  |  | 14,177 |  |  | 123,935 |  |  | 202,558 |  |
| Total revenue by timing of revenue recognition | $ | 699,537 |  |  | $ | 83,212 |  |  | $ | 25,791 |  |  | $ | 133,768 |  |  | $ | 942,308 |  |
  (was, 2025-06-05, similarity 0.9961):
[0000936395-25-000025:note_history:27]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:28]
|  | Nine Months Ended August 2, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 2,317,062 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,317,062 |  |
| Routing and Switching | 311,749 |  |  | — |  |  | — |  |  | — |  |  | 311,749 |  |
| Platform Software and Services | — |  |  | 270,469 |  |  | — |  |  | — |  |  | 270,469 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 81,787 |  |  | — |  |  | 81,787 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 234,758 |  |  | 234,758 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,735 |  |  | 171,735 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 29,963 |  |  | 29,963 |  |
| Total revenue by product line | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,628,811 |  |  | $ | 75,260 |  |  | $ | 32,846 |  |  | $ | 23,783 |  |  | $ | 2,760,700 |  |
| Services transferred over time | — |  |  | 195,209 |  |  | 48,941 |  |  | 412,673 |  |  | 656,823 |  |
| Total revenue by timing of revenue recognition | $ | 2,628,811 |  |  | $ | 270,469 |  |  | $ | 81,787 |  |  | $ | 436,456 |  |  | $ | 3,417,523 |  |
  (was, 2025-06-05, similarity 0.9931):
[0000936395-25-000025:note_history:28]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:29]
|  | Nine Months Ended July 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,862,917 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,862,917 |  |
| Routing and Switching | 320,113 |  |  | — |  |  | — |  |  | — |  |  | 320,113 |  |
| Platform Software and Services | — |  |  | 258,402 |  |  | — |  |  | — |  |  | 258,402 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,167 |  |  | — |  |  | 54,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 225,869 |  |  | 225,869 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 132,993 |  |  | 132,993 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 36,382 |  |  | 36,382 |  |
| Total revenue by product line | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,183,030 |  |  | $ | 69,149 |  |  | $ | 15,530 |  |  | $ | 29,904 |  |  | $ | 2,297,613 |  |
| Services transferred over time | — |  |  | 189,253 |  |  | 38,637 |  |  | 365,340 |  |  | 593,230 |  |
| Total revenue by timing of revenue recognition | $ | 2,183,030 |  |  | $ | 258,402 |  |  | $ | 54,167 |  |  | $ | 395,244 |  |  | $ | 2,890,843 |  |
  (was, 2025-06-05, similarity 0.9931):
[0000936395-25-000025:note_history:29]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:30]
•Platform Services - includes sales of subscription, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.
  (was, 2025-06-05, similarity 0.9724):
[0000936395-25-000025:note_history:30]
•Platform Services - includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above.

- changed (2025-09-04):
[0000936395-25-000041:note_history:31]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | August 2, |  | July 27, |  | August 2, |  | July 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 923,627 |  |  | $ | 718,605 |  |  | $ | 2,553,081 |  |  | $ | 2,099,680 |  |
| EMEA |  | 186,018 |  |  | 135,009 |  |  | 535,519 |  |  | 498,212 |  |
| APAC |  | 109,740 |  |  | 88,694 |  |  | 328,923 |  |  | 292,951 |  |
| Total revenue by geographic distribution |  | $ | 1,219,385 |  |  | $ | 942,308 |  |  | $ | 3,417,523 |  |  | $ | 2,890,843 |  |
  (was, 2025-06-05, similarity 0.9215):
[0000936395-25-000025:note_history:31]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 833,822 |  |  | $ | 662,877 |  |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |
| EMEA |  | 191,585 |  |  | 155,791 |  |  | 349,501 |  |  | 363,203 |  |
| APAC |  | 100,471 |  |  | 92,158 |  |  | 219,183 |  |  | 204,257 |  |
| Total revenue by geographic distribution |  | $ | 1,125,878 |  |  | $ | 910,826 |  |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:32]
Ciena’s revenue includes $882.8 million and $676.0 million of U.S. revenue for the third quarter of fiscal 2025 and 2024, respectively. For the nine months ended August 2, 2025 and July 27, 2024, U.S. revenue was $2.4 billion and $2.0 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.
  (was, 2025-06-05, similarity 0.8825):
[0000936395-25-000025:note_history:32]
Ciena’s revenue includes $797.5 million and $618.8 million of U.S. revenue for the second quarter of fiscal 2025 and 2024, respectively. For the six months ended May 3, 2025 and April 27, 2024, U.S. revenue was $1.6 billion and $1.3 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- added (2025-09-04):
[0000936395-25-000041:note_history:33]
Ciena’s revenue from a cloud provider includes $218.0 million and $538.2 million for the third quarter and nine months ended August 2, 2025, respectively, and $137.2 million and $331.6 million for the third quarter and nine months ended July 27, 2024, respectively. Revenue also includes $133.0 million and $361.4 million from AT&T for the third quarter and nine months ended August 2, 2025, respectively, and $113.1 million and $324.8 million for the third quarter and nine months ended July 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

- changed (2025-09-04):
[0000936395-25-000041:note_history:34]
|  |  | Balance at August 2, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 1,025,563 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 164,326 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 277,266 |  |  | $ | 237,619 |  |
  (was, 2025-06-05, similarity 0.879):
[0000936395-25-000025:note_history:34]
|  |  | Balance at May 3, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 929,799 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,769 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 305,074 |  |  | $ | 237,619 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:35]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $134.6 million and $130.5 million of revenue during the first nine months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended August 2, 2025 and July 27, 2024.
  (was, 2025-06-05, similarity 0.9355):
[0000936395-25-000025:note_history:35]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $111.3 million and $105.3 million of revenue during the first six months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 3, 2025 and April 27, 2024.

- changed (2025-09-04):
[0000936395-25-000041:note_history:36]
|  | August 2,2025 |  | November 2,2024 |
| Products | $ | 33,476 |  |  | $ | 19,017 |  |
| Services | 243,790 |  |  | 218,602 |  |
| Total deferred revenue | 277,266 |  |  | 237,619 |  |
| Less current portion | (196,209) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 81,057 |  |  | $ | 81,240 |  |
  (was, 2025-06-05, similarity 0.9845):
[0000936395-25-000025:note_history:36]
|  | May 3,2025 |  | November 2,2024 |
| Products | $ | 31,651 |  |  | $ | 19,017 |  |
| Services | 273,423 |  |  | 218,602 |  |
| Total deferred revenue | 305,074 |  |  | 237,619 |  |
| Less current portion | (221,835) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,239 |  |  | $ | 81,240 |  |

- changed (2025-09-04):
[0000936395-25-000041:note_history:37]
Capitalized contract acquisition costs consist of deferred sales commissions and were $33.4 million and $28.4 million as of August 2, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $22.9 million during the first nine months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2025-06-05, similarity 0.9848):
[0000936395-25-000025:note_history:37]
Capitalized contract acquisition costs consist of deferred sales commissions and were $29.3 million and $28.4 million as of May 3, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $16.7 million and $14.9 million during the first six months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2025-09-04):
[0000936395-25-000041:note_history:38]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of August 2, 2025, the aggregate amount of RPO was $2.0 billion. As of August 2, 2025, Ciena expects approximately 82% of the RPO balance to be recognized as revenue within the next 12 months.
  (was, 2025-06-05, similarity 0.9776):
[0000936395-25-000025:note_history:38]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 3, 2025, the aggregate amount of RPO was $1.7 billion. As of May 3, 2025, Ciena expects approximately 79% of the RPO balance to be recognized as revenue within the next 12 months.

- removed (2025-09-04):
[0000936395-25-000025:note_history:39]
Ciena’s revenue includes $151.3 million and $320.2 million from a cloud provider for the second quarter and six months ended May 3, 2025, respectively, and such customer did not account for 10% or more of total revenue for the second quarter or six months ended April 27, 2024. Revenue also includes $117.4 million and $228.4 million from AT&T for the second quarter and six months ended May 3, 2025, respectively, and $125.5 million and $211.7 million for the second quarter and six months ended April 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-09-04):
[0000936395-25-000041:note_history:40]
From the end of the third quarter of fiscal 2025 through August 29, 2025, Ciena repurchased 286,619 shares of its common stock for an aggregate purchase price of $26.4 million at an average price of $92.10 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of August 29, 2025, Ciena has an aggregate of $728.4 million of authorized funds remaining under this repurchase program.
  (was, 2025-06-05, similarity 0.9658):
[0000936395-25-000025:note_history:40]
From the end of the second quarter of fiscal 2025 through May 30, 2025, Ciena repurchased 318,958 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $78.63 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of May 30, 2025, Ciena has an aggregate of $811.5 million of authorized funds remaining under this repurchase program.

- added (2025-09-04):
[0000936395-25-000041:note_history:41]
Reallocation of Innovation Investment and Fiscal 2025 Restructuring Plan

- added (2025-09-04):
[0000936395-25-000041:note_history:42]
On August 26, 2025, in order to align Ciena’s strategic investments with our highest-growth demand opportunities, its executive team determined to cease forward investment in certain broadband development initiatives, primarily 25G PON, within the routing and switching product line of the Network Platforms operating segment. Ciena intends to continue support and development of its 10G PON-based products.

- added (2025-09-04):
[0000936395-25-000041:note_history:43]
Ciena’s executive team also approved a restructuring plan intended to deliver increased operating efficiencies and, as a result, commencing during the fourth quarter of fiscal 2025, Ciena is implementing a workforce reduction of approximately 4%

- added (2025-09-04):
[0000936395-25-000041:note_history:44]
to 5% of its global headcount, which includes employees associated with the broadband development initiatives discussed above. 
The estimated cash cost related to these actions is approximately $20.0 million and represents employee severance and related costs. As such, we expect an expense of approximately $20.0 million to be incurred in the fourth quarter of fiscal 2025. In addition, Ciena anticipates that its decision to cease future investment in 25G PON will result in a non-cash charge in the fourth quarter of fiscal 2025 related to the abandonment of its in-process R&D intangible asset, which has a carrying value of $89.1 million as of August 2, 2025. During the fourth quarter of fiscal 2025, Ciena will also evaluate the impact of these actions on other assets including, but not limited to, inventory and fixed assets.
