# CIEN MD&A — 0001628280-26-040767


## mdna

[0001628280-26-040767:mdna:1]
[same as prior period, unchanged from 0001628280-26-015152:mdna:1]

[0001628280-26-040767:mdna:2]
[same as prior period, unchanged from 0001628280-26-015152:mdna:2]

[0001628280-26-040767:mdna:3]
[same as prior period, unchanged from 0001628280-26-015152:mdna:3]

[0001628280-26-040767:mdna:4]
[same as prior period, unchanged from 0001628280-26-015152:mdna:5]

[0001628280-26-040767:mdna:5]
[same as prior period, unchanged from 0001628280-26-015152:mdna:6]

[0001628280-26-040767:mdna:6]
[same as prior period, unchanged from 0001628280-26-015152:mdna:7]

[0001628280-26-040767:mdna:7]
[same as prior period, unchanged from 0001628280-26-015152:mdna:8]

[0001628280-26-040767:mdna:8]
Our industry has been experiencing unprecedented increases in demand, in particular due to capital expenditures related to AI and other cloud-based applications. As a result, we experienced strong momentum and growth in fiscal 2025 that continued in the first half of fiscal 2026. As our sales to cloud providers grow, we are seeing a small number of those customers become a larger portion of our business across multiple revenue segments. Our revenue increased by 40% to $1.6 billion in the second quarter of fiscal 2026 as compared to $1.1 billion in the second quarter of fiscal 2025, with orders for our products and services significantly exceeding our revenue. This dynamic, together with an industry-wide constrained supply environment, has resulted in historically high backlog.

[0001628280-26-040767:mdna:9]
[same as prior period, unchanged from 0001628280-26-015152:mdna:10]

[0001628280-26-040767:mdna:10]
Our gross margin increased to 44.0% in the second quarter of fiscal 2026, compared to 40.2% in the second quarter of fiscal 2025, primarily due to higher product gross margin associated with cost reduction, pricing optimization, and product mix.

[0001628280-26-040767:mdna:11]
[same as prior period, unchanged from 0001628280-26-015152:mdna:12]

[0001628280-26-040767:mdna:12]
Our operating expense grew from $420 million in the second quarter of fiscal 2025 to $454 million in the second quarter of fiscal 2026. During the second quarter of fiscal 2026, we invested $238 million in research and development activities, an increase of 11% compared to the second quarter of fiscal 2025. We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets, which requires both investment capacity and expenditures. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we continued to increase the performance of and enhance the capabilities for our leading WaveLogicTM coherent modem technology, through which we seek to extend our leadership in optical networking, and leverage it to expand our addressable market, including inside and around the data center.

[0001628280-26-040767:mdna:13]
[same as prior period, unchanged from 0001628280-26-015152:mdna:14]

[0001628280-26-040767:mdna:14]
Our capital allocation strategy is focused on maintaining our significant innovation investment, investing in select transactions, and returning value to stockholders, while preserving our strategic and operational flexibility. We continuously work to improve our cash cycle and evaluate alternatives to manage our capital structure in order to enhance our liquidity. We ended the first half of fiscal 2026 with $1.4 billion of cash, cash equivalents, and investments. As of the end of the first half of fiscal 2026, cash generated from operations increased to $487 million as compared to $261 million as of the end of the first half of fiscal 2025. Consistent with our capital allocation priorities, during the first half of fiscal 2026, we invested $115 million in capital purchases, primarily for supply chain equipment and research and development, and $344 million to repurchase shares through our share buyback program and for tax withholding purposes associated with employee stock awards.

[0001628280-26-040767:mdna:15]
[same as prior period, unchanged from 0001628280-26-015152:mdna:16]

[0001628280-26-040767:mdna:16]
[same as prior period, unchanged from 0001628280-26-015152:mdna:17]

[0001628280-26-040767:mdna:17]
[same as prior period, unchanged from 0001628280-26-015152:mdna:18]

[0001628280-26-040767:mdna:18]
[same as prior period, unchanged from 0001628280-26-015152:mdna:19]

[0001628280-26-040767:mdna:19]
[same as prior period, unchanged from 0001628280-26-015152:mdna:20]

[0001628280-26-040767:mdna:20]
As a result of the increased demand described above, our revenue increased by approximately 40%, or $444.9 million, in the second quarter of fiscal 2026 as compared to the second quarter of fiscal 2025, and approximately 36% or $799.6 million, in the six months ended May 2, 2026 as compared to the six months ended May 3, 2025.

[0001628280-26-040767:mdna:21]
[same as prior period, unchanged from 0001628280-26-015152:mdna:22]

[0001628280-26-040767:mdna:22]
[same as prior period, unchanged from 0001628280-26-015152:mdna:23]

[0001628280-26-040767:mdna:23]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,099,848 |  |  | $ | 773,592 |  |  |  |  | 42.2 | % |  | $ | 2,123,010 |  |  | $ | 1,501,566 |  |  |  |  | 41.4 | % |
| %** | 70.0 | % |  | 68.7 | % |  |  |  |  |  | 70.8 | % |  | 68.3 | % |  |  |  |  |
| Routing and Switching | 174,230 |  |  | 92,723 |  |  |  |  | 87.9 | % |  | 300,236 |  |  | 185,892 |  |  |  |  | 61.5 | % |
| %** | 11.1 | % |  | 8.2 | % |  |  |  |  |  | 10.0 | % |  | 8.5 | % |  |  |  |  |
| Total Networking Platforms | 1,274,078 |  |  | 866,315 |  |  |  |  | 47.1 | % |  | 2,423,246 |  |  | 1,687,458 |  |  |  |  | 43.6 | % |
| %** | 81.1 | % |  | 76.9 | % |  |  |  |  |  | 80.8 | % |  | 76.8 | % |  |  |  |  |
| Platform Software and Services | 93,878 |  |  | 85,441 |  |  |  |  | 9.9 | % |  | 187,262 |  |  | 180,508 |  |  |  |  | 3.7 | % |
| %** | 6.0 | % |  | 7.5 | % |  |  |  |  |  | 6.2 | % |  | 8.2 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 23,361 |  |  | 27,951 |  |  |  |  | (16.4) | % |  | 43,781 |  |  | 53,982 |  |  |  |  | (18.9) | % |
| %** | 1.5 | % |  | 2.5 | % |  |  |  |  |  | 1.6 | % |  | 2.5 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance, Support, and Learning | 89,286 |  |  | 79,442 |  |  |  |  | 12.4 | % |  | 176,837 |  |  | 154,014 |  |  |  |  | 14.8 | % |
| %** | 5.7 | % |  | 7.1 | % |  |  |  |  |  | 5.9 | % |  | 7.0 | % |  |  |  |  |
| Implementation | 79,702 |  |  | 58,174 |  |  |  |  | 37.0 | % |  | 147,650 |  |  | 105,857 |  |  |  |  | 39.5 | % |
| %** | 5.1 | % |  | 5.2 | % |  |  |  |  |  | 4.9 | % |  | 4.8 | % |  |  |  |  |
| Advisory and Enablement | 10,434 |  |  | 8,555 |  |  |  |  | 22.0 | % |  | 19,005 |  |  | 16,319 |  |  |  |  | 16.5 | % |
| %** | 0.6 | % |  | 0.8 | % |  |  |  |  |  | 0.6 | % |  | 0.7 | % |  |  |  |  |
| Total Global Services | 179,422 |  |  | 146,171 |  |  |  |  | 22.7 | % |  | 343,492 |  |  | 276,190 |  |  |  |  | 24.4 | % |
| %** | 11.4 | % |  | 13.1 | % |  |  |  |  |  | 11.4 | % |  | 12.5 | % |  |  |  |  |
| Total revenue | $ | 1,570,739 |  |  | $ | 1,125,878 |  |  |  |  | 39.5 | % |  | $ | 2,997,781 |  |  | $ | 2,198,138 |  |  |  |  | 36.4 | % |

[0001628280-26-040767:mdna:24]
[same as prior period, unchanged from 0001628280-26-015152:mdna:25]

[0001628280-26-040767:mdna:25]
[same as prior period, unchanged from 0001628280-26-015152:mdna:26]

[0001628280-26-040767:mdna:26]
[same as prior period, unchanged from 0001628280-26-015152:mdna:27]

[0001628280-26-040767:mdna:27]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:28]
•Networking Platforms segment revenue increased by $407.8 million.

[0001628280-26-040767:mdna:29]
•Optical Networking products revenue increased by $326.3 million, primarily driven by increases in sales of our Waveserver® system and our 6500 Reconfigurable Line Systems (RLS).

[0001628280-26-040767:mdna:30]
•Routing and Switching products revenue increased by $81.5 million, primarily driven by increases in sales of our 3000 and 5000 series of service delivery and aggregation platforms, and our 8100 Coherent IP networking platforms in our out-of-band data center management (DCOM) solution.

[0001628280-26-040767:mdna:31]
•Platform Software and Services segment revenue increased by $8.4 million, primarily reflecting a sales increase in our Navigator Network Control Suite (NCS) software solution.

[0001628280-26-040767:mdna:32]
•Blue Planet Automation Software and Services segment revenue decreased by $4.6 million, primarily reflecting a sales decrease in our unified assurance and analytics software.

[0001628280-26-040767:mdna:33]
•Global Services segment revenue increased by $33.3 million, primarily reflecting sales increases in our implementation services and maintenance, support, and learning services.

[0001628280-26-040767:mdna:34]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:35]
•Networking Platforms segment revenue increased by $735.7 million.

[0001628280-26-040767:mdna:36]
•Optical Networking revenue increased by $621.4 million, primarily driven by increases in sales of our Waveserver® system and our 6500 RLS.

[0001628280-26-040767:mdna:37]
•Routing and Switching revenue increased by $114.3 million, primarily driven by increases in sales of our 3000 and 5000 series of service delivery and aggregation platforms, and our 8100 Coherent IP networking platforms in our DCOM solution.

[0001628280-26-040767:mdna:38]
•Platform Software and Services segment revenue increased by $6.8 million, primarily reflecting a sales increase in our Navigator NCS software solution, partially offset by sales decreases of our software consulting services.

[0001628280-26-040767:mdna:39]
•Blue Planet Automation Software and Services segment revenue decreased by $10.2 million, primarily reflecting a sales decrease in our unified assurance and analytics software.

[0001628280-26-040767:mdna:40]
•Global Services segment revenue increased by $67.3 million, primarily reflecting sales increases in our implementation services and maintenance support and learning services.

[0001628280-26-040767:mdna:41]
[same as prior period, unchanged from 0001628280-26-015152:mdna:35]

[0001628280-26-040767:mdna:42]
[same as prior period, unchanged from 0001628280-26-015152:mdna:36]

[0001628280-26-040767:mdna:43]
[same as prior period, unchanged from 0001628280-26-015152:mdna:37]

[0001628280-26-040767:mdna:44]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |
| Americas | $ | 1,202,214 |  |  | $ | 833,822 |  |  |  |  | 44.2 | % |  | $ | 2,320,437 |  |  | $ | 1,629,454 |  |  |  |  | 42.4 | % |
| %** | 76.5 | % |  | 74.1 | % |  |  |  |  |  | 77.4 | % |  | 74.1 | % |  |  |  |  |
| EMEA | 196,037 |  |  | 191,585 |  |  |  |  | 2.3 | % |  | 396,625 |  |  | 349,501 |  |  |  |  | 13.5 | % |
| %** | 12.5 | % |  | 17.0 | % |  |  |  |  |  | 13.2 | % |  | 15.9 | % |  |  |  |  |
| APAC | 172,488 |  |  | 100,471 |  |  |  |  | 71.7 | % |  | 280,719 |  |  | 219,183 |  |  |  |  | 28.1 | % |
| %** | 11.0 | % |  | 8.9 | % |  |  |  |  |  | 9.4 | % |  | 10.0 | % |  |  |  |  |
| Total | $ | 1,570,739 |  |  | $ | 1,125,878 |  |  |  |  | 39.5 | % |  | $ | 2,997,781 |  |  | $ | 2,198,138 |  |  |  |  | 36.4 | % |

[0001628280-26-040767:mdna:45]
[same as prior period, unchanged from 0001628280-26-015152:mdna:39]

[0001628280-26-040767:mdna:46]
[same as prior period, unchanged from 0001628280-26-015152:mdna:40]

[0001628280-26-040767:mdna:47]
[same as prior period, unchanged from 0001628280-26-015152:mdna:41]

[0001628280-26-040767:mdna:48]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:49]
•Americas revenue increased by $368.4 million, primarily driven by increased sales to cloud provider customers as well as service provider customers in the United States.

[0001628280-26-040767:mdna:50]
•EMEA revenue increased by $4.5 million, primarily driven by increased sales in France, partially offset by decreased sales to cloud provider customers in the Netherlands.

[0001628280-26-040767:mdna:51]
•APAC revenue increased by $72.0 million, primarily driven by increased sales to service provider customers in India and enterprise customers in Australia.

[0001628280-26-040767:mdna:52]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:53]
•Americas revenue increased by $691.0 million, primarily driven by increased sales to cloud provider customers and service provider customers in the United States.

[0001628280-26-040767:mdna:54]
•EMEA revenue increased by $47.1 million, primarily driven by increased sales to cloud provider customers in the Netherlands and increased sales in France.

[0001628280-26-040767:mdna:55]
•APAC revenue increased by $61.5 million, primarily driven by increased sales to service provider customers in India, cloud provider customers in Singapore, and enterprise customers in Australia.

[0001628280-26-040767:mdna:56]
[same as prior period, unchanged from 0001628280-26-015152:mdna:46]

[0001628280-26-040767:mdna:57]
During both the second quarter and first six months of fiscal 2026, approximately 9% of our revenue was non-U.S. Dollar-denominated. During the second quarter and first six months of fiscal 2026 as compared to the second quarter and first six months of fiscal 2025, the U.S. Dollar generally weakened against other currencies with minimal impact.

[0001628280-26-040767:mdna:58]
[same as prior period, unchanged from 0001628280-26-015152:mdna:48]

[0001628280-26-040767:mdna:59]
[same as prior period, unchanged from 0001628280-26-015152:mdna:49]

[0001628280-26-040767:mdna:60]
[same as prior period, unchanged from 0001628280-26-015152:mdna:50]

[0001628280-26-040767:mdna:61]
[same as prior period, unchanged from 0001628280-26-015152:mdna:51]

[0001628280-26-040767:mdna:62]
Gross margin can fluctuate due to a number of factors, including technology-based price changes, product and service mix, the lifecycle stage of our products and cost reductions.

[0001628280-26-040767:mdna:63]
[same as prior period, unchanged from 0001628280-26-015152:mdna:53]

[0001628280-26-040767:mdna:64]
|  | Quarter Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  |  |
|  | Revenue |  | Gross Margin (%)** |  | Revenue |  | Gross Margin (%)** |  | Revenue Change (%)* |  | Gross Margin Change |
| Total | $ | 1,570,739 |  |  | 44.0 | % |  | $ | 1,125,878 |  |  | 40.2 | % |  | 39.5 | % |  | 3.8 | % |
| Products | $ | 1,311,488 |  |  | 43.9 | % |  | $ | 898,581 |  |  | 38.8 | % |  | 46.0 | % |  | 5.1 | % |
| Services | $ | 259,251 |  |  | 44.8 | % |  | $ | 227,297 |  |  | 45.9 | % |  | 14.1 | % |  | (1.1) | % |
|  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  |  |
|  | Revenue |  | Gross Margin (%)** |  | Revenue |  | Gross Margin (%)** |  | Revenue Change (%)* |  | Gross Margin Change |
| Total | $ | 2,997,781 |  |  | 43.9 | % |  | $ | 2,198,138 |  |  | 42.1 | % |  | 36.4 | % |  | 1.8 | % |
| Products | $ | 2,491,358 |  |  | 43.7 | % |  | $ | 1,753,366 |  |  | 40.6 | % |  | 42.1 | % |  | 3.1 | % |
| Services | $ | 506,423 |  |  | 45.1 | % |  | $ | 444,772 |  |  | 47.7 | % |  | 13.9 | % |  | (2.6) | % |

[0001628280-26-040767:mdna:65]
[same as prior period, unchanged from 0001628280-26-015152:mdna:55]

[0001628280-26-040767:mdna:66]
[same as prior period, unchanged from 0001628280-26-015152:mdna:64]

[0001628280-26-040767:mdna:67]
[same as prior period, unchanged from 0001628280-26-015152:mdna:65]

[0001628280-26-040767:mdna:68]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:69]
•Gross margin increased by 380 basis points, primarily reflecting increased product margin offset by decreased services margin.

[0001628280-26-040767:mdna:70]
•Product gross margin increased by 510 basis points, primarily due to cost reduction, pricing optimization, and product mix, partially offset by lower manufacturing efficiencies.

[0001628280-26-040767:mdna:71]
•Services gross margin decreased by 110 basis points, primarily due to a less favorable services mix, partially offset by improved margins on implementation services.

[0001628280-26-040767:mdna:72]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:73]
•Gross margin increased by 180 basis points, primarily reflecting increased product margin offset by decreased services margin.

[0001628280-26-040767:mdna:74]
•Product gross margin increased by 310 basis points, primarily due to cost reduction, pricing optimization, and product mix, partially offset by lower manufacturing efficiencies.

[0001628280-26-040767:mdna:75]
•Services gross margin decreased by 260 basis points, primarily due to a less favorable services mix, partially offset by improved margins on implementation services.

[0001628280-26-040767:mdna:76]
[same as prior period, unchanged from 0001628280-26-015152:mdna:60]

[0001628280-26-040767:mdna:77]
[same as prior period, unchanged from 0001628280-26-015152:mdna:61]

[0001628280-26-040767:mdna:78]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |
| Research and development | $ | 237,905 |  |  | $ | 214,868 |  |  |  |  | 10.7 | % |  | $ | 459,363 |  |  | $ | 407,531 |  |  |  |  | 12.7 | % |
| %** | 15.1 | % |  | 19.1 | % |  |  |  |  |  | 15.3 | % |  | 18.5 | % |  |  |  |  |
| Selling and marketing | 150,039 |  |  | 139,683 |  |  |  |  | 7.4 | % |  | 298,906 |  |  | 276,187 |  |  |  |  | 8.2 | % |
| %** | 9.6 | % |  | 12.4 | % |  |  |  |  |  | 10.0 | % |  | 12.6 | % |  |  |  |  |
| General and administrative | 61,221 |  |  | 56,952 |  |  |  |  | 7.5 | % |  | 120,464 |  |  | 110,854 |  |  |  |  | 8.7 | % |
| %** | 3.9 | % |  | 5.1 | % |  |  |  |  |  | 4.0 | % |  | 5.0 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 805 |  |  | 1,948 |  |  |  |  | (58.7) | % |  | 2,303 |  |  | 3,492 |  |  |  |  | (34.0) | % |
| %** | 0.1 | % |  | 0.2 | % |  |  |  |  |  | 0.1 | % |  | 0.2 | % |  |  |  |  |
| Amortization of intangible assets | 3,713 |  |  | 6,545 |  |  |  |  | (43.3) | % |  | 8,449 |  |  | 13,090 |  |  |  |  | (35.5) | % |
| %** | 0.2 | % |  | 0.6 | % |  |  |  |  |  | 0.3 | % |  | 0.6 | % |  |  |  |  |
| Acquisition and integration costs | — |  |  | — |  |  |  |  | — | % |  | 306 |  |  | — |  |  |  |  | 100.0 | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 453,683 |  |  | $ | 419,996 |  |  |  |  | 8.0 | % |  | $ | 889,791 |  |  | $ | 811,154 |  |  |  |  | 9.7 | % |
| %** | 28.9 | % |  | 37.3 | % |  |  |  |  |  | 29.7 | % |  | 36.9 | % |  |  |  |  |

[0001628280-26-040767:mdna:79]
[same as prior period, unchanged from 0001628280-26-015152:mdna:63]

[0001628280-26-040767:mdna:80]
[same as prior period, unchanged from 0001628280-26-015152:mdna:79]

[0001628280-26-040767:mdna:81]
[same as prior period, unchanged from 0001628280-26-015152:mdna:90]

[0001628280-26-040767:mdna:82]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:83]
•Research and development expense increased by $23.0 million. Net of hedging, this primarily reflects higher employee headcount and related costs, including from our acquisition of Nubis Communications, technology related costs and engineering design and development costs.

[0001628280-26-040767:mdna:84]
•Selling and marketing expense increased by $10.4 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-040767:mdna:85]
•General and administrative expense increased by $4.3 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-040767:mdna:86]
[same as prior period, unchanged from 0001628280-26-015152:mdna:70]

[0001628280-26-040767:mdna:87]
•Amortization of intangible assets decreased by $2.8 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0001628280-26-040767:mdna:88]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:89]
•Research and development expense increased by $51.8 million. Net of hedging, this primarily reflects higher employee headcount and related costs, including from our acquisition of Nubis Communications, technology related costs and engineering design and development costs.

[0001628280-26-040767:mdna:90]
•Selling and marketing expense increased by $22.7 million, which primarily reflects increases in employee-related compensation costs.

[0001628280-26-040767:mdna:91]
•General and administrative expense increased by $9.6 million, which primarily reflects increases in employee-related compensation costs and professional services.

[0001628280-26-040767:mdna:92]
•Significant asset impairments and restructuring costs remained relatively unchanged.

[0001628280-26-040767:mdna:93]
•Amortization of intangible assets decreased by $4.6 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0001628280-26-040767:mdna:94]
[same as prior period, unchanged from 0001628280-26-015152:mdna:72]

[0001628280-26-040767:mdna:95]
[same as prior period, unchanged from 0001628280-26-015152:mdna:73]

[0001628280-26-040767:mdna:96]
During both the second quarter and first six months of fiscal 2026, approximately 50% of our operating expense was non-U.S. Dollar-denominated. During the second quarter and first six months of fiscal 2026, as compared to the second quarter and first six months of fiscal 2025, the U.S. Dollar generally weakened against other currencies. These currency fluctuations, net of hedging, had minimal impact.

[0001628280-26-040767:mdna:97]
[same as prior period, unchanged from 0001628280-26-015152:mdna:75]

[0001628280-26-040767:mdna:98]
[same as prior period, unchanged from 0001628280-26-015152:mdna:76]

[0001628280-26-040767:mdna:99]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 361,551 |  |  | $ | 151,422 |  |  |  |  | 138.8 | % |  | $ | 678,182 |  |  | $ | 333,584 |  |  |  |  | 103.3 | % |
| Platform Software and Services | $ | 62,444 |  |  | $ | 52,995 |  |  |  |  | 17.8 | % |  | $ | 124,162 |  |  | $ | 118,420 |  |  |  |  | 4.8 | % |
| Blue Planet Automation Software and Services | $ | (2,842) |  |  | $ | 6,477 |  |  |  |  | (143.9) | % |  | $ | (6,657) |  |  | $ | 12,976 |  |  |  |  | (151.3) | % |
| Global Services | $ | 64,383 |  |  | $ | 52,342 |  |  |  |  | 23.0 | % |  | $ | 123,137 |  |  | $ | 99,039 |  |  |  |  | 24.3 | % |

[0001628280-26-040767:mdna:100]
[same as prior period, unchanged from 0001628280-26-015152:mdna:78]

[0001628280-26-040767:mdna:101]
[same as prior period, unchanged from 0001628280-26-015152:mdna:89]

[0001628280-26-040767:mdna:102]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:103]
•Networking Platforms segment profit increased by $210.1 million, primarily due to higher sales volume and improved gross margin as described above, partially offset by higher research and development costs.

[0001628280-26-040767:mdna:104]
•Platform Software and Services segment profit increased by $9.4 million, primarily due to higher product sales volume, as described above, and improved gross margin.

[0001628280-26-040767:mdna:105]
[same as prior period, unchanged from 0001628280-26-015152:mdna:83]

[0001628280-26-040767:mdna:106]
•Global Services segment profit increased by $12.0 million, primarily due to increased sales volume as described above.

[0001628280-26-040767:mdna:107]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:108]
•Networking Platforms segment profit increased by $344.6 million, primarily due to higher sales volume and improved gross margin as described above, partially offset by higher research and development costs.

[0001628280-26-040767:mdna:109]
•Platform Software and Services segment profit increased by $5.7 million, primarily due to higher product sales and slightly higher gross margin, partially offset by lower services sales volume and increased research and development costs.

[0001628280-26-040767:mdna:110]
•Blue Planet Automation Software and Services segment primarily reflects lower software sales volume as described above, reduced gross margins and increased research and development costs.

[0001628280-26-040767:mdna:111]
•Global Services segment profit increased by $24.1 million, primarily due to increased sales volume as described above.

[0001628280-26-040767:mdna:112]
[same as prior period, unchanged from 0001628280-26-015152:mdna:85]

[0001628280-26-040767:mdna:113]
[same as prior period, unchanged from 0001628280-26-015152:mdna:86]

[0001628280-26-040767:mdna:114]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |  | May 2, 2026 |  | May 3, 2025 |  |  |  | %* |
| Interest and other income, net | $ | 14,111 |  |  | $ | 7,871 |  |  |  |  | 79.3 | % |  | $ | 27,068 |  |  | $ | 19,449 |  |  |  |  | 39.2 | % |
| %** | 0.9 | % |  | 0.7 | % |  |  |  |  |  | 0.9 | % |  | 0.9 | % |  |  |  |  |
| Interest expense | $ | 20,922 |  |  | $ | 21,697 |  |  |  |  | (3.6) | % |  | $ | 42,176 |  |  | $ | 44,615 |  |  |  |  | (5.5) | % |
| %** | 1.3 | % |  | 1.9 | % |  |  |  |  |  | 1.4 | % |  | 2.0 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | — |  |  |  |  | — | % |  | $ | — |  |  | $ | 729 |  |  |  |  | (100.0) | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Provision for income taxes | $ | 12,840 |  |  | $ | 10,047 |  |  |  |  | 27.8 | % |  | $ | 43,672 |  |  | $ | 34,069 |  |  |  |  | 28.2 | % |
| %** | 0.8 | % |  | 0.9 | % |  |  |  |  |  | 1.5 | % |  | 1.5 | % |  |  |  |  |

[0001628280-26-040767:mdna:115]
[same as prior period, unchanged from 0001628280-26-015152:mdna:88]

[0001628280-26-040767:mdna:116]
*    Denotes % change from fiscal 2025 to fiscal 2026

[0001628280-26-040767:mdna:117]
**     Denotes % of total revenue

[0001628280-26-040767:mdna:118]
Quarter ended May 2, 2026 as compared to the quarter ended May 3, 2025

[0001628280-26-040767:mdna:119]
•Interest and other income, net increased by $6.2 million, primarily reflecting the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0001628280-26-040767:mdna:120]
•Interest expense remained relatively unchanged.

[0001628280-26-040767:mdna:121]
•Provision for income taxes increased by $2.8 million, primarily due to the increase in pre-tax book income.

[0001628280-26-040767:mdna:122]
Six months ended May 2, 2026 as compared to the six months ended May 3, 2025

[0001628280-26-040767:mdna:123]
•Interest and other income, net increased by $7.6 million, primarily reflecting the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0001628280-26-040767:mdna:124]
•Interest expense decreased by $2.4 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity.

[0001628280-26-040767:mdna:125]
[same as prior period, unchanged from 0001628280-26-015152:mdna:94]

[0001628280-26-040767:mdna:126]
•Provision for income taxes increased by $9.6 million, primarily due to the increase in pre-tax book income.

[0001628280-26-040767:mdna:127]
[same as prior period, unchanged from 0001628280-26-015152:mdna:96]

[0001628280-26-040767:mdna:128]
[same as prior period, unchanged from 0001628280-26-015152:mdna:97]

[0001628280-26-040767:mdna:129]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of May 2, 2026, totaled $1.4 billion, as well as our credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of May 2, 2026, letters of credit totaling $39.9 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of May 2, 2026.

[0001628280-26-040767:mdna:130]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $379.7 million as of May 2, 2026. Approximately $92.3 million of undistributed earnings from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability has been accrued to account for the anticipated repatriation amount. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0001628280-26-040767:mdna:131]
Stock Repurchases. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first six months of fiscal 2026, we repurchased $163.7 million of our common stock under the stock repurchase program, and $506.7 million remained under the current repurchase authorization as of May 2, 2026. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. During the the first six months of fiscal 2026, we also repurchased $179.4 million of our common stock in settlement of employee tax withholding obligations due upon the vesting of stock unit awards. See Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as “Issuer Purchases of Equity Securities” in Item 2 of Part II of this report.

[0001628280-26-040767:mdna:132]
[same as prior period, unchanged from 0001628280-26-015152:mdna:101]

[0001628280-26-040767:mdna:133]
[same as prior period, unchanged from 0001628280-26-015152:mdna:102]

[0001628280-26-040767:mdna:134]
|  | May 2,2026 |  | November 1,2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 1,045,126 |  |  | $ | 1,091,952 |  |  | $ | (46,826) |  |
| Short-term investments in marketable debt securities | 157,708 |  |  | 216,148 |  |  | (58,440) |  |
| Long-term investments in marketable debt securities | 200,106 |  |  | 57,142 |  |  | 142,964 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,402,940 |  |  | $ | 1,365,242 |  |  | $ | 37,698 |  |

[0001628280-26-040767:mdna:135]
Cash, cash equivalents and investments increased by $37.7 million during the first six months of fiscal 2026. Cash from operating activities generated $487.3 million, which was partially offset by the following: (i) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $179.4 million; (ii) cash used for stock repurchases under our stock repurchase program of $164.9 million; (iii) cash used to fund our investing activities for capital expenditures totaling $114.9 million; and (iv) cash used for payments on our term loan due October 28, 2030 of $5.8 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $17.2 million in cash during the six months ended May 2, 2026.

[0001628280-26-040767:mdna:136]
[same as prior period, unchanged from 0001628280-26-015152:mdna:105]

[0001628280-26-040767:mdna:137]
The following sections set forth the components of our $487.3 million of cash provided by operating activities during the first six months of fiscal 2026. Net income (adjusted for non-cash charges) provided cash of $612.0 million, offset by cash used in operating assets and liabilities of $124.7 million.

[0001628280-26-040767:mdna:138]
[same as prior period, unchanged from 0001628280-26-015152:mdna:107]

[0001628280-26-040767:mdna:139]
[same as prior period, unchanged from 0001628280-26-015152:mdna:108]

[0001628280-26-040767:mdna:140]
|  | Six Months Ended |
|  | May 2, 2026 |
| Net income | $ | 368,503 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 67,021 |  |
| Share-based compensation expense | 105,300 |  |
| Amortization of intangible assets | 22,020 |  |
| Deferred taxes | (10,563) |  |
| Provision for inventory excess and obsolescence | 42,481 |  |
| Provision for warranty | 16,685 |  |
| Other | 603 |  |
| Net income (adjusted for non-cash charges) | $ | 612,050 |  |

[0001628280-26-040767:mdna:141]
[same as prior period, unchanged from 0001628280-26-015152:mdna:110]

[0001628280-26-040767:mdna:142]
Operating asset and liability requirements increased by $124.7 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0001628280-26-040767:mdna:143]
|  | Six Months Ended |
|  | May 2, 2026 |
| Accounts receivable | $ | (71,555) |  |
| Inventories | (24,690) |  |
| Prepaid expenses and other | (34,047) |  |
| Accounts payable, accruals, and other obligations | (27,945) |  |
| Deferred revenue | 35,442 |  |
| Operating lease assets and liabilities, net | (1,908) |  |
| Total cash consumed by operating assets and liabilities | $ | (124,703) |  |

[0001628280-26-040767:mdna:144]
As compared to the end of fiscal 2025, for the first six months of fiscal 2026:

[0001628280-26-040767:mdna:145]
•The change in accounts receivable primarily reflects increased sales volume, partially offset by improved cash collections;

[0001628280-26-040767:mdna:146]
•The change in inventories primarily reflects increased finished good inventory to mitigate supply chain volatility, partially offset by reduction in raw materials;

[0001628280-26-040767:mdna:147]
•The change in prepaid expenses and other primarily reflects higher refundable cash advances to a third-party contract manufacturer and higher prepaid value-added tax (VAT);

[0001628280-26-040767:mdna:148]
•The change in accounts payable, accruals, and other obligations primarily reflects the timing of payments associated with our annual incentive compensation plan, partially offset by the timing of payments to suppliers;

[0001628280-26-040767:mdna:149]
[same as prior period, unchanged from 0001628280-26-015152:mdna:118]

[0001628280-26-040767:mdna:150]
[same as prior period, unchanged from 0001628280-26-015152:mdna:119]

[0001628280-26-040767:mdna:151]
[same as prior period, unchanged from 0001628280-26-015152:mdna:120]

[0001628280-26-040767:mdna:152]
[same as prior period, unchanged from 0001628280-26-015152:mdna:121]

[0001628280-26-040767:mdna:153]
|  | Six Months Ended |
|  | May 2, 2026 |
| Refinanced 2030 Term Loan due October 28, 2030(1) | $ | 32,115 |  |
| 2030 Senior Notes due January 31, 2030(2) | 8,000 |  |
| Interest rate swaps(3) | (1,470) |  |
| Revolving Credit Facility(4) | 758 |  |
| Finance leases | 1,576 |  |
| Cash paid during period | $ | 40,979 |  |

[0001628280-26-040767:mdna:154]
(1) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the second quarter of fiscal 2026, the interest rate on the Refinanced 2030 Term Loan was 5.41%.

[0001628280-26-040767:mdna:155]
[same as prior period, unchanged from 0001628280-26-015152:mdna:124]

[0001628280-26-040767:mdna:156]
(3) Our interest rate swaps fix the SOFR rate for $350.0 million of our Refinanced 2030 Term Loan at 3.47% through January 2028 and another $350.0 million of our Refinanced 2030 Term Loan at 3.287% through December 2028.

[0001628280-26-040767:mdna:157]
(4) During the first six months of fiscal 2026, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0001628280-26-040767:mdna:158]
[same as prior period, unchanged from 0001628280-26-015152:mdna:127]

[0001628280-26-040767:mdna:159]
[same as prior period, unchanged from 0001628280-26-015152:mdna:128]

[0001628280-26-040767:mdna:160]
Our contractual obligations have not changed materially since November 1, 2025, except for the item listed below. For a summary of our contractual obligations, see “Liquidity and Capital Resources – Contractual Obligations” in Item 7 of Part II of our 2025 Annual Report.

[0001628280-26-040767:mdna:161]
Purchase Order Obligations. As of May 2, 2026, we had $2.8 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0001628280-26-040767:mdna:162]
[same as prior period, unchanged from 0001628280-26-015152:mdna:130]

[0001628280-26-040767:mdna:163]
[same as prior period, unchanged from 0001628280-26-015152:mdna:131]

[0001628280-26-040767:mdna:164]
[same as prior period, unchanged from 0001628280-26-015152:mdna:132]

[0001628280-26-040767:mdna:165]
[same as prior period, unchanged from 0001628280-26-015152:mdna:133]
