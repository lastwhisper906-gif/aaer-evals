# CIEN 8-K — 0000936395-21-000048 filed 2021-12-09

## item codes, every 8-K on or before 2021-12-17

- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2021-12-17

- none on or before 2021-12-17

## item 2.02 — earnings release, exhibit 99.1

[0000936395-21-000048:8k_2_02:1]
EX-99.1
2
ex991-2021q4earningspressr.htm
EX-99.1

[0000936395-21-000048:8k_2_02:2]
Document

[0000936395-21-000048:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-21-000048:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2021 and Year-End Financial Results

[0000936395-21-000048:8k_2_02:5]
Board Authorizes Share Repurchase up to $1.0 Billion

[0000936395-21-000048:8k_2_02:6]
HANOVER, Md. - December 9, 2021 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter and year ended October 30, 2021.

[0000936395-21-000048:8k_2_02:7]
•Q4 Revenue: $1.04 billion, increasing 25.7% year over year

[0000936395-21-000048:8k_2_02:8]
•Q4 Net Income per Share: $0.66 GAAP; $0.85 adjusted (non-GAAP), increasing 41.7% year over year

[0000936395-21-000048:8k_2_02:9]
•Share Repurchases: Repurchased approximately 0.5 million shares of common stock for an aggregate price of $26.7 million during the fourth quarter

[0000936395-21-000048:8k_2_02:10]
“Our strong financial results exceeded our expectations in the fourth quarter and for the full fiscal year, driven by continued execution of our strategy and our demonstrated ability to manage supply chain challenges," said Gary Smith, President and CEO, Ciena. "Looking ahead, we intend to continue driving growth in our business by leveraging our market leadership and investing to capitalize on robust demand dynamics. In addition, our strong balance sheet and cash generation expectations allow us to increase return of capital to our shareholders."

[0000936395-21-000048:8k_2_02:11]
For fiscal fourth quarter 2021, Ciena reported revenue of $1.04 billion, as compared to $828.5 million for fiscal fourth quarter 2020. For fiscal year 2021, Ciena reported revenue of $3.62 billion, as compared to $3.53 billion for fiscal year 2020.

[0000936395-21-000048:8k_2_02:12]
Ciena's GAAP net income for fiscal fourth quarter 2021 was $103.5 million, or $0.66 per diluted common share, which compares to GAAP net income of $65.0 million, or $0.42 per diluted common share, for fiscal fourth quarter 2020. For fiscal year 2021, Ciena's GAAP net income was $500.2 million, or $3.19 per diluted common share, as compared to GAAP net income of $361.3 million, or $2.32 per diluted common share, for fiscal year 2020.

[0000936395-21-000048:8k_2_02:13]
Ciena's adjusted (non-GAAP) net income for fiscal fourth quarter 2021 was $132.7 million, or $0.85 per diluted common share, which compares to adjusted (non-GAAP) net income of $94.5 million, or $0.60 per diluted common share, for fiscal fourth quarter 2020. For fiscal year 2021, Ciena's adjusted (non-GAAP) net income was $456.5 million, or $2.91 per diluted common share, as compared to adjusted (non-GAAP) net income of $460.1 million, or $2.95 per diluted common share, for fiscal year 2020.

[0000936395-21-000048:8k_2_02:14]
Share Repurchase Program

[0000936395-21-000048:8k_2_02:15]
On December 1, 2021, Ciena's Board of Directors authorized the repurchase of up to $1.0 billion of the Company's stock, replacing the previous share repurchase authorization. In connection with this new

[0000936395-21-000048:8k_2_02:16]
authorization, the company intends to enter into an accelerated share repurchase (ASR) arrangement under which it will repurchase $250 million of its common stock. The final settlement of the ASR is expected to be completed in the second quarter of fiscal 2022.

[0000936395-21-000048:8k_2_02:17]
Performance Summary for the Fiscal Fourth Quarter and the Year Ended October 30, 2021

[0000936395-21-000048:8k_2_02:18]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-21-000048:8k_2_02:19]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 30, |  | October 31, |  | Change |  | October 30, |  | October 31, |  | Change |
|  |  | 2021 |  | 2020 |  | Y-T-Y* |  | 2021 |  | 2020 |  | Y-T-Y* |
| Revenue |  | $ | 1,041.5 |  |  | $ | 828.5 |  |  | 25.7 | % |  | $ | 3,620.7 |  |  | $ | 3,532.2 |  |  | 2.5 | % |
| Gross margin |  | 45.8 | % |  | 48.8 | % |  | (3.0) | % |  | 47.6 | % |  | 46.8 | % |  | 0.8 | % |
| Operating expense |  | $ | 339.7 |  |  | $ | 310.9 |  |  | 9.3 | % |  | $ | 1,226.6 |  |  | $ | 1,165.9 |  |  | 5.2 | % |
| Operating margin |  | 13.2 | % |  | 11.3 | % |  | 1.9 | % |  | 13.7 | % |  | 13.8 | % |  | (0.1) | % |

[0000936395-21-000048:8k_2_02:20]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 30, |  | October 31, |  | Change |  | October 30, |  | October 31, |  | Change |
|  |  | 2021 |  | 2020 |  | Y-T-Y* |  | 2021 |  | 2020 |  | Y-T-Y* |
| Revenue |  | $ | 1,041.5 |  |  | $ | 828.5 |  |  | 25.7 | % |  | $ | 3,620.7 |  |  | $ | 3,532.2 |  |  | 2.5 | % |
| Adj. gross margin |  | 46.3 | % |  | 49.5 | % |  | (3.2) | % |  | 47.9 | % |  | 47.4 | % |  | 0.5 | % |
| Adj. operating expense |  | $ | 307.1 |  |  | $ | 278.9 |  |  | 10.1 | % |  | $ | 1,129.3 |  |  | $ | 1,055.3 |  |  | 7.0 | % |
| Adj. operating margin |  | 16.8 | % |  | 15.8 | % |  | 1.0 | % |  | 16.8 | % |  | 17.6 | % |  | (0.8) | % |
| Adj. EBITDA |  | $ | 199.2 |  |  | $ | 154.5 |  |  | 28.9 | % |  | $ | 702.8 |  |  | $ | 713.9 |  |  | (1.6) | % |

[0000936395-21-000048:8k_2_02:21]
* Denotes % change, or in the case of margin, absolute change

[0000936395-21-000048:8k_2_02:22]
2

[0000936395-21-000048:8k_2_02:23]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 754.6 |  |  | 72.5 |  |  | $ | 579.3 |  |  | 69.9 |  |
| Routing and Switching (1) |  | 74.2 |  |  | 7.1 |  |  | 56.0 |  |  | 6.8 |  |
| Total Networking Platforms |  | 828.8 |  |  | 79.6 |  |  | 635.3 |  |  | 76.7 |  |
| Platform Software and Services |  | 66.1 |  |  | 6.3 |  |  | 54.5 |  |  | 6.6 |  |
| Blue Planet Automation Software and Services |  | 19.8 |  |  | 1.9 |  |  | 20.9 |  |  | 2.5 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 71.3 |  |  | 6.9 |  |  | 67.0 |  |  | 8.1 |  |
| Installation and Deployment |  | 47.2 |  |  | 4.5 |  |  | 43.0 |  |  | 5.2 |  |
| Consulting and Network Design |  | 8.3 |  |  | 0.8 |  |  | 7.8 |  |  | 0.9 |  |
| Total Global Services |  | 126.8 |  |  | 12.2 |  |  | 117.8 |  |  | 14.2 |  |
| Total |  | $ | 1,041.5 |  |  | 100.0 |  |  | $ | 828.5 |  |  | 100.0 |  |

[0000936395-21-000048:8k_2_02:24]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 2,553.5 |  |  | 70.5 |  |  | $ | 2,547.6 |  |  | 72.1 |  |
| Routing and Switching (1) |  | 271.8 |  |  | 7.5 |  |  | 267.5 |  |  | 7.6 |  |
| Total Networking Platforms |  | 2,825.3 |  |  | 78.0 |  |  | 2,815.1 |  |  | 79.7 |  |
| Platform Software and Services |  | 229.6 |  |  | 6.4 |  |  | 197.8 |  |  | 5.6 |  |
| Blue Planet Automation Software and Services |  | 77.2 |  |  | 2.1 |  |  | 62.6 |  |  | 1.8 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 283.4 |  |  | 7.8 |  |  | 269.4 |  |  | 7.6 |  |
| Installation and Deployment |  | 171.5 |  |  | 4.7 |  |  | 152.0 |  |  | 4.3 |  |
| Consulting and Network Design |  | 33.7 |  |  | 1.0 |  |  | 35.3 |  |  | 1.0 |  |
| Total Global Services |  | 488.6 |  |  | 13.5 |  |  | 456.7 |  |  | 12.9 |  |
| Total |  | $ | 3,620.7 |  |  | 100.0 |  |  | $ | 3,532.2 |  |  | 100.0 |  |

[0000936395-21-000048:8k_2_02:25]
**  Denotes %  of total revenue

[0000936395-21-000048:8k_2_02:26]
(1)  Ciena renamed its former “Packet Networking” product line “Routing and Switching” effective as of the beginning of fiscal 2021. This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product category.

[0000936395-21-000048:8k_2_02:27]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended October 30, 2021

[0000936395-21-000048:8k_2_02:28]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 748.7 |  |  | 71.9 |  |  | $ | 531.6 |  |  | 64.2 |  |
| Europe, Middle East and Africa |  | 170.8 |  |  | 16.4 |  |  | 157.6 |  |  | 19.0 |  |
| Asia Pacific |  | 122.0 |  |  | 11.7 |  |  | 139.3 |  |  | 16.8 |  |
| Total |  | $ | 1,041.5 |  |  | 100.0 |  |  | $ | 828.5 |  |  | 100.0 |  |

[0000936395-21-000048:8k_2_02:29]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 2,525.6 |  |  | 69.8 |  |  | $ | 2,469.3 |  |  | 69.9 |  |
| Europe, Middle East and Africa |  | 670.5 |  |  | 18.5 |  |  | 591.5 |  |  | 16.8 |  |
| Asia Pacific |  | 424.6 |  |  | 11.7 |  |  | 471.4 |  |  | 13.3 |  |
| Total |  | $ | 3,620.7 |  |  | 100.0 |  |  | $ | 3,532.2 |  |  | 100.0 |  |

[0000936395-21-000048:8k_2_02:30]
**  Denotes %  of total revenue

[0000936395-21-000048:8k_2_02:31]
•One 10%-plus customer represented a total of 12.9% and 12.4% of revenue for the fiscal fourth quarter and fiscal year 2021, respectively

[0000936395-21-000048:8k_2_02:32]
•Cash and investments totaled $1.7 billion

[0000936395-21-000048:8k_2_02:33]
•Cash flow from operations totaled $254.9 million and $541.6 million for the fiscal fourth quarter and fiscal year 2021, respectively

[0000936395-21-000048:8k_2_02:34]
•Average days' sales outstanding (DSOs) were 85 and 98 for the fiscal fourth quarter and fiscal year 2021, respectively

[0000936395-21-000048:8k_2_02:35]
•Accounts receivable, net balance was $885.0 million

[0000936395-21-000048:8k_2_02:36]
•Unbilled contract asset balance, net was $101.4 million

[0000936395-21-000048:8k_2_02:37]
•Inventories totaled $374.3 million, including:

[0000936395-21-000048:8k_2_02:38]
◦Raw materials: $175.4 million

[0000936395-21-000048:8k_2_02:39]
◦Work in process: $10.3 million

[0000936395-21-000048:8k_2_02:40]
◦Finished goods: $180.8 million

[0000936395-21-000048:8k_2_02:41]
◦Deferred cost of sales: $44.7 million

[0000936395-21-000048:8k_2_02:42]
◦Reserve for excess and obsolescence: $(36.9) million

[0000936395-21-000048:8k_2_02:43]
•Product inventory turns were 5.0 and 4.1 for the fiscal fourth quarter and fiscal year 2021, respectively

[0000936395-21-000048:8k_2_02:44]
•Headcount totaled 7,241

[0000936395-21-000048:8k_2_02:45]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter and Year-End 2021 Results

[0000936395-21-000048:8k_2_02:46]
Today, Thursday, December 9, 2021, in conjunction with this announcement, Ciena posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter and fiscal year 2021 results.

[0000936395-21-000048:8k_2_02:47]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-21-000048:8k_2_02:48]
Notes to Investors

[0000936395-21-000048:8k_2_02:49]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our strong financial results exceeded our expectations in the fourth quarter and for the full fiscal year, driven by continued execution of our strategy and our demonstrated ability to manage supply chain challenges"; "Looking ahead, we intend to continue driving growth in our business by leveraging our market leadership and investing to capitalize on robust demand dynamics"; In addition, our strong balance sheet and cash generation expectations allow us to increase return of capital to our shareholders."

[0000936395-21-000048:8k_2_02:50]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread; the impact of COVID-19 on macroeconomic conditions, the level of economic activity, demand for our technology solutions, short- and long-term customer or end user needs and changes thereto, continuity of supply chain, logistics and business operations, liquidity and financial results; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies, including the COVID-19 pandemic; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on September 8, 2021 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-21-000048:8k_2_02:51]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release for the relevant period,

[0000936395-21-000048:8k_2_02:52]
5

[0000936395-21-000048:8k_2_02:53]
Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-21-000048:8k_2_02:54]
About Ciena.  Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our clients create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-21-000048:8k_2_02:55]
CIENA CORPORATION

[0000936395-21-000048:8k_2_02:56]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-21-000048:8k_2_02:57]
(in thousands, except per share data)

[0000936395-21-000048:8k_2_02:58]
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 30, |  | October 31, |  | October 30, |  | October 31, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 860,925 |  |  | $ | 668,661 |  |  | $ | 2,932,602 |  |  | $ | 2,914,790 |  |
| Services |  | 180,561 |  |  | 159,819 |  |  | 688,082 |  |  | 617,367 |  |
| Total revenue |  | 1,041,486 |  |  | 828,480 |  |  | 3,620,684 |  |  | 3,532,157 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 470,334 |  |  | 343,413 |  |  | 1,545,269 |  |  | 1,573,791 |  |
| Services |  | 94,033 |  |  | 80,718 |  |  | 353,436 |  |  | 305,475 |  |
| Total cost of goods sold |  | 564,367 |  |  | 424,131 |  |  | 1,898,705 |  |  | 1,879,266 |  |
| Gross profit |  | 477,119 |  |  | 404,349 |  |  | 1,721,979 |  |  | 1,652,891 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 147,454 |  |  | 137,237 |  |  | 536,666 |  |  | 529,888 |  |
| Selling and marketing |  | 129,625 |  |  | 113,382 |  |  | 452,214 |  |  | 416,425 |  |
| General and administrative |  | 49,383 |  |  | 43,415 |  |  | 181,874 |  |  | 169,548 |  |
| Significant asset impairments and restructuring costs |  | 5,700 |  |  | 7,854 |  |  | 29,565 |  |  | 22,652 |  |
| Amortization of intangible assets |  | 5,836 |  |  | 5,851 |  |  | 23,732 |  |  | 23,383 |  |
| Acquisition and integration costs |  | 1,712 |  |  | 3,127 |  |  | 2,572 |  |  | 4,031 |  |
| Total operating expenses |  | 339,710 |  |  | 310,866 |  |  | 1,226,623 |  |  | 1,165,927 |  |
| Income from operations |  | 137,409 |  |  | 93,483 |  |  | 495,356 |  |  | 486,964 |  |
| Interest and other income (loss), net |  | (168) |  |  | (249) |  |  | (1,768) |  |  | 964 |  |
| Interest expense |  | (7,916) |  |  | (7,395) |  |  | (30,837) |  |  | (31,321) |  |
| Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | — |  |  | (646) |  |
| Income before income taxes |  | 129,325 |  |  | 85,839 |  |  | 462,751 |  |  | 455,961 |  |
| Provision (benefit) for income taxes |  | 25,826 |  |  | 20,798 |  |  | (37,445) |  |  | 94,670 |  |
| Net income |  | $ | 103,499 |  |  | $ | 65,041 |  |  | $ | 500,196 |  |  | $ | 361,291 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| Basic net income per common share |  | $ | 0.67 |  |  | $ | 0.42 |  |  | $ | 3.22 |  |  | $ | 2.34 |  |
| Diluted net income per potential common share |  | $ | 0.66 |  |  | $ | 0.42 |  |  | $ | 3.19 |  |  | $ | 2.32 |  |
| Weighted average basic common shares outstanding |  | 155,232 |  |  | 154,706 |  |  | 155,279 |  |  | 154,287 |  |
| Weighted average diluted potential common shares outstanding(1) |  | 156,689 |  |  | 156,563 |  |  | 156,743 |  |  | 155,955 |  |

[0000936395-21-000048:8k_2_02:59]
(1) Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the fourth quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:60]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:61]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the fourth quarter of fiscal 2020 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:62]
Weighted average diluted potential common shares outstanding used in calculating GAAP diluted net income per potential common share for fiscal 2020 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:63]
CIENA CORPORATION

[0000936395-21-000048:8k_2_02:64]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-21-000048:8k_2_02:65]
(in thousands, except share data)

[0000936395-21-000048:8k_2_02:66]
|  | October 30, |  | October 31, |
|  | 2021 |  | 2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,422,546 |  |  | $ | 1,088,624 |  |
| Short-term investments | 181,483 |  |  | 150,667 |  |
| Accounts receivable, net | 884,958 |  |  | 719,405 |  |
| Inventories | 374,265 |  |  | 344,379 |  |
| Prepaid expenses and other | 325,654 |  |  | 308,084 |  |
| Total current assets | 3,188,906 |  |  | 2,611,159 |  |
| Long-term investments | 70,038 |  |  | 82,226 |  |
| Equipment, building, furniture and fixtures, net | 284,968 |  |  | 272,377 |  |
| Operating lease right-of-use assets | 44,285 |  |  | 57,026 |  |
| Goodwill | 311,645 |  |  | 310,847 |  |
| Other intangible assets, net | 65,314 |  |  | 96,647 |  |
| Deferred tax asset, net | 800,180 |  |  | 647,805 |  |
| Other long-term assets | 99,891 |  |  | 102,830 |  |
| Total assets | $ | 4,865,227 |  |  | $ | 4,180,917 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 356,176 |  |  | $ | 291,904 |  |
| Accrued liabilities and other short-term obligations | 409,285 |  |  | 334,132 |  |
| Deferred revenue | 118,007 |  |  | 108,700 |  |
| Operating lease liabilities | 18,632 |  |  | 19,035 |  |
| Current portion of long-term debt | 6,930 |  |  | 6,930 |  |
| Total current liabilities | 909,030 |  |  | 760,701 |  |
| Long-term deferred revenue | 57,457 |  |  | 49,663 |  |
| Other long-term obligations | 166,803 |  |  | 123,185 |  |
| Long-term operating lease liabilities | 41,564 |  |  | 61,415 |  |
| Long-term debt, net | 670,355 |  |  | 676,356 |  |
| Total liabilities | $ | 1,845,209 |  |  | $ | 1,671,320 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 154,858,981 and 154,563,005 shares issued and outstanding | 1,549 |  |  | 1,546 |  |
| Additional paid-in capital | 6,803,162 |  |  | 6,826,531 |  |
| Accumulated other comprehensive income (loss) | 439 |  |  | (35,358) |  |
| Accumulated deficit | (3,785,132) |  |  | (4,283,122) |  |
| Total stockholders’ equity | 3,020,018 |  |  | 2,509,597 |  |
| Total liabilities and stockholders’ equity | $ | 4,865,227 |  |  | $ | 4,180,917 |  |

[0000936395-21-000048:8k_2_02:67]
8

[0000936395-21-000048:8k_2_02:68]
CIENA CORPORATION

[0000936395-21-000048:8k_2_02:69]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-21-000048:8k_2_02:70]
(in thousands)

[0000936395-21-000048:8k_2_02:71]
|  | Year Ended |
|  | October 30, 2021 |  | October 31, 2020 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 500,196 |  |  | $ | 361,291 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 96,233 |  |  | 93,908 |  |
| Share-based compensation costs | 84,336 |  |  | 67,758 |  |
| Amortization of intangible assets | 36,033 |  |  | 38,619 |  |
| Deferred taxes | (156,469) |  |  | 64,339 |  |
| Provision for inventory excess and obsolescence | 17,850 |  |  | 24,701 |  |
| Provision for warranty | 17,093 |  |  | 22,417 |  |
| Other | 14,525 |  |  | 20,483 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (174,377) |  |  | (17,299) |  |
| Inventories | (47,567) |  |  | (25,044) |  |
| Prepaid expenses and other | (19,691) |  |  | (38,998) |  |
| Operating lease right-of-use assets | 16,632 |  |  | 16,787 |  |
| Accounts payable, accruals and other obligations | 162,134 |  |  | (117,931) |  |
| Deferred revenue | 16,822 |  |  | 2,519 |  |
| Short and long-term operating lease liabilities | (22,104) |  |  | (19,896) |  |
| Net cash provided by operating activities | 541,646 |  |  | 493,654 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (79,550) |  |  | (82,667) |  |
| Purchase of available for sale securities | (172,778) |  |  | (223,196) |  |
| Proceeds from maturities of available for sale securities | 152,253 |  |  | 110,390 |  |
| Settlement of foreign currency forward contracts, net | 4,680 |  |  | 3,531 |  |
| Proceeds from sale of equity investment | 4,678 |  |  | — |  |
| Acquisition of businesses, net of cash acquired | — |  |  | (28,300) |  |
| Net cash used in investing activities | (90,717) |  |  | (220,242) |  |
| Cash flows used in financing activities: |  |  |  |
| Payment of long-term debt | (6,929) |  |  | (5,198) |  |
| Payment of debt issuance costs | — |  |  | (382) |  |
| Payment of finance lease obligations | (3,004) |  |  | (2,703) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (44,071) |  |  | (32,472) |  |
| Repurchases of common stock - repurchase program | (91,288) |  |  | (74,535) |  |
| Proceeds from issuance of common stock | 28,457 |  |  | 28,068 |  |
| Net cash used in financing activities | (116,835) |  |  | (87,222) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (198) |  |  | (1,643) |  |
| Net increase in cash, cash equivalents and restricted cash | 333,896 |  |  | 184,547 |  |
| Cash, cash equivalents and restricted cash at beginning of fiscal year | 1,088,708 |  |  | 904,161 |  |
| Cash, cash equivalents and restricted cash at end of fiscal year | $ | 1,422,604 |  |  | $ | 1,088,708 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 29,864 |  |  | $ | 32,837 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 73,127 |  |  | $ | 53,076 |  |
| Operating lease payments | $ | 24,058 |  |  | $ | 22,089 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 10,138 |  |  | $ | 7,854 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 800 |  |  | $ | — |  |
| Operating lease right-of-use assets subject to lease liability | $ | 4,356 |  |  | $ | 24,160 |  |
| Unrealized gain on equity investment | $ | — |  |  | $ | 2,681 |  |

[0000936395-21-000048:8k_2_02:72]
| APPENDIX A - Reconciliation of Adjusted (Non-GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |  | October 30, 2021 |  | October 31, 2020 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 477,119 |  |  | $ | 404,349 |  |  | $ | 1,721,979 |  |  | $ | 1,652,891 |  |
| Share-based compensation-products |  | 920 |  |  | 724 |  |  | 3,408 |  |  | 3,182 |  |
| Share-based compensation-services |  | 1,240 |  |  | 968 |  |  | 5,181 |  |  | 3,853 |  |
| Canadian Emergency Wage Subsidy-products |  | — |  |  | — |  |  | (4,283) |  |  | — |  |
| Canadian Emergency Wage Subsidy-services |  | — |  |  | — |  |  | (2,667) |  |  | — |  |
| Amortization of intangible assets |  | 2,856 |  |  | 3,732 |  |  | 12,301 |  |  | 15,235 |  |
| Total adjustments related to gross profit |  | 5,016 |  |  | 5,424 |  |  | 13,940 |  |  | 22,270 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 482,135 |  |  | $ | 409,773 |  |  | $ | 1,735,919 |  |  | $ | 1,675,161 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 46.3 | % |  | 49.5 | % |  | 47.9 | % |  | 47.4 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 339,710 |  |  | $ | 310,866 |  |  | $ | 1,226,623 |  |  | $ | 1,165,927 |  |
| Share-based compensation-research and development |  | 5,684 |  |  | 4,030 |  |  | 21,863 |  |  | 16,987 |  |
| Share-based compensation-sales and marketing |  | 6,192 |  |  | 5,137 |  |  | 25,152 |  |  | 20,194 |  |
| Share-based compensation-general and administrative |  | 7,466 |  |  | 5,982 |  |  | 28,804 |  |  | 23,424 |  |
| Canadian Emergency Wage Subsidy-research and development |  | — |  |  | — |  |  | (29,519) |  |  | — |  |
| Canadian Emergency Wage Subsidy-sales and marketing |  | — |  |  | — |  |  | (2,604) |  |  | — |  |
| Canadian Emergency Wage Subsidy-general and administrative |  | — |  |  | — |  |  | (2,207) |  |  | — |  |
| Significant asset impairments and restructuring costs |  | 5,700 |  |  | 7,854 |  |  | 29,565 |  |  | 22,652 |  |
| Amortization of intangible assets |  | 5,836 |  |  | 5,851 |  |  | 23,732 |  |  | 23,383 |  |
| Acquisition and integration costs |  | 1,712 |  |  | 3,127 |  |  | 2,572 |  |  | 4,031 |  |
| Total adjustments related to operating expense |  | $ | 32,590 |  |  | $ | 31,981 |  |  | $ | 97,358 |  |  | $ | 110,671 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 307,120 |  |  | $ | 278,885 |  |  | $ | 1,129,265 |  |  | $ | 1,055,256 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 137,409 |  |  | $ | 93,483 |  |  | $ | 495,356 |  |  | $ | 486,964 |  |
| Total adjustments related to gross profit |  | 5,016 |  |  | 5,424 |  |  | 13,940 |  |  | 22,270 |  |
| Total adjustments related to operating expense |  | 32,590 |  |  | 31,981 |  |  | 97,358 |  |  | 110,671 |  |
| Total adjustments related to income from operations |  | 37,606 |  |  | 37,405 |  |  | 111,298 |  |  | 132,941 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 175,015 |  |  | $ | 130,888 |  |  | $ | 606,654 |  |  | $ | 619,905 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 16.8 | % |  | 15.8 | % |  | 16.8 | % |  | 17.6 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 103,499 |  |  | $ | 65,041 |  |  | $ | 500,196 |  |  | $ | 361,291 |  |
| Exclude GAAP provision (benefit) for income taxes |  | 25,826 |  |  | 20,798 |  |  | (37,445) |  |  | 94,670 |  |
| Income before income taxes |  | 129,325 |  |  | 85,839 |  |  | 462,751 |  |  | 455,961 |  |
| Total adjustments related to income from operations |  | 37,606 |  |  | 37,405 |  |  | 111,298 |  |  | 132,941 |  |
| Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | — |  |  | 646 |  |
| Unrealized (gain) loss on equity investment |  | — |  |  | (2,681) |  |  | 165 |  |  | (2,681) |  |
| Adjusted income before income taxes |  | 166,931 |  |  | 120,563 |  |  | 574,214 |  |  | 586,867 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 34,221 |  |  | 26,042 |  |  | 117,714 |  |  | 126,763 |  |
| Adjusted (non-GAAP) net income |  | $ | 132,710 |  |  | $ | 94,521 |  |  | $ | 456,500 |  |  | $ | 460,104 |  |
| Weighted average basic common shares outstanding |  | 155,232 |  |  | 154,706 |  |  | 155,279 |  |  | 154,287 |  |
| Weighted average diluted potential common shares outstanding(1) |  | 156,689 |  |  | 156,563 |  |  | 156,743 |  |  | 155,955 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.66 |  |  | $ | 0.42 |  |  | $ | 3.19 |  |  | $ | 2.32 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.85 |  |  | $ | 0.60 |  |  | $ | 2.91 |  |  | $ | 2.95 |  |

[0000936395-21-000048:8k_2_02:73]
(1) Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the fourth quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:74]
Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:75]
Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the fourth quarter of fiscal 2020 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:76]
Weighted average diluted potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for fiscal 2020 includes 1.7 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000048:8k_2_02:77]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 30, 2021 |  | October 31, 2020 |  | October 30, 2021 |  | October 31, 2020 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 103,499 |  |  | $ | 65,041 |  |  | $ | 500,196 |  |  | $ | 361,291 |  |
| Add: Interest expense |  | 7,916 |  |  | 7,395 |  |  | 30,837 |  |  | 31,321 |  |
| Less: Interest and other income (loss), net |  | (168) |  |  | (249) |  |  | (1,768) |  |  | 964 |  |
| Add: Loss on extinguishment and modification of debt |  | — |  |  | — |  |  | — |  |  | (646) |  |
| Add: Provision (benefit) for income taxes |  | 25,826 |  |  | 20,798 |  |  | (37,445) |  |  | 94,670 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 24,315 |  |  | 23,538 |  |  | 96,233 |  |  | 93,908 |  |
| Add: Amortization of intangible assets |  | 8,692 |  |  | 9,584 |  |  | 36,033 |  |  | 38,619 |  |
| EBITDA |  | $ | 170,416 |  |  | $ | 126,605 |  |  | $ | 627,622 |  |  | $ | 619,491 |  |
| Less: Canadian Emergency Wage Subsidy |  | — |  |  | — |  |  | 41,280 |  |  | — |  |
| Add: Share-based compensation cost |  | 21,366 |  |  | 16,920 |  |  | 84,336 |  |  | 67,758 |  |
| Add: Significant asset impairments and restructuring costs |  | 5,700 |  |  | 7,854 |  |  | 29,565 |  |  | 22,652 |  |
| Add: Acquisition and integration costs |  | 1,712 |  |  | 3,127 |  |  | 2,572 |  |  | 4,031 |  |
| Adjusted EBITDA |  | $ | 199,194 |  |  | $ | 154,506 |  |  | $ | 702,815 |  |  | $ | 713,932 |  |

[0000936395-21-000048:8k_2_02:78]
* * *

[0000936395-21-000048:8k_2_02:79]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-21-000048:8k_2_02:80]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-21-000048:8k_2_02:81]
•Canadian Emergency Wage Subsidy - a program introduced by the Government of Canada to offset a portion of employee wages for a limited period in response to COVID-19 outbreak.

[0000936395-21-000048:8k_2_02:82]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and the redesign of business processes.

[0000936395-21-000048:8k_2_02:83]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-21-000048:8k_2_02:84]
•Acquisition and integration costs - includes expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisition of Centina in fiscal 2020, and costs and recoveries of acquisition consideration and compensation associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities.

[0000936395-21-000048:8k_2_02:85]
•Loss on extinguishment and modification of debt - reflects extinguishment and modification of debt expenses related to refinancing of our Term Loan due September 28, 2025.

[0000936395-21-000048:8k_2_02:86]
•Unrealized (gain)loss on equity investment - reflects a change in the carrying value of certain cost method equity investments.

[0000936395-21-000048:8k_2_02:87]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20.5% for fiscal 2021 and 21.6% for fiscal 2020. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.

[0000936395-21-000048:8k_2_02:88]
Ciena's GAAP tax provision for fiscal 2021 benefited from recording a $119.3 million tax benefit related to an

[0000936395-21-000048:8k_2_02:89]
internal transfer of non-U.S. intangible assets that was recognized as a result of the step-up in basis of such

[0000936395-21-000048:8k_2_02:90]
rights for tax purposes. The Non-GAAP tax provision for the periods presented do not include this tax benefit or

[0000936395-21-000048:8k_2_02:91]
the corresponding deferred tax asset.
