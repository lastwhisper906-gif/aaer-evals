# CIEN 10-K controls and the auditor's report


## auditors_report

[0000936395-21-000054:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0000936395-21-000054:auditors_report:2]
To the Board of Directors and Stockholders of Ciena Corporation

[0000936395-21-000054:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0000936395-21-000054:auditors_report:4]
We have audited the accompanying consolidated balance sheets of Ciena Corporation and its subsidiaries (the “Company”) as of October 30, 2021 and October 31, 2020, and the related consolidated statements of operations, of comprehensive income, of changes in stockholders’ equity and of cash flows for each of the three years in the period ended October 30, 2021, including the related notes (collectively referred to as the “consolidated financial statements”). We also have audited the Company's internal control over financial reporting as of October 30, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0000936395-21-000054:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of October 30, 2021 and October 31, 2020, and the results of its operations and its cash flows for each of the three years in the period ended October 30, 2021 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company maintained, in all material respects, effective internal control over financial reporting as of October 30, 2021, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO.

[0000936395-21-000054:auditors_report:6]
Changes in Accounting Principles

[0000936395-21-000054:auditors_report:7]
As discussed in Note 1 to the consolidated financial statements, the Company changed the manner in which it accounts for leases in 2020, and the manner in which it accounts for revenue from contracts with customers in 2019.

[0000936395-21-000054:auditors_report:8]
Basis for Opinions

[0000936395-21-000054:auditors_report:9]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in the Report of Management on Internal Control Over Financial Reporting appearing under Item 9A. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0000936395-21-000054:auditors_report:10]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0000936395-21-000054:auditors_report:11]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0000936395-21-000054:auditors_report:12]
Definition and Limitations of Internal Control over Financial Reporting

[0000936395-21-000054:auditors_report:13]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0000936395-21-000054:auditors_report:14]
66

[0000936395-21-000054:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0000936395-21-000054:auditors_report:16]
Critical Audit Matters

[0000936395-21-000054:auditors_report:17]
The critical audit matters communicated below are matters arising from the current period audit of the consolidated financial statements that were communicated or required to be communicated to the audit committee and that (i) relate to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matters below, providing separate opinions on the critical audit matters or on the accounts or disclosures to which they relate.

[0000936395-21-000054:auditors_report:18]
Reserve for Excess and Obsolete Inventory

[0000936395-21-000054:auditors_report:19]
As described in Notes 1 and 10 to the consolidated financial statements, the Company’s consolidated inventory balance, net of the allowance for excess and obsolescence, was $374.3 million as of October 30, 2021. Management records a provision for excess and obsolete inventory when an impairment has been identified and has a reserve for excess and obsolete inventory of $37.0 million as of October 30, 2021. Management writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in the Company’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions.

[0000936395-21-000054:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the reserve for excess and obsolete inventory is a critical audit matter are the significant judgment by management when developing their estimate, which in turn led to a high degree of auditor judgment and effort to perform procedures and evaluate the audit evidence obtained relating to the assumptions regarding future demand.

[0000936395-21-000054:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the Company’s evaluation of the reserve for excess and obsolete inventory, including controls over the assumptions used within the model. These procedures also included, among others, testing management’s process for determining the reserve for excess and obsolete inventory. This included evaluating the appropriateness of the inventory reserve model and the reasonableness of the significant assumptions relating to the future demand. Evaluating the assumptions related to future demand involved evaluating whether the assumptions used were reasonable considering historical sales and expectations regarding future sales. Testing management's process for determining future demand included procedures to evaluate the reliability, completeness and relevance of management's data used in the future demand assumption. Testing the relevance and reliability of the data included evaluating the reasonableness of the long-term sales forecasts and historical activity.

[0000936395-21-000054:auditors_report:22]
Internal Transfer of Certain Non-U.S. Intangible Assets

[0000936395-21-000054:auditors_report:23]
As described in Note 23 to the consolidated financial statements, the Company completed an internal transfer of certain of its non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. As disclosed by management, the recognition of the deferred tax asset from the internal transfer of the non-U.S. intangible assets requires management to make estimates and assumptions to determine the fair value of the intangible assets transferred and significant judgments in evaluating the application of tax laws in the applicable jurisdictions, including where the deferred tax asset will be recovered.

[0000936395-21-000054:auditors_report:24]
The principal considerations for our determination that performing procedures relating to the internal transfer of certain non-U.S. intangible assets is a critical audit matter are the significant judgment by management in evaluating the application of tax laws in the applicable jurisdictions, which in turn led to a high degree of auditor judgment, subjectivity, and effort to perform procedures and evaluate the audit evidence obtained relating to accounting for the internal transfer and recovery of certain non-U.S. intangible assets based on management’s application of tax laws in the applicable jurisdictions. In addition, the audit effort involved the use of professionals with specialized skill and knowledge.

[0000936395-21-000054:auditors_report:25]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to the accounting for the internal transfer of the non-U.S. intangible assets, including controls over management’s review of the underlying agreements and management’s application of the tax laws to the transfer and recovery of the non-U.S. intangible assets. These procedures also included, among others, (i) examining the underlying agreements, (ii) evaluating the tax laws applicable to the transfer and recovery of certain non-U.S. intangible assets, and (iii) testing the calculation of the deferred tax

[0000936395-21-000054:auditors_report:26]
67

[0000936395-21-000054:auditors_report:27]
asset, including testing the completeness and accuracy of the data used. Professionals with specialized skill and knowledge were used to assist in the evaluation of management’s determination of the applicability of the relevant tax laws in the applicable jurisdictions.

[0000936395-21-000054:auditors_report:28]
/s/ PricewaterhouseCoopers LLP

[0000936395-21-000054:auditors_report:29]
Baltimore, Maryland

[0000936395-21-000054:auditors_report:30]
December 17, 2021

[0000936395-21-000054:auditors_report:31]
We have served as the Company’s auditor since 1992.

[0000936395-21-000054:auditors_report:32]
68

[0000936395-21-000054:auditors_report:33]
CIENA CORPORATION


## item_9a

[0000936395-21-000054:item_9a:1]
Item 9A. Controls and Procedures

[0000936395-21-000054:item_9a:2]
Disclosure Controls and Procedures

[0000936395-21-000054:item_9a:3]
As of the end of the period covered by this report, we carried out an evaluation under the supervision and with the participation of management, including our Chief Executive Officer and Chief Financial Officer, of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e) under the Exchange Act). Based on this evaluation, our Chief Executive Officer and Chief Financial Officer concluded that our disclosure controls and procedures were effective as of the end of the period covered by this report.

[0000936395-21-000054:item_9a:4]
Changes in Internal Control over Financial Reporting

[0000936395-21-000054:item_9a:5]
There was no change in our internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended) during the most recently completed fiscal quarter that has materially affected, or is reasonably likely to materially affect, our internal control over financial reporting.

[0000936395-21-000054:item_9a:6]
Report of Management on Internal Control Over Financial Reporting

[0000936395-21-000054:item_9a:7]
The management of Ciena Corporation is responsible for establishing and maintaining adequate internal control over financial reporting (as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934).

[0000936395-21-000054:item_9a:8]
The internal control over financial reporting at Ciena Corporation was designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with accounting principles generally accepted in the United States of America. Internal control over financial reporting includes those policies and procedures that:

[0000936395-21-000054:item_9a:9]
•pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of Ciena Corporation;

[0000936395-21-000054:item_9a:10]
•provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with accounting principles generally accepted in the United States of America;

[0000936395-21-000054:item_9a:11]
•provide reasonable assurance that receipts and expenditures of Ciena Corporation are being made only in accordance with authorization of management and directors of Ciena Corporation; and

[0000936395-21-000054:item_9a:12]
•provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of assets that could have a material effect on the consolidated financial statements.

[0000936395-21-000054:item_9a:13]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements.

[0000936395-21-000054:item_9a:14]
Management of Ciena Corporation assessed the effectiveness of the Company’s internal control over financial reporting as of October 30, 2021. Management based this assessment on criteria for effective internal control over financial reporting described in “COSO 2013 Internal Control — Integrated Framework” issued by the Committee of Sponsoring Organizations of the Treadway Commission. Based on this assessment, management determined that, as of October 30, 2021, Ciena Corporation maintained effective internal control over financial reporting. Management reviewed the results of its assessment with the Audit Committee of our Board of Directors.

[0000936395-21-000054:item_9a:15]
PricewaterhouseCoopers LLP, independent registered public accounting firm, who audited and reported on the consolidated financial statements of Ciena Corporation included in this annual report, has also audited the effectiveness of Ciena Corporation’s internal control over financial reporting as of October 30, 2021, as stated in its report appearing in Item 8 of Part II of this annual report.

[0000936395-21-000054:item_9a:16]
| /s/ Gary B. Smith |  | /s/ James E. Moylan, Jr. |  |
| Gary B. Smith |  | James E. Moylan, Jr. |  |
| President and Chief Executive Officer |  | Senior Vice President and Chief Financial Officer |  |
| December 17, 2021 |  | December 17, 2021 |  |
