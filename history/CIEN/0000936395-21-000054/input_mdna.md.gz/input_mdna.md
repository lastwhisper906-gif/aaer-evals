# CIEN MD&A — 0000936395-21-000054


## mdna

[0000936395-21-000054:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-21-000054:mdna:2]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-21-000054:mdna:3]
Overview

[0000936395-21-000054:mdna:4]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that enable the transport, routing, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and emerging network operators.

[0000936395-21-000054:mdna:5]
Our portfolio is designed to enable what we refer to as the Adaptive Network™, our vision for a network end state that emphasizes a programmable and scalable network infrastructure, software control and automation capabilities, network analytics and intelligence, and related advanced services. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end-user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-21-000054:mdna:6]
Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. Our Converged Packet Optical portfolio includes products that support the connection of content to content, including in long haul and regional, submarine and data center interconnect networks, and users to content, including in metro and edge networks. Our Routing and Switching portfolio includes products and solutions that enable efficient IP transport in next-generation metro edge, access and aggregation networks, connecting users to content in applications that include 5G and Internet of Things, mobile backhaul, optical access, virtualization and enterprise services.

[0000936395-21-000054:mdna:7]
To complement our Networking Platforms, we offer Platform Software, which includes a wide array of software solutions that deliver operations, administration, maintenance, and provisioning (“OAM&P”) functionality, as well as domain control, orchestration, operational support systems (“OSS”) and service assurance to achieve closed loop automation across multi-vendor and multi-domain network environments. Through our Blue Planet® Software suite, we enable customers to accelerate the digital transformation of their networks through service lifecycle automation.

[0000936395-21-000054:mdna:8]
In addition to our systems and software, we also offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, network operations center (“NOC”) management, and optimization services.

[0000936395-21-000054:mdna:9]
Supply Chain Constraints

[0000936395-21-000054:mdna:10]
Due to increased demand across a range of industries, the global supply market for certain raw materials and components, including, in particular, the semiconductor components used in most of our products, has experienced significant disruption in recent periods. These conditions, which worsened during the second half of fiscal 2021, have been exacerbated in part by the COVID-19 pandemic. As a result, we have experienced ongoing component shortages, longer lead times and increased cost of components, particularly relating to semiconductors. Some of our suppliers have indicated that, as a result of current constraints, they intend to cease manufacturing of certain components used in our products. These conditions have impacted the lead times for our products, and could adversely impact our ability to meet customer demand where we cannot timely secure supply of these components. In response, we have implemented mitigation strategies and increased our purchases of inventory for certain components. In some cases, we have incurred higher costs to secure available inventory, or have extended our purchase commitments or placed non-cancellable orders with suppliers, which introduces inventory risk if our forecasts and assumptions are inaccurate.

[0000936395-21-000054:mdna:11]
We expect these constrained supply conditions to increase our costs of goods sold and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. The current supply conditions can also be expected to adversely impact our gross margin as well as the level and timing of our revenue during fiscal 2022. We believe these supply chain challenges and their adverse impact on our business and financial results will persist, at least through

[0000936395-21-000054:mdna:12]
the first half of calendar 2022, and may extend into periods thereafter. See “Risk Factors” in Item 1A of Part I of this report for further discussion of risks related to our supply chain.

[0000936395-21-000054:mdna:13]
Impact of the COVID-19 Pandemic on our Business and Operations

[0000936395-21-000054:mdna:14]
In response to the COVID-19 pandemic, we have prioritized the safety of our employees and business partners, while continuing to support the needs of our customers and communities during this unprecedented period. We have also implemented business continuity plans designed to minimize potential business disruption from the COVID-19 pandemic and to protect our supply chain and customer fulfillment and support operations. During fiscal 2021, the COVID-19 pandemic continued to affect our business operations, including as set forth below.

[0000936395-21-000054:mdna:15]
Demand for Products & Services. The demand environment for our products and services remains dynamic and continues to be impacted by the effects of the COVID-19 pandemic. For example, we experienced a constrained spending environment during the second half of fiscal 2020 and the first quarter of fiscal 2021 that adversely impacted our revenue during that period. During the remainder of fiscal 2021, we experienced significantly stronger order volumes for our products and services, particularly among a concentrated set of larger customers with which we have existing positions as a supplier. This improved demand environment and growth in order volumes contributed to our increased revenue in the second half of fiscal 2021 compared to the first half of fiscal 2021. We believe some portion of these orders reflects certain short-term customer purchasing behaviors, including network operators addressing capacity and network requirements following a period of constrained spending in previous quarters, and possible acceleration of future orders due to the implementation of security of supply strategies amidst global supply constraints for semiconductor components. Over the longer term, we continue to believe that the increased demands placed on network infrastructures as a result of the COVID-19 pandemic, and the related increase in remote working worldwide, have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation.

[0000936395-21-000054:mdna:16]
Services and Customer Fulfillment. During fiscal 2020 and fiscal 2021, we experienced some disruption in our ability to provide installation, professional and fulfillment services to customers due to site readiness and access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings. We have also experienced some disruption and delays in our supply chain operations and logistics, including shipping delays and higher transport costs. The duration and severity of conditions in the future is uncertain and, as a result, may continue to adversely impact our revenue and results of operations.

[0000936395-21-000054:mdna:17]
Sales & Marketing. Restrictions on travel due to COVID-19 and limitations on interactions with customers, such as field and lab trials, have continued to negatively impact our ability to carry out certain sales and marketing activities, including our ability to secure new customers, to qualify and sell new products, and to grow sales with customers. Customer delays in operationalizing new network projects during fiscal 2021 that we anticipated occurring on their original timelines adversely affected our revenue. Conversely, our recent gross margin performance during fiscal 2021 benefited from these dynamics, with a larger percentage of our revenue comprised of existing business, as compared to new design wins and early in life projects, which tend to have lower margins.

[0000936395-21-000054:mdna:18]
Canada Emergency Wage Subsidy (“CEWS”). In April 2020, the government of Canada introduced the CEWS program to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. Amounts from the CEWS program positively impacted our operating expense and measures of profit for the fiscal year ended October 30, 2021. For the fiscal year ended October 30, 2021, we recorded CEWS benefits of CAD$52.2 million ($41.3 million), net of certain fees, related to claim periods beginning March 15, 2020, including CAD$43.9 million ($35.4 million) related to employee wages from fiscal 2020. The CEWS program has expired and we do not anticipate a similar impact on our financial results in future periods. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information.

[0000936395-21-000054:mdna:19]
The COVID-19 pandemic and countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications for our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 pandemic and its impact remain dynamic. Variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-21-000054:mdna:20]
Supply Chain and Distribution Structure; Recognition of Deferred Tax Asset in Fiscal 2021

[0000936395-21-000054:mdna:21]
To better accommodate the requirements of a global business, we are implementing a plan to reorganize our global supply chain and distribution structure more substantially, which includes a legal entity reorganization and related system upgrade. We completed the first phase of this plan in fiscal 2021, and expect to continue to implement the plan during the first half of fiscal 2022. As part of this reorganization, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of $119.3 million as a deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in our effective tax rate for the year ended October 30, 2021, and had a significant, one-time impact on our net income for the period.

[0000936395-21-000054:mdna:22]
Market Opportunity

[0000936395-21-000054:mdna:23]
The markets in which we sell our communications networking solutions are dynamic and are characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Emerging services and applications, including 5G mobile communications, Fiber Deep and the Internet of Things, are further impacting or expected to impact wireline network infrastructures, particularly at the edge of networks, where increased computing power and automation are required to provide the quality of experience demanded by end users. Many network operators are under pressure to constrain their capital expenditure budgets, as they cannot grow their network spending at the rate of bandwidth growth. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation. Other network operators are pursuing a diverse range of consumption models in their design and procurement of network infrastructure solutions. Our Adaptive Network vision and our business strategy to capitalize on these changing market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-21-000054:mdna:24]
Business Diversification

[0000936395-21-000054:mdna:25]
A key element of our strategy is to continue to diversify our solutions offerings, customer base and geographic reach to address fast-growing applications and markets. We believe that the continued diversification of our business is important to address the dynamic industry environment in which we operate, to grow our business, and to withstand potential slowdowns adversely affecting particular geographies, markets or customer segments. We believe this diversification has allowed us to maintain a greater degree of stability, to remain resilient and to continue to grow our business despite the impact of the COVID-19 pandemic on any particular geography, segment or customer account.

[0000936395-21-000054:mdna:26]
Investment in Technology Innovation

[0000936395-21-000054:mdna:27]
We are focused on growing our optical and packet infrastructure business by addressing fast-growing markets and applications, including data center interconnection, packet aggregation and routing and submarine networks. In fiscal 2021, we brought to market our footprint-optimized WaveLogic 5 Nano 100G-400G coherent pluggable transceivers. We are also developing Routing and Switching solutions with enhanced IP/Ethernet capabilities to expand our addressable market into additional next generation metro and access applications including packet routing, aggregation and switching, 5G cross-haul, Fiber Deep, and edge computing. In fiscal 2021, we also added several new routing platforms to support the demands of mobile xHaul (fronthaul, midhaul and backhaul) transport. During the first quarter of fiscal 2022, we acquired AT&T’s Vyatta virtual routing and switching technology, which is intended to expand and accelerate our Adaptive IP solutions and address the growing market opportunity to transform the edge, including 5G networks and cloud environments. See Note 28 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on this acquisition and the related accounting.

[0000936395-21-000054:mdna:28]
Fiscal Year-End Backlog

[0000936395-21-000054:mdna:29]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These agreements do not obligate customers to purchase any minimum or guaranteed order quantities. Moreover, we are periodically awarded business for new network opportunities or network upgrades following a selection process. In calculating backlog, we only include (i) customer purchase orders for products that have not been shipped and for services that have not yet been performed; and (ii) customer orders relating to products that have been delivered and services that have been performed, but are awaiting customer acceptance under the applicable contract terms. Generally, our customers may cancel or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. Backlog may be fulfilled several quarters following receipt of a purchase order, or in the case of certain service obligations, may relate to multi-year support period. As a result, backlog should not necessarily be viewed as an accurate indicator of future revenue for any particular period.

[0000936395-21-000054:mdna:30]
Our backlog was $2.17 billion as of October 30, 2021 as compared to $1.19 billion as of October 31, 2020. Backlog includes product and service orders from commercial and government customers combined, and our significant annual growth reflects the demand dynamics described above. Backlog at October 30, 2021 includes approximately $241.7 million primarily related to orders for products and maintenance and support services that are not expected to be filled or performed within fiscal 2022. Because backlog can be defined in different ways by different companies, our presentation of backlog may not be comparable with figures presented by other companies in our industry.

[0000936395-21-000054:mdna:31]
Consolidated Results of Operations

[0000936395-21-000054:mdna:32]
A discussion regarding our financial condition and results of operations for fiscal 2021 compared to fiscal 2020 is presented below. A discussion of fiscal 2020 compared to fiscal 2019 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended October 31, 2020, filed with the SEC on December 18, 2020 (our “2020 Annual Report”), which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-21-000054:mdna:33]
Operating Segments

[0000936395-21-000054:mdna:34]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Effective as of the beginning of fiscal 2021, we renamed our “Packet Networking” product line “Routing and Switching.” This change was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product line. References to our “Packet Networking” product line in prior periods have been changed to “Routing and Switching” in this report. See Notes 2 and 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0000936395-21-000054:mdna:35]
Fiscal 2021 Compared to Fiscal 2020

[0000936395-21-000054:mdna:36]
Revenue

[0000936395-21-000054:mdna:37]
Currency Fluctuations

[0000936395-21-000054:mdna:38]
During fiscal 2021, approximately 16.4% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Canadian Dollars, Brazilian Reais, British Pounds, Japanese Yen, and Indian Rupee. During fiscal 2021, as compared to fiscal 2020, the U.S. Dollar primarily weakened against these and other currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $21.8 million, or 0.6%, as compared to fiscal 2020.

[0000936395-21-000054:mdna:39]
Operating Segment Revenue

[0000936395-21-000054:mdna:40]
The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000054:mdna:41]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,553,509 |  |  | 70.5 |  | $ | 2,547,647 |  |  | 72.1 |  | $ | 5,862 |  |  | 0.2 |
| Routing and Switching | 271,796 |  |  | 7.5 |  | 267,416 |  |  | 7.6 |  | 4,380 |  |  | 1.6 |
| Total Networking Platforms | 2,825,305 |  |  | 78.0 |  | 2,815,063 |  |  | 79.7 |  | 10,242 |  |  | 0.4 |
| Platform Software and Services | 229,588 |  |  | 6.4 |  | 197,809 |  |  | 5.6 |  | 31,779 |  |  | 16.1 |
| Blue Planet Automation Software and Services | 77,247 |  |  | 2.1 |  | 62,632 |  |  | 1.8 |  | 14,615 |  |  | 23.3 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 283,350 |  |  | 7.8 |  | 269,354 |  |  | 7.6 |  | 13,996 |  |  | 5.2 |
| Installation and Deployment | 171,489 |  |  | 4.7 |  | 152,003 |  |  | 4.3 |  | 19,486 |  |  | 12.8 |
| Consulting and Network Design | 33,705 |  |  | 1.0 |  | 35,296 |  |  | 1.0 |  | (1,591) |  |  | (4.5) |
| Total Global Services | 488,544 |  |  | 13.5 |  | 456,653 |  |  | 12.9 |  | 31,891 |  |  | 7.0 |
| Consolidated revenue | $ | 3,620,684 |  |  | 100.0 |  | $ | 3,532,157 |  |  | 100.0 |  | $ | 88,527 |  |  | 2.5 |

[0000936395-21-000054:mdna:42]
_________________________________

[0000936395-21-000054:mdna:43]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:44]
•Networking Platforms segment revenue increased, reflecting product line sales increases of $5.9 million of our Converged Packet Optical products and $4.4 million of our Routing and Switching products.

[0000936395-21-000054:mdna:45]
◦Converged Packet Optical sales increased, primarily reflecting sales increases of $88.4 million of our Waveserver® products and $45.6 million of our 6500 Reconfigurable Line System (RLS), primarily to communication service providers. These sales increases were partially offset primarily by sales decreases of $75.7 million of our 6500 Packet-Optical Platform primarily to enterprise customers and communication service providers and $40.2 million of our 5400 family of Packet-Optical Platforms primarily to communications service providers.

[0000936395-21-000054:mdna:46]
◦Routing and Switching sales increased, primarily reflecting sales increases of $10.9 million of our platform independent software and $8.1 million of our 3000 and 5000 families of service delivery and aggregation switches to communication service providers. These increases were partially offset by a sales decrease of $12.5 million of our 8700 Packetwave Platform primarily to government customers.

[0000936395-21-000054:mdna:47]
•Platform Software and Services segment revenue increased, reflecting an increase of $33.2 million in services, primarily to communication service providers. This sales increase was partially offset by a $1.5 million decrease in software sales. The software sales decrease was primarily due to declines in sales of $4.0 million of our OneControl Unified Management System software and $2.9 million of our other legacy software solutions, partially offset by increased sales of $5.1 million of our MCP software platform. We continue to pursue further customer adoption of our MCP software platform and its enhanced features and functionality. As we transition existing customers as well as features and functionality from our legacy software to this platform, we expect revenue declines for our legacy software solutions within this segment.

[0000936395-21-000054:mdna:48]
•Blue Planet Automation Software and Services segment revenue increased, reflecting increases of $9.0 million of software and $5.6 million in software services.

[0000936395-21-000054:mdna:49]
•Global Services segment revenue increased, primarily reflecting sales increases of $19.5 million of our installation and deployment services and $14.0 million of our maintenance support and training, partially offset by a sales decrease of $1.6 million of our consulting and network design services.

[0000936395-21-000054:mdna:50]
Revenue by Geographic Region

[0000936395-21-000054:mdna:51]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”) and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our EMEA region revenue for fiscal 2021 was primarily driven by increased sales in the United Kingdom, France and the Netherlands. The increase in our Americas region revenue for fiscal 2021 was primarily driven by increased sales in the United States, Canada, and Brazil. The decrease in our APAC region revenue for fiscal 2021 was primarily driven by decreased sales in Japan, Singapore and Australia, partially offset by increased sales in India. The following table reflects our geographic distribution of revenue, which is principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-21-000054:mdna:52]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 2,525,619 |  |  | 69.8 |  | $ | 2,469,278 |  |  | 69.9 |  | $ | 56,341 |  |  | 2.3 |
| EMEA | 670,462 |  |  | 18.5 |  | 591,468 |  |  | 16.8 |  | 78,994 |  |  | 13.4 |
| APAC | 424,603 |  |  | 11.7 |  | 471,411 |  |  | 13.3 |  | (46,808) |  |  | (9.9) |
| Total | $ | 3,620,684 |  |  | 100.0 |  | $ | 3,532,157 |  |  | 100.0 |  | $ | 88,527 |  |  | 2.5 |

[0000936395-21-000054:mdna:53]
_________________________________

[0000936395-21-000054:mdna:54]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:55]
•Americas revenue increased, reflecting sales increases of $18.4 million within our Networking Platforms segment, $13.3 million within our Platform Software and Services segment, $12.4 million within our Global Services segment and $12.3 million within our Blue Planet Automation Software and Services segment.

[0000936395-21-000054:mdna:56]
•EMEA revenue increased, reflecting sales increases of $47.5 million within our Networking Platforms segment, $17.4 million within our Global Services segment, $8.7 million within our Platform Software and Services segment and $5.4 million within our Blue Planet Automation Software and Services segment. These sales increases were primarily due to increased sales to Web-scale providers in the Netherlands and the United Kingdom, and communications service providers in France and the United Kingdom.

[0000936395-21-000054:mdna:57]
•APAC revenue decreased, primarily reflecting sales decreases of $55.6 million within our Networking Platforms segment and $3.0 million within our Blue Planet Automation Software and Services segment. These decreases were partially offset by sales increases of $9.8 million within our Platform Software and Services segment and $2.1 million within our Global Services segment. Our Networking Platforms segment revenue sales decreases were primarily due to decreased sales to communications service providers in Japan, enterprise customers in Australia, and Web-scale providers in Singapore, partially offset by increased sales to enterprise customers in India.

[0000936395-21-000054:mdna:58]
In fiscal 2021 and fiscal 2020, our top ten customers contributed 55.5% and 54.5% of our revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting the businesses of those customers. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Sales to AT&T were $447.4 million, or 12.4% of total revenue, in fiscal 2021, and $373.2 million, or 10.6% of total revenue, in fiscal 2020. No other customer accounted for greater than 10% of our revenue in fiscal 2021 or fiscal 2020.

[0000936395-21-000054:mdna:59]
While drivers of bandwidth growth and network evolution remain strong, many of our network operator customers are under pressure to constrain their capital expenditure budgets, and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or add features, there is a market expectation for solutions that are more cost-effective than existing or competing solutions and that new products consistently deliver lower price per bit performance. The combination of this regular technology-driven price compression, price competition in our markets and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-21-000054:mdna:60]
Cost of Goods Sold and Gross Profit

[0000936395-21-000054:mdna:61]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-21-000054:mdna:62]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-21-000054:mdna:63]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive annual product cost reductions relative to the price erosion that we regularly encounter in our markets. This can be challenging, particularly within the current supply constrained environment. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity and need to monitor their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-21-000054:mdna:64]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-21-000054:mdna:65]
In fiscal 2021, we recorded CEWS benefits of $7.0 million, net of certain fees, related to the particular line item within costs of goods sold in our Consolidated Statement of Operations to which the grant activity related. For further information relating to our receipt of amounts under the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-21-000054:mdna:66]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 3,620,684 |  |  | 100.0 |  | $ | 3,532,157 |  |  | 100.0 |  | $ | 88,527 |  |  | 2.5 |
| Total cost of goods sold | 1,898,705 |  |  | 52.4 |  | 1,879,266 |  |  | 53.2 |  | 19,439 |  |  | 1.0 |
| Gross profit | $ | 1,721,979 |  |  | 47.6 |  | $ | 1,652,891 |  |  | 46.8 |  | $ | 69,088 |  |  | 4.2 |

[0000936395-21-000054:mdna:67]
_________________________________

[0000936395-21-000054:mdna:68]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:69]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,932,602 |  |  | 100.0 |  | $ | 2,914,790 |  |  | 100.0 |  | $ | 17,812 |  |  | 0.6 |
| Product cost of goods sold | 1,545,269 |  |  | 52.7 |  | 1,573,791 |  |  | 54.0 |  | (28,522) |  |  | (1.8) |
| Product gross profit | $ | 1,387,333 |  |  | 47.3 |  | $ | 1,340,999 |  |  | 46.0 |  | $ | 46,334 |  |  | 3.5 |

[0000936395-21-000054:mdna:70]
_________________________________

[0000936395-21-000054:mdna:71]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:72]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 688,082 |  |  | 100.0 |  | $ | 617,367 |  |  | 100.0 |  | $ | 70,715 |  |  | 11.5 |
| Service cost of goods sold | 353,436 |  |  | 51.4 |  | 305,475 |  |  | 49.5 |  | 47,961 |  |  | 15.7 |
| Service gross profit | $ | 334,646 |  |  | 48.6 |  | $ | 311,892 |  |  | 50.5 |  | $ | 22,754 |  |  | 7.3 |

[0000936395-21-000054:mdna:73]
_________________________________

[0000936395-21-000054:mdna:74]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:75]
•Gross profit as a percentage of revenue increased by $69.1 million. Gross profit as a percentage of total revenue (“gross margin”) increased by 80 basis points. Our gross margin benefited from product cost reductions and a $7.0 million benefit from the CEWS program, partially offset by market-based price compression that we encountered during the period and a reduction in our services gross margin. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, a higher proportion of our fiscal 2021 revenue consisted of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, all of which tend to carry lower margins. We expect our future gross margins to reduce from these elevated short-term levels as the adverse impact of the pandemic on new business lessens and our overall revenue resumes a more typical composition of revenue from existing and new business. Moreover, as described in “Overview” above, we expect the current market shortage for semiconductor components and constrained supply environment to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2022. We believe these supply chain challenges and their adverse impact on our business and financial results will persist, at least through the first half of calendar 2022, and may extend into periods thereafter.

[0000936395-21-000054:mdna:76]
•Gross profit on products as a percentage of product revenue increased by $46.3 million. Gross profit on products as a percentage of product revenue (“product gross margin”) increased by 130 basis points, primarily due to product cost reductions and a $4.3 million benefit from the CEWS program, partially offset by market-based price compression we encountered during the period as mentioned above.

[0000936395-21-000054:mdna:77]
•Gross profit on services as a percentage of services revenue increased by $22.8 million. Gross profit on services as a percentage of service revenue (“service gross margin) decreased by 190 basis points, primarily due to lower installation and deployment margins. The lower margins on installation and deployment services were primarily due to certain customer site readiness delays that caused cost inefficiencies. Lower service margins were also driven by higher compensation costs associated with our annual cash incentive compensation plan. These lower margins were partially offset by a $2.7 million benefit from the CEWS program.

[0000936395-21-000054:mdna:78]
Operating Expense

[0000936395-21-000054:mdna:79]
Currency Fluctuations

[0000936395-21-000054:mdna:80]
During fiscal 2021, approximately 49.4% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, Indian Rupees, British Pounds and Euros. During fiscal 2021 as compared to fiscal 2020, the U.S. Dollar primarily weakened against these and other currencies. Consequently, our operating expense reported in U.S. Dollars increased by approximately $15.1 million, or 1.2%, net of hedging.

[0000936395-21-000054:mdna:81]
CEWS Program Benefits

[0000936395-21-000054:mdna:82]
In fiscal 2021, we recorded CEWS benefits of $34.3 million, net of certain fees, related to the particular line item within operating expense in our Consolidated Statement of Operations to which the grant activity related. For further information relating to our receipt of amounts under the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:83]
Operating expense increased in fiscal 2021 from the level reported for fiscal 2020 primarily due to an increase in certain variable compensation costs associated with our annual cash incentive compensation plan, offset by decreases in travel and

[0000936395-21-000054:mdna:84]
entertainment costs as a result of the impact of COVID-19. We expect operating expense to continue to increase from the level reported in fiscal 2021 primarily due to planned investment in research and development to advance our strategy and our expectation that customer engagement and related travel and entertainment costs will begin to normalize.

[0000936395-21-000054:mdna:85]
Operating expense consists of the component elements described below.

[0000936395-21-000054:mdna:86]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-21-000054:mdna:87]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-21-000054:mdna:88]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-21-000054:mdna:89]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-21-000054:mdna:90]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-21-000054:mdna:91]
•Acquisition and integration costs primarily consist of employee-related costs associated with a three-year earn-out arrangement related to the acquisition of DonRiver Holdings, LLC (“DonRiver”) in fiscal 2018 and other fees related to the acquisition of Centina Systems, Inc. (“Centina”) in fiscal 2020.

[0000936395-21-000054:mdna:92]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-21-000054:mdna:93]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 536,666 |  |  | 14.8 |  | $ | 529,888 |  |  | 15.0 |  | $ | 6,778 |  |  | 1.3 |
| Selling and marketing | 452,214 |  |  | 12.5 |  | 416,425 |  |  | 11.8 |  | 35,789 |  |  | 8.6 |
| General and administrative | 181,874 |  |  | 5.0 |  | 169,548 |  |  | 4.8 |  | 12,326 |  |  | 7.3 |
| Significant asset impairments and restructuring costs | 29,565 |  |  | 0.8 |  | 22,652 |  |  | 0.6 |  | 6,913 |  |  | 30.5 |
| Amortization of intangible assets | 23,732 |  |  | 0.7 |  | 23,383 |  |  | 0.7 |  | 349 |  |  | 1.5 |
| Acquisition and integration costs | 2,572 |  |  | 0.1 |  | 4,031 |  |  | 0.1 |  | (1,459) |  |  | (36.2) |
| Total operating expenses | $ | 1,226,623 |  |  | 33.9 |  | $ | 1,165,927 |  |  | 33.0 |  | $ | 60,696 |  |  | 5.2 |

[0000936395-21-000054:mdna:94]
_________________________________

[0000936395-21-000054:mdna:95]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:96]
•Research and development expense was adversely affected by $6.7 million as a result of foreign exchange rates, net of hedging, primarily due to the weakening of the U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expense increased by $6.8 million. This increase primarily reflects an increase in employee and compensation costs associated with higher headcount, and our annual cash incentive compensation plan, partially offset by $29.5 million received from the CEWS program and a decrease in professional services.

[0000936395-21-000054:mdna:97]
•Selling and marketing expense was adversely affected by $6.8 million as a result of foreign exchange rates, primarily due to the weakening of the U.S. Dollar in relation to the Canadian Dollar and Euro. Including the effect of foreign exchange rates, sales and marketing expense increased by $35.8 million. This increase primarily reflects an increase in employee and compensation costs associated with higher sales commissions, partially offset by decreases in travel and entertainment costs as a result of COVID-19.

[0000936395-21-000054:mdna:98]
•General and administrative expense was adversely affected by $1.6 million as a result of foreign exchange rates, primarily due to the weakening of the U.S. Dollar in relation to the Canadian Dollar and Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $12.3 million. This increase primarily reflects an increase in employee and compensation costs associated with our annual cash incentive compensation plan and legal fees, partially offset by reduced bad debt expense.

[0000936395-21-000054:mdna:99]
•Significant asset impairments and restructuring costs reflect actions that we have taken to redesign certain business processes and align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-21-000054:mdna:100]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-21-000054:mdna:101]
•Acquisition and integration costs primarily reflect acquisition compensation associated with a three-year earn-out arrangement related to the acquisition of DonRiver in fiscal 2018 and other fees related to the acquisition of Centina in fiscal 2020.

[0000936395-21-000054:mdna:102]
Other Items

[0000936395-21-000054:mdna:103]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-21-000054:mdna:104]
|  | Fiscal Year |  |  |  |  |
|  | 2021 |  | %* |  | 2020 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | (1,768) |  |  | — |  | $ | 964 |  |  | — |  | $ | (2,732) |  |  | (283.4) |
| Interest expense | $ | 30,837 |  |  | 0.9 |  | $ | 31,321 |  |  | 0.9 |  | $ | (484) |  |  | (1.5) |
| Loss on extinguishment/modification of debt | $ | — |  |  | — |  | $ | (646) |  |  | — |  | $ | (646) |  |  | 100.0 |
| Provision (benefit) for income taxes | $ | (37,445) |  |  | (1.0) |  | $ | 94,670 |  |  | 2.7 |  | $ | (132,115) |  |  | (139.6) |

[0000936395-21-000054:mdna:105]
_________________________________

[0000936395-21-000054:mdna:106]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:107]
•Interest and other income (loss), net decreased, primarily reflecting lower interest income due to reduced interest rates on our investments, partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-21-000054:mdna:108]
•Interest expense remained relatively unchanged.

[0000936395-21-000054:mdna:109]
•Loss on extinguishment and modification of debt reflects the refinance of our 2025 Term Loan. See Note 19 to our Consolidated Financial Statements in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:110]
•Provision (benefit) for income taxes decreased, primarily due to the $119.3 million tax benefit associated with recording a deferred tax asset for fiscal 2021. The effective tax rate for fiscal 2021 was lower as compared to fiscal 2020, primarily due to the tax benefit associated with recording a deferred tax asset. For further discussion, see Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:111]
Segment Profit (Loss)

[0000936395-21-000054:mdna:112]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-21-000054:mdna:113]
|  | Fiscal Year |  |  |
|  | 2021 |  | 2020 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 850,901 |  |  | $ | 827,105 |  |  | $ | 23,796 |  |  | 2.9 |
| Platform Software and Services | $ | 136,602 |  |  | $ | 105,609 |  |  | $ | 30,993 |  |  | 29.3 |
| Blue Planet Automation Software and Services | $ | (711) |  |  | $ | (12,446) |  |  | $ | 11,735 |  |  | (94.3) |
| Global Services | $ | 198,521 |  |  | $ | 202,735 |  |  | $ | (4,214) |  |  | (2.1) |

[0000936395-21-000054:mdna:114]
_________________________________

[0000936395-21-000054:mdna:115]
| * | Denotes % change from 2020 to 2021 |

[0000936395-21-000054:mdna:116]
Segment profit (loss) includes CEWS benefits of $36.5 million in fiscal 2021, net of certain fees. For further discussion of benefits from the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-21-000054:mdna:117]
•Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, higher gross margin and a CEWS benefit of $30.4 million, offset by higher research and development costs.

[0000936395-21-000054:mdna:118]
•Platform Software and Services segment profit increased, primarily due to higher sales volume, as described above, higher gross margin, and lower research and development costs which benefited from a CEWS benefit of $2.6 million.

[0000936395-21-000054:mdna:119]
•Blue Planet Automation Software and Services segment loss decreased, primarily due to higher sales volume, as described above, higher gross margin on software revenue and lower research and development costs which partially benefited from a CEWS benefit of $1.2 million, partially offset by lower gross margin on software-related services.

[0000936395-21-000054:mdna:120]
•Global Services segment profit decreased, primarily due to lower gross margin, partially offset by higher sales volume, as described above and lower research and development costs which benefited from a CEWS benefit of $2.3 million.

[0000936395-21-000054:mdna:121]
Liquidity and Capital Resources

[0000936395-21-000054:mdna:122]
Overview. For the fiscal year ended October 30, 2021, we generated $541.6 million of cash from operations, as our net income (adjusted for non-cash charges) of $609.8 million exceeded our working capital requirements of $68.2 million. For additional details on our cash provided by operating activities, see the discussion below under the caption “Cash Provided By Operating Activities.”

[0000936395-21-000054:mdna:123]
Cash, cash equivalents and investments increased by $352.6 million during fiscal 2021. The cash from operations above was partially offset by the following: (i) cash used to fund our investing activities for capital expenditures totaling $79.6 million; (ii) cash used for stock repurchase under our stock repurchase program of $91.3 million; (iii) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $44.1 million; and (iv) cash used for payments on our term loan due September 28, 2025 (the “2025 Term Loan”) of $6.9 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $28.5 million in cash during fiscal 2021.

[0000936395-21-000054:mdna:124]
See Notes 19 and 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-21-000054:mdna:125]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-21-000054:mdna:126]
|  | October 30, 2021 |  | October 31, 2020 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 1,422,546 |  |  | $ | 1,088,624 |  |  | $ | 333,922 |  |
| Short-term investments in marketable debt securities | 181,483 |  |  | 150,667 |  |  | 30,816 |  |
| Long-term investments in marketable debt securities | 70,038 |  |  | 82,226 |  |  | (12,188) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,674,067 |  |  | $ | 1,321,517 |  |  | $ | 352,550 |  |

[0000936395-21-000054:mdna:127]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash and investments, which as of October 30, 2021 totaled $1.67 billion, as well as the senior secured asset-based revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility, which we and certain of our subsidiaries entered into on October 28, 2019, replaced a predecessor senior secured asset-based revolving credit facility and provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 30, 2021, letters of credit totaling $87.4 million were outstanding under our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 30, 2021.

[0000936395-21-000054:mdna:128]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $432.3 million as of October 30, 2021. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign

[0000936395-21-000054:mdna:129]
withholding taxes would be approximately $32.0 million. See Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:130]
Stock Repurchase Authorization. On December 13, 2018, we announced that our Board of Directors authorized a program to repurchase up to $500 million of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. We repurchased $92.1 million under this program during fiscal 2021. We did not repurchase any shares of our common stock under this program after October 30, 2021. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement for the repurchase of $250.0 million of our common stock. The amount and timing of the remaining repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 28 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:131]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. Any potential further economic or market impact of the COVID-19 pandemic remains uncertain, and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-21-000054:mdna:132]
Cash Provided by Operating Activities

[0000936395-21-000054:mdna:133]
The following sections set forth the components of our $541.6 million of cash provided by operating activities for fiscal 2021:

[0000936395-21-000054:mdna:134]
Net Income (adjusted for non-cash charges)

[0000936395-21-000054:mdna:135]
The following table sets forth our net income (adjusted for non-cash charges) during fiscal 2021 (in thousands):

[0000936395-21-000054:mdna:136]
|  | Year Ended |
|  | October 30, 2021 |
| Net income | $ | 500,196 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 96,233 |  |
| Share-based compensation costs | 84,336 |  |
| Amortization of intangible assets | 36,033 |  |
| Deferred taxes | (156,469) |  |
| Provision for inventory excess and obsolescence | 17,850 |  |
| Provision for warranty | 17,093 |  |
| Other | 14,525 |  |
| Net income (adjusted for non-cash charges) | $ | 609,797 |  |

[0000936395-21-000054:mdna:137]
Working Capital

[0000936395-21-000054:mdna:138]
We used $68.2 million of cash for working capital during fiscal 2021. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-21-000054:mdna:139]
|  | Year Ended |
|  | October 30, 2021 |
| Cash used in accounts receivable | $ | (174,377) |  |
| Cash used in inventories | (47,567) |  |
| Cash used in prepaid expenses and other | (19,691) |  |
| Cash provided by accounts payable, accruals and other obligations | 162,134 |  |
| Cash provided by deferred revenue | 16,822 |  |
| Cash used in operating lease assets and liabilities, net | (5,472) |  |
| Total cash used for working capital | $ | (68,151) |  |

[0000936395-21-000054:mdna:140]
As compared to the end of fiscal 2020:

[0000936395-21-000054:mdna:141]
•The $174.4 million of cash used in accounts receivable during fiscal 2021 reflects increased sales volume at the end of the fourth quarter of fiscal 2021;

[0000936395-21-000054:mdna:142]
•The $47.6 million of cash used in inventory during fiscal 2021 primarily reflects increases in raw materials inventory related to the steps we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-21-000054:mdna:143]
•The $19.7 million of cash used in prepaid expenses and other during fiscal 2021 primarily reflects increases in contract assets for unbilled accounts receivable, capitalized commissions and foreign currency forward contracts, partially offset by decreases in upfront future discounts paid to customers and product demonstration equipment;

[0000936395-21-000054:mdna:144]
•The $162.1 million of cash provided by accounts payable, accruals and other obligations during fiscal 2021 primarily reflects higher provisions under our annual cash incentive compensation plan, and increased income taxes payable;

[0000936395-21-000054:mdna:145]
•The $16.8 million of cash provided by deferred revenue during fiscal 2021 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-21-000054:mdna:146]
•The $5.5 million of cash used in operating lease assets and liabilities, net, during fiscal 2021 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 18 to our Consolidated Financial Statements in Item 8 of Part II of this report.

[0000936395-21-000054:mdna:147]
Our days sales outstanding (“DSOs”) were 98 for fiscal 2021 as compared to 82 for fiscal 2020. Our inventory turns decreased from 4.6 turns during fiscal 2020 to 4.1 turns during fiscal 2021 due to the increase in inventory. The calculation of DSOs includes accounts receivable, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-21-000054:mdna:148]
Cash Paid for Interest

[0000936395-21-000054:mdna:149]
The following table sets forth the cash paid for interest during fiscal 2021 (in thousands):

[0000936395-21-000054:mdna:150]
|  | Year Ended |
|  | October 30, 2021 |
| Term Loan due September 28, 2025(1) | $ | 12,960 |  |
| Interest rate swaps(2) | 10,087 |  |
| ABL Credit Facilities(3) | 1,935 |  |
| Finance leases | 4,882 |  |
| Cash paid during period | $ | 29,864 |  |

[0000936395-21-000054:mdna:151]
(1) Interest on the New 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The New 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of fiscal 2021, the interest rate on the New 2025 Term Loan was 1.84%.

[0000936395-21-000054:mdna:152]
(2) The interest rate swaps fix the LIBOR rate for $350.0 million of the New 2025 Term Loan at 2.957% through September 2023.

[0000936395-21-000054:mdna:153]
(3) During fiscal 2021, we utilized the ABL Credit Facility and its predecessor to collateralize certain standby letters of credit and paid $1.9 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-21-000054:mdna:154]
For additional information about our term loans, ABL Credit Facility and interest rate swaps, see Notes 16, 19 and 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-21-000054:mdna:155]
Contractual Obligations

[0000936395-21-000054:mdna:156]
Debt. As of October 30, 2021, we had $6.9 million outstanding principal associated with our 2025 Term Loan payable within 12 months. Interest on the 2025 Term Loan and payments due under the interest rate swaps is variable and is calculated using the rate in effect on the balance sheet date. Future interest payments associated with the 2025 Term Loan Notes total $49.0 million, with $12.6 million payable within 12 months. Future interest payments associated with the interest rate swaps total $19.5 million, with $10.2 million payable within 12 months. For additional information about our term loan and the interest rate swaps, see Notes 16 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-21-000054:mdna:157]
Purchase Order Obligations. As of October 30, 2021, we had $430.7 million in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0000936395-21-000054:mdna:158]
Leases. We have lease arrangements for facilities including research and development centers, engineering facilities and smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. As of October 30, 2021, we had fixed lease payment obligations of $160.2 million, with $28.2 million payable within 12 months. See Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-21-000054:mdna:159]
Off-Balance Sheet Arrangements

[0000936395-21-000054:mdna:160]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-21-000054:mdna:161]
Critical Accounting Policies and Estimates

[0000936395-21-000054:mdna:162]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of our estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-21-000054:mdna:163]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-21-000054:mdna:164]
Revenue Recognition

[0000936395-21-000054:mdna:165]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when

[0000936395-21-000054:mdna:166]
we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-21-000054:mdna:167]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-21-000054:mdna:168]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-21-000054:mdna:169]
Our total deferred revenue for products was $12.9 million and $17.5 million as of October 30, 2021 and October 31, 2020, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $162.6 million and $140.8 million as of October 30, 2021 and October 31, 2020, respectively.

[0000936395-21-000054:mdna:170]
Business Combinations

[0000936395-21-000054:mdna:171]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur that may affect the accuracy or validity of such estimates. During fiscal 2020, we completed the Centina acquisition for a purchase price of $34.0 million. See Note 4 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for more information regarding this transaction.

[0000936395-21-000054:mdna:172]
Share-Based Compensation

[0000936395-21-000054:mdna:173]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-21-000054:mdna:174]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 24 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this

[0000936395-21-000054:mdna:175]
report. As of October 30, 2021, total unrecognized compensation expense was $143.3 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.51 years.

[0000936395-21-000054:mdna:176]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-21-000054:mdna:177]
Reserve for Inventory Obsolescence

[0000936395-21-000054:mdna:178]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-21-000054:mdna:179]
We recorded charges for excess and obsolete inventory of $17.9 million, $24.7 million and $28.1 million in fiscal 2021, 2020 and 2019, respectively. Our inventory, net of allowance for excess and obsolescence, was $374.3 million and $344.4 million as of October 30, 2021 and October 31, 2020, respectively.

[0000936395-21-000054:mdna:180]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-21-000054:mdna:181]
We estimate our allowances for credit losses using relevant available information from internal and external sources. This information is related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-21-000054:mdna:182]
Probability of default rates is published by third-party credit rating agencies. Adjustments to our exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-21-000054:mdna:183]
Our accounts receivable, net of allowance for credit losses, was $885.0 million and $719.4 million as of October 30, 2021 and October 31, 2020, respectively. Our allowance for credit losses was $10.9 million and $10.6 million as of October 30, 2021 and October 31, 2020, respectively.

[0000936395-21-000054:mdna:184]
Our contract assets for unbilled accounts receivable, net of allowance for credit losses, was $101.4 million and $85.8 million as of October 30, 2021 and October 31, 2020, respectively. Our allowance for credit losses was $0.1 million as of October 30, 2021. There was no allowance for credit losses as of October 31, 2020.

[0000936395-21-000054:mdna:185]
Goodwill

[0000936395-21-000054:mdna:186]
Our goodwill was generated from the acquisitions of (i) Cyan during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion during fiscal 2016, (iii) Packet Design on July 2, 2018, (iv) DonRiver on October 1, 2018, and (v) Centina on November 2, 2019. The goodwill from these acquisitions is primarily related to expected economic synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-21-000054:mdna:187]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test

[0000936395-21-000054:mdna:188]
indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 30, 2021 and October 31, 2020, the goodwill balance was $311.6 million and $310.8 million, respectively. There were no goodwill impairments resulting from our fiscal 2021 and 2020 impairment tests and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-21-000054:mdna:189]
Long-lived Assets

[0000936395-21-000054:mdna:190]
Our long-lived assets include equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets and maintenance spares. As of October 30, 2021 and October 31, 2020 these assets totaled $450.3 million and $488.1 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-21-000054:mdna:191]
Deferred Tax Assets

[0000936395-21-000054:mdna:192]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-21-000054:mdna:193]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The valuation allowance balances at October 30, 2021 and October 31, 2020 were $159.6 million and $151.4 million, respectively. The corresponding net deferred tax assets were $800.2 million and $647.8 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy.

[0000936395-21-000054:mdna:194]
During fiscal 2021, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. The recognition of the deferred tax asset from the internal transfer of the non-U.S. intangible assets requires management to make estimates and assumptions to determine the fair value of the intangible assets transferred and significant judgments in evaluating the application of tax laws in the applicable jurisdictions, including where the deferred tax asset will be recovered. Estimates in valuing the intangible assets include, but are not limited to, internal revenue and expense forecasts, the estimated life of the intangible assets, and discount rates, which are affected by expectations about future market or economic conditions. Although we believe the assumptions and estimates that we have made are reasonable and appropriate, they are based, in part, on historical experience and are inherently uncertain.

[0000936395-21-000054:mdna:195]
For further discussion, see Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-21-000054:mdna:196]
Warranty

[0000936395-21-000054:mdna:197]
Our liability for product warranties, included in accrued liabilities and other short-term obligations, was $48.0 million and $49.9 million as of October 30, 2021 and October 31, 2020, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support customer repairs within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $17.1 million, $22.4

[0000936395-21-000054:mdna:198]
million and $23.1 million for fiscal 2021, 2020 and 2019, respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 15 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-21-000054:mdna:199]
Effects of Recent Accounting Pronouncements

[0000936395-21-000054:mdna:200]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-21-000054:mdna:201]
63
