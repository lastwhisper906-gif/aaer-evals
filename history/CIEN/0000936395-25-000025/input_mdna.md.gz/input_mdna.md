# CIEN MD&A — 0000936395-25-000025


## mdna

[0000936395-25-000025:mdna:1]
[same as prior period, unchanged from 0000936395-25-000011:mdna:1]

[0000936395-25-000025:mdna:2]
[same as prior period, unchanged from 0000936395-25-000011:mdna:2]

[0000936395-25-000025:mdna:3]
[same as prior period, unchanged from 0000936395-25-000011:mdna:3]

[0000936395-25-000025:mdna:4]
[same as prior period, unchanged from 0000936395-25-000011:mdna:4]

[0000936395-25-000025:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations is designed to provide an understanding of our financial condition, results of operations, and cash flows, and it should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and in Item 8 of Part II of our 2024 Annual Report.

[0000936395-25-000025:mdna:6]
We are a network technology company, providing hardware, software, and services to a wide range of network operators and enabling enhanced network capacity, service delivery, and automation. Our solutions support network traffic across a wide range of applications, including cloud, video, data, artificial intelligence (“AI”), and voice. Our network solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network™, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by network analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking portfolio and our Routing and Switching portfolio, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, to increase transmission speeds, to allocate traffic efficiently, and to adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator Network Control Software (NCS) and advanced applications that deliver multi-layer domain control and operations for network operators. Through our Blue Planet Automation Software, we also enable complete service lifecycle management automation with productized operational support systems, including inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-25-000025:mdna:7]
25

[0000936395-25-000025:mdna:8]
[same as prior period, unchanged from 0000936395-25-000011:mdna:7]

[0000936395-25-000025:mdna:9]
The market into which we sell our communications networking solutions is dynamic and is characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services, and new approaches, or “consumption models,” for designing and procuring networking solutions. Drivers of increased bandwidth demand include enterprise and consumer cloud network adoption, AI, 5G, high-definition video, and network operator focus on resilience and automation. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation.

[0000936395-25-000025:mdna:10]
We believe that our investment capacity and our efforts to push the pace of innovation are important competitive differentiators in our markets. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures, and research and development spending represented 18.5% of our revenue in the first half of fiscal 2025. During the first half of fiscal 2025, we invested $407.5 million in research and development activities, an increase of 6.5% compared to the first half of fiscal 2024. In particular, in an effort to capture certain market opportunities created by the impact of AI on networks, we have continued to innovate, increase the performance of, and enhance the capabilities for our leading WaveLogicTM coherent modem technology in multiple form factors. Through this innovation, we seek to extend our leadership in our core business and leverage this to expand our addressable market into complementary and adjacent network applications, including inside and around the data center.

[0000936395-25-000025:mdna:11]
[same as prior period, unchanged from 0000936395-25-000011:mdna:11]

[0000936395-25-000025:mdna:12]
During the second quarter of fiscal 2025, we continued to experience broad-based business momentum, with orders for our products and services exceeding our revenue, resulting in increased backlog. We experienced year-over-year order growth in our major customer segments, particularly with large communications service provider customers and cloud provider customers, with one cloud provider customer continuing to provide a significant volume of orders. As a result, our revenue increased by 23.6% to $1.1 billion in the second quarter of fiscal 2025 as compared to $910.8 million in the second quarter of fiscal 2024. Three of our top five customers by revenue for the second quarter of fiscal 2025 were cloud providers. Although our business remains subject to quarterly fluctuations due to customer purchasing patterns and supply chain dynamics, we continue to believe that certain trends and shifts in business and consumer behaviors and the drivers of bandwidth demand described above under the heading “Overview - Market Opportunity and Investment in Technology Innovation” in this Item 2 represent long-term opportunities for our business.

[0000936395-25-000025:mdna:13]
[same as prior period, unchanged from 0000936395-25-000011:mdna:13]

[0000936395-25-000025:mdna:14]
[same as prior period, unchanged from 0000936395-25-000011:mdna:14]

[0000936395-25-000025:mdna:15]
[same as prior period, unchanged from 0000936395-25-000011:mdna:15]

[0000936395-25-000025:mdna:16]
[same as prior period, unchanged from 0000936395-25-000011:mdna:16]

[0000936395-25-000025:mdna:17]
[same as prior period, unchanged from 0000936395-25-000011:mdna:17]

[0000936395-25-000025:mdna:18]
Our revenue increased by 23.6%, or $215.1 million in the second quarter of fiscal 2025 as compared to the second quarter of fiscal 2024, and 12.8%, or $249.6 million in the first six months of fiscal 2025 as compared to the first six months of fiscal 2024.

[0000936395-25-000025:mdna:19]
[same as prior period, unchanged from 0000936395-25-000011:mdna:19]

[0000936395-25-000025:mdna:20]
[same as prior period, unchanged from 0000936395-25-000011:mdna:20]

[0000936395-25-000025:mdna:21]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | 560,224 |  |  |  |  | 38.1 | % |  | $ | 1,501,566 |  |  | $ | 1,256,072 |  |  |  |  | 19.5 | % |
| %** | 68.7 | % |  | 61.5 | % |  |  |  |  |  | 68.3 | % |  | 64.4 | % |  |  |  |  |
| Routing and Switching | 92,723 |  |  | 116,034 |  |  |  |  | (20.1) | % |  | 185,892 |  |  | 227,421 |  |  |  |  | (18.3) | % |
| %** | 8.2 | % |  | 12.7 | % |  |  |  |  |  | 8.5 | % |  | 11.7 | % |  |  |  |  |
| Total Networking Platforms | 866,315 |  |  | 676,258 |  |  |  |  | 28.1 | % |  | 1,687,458 |  |  | 1,483,493 |  |  |  |  | 13.7 | % |
| %** | 76.9 | % |  | 74.2 | % |  |  |  |  |  | 76.8 | % |  | 76.1 | % |  |  |  |  |
| Platform Software and Services | 85,441 |  |  | 85,445 |  |  |  |  | — | % |  | 180,508 |  |  | 175,190 |  |  |  |  | 3.0 | % |
| %** | 7.5 | % |  | 9.4 | % |  |  |  |  |  | 8.2 | % |  | 9.0 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 27,951 |  |  | 14,434 |  |  |  |  | 93.6 | % |  | 53,982 |  |  | 28,376 |  |  |  |  | 90.2 | % |
| %** | 2.5 | % |  | 1.6 | % |  |  |  |  |  | 2.5 | % |  | 1.5 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 79,442 |  |  | 77,410 |  |  |  |  | 2.6 | % |  | 154,014 |  |  | 151,525 |  |  |  |  | 1.6 | % |
| %** | 7.1 | % |  | 8.5 | % |  |  |  |  |  | 7.0 | % |  | 7.8 | % |  |  |  |  |
| Installation and Deployment | 58,174 |  |  | 43,785 |  |  |  |  | 32.9 | % |  | 105,857 |  |  | 86,509 |  |  |  |  | 22.4 | % |
| %** | 5.2 | % |  | 4.8 | % |  |  |  |  |  | 4.8 | % |  | 4.4 | % |  |  |  |  |
| Consulting and Network Design | 8,555 |  |  | 13,494 |  |  |  |  | (36.6) | % |  | 16,319 |  |  | 23,442 |  |  |  |  | (30.4) | % |
| %** | 0.8 | % |  | 1.5 | % |  |  |  |  |  | 0.7 | % |  | 1.2 | % |  |  |  |  |
| Total Global Services | 146,171 |  |  | 134,689 |  |  |  |  | 8.5 | % |  | 276,190 |  |  | 261,476 |  |  |  |  | 5.6 | % |
| %** | 13.1 | % |  | 14.8 | % |  |  |  |  |  | 12.5 | % |  | 13.4 | % |  |  |  |  |
| Total revenue | $ | 1,125,878 |  |  | $ | 910,826 |  |  |  |  | 23.6 | % |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |  |  |  | 12.8 | % |

[0000936395-25-000025:mdna:22]
[same as prior period, unchanged from 0000936395-25-000011:mdna:22]

[0000936395-25-000025:mdna:23]
[same as prior period, unchanged from 0000936395-25-000011:mdna:23]

[0000936395-25-000025:mdna:24]
[same as prior period, unchanged from 0000936395-25-000011:mdna:24]

[0000936395-25-000025:mdna:25]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:26]
•Networking Platforms segment revenue increased by $190.1 million.

[0000936395-25-000025:mdna:27]
•Optical Networking products revenue increased by $213.4 million, primarily driven by increases in sales of our  6500 Reconfigurable Line Systems (“RLS”), our Waveserver® system, and our coherent pluggables, each primarily to cloud provider customers, and our 6500 Packet-Optical Platform primarily to communications service providers.

[0000936395-25-000025:mdna:28]
•Routing and Switching products revenue decreased by $23.3 million, primarily driven by decreases in sales of our 3000 and 5000 series of service delivery and aggregation platforms.

[0000936395-25-000025:mdna:29]
•Platform Software and Services segment revenue remained relatively unchanged.

[0000936395-25-000025:mdna:30]
•Blue Planet Automation Software and Services segment revenue increased by $13.5 million, primarily reflecting sales increases in our unified assurance and analytics software and software services and inventory management software services.

[0000936395-25-000025:mdna:31]
•Global Services segment revenue increased by $11.5 million, primarily reflecting a sales increase in our installation and deployment and support services, partially offset by a sales decrease in our consulting and network design services.

[0000936395-25-000025:mdna:32]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:33]
•Networking Platforms segment revenue increased by $204.0 million.

[0000936395-25-000025:mdna:34]
•Optical Networking sales increased by $245.5 million, primarily driven by increases in sales of our 6500 RLS and our coherent pluggables, both primarily to cloud provider customers, and our 6500 Packet-Optical Platforms, primarily to service provider customers. These increases were partially offset by a reduction in Waveserver revenue, primarily related to decreased sales to cloud provider customers.

[0000936395-25-000025:mdna:35]
•Routing and Switching sales decreased by $41.5 million, primarily driven by decreases in sales of our 3000 and 5000 series of service delivery and aggregation platforms, partially offset by an increase in sales of our virtualization software.

[0000936395-25-000025:mdna:36]
•Platform Software and Services segment revenue increased by $5.3 million, primarily reflecting sales increases of our software consulting services and our software maintenance services, partially offset by sales decreases of our software platforms.

[0000936395-25-000025:mdna:37]
•Blue Planet Automation Software and Services segment revenue increased by $25.6 million, primarily reflecting sales increases in our unified assurance and analytics software and software services and inventory management software services.

[0000936395-25-000025:mdna:38]
•Global Services segment revenue increased by $14.7 million, primarily reflecting a sales increase in our installation and deployment and support services, partially offset by a sales decrease in our consulting and network design services.

[0000936395-25-000025:mdna:39]
[same as prior period, unchanged from 0000936395-25-000011:mdna:32]

[0000936395-25-000025:mdna:40]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in variations in geographic revenue results in any particular period.

[0000936395-25-000025:mdna:41]
[same as prior period, unchanged from 0000936395-25-000011:mdna:34]

[0000936395-25-000025:mdna:42]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Americas | $ | 833,822 |  |  | $ | 662,877 |  |  |  |  | 25.8 | % |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |  |  |  | 18.0 | % |
| %** | 74.1 | % |  | 72.8 | % |  |  |  |  |  | 74.1 | % |  | 70.9 | % |  |  |  |  |
| EMEA | 191,585 |  |  | 155,791 |  |  |  |  | 23.0 | % |  | 349,501 |  |  | 363,203 |  |  |  |  | (3.8) | % |
| %** | 17.0 | % |  | 17.1 | % |  |  |  |  |  | 15.9 | % |  | 18.6 | % |  |  |  |  |
| APAC | 100,471 |  |  | 92,158 |  |  |  |  | 9.0 | % |  | 219,183 |  |  | 204,257 |  |  |  |  | 7.3 | % |
| %** | 8.9 | % |  | 10.1 | % |  |  |  |  |  | 10.0 | % |  | 10.5 | % |  |  |  |  |
| Total | $ | 1,125,878 |  |  | $ | 910,826 |  |  |  |  | 23.6 | % |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |  |  |  | 12.8 | % |

[0000936395-25-000025:mdna:43]
[same as prior period, unchanged from 0000936395-25-000011:mdna:36]

[0000936395-25-000025:mdna:44]
[same as prior period, unchanged from 0000936395-25-000011:mdna:37]

[0000936395-25-000025:mdna:45]
[same as prior period, unchanged from 0000936395-25-000011:mdna:38]

[0000936395-25-000025:mdna:46]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:47]
•Americas revenue increased by $171.0 million, primarily driven by increased sales to cloud providers, partially offset by decreased sales to government customers, each primarily in the United States.

[0000936395-25-000025:mdna:48]
•EMEA revenue increased by $35.8 million, primarily driven by increased sales to cloud providers in the Netherlands.

[0000936395-25-000025:mdna:49]
•APAC revenue increased by $8.3 million, primarily driven by increased sales to communications service providers in Japan.

[0000936395-25-000025:mdna:50]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:51]
•Americas revenue increased by $248.4 million, primarily driven by increased sales to cloud providers and communications service providers, partially offset by decreased sales to government customers and cable and multiservice operators, each primarily in the United States.

[0000936395-25-000025:mdna:52]
•EMEA revenue decreased by $13.7 million, primarily driven by decreased sales to submarine network operators.

[0000936395-25-000025:mdna:53]
•APAC revenue increased by $14.9 million, primarily driven by increased sales to communications service providers in India and Japan.

[0000936395-25-000025:mdna:54]
[same as prior period, unchanged from 0000936395-25-000011:mdna:43]

[0000936395-25-000025:mdna:55]
During the second quarter and first six months of fiscal 2025, approximately 13.1% and 14.2% of our revenue was non-U.S. Dollar-denominated, respectively. During the second quarter and first six months of fiscal 2025 as compared to the second quarter and first six months of fiscal 2024, the U.S. Dollar generally strengthened against other currencies. These currency fluctuations had an adverse effect on our revenue reported in U.S. Dollars of approximately $3.0 million, or 0.3%, as compared to the second quarter of fiscal 2024, and $9.5 million, or 0.4%, as compared to the first six months of fiscal 2024.

[0000936395-25-000025:mdna:56]
[same as prior period, unchanged from 0000936395-25-000011:mdna:45]

[0000936395-25-000025:mdna:57]
There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. For example, early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonic line systems, and installation services, with the intent to improve margin as we sell channel cards, advanced software, and maintenance services to customers as they add capacity. In addition, products that are in early or introductory phases may carry lower margins. The component elements that comprise our product cost of goods sold and services cost of goods sold, and certain factors that can cause gross margin to fluctuate, are described in detail in the “Consolidated Results of Operations - Cost of Goods Sold and Gross Profit” in Item 7 of Part II and “Risk Factors” in Item 1A of Part I of our 2024 Annual Report.

[0000936395-25-000025:mdna:58]
[same as prior period, unchanged from 0000936395-25-000011:mdna:47]

[0000936395-25-000025:mdna:59]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Total revenue | $ | 1,125,878 |  |  | $ | 910,826 |  |  |  |  | 23.6 | % |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |  |  |  | 12.8 | % |
| Total cost of goods sold | 673,040 |  |  | 522,165 |  |  |  |  | 28.9 | % |  | 1,273,479 |  |  | 1,092,912 |  |  |  |  | 16.5 | % |
| Gross profit | $ | 452,838 |  |  | $ | 388,661 |  |  |  |  | 16.5 | % |  | $ | 924,659 |  |  | $ | 855,623 |  |  |  |  | 8.1 | % |
| %** | 40.2 | % |  | 42.7 | % |  |  |  |  |  | 42.1 | % |  | 43.9 | % |  |  |  |  |

[0000936395-25-000025:mdna:60]
[same as prior period, unchanged from 0000936395-25-000011:mdna:49]

[0000936395-25-000025:mdna:61]
[same as prior period, unchanged from 0000936395-25-000011:mdna:50]

[0000936395-25-000025:mdna:62]
[same as prior period, unchanged from 0000936395-25-000011:mdna:51]

[0000936395-25-000025:mdna:63]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:64]
•Gross profit increased by $64.2 million. Gross margin decreased by 250 basis points, primarily reflecting decreased product and services margins.

[0000936395-25-000025:mdna:65]
•Gross profit on products increased by $63.0 million from $285.6 million for the second quarter of fiscal 2024 to $348.6 million for the second quarter of fiscal 2025. Product gross margin decreased by 190 basis points, from 40.7% for the second quarter of fiscal 2024 to 38.8% for the second quarter of fiscal 2025, primarily due to product mix and the effect of tariffs, partially offset by manufacturing efficiencies.

[0000936395-25-000025:mdna:66]
•Gross profit on services increased by $1.2 million from $103.1 million for the second quarter of fiscal 2024 to $104.2 million for the second quarter of fiscal 2025. Services gross margin decreased by 330 basis points, from 49.2% for the second quarter of fiscal 2024 to 45.9% for the second quarter of fiscal 2025, primarily due to increased costs related to delivering maintenance arrangements.

[0000936395-25-000025:mdna:67]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:68]
•Gross profit increased by $69.0 million. Gross margin decreased by 180 basis points, primarily reflecting decreased product and services margin.

[0000936395-25-000025:mdna:69]
•Gross profit on products increased by $57.7 million from $654.9 million for the first six months of fiscal 2024 to $712.6 million for the first six months of fiscal 2025. Product gross margin decreased by 200 basis points, from 42.6% for the first six months of fiscal 2024 to 40.6% for the first six months of fiscal 2025, primarily due to product mix, partially offset by manufacturing efficiencies.

[0000936395-25-000025:mdna:70]
•Gross profit on services increased by $11.3 million from $200.7 million for the first six months of fiscal 2024 to $212.1 million for the first six months of fiscal 2025. Services gross margin decreased by 110 basis points, from 48.8% for the first six months of fiscal 2024 to 47.7% for the first six months of fiscal 2025, primarily due increased costs related to delivering maintenance arrangements.

[0000936395-25-000025:mdna:71]
[same as prior period, unchanged from 0000936395-25-000011:mdna:56]

[0000936395-25-000025:mdna:72]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Consolidated Results of Operations - Operating Expense” in Item 7 of Part II of our 2024 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-25-000025:mdna:73]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Research and development | $ | 214,868 |  |  | $ | 195,380 |  |  |  |  | 10.0 | % |  | $ | 407,531 |  |  | $ | 382,649 |  |  |  |  | 6.5 | % |
| %** | 19.1 | % |  | 21.5 | % |  |  |  |  |  | 18.5 | % |  | 19.6 | % |  |  |  |  |
| Selling and marketing | 139,683 |  |  | 124,071 |  |  |  |  | 12.6 | % |  | 276,187 |  |  | 252,229 |  |  |  |  | 9.5 | % |
| %** | 12.4 | % |  | 13.6 | % |  |  |  |  |  | 12.6 | % |  | 12.9 | % |  |  |  |  |
| General and administrative | 56,952 |  |  | 49,573 |  |  |  |  | 14.9 | % |  | 110,854 |  |  | 104,256 |  |  |  |  | 6.3 | % |
| %** | 5.1 | % |  | 5.4 | % |  |  |  |  |  | 5.0 | % |  | 5.4 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 1,948 |  |  | 15,655 |  |  |  |  | (87.6) | % |  | 3,492 |  |  | 20,626 |  |  |  |  | (83.1) | % |
| %** | 0.2 | % |  | 1.7 | % |  |  |  |  |  | 0.2 | % |  | 1.1 | % |  |  |  |  |
| Amortization of intangible assets | 6,545 |  |  | 7,947 |  |  |  |  | (17.6) | % |  | 13,090 |  |  | 15,199 |  |  |  |  | (13.9) | % |
| %** | 0.6 | % |  | 0.9 | % |  |  |  |  |  | 0.6 | % |  | 0.8 | % |  |  |  |  |
| Total operating expenses | $ | 419,996 |  |  | $ | 392,626 |  |  |  |  | 7.0 | % |  | $ | 811,154 |  |  | $ | 774,959 |  |  |  |  | 4.7 | % |
| %** | 37.3 | % |  | 43.1 | % |  |  |  |  |  | 36.9 | % |  | 39.8 | % |  |  |  |  |

[0000936395-25-000025:mdna:74]
[same as prior period, unchanged from 0000936395-25-000011:mdna:59]

[0000936395-25-000025:mdna:75]
[same as prior period, unchanged from 0000936395-25-000011:mdna:60]

[0000936395-25-000025:mdna:76]
[same as prior period, unchanged from 0000936395-25-000011:mdna:61]

[0000936395-25-000025:mdna:77]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:78]
•Research and development expense increased by $19.5 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, share-based compensation expense and headcount; and professional services related to design engineering, fabrication and production of application-specific integrated circuit (“ASIC”) chips.

[0000936395-25-000025:mdna:79]
•Selling and marketing expense increased by $15.6 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation.

[0000936395-25-000025:mdna:80]
•General and administrative expense increased by $7.4 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation and share-based compensation expense; and professional services.

[0000936395-25-000025:mdna:81]
•Significant asset impairments and restructuring costs decreased by $13.7 million, primarily due to a reduction in restructuring activities. For more information on our restructuring costs, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000025:mdna:82]
•Amortization of intangible assets decreased by $1.4 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-25-000025:mdna:83]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:84]
•Research and development expense increased by $24.9 million. Net of hedging, this increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation, share-based compensation expense and headcount; and professional services related to design engineering, fabrication and production of ASIC chips.

[0000936395-25-000025:mdna:85]
•Selling and marketing expense increased by $24.0 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation.

[0000936395-25-000025:mdna:86]
•General and administrative expense increased by $6.6 million. This increase primarily reflects increases in employee-related compensation costs primarily due to increases in incentive compensation and share-based compensation expense; and professional services, partially offset by lower bad debt expense.

[0000936395-25-000025:mdna:87]
•Significant asset impairments and restructuring costs decreased by $17.1 million primarily due to a reduction in restructuring activities. For more information on our restructuring costs, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000025:mdna:88]
•Amortization of intangible assets decreased by $2.1 million, primarily reflecting certain intangible assets having reached the end of their economic lives.

[0000936395-25-000025:mdna:89]
[same as prior period, unchanged from 0000936395-25-000011:mdna:68]

[0000936395-25-000025:mdna:90]
During the second quarter and first six months of fiscal 2025, approximately 49.5% and 48.5% of our operating expense was non-U.S. Dollar-denominated, respectively. During the second quarter and first six months of fiscal 2025, as compared to the second quarter and first six months of fiscal 2024, the U.S. Dollar generally strengthened against other currencies. These currency fluctuations, net of hedging, had the effect of reducing our operating expense by approximately $6.4 million, or 1.5%, as compared to the second quarter of fiscal 2024, and $11.9 million, or 1.5% as compared to the first six months of fiscal 2024.

[0000936395-25-000025:mdna:91]
[same as prior period, unchanged from 0000936395-25-000011:mdna:70]

[0000936395-25-000025:mdna:92]
[same as prior period, unchanged from 0000936395-25-000011:mdna:71]

[0000936395-25-000025:mdna:93]
[same as prior period, unchanged from 0000936395-25-000011:mdna:72]

[0000936395-25-000025:mdna:94]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 133,712 |  |  | $ | 96,566 |  |  |  |  | 38.5 | % |  | $ | 300,791 |  |  | $ | 280,341 |  |  |  |  | 7.3 | % |
| Platform Software and Services | $ | 50,423 |  |  | $ | 54,037 |  |  |  |  | (6.7) | % |  | $ | 113,548 |  |  | $ | 112,041 |  |  |  |  | 1.3 | % |
| Blue Planet Automation Software and Services | $ | 4,291 |  |  | $ | (7,763) |  |  |  |  | 155.3 | % |  | $ | 8,867 |  |  | $ | (14,832) |  |  |  |  | 159.8 | % |
| Global Services | $ | 49,544 |  |  | $ | 50,441 |  |  |  |  | (1.8) | % |  | $ | 93,922 |  |  | $ | 95,424 |  |  |  |  | (1.6) | % |

[0000936395-25-000025:mdna:95]
[same as prior period, unchanged from 0000936395-25-000011:mdna:74]

[0000936395-25-000025:mdna:96]
[same as prior period, unchanged from 0000936395-25-000011:mdna:75]

[0000936395-25-000025:mdna:97]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:98]
•Networking Platforms segment profit increased by $37.1 million, primarily due to higher sales volume, partially offset by lower product margin as described above, and higher research and development costs.

[0000936395-25-000025:mdna:99]
•Platform Software and Services segment profit decreased by $3.6 million, primarily due to lower services margin, and increased research and development costs.

[0000936395-25-000025:mdna:100]
•Blue Planet Automation Software and Services segment profit increased by $12.1 million, primarily due to higher sales volume as described above, and improved margins on products and services.

[0000936395-25-000025:mdna:101]
•Global Services segment profit slightly decreased, primarily due to reduced services margin as described above, partially offset by increased sales volume also described above.

[0000936395-25-000025:mdna:102]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:103]
•Networking Platforms segment profit increased by $20.5 million, primarily due to higher sales volume, partially offset by lower product margin as described above, and higher research and development costs.

[0000936395-25-000025:mdna:104]
•Platform Software and Services segment profit slightly increased by $1.5 million, primarily due to higher services sales volume, partially offset by lower software sales volume and increased research and development costs.

[0000936395-25-000025:mdna:105]
•Blue Planet Automation Software and Services segment profit increased by $23.7 million, primarily due to higher sales volume as described above, and improved margins on products and services.

[0000936395-25-000025:mdna:106]
•Global Services segment profit slightly decreased by $1.5 million, primarily due to reduced services margins as described above, partially offset by increased sales volume also described above.

[0000936395-25-000025:mdna:107]
[same as prior period, unchanged from 0000936395-25-000011:mdna:81]

[0000936395-25-000025:mdna:108]
[same as prior period, unchanged from 0000936395-25-000011:mdna:82]

[0000936395-25-000025:mdna:109]
|  | Quarter Ended |  |  |  |  |  | Six Months Ended |  |  |  |  |
|  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |  | May 3, 2025 |  | April 27, 2024 |  |  |  | %* |
| Interest and other income, net | $ | 7,871 |  |  | $ | 11,797 |  |  |  |  | (33.3) | % |  | $ | 19,449 |  |  | $ | 22,447 |  |  |  |  | (13.4) | % |
| %** | 0.7 | % |  | 1.3 | % |  |  |  |  |  | 0.9 | % |  | 1.2 | % |  |  |  |  |
| Interest expense | $ | 21,697 |  |  | $ | 23,861 |  |  |  |  | (9.1) | % |  | $ | 44,615 |  |  | $ | 47,637 |  |  |  |  | (6.3) | % |
| %** | 1.9 | % |  | 2.6 | % |  |  |  |  |  | 2.0 | % |  | 2.4 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | — |  |  |  |  | — | % |  | $ | 729 |  |  | $ | — |  |  |  |  | 100.0 | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Provision for income taxes | $ | 10,047 |  |  | $ | 820 |  |  |  |  | 1,125.2 | % |  | $ | 34,069 |  |  | $ | 22,776 |  |  |  |  | 49.6 | % |
| %** | 0.9 | % |  | 0.1 | % |  |  |  |  |  | 1.5 | % |  | 1.2 | % |  |  |  |  |

[0000936395-25-000025:mdna:110]
[same as prior period, unchanged from 0000936395-25-000011:mdna:84]

[0000936395-25-000025:mdna:111]
[same as prior period, unchanged from 0000936395-25-000011:mdna:85]

[0000936395-25-000025:mdna:112]
[same as prior period, unchanged from 0000936395-25-000011:mdna:86]

[0000936395-25-000025:mdna:113]
Quarter ended May 3, 2025 as compared to the quarter ended April 27, 2024

[0000936395-25-000025:mdna:114]
•Interest and other income, net decreased by $3.9 million, primarily resulting from the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-25-000025:mdna:115]
•Interest expense decreased by $2.2 million, primarily due to lower interest rates on our floating rate debt, net of hedging activity. For more information on our short-term and long-term debt, see Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000025:mdna:116]
•Provision for income taxes increased by $9.2 million, primarily due to the increase in pre-tax book income.

[0000936395-25-000025:mdna:117]
Six months ended May 3, 2025 as compared to the six months ended April 27, 2024

[0000936395-25-000025:mdna:118]
•Interest and other income, net decreased by $3.0 million, primarily resulting from lower interest income on our investments.

[0000936395-25-000025:mdna:119]
•Interest expense decreased by $3.0 million, primarily due to primarily due to lower interest rates on our floating rate debt, net of hedging activity. For more information on our short-term and long-term debt, see Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000025:mdna:120]
•Loss on extinguishment and modification of debt reflects the refinance of our 2030 Term Loan in the first quarter of fiscal 2025. See Note 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part 1 of this report for more details.

[0000936395-25-000025:mdna:121]
•Provision for income taxes increased by $11.3 million, primarily due to the increase in pre-tax book income.

[0000936395-25-000025:mdna:122]
[same as prior period, unchanged from 0000936395-25-000011:mdna:92]

[0000936395-25-000025:mdna:123]
Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility (as defined below), will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our capital structure, liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans or increase our strategic flexibility, and we will continue to consider capital raising and other market opportunities.

[0000936395-25-000025:mdna:124]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of May 3, 2025, totaled $1.3 billion, as well as the unused portion of our senior secured revolving credit facility (the “Revolving Credit Facility”), to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of May 3, 2025, letters of credit totaling $64.3 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of May 3, 2025.

[0000936395-25-000025:mdna:125]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $166.7 million as of May 3, 2025. Approximately $92.2 million of future cash generated from these foreign subsidiaries is expected to be repatriated, with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-25-000025:mdna:126]
Stock Repurchase Authorization. On October 2, 2024, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2022. During the first six months of fiscal 2025, we repurchased $163.5 million of our common stock under the stock repurchase program, and $836.5 million remained under the current repurchase authorization as of May 3, 2025. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report as well as Item 2 of Part II of this report.

[0000936395-25-000025:mdna:127]
[same as prior period, unchanged from 0000936395-25-000011:mdna:97]

[0000936395-25-000025:mdna:128]
The following table sets forth changes in our cash, cash equivalents, and investments in marketable debt securities for the periods indicated (in thousands):

[0000936395-25-000025:mdna:129]
|  | May 3,2025 |  | November 2,2024 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 949,771 |  |  | $ | 934,863 |  |  | $ | 14,908 |  |
| Short-term investments in marketable debt securities | 304,177 |  |  | 316,343 |  |  | (12,166) |  |
| Long-term investments in marketable debt securities | 92,121 |  |  | 80,920 |  |  | 11,201 |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,346,069 |  |  | $ | 1,332,126 |  |  | $ | 13,943 |  |

[0000936395-25-000025:mdna:130]
Cash, cash equivalents and investments increased by $13.9 million during the first six months of fiscal 2025. Cash from operations generated $260.7 million which was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $168.2 million; (ii) cash used to fund our investing activities for capital expenditures totaling $55.6 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $42.3 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $17.1 million in cash during the six months ended May 3, 2025.

[0000936395-25-000025:mdna:131]
[same as prior period, unchanged from 0000936395-25-000011:mdna:101]

[0000936395-25-000025:mdna:132]
The following sections set forth the components of our $260.7 million of cash provided by operating activities during the first six months of fiscal 2025. Net income (adjusted for non-cash charges) provided cash of approximately $227.0 million and cash provided by operating assets and liabilities was approximately $33.7 million.

[0000936395-25-000025:mdna:133]
[same as prior period, unchanged from 0000936395-25-000011:mdna:103]

[0000936395-25-000025:mdna:134]
[same as prior period, unchanged from 0000936395-25-000011:mdna:104]

[0000936395-25-000025:mdna:135]
|  | Six Months Ended |
|  | May 3, 2025 |
| Net income | $ | 53,541 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 49,771 |  |
| Share-based compensation expense | 88,767 |  |
| Amortization of intangible assets | 17,555 |  |
| Deferred taxes | (10,470) |  |
| Provision for inventory excess and obsolescence | 23,431 |  |
| Provision for warranty | 10,714 |  |
| Other | (6,355) |  |
| Net income (adjusted for non-cash charges) | $ | 226,954 |  |

[0000936395-25-000025:mdna:136]
[same as prior period, unchanged from 0000936395-25-000011:mdna:106]

[0000936395-25-000025:mdna:137]
Operating asset and liability requirements decreased by $33.7 million during the period. The following table sets forth the major components of the cash changes in operating assets and liabilities (in thousands):

[0000936395-25-000025:mdna:138]
|  | Six Months Ended |
|  | May 3, 2025 |
| Accounts receivable | $ | (20,857) |  |
| Inventories | (76,904) |  |
| Prepaid expenses and other | 84,144 |  |
| Accounts payable, accruals, and other obligations | (16,755) |  |
| Deferred revenue | 66,493 |  |
| Operating lease assets and liabilities, net | (2,406) |  |
| Total cash provided by operating assets and liabilities | $ | 33,715 |  |

[0000936395-25-000025:mdna:139]
As compared to the end of fiscal 2024, for the first six months of fiscal 2025:

[0000936395-25-000025:mdna:140]
[same as prior period, unchanged from 0000936395-25-000011:mdna:110]

[0000936395-25-000025:mdna:141]
[same as prior period, unchanged from 0000936395-25-000011:mdna:111]

[0000936395-25-000025:mdna:142]
[same as prior period, unchanged from 0000936395-25-000011:mdna:112]

[0000936395-25-000025:mdna:143]
•The change in accounts payable, accruals, and other obligations primarily reflects the timing of payments for income taxes;

[0000936395-25-000025:mdna:144]
[same as prior period, unchanged from 0000936395-25-000011:mdna:114]

[0000936395-25-000025:mdna:145]
[same as prior period, unchanged from 0000936395-25-000011:mdna:115]

[0000936395-25-000025:mdna:146]
Our days sales outstanding (“DSOs”) decreased from 92 for the first six months of fiscal 2024 to 89 for the first six months of fiscal 2025. The calculation of DSOs includes accounts receivables, net, and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 1.7 for the first six months of fiscal 2024 to 2.4 for the first six months of fiscal 2025.

[0000936395-25-000025:mdna:147]
[same as prior period, unchanged from 0000936395-25-000011:mdna:117]

[0000936395-25-000025:mdna:148]
[same as prior period, unchanged from 0000936395-25-000011:mdna:118]

[0000936395-25-000025:mdna:149]
|  | Six Months Ended |
|  | May 3, 2025 |
| 2030 Term Loan terminated January 17, 2025(1) | $ | 18,639 |  |
| Refinanced 2030 Term Loan due October 28, 2030(2) | 18,299 |  |
| 2030 Senior Notes due January 31, 2030(3) | 8,000 |  |
| Interest rate swaps(4) | (4,334) |  |
| Revolving Credit Facility(5) | 906 |  |
| Finance leases | 1,690 |  |
| Cash paid during period | $ | 43,200 |  |

[0000936395-25-000025:mdna:150]
[same as prior period, unchanged from 0000936395-25-000011:mdna:120]

[0000936395-25-000025:mdna:151]
(2) Interest on the Refinanced 2030 Term Loan is payable periodically based on the interest period selected for borrowing. The Refinanced 2030 Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 1.75% subject to a minimum SOFR rate of 0.00%. At the end of the second quarter of fiscal 2025, the interest rate on the Refinanced 2030 Term Loan was 6.07%.

[0000936395-25-000025:mdna:152]
[same as prior period, unchanged from 0000936395-25-000011:mdna:122]

[0000936395-25-000025:mdna:153]
[same as prior period, unchanged from 0000936395-25-000011:mdna:123]

[0000936395-25-000025:mdna:154]
(5) During the first six months of fiscal 2025, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility.

[0000936395-25-000025:mdna:155]
For additional information about our debt and interest rate swaps, see Notes 10 and 12 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-25-000025:mdna:156]
[same as prior period, unchanged from 0000936395-25-000011:mdna:126]

[0000936395-25-000025:mdna:157]
Our contractual obligations have not changed materially since November 2, 2024. For a summary of our contractual obligations, see “Liquidity and Capital Resources – Contractual Obligations” in Item 7 of Part II of our 2024 Annual Report.

[0000936395-25-000025:mdna:158]
[same as prior period, unchanged from 0000936395-25-000011:mdna:128]

[0000936395-25-000025:mdna:159]
Our critical accounting policies and estimates have not changed materially since November 2, 2024. For a discussion of our critical accounting policies and estimates, see “Critical Accounting Policies and Estimates” in Item 7 of Part II of our 2024 Annual Report.

[0000936395-25-000025:mdna:160]
[same as prior period, unchanged from 0000936395-25-000011:mdna:130]

[0000936395-25-000025:mdna:161]
[same as prior period, unchanged from 0000936395-25-000011:mdna:131]
