# CIEN notes — 0000936395-25-000025


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-25-000025:notes:1]
[same as prior period, unchanged from 0000936395-25-000011:notes:1]

[0000936395-25-000025:notes:2]
[same as prior period, unchanged from 0000936395-25-000011:notes:2]

[0000936395-25-000025:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-25-000025:notes:4]
[same as prior period, unchanged from 0000936395-25-000011:notes:4]

[0000936395-25-000025:notes:5]
[same as prior period, unchanged from 0000936395-25-000011:notes:5]

[0000936395-25-000025:notes:6]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures, to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for Ciena’s fiscal 2025 Annual Report on Form 10-K on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its segment disclosures.

[0000936395-25-000025:notes:7]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures, to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.

[0000936395-25-000025:notes:8]
In November 2024, the FASB issued ASU No. 2024-03 (“ASU 2024-03”), Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40), to improve financial reporting by requiring that public business entities disclose additional information about specific expense categories in the notes to financial statements at interim and annual reporting periods. ASU 2024-03 is effective for annual periods beginning after December 15, 2026, and interim reporting periods beginning after December 15, 2027; however, early adoption is permitted. ASU 2024-03 allows for adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this ASU on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-25-000025:notes:9]
[same as prior period, unchanged from 0000936395-25-000011:notes:9]

[0000936395-25-000025:notes:10]
Ciena’s disaggregated segment and product line revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 17 below.

[0000936395-25-000025:notes:11]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

[0000936395-25-000025:notes:12]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |

[0000936395-25-000025:notes:13]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |

[0000936395-25-000025:notes:14]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

[0000936395-25-000025:notes:15]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

[0000936395-25-000025:notes:16]
[same as prior period, unchanged from 0000936395-25-000011:notes:14]

[0000936395-25-000025:notes:17]
[same as prior period, unchanged from 0000936395-25-000011:notes:15]

[0000936395-25-000025:notes:18]
[same as prior period, unchanged from 0000936395-25-000011:notes:16]

[0000936395-25-000025:notes:19]
[same as prior period, unchanged from 0000936395-25-000011:notes:17]

[0000936395-25-000025:notes:20]
[same as prior period, unchanged from 0000936395-25-000011:notes:18]

[0000936395-25-000025:notes:21]
[same as prior period, unchanged from 0000936395-25-000011:notes:19]

[0000936395-25-000025:notes:22]
[same as prior period, unchanged from 0000936395-25-000011:notes:20]

[0000936395-25-000025:notes:23]
[same as prior period, unchanged from 0000936395-25-000011:notes:21]

[0000936395-25-000025:notes:24]
[same as prior period, unchanged from 0000936395-25-000011:notes:22]

[0000936395-25-000025:notes:25]
[same as prior period, unchanged from 0000936395-25-000011:notes:23]

[0000936395-25-000025:notes:26]
[same as prior period, unchanged from 0000936395-25-000011:notes:24]

[0000936395-25-000025:notes:27]
[same as prior period, unchanged from 0000936395-25-000011:notes:25]

[0000936395-25-000025:notes:28]
[same as prior period, unchanged from 0000936395-25-000011:notes:26]

[0000936395-25-000025:notes:29]
[same as prior period, unchanged from 0000936395-25-000011:notes:27]

[0000936395-25-000025:notes:30]
[same as prior period, unchanged from 0000936395-25-000011:notes:28]

[0000936395-25-000025:notes:31]
[same as prior period, unchanged from 0000936395-25-000011:notes:29]

[0000936395-25-000025:notes:32]
[same as prior period, unchanged from 0000936395-25-000011:notes:30]

[0000936395-25-000025:notes:33]
[same as prior period, unchanged from 0000936395-25-000011:notes:31]

[0000936395-25-000025:notes:34]
[same as prior period, unchanged from 0000936395-25-000011:notes:32]

[0000936395-25-000025:notes:35]
[same as prior period, unchanged from 0000936395-25-000011:notes:33]

[0000936395-25-000025:notes:36]
[same as prior period, unchanged from 0000936395-25-000011:notes:34]

[0000936395-25-000025:notes:37]
[same as prior period, unchanged from 0000936395-25-000011:notes:35]

[0000936395-25-000025:notes:38]
For additional information on Ciena’s revenue recognition policy, see Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

[0000936395-25-000025:notes:39]
[same as prior period, unchanged from 0000936395-25-000011:notes:37]

[0000936395-25-000025:notes:40]
[same as prior period, unchanged from 0000936395-25-000011:notes:38]

[0000936395-25-000025:notes:41]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-25-000025:notes:42]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 833,822 |  |  | $ | 662,877 |  |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |
| EMEA |  | 191,585 |  |  | 155,791 |  |  | 349,501 |  |  | 363,203 |  |
| APAC |  | 100,471 |  |  | 92,158 |  |  | 219,183 |  |  | 204,257 |  |
| Total revenue by geographic distribution |  | $ | 1,125,878 |  |  | $ | 910,826 |  |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |

[0000936395-25-000025:notes:43]
Ciena’s revenue includes $797.5 million and $618.8 million of U.S. revenue for the second quarter of fiscal 2025 and 2024, respectively. For the six months ended May 3, 2025 and April 27, 2024, U.S. revenue was $1.6 billion and $1.3 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

[0000936395-25-000025:notes:44]
Ciena’s revenue includes $151.3 million and $320.2 million from a cloud provider for the second quarter and six months ended May 3, 2025, respectively, and such customer did not account for 10% or more of total revenue for the second quarter or six months ended April 27, 2024. Revenue also includes $117.4 million and $228.4 million from AT&T for the second quarter and six months ended May 3, 2025, respectively, and $125.5 million and $211.7 million for the second quarter and six months ended April 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

[0000936395-25-000025:notes:45]
[same as prior period, unchanged from 0000936395-25-000011:notes:43]

[0000936395-25-000025:notes:46]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

[0000936395-25-000025:notes:47]
|  |  | Balance at May 3, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 929,799 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,769 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 305,074 |  |  | $ | 237,619 |  |

[0000936395-25-000025:notes:48]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.

[0000936395-25-000025:notes:49]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $111.3 million and $105.3 million of revenue during the first six months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 3, 2025 and April 27, 2024.

[0000936395-25-000025:notes:50]
[same as prior period, unchanged from 0000936395-25-000011:notes:48]

[0000936395-25-000025:notes:51]
|  | May 3,2025 |  | November 2,2024 |
| Products | $ | 31,651 |  |  | $ | 19,017 |  |
| Services | 273,423 |  |  | 218,602 |  |
| Total deferred revenue | 305,074 |  |  | 237,619 |  |
| Less current portion | (221,835) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,239 |  |  | $ | 81,240 |  |

[0000936395-25-000025:notes:52]
[same as prior period, unchanged from 0000936395-25-000011:notes:50]

[0000936395-25-000025:notes:53]
Capitalized contract acquisition costs consist of deferred sales commissions and were $29.3 million and $28.4 million as of May 3, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $16.7 million and $14.9 million during the first six months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-25-000025:notes:54]
[same as prior period, unchanged from 0000936395-25-000011:notes:52]

[0000936395-25-000025:notes:55]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 3, 2025, the aggregate amount of RPO was $1.7 billion. As of May 3, 2025, Ciena expects approximately 79% of the RPO balance to be recognized as revenue within the next 12 months.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-25-000025:notes:56]
[same as prior period, unchanged from 0000936395-25-000011:notes:54]

[0000936395-25-000025:notes:57]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the six months ended May 3, 2025 (in thousands):

[0000936395-25-000025:notes:58]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at November 2, 2024 | $ | 1,927 |  |  | $ | — |  |  | $ | 1,927 |  |
| Charges | 1,589 |  |  | 1,903 |  | (1) | 3,492 |  |
| Cash payments | (2,840) |  |  | (1,903) |  |  | (4,743) |  |
| Balance at May 3, 2025 | $ | 676 |  |  | $ | — |  |  | $ | 676 |  |
| Current restructuring liabilities | $ | 676 |  |  | $ | — |  |  | $ | 676 |  |

[0000936395-25-000025:notes:59]
[same as prior period, unchanged from 0000936395-25-000011:notes:57]

[0000936395-25-000025:notes:60]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the six months ended April 27, 2024 (in thousands):

[0000936395-25-000025:notes:61]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 13,984 |  | (1) | 6,642 |  | (2) | 20,626 |  |
| Cash payments | (7,147) |  |  | (6,642) |  |  | (13,789) |  |
| Balance at April 27, 2024 | $ | 8,750 |  |  | $ | — |  |  | $ | 8,750 |  |
| Current restructuring liabilities | $ | 8,750 |  |  | $ | — |  |  | $ | 8,750 |  |

[0000936395-25-000025:notes:62]
(1)  Reflects a global workforce reduction of approximately 360 employees during the six months ended April 27, 2024 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-25-000025:notes:63]
(2) Primarily represents costs related to restructured real estate facilities and the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-25-000025:notes:64]
[same as prior period, unchanged from 0000936395-25-000011:notes:61]

[0000936395-25-000025:notes:65]
|  | Quarter Ended |  | Six Months Ended |
|  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Interest income | $ | 13,435 |  |  | $ | 15,255 |  |  | $ | 27,145 |  |  | $ | 30,433 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts(1) | 536 |  |  | (1,114) |  |  | (2,337) |  |  | 1,998 |  |
| Foreign currency exchange losses(2) | (4,243) |  |  | (411) |  |  | (3,003) |  |  | (9,604) |  |
| Other | (1,857) |  |  | (1,933) |  |  | (2,356) |  |  | (380) |  |
| Interest and other income, net | $ | 7,871 |  |  | $ | 11,797 |  |  | $ | 19,449 |  |  | $ | 22,447 |  |

[0000936395-25-000025:notes:66]
(1) Ciena has forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations.

[0000936395-25-000025:notes:67]
[same as prior period, unchanged from 0000936395-25-000011:notes:64]


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-25-000025:notes:68]
INCOME TAXES
The effective tax rate for the second quarter of fiscal 2025 was higher than the effective tax rate for the second quarter of fiscal 2024, primarily due to a change in valuation allowance and interest expense related to previously recorded uncertain tax positions.

[0000936395-25-000025:notes:69]
The effective tax rate for the first six months of fiscal 2025 was lower than the effective tax rate for the first six months of fiscal 2024, primarily due to an income tax benefit for share-based compensation expense. 
For the six months ended May 3, 2025, the impact of the 15% global minimum tax, referred to as Pillar Two, was not material to the consolidated financial statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-25-000025:notes:70]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-25-000025:notes:71]
|  | May 3, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 272,552 |  |  | $ | 500 |  |  | $ | (28) |  |  | $ | 273,024 |  |
| Corporate debt securities | 122,049 |  |  | 130 |  |  | (58) |  |  | 122,121 |  |
| Time deposits | 125,479 |  |  | 1 |  |  | (2) |  |  | 125,478 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |
| Included in cash equivalents | $ | 124,325 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,325 |  |
| Included in short-term investments | 303,798 |  |  | 412 |  |  | (33) |  |  | 304,177 |  |
| Included in long-term investments | 91,957 |  |  | 219 |  |  | (55) |  |  | 92,121 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |

[0000936395-25-000025:notes:72]
|  | November 2, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 285,492 |  |  | $ | 751 |  |  | $ | (62) |  |  | $ | 286,181 |  |
| Corporate debt securities | 111,103 |  |  | 137 |  |  | (97) |  |  | 111,143 |  |
| Time deposits | 92,803 |  |  | 4 |  |  | (3) |  |  | 92,804 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |
| Included in cash equivalents | $ | 92,865 |  |  | $ | — |  |  | $ | — |  |  | $ | 92,865 |  |
| Included in short-term investments | 315,654 |  |  | 734 |  |  | (45) |  |  | 316,343 |  |
| Included in long-term investments | 80,879 |  |  | 158 |  |  | (117) |  |  | 80,920 |  |
|  | $ | 489,398 |  |  | $ | 892 |  |  | $ | (162) |  |  | $ | 490,128 |  |

[0000936395-25-000025:notes:73]
The following table summarizes the final legal maturities of debt investments as of May 3, 2025 (in thousands):

[0000936395-25-000025:notes:74]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 428,123 |  |  | $ | 428,502 |  |
| Due in 1-2 years | 91,957 |  |  | 92,121 |  |
|  | $ | 520,080 |  |  | $ | 520,623 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-25-000025:notes:75]
[same as prior period, unchanged from 0000936395-25-000011:notes:72]

[0000936395-25-000025:notes:76]
|  | May 3, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 584,853 |  |  | $ | — |  |  | $ | — |  |  | $ | 584,853 |  |
| Bond mutual fund | 115,236 |  |  | — |  |  | — |  |  | 115,236 |  |
| Time deposits | 125,478 |  |  | — |  |  | — |  |  | 125,478 |  |
| Deferred compensation plan assets | 18,003 |  |  | — |  |  | — |  |  | 18,003 |  |
| U.S. government obligations | — |  |  | 273,024 |  |  | — |  |  | 273,024 |  |
| Corporate debt securities | — |  |  | 122,121 |  |  | — |  |  | 122,121 |  |
| Foreign currency forward contracts | — |  |  | 8,165 |  |  | — |  |  | 8,165 |  |
| Interest rate swaps | — |  |  | 2,421 |  |  | — |  |  | 2,421 |  |
| Total assets measured at fair value | $ | 843,570 |  |  | $ | 405,731 |  |  | $ | — |  |  | $ | 1,249,301 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 5,054 |  |  | $ | — |  |  | $ | 5,054 |  |
| Interest rate swaps | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,098 |  |  | $ | — |  |  | $ | 5,098 |  |

[0000936395-25-000025:notes:77]
[same as prior period, unchanged from 0000936395-25-000011:notes:74]

[0000936395-25-000025:notes:78]
[same as prior period, unchanged from 0000936395-25-000011:notes:75]

[0000936395-25-000025:notes:79]
|  | May 3, 2025 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 822,388 |  |  | $ | 2,026 |  |  | $ | — |  |  | $ | 824,414 |  |
| Short-term investments | 3,179 |  |  | 300,998 |  |  | — |  |  | 304,177 |  |
| Prepaid expenses and other | — |  |  | 8,165 |  |  | — |  |  | 8,165 |  |
| Long-term investments | — |  |  | 92,121 |  |  | — |  |  | 92,121 |  |
| Other long-term assets | 18,003 |  |  | 2,421 |  |  | — |  |  | 20,424 |  |
| Total assets measured at fair value | $ | 843,570 |  |  | $ | 405,731 |  |  | $ | — |  |  | $ | 1,249,301 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 5,054 |  |  | $ | — |  |  | $ | 5,054 |  |
| Other long-term obligations | — |  |  | 44 |  |  | — |  |  | 44 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,098 |  |  | $ | — |  |  | $ | 5,098 |  |

[0000936395-25-000025:notes:80]
[same as prior period, unchanged from 0000936395-25-000011:notes:77]

[0000936395-25-000025:notes:81]
[same as prior period, unchanged from 0000936395-25-000011:notes:78]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-25-000025:notes:82]
[same as prior period, unchanged from 0000936395-25-000011:notes:79]

[0000936395-25-000025:notes:83]
|  | May 3,2025 |  | November 2,2024 |
| Raw materials | $ | 646,991 |  |  | $ | 542,785 |  |
| Work-in-process | 35,317 |  |  | 32,219 |  |
| Finished goods | 273,376 |  |  | 324,697 |  |
| Deferred cost of goods sold | 36,663 |  |  | 27,902 |  |
| Gross inventories | 992,347 |  |  | 927,603 |  |
| Reserve for inventory excess and obsolescence | (118,021) |  |  | (107,173) |  |
| Inventories, net | $ | 874,326 |  |  | $ | 820,430 |  |

[0000936395-25-000025:notes:84]
During the first six months of fiscal 2025, Ciena recorded a provision for inventory excess and obsolescence of $23.4 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the reserve for excess and obsolete inventory relate primarily to sales and disposal activities.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-25-000025:notes:85]
[same as prior period, unchanged from 0000936395-25-000011:notes:82]

[0000936395-25-000025:notes:86]
Ciena conducts business globally in many currencies, and thus is exposed to foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-25-000025:notes:87]
As of May 3, 2025 and November 2, 2024, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $349.2 million and $257.0 million as of May 3, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-25-000025:notes:88]
As of May 3, 2025 and November 2, 2024, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $65.1 million and $65.4 million as of May 3, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 36 months or less and have been designated as net investment hedges.

[0000936395-25-000025:notes:89]
As of May 3, 2025 and November 2, 2024, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $140.9 million and $201.2 million as of May 3, 2025 and November 2, 2024, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-25-000025:notes:90]
[same as prior period, unchanged from 0000936395-25-000011:notes:87]

[0000936395-25-000025:notes:91]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 12 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”).

[0000936395-25-000025:notes:92]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest rate swaps was $350.0 million as of May 3, 2025 and November 2, 2024.

[0000936395-25-000025:notes:93]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028. The total notional amount of these interest rate swaps was $350.0 million as of May 3, 2025 and November 2, 2024.

[0000936395-25-000025:notes:94]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of May 3, 2025 and November 2, 2024.

[0000936395-25-000025:notes:95]
Ciena expects the variable rate payments to be received under the terms of these interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the Refinanced 2030 Term Loan (as defined in Note 12 below). These derivative contracts have been designated as cash flow hedges.

[0000936395-25-000025:notes:96]
[same as prior period, unchanged from 0000936395-25-000011:notes:93]


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-25-000025:notes:97]
LEASES
Operating leases included on the Condensed Consolidated Balance Sheets for the fiscal periods indicated were as follows (in thousands):

[0000936395-25-000025:notes:98]
|  | Classification |  | Balance at May 3, 2025 |  | Balance at November 2, 2024 |
| Operating leases: |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 38,655 |  |  | $ | 27,417 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 48,273 |  |  | $ | 39,562 |  |

[0000936395-25-000025:notes:99]
Ciena added two new 10-year operating leases to its portfolio in the second quarter of fiscal 2025. The addition of these two operating leases increased both operating right-of-use (“ROU”) assets and lease liabilities for fiscal 2025.


## us-gaap:DebtDisclosureTextBlock

[0000936395-25-000025:notes:100]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-25-000025:notes:101]
Refinanced 2030 Term Loan

[0000936395-25-000025:notes:102]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained a senior secured term loan with an outstanding aggregate principal amount, as of January 17, 2025, of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).

[0000936395-25-000025:notes:103]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing

[0000936395-25-000025:notes:104]
Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

[0000936395-25-000025:notes:105]
•mature on October 24, 2030;

[0000936395-25-000025:notes:106]
•amortize in equal quarterly installments in aggregate amounts equal to approximately 0.25% of the principal amount of the Refinanced 2030 Term Loan as of the Closing Date, with the balance payable at maturity;

[0000936395-25-000025:notes:107]
•be subject to mandatory prepayment upon the occurrence of certain specified events substantially similar to the 2030 Term Loan, including upon the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

[0000936395-25-000025:notes:108]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 1.75%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 0.75%;

[0000936395-25-000025:notes:109]
•be repayable at any time at Ciena’s election, provided that repayment of the Refinanced 2030 Term Loan with proceeds of certain indebtedness prior to July 17, 2025 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and

[0000936395-25-000025:notes:110]
•except as described above or otherwise set forth in the Amendment, have substantially identical terms as the 2030 Term Loan.

[0000936395-25-000025:notes:111]
Except as amended by the Amendment, the remaining terms of the Credit Agreement remain in full force and effect.

[0000936395-25-000025:notes:112]
The net carrying value of the Ciena’s term loans were comprised of the following as of the date indicated (in thousands):

[0000936395-25-000025:notes:113]
|  |  | May 3, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,152,510 |  |  | $ | (3,921) |  |  | $ | (5,006) |  |  | $ | 1,143,583 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

[0000936395-25-000025:notes:114]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.5 million during both the first six months of fiscal 2025 and fiscal 2024.

[0000936395-25-000025:notes:115]
As of May 3, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.14 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-25-000025:notes:116]
Outstanding Senior Notes Payable

[0000936395-25-000025:notes:117]
2030 Notes

[0000936395-25-000025:notes:118]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-25-000025:notes:119]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-25-000025:notes:120]
|  |  | May 3, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,227) |  |  | $ | 396,773 |  |  | $ | 396,427 |  |  |  |

[0000936395-25-000025:notes:121]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.3 million during both the first six months of fiscal 2025 and fiscal 2024.

[0000936395-25-000025:notes:122]
As of May 3, 2025, the estimated fair value of the 2030 Notes was $370.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-25-000025:notes:123]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the six months ended May 3, 2025 (in thousands):

[0000936395-25-000025:notes:124]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at November 2, 2024 | $ | 798 |  |  | $ | (4,880) |  |  |  |  | $ | 8,668 |  |  | $ | (51,297) |  |  | $ | (46,711) |  |
| Other comprehensive gain (loss) before reclassifications | (399) |  |  | 3,247 |  |  |  |  | (2,548) |  |  | 7,711 |  |  | 8,011 |  |
| Amounts reclassified from AOCI | — |  |  | 3,438 |  |  |  |  | (4,334) |  |  | — |  |  | (896) |  |
| Balance at May 3, 2025 | $ | 399 |  |  | $ | 1,805 |  |  |  |  | $ | 1,786 |  |  | $ | (43,586) |  |  | $ | (39,596) |  |

[0000936395-25-000025:notes:125]
The following table summarizes the changes in AOCI, net of tax, for the six months ended April 27, 2024 (in thousands):

[0000936395-25-000025:notes:126]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications | (282) |  |  | 2,812 |  |  | 11,681 |  |  | 7,647 |  |  | 21,858 |  |
| Amounts reclassified from AOCI | — |  |  | 1,796 |  |  | (7,616) |  |  | — |  |  | (5,820) |  |
| Balance at April 27, 2024 | $ | (654) |  |  | $ | (3,548) |  |  | $ | 23,027 |  |  | $ | (40,554) |  |  | $ | (21,729) |  |

[0000936395-25-000025:notes:127]
All amounts reclassified from AOCI related to settlements on foreign currency forward contracts designated as cash flow hedges, impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlements on interest rate swaps designated as cash flow hedges, impacted interest and other income, net, on the Condensed Consolidated Statements of Operations.


## us-gaap:EarningsPerShareTextBlock

[0000936395-25-000025:notes:128]
EARNINGS (LOSS) PER SHARE CALCULATION
Basic net income (loss) per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income (loss) per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent that the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan, using the treasury stock method.

[0000936395-25-000025:notes:129]
[same as prior period, unchanged from 0000936395-25-000011:notes:123]

[0000936395-25-000025:notes:130]
|  | Quarter Ended |  | Six Months Ended |
|  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Net income (loss) | $ | 8,969 |  |  | $ | (16,849) |  |  | $ | 53,541 |  |  | $ | 32,698 |  |
| Basic weighted average shares outstanding | 142,503 |  |  | 144,914 |  |  | 142,704 |  |  | 145,104 |  |
| Effect of dilutive potential common shares | 2,469 |  |  | — |  |  | 2,766 |  |  | 955 |  |
| Diluted weighted average shares | 144,972 |  |  | 144,914 |  |  | 145,470 |  |  | 146,059 |  |
| Basic EPS | $ | 0.06 |  |  | $ | (0.12) |  |  | $ | 0.38 |  |  | $ | 0.23 |  |
| Diluted EPS | $ | 0.06 |  |  | $ | (0.12) |  |  | $ | 0.37 |  |  | $ | 0.22 |  |
| Antidilutive employee share-based awards, excluded | 1,630 |  |  | 2,030 |  |  | 1,310 |  |  | 1,584 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-25-000025:notes:131]
[same as prior period, unchanged from 0000936395-25-000011:notes:125]

[0000936395-25-000025:notes:132]
[same as prior period, unchanged from 0000936395-25-000011:notes:126]

[0000936395-25-000025:notes:133]
During the first six months of fiscal 2025, Ciena repurchased approximately 2.2 million shares of its common stock for an aggregate purchase price of approximately $163.5 million, which equates to an average price of $72.89 per share. As of May 3, 2025, Ciena has an aggregate of $836.5 million authorized and remaining under its stock repurchase program. Ciena is required to allocate the purchase price for the shares of Ciena’s stock repurchased as a reduction of common stock and additional paid-in capital.

[0000936395-25-000025:notes:134]
[same as prior period, unchanged from 0000936395-25-000011:notes:128]

[0000936395-25-000025:notes:135]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $42.3 million for the shares of Ciena’s stock repurchased during the first six months of fiscal 2025 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-25-000025:notes:136]
[same as prior period, unchanged from 0000936395-25-000011:notes:130]

[0000936395-25-000025:notes:137]
|  | Quarter Ended |  | Six Months Ended |
|  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Products | $ | 2,033 |  |  | $ | 1,760 |  |  | $ | 3,783 |  |  | $ | 3,078 |  |
| Services | 3,980 |  |  | 3,344 |  |  | 7,385 |  |  | 6,364 |  |
| Share-based compensation expense included in cost of goods sold | 6,013 |  |  | 5,104 |  |  | 11,168 |  |  | 9,442 |  |
| Research and development | 17,021 |  |  | 14,066 |  |  | 31,258 |  |  | 26,946 |  |
| Selling and marketing | 13,649 |  |  | 11,166 |  |  | 25,246 |  |  | 21,471 |  |
| General and administrative | 11,341 |  |  | 9,875 |  |  | 21,168 |  |  | 19,954 |  |
| Share-based compensation expense included in operating expense | 42,011 |  |  | 35,107 |  |  | 77,672 |  |  | 68,371 |  |
| Share-based compensation expense capitalized in inventory, net | (64) |  |  | 37 |  |  | (73) |  |  | 262 |  |
| Total share-based compensation expense | $ | 47,960 |  |  | $ | 40,248 |  |  | $ | 88,767 |  |  | $ | 78,075 |  |

[0000936395-25-000025:notes:138]
As of May 3, 2025, total unrecognized share-based compensation expense was approximately $312.0 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-25-000025:notes:139]
[same as prior period, unchanged from 0000936395-25-000011:notes:133]

[0000936395-25-000025:notes:140]
[same as prior period, unchanged from 0000936395-25-000011:notes:134]

[0000936395-25-000025:notes:141]
[same as prior period, unchanged from 0000936395-25-000011:notes:135]

[0000936395-25-000025:notes:142]
[same as prior period, unchanged from 0000936395-25-000011:notes:136]

[0000936395-25-000025:notes:143]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to net income (loss) for the periods presented (in thousands):

[0000936395-25-000025:notes:144]
|  | Quarter Ended |  | Six Months Ended |
|  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 133,712 |  |  | $ | 96,566 |  |  | $ | 300,791 |  |  | $ | 280,341 |  |
| Platform Software and Services | 50,423 |  |  | 54,037 |  |  | 113,548 |  |  | 112,041 |  |
| Blue Planet Automation Software and Services | 4,291 |  |  | (7,763) |  |  | 8,867 |  |  | (14,832) |  |
| Global Services | 49,544 |  |  | 50,441 |  |  | 93,922 |  |  | 95,424 |  |
| Total segment profit | 237,970 |  |  | 193,281 |  |  | 517,128 |  |  | 472,974 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 139,683 |  |  | 124,071 |  |  | 276,187 |  |  | 252,229 |  |
| General and administrative | 56,952 |  |  | 49,573 |  |  | 110,854 |  |  | 104,256 |  |
| Significant asset impairments and restructuring costs | 1,948 |  |  | 15,655 |  |  | 3,492 |  |  | 20,626 |  |
| Amortization of intangible assets | 6,545 |  |  | 7,947 |  |  | 13,090 |  |  | 15,199 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 7,871 |  |  | 11,797 |  |  | 19,449 |  |  | 22,447 |  |
| Interest expense | (21,697) |  |  | (23,861) |  |  | (44,615) |  |  | (47,637) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (729) |  |  | — |  |
| Less: Provision for income taxes | 10,047 |  |  | 820 |  |  | 34,069 |  |  | 22,776 |  |
| Net income (loss) | $ | 8,969 |  |  | $ | (16,849) |  |  | $ | 53,541 |  |  | $ | 32,698 |  |

[0000936395-25-000025:notes:145]
[same as prior period, unchanged from 0000936395-25-000011:notes:139]

[0000936395-25-000025:notes:146]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of May 3, 2025, equipment, building, furniture and fixtures, net, totaled $349.3 million, and operating ROU assets totaled $38.7 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of May 3, 2025, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-25-000025:notes:147]
|  | May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 144,673 |  |  | — |  |  | 2,786 |  |  | — |  |  | $ | 147,459 |  |
| Goodwill | $ | 199,565 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 444,805 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 88,507 |  |  | $ | 88,507 |  |

[0000936395-25-000025:notes:148]
The following table represents Ciena’s geographic distribution of equipment, building, furniture and fixtures, net and operating ROU assets, specifically identifying any country that accounts for at least 10% of the total of these assets. Assets attributable to geographic regions not identified are reflected as “Other International.” For the periods indicated, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-25-000025:notes:149]
|  | May 3,2025 |  | November 2,2024 |
| Canada | $ | 296,820 |  |  | $ | 283,760 |  |
| United States | 45,447 |  |  | 49,195 |  |
| Other International | 45,737 |  |  | 32,184 |  |
| Total | $ | 388,004 |  |  | $ | 365,139 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-25-000025:notes:150]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-25-000025:notes:151]
Ciena is subject to various tax contingencies arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these contingencies will have a material effect on its financial position or cash flows.

[0000936395-25-000025:notes:152]
Litigation

[0000936395-25-000025:notes:153]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-25-000025:notes:154]
Purchase Obligations

[0000936395-25-000025:notes:155]
Ciena has certain advanced commitments for supply of certain long lead time components. As of May 3, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-25-000025:notes:156]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-25-000025:notes:157]
From the end of the second quarter of fiscal 2025 through May 30, 2025, Ciena repurchased 318,958 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $78.63 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of May 30, 2025, Ciena has an aggregate of $811.5 million of authorized funds remaining under this repurchase program.
