# CIEN note change history — 0000936395-25-000011 → 0000936395-25-000025


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:1]
Ciena is subject to various tax contingencies arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these contingencies will have a material effect on its financial position or cash flows.
  (was, 2025-03-12, similarity 0.7992):
[0000936395-25-000011:note_history:1]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

- changed (2025-06-05):
[0000936395-25-000025:note_history:2]
Ciena has certain advanced commitments for supply of certain long lead time components. As of May 3, 2025, Ciena had $1.8 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.
  (was, 2025-03-12, similarity 0.9894):
[0000936395-25-000011:note_history:2]
Ciena has certain advanced commitments for supply of certain long lead time components. As of February 1, 2025, Ciena had $1.7 billion in outstanding purchase commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these commitments. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.
  (was, 2025-03-12, similarity 0.9997):
[0000936395-25-000011:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of November 2, 2024 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended November 2, 2024 (the “2024 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2025 is a 52-week fiscal year. Fiscal 2024 was a 53-week fiscal year with the additional week occurring in the fourth quarter.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:4]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena maintained a senior secured term loan with an outstanding aggregate principal amount, as of January 17, 2025, of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).
  (was, 2025-03-12, similarity 0.7159):
[0000936395-25-000011:note_history:4]
Pursuant to a Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena Corporation, the lenders party thereto and Bank of America, N.A., as administrative agent (the “Administrative Agent”), Ciena

- added (2025-06-05):
[0000936395-25-000025:note_history:5]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing

- changed (2025-06-05):
[0000936395-25-000025:note_history:6]
Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:
  (was, 2025-03-12, similarity 0.8373):
[0000936395-25-000011:note_history:6]
On January 17, 2025, Ciena Corporation, as borrower, and Ciena Communications, Inc., Ciena Government Solutions, Inc., Ciena Communications International, LLC and Blue Planet Software, Inc., as guarantors, entered into a Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Amendment”), pursuant to which Ciena incurred a new single tranche of senior secured term loans in an aggregate principal amount of approximately $1.16 billion (the “Refinanced 2030 Term Loan”). The proceeds of the Refinanced 2030 Term Loan, together with cash on hand, were used to refinance in full the 2030 Term Loan, including accrued interest, and pay transaction fees and expenses. The Amendment amends the Credit Agreement and provides that the Refinanced 2030 Term Loan will, among other things:

- changed (2025-06-05):
[0000936395-25-000025:note_history:7]
|  |  | May 3, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,152,510 |  |  | $ | (3,921) |  |  | $ | (5,006) |  |  | $ | 1,143,583 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |
  (was, 2025-03-12, similarity 0.9864):
[0000936395-25-000011:note_history:7]
|  |  | February 1, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,155,405 |  |  | $ | (4,103) |  |  | $ | (5,238) |  |  | $ | 1,146,064 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:8]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was approximately $0.5 million during both the first six months of fiscal 2025 and fiscal 2024.
  (was, 2025-03-12, similarity 0.8291):
[0000936395-25-000011:note_history:8]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loans. The amortization of deferred debt issuance costs for the term loans is included in interest expense and was minimal during the first three months of fiscal 2025 and fiscal 2024.

- changed (2025-06-05):
[0000936395-25-000025:note_history:9]
As of May 3, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.14 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-03-12, similarity 0.9863):
[0000936395-25-000011:note_history:9]
As of February 1, 2025, the estimated fair value of the Refinanced 2030 Term Loan was $1.16 billion. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- changed (2025-06-05):
[0000936395-25-000025:note_history:10]
|  |  | May 3, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,227) |  |  | $ | 396,773 |  |  | $ | 396,427 |  |  |  |
  (was, 2025-03-12, similarity 0.9789):
[0000936395-25-000011:note_history:10]
|  |  | February 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,400) |  |  | $ | 396,600 |  |  | $ | 396,427 |  |  |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:11]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was approximately $0.3 million during both the first six months of fiscal 2025 and fiscal 2024.
  (was, 2025-03-12, similarity 0.8204):
[0000936395-25-000011:note_history:11]
Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense and was minimal during both the first three months of fiscal 2025 and fiscal 2024.

- changed (2025-06-05):
[0000936395-25-000025:note_history:12]
As of May 3, 2025, the estimated fair value of the 2030 Notes was $370.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2025-03-12, similarity 0.9853):
[0000936395-25-000011:note_history:12]
As of February 1, 2025, the estimated fair value of the 2030 Notes was $368.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2025-06-05):
[0000936395-25-000011:note_history:13]
maintained a senior secured term loan with an outstanding aggregate principal amount as of January 17, 2025 of approximately $1.16 billion and maturing on October 24, 2030 (the “2030 Term Loan”).


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:14]
|  | May 3, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 272,552 |  |  | $ | 500 |  |  | $ | (28) |  |  | $ | 273,024 |  |
| Corporate debt securities | 122,049 |  |  | 130 |  |  | (58) |  |  | 122,121 |  |
| Time deposits | 125,479 |  |  | 1 |  |  | (2) |  |  | 125,478 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |
| Included in cash equivalents | $ | 124,325 |  |  | $ | — |  |  | $ | — |  |  | $ | 124,325 |  |
| Included in short-term investments | 303,798 |  |  | 412 |  |  | (33) |  |  | 304,177 |  |
| Included in long-term investments | 91,957 |  |  | 219 |  |  | (55) |  |  | 92,121 |  |
|  | $ | 520,080 |  |  | $ | 631 |  |  | $ | (88) |  |  | $ | 520,623 |  |
  (was, 2025-03-12, similarity 0.9929):
[0000936395-25-000011:note_history:14]
|  | February 1, 2025 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 328,949 |  |  | $ | 591 |  |  | $ | (44) |  |  | $ | 329,496 |  |
| Corporate debt securities | 106,044 |  |  | 126 |  |  | (53) |  |  | 106,117 |  |
| Time deposits | 92,937 |  |  | 2 |  |  | (2) |  |  | 92,937 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |
| Included in cash equivalents | $ | 86,195 |  |  | $ | — |  |  | $ | — |  |  | $ | 86,195 |  |
| Included in short-term investments | 336,734 |  |  | 608 |  |  | (22) |  |  | 337,320 |  |
| Included in long-term investments | 105,001 |  |  | 111 |  |  | (77) |  |  | 105,035 |  |
|  | $ | 527,930 |  |  | $ | 719 |  |  | $ | (99) |  |  | $ | 528,550 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:15]
The following table summarizes the final legal maturities of debt investments as of May 3, 2025 (in thousands):
  (was, 2025-03-12, similarity 0.968):
[0000936395-25-000011:note_history:15]
The following table summarizes the final legal maturities of debt investments as of February 1, 2025 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:16]
|  |  | May 3, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,152,510 |  |  | $ | (3,921) |  |  | $ | (5,006) |  |  | $ | 1,143,583 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |
  (was, 2025-03-12, similarity 0.9864):
[0000936395-25-000011:note_history:16]
|  |  | February 1, 2025 |  | November 2, 2024 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Refinanced 2030 Term Loan |  | $ | 1,155,405 |  |  | $ | (4,103) |  |  | $ | (5,238) |  |  | $ | 1,146,064 |  |  | $ | — |  |
| 2030 Term Loan |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,148,347 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:17]
|  |  | May 3, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,227) |  |  | $ | 396,773 |  |  | $ | 396,427 |  |  |  |
  (was, 2025-03-12, similarity 0.9789):
[0000936395-25-000011:note_history:17]
|  |  | February 1, 2025 |  | November 2, 2024 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (3,400) |  |  | $ | 396,600 |  |  | $ | 396,427 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:18]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2025-03-12, similarity 0.8934):
[0000936395-25-000011:note_history:18]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2025-06-05):
[0000936395-25-000025:note_history:19]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
  (was, 2025-03-12, similarity 0.9803):
[0000936395-25-000011:note_history:19]
|  | Quarter Ended January 27, 2024 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:20]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
  (was, 2025-03-12, similarity 0.9782):
[0000936395-25-000011:note_history:20]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

- added (2025-06-05):
[0000936395-25-000025:note_history:21]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- added (2025-06-05):
[0000936395-25-000025:note_history:22]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:23]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2025-03-12, similarity 0.9388):
[0000936395-25-000011:note_history:23]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2025-06-05):
[0000936395-25-000025:note_history:24]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 833,822 |  |  | $ | 662,877 |  |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |
| EMEA |  | 191,585 |  |  | 155,791 |  |  | 349,501 |  |  | 363,203 |  |
| APAC |  | 100,471 |  |  | 92,158 |  |  | 219,183 |  |  | 204,257 |  |
| Total revenue by geographic distribution |  | $ | 1,125,878 |  |  | $ | 910,826 |  |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |
  (was, 2025-03-12, similarity 0.7396):
[0000936395-25-000011:note_history:24]
|  |  | Quarter Ended |  |  |
|  |  | February 1, |  | January 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  |  |
| EMEA |  | 157,916 |  |  | 207,413 |  |  |  |  |  |
| APAC |  | 118,712 |  |  | 112,098 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:25]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):
  (was, 2025-03-12, similarity 0.8934):
[0000936395-25-000011:note_history:25]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

- changed (2025-06-05):
[0000936395-25-000025:note_history:26]
|  | Quarter Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 773,592 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 773,592 |  |
| Routing and Switching | 92,723 |  |  | — |  |  | — |  |  | — |  |  | 92,723 |  |
| Platform Software and Services | — |  |  | 85,441 |  |  | — |  |  | — |  |  | 85,441 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 27,951 |  |  | — |  |  | 27,951 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 79,442 |  |  | 79,442 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 58,174 |  |  | 58,174 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 8,555 |  |  | 8,555 |  |
| Total revenue by product line | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 866,315 |  |  | $ | 22,048 |  |  | $ | 10,511 |  |  | $ | 7,844 |  |  | $ | 906,718 |  |
| Services transferred over time | — |  |  | 63,393 |  |  | 17,440 |  |  | 138,327 |  |  | 219,160 |  |
| Total revenue by timing of revenue recognition | $ | 866,315 |  |  | $ | 85,441 |  |  | $ | 27,951 |  |  | $ | 146,171 |  |  | $ | 1,125,878 |  |
  (was, 2025-03-12, similarity 0.9803):
[0000936395-25-000011:note_history:26]
|  | Quarter Ended January 27, 2024 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:27]
|  | Quarter Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 560,224 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 560,224 |  |
| Routing and Switching | 116,034 |  |  | — |  |  | — |  |  | — |  |  | 116,034 |  |
| Platform Software and Services | — |  |  | 85,445 |  |  | — |  |  | — |  |  | 85,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 14,434 |  |  | — |  |  | 14,434 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 77,410 |  |  | 77,410 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 43,785 |  |  | 43,785 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 13,494 |  |  | 13,494 |  |
| Total revenue by product line | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 676,258 |  |  | $ | 22,689 |  |  | $ | 2,848 |  |  | $ | 10,432 |  |  | $ | 712,227 |  |
| Services transferred over time | — |  |  | 62,756 |  |  | 11,586 |  |  | 124,257 |  |  | 198,599 |  |
| Total revenue by timing of revenue recognition | $ | 676,258 |  |  | $ | 85,445 |  |  | $ | 14,434 |  |  | $ | 134,689 |  |  | $ | 910,826 |  |
  (was, 2025-03-12, similarity 0.9782):
[0000936395-25-000011:note_history:27]
|  | Quarter Ended February 1, 2025 |
|  | Segment |  | Total |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  |  |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 727,973 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 727,973 |  |
| Routing and Switching | 93,169 |  |  | — |  |  | — |  |  | — |  |  | 93,169 |  |
| Platform Software and Services | — |  |  | 95,067 |  |  | — |  |  | — |  |  | 95,067 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 26,032 |  |  | — |  |  | 26,032 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,573 |  |  | 74,573 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 47,682 |  |  | 47,682 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,764 |  |  | 7,764 |  |
| Total revenue by product line | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 821,142 |  |  | $ | 28,931 |  |  | $ | 10,427 |  |  | $ | 6,133 |  |  | $ | 866,633 |  |
| Services transferred over time | — |  |  | 66,136 |  |  | 15,605 |  |  | 123,886 |  |  | 205,627 |  |
| Total revenue by timing of revenue recognition | $ | 821,142 |  |  | $ | 95,067 |  |  | $ | 26,032 |  |  | $ | 130,019 |  |  | $ | 1,072,260 |  |

- added (2025-06-05):
[0000936395-25-000025:note_history:28]
|  | Six Months Ended May 3, 2025 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,501,566 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,501,566 |  |
| Routing and Switching | 185,892 |  |  | — |  |  | — |  |  | — |  |  | 185,892 |  |
| Platform Software and Services | — |  |  | 180,508 |  |  | — |  |  | — |  |  | 180,508 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 53,982 |  |  | — |  |  | 53,982 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 154,014 |  |  | 154,014 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 105,857 |  |  | 105,857 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 16,319 |  |  | 16,319 |  |
| Total revenue by product line | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,687,458 |  |  | $ | 50,979 |  |  | $ | 20,937 |  |  | $ | 13,977 |  |  | $ | 1,773,351 |  |
| Services transferred over time | — |  |  | 129,529 |  |  | 33,045 |  |  | 262,213 |  |  | 424,787 |  |
| Total revenue by timing of revenue recognition | $ | 1,687,458 |  |  | $ | 180,508 |  |  | $ | 53,982 |  |  | $ | 276,190 |  |  | $ | 2,198,138 |  |

- added (2025-06-05):
[0000936395-25-000025:note_history:29]
|  | Six Months Ended April 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 1,256,072 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,256,072 |  |
| Routing and Switching | 227,421 |  |  | — |  |  | — |  |  | — |  |  | 227,421 |  |
| Platform Software and Services | — |  |  | 175,190 |  |  | — |  |  | — |  |  | 175,190 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 28,376 |  |  | — |  |  | 28,376 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 151,525 |  |  | 151,525 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 86,509 |  |  | 86,509 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 23,442 |  |  | 23,442 |  |
| Total revenue by product line | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,483,493 |  |  | $ | 50,383 |  |  | $ | 3,916 |  |  | $ | 20,071 |  |  | $ | 1,557,863 |  |
| Services transferred over time | — |  |  | 124,807 |  |  | 24,460 |  |  | 241,405 |  |  | 390,672 |  |
| Total revenue by timing of revenue recognition | $ | 1,483,493 |  |  | $ | 175,190 |  |  | $ | 28,376 |  |  | $ | 261,476 |  |  | $ | 1,948,535 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:30]
For additional information on Ciena’s revenue recognition policy, see Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.
  (was, 2025-03-12, similarity 0.9874):
[0000936395-25-000011:note_history:30]
For additional information on Ciena’s revenue recognition policy, see the Notes to Consolidated Financial Statements in Item 8 of Part II of the 2024 Annual Report.

- changed (2025-06-05):
[0000936395-25-000025:note_history:31]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2025-03-12, similarity 0.9388):
[0000936395-25-000011:note_history:31]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2025-06-05):
[0000936395-25-000025:note_history:32]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 3, |  | April 27, |  | May 3, |  | April 27, |
|  |  | 2025 |  | 2024 |  | 2025 |  | 2024 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 833,822 |  |  | $ | 662,877 |  |  | $ | 1,629,454 |  |  | $ | 1,381,075 |  |
| EMEA |  | 191,585 |  |  | 155,791 |  |  | 349,501 |  |  | 363,203 |  |
| APAC |  | 100,471 |  |  | 92,158 |  |  | 219,183 |  |  | 204,257 |  |
| Total revenue by geographic distribution |  | $ | 1,125,878 |  |  | $ | 910,826 |  |  | $ | 2,198,138 |  |  | $ | 1,948,535 |  |
  (was, 2025-03-12, similarity 0.7396):
[0000936395-25-000011:note_history:32]
|  |  | Quarter Ended |  |  |
|  |  | February 1, |  | January 27, |  |  |  |  |
|  |  | 2025 |  | 2024 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 795,632 |  |  | $ | 718,198 |  |  |  |  |  |
| EMEA |  | 157,916 |  |  | 207,413 |  |  |  |  |  |
| APAC |  | 118,712 |  |  | 112,098 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,072,260 |  |  | $ | 1,037,709 |  |  |  |  |  |

- added (2025-06-05):
[0000936395-25-000025:note_history:33]
Ciena’s revenue includes $797.5 million and $618.8 million of U.S. revenue for the second quarter of fiscal 2025 and 2024, respectively. For the six months ended May 3, 2025 and April 27, 2024, U.S. revenue was $1.6 billion and $1.3 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- added (2025-06-05):
[0000936395-25-000025:note_history:34]
Ciena’s revenue includes $151.3 million and $320.2 million from a cloud provider for the second quarter and six months ended May 3, 2025, respectively, and such customer did not account for 10% or more of total revenue for the second quarter or six months ended April 27, 2024. Revenue also includes $117.4 million and $228.4 million from AT&T for the second quarter and six months ended May 3, 2025, respectively, and $125.5 million and $211.7 million for the second quarter and six months ended April 27, 2024, respectively. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.

- changed (2025-06-05):
[0000936395-25-000025:note_history:35]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):
  (was, 2025-03-12, similarity 0.9244):
[0000936395-25-000011:note_history:35]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- changed (2025-06-05):
[0000936395-25-000025:note_history:36]
|  |  | Balance at May 3, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 929,799 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,769 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 305,074 |  |  | $ | 237,619 |  |
  (was, 2025-03-12, similarity 0.8753):
[0000936395-25-000011:note_history:36]
|  |  | Balance at February 1, 2025 |  | Balance at November 2, 2024 |
| Accounts receivable, net |  | $ | 938,703 |  |  | $ | 908,597 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 138,718 |  |  | $ | 127,919 |  |
| Deferred revenue |  | $ | 257,277 |  |  | $ | 237,619 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:37]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets.
  (was, 2025-03-12, similarity 0.998):
[0000936395-25-000011:note_history:37]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets.

- changed (2025-06-05):
[0000936395-25-000025:note_history:38]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $111.3 million and $105.3 million of revenue during the first six months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance as of November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 3, 2025 and April 27, 2024.
  (was, 2025-03-12, similarity 0.9171):
[0000936395-25-000011:note_history:38]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $74.5 million and $70.6 million of revenue during the first three months of fiscal 2025 and 2024, respectively, that was included in the deferred revenue balance at November 2, 2024 and October 28, 2023, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended February 1, 2025 and January 27, 2024.

- changed (2025-06-05):
[0000936395-25-000025:note_history:39]
|  | May 3,2025 |  | November 2,2024 |
| Products | $ | 31,651 |  |  | $ | 19,017 |  |
| Services | 273,423 |  |  | 218,602 |  |
| Total deferred revenue | 305,074 |  |  | 237,619 |  |
| Less current portion | (221,835) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,239 |  |  | $ | 81,240 |  |
  (was, 2025-03-12, similarity 0.9846):
[0000936395-25-000011:note_history:39]
|  | February 1,2025 |  | November 2,2024 |
| Products | $ | 26,413 |  |  | $ | 19,017 |  |
| Services | 230,864 |  |  | 218,602 |  |
| Total deferred revenue | 257,277 |  |  | 237,619 |  |
| Less current portion | (174,151) |  |  | (156,379) |  |
| Long-term deferred revenue | $ | 83,126 |  |  | $ | 81,240 |  |

- changed (2025-06-05):
[0000936395-25-000025:note_history:40]
Capitalized contract acquisition costs consist of deferred sales commissions and were $29.3 million and $28.4 million as of May 3, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other, and (ii) other long-term assets. The amortization expense associated with these costs was $16.7 million and $14.9 million during the first six months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2025-03-12, similarity 0.942):
[0000936395-25-000011:note_history:40]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.4 million and $28.4 million as of February 1, 2025 and November 2, 2024, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $8.5 million and $7.7 million during the first three months of fiscal 2025 and 2024, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2025-06-05):
[0000936395-25-000025:note_history:41]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 3, 2025, the aggregate amount of RPO was $1.7 billion. As of May 3, 2025, Ciena expects approximately 79% of the RPO balance to be recognized as revenue within the next 12 months.
  (was, 2025-03-12, similarity 0.9675):
[0000936395-25-000011:note_history:41]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of February 1, 2025, the aggregate amount of RPO was $1.7 billion. As of February 1, 2025, Ciena expects approximately 79% of the RPO to be recognized as revenue within the next 12 months.

- removed (2025-06-05):
[0000936395-25-000011:note_history:42]
Ciena’s revenue includes $752.5 million and $677.6 million from the United States for the first quarter of fiscal 2025 and 2024, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- removed (2025-06-05):
[0000936395-25-000011:note_history:43]
Ciena’s revenue includes $168.9 million and $109.1 million from a cloud provider for the first quarter of fiscal 2025 and 2024, respectively. Revenue also includes $111.0 million from AT&T for the first quarter of fiscal 2025 and $166.0 million from an additional cloud provider for the first quarter of fiscal 2024. These customers purchased products from the Networking Platforms, Platform Software and Services, and Global Services operating segments for the periods presented. No other customer accounted for 10% or more of total revenue for the periods presented.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2025-06-05):
[0000936395-25-000025:note_history:44]
From the end of the second quarter of fiscal 2025 through May 30, 2025, Ciena repurchased 318,958 shares of its common stock for an aggregate purchase price of $25.1 million at an average price of $78.63 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of May 30, 2025, Ciena has an aggregate of $811.5 million of authorized funds remaining under this repurchase program.
  (was, 2025-03-12, similarity 0.9759):
[0000936395-25-000011:note_history:44]
From the end of the first quarter of fiscal 2025 through March 7, 2025, Ciena repurchased 382,834 shares of its common stock for an aggregate purchase price of $31.7 million at an average price of $82.75 per share, inclusive of repurchases pending settlement under its current stock repurchase program. As of March 7, 2025, Ciena has an aggregate of $889.1 million of authorized funds remaining under this repurchase program.
