# CIEN note change history — 0000936395-23-000034 → 0000936395-24-000008


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2024-03-07):
[0000936395-24-000008:note_history:1]
Purchase Order Obligations

- added (2024-03-07):
[0000936395-24-000008:note_history:2]
Ciena has certain advanced orders for supply of certain long lead time components. As of January 27, 2024, Ciena had $1.9 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 28, 2023 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended October 28, 2023 (the “2023 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2024 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2023 was a 52-week fiscal year.
  (was, 2023-09-06, similarity 0.9485):
[0000936395-23-000034:note_history:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 29, 2022 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for fiscal 2022 (the “2022 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2023 and 2022 are 52-week fiscal years.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2024-03-07):
[0000936395-24-000008:note_history:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2023 Annual Report.

- added (2024-03-07):
[0000936395-24-000008:note_history:5]
Newly Issued Accounting Standards - Effective

- changed (2024-03-07):
[0000936395-24-000008:note_history:6]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.
  (was, 2023-09-06, similarity 0.6349):
[0000936395-23-000034:note_history:6]
In October 2021, the Financial Accounting Standards Board (the “FASB”) issued Accounting Standards Update (“ASU”) No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this ASU on its condensed consolidated financial statements and related disclosures.

- added (2024-03-07):
[0000936395-24-000008:note_history:7]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

- added (2024-03-07):
[0000936395-24-000008:note_history:8]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for 
adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

- removed (2024-03-07):
[0000936395-23-000034:note_history:9]
SIGNIFICANT ACCOUNTING POLICIES
There have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2022 Annual Report.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:10]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable
  (was, 2023-09-06, similarity 0.9916):
[0000936395-23-000034:note_history:10]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loans Payable

- added (2024-03-07):
[0000936395-24-000008:note_history:11]
2030 New Term Loan

- added (2024-03-07):
[0000936395-24-000008:note_history:12]
On October 24, 2023, Ciena entered into an Incremental Amendment Agreement to its Credit Agreement to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion maturing on October 24, 2030 (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”). The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.7 million annually, with the remaining balance payable at maturity.

- changed (2024-03-07):
[0000936395-24-000008:note_history:13]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):
  (was, 2023-09-06, similarity 0.9826):
[0000936395-23-000034:note_history:13]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:14]
|  |  | January 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (4,934) |  |  | $ | (6,157) |  |  | $ | 1,158,909 |  |  | $ | 1,159,371 |  |
  (was, 2023-09-06, similarity 0.9776):
[0000936395-23-000034:note_history:14]
|  |  | July 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 670,478 |  |  | $ | (687) |  |  | $ | (1,286) |  |  | $ | 668,505 |  |  | $ | 673,010 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:15]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $6.2 million as of January 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.2 million during the first three months of fiscal 2024.
  (was, 2023-09-06, similarity 0.8593):
[0000936395-23-000034:note_history:15]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.4 million as of July 29, 2023 and $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.5 million and $0.4 million during the first nine months of fiscal 2023 and fiscal 2022, respectively.

- changed (2024-03-07):
[0000936395-24-000008:note_history:16]
As of January 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-09-06, similarity 0.9155):
[0000936395-23-000034:note_history:16]
As of July 29, 2023, the estimated fair value of the 2025 Term Loan was $668.8 million. Ciena’s 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- added (2024-03-07):
[0000936395-24-000008:note_history:17]
Refinanced Term Loans

- added (2024-03-07):
[0000936395-24-000008:note_history:18]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the 2025 Term Loan (as defined below) and the 2030 Term Loan (as defined below), together the Refinanced Term Loans, including accrued interest.

- added (2024-03-07):
[0000936395-24-000008:note_history:19]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace LIBOR with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million for the first three months of fiscal 2023.

- changed (2024-03-07):
[0000936395-24-000008:note_history:20]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was nominal for the first three months of fiscal 2023.
  (was, 2023-09-06, similarity 0.7482):
[0000936395-23-000034:note_history:20]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended (the “Credit Agreement”), by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan are intended to be used for general corporate purposes.

- changed (2024-03-07):
[0000936395-24-000008:note_history:21]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).
  (was, 2023-09-06, similarity 0.9812):
[0000936395-23-000034:note_history:21]
On January 18, 2022, Ciena entered into an Indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

- changed (2024-03-07):
[0000936395-24-000008:note_history:22]
|  |  | January 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (4,091) |  |  | $ | 395,909 |  |  | $ | 395,735 |  |  |  |
  (was, 2023-09-06, similarity 0.9148):
[0000936395-23-000034:note_history:22]
|  |  | July 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,438) |  |  | $ | 395,562 |  |  | $ | 395,045 |  |  |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:23]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.1 million as of January 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.2 million during both the first three months of fiscal 2024 and fiscal 2023.
  (was, 2023-09-06, similarity 0.7611):
[0000936395-23-000034:note_history:23]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.3 million as of July 29, 2023 and $1.7 million at October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was approximately $0.5 million during the first nine months of each of fiscal 2023 and fiscal 2022. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

- changed (2024-03-07):
[0000936395-24-000008:note_history:24]
As of January 27, 2024, the estimated fair value of the 2030 Notes was $363.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2023-09-06, similarity 0.8854):
[0000936395-23-000034:note_history:24]
As of July 29, 2023, the estimated fair value of the 2030 Term Loan was $500.0 million. Ciena’s 2030 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

- removed (2024-03-07):
[0000936395-23-000034:note_history:25]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

- removed (2024-03-07):
[0000936395-23-000034:note_history:26]
On January 19, 2023, in connection with the Incremental Agreement (as defined below) to the Credit Agreement (as defined below), the Credit Agreement was amended to replace LIBOR with SOFR for the 2025 Term Loan in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform.

- removed (2024-03-07):
[0000936395-23-000034:note_history:27]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

- removed (2024-03-07):
[0000936395-23-000034:note_history:28]
The Incremental Agreement amends the Credit Agreement and provides that the 2030 Term Loan will, among other things:

- removed (2024-03-07):
[0000936395-23-000034:note_history:29]
•mature on January 19, 2030;

- removed (2024-03-07):
[0000936395-23-000034:note_history:30]
•amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2030 Term Loan as of January 19, 2023, or $1.25 million, with the balance payable at maturity;

- removed (2024-03-07):
[0000936395-23-000034:note_history:31]
•be subject to mandatory prepayment on the same basis as the 2025 Term Loan, including on the occurrence of certain specified events such as asset sales, debt issuances, and receipt of annual Excess Cash Flow (as defined in the Credit Agreement);

- removed (2024-03-07):
[0000936395-23-000034:note_history:32]
•bear interest, at Ciena’s election, at a per annum rate equal to (a) SOFR (subject to a floor of 0.00%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.50%; and

- removed (2024-03-07):
[0000936395-23-000034:note_history:33]
•be repayable at any time at Ciena’s election, provided that repayment of the 2030 Term Loan with proceeds of certain indebtedness prior to July 19, 2023 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.

- removed (2024-03-07):
[0000936395-23-000034:note_history:34]
Except as amended by the Incremental Agreement, the remaining terms of the Credit Agreement remain in full force and effect.

- removed (2024-03-07):
[0000936395-23-000034:note_history:35]
|  |  | July 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 498,750 |  |  | $ | (2,308) |  |  | $ | (4,679) |  |  | $ | 491,763 |  |  |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:36]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2030 Term Loan totaled $4.7 million as of July 29, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense and was $0.4 million during the first nine months of fiscal 2023. The carrying value of the 2030 Term Loan listed above is also net of any unamortized debt discounts.

- removed (2024-03-07):
[0000936395-23-000034:note_history:37]
As of July 29, 2023, the estimated fair value of the 2030 Notes was $350.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.
ABL CREDIT FACILITYOn February 10, 2023, Ciena modified its senior secured asset-backed revolving credit facility (the “ABL Credit Facility”), which provides for a total commitment of $300.0 million to extend its maturity date to September 28, 2025. Other terms of the ABL Credit Facility remain unchanged.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:38]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):
  (was, 2023-09-06, similarity 0.9964):
[0000936395-23-000034:note_history:38]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTSAs of the dates indicated, investments are comprised of the following (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:39]
|  | January 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 141,947 |  |  | $ | 759 |  |  | $ | (82) |  |  | $ | 142,624 |  |
| Corporate debt securities | 57,604 |  |  | 40 |  |  | (25) |  |  | 57,619 |  |
| Time deposits | 144,106 |  |  | 20 |  |  | — |  |  | 144,126 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |
| Included in cash equivalents | $ | 133,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 133,829 |  |
| Included in short-term investments | 106,603 |  |  | 143 |  |  | (68) |  |  | 106,678 |  |
| Included in long-term investments | 103,225 |  |  | 676 |  |  | (39) |  |  | 103,862 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |
  (was, 2023-09-06, similarity 0.9897):
[0000936395-23-000034:note_history:39]
|  | July 29, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 94,715 |  |  | $ | 1 |  |  | $ | (976) |  |  | $ | 93,740 |  |
| Corporate debt securities | 63,401 |  |  | 2 |  |  | (155) |  |  | 63,248 |  |
| Time deposits | 80,854 |  |  | 1 |  |  | (12) |  |  | 80,843 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |
| Included in cash equivalents | $ | 74,890 |  |  | $ | — |  |  | $ | — |  |  | $ | 74,890 |  |
| Included in short-term investments | 142,743 |  |  | 4 |  |  | (904) |  |  | 141,843 |  |
| Included in long-term investments | 21,337 |  |  | — |  |  | (239) |  |  | 21,098 |  |
|  | $ | 238,970 |  |  | $ | 4 |  |  | $ | (1,143) |  |  | $ | 237,831 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:40]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
  (was, 2023-09-06, similarity 0.9952):
[0000936395-23-000034:note_history:40]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:41]
The following table summarizes the final legal maturities of debt investments as of January 27, 2024 (in thousands):
  (was, 2023-09-06, similarity 0.9772):
[0000936395-23-000034:note_history:41]
The following table summarizes the final legal maturities of debt investments as of July 29, 2023 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:42]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):
  (was, 2023-09-06, similarity 0.9826):
[0000936395-23-000034:note_history:42]
The net carrying value of the 2030 Term Loan was comprised of the following as of the date indicated (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:43]
|  |  | January 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (4,934) |  |  | $ | (6,157) |  |  | $ | 1,158,909 |  |  | $ | 1,159,371 |  |
  (was, 2023-09-06, similarity 0.9776):
[0000936395-23-000034:note_history:43]
|  |  | July 29, 2023 |  | October 29, 2022 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 670,478 |  |  | $ | (687) |  |  | $ | (1,286) |  |  | $ | 668,505 |  |  | $ | 673,010 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:44]
|  |  | January 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (4,091) |  |  | $ | 395,909 |  |  | $ | 395,735 |  |  |  |
  (was, 2023-09-06, similarity 0.9148):
[0000936395-23-000034:note_history:44]
|  |  | July 29, 2023 |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,438) |  |  | $ | 395,562 |  |  | $ | 395,045 |  |  |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:45]
The net carrying value of the 2025 Term Loan was comprised of the following as of the dates indicated (in thousands):

- removed (2024-03-07):
[0000936395-23-000034:note_history:46]
|  |  | July 29, 2023 |  |  |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Term Loan |  | $ | 498,750 |  |  | $ | (2,308) |  |  | $ | (4,679) |  |  | $ | 491,763 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:47]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2023-09-06, similarity 0.8934):
[0000936395-23-000034:note_history:47]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:48]
|  | Quarter Ended January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
  (was, 2023-09-06, similarity 0.9798):
[0000936395-23-000034:note_history:48]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:49]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
  (was, 2023-09-06, similarity 0.9798):
[0000936395-23-000034:note_history:49]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:50]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2023-09-06, similarity 0.9388):
[0000936395-23-000034:note_history:50]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:51]
|  |  | Quarter Ended |  |  |
|  |  | January 27, |  | January 28, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  |  |
| EMEA |  | 207,413 |  |  | 152,804 |  |  |  |  |  |
| APAC |  | 112,098 |  |  | 138,621 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  |  |
  (was, 2023-09-06, similarity 0.7673):
[0000936395-23-000034:note_history:51]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 749,479 |  |  | $ | 617,366 |  |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |
| EMEA |  | 152,834 |  |  | 124,185 |  |  | 479,053 |  |  | 420,075 |  |
| APAC |  | 165,573 |  |  | 126,430 |  |  | 469,075 |  |  | 328,226 |  |
| Total revenue by geographic distribution |  | $ | 1,067,886 |  |  | $ | 867,981 |  |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:52]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2023-09-06, similarity 0.952):
[0000936395-23-000034:note_history:52]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2024-03-07):
[0000936395-24-000008:note_history:53]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cloud provider A | $ | 166,008 |  |  | n/a |  |  |  |  |
| Cloud provider B | 109,098 |  |  | 121,327 |  |  |  |  |  |
| AT&T | n/a |  | 149,981 |  |  |  |  |  |
| Total | $ | 275,106 |  |  | $ | 271,308 |  |  |  |  |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:54]
|  | Nine Months Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:55]
|  | Nine months ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:56]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 124,897 |  |  | n/a |  | $ | 369,678 |  |  | n/a |
| AT&T | n/a |  | 100,293 |  |  | $ | 357,382 |  |  | 314,358 |  |
| Verizon | n/a |  | 108,495 |  |  | n/a |  | 273,158 |  |
| Total | $ | 124,897 |  |  | $ | 208,788 |  |  | $ | 727,060 |  |  | $ | 587,516 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:57]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.
  (was, 2023-09-06, similarity 0.7671):
[0000936395-23-000034:note_history:57]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ across Ciena’s product lines, resulting in different economic risk profiles for each line.

- changed (2024-03-07):
[0000936395-24-000008:note_history:58]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):
  (was, 2023-09-06, similarity 0.8934):
[0000936395-23-000034:note_history:58]
The tables below set forth Ciena’s disaggregated revenue for the periods indicated (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:59]
|  | Quarter Ended January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
  (was, 2023-09-06, similarity 0.9798):
[0000936395-23-000034:note_history:59]
|  | Quarter Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 718,997 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 718,997 |  |
| Routing and Switching | 127,563 |  |  | — |  |  | — |  |  | — |  |  | 127,563 |  |
| Platform Software and Services | — |  |  | 78,880 |  |  | — |  |  | — |  |  | 78,880 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,167 |  |  | — |  |  | 13,167 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,887 |  |  | 72,887 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,840 |  |  | 46,840 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,552 |  |  | 9,552 |  |
| Total revenue by product line | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 846,560 |  |  | $ | 15,980 |  |  | $ | 2,832 |  |  | $ | 11,886 |  |  | $ | 877,258 |  |
| Services transferred over time | — |  |  | 62,900 |  |  | 10,335 |  |  | 117,393 |  |  | 190,628 |  |
| Total revenue by timing of revenue recognition | $ | 846,560 |  |  | $ | 78,880 |  |  | $ | 13,167 |  |  | $ | 129,279 |  |  | $ | 1,067,886 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:60]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
  (was, 2023-09-06, similarity 0.9798):
[0000936395-23-000034:note_history:60]
|  | Quarter Ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 563,837 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 563,837 |  |
| Routing and Switching | 100,741 |  |  | — |  |  | — |  |  | — |  |  | 100,741 |  |
| Platform Software and Services | — |  |  | 63,483 |  |  | — |  |  | — |  |  | 63,483 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 17,342 |  |  | — |  |  | 17,342 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 72,760 |  |  | 72,760 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 38,704 |  |  | 38,704 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,114 |  |  | 11,114 |  |
| Total revenue by product line | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 664,578 |  |  | $ | 15,230 |  |  | $ | 4,632 |  |  | $ | 9,408 |  |  | $ | 693,848 |  |
| Services transferred over time | — |  |  | 48,253 |  |  | 12,710 |  |  | 113,170 |  |  | 174,133 |  |
| Total revenue by timing of revenue recognition | $ | 664,578 |  |  | $ | 63,483 |  |  | $ | 17,342 |  |  | $ | 122,578 |  |  | $ | 867,981 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:61]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2023-09-06, similarity 0.9993):
[0000936395-23-000034:note_history:61]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2024-03-07):
[0000936395-24-000008:note_history:62]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):
  (was, 2023-09-06, similarity 0.9388):
[0000936395-23-000034:note_history:62]
For the periods indicated, Ciena’s geographic distribution of revenue was as follows (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:63]
|  |  | Quarter Ended |  |  |
|  |  | January 27, |  | January 28, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  |  |
| EMEA |  | 207,413 |  |  | 152,804 |  |  |  |  |  |
| APAC |  | 112,098 |  |  | 138,621 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  |  |
  (was, 2023-09-06, similarity 0.7673):
[0000936395-23-000034:note_history:63]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  |  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 749,479 |  |  | $ | 617,366 |  |  | $ | 2,308,934 |  |  | $ | 1,913,350 |  |
| EMEA |  | 152,834 |  |  | 124,185 |  |  | 479,053 |  |  | 420,075 |  |
| APAC |  | 165,573 |  |  | 126,430 |  |  | 469,075 |  |  | 328,226 |  |
| Total revenue by geographic distribution |  | $ | 1,067,886 |  |  | $ | 867,981 |  |  | $ | 3,257,062 |  |  | $ | 2,661,651 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:64]
Ciena’s revenue includes $677.6 million and $693.6 million of United States revenue for the first quarter of fiscal 2024 and 2023, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.
  (was, 2023-09-06, similarity 0.7263):
[0000936395-23-000034:note_history:64]
Ciena’s revenue includes $685.8 million and $574.3 million of United States revenue for the third quarter of fiscal 2023 and 2022, respectively. For the nine months ended July 29, 2023 and July 30, 2022, United States revenue was $2.1 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods indicated in the above table.

- changed (2024-03-07):
[0000936395-24-000008:note_history:65]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):
  (was, 2023-09-06, similarity 0.952):
[0000936395-23-000034:note_history:65]
For the periods indicated, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

- added (2024-03-07):
[0000936395-24-000008:note_history:66]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cloud provider A | $ | 166,008 |  |  | n/a |  |  |  |  |
| Cloud provider B | 109,098 |  |  | 121,327 |  |  |  |  |  |
| AT&T | n/a |  | 149,981 |  |  |  |  |  |
| Total | $ | 275,106 |  |  | $ | 271,308 |  |  |  |  |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:67]
The cloud providers noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for the period presented.
  (was, 2023-09-06, similarity 0.7748):
[0000936395-23-000034:note_history:67]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services for each of the periods presented. The other customers identified above purchased products and services from each of Ciena’s operating segments for each of the periods presented.

- changed (2024-03-07):
[0000936395-24-000008:note_history:68]
•Networking Platforms revenue reflects sales of Ciena’s Optical Networking and Routing and Switching product lines.
  (was, 2023-09-06, similarity 0.8814):
[0000936395-23-000034:note_history:68]
•Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Routing and Switching product lines.

- changed (2024-03-07):
[0000936395-24-000008:note_history:69]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the WaveLogic 5 Nano (WL5n) 100G-400G coherent pluggable transceivers.
  (was, 2023-09-06, similarity 0.8124):
[0000936395-23-000034:note_history:69]
•Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line includes the WL5n 100G-400G

- added (2024-03-07):
[0000936395-24-000008:note_history:70]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and our microplug Optical Line Terminal (OLT) transceiver. This product line also includes Ciena’s WaveRouterTM product, which was introduced during fiscal 2023, for which there have been no material sales to date.

- added (2024-03-07):
[0000936395-24-000008:note_history:71]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more proactive visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, which was previously referred to as “Manage, Control and Plan (MCP),” and its OneControl Unified Management System, as well as planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2024-03-07):
[0000936395-24-000008:note_history:72]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), multi-cloud orchestration (MCO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2023-09-06, similarity 0.9747):
[0000936395-23-000034:note_history:72]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2024-03-07):
[0000936395-24-000008:note_history:73]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.
  (was, 2023-09-06, similarity 0.9937):
[0000936395-23-000034:note_history:73]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations in which revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- changed (2024-03-07):
[0000936395-24-000008:note_history:74]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.
  (was, 2023-09-06, similarity 0.9868):
[0000936395-23-000034:note_history:74]
Ciena’s Global Services are considered a distinct performance obligation for which revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is also recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

- changed (2024-03-07):
[0000936395-24-000008:note_history:75]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):
  (was, 2023-09-06, similarity 0.9244):
[0000936395-23-000034:note_history:75]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers as of the dates indicated (in thousands):

- changed (2024-03-07):
[0000936395-24-000008:note_history:76]
|  |  | Balance at January 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 865,239 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,572 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 243,270 |  |  | $ | 228,460 |  |
  (was, 2023-09-06, similarity 0.9851):
[0000936395-23-000034:note_history:76]
|  |  | Balance at July 29, 2023 |  | Balance at October 29, 2022 |
| Accounts receivable, net |  | $ | 997,373 |  |  | $ | 920,772 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 142,305 |  |  | $ | 156,039 |  |
| Deferred revenue |  | $ | 259,977 |  |  | $ | 200,235 |  |

- changed (2024-03-07):
[0000936395-24-000008:note_history:77]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 10 below.
  (was, 2023-09-06, similarity 0.9981):
[0000936395-23-000034:note_history:77]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Condensed Consolidated Balance Sheets. See Note 11 below.

- changed (2024-03-07):
[0000936395-24-000008:note_history:78]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $70.6 million and $67.9 million of revenue during the first three months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance at October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 27, 2024 and January 28, 2023.
  (was, 2023-09-06, similarity 0.9636):
[0000936395-23-000034:note_history:78]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $119.8 million and $98.9 million of revenue during the first nine months of fiscal 2023 and 2022, respectively, that was included in the deferred revenue balance as of October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 29, 2023 and July 30, 2022.

- changed (2024-03-07):
[0000936395-24-000008:note_history:79]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.8 million and $30.2 million as of January 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $7.7 million and $7.2 million during the first three months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.
  (was, 2023-09-06, similarity 0.9483):
[0000936395-23-000034:note_history:79]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $31.4 million and $39.7 million as of July 29, 2023 and October 29, 2022, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets. The amortization expense associated with these costs was $26.0 million and $20.5 million during the first nine months of fiscal 2023 and 2022, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

- changed (2024-03-07):
[0000936395-24-000008:note_history:80]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 27, 2024, the aggregate amount of RPO was $1.7 billion. As of January 27, 2024, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next 12 months.
  (was, 2023-09-06, similarity 0.9823):
[0000936395-23-000034:note_history:80]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 29, 2023, the aggregate amount of RPO was $2.1 billion. As of July 29, 2023, Ciena expects approximately 84% of the RPO to be recognized as revenue within the next 12 months.

- removed (2024-03-07):
[0000936395-23-000034:note_history:81]
|  | Nine Months Ended July 29, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,239,180 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,239,180 |  |
| Routing and Switching | 377,378 |  |  | — |  |  | — |  |  | — |  |  | 377,378 |  |
| Platform Software and Services | — |  |  | 221,768 |  |  | — |  |  | — |  |  | 221,768 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 49,139 |  |  | — |  |  | 49,139 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 213,938 |  |  | 213,938 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,901 |  |  | 120,901 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 34,758 |  |  | 34,758 |  |
| Total revenue by product line | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,616,558 |  |  | $ | 48,290 |  |  | $ | 14,143 |  |  | $ | 36,553 |  |  | $ | 2,715,544 |  |
| Services transferred over time | — |  |  | 173,478 |  |  | 34,996 |  |  | 333,044 |  |  | 541,518 |  |
| Total revenue by timing of revenue recognition | $ | 2,616,558 |  |  | $ | 221,768 |  |  | $ | 49,139 |  |  | $ | 369,597 |  |  | $ | 3,257,062 |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:82]
|  | Nine months ended July 30, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,730,066 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,730,066 |  |
| Routing and Switching | 295,638 |  |  | — |  |  | — |  |  | — |  |  | 295,638 |  |
| Platform Software and Services | — |  |  | 205,557 |  |  | — |  |  | — |  |  | 205,557 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 55,334 |  |  | — |  |  | 55,334 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 219,270 |  |  | 219,270 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 120,504 |  |  | 120,504 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,282 |  |  | 35,282 |  |
| Total revenue by product line | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,025,704 |  |  | $ | 66,655 |  |  | $ | 17,442 |  |  | $ | 31,368 |  |  | $ | 2,141,169 |  |
| Services transferred over time | — |  |  | 138,902 |  |  | 37,892 |  |  | 343,688 |  |  | 520,482 |  |
| Total revenue by timing of revenue recognition | $ | 2,025,704 |  |  | $ | 205,557 |  |  | $ | 55,334 |  |  | $ | 375,056 |  |  | $ | 2,661,651 |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:83]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 29, |  | July 30, |  | July 29, |  | July 30, |
|  | 2023 |  | 2022 |  | 2023 |  | 2022 |
| Web-scale provider | $ | 124,897 |  |  | n/a |  | $ | 369,678 |  |  | n/a |
| AT&T | n/a |  | 100,293 |  |  | $ | 357,382 |  |  | 314,358 |  |
| Verizon | n/a |  | 108,495 |  |  | n/a |  | 273,158 |  |
| Total | $ | 124,897 |  |  | $ | 208,788 |  |  | $ | 727,060 |  |  | $ | 587,516 |  |

- removed (2024-03-07):
[0000936395-23-000034:note_history:84]
coherent pluggable transceivers. This product line also includes the Z-Series Packet-Optical Platform and Optical Microsystems products.

- removed (2024-03-07):
[0000936395-23-000034:note_history:85]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and passive optical network (“PON”) routing and switching portfolio products from our recent acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) respectively, during the first quarter of fiscal 2023. This product line also includes Ciena’s WaveRouter® product, which was introduced during the second quarter of fiscal 2023, for which there have been no sales to date.

- removed (2024-03-07):
[0000936395-23-000034:note_history:86]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools, and applications to assist customers in managing their networks, including by creating more efficient operations and more

- removed (2024-03-07):
[0000936395-23-000034:note_history:87]
proactive visibility into their networks. Ciena’s platform software includes its Manage, Control and Plan (“MCP”) domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2024-03-07):
[0000936395-24-000008:note_history:88]
SUBSEQUENT EVENTS
Stock Repurchase Program
From the end of the first quarter of fiscal 2024 through March 1, 2024, Ciena repurchased an additional 0.3 million shares of its common stock for an aggregate purchase price of $19.2 million at an average price of $55.44 per share, inclusive of repurchases pending settlement. As of March 1, 2024, Ciena has repurchased an aggregate of 15.1 million shares and has an aggregate of $198.8 million of authorized funds remaining under its stock repurchase program.
  (was, 2023-09-06, similarity 0.9154):
[0000936395-23-000034:note_history:88]
SUBSEQUENT EVENTSStock Repurchase ProgramFrom the end of the third quarter of fiscal 2023 through September 1, 2023, Ciena repurchased an additional 0.9 million shares of its common stock, for an aggregate purchase price of $38.8 million at an average price of $41.67 per share, inclusive of repurchases pending settlement. As of September 1, 2023, Ciena has repurchased an aggregate of 10.8 million shares and has an aggregate of $400.0 million of authorized funds remaining under its stock repurchase program.
