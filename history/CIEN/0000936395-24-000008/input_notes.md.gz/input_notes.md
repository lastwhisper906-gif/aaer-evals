# CIEN notes — 0000936395-24-000008


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-24-000008:notes:1]
[same as prior period, unchanged from 0000936395-23-000034:notes:1]

[0000936395-24-000008:notes:2]
[same as prior period, unchanged from 0000936395-23-000034:notes:2]

[0000936395-24-000008:notes:3]
In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations of Ciena for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with GAAP have been condensed or omitted pursuant to SEC rules and regulations. The Condensed Consolidated Balance Sheet as of October 28, 2023 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s Annual Report on Form 10-K for the fiscal year ended October 28, 2023 (the “2023 Annual Report”).
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July, and October, respectively, of each year. Fiscal 2024 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2023 was a 52-week fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-24-000008:notes:4]
SIGNIFICANT ACCOUNTING POLICIES
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of the 2023 Annual Report.

[0000936395-24-000008:notes:5]
Newly Issued Accounting Standards - Effective

[0000936395-24-000008:notes:6]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 was effective for Ciena beginning in the first quarter of fiscal 2024 without any material impact on its consolidated financial position, results of operations and related disclosures.

[0000936395-24-000008:notes:7]
[same as prior period, unchanged from 0000936395-23-000034:notes:5]

[0000936395-24-000008:notes:8]
In November 2023, the FASB issued ASU No. 2023-07 (“ASU 2023-07”), Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses. ASU 2023-07 is effective for fiscal years beginning after December 15, 2023 on a retrospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.

[0000936395-24-000008:notes:9]
In December 2023, the FASB issued ASU No. 2023-09 (“ASU 2023-09”), Income Taxes (Topic 740): Improvement to Income Tax Disclosures to enhance the transparency and decision usefulness of income tax disclosures. ASU 2023-09 is effective for annual periods beginning after December 15, 2024; however, early adoption is permitted. ASU 2023-09 allows for 
adoption using either a prospective or retrospective method. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-24-000008:notes:10]
[same as prior period, unchanged from 0000936395-23-000034:notes:7]

[0000936395-24-000008:notes:11]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-24-000008:notes:12]
The tables below set forth Ciena’s disaggregated revenue for the respective periods (in thousands):

[0000936395-24-000008:notes:13]
|  | Quarter Ended January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 695,849 |  |
| Routing and Switching | 111,387 |  |  | — |  |  | — |  |  | — |  |  | 111,387 |  |
| Platform Software and Services | — |  |  | 89,745 |  |  | — |  |  | — |  |  | 89,745 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 13,942 |  |  | — |  |  | 13,942 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,115 |  |  | 74,115 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 42,723 |  |  | 42,723 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,948 |  |  | 9,948 |  |
| Total revenue by product line | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 807,236 |  |  | $ | 27,694 |  |  | $ | 1,069 |  |  | $ | 9,638 |  |  | $ | 845,637 |  |
| Services transferred over time | — |  |  | 62,051 |  |  | 12,873 |  |  | 117,148 |  |  | 192,072 |  |
| Total revenue by timing of revenue recognition | $ | 807,236 |  |  | $ | 89,745 |  |  | $ | 13,942 |  |  | $ | 126,786 |  |  | $ | 1,037,709 |  |

[0000936395-24-000008:notes:14]
|  | Quarter Ended January 28, 2023 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 735,634 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 735,634 |  |
| Routing and Switching | 119,505 |  |  | — |  |  | — |  |  | — |  |  | 119,505 |  |
| Platform Software and Services | — |  |  | 73,445 |  |  | — |  |  | — |  |  | 73,445 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,405 |  |  | — |  |  | 15,405 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 67,891 |  |  | 67,891 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,575 |  |  | 34,575 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 10,066 |  |  | 10,066 |  |
| Total revenue by product line | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 855,139 |  |  | $ | 18,864 |  |  | $ | 3,982 |  |  | $ | 9,255 |  |  | $ | 887,240 |  |
| Services transferred over time | — |  |  | 54,581 |  |  | 11,423 |  |  | 103,277 |  |  | 169,281 |  |
| Total revenue by timing of revenue recognition | $ | 855,139 |  |  | $ | 73,445 |  |  | $ | 15,405 |  |  | $ | 112,532 |  |  | $ | 1,056,521 |  |

[0000936395-24-000008:notes:15]
Ciena reports its sales geographically using the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer, or market vertical. These teams include sales management, account salespersons, and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-24-000008:notes:16]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-24-000008:notes:17]
|  |  | Quarter Ended |  |  |
|  |  | January 27, |  | January 28, |  |  |  |  |
|  |  | 2024 |  | 2023 |  |  |  |  |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  |  |
| EMEA |  | 207,413 |  |  | 152,804 |  |  |  |  |  |
| APAC |  | 112,098 |  |  | 138,621 |  |  |  |  |  |
| Total revenue by geographic distribution |  | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  |  |

[0000936395-24-000008:notes:18]
Ciena’s revenue includes $677.6 million and $693.6 million of United States revenue for the first quarter of fiscal 2024 and 2023, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-24-000008:notes:19]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-24-000008:notes:20]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Cloud provider A | $ | 166,008 |  |  | n/a |  |  |  |  |
| Cloud provider B | 109,098 |  |  | 121,327 |  |  |  |  |  |
| AT&T | n/a |  | 149,981 |  |  |  |  |  |
| Total | $ | 275,106 |  |  | $ | 271,308 |  |  |  |  |  |

[0000936395-24-000008:notes:21]
[same as prior period, unchanged from 0000936395-23-000034:notes:20]

[0000936395-24-000008:notes:22]
[same as prior period, unchanged from 0000936395-23-000034:notes:21]

[0000936395-24-000008:notes:23]
The cloud providers noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. AT&T purchased products and services from each of Ciena’s operating segments for the period presented.

[0000936395-24-000008:notes:24]
•Networking Platforms revenue reflects sales of Ciena’s Optical Networking and Routing and Switching product lines.

[0000936395-24-000008:notes:25]
•Optical Networking - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line also includes the WaveLogic 5 Nano (WL5n) 100G-400G coherent pluggable transceivers.

[0000936395-24-000008:notes:26]
•Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent IP networking platforms, the 8700 Packetwave Platform, and virtualization software. This product line also includes SD-Edge software and our microplug Optical Line Terminal (OLT) transceiver. This product line also includes Ciena’s WaveRouterTM product, which was introduced during fiscal 2023, for which there have been no material sales to date.

[0000936395-24-000008:notes:27]
[same as prior period, unchanged from 0000936395-23-000034:notes:27]

[0000936395-24-000008:notes:28]
•Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and providing more proactive visibility into their networks. Ciena’s platform software includes its Navigator Network Control SuiteTM (“Navigator NCS”) domain controller solution, its suite of Navigator NCS applications, which was previously referred to as “Manage, Control and Plan (MCP),” and its OneControl Unified Management System, as well as planning tools and legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-24-000008:notes:29]
•Blue Planet Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), multi-cloud orchestration (MCO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-24-000008:notes:30]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-24-000008:notes:31]
[same as prior period, unchanged from 0000936395-23-000034:notes:32]

[0000936395-24-000008:notes:32]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-24-000008:notes:33]
[same as prior period, unchanged from 0000936395-23-000034:notes:34]

[0000936395-24-000008:notes:34]
The following table provides information about receivables, contract assets, and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-24-000008:notes:35]
|  |  | Balance at January 27, 2024 |  | Balance at October 28, 2023 |
| Accounts receivable, net |  | $ | 865,239 |  |  | $ | 1,003,876 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 151,572 |  |  | $ | 150,312 |  |
| Deferred revenue |  | $ | 243,270 |  |  | $ | 228,460 |  |

[0000936395-24-000008:notes:36]
Ciena’s contract assets represent unbilled accounts receivable, net where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other on the Condensed Consolidated Balance Sheets. See Note 10 below.

[0000936395-24-000008:notes:37]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $70.6 million and $67.9 million of revenue during the first three months of fiscal 2024 and 2023, respectively, that was included in the deferred revenue balance at October 28, 2023 and October 29, 2022, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the three months ended January 27, 2024 and January 28, 2023.

[0000936395-24-000008:notes:38]
[same as prior period, unchanged from 0000936395-23-000034:notes:39]

[0000936395-24-000008:notes:39]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $27.8 million and $30.2 million as of January 27, 2024 and October 28, 2023, respectively. Capitalized contract acquisition costs were included in (i) prepaid expenses and other and (ii) other long-term assets on the Condensed Consolidated Balance Sheets. The amortization expense associated with these costs was $7.7 million and $7.2 million during the first three months of fiscal 2024 and 2023, respectively, and was included in selling and marketing expense on the Condensed Consolidated Statements of Operations.

[0000936395-24-000008:notes:40]
[same as prior period, unchanged from 0000936395-23-000034:notes:41]

[0000936395-24-000008:notes:41]
Remaining performance obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 27, 2024, the aggregate amount of RPO was $1.7 billion. As of January 27, 2024, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next 12 months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-24-000008:notes:42]
[same as prior period, unchanged from 0000936395-23-000034:notes:43]

[0000936395-24-000008:notes:43]
|  | January 27,2024 |  | October 28,2023 |
| Products | $ | 24,415 |  |  | $ | 28,353 |  |
| Services | 218,855 |  |  | 200,107 |  |
| Total deferred revenue | 243,270 |  |  | 228,460 |  |
| Less current portion | (166,714) |  |  | (154,419) |  |
| Long-term deferred revenue | $ | 76,556 |  |  | $ | 74,041 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-24-000008:notes:44]
[same as prior period, unchanged from 0000936395-23-000034:notes:55]

[0000936395-24-000008:notes:45]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to align its workforce and costs with market opportunities, product development, and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets, for the three months ended January 27, 2024 (in thousands):

[0000936395-24-000008:notes:46]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 28, 2023 | $ | 1,913 |  |  | $ | — |  |  | $ | 1,913 |  |
| Charges | 2,861 |  | (1) | 2,110 |  | (2) | 4,971 |  |
| Cash payments | (4,058) |  |  | (2,110) |  |  | (6,168) |  |
| Balance at January 27, 2024 | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Current restructuring liabilities | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |

[0000936395-24-000008:notes:47]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 27, 2024 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-24-000008:notes:48]
[same as prior period, unchanged from 0000936395-23-000034:notes:59]

[0000936395-24-000008:notes:49]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on the Condensed Consolidated Balance Sheets for the three months ended January 28, 2023 (in thousands):

[0000936395-24-000008:notes:50]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Charges | 704 |  | (1) | 3,594 |  | (2) | 4,298 |  |
| Cash payments | (1,498) |  |  | (8,214) |  |  | (9,712) |  |
| Balance at January 28, 2023 | $ | 421 |  |  | $ | — |  |  | $ | 421 |  |
| Current restructuring liabilities | $ | 421 |  |  | $ | — |  |  | $ | 421 |  |

[0000936395-24-000008:notes:51]
(1) Reflects employee costs associated with workforce reductions during the three months ended January 28, 2023 as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes.

[0000936395-24-000008:notes:52]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-24-000008:notes:53]
[same as prior period, unchanged from 0000936395-23-000034:notes:63]

[0000936395-24-000008:notes:54]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Interest income | $ | 15,177 |  |  | $ | 7,121 |  |  |  |  |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 3,112 |  |  | (1,769) |  |  |  |  |  |
| Foreign currency exchange losses | (9,192) |  |  | (1,889) |  |  |  |  |  |
| Gain on cost method equity investments, net | — |  |  | 26,455 |  |  |  |  |  |
| Other | 1,553 |  |  | 2,055 |  |  |  |  |  |
| Interest and other income, net | $ | 10,650 |  |  | $ | 31,973 |  |  |  |  |  |

[0000936395-24-000008:notes:55]
During the first quarter of fiscal 2023, the acquisition of Tibit Communications, Inc. (“Tibit”) by Ciena triggered the remeasurement of Ciena’s previously held investment in Tibit to fair value, which resulted in Ciena recognizing a gain on its cost method equity investment of $26.5 million.

[0000936395-24-000008:notes:56]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $9.2 million and $1.9 million during the first three months of fiscal 2024 and fiscal 2023, respectively, in foreign currency exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income, net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These 
forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net, on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2024, Ciena recorded gains of $3.1 million from non-hedge designated foreign currency forward contracts. During the first three months of fiscal 2023, Ciena recorded losses of $1.8 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-24-000008:notes:57]
INCOME TAXES
The effective tax rate for the quarter ended January 27, 2024 was higher than the effective tax rate for the quarter ended January 28, 2023, primarily due to the tax benefit of a gain on a cost method equity investment in the first quarter of fiscal 2023.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-24-000008:notes:58]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-24-000008:notes:59]
|  | January 27, 2024 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 141,947 |  |  | $ | 759 |  |  | $ | (82) |  |  | $ | 142,624 |  |
| Corporate debt securities | 57,604 |  |  | 40 |  |  | (25) |  |  | 57,619 |  |
| Time deposits | 144,106 |  |  | 20 |  |  | — |  |  | 144,126 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |
| Included in cash equivalents | $ | 133,829 |  |  | $ | — |  |  | $ | — |  |  | $ | 133,829 |  |
| Included in short-term investments | 106,603 |  |  | 143 |  |  | (68) |  |  | 106,678 |  |
| Included in long-term investments | 103,225 |  |  | 676 |  |  | (39) |  |  | 103,862 |  |
|  | $ | 343,657 |  |  | $ | 819 |  |  | $ | (107) |  |  | $ | 344,369 |  |

[0000936395-24-000008:notes:60]
|  | October 28, 2023 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 170,260 |  |  | $ | 28 |  |  | $ | (379) |  |  | $ | 169,909 |  |
| Corporate debt securities | 59,683 |  |  | 1 |  |  | (115) |  |  | 59,569 |  |
| Time deposits | 138,830 |  |  | 4 |  |  | (5) |  |  | 138,829 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |
| Included in cash equivalents | $ | 129,276 |  |  | $ | — |  |  | $ | — |  |  | $ | 129,276 |  |
| Included in short-term investments | 105,042 |  |  | 4 |  |  | (293) |  |  | 104,753 |  |
| Included in long-term investments | 134,455 |  |  | 29 |  |  | (206) |  |  | 134,278 |  |
|  | $ | 368,773 |  |  | $ | 33 |  |  | $ | (499) |  |  | $ | 368,307 |  |

[0000936395-24-000008:notes:61]
The following table summarizes the final legal maturities of debt investments as of January 27, 2024 (in thousands):

[0000936395-24-000008:notes:62]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 240,433 |  |  | $ | 240,507 |  |
| Due in 1-2 years | 103,224 |  |  | 103,862 |  |
|  | $ | 343,657 |  |  | $ | 344,369 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-24-000008:notes:63]
FAIR VALUE MEASUREMENTS
    As of the dates indicated, the following tables summarize the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-24-000008:notes:64]
|  | January 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 895,909 |  |  | $ | — |  |  | $ | — |  |  | $ | 895,909 |  |
| Bond mutual fund | 156,300 |  |  | — |  |  | — |  |  | 156,300 |  |
| Time deposits | 144,126 |  |  | — |  |  | — |  |  | 144,126 |  |
| Deferred compensation plan assets | 14,614 |  |  | — |  |  | — |  |  | 14,614 |  |
| U.S. government obligations | — |  |  | 142,624 |  |  | — |  |  | 142,624 |  |
| Corporate debt securities | — |  |  | 57,619 |  |  | — |  |  | 57,619 |  |
| Foreign currency forward contracts | — |  |  | 3,020 |  |  | — |  |  | 3,020 |  |
| Interest rate swaps | — |  |  | 12,501 |  |  | — |  |  | 12,501 |  |
| Total assets measured at fair value | $ | 1,210,949 |  |  | $ | 215,764 |  |  | $ | — |  |  | $ | 1,426,713 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 6,184 |  |  | $ | — |  |  | $ | 6,184 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,184 |  |  | $ | — |  |  | $ | 6,184 |  |

[0000936395-24-000008:notes:65]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 661,101 |  |  | $ | — |  |  | $ | — |  |  | $ | 661,101 |  |
| Bond mutual fund | 104,171 |  |  | — |  |  | — |  |  | 104,171 |  |
| Time deposits | 138,829 |  |  | — |  |  | — |  |  | 138,829 |  |
| Deferred compensation plan assets | 11,456 |  |  | — |  |  | — |  |  | 11,456 |  |
| U.S. government obligations | — |  |  | 169,909 |  |  | — |  |  | 169,909 |  |
| Corporate debt securities | — |  |  | 59,569 |  |  | — |  |  | 59,569 |  |
| Foreign currency forward contracts | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Interest rate swaps | — |  |  | 24,953 |  |  | — |  |  | 24,953 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-24-000008:notes:66]
[same as prior period, unchanged from 0000936395-23-000034:notes:76]

[0000936395-24-000008:notes:67]
|  | January 27, 2024 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,183,109 |  |  | $ | 2,929 |  |  | $ | — |  |  | $ | 1,186,038 |  |
| Short-term investments | 13,226 |  |  | 93,452 |  |  | — |  |  | 106,678 |  |
| Prepaid expenses and other | — |  |  | 3,020 |  |  | — |  |  | 3,020 |  |
| Long-term investments | — |  |  | 103,862 |  |  | — |  |  | 103,862 |  |
| Other long-term assets | 14,614 |  |  | 12,501 |  |  | — |  |  | 27,115 |  |
| Total assets measured at fair value | $ | 1,210,949 |  |  | $ | 215,764 |  |  | $ | — |  |  | $ | 1,426,713 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 6,184 |  |  | $ | — |  |  | $ | 6,184 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,184 |  |  | $ | — |  |  | $ | 6,184 |  |

[0000936395-24-000008:notes:68]
|  | October 28, 2023 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 891,788 |  |  | $ | 2,760 |  |  | $ | — |  |  | $ | 894,548 |  |
| Short-term investments | 12,313 |  |  | 92,440 |  |  | — |  |  | 104,753 |  |
| Prepaid expenses and other | — |  |  | 1,119 |  |  | — |  |  | 1,119 |  |
| Long-term investments | — |  |  | 134,278 |  |  | — |  |  | 134,278 |  |
| Other long-term assets | 11,456 |  |  | 24,953 |  |  | — |  |  | 36,409 |  |
| Total assets measured at fair value | $ | 915,557 |  |  | $ | 255,550 |  |  | $ | — |  |  | $ | 1,171,107 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 14,509 |  |  | $ | — |  |  | $ | 14,509 |  |

[0000936395-24-000008:notes:69]
[same as prior period, unchanged from 0000936395-23-000034:notes:79]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-24-000008:notes:70]
[same as prior period, unchanged from 0000936395-23-000034:notes:80]

[0000936395-24-000008:notes:71]
|  | January 27,2024 |  | October 28,2023 |
| Raw materials | $ | 571,666 |  |  | $ | 664,797 |  |
| Work-in-process | 60,644 |  |  | 55,242 |  |
| Finished goods | 369,771 |  |  | 314,168 |  |
| Deferred cost of goods sold | 36,824 |  |  | 66,634 |  |
| Gross inventories | 1,038,905 |  |  | 1,100,841 |  |
| Reserve for inventory excess and obsolescence | (54,019) |  |  | (50,003) |  |
| Inventories, net | $ | 984,886 |  |  | $ | 1,050,838 |  |

[0000936395-24-000008:notes:72]
Ciena has been expanding its manufacturing capacity and had been accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly upon the easing of supply constraints for certain common components. During the first quarter of fiscal 2024 Ciena reduced its raw materials inventory of components due to the consumption of raw materials in excess of purchases. The increase in finished goods inventories resulted primarily from planned fulfillment of customer advance orders for which some deliveries have been rescheduled outside of the first quarter of fiscal 2024.

[0000936395-24-000008:notes:73]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For the periods presented, future demand was calculated using both customer backlog and future forecasted sales. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services, although instances of both cancellation and non-acceptance are rare. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first three months of fiscal 2024, Ciena recorded a provision for inventory excess and obsolescence of $10.4 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-24-000008:notes:74]
[same as prior period, unchanged from 0000936395-23-000034:notes:84]

[0000936395-24-000008:notes:75]
|  | January 27,2024 |  | October 28,2023 |
| Contract assets for unbilled accounts receivable, net | $ | 151,572 |  |  | $ | 150,312 |  |
| Prepaid VAT and other taxes | 87,965 |  |  | 96,724 |  |
| Prepaid expenses | 60,495 |  |  | 58,954 |  |
| Product demonstration equipment, net | 40,294 |  |  | 40,682 |  |
| Capitalized contract acquisition costs | 20,824 |  |  | 23,326 |  |
| Other non-trade receivables | 20,910 |  |  | 33,408 |  |
| Derivative Assets | 3,020 |  |  | 1,118 |  |
| Deferred deployment expense | 2,113 |  |  | 1,170 |  |
|  | $ | 387,193 |  |  | $ | 405,694 |  |

[0000936395-24-000008:notes:76]
Depreciation of product demonstration equipment was $1.9 million during both the first three months of fiscal 2024 and fiscal 2023.

[0000936395-24-000008:notes:77]
[same as prior period, unchanged from 0000936395-23-000034:notes:87]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-24-000008:notes:78]
[same as prior period, unchanged from 0000936395-23-000034:notes:95]

[0000936395-24-000008:notes:79]
|  | January 27,2024 |  | October 28,2023 |
| Compensation, payroll related tax and benefits | $ | 93,937 |  |  | $ | 159,530 |  |
| Warranty | 56,400 |  |  | 57,089 |  |
| Vacation | 29,700 |  |  | 29,503 |  |
| Interest payable | 8,856 |  |  | 4,514 |  |
| Income taxes payable | 8,153 |  |  | 16,341 |  |
| Foreign currency forward contracts | 6,184 |  |  | 14,509 |  |
| Finance lease liabilities | 4,169 |  |  | 3,953 |  |
| Other | 122,511 |  |  | 145,980 |  |
|  | $ | 329,910 |  |  | $ | 431,419 |  |

[0000936395-24-000008:notes:80]
[same as prior period, unchanged from 0000936395-23-000034:notes:97]

[0000936395-24-000008:notes:81]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Three Months Ended January 28, 2023 |  | $ | 45,503 |  |  |  |  | 8,230 |  |  | (5,190) |  |  | $ | 48,543 |  |
| Three Months Ended January 27, 2024 |  | $ | 57,089 |  |  |  |  | 4,841 |  |  | (5,530) |  |  | $ | 56,400 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-24-000008:notes:82]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-24-000008:notes:83]
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-24-000008:notes:84]
As of January 27, 2024 and October 28, 2023, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability in certain currencies for expenses principally related to research and development activities. The notional amount of these contracts was approximately $349.5 million and $367.3 million as of January 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-24-000008:notes:85]
As of January 27, 2024 and October 28, 2023, Ciena had forward contracts designated as net investment hedges to minimize the effect of foreign exchange rate movements on its net investments in foreign operations. The notional amount of these contracts was approximately $48.1 million and $48.0 million as of January 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as net investment hedges.

[0000936395-24-000008:notes:86]
As of January 27, 2024 and October 28, 2023, Ciena had forward contracts in place to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $190.8 million and $226.3 million as of January 27, 2024 and October 28, 2023, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-24-000008:notes:87]
[same as prior period, unchanged from 0000936395-23-000034:notes:103]

[0000936395-24-000008:notes:88]
Ciena is exposed to floating rates of interest on its term loan borrowings (see Note 13 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements.

[0000936395-24-000008:notes:89]
In April 2022, Ciena entered into forward starting interest rate swaps to fix the Secured Overnight Financing Rate (“SOFR”) for the first $350.0 million of its floating rate debt at 2.968% from September 2023 through September 2025 (“2025 interest rate swaps”). The total notional amount of the 2025 interest swaps was $350.0 million as of January 27, 2024.

[0000936395-24-000008:notes:90]
In January 2023, Ciena entered into interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.47% through January 2028 (“2028 interest rate swaps”). The total notional amount of these interest rate swaps in effect as of January 27, 2024 was $350.0 million.

[0000936395-24-000008:notes:91]
In December 2023, Ciena entered into forward starting interest rate swaps to fix SOFR for an additional $350.0 million of its floating rate debt at 3.287% from September 2025 through December 2028 (“2028 forward starting interest rate swaps”). The total notional amount of the 2028 forward starting interest rate swaps effective September 2025 was $350.0 million as of January 27, 2024.

[0000936395-24-000008:notes:92]
Ciena expects the variable rate payments to be received under the terms of these interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the 2030 New Term Loan (as defined in Note 13 below). These derivative contracts have been designated as cash flow hedges.

[0000936395-24-000008:notes:93]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Note 5 and Note 8 above.


## us-gaap:DebtDisclosureTextBlock

[0000936395-24-000008:notes:94]
SHORT-TERM AND LONG-TERM DEBT 
Outstanding Term Loan Payable

[0000936395-24-000008:notes:95]
2030 New Term Loan

[0000936395-24-000008:notes:96]
On October 24, 2023, Ciena entered into an Incremental Amendment Agreement to its Credit Agreement to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $1.2 billion maturing on October 24, 2030 (the “2030 New Term Loan”) and a new senior secured revolving credit facility of $300.0 million (the “Revolving Credit Facility”). The 2030 New Term Loan requires Ciena to make installment payments of $2.9 million quarterly, or $11.7 million annually, with the remaining balance payable at maturity.

[0000936395-24-000008:notes:97]
The net carrying value of the 2030 New Term Loan was comprised of the following as of the date indicated (in thousands):

[0000936395-24-000008:notes:98]
|  |  | January 27, 2024 |  | October 28, 2023 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2030 New Term Loan |  | $ | 1,170,000 |  |  | $ | (4,934) |  |  | $ | (6,157) |  |  | $ | 1,158,909 |  |  | $ | 1,159,371 |  |

[0000936395-24-000008:notes:99]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 New Term Loan totaled $6.2 million as of January 27, 2024 and $5.5 million at October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 New Term Loan. The amortization of deferred debt issuance costs for the 2030 New Term Loan is included in interest expense and was approximately $0.2 million during the first three months of fiscal 2024.

[0000936395-24-000008:notes:100]
As of January 27, 2024, the estimated fair value of the 2030 New Term Loan was $1.2 billion. The 2030 New Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 New Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-24-000008:notes:101]
Refinanced Term Loans

[0000936395-24-000008:notes:102]
The proceeds of the 2030 New Term Loan, net of original issuance discount, was used to repay in full $1.2 billion of outstanding principal of the 2025 Term Loan (as defined below) and the 2030 Term Loan (as defined below), together the Refinanced Term Loans, including accrued interest.

[0000936395-24-000008:notes:103]
2025 Term Loan

[0000936395-24-000008:notes:104]
On January 19, 2023, pursuant to the Incremental Agreement (as defined below) to the Credit Agreement, the Credit Agreement was amended to replace LIBOR with SOFR for Ciena’s senior secured term loan maturing on September 28, 2025 (the “2025 Term Loan”) in response to pending impact of FASB Accounting Standards Codification 848, Reference Rate Reform. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million for the first three months of fiscal 2023.

[0000936395-24-000008:notes:105]
2030 Term Loan

[0000936395-24-000008:notes:106]
On January 19, 2023, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Agreement”) to its Credit Agreement, dated July 15, 2014, as amended, by and among Ciena, the lenders party thereto and Bank of America, N.A., as administrative agent, pursuant to which Ciena incurred a new tranche of senior secured term loans in an aggregate principal amount of $500.0 million and maturing on January 19, 2030 (the “2030 Term Loan”). Net of original issue discount and debt issuance costs, the $492.5 million in proceeds from the 2030 Term Loan were used for general corporate purposes. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2030 Term Loan. The amortization of deferred debt issuance costs for the 2030 Term Loan is included in interest expense, and was nominal for the first three months of fiscal 2023.

[0000936395-24-000008:notes:107]
Outstanding Senior Notes Payable

[0000936395-24-000008:notes:108]
2030 Notes

[0000936395-24-000008:notes:109]
On January 18, 2022, Ciena entered into an indenture among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors, and U.S. Bank National Association, as trustee, pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% fixed-rate senior notes due 2030 (the “2030 Notes”).

[0000936395-24-000008:notes:110]
The net carrying value of the 2030 Notes was comprised of the following as of the dates indicated (in thousands):

[0000936395-24-000008:notes:111]
|  |  | January 27, 2024 |  | October 28, 2023 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |  |  |
| 2030 Notes |  | $ | 400,000 |  |  | $ | (4,091) |  |  | $ | 395,909 |  |  | $ | 395,735 |  |  |  |

[0000936395-24-000008:notes:112]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $4.1 million as of January 27, 2024 and $4.3 million as of October 28, 2023. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was approximately $0.2 million during both the first three months of fiscal 2024 and fiscal 2023.

[0000936395-24-000008:notes:113]
As of January 27, 2024, the estimated fair value of the 2030 Notes was $363.5 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-24-000008:notes:114]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 27, 2024 (in thousands):

[0000936395-24-000008:notes:115]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  |  |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 28, 2023 | $ | (372) |  |  | $ | (8,156) |  |  |  |  | $ | 18,962 |  |  | $ | (48,201) |  |  | $ | (37,767) |  |
| Other comprehensive gain (loss) before reclassifications | 895 |  |  | 6,448 |  |  |  |  | (5,592) |  |  | 14,323 |  |  | 16,074 |  |
| Amounts reclassified from AOCI | — |  |  | 708 |  |  |  |  | (3,882) |  |  | — |  |  | (3,174) |  |
| Balance at January 27, 2024 | $ | 523 |  |  | $ | (1,000) |  |  |  |  | $ | 9,488 |  |  | $ | (33,878) |  |  | $ | (24,867) |  |

[0000936395-24-000008:notes:116]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 28, 2023 (in thousands):

[0000936395-24-000008:notes:117]
|  | Unrealized Gain (Loss) on |  |  |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Interest Rate Swaps |  | Cumulative Translation Adjustment |  | Total |
| Balance at October 29, 2022 | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |
| Other comprehensive gain (loss) before reclassifications | 1,050 |  |  | 7,630 |  |  | (4,226) |  |  | 15,979 |  |  | 20,433 |  |
| Amounts reclassified from AOCI | — |  |  | (2,288) |  |  | (799) |  |  | — |  |  | (3,087) |  |
| Balance at January 28, 2023 | $ | (1,915) |  |  | $ | (4,855) |  |  | $ | 4,372 |  |  | $ | (26,901) |  |  | $ | (29,299) |  |

[0000936395-24-000008:notes:118]
[same as prior period, unchanged from 0000936395-23-000034:notes:141]


## us-gaap:EarningsPerShareTextBlock

[0000936395-24-000008:notes:119]
[same as prior period, unchanged from 0000936395-23-000034:notes:142]

[0000936395-24-000008:notes:120]
[same as prior period, unchanged from 0000936395-23-000034:notes:143]

[0000936395-24-000008:notes:121]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Net income | $ | 49,547 |  |  | $ | 76,241 |  |  |  |  |  |
| Basic weighted average shares outstanding | 145,291 |  |  | 149,081 |  |  |  |  |  |
| Effect of dilutive potential common shares | 557 |  |  | 470 |  |  |  |  |  |
| Diluted weighted average shares | 145,848 |  |  | 149,551 |  |  |  |  |  |
| Basic EPS | $ | 0.34 |  |  | $ | 0.51 |  |  |  |  |  |
| Diluted EPS | $ | 0.34 |  |  | $ | 0.51 |  |  |  |  |  |
| Antidilutive employee share-based awards, excluded | 2,491 |  |  | 2,768 |  |  |  |  |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-24-000008:notes:122]
[same as prior period, unchanged from 0000936395-23-000034:notes:145]

[0000936395-24-000008:notes:123]
[same as prior period, unchanged from 0000936395-23-000034:notes:146]

[0000936395-24-000008:notes:124]
During the first three months of fiscal 2024, Ciena repurchased an additional 0.7 million shares of its common stock for an aggregate purchase price of $32.0 million at an average price of $46.30 per share. As of January 27, 2024, Ciena (i) has repurchased 14.8 million shares for an aggregate purchase price of $782.0 million at an average price of $52.85 per share and (ii) has an aggregate of $218.0 million authorized and remaining under its stock repurchase program.

[0000936395-24-000008:notes:125]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-24-000008:notes:126]
[same as prior period, unchanged from 0000936395-23-000034:notes:148]

[0000936395-24-000008:notes:127]
Ciena repurchases shares of its common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The related purchase price of $10.1 million for the shares of Ciena’s stock repurchased during the first three months of fiscal 2024 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-24-000008:notes:128]
[same as prior period, unchanged from 0000936395-23-000034:notes:150]

[0000936395-24-000008:notes:129]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Products | $ | 1,318 |  |  | $ | 1,051 |  |  |  |  |  |
| Services | 3,020 |  |  | 2,297 |  |  |  |  |  |
| Share-based compensation expense included in cost of goods sold | 4,338 |  |  | 3,348 |  |  |  |  |  |
| Research and development | 12,880 |  |  | 9,234 |  |  |  |  |  |
| Selling and marketing | 10,305 |  |  | 8,424 |  |  |  |  |  |
| General and administrative | 10,079 |  |  | 9,468 |  |  |  |  |  |
| Share-based compensation expense included in operating expense | 33,264 |  |  | 27,126 |  |  |  |  |  |
| Share-based compensation expense capitalized in inventory, net | 225 |  |  | 38 |  |  |  |  |  |
| Total share-based compensation expense | $ | 37,827 |  |  | $ | 30,512 |  |  |  |  |  |

[0000936395-24-000008:notes:130]
As of January 27, 2024, total unrecognized share-based compensation expense was approximately $333.9 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.56 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-24-000008:notes:131]
[same as prior period, unchanged from 0000936395-23-000034:notes:154]

[0000936395-24-000008:notes:132]
[same as prior period, unchanged from 0000936395-23-000034:notes:155]

[0000936395-24-000008:notes:133]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, right-of-use (“ROU”) assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 27, 2024, equipment, building, furniture and fixtures, net, totaled $280.4 million, and operating ROU assets totaled $35.7 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of January 27, 2024, finite-lived intangible assets, goodwill, and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-24-000008:notes:134]
|  | January 27, 2024 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 181,155 |  |  | — |  |  | 14,527 |  |  | — |  |  | $ | 195,682 |  |
| Goodwill | $ | 199,844 |  |  | 156,191 |  |  | 89,049 |  |  | — |  |  | $ | 445,084 |  |
| Maintenance spares, net | $ | — |  |  | — |  |  | — |  |  | 56,266 |  |  | $ | 56,266 |  |

[0000936395-24-000008:notes:135]
[same as prior period, unchanged from 0000936395-23-000034:notes:158]

[0000936395-24-000008:notes:136]
[same as prior period, unchanged from 0000936395-23-000034:notes:159]

[0000936395-24-000008:notes:137]
[same as prior period, unchanged from 0000936395-23-000034:notes:160]

[0000936395-24-000008:notes:138]
|  | Quarter Ended |  |  |
|  | January 27, |  | January 28, |  |  |  |  |
|  | 2024 |  | 2023 |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 183,775 |  |  | $ | 202,147 |  |  |  |  |  |
| Platform Software and Services | 58,004 |  |  | 45,650 |  |  |  |  |  |
| Blue Planet Automation Software and Services | (7,069) |  |  | (11,059) |  |  |  |  |  |
| Global Services | 44,983 |  |  | 37,478 |  |  |  |  |  |
| Total segment profit | 279,693 |  |  | 274,216 |  |  |  |  |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 128,158 |  |  | 123,807 |  |  |  |  |  |
| General and administrative | 54,683 |  |  | 50,896 |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,971 |  |  | 4,298 |  |  |  |  |  |
| Amortization of intangible assets | 7,252 |  |  | 7,441 |  |  |  |  |  |
| Acquisition and integration costs | — |  |  | 2,558 |  |  |  |  |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest and other income, net | 10,650 |  |  | 31,973 |  |  |  |  |  |
| Interest expense | (23,776) |  |  | (15,870) |  |  |  |  |  |
| Less: Provision for income taxes | 21,956 |  |  | 25,078 |  |  |  |  |  |
| Net income | $ | 49,547 |  |  | $ | 76,241 |  |  |  |  |  |

[0000936395-24-000008:notes:139]
[same as prior period, unchanged from 0000936395-23-000034:notes:162]

[0000936395-24-000008:notes:140]
[same as prior period, unchanged from 0000936395-23-000034:notes:163]

[0000936395-24-000008:notes:141]
|  | January 27,2024 |  | October 28,2023 |
| Canada | $ | 230,712 |  |  | $ | 229,707 |  |
| United States | 47,231 |  |  | 46,933 |  |
| Other International | 38,093 |  |  | 38,647 |  |
| Total | $ | 316,036 |  |  | $ | 315,287 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-24-000008:notes:142]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-24-000008:notes:143]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000008:notes:144]
Litigation

[0000936395-24-000008:notes:145]
Ciena is subject to various legal proceedings, claims, and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax, and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position, or cash flows.

[0000936395-24-000008:notes:146]
Purchase Order Obligations

[0000936395-24-000008:notes:147]
Ciena has certain advanced orders for supply of certain long lead time components. As of January 27, 2024, Ciena had $1.9 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-24-000008:notes:148]
SUBSEQUENT EVENTS
Stock Repurchase Program
From the end of the first quarter of fiscal 2024 through March 1, 2024, Ciena repurchased an additional 0.3 million shares of its common stock for an aggregate purchase price of $19.2 million at an average price of $55.44 per share, inclusive of repurchases pending settlement. As of March 1, 2024, Ciena has repurchased an aggregate of 15.1 million shares and has an aggregate of $198.8 million of authorized funds remaining under its stock repurchase program.


## ecd:MtrlTermsOfTrdArrTextBlock

[0000936395-24-000008:notes:149]
The following table describes, for the quarter ended January 27, 2024, each trading arrangement for the sale or purchase of our securities adopted, terminated or for which the amount, pricing or timing provisions were modified by our directors and officers (as defined in Rule 16a-1(f) of the Exchange Act) that is either (1) a contract, instruction or written plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) (a “Rule 10b5-1 trading arrangement”) or (2) a “non-Rule 10b5-1 trading arrangement” (as defined in Item 408(c) of Regulation S-K):

[0000936395-24-000008:notes:150]
| Name(Title) | Action Taken (Date of Action) | Type of Trading Arrangement | Nature of Trading Arrangement | Duration of Trading Arrangement | Aggregate Number of Securities to be Purchased or Sold |
| Joseph Cumello (Senior Vice President and General Manager of Blue Planet) | Adoption (January 8, 2024) | Rule 10b5-1 trading arrangement | Sales | Until December 27, 2024, or such earlier date upon which all transactions are completed or expire without execution | * |

[0000936395-24-000008:notes:151]
•The aggregate number of shares of common stock to be sold pursuant to Mr. Cumello’s arrangement is up to (i) 11,599 shares of common stock plus (ii) 100% of the net after-tax shares of common stock to be received as a result of the March 20, 2024 vesting of 2,805 restricted stock units. The actual number of net after-tax shares to be received will vary based on the market price of our common stock at the time of settlement.
