# CIEN MD&A — 0000936395-24-000008


## mdna

[0000936395-24-000008:mdna:1]
[same as prior period, unchanged from 0000936395-23-000034:mdna:1]

[0000936395-24-000008:mdna:2]
[same as prior period, unchanged from 0000936395-23-000034:mdna:2]

[0000936395-24-000008:mdna:3]
[same as prior period, unchanged from 0000936395-23-000034:mdna:3]

[0000936395-24-000008:mdna:4]
[same as prior period, unchanged from 0000936395-23-000034:mdna:4]

[0000936395-24-000008:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations is designed to provide an understanding of Ciena’s financial condition, results of operations, and cash flows, and should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and in Item 8 of Part II of our 2023 Annual Report.

[0000936395-24-000008:mdna:6]
We are a network platform, software, and services company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software, and services that support the delivery of video, data, and voice traffic over core, metro, aggregation, and

[0000936395-24-000008:mdna:7]
access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, cloud providers, submarine network operators, governments, and enterprises across multiple industry verticals. Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that is informed by analytics and intelligence. Our solutions include Networking Platforms, including our Optical Networking and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. To complement our Networking Platforms, we offer Platform Software, which includes our Navigator Network Control SuiteTM (“Navigator NCS”), which we previously referred to as Manage, Control, and Plan (MCP), applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software, we also enable complete service lifecycle management automation with productized operational support systems (OSS), which include inventory, orchestration and assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-24-000008:mdna:8]
[same as prior period, unchanged from 0000936395-23-000034:mdna:8]

[0000936395-24-000008:mdna:9]
From the second quarter of fiscal 2021 through the third quarter of fiscal 2022, we received an unprecedented volume of orders for our products and services, which significantly exceeded our revenue and historical order volumes. We believe some portion of these large orders reflected customer acceleration of future orders due to a constrained supply environment, as well as orders which were delayed due to the dynamics of the COVID-19 pandemic. Our order volumes began to moderate in the fourth quarter of fiscal 2022, and we experienced order levels below revenue during fiscal 2023 and the first quarter of fiscal 2024, particularly from our communications service provider customers. Our expected return to more typical order patterns with our service provider customers in fiscal 2024 is taking longer than anticipated. We believe this is, in part, due to service providers in North America working through relatively high levels of inventory previously acquired, which has been made more difficult due to challenges installing and deploying equipment, including site readiness and access to fiber or other resources. In addition, in certain international geographies, we believe that caution driven by macroecononic concerns and market-specific issues are contributing to lower-than-expected order volumes from service providers. We expect these dynamics with our service provider customers to persist for the next few quarters. Notwithstanding these near-term impacts, we continue to believe that certain trends and shifts in business and consumer behaviors, including enterprise and consumer cloud network adoption, 5G, high-definition video, generative AI, and network operator focus on resilience and automation, represent positive, long-term drivers of bandwidth demand and long-term opportunities for our business.

[0000936395-24-000008:mdna:10]
[same as prior period, unchanged from 0000936395-23-000034:mdna:10]

[0000936395-24-000008:mdna:11]
Historically, a meaningful portion of our quarterly revenue was generated from customer orders received during that same quarter (which we refer to as “book to revenue”) and was therefore less predictable and subject to fluctuation. As a result of elevated order volumes during portions of fiscal 2021 and fiscal 2022, however, our backlog grew from $1.2 billion at the end of fiscal 2020 to $4.2 billion at the end of fiscal 2022. Accordingly, our revenue in recent fiscal years has been more significantly impacted by factors including availability of supply and customer delivery deferrals, as we converted our existing backlog to revenue. As supply chain conditions have improved, and we have been able to increase shipment volumes and reduce lead times, our backlog decreased to $2.2 billion as of the end of the first quarter of fiscal 2024. We expect our backlog to continue to reduce during fiscal 2024 as supply chain conditions continue to improve and customers place fewer advanced orders. As that happens, we expect that our reliance upon securing quarterly book to revenue orders will grow, and that increased orders and a return to a more typical composition of our quarterly revenue will be a critical element of any future revenue growth.

[0000936395-24-000008:mdna:12]
The timing and degree to which we fulfill our backlog will have a significant impact on our revenue and can be affected by factors outside of our control, including customer readiness and willingness to receive shipment against existing orders. During fiscal 2023 and the first quarter of fiscal 2024, certain customers, including communications service providers and cable and multiservice operators in North America, that had earlier placed significant advanced orders, rescheduled deliveries for a portion of such orders. We believe that this was the result of a number of factors, including the rapid improvement in our delivery lead times as supply chain conditions improved and their capital expenditure and inventory levels. Accordingly, our results for a particular period can be difficult to predict. As a result of these and other factors, the timing of our fulfillment of backlog could cause some volatility in our results of operations and our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period.

[0000936395-24-000008:mdna:13]
For additional information regarding our business, industry, market opportunity, competitive landscape, and strategy, see our 2023 Annual Report.

[0000936395-24-000008:mdna:14]
[same as prior period, unchanged from 0000936395-23-000034:mdna:18]

[0000936395-24-000008:mdna:15]
[same as prior period, unchanged from 0000936395-23-000034:mdna:19]

[0000936395-24-000008:mdna:16]
[same as prior period, unchanged from 0000936395-23-000034:mdna:20]

[0000936395-24-000008:mdna:17]
[same as prior period, unchanged from 0000936395-23-000034:mdna:21]

[0000936395-24-000008:mdna:18]
Revenue and Currency Fluctuations

[0000936395-24-000008:mdna:19]
As a result of the reduction in orders relative to revenue described under “Overview” above, our revenue declined by 1.8% in the first quarter of fiscal 2024 as compared to the first quarter of fiscal 2023. In addition, during the first quarter of fiscal 2024, approximately 14.3% of our revenue was non-U.S. Dollar-denominated primarily including sales in Euros, Canadian Dollars, and British Pounds. During the first quarter of fiscal 2024 as compared to the first quarter of fiscal 2023, the U.S. Dollar primarily weakened against these currencies. Consequently, our revenue reported in U.S. Dollars slightly increased by approximately $3.4 million, or 0.3%, as compared to the first quarter of fiscal 2023, as a result of foreign exchange rates.

[0000936395-24-000008:mdna:20]
[same as prior period, unchanged from 0000936395-23-000034:mdna:24]

[0000936395-24-000008:mdna:21]
[same as prior period, unchanged from 0000936395-23-000034:mdna:25]

[0000936395-24-000008:mdna:22]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Optical Networking | $ | 695,849 |  |  | $ | 735,634 |  |  |  |  | (5.4) | % |  |  |  |  |  |  |  |  |
| %** | 67.1 | % |  | 69.6 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Routing and Switching | 111,387 |  |  | 119,505 |  |  |  |  | (6.8) | % |  |  |  |  |  |  |  |  |
| %** | 10.7 | % |  | 11.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Networking Platforms | 807,236 |  |  | 855,139 |  |  |  |  | (5.6) | % |  |  |  |  |  |  |  |  |
| %** | 77.8 | % |  | 80.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 89,745 |  |  | 73,445 |  |  |  |  | 22.2 | % |  |  |  |  |  |  |  |  |
| %** | 8.6 | % |  | 6.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | 13,942 |  |  | 15,405 |  |  |  |  | (9.5) | % |  |  |  |  |  |  |  |  |
| %** | 1.4 | % |  | 1.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 74,115 |  |  | 67,891 |  |  |  |  | 9.2 | % |  |  |  |  |  |  |  |  |
| %** | 7.1 | % |  | 6.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Installation and Deployment | 42,723 |  |  | 34,575 |  |  |  |  | 23.6 | % |  |  |  |  |  |  |  |  |
| %** | 4.1 | % |  | 3.3 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Consulting and Network Design | 9,948 |  |  | 10,066 |  |  |  |  | (1.2) | % |  |  |  |  |  |  |  |  |
| %** | 1.0 | % |  | 1.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total Global Services | 126,786 |  |  | 112,532 |  |  |  |  | 12.7 | % |  |  |  |  |  |  |  |  |
| %** | 12.2 | % |  | 10.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  | (1.8) | % |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:23]
[same as prior period, unchanged from 0000936395-23-000034:mdna:27]

[0000936395-24-000008:mdna:24]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:25]
[same as prior period, unchanged from 0000936395-23-000034:mdna:29]

[0000936395-24-000008:mdna:26]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:27]
•Networking Platforms segment revenue decreased by $47.9 million, reflecting product line sales decreases of $39.8 million of our Optical Networking products and $8.1 million of our Routing and Switching products.

[0000936395-24-000008:mdna:28]
◦Optical Networking sales decreased, primarily reflecting a sales decrease of $178.6 million of our 6500 Packet-Optical Platform, primarily to communications service providers. This sales decrease was partially offset by sales increases of $73.5 million of our 6500 Reconfigurable Line System (RLS) products and $64.5 million of our Waveserver® modular interconnect system, both primarily to cloud providers.

[0000936395-24-000008:mdna:29]
•Routing and Switching sales decreased, primarily reflecting a sales decrease of $29.8 million of our virtualization software primarily to communications service providers, partially offset by sales increases of $11.0 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, $5.6 million of our platform independent software and $5.3 million of our 8100 Coherent IP networking platforms, both primarily to communications service providers.

[0000936395-24-000008:mdna:30]
•Platform Software and Services segment revenue increased by $16.3 million, reflecting sales increases of $8.8 million of our software platforms and $7.5 million in our software maintenance services, both primarily for our Navigator NCS software platform.

[0000936395-24-000008:mdna:31]
•Blue Planet Automation Software and Services segment revenue decreased by $1.5 million reflecting a sales decrease of $2.8 million in software platforms, partially offset by a sales increase of $1.3 million in professional software services, both primarily to communications service providers.

[0000936395-24-000008:mdna:32]
•Global Services segment revenue increased by $14.3 million, primarily reflecting sales increases of $8.1 million of our installation and deployment services and $6.2 million of our maintenance support and training.

[0000936395-24-000008:mdna:33]
[same as prior period, unchanged from 0000936395-23-000034:mdna:45]

[0000936395-24-000008:mdna:34]
Our operating segments engage in business and operations across three geographic regions: the United States, Canada, the Caribbean and Latin America (“Americas”); Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The decrease in our Americas region revenue for the quarter ended January 27, 2024 was primarily driven by decreased sales in Canada and the United States. The decrease in our APAC region revenue for the quarter ended January 27, 2024 was primarily driven by decreased sales in India. The increase in our EMEA region revenue for the quarter ended January 27, 2024 was primarily driven by increased sales in the Netherlands.

[0000936395-24-000008:mdna:35]
[same as prior period, unchanged from 0000936395-23-000034:mdna:47]

[0000936395-24-000008:mdna:36]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Americas | $ | 718,198 |  |  | $ | 765,096 |  |  |  |  | (6.1) | % |  |  |  |  |  |  |  |  |
| %** | 69.2 | % |  | 72.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| EMEA | 207,413 |  |  | 152,804 |  |  |  |  | 35.7 | % |  |  |  |  |  |  |  |  |
| %** | 20.0 | % |  | 14.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| APAC | 112,098 |  |  | 138,621 |  |  |  |  | (19.1) | % |  |  |  |  |  |  |  |  |
| %** | 10.8 | % |  | 13.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  | (1.8) | % |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:37]
[same as prior period, unchanged from 0000936395-23-000034:mdna:49]

[0000936395-24-000008:mdna:38]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:39]
[same as prior period, unchanged from 0000936395-23-000034:mdna:51]

[0000936395-24-000008:mdna:40]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:41]
•Americas revenue decreased by $46.9 million, primarily reflecting sales decreases of $59.7 million within our Networking Platforms segment and $1.4 million within our Blue Planet Automation Software and Services segment,

[0000936395-24-000008:mdna:42]
partially offset by sales increases of $8.8 million within our Platform Software and Services segment and $5.3 million within our Global Services segment. The decrease within our Networking Platforms segment reflects product line sales decreases of $42.3 million of our Optical Networking products and $17.4 million of our Routing and Switching products. The decrease within our Optical Networking product line was primarily related to a sales decrease of $136.1 million of our 6500 Packet-Optical Platform, primarily to communication service providers. This decrease was partially offset by sales increases of $55.8 million of our 6500 RLS products, primarily to cloud providers, and $39.7 million of our Waveserver® modular interconnect system, primarily to cloud providers and communication service providers. The decrease within our Routing and Switching product line primarily reflects a sales decrease of $29.8 million of our virtualization software, primarily to communications service providers.

[0000936395-24-000008:mdna:43]
•EMEA revenue increased by $54.6 million, primarily reflecting sales increases of $42.5 million within our

[0000936395-24-000008:mdna:44]
Networking Platforms segment, $7.1 million within our Global Services segment and $5.4 million within our Platform Software and Services segment. The increase within our Networking Platforms segment primarily reflects product line sales increases of $36.8 million of our Optical Networking product line, primarily related to a sales increase of $24.8 million of our Waveserver® modular interconnect system, primarily to cloud providers.

[0000936395-24-000008:mdna:45]
•APAC revenue decreased by $26.5 million, primarily reflecting a sales decrease of $30.7 million within our

[0000936395-24-000008:mdna:46]
Networking Platforms segment, partially offset by increased sales of $2.1 million within our Platform Software and Services segment and $1.8 million within our Global Services segment. The decrease within our Networking Platforms segment primarily reflects a product line sales decrease of $34.3 million of Optical Networking products, which primarily reflects a sales decrease of $40.5 million of our 6500 Packet-Optical Platform, primarily to communication service providers.

[0000936395-24-000008:mdna:47]
[same as prior period, unchanged from 0000936395-23-000034:mdna:63]

[0000936395-24-000008:mdna:48]
There are a number of important factors or conditions that can adversely affect or cause our gross profit as a percentage of product or service revenue, or “gross margin,” to fluctuate on a quarterly basis. For example, early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales, and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity. The component elements that comprise our product cost of goods sold and services cost of goods sold, and certain factors that can cause gross margin to fluctuate, are described in detail in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” and “Risk Factors” sections of our 2023 Annual Report.

[0000936395-24-000008:mdna:49]
[same as prior period, unchanged from 0000936395-23-000034:mdna:65]

[0000936395-24-000008:mdna:50]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Total revenue | $ | 1,037,709 |  |  | $ | 1,056,521 |  |  |  |  | (1.8) | % |  |  |  |  |  |  |  |  |
| Total cost of goods sold | 570,747 |  |  | 600,575 |  |  |  |  | (5.0) | % |  |  |  |  |  |  |  |  |
| Gross profit | $ | 466,962 |  |  | $ | 455,946 |  |  |  |  | 2.4 | % |  |  |  |  |  |  |  |  |
| %** | 45.0 | % |  | 43.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:51]
[same as prior period, unchanged from 0000936395-23-000034:mdna:67]

[0000936395-24-000008:mdna:52]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:53]
[same as prior period, unchanged from 0000936395-23-000034:mdna:69]

[0000936395-24-000008:mdna:54]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Product revenue | $ | 835,777 |  |  | $ | 877,715 |  |  |  |  | (4.8) | % |  |  |  |  |  |  |  |  |
| Product cost of goods sold | 466,472 |  |  | 500,337 |  |  |  |  | (6.8) | % |  |  |  |  |  |  |  |  |
| Product gross profit | $ | 369,305 |  |  | $ | 377,378 |  |  |  |  | (2.1) | % |  |  |  |  |  |  |  |  |
| %** | 44.2 | % |  | 43.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:55]
[same as prior period, unchanged from 0000936395-23-000034:mdna:71]

[0000936395-24-000008:mdna:56]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:57]
[same as prior period, unchanged from 0000936395-23-000034:mdna:73]

[0000936395-24-000008:mdna:58]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Services revenue | $ | 201,932 |  |  | $ | 178,806 |  |  |  |  | 12.9 | % |  |  |  |  |  |  |  |  |
| Services cost of goods sold | 104,275 |  |  | 100,238 |  |  |  |  | 4.0 | % |  |  |  |  |  |  |  |  |
| Services gross profit | $ | 97,657 |  |  | $ | 78,568 |  |  |  |  | 24.3 | % |  |  |  |  |  |  |  |  |
| % ** | 48.4 | % |  | 43.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:59]
[same as prior period, unchanged from 0000936395-23-000034:mdna:75]

[0000936395-24-000008:mdna:60]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:61]
[same as prior period, unchanged from 0000936395-23-000034:mdna:77]

[0000936395-24-000008:mdna:62]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:63]
•Gross profit increased by $11.0 million. Gross margin increased by 180 basis points, primarily due to reduced component costs and improved margins on Blue Planet software services, partially offset by a higher concentration of lower margin product mix.

[0000936395-24-000008:mdna:64]
•Gross profit on products decreased by $8.1 million. Product gross margin increased by 120 basis points, primarily due to reduced component costs and higher software sales, partially offset by a higher concentration of lower margin product mix and higher inventory excess and obsolescence costs.

[0000936395-24-000008:mdna:65]
•Gross profit on services increased by $19.1 million. Gross margin increased by 450 basis points, primarily due to improved margins on Blue Planet software services due to improved efficiencies on delivery. Additionally, margins on deployment services increased due to increased revenue and efficiencies reducing costs.

[0000936395-24-000008:mdna:66]
[same as prior period, unchanged from 0000936395-23-000034:mdna:86]

[0000936395-24-000008:mdna:67]
[same as prior period, unchanged from 0000936395-23-000034:mdna:22]

[0000936395-24-000008:mdna:68]
Approximately 48.0% of our operating expense was non-U.S. Dollar-denominated during the first quarter of fiscal 2024, including expenses in Canadian Dollars, Indian Rupees, and Euros. During the first quarter of fiscal 2024, as compared to the first quarter of fiscal 2023, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense, net of hedging, reported in U.S. Dollars, was adversely affected by approximately $0.9 million, or 0.2%.

[0000936395-24-000008:mdna:69]
The component elements that comprise each of our operating expense categories in the table below are set forth in the “Management’s Discussion and Analysis of Financial Condition and Results of Operations” section of our 2023 Annual Report. The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-24-000008:mdna:70]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Research and development | $ | 187,269 |  |  | $ | 181,730 |  |  |  |  | 3.0 | % |  |  |  |  |  |  |  |  |
| %** | 18.0 | % |  | 17.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Selling and marketing | 128,158 |  |  | 123,807 |  |  |  |  | 3.5 | % |  |  |  |  |  |  |  |  |
| %** | 12.3 | % |  | 11.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| General and administrative | 54,683 |  |  | 50,896 |  |  |  |  | 7.4 | % |  |  |  |  |  |  |  |  |
| %** | 5.3 | % |  | 4.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Significant asset impairments and restructuring costs | 4,971 |  |  | 4,298 |  |  |  |  | 15.7 | % |  |  |  |  |  |  |  |  |
| %** | 0.5 | % |  | 0.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of intangible assets | 7,252 |  |  | 7,441 |  |  |  |  | (2.5) | % |  |  |  |  |  |  |  |  |
| %** | 0.7 | % |  | 0.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition and integration costs | — |  |  | 2,558 |  |  |  |  | (100.0) | % |  |  |  |  |  |  |  |  |
| %** | — | % |  | 0.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total operating expenses | $ | 382,333 |  |  | $ | 370,730 |  |  |  |  | 3.1 | % |  |  |  |  |  |  |  |  |
| %** | 36.8 | % |  | 35.1 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:71]
[same as prior period, unchanged from 0000936395-23-000034:mdna:91]

[0000936395-24-000008:mdna:72]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:73]
[same as prior period, unchanged from 0000936395-23-000034:mdna:93]

[0000936395-24-000008:mdna:74]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:75]
•Research and development expense increased by $5.5 million. This increase primarily reflects increases in employee headcount and related compensation costs, partially offset by decreased professional services related to design engineering, fabrication and production of ASIC chips.

[0000936395-24-000008:mdna:76]
•Selling and marketing expense increased by $4.4 million. This increase primarily reflects increases in employee-related compensation costs.

[0000936395-24-000008:mdna:77]
•General and administrative expense increased by $3.8 million. This increase primarily reflects increases in employee-related compensation costs and bad debt expense, partially offset by decreased costs for professional services.

[0000936395-24-000008:mdna:78]
[same as prior period, unchanged from 0000936395-23-000034:mdna:99]

[0000936395-24-000008:mdna:79]
•Amortization of intangible assets remained relatively unchanged.

[0000936395-24-000008:mdna:80]
•Acquisition and integration costs in the first quarter of fiscal 2023 reflect financial, legal, and accounting advisors and employee-related costs related to our acquisitions of Benu Networks, Inc. (“Benu”) and Tibit Communications, Inc. (“Tibit”) during the first quarter of fiscal 2023.

[0000936395-24-000008:mdna:81]
[same as prior period, unchanged from 0000936395-23-000034:mdna:111]

[0000936395-24-000008:mdna:82]
[same as prior period, unchanged from 0000936395-23-000034:mdna:112]

[0000936395-24-000008:mdna:83]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Interest and other income, net | $ | 10,650 |  |  | $ | 31,973 |  |  |  |  | (66.7) | % |  |  |  |  |  |  |  |  |
| %** | 1.0 | % |  | 3.0 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Interest expense | $ | 23,776 |  |  | $ | 15,870 |  |  |  |  | 49.8 | % |  |  |  |  |  |  |  |  |
| %** | 2.3 | % |  | 1.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Provision for income taxes | $ | 21,956 |  |  | $ | 25,078 |  |  |  |  | (12.4) | % |  |  |  |  |  |  |  |  |
| %** | 2.1 | % |  | 2.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:84]
[same as prior period, unchanged from 0000936395-23-000034:mdna:115]

[0000936395-24-000008:mdna:85]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:86]
[same as prior period, unchanged from 0000936395-23-000034:mdna:117]

[0000936395-24-000008:mdna:87]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:88]
•Interest and other income, net decreased by $21.3 million, primarily resulting from the remeasurement of our previously held investment in Tibit to fair value, which resulted in a gain on our cost method equity investment of $26.5 million in the first quarter of fiscal 2023, partially offset by higher interest income on our investments.

[0000936395-24-000008:mdna:89]
•Interest expense increased by $7.9 million, primarily due to higher interest rates on our floating rate debt, net of hedging activity. For more information on our short-term and long-term debt, see Note 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000008:mdna:90]
•Provision for income taxes decreased by $3.1 million, primarily due to the effect of research and development expenditures and tax credits. The effective tax rate for the first quarter of fiscal 2024 was higher than the effective tax rate for the first quarter of fiscal 2023, primarily due to the tax benefit of a gain on our cost method equity investment in the first quarter of fiscal 2023.

[0000936395-24-000008:mdna:91]
[same as prior period, unchanged from 0000936395-23-000034:mdna:126]

[0000936395-24-000008:mdna:92]
[same as prior period, unchanged from 0000936395-23-000034:mdna:127]

[0000936395-24-000008:mdna:93]
|  | Quarter Ended |  |  |  |  |  |  |  |  |  |  |
|  | January 27, 2024 |  | January 28, 2023 |  |  |  | %* |  |  |  |  |  |  |  |  |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 183,775 |  |  | $ | 202,147 |  |  |  |  | (9.1) | % |  |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 58,004 |  |  | $ | 45,650 |  |  |  |  | 27.1 | % |  |  |  |  |  |  |  |  |
| Blue Planet Automation Software and Services | $ | (7,069) |  |  | $ | (11,059) |  |  |  |  | 36.1 | % |  |  |  |  |  |  |  |  |
| Global Services | $ | 44,983 |  |  | $ | 37,478 |  |  |  |  | 20.0 | % |  |  |  |  |  |  |  |  |

[0000936395-24-000008:mdna:94]
[same as prior period, unchanged from 0000936395-23-000034:mdna:129]

[0000936395-24-000008:mdna:95]
*    Denotes % change from fiscal 2023 to fiscal 2024

[0000936395-24-000008:mdna:96]
Quarter ended January 27, 2024 as compared to the quarter ended January 28, 2023

[0000936395-24-000008:mdna:97]
•Networking Platforms segment profit decreased by $18.4 million, primarily due to lower product sales volume and increased research and development costs, offset by slightly higher gross margin as described above.

[0000936395-24-000008:mdna:98]
•Platform Software and Services segment profit increased by $12.4 million, primarily due to higher sales volume as described above, partially offset by increased research and development costs.

[0000936395-24-000008:mdna:99]
•Blue Planet Automation Software and Services segment loss decreased by $4.0 million, primarily due to improved margins on software services as described above, partially offset by lower sales volume as described above.

[0000936395-24-000008:mdna:100]
•Global Services segment profit increased by $7.5 million, primarily due to higher sales volume and improved margins as described above.

[0000936395-24-000008:mdna:101]
[same as prior period, unchanged from 0000936395-23-000034:mdna:141]

[0000936395-24-000008:mdna:102]
Overview. For the three months ended January 27, 2024, we generated $266.1 million of cash in operating activities. Net income (adjusted for non-cash charges) provided approximately $136.1 million of cash and working capital provided approximately $130.0 million of cash. For additional details, see “Cash Provided By Operating Activities” below.

[0000936395-24-000008:mdna:103]
Cash, cash equivalents and investments increased by $225.6 million during the first three months of fiscal 2024. Cash from operations was partially offset by the following: (i) cash used for stock repurchases under our stock repurchase program of $38.2 million; (ii) cash used to fund our investing activities for capital expenditures totaling $16.6 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $10.1 million. In addition to cash provided by operating activities, proceeds from the issuance of equity under our employee stock purchase plan provided $16.9 million in cash during the three months ended January 27, 2024.

[0000936395-24-000008:mdna:104]
[same as prior period, unchanged from 0000936395-23-000034:mdna:145]

[0000936395-24-000008:mdna:105]
|  | January 27,2024 |  | October 28,2023 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,264,751 |  |  | $ | 1,010,618 |  |  | $ | 254,133 |  |
| Short-term investments in marketable debt securities | 106,678 |  |  | 104,753 |  |  | 1,925 |  |
| Long-term investments in marketable debt securities | 103,862 |  |  | 134,278 |  |  | (30,416) |  |
| Total cash, cash equivalents, and investments in marketable debt securities | $ | 1,475,291 |  |  | $ | 1,249,649 |  |  | $ | 225,642 |  |

[0000936395-24-000008:mdna:106]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents, and investments, which, as of January 27, 2024 totaled $1.5 billion, as well as the unused portion of the Revolving Credit Facility, to which we and certain of our subsidiaries are parties. The Revolving Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 24, 2028. We principally use the Revolving Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and for general corporate purposes. As of

[0000936395-24-000008:mdna:107]
January 27, 2024, letters of credit totaling $70.6 million were issued under the Revolving Credit Facility. There were no borrowings outstanding under the Revolving Credit Facility as of January 27, 2024.

[0000936395-24-000008:mdna:108]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $214.6 million as of January 27, 2024. Approximately $93.0 million of future cash generated from these foreign subsidiaries is expected to be repatriated with any remaining amount continuing to be indefinitely reinvested. A deferred tax liability related to the expected repatriation amount was accrued in fiscal 2023. There are no other significant temporary differences related to our investment in the foreign subsidiaries for which a deferred tax liability has not been recognized.

[0000936395-24-000008:mdna:109]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. During the first quarter of fiscal 2024, we repurchased an additional $32.0 million of our common stock under the stock repurchase program, and $218.0 million remained under the current repurchase authorization as of January 27, 2024. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000008:mdna:110]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our Revolving Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-24-000008:mdna:111]
Cash Provided By Operating Activities

[0000936395-24-000008:mdna:112]
The following sections set forth the components of our $266.1 million of cash provided by operating activities during the first three months of fiscal 2024:

[0000936395-24-000008:mdna:113]
[same as prior period, unchanged from 0000936395-23-000034:mdna:153]

[0000936395-24-000008:mdna:114]
[same as prior period, unchanged from 0000936395-23-000034:mdna:154]

[0000936395-24-000008:mdna:115]
|  | Three Months Ended |
|  | January 27, 2024 |
| Net income | $ | 49,547 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 22,808 |  |
| Share-based compensation expenses | 37,827 |  |
| Amortization of intangible assets | 10,016 |  |
| Deferred taxes | (4,368) |  |
| Provision for inventory excess and obsolescence | 10,350 |  |
| Provision for warranty | 4,841 |  |
| Other | 5,051 |  |
| Net income (adjusted for non-cash charges) | $ | 136,072 |  |

[0000936395-24-000008:mdna:116]
[same as prior period, unchanged from 0000936395-23-000034:mdna:156]

[0000936395-24-000008:mdna:117]
We provided $130.0 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-24-000008:mdna:118]
|  | Three Months Ended |
|  | January 27, 2024 |
| Cash provided by accounts receivable | $ | 135,160 |  |
| Cash provided by inventories | 56,157 |  |
| Cash provided by prepaid expenses and other | 17,116 |  |
| Cash used in accounts payable, accruals, and other obligations | (90,915) |  |
| Cash provided by deferred revenue | 14,022 |  |
| Cash used in operating lease assets and liabilities, net | (1,536) |  |
| Total cash provided by working capital | $ | 130,004 |  |

[0000936395-24-000008:mdna:119]
As compared to the end of fiscal 2023:

[0000936395-24-000008:mdna:120]
•The $135.2 million of cash provided by accounts receivable during the first three months of fiscal 2024 primarily reflects increased cash collections and lower sales volume as compared to the fourth quarter of fiscal 2023;

[0000936395-24-000008:mdna:121]
•The $56.2 million of cash provided by inventories during the first three months of fiscal 2024 primarily reflects the consumption of raw materials in excess of purchases, partially offset by increases in finished goods inventories from planned fulfillment of customer advance orders for which some deliveries have since been rescheduled as described in “Overview” above;

[0000936395-24-000008:mdna:122]
•The $17.1 million of cash provided by prepaid expense and other during the first three months of fiscal 2024 primarily reflects lower non-trade receivables, upfront fees paid to customers and capitalized contract acquisition costs;

[0000936395-24-000008:mdna:123]
•The $90.9 million of cash used in accounts payable, accruals, and other obligations during the first three months of fiscal 2024 primarily reflects the timing of payments to employees under our annual cash incentive compensation plans;

[0000936395-24-000008:mdna:124]
•The $14.0 million of cash provided by deferred revenue during the first three months of fiscal 2024 represents an increase in advanced payments received on multi-year maintenance contracts from customers prior to revenue recognition; and

[0000936395-24-000008:mdna:125]
•The $1.5 million of cash used in operating lease assets and liabilities, net, during the first three months of fiscal 2024 represents cash paid for operating lease payments in excess of operating lease costs.

[0000936395-24-000008:mdna:126]
Our days sales outstanding (“DSOs”) decreased from 103 for the first three months of fiscal 2023 to 88 for the first three months of fiscal 2024. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns increased from 1.7 for the first three months of fiscal 2023 to 1.9 for the first three months of fiscal 2024.

[0000936395-24-000008:mdna:127]
[same as prior period, unchanged from 0000936395-23-000034:mdna:167]

[0000936395-24-000008:mdna:128]
[same as prior period, unchanged from 0000936395-23-000034:mdna:168]

[0000936395-24-000008:mdna:129]
|  | Three Months Ended |
|  | January 27, 2024 |
| 2030 New Term Loan due October 28, 2030(1) | 21,473 |  |
| 2030 Senior Notes due January 31, 2030(2) | — |  |
| Interest rate swaps(3) | (3,882) |  |
| Revolving Credit Facility(4) | 12 |  |
| Finance leases | 979 |  |
| Cash paid during period | $ | 18,582 |  |

[0000936395-24-000008:mdna:130]
(1) Interest on the 2030 New Term Loan is payable periodically based on the interest period selected for borrowing. The 2030 New Term Loan bears interest at SOFR for the chosen borrowing period plus a spread of 2.00% subject to a minimum SOFR rate of 0.00%. At the end of the first quarter of fiscal 2024, the interest rate on the 2030 New Term Loan was 7.34%.

[0000936395-24-000008:mdna:131]
(2) The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year.

[0000936395-24-000008:mdna:132]
(3) Our interest rate swaps fix the SOFR rate for $350.0 million of our Term Loans at 3.47% through January 2028 and another $350.0 million of our Term Loans at 2.968% through September 2025.

[0000936395-24-000008:mdna:133]
(4) During the first three months of fiscal 2024, we utilized the Revolving Credit Facility to issue certain standby letters of credit and paid nominal commitment fees, interest expense and other administrative charges primarily relating to the Revolving Credit Facility, approximately $0.3 million was accrued as of January 27, 2024.

[0000936395-24-000008:mdna:134]
For additional information about our debt and interest rate swaps, see Notes 12 and 13 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-24-000008:mdna:135]
[same as prior period, unchanged from 0000936395-23-000034:mdna:177]

[0000936395-24-000008:mdna:136]
Our contractual obligations have not changed materially since October 28, 2023, except for the items listed below. For a summary of our contractual obligations, see Item 7 of Part II of the 2023 Annual Report.

[0000936395-24-000008:mdna:137]
Purchase Order Obligations. As of January 27, 2024 we had $1.9 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule, or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable, and unconditional obligations.

[0000936395-24-000008:mdna:138]
[same as prior period, unchanged from 0000936395-23-000034:mdna:181]

[0000936395-24-000008:mdna:139]
Our critical accounting policies and estimates have not changed materially since October 28, 2023. For a discussion of our critical accounting policies and estimates, see “Management’s Discussion and Analysis of Financial Condition and Results of Operations” in Item 7 of Part II of our 2023 Annual Report.

[0000936395-24-000008:mdna:140]
[same as prior period, unchanged from 0000936395-23-000034:mdna:184]

[0000936395-24-000008:mdna:141]
[same as prior period, unchanged from 0000936395-23-000034:mdna:185]
