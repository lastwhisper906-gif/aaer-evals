# CIEN MD&A — 0000936395-15-000038


## mdna

[0000936395-15-000038:mdna:1]
[same as prior period, unchanged from 0000936395-15-000024:mdna:1]

[0000936395-15-000038:mdna:2]
Some of the statements contained in this quarterly report discuss future events or expectations, contain projections of results of operations or financial condition, changes in the markets for our products and services, or state other “forward-looking” information. Ciena’s “forward-looking” information is based on various factors and was derived using numerous assumptions. In some cases, you can identify these “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential” or “continue” or the negative of those words and other comparable words. You should be aware that these statements only reflect our current predictions and beliefs. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially. Important factors that could cause our actual results to be materially different from the forward-looking statements are disclosed throughout this report, particularly in Item 1A “Risk Factors” of Part II of this report below. For a more complete understanding of the risks associated with an investment in Ciena’s securities, you should review these risk factors and the rest of this quarterly report in combination with the more detailed description of our business and management’s discussion and analysis of financial condition in our annual report on Form 10-K, which we filed with the Securities and Exchange Commission ("SEC") on December 19, 2014. Ciena undertakes no obligation to revise or update any forward-looking statements.

[0000936395-15-000038:mdna:3]
[same as prior period, unchanged from 0000936395-15-000024:mdna:3]

[0000936395-15-000038:mdna:4]
[same as prior period, unchanged from 0000936395-15-000024:mdna:4]

[0000936395-15-000038:mdna:5]
[same as prior period, unchanged from 0000936395-15-000024:mdna:5]

[0000936395-15-000038:mdna:6]
The rapid proliferation of communications services and devices, together with increased mobility and growth in cloud-based services, have fundamentally affected the demands placed upon communications networks and how they are designed.

[0000936395-15-000038:mdna:7]
Network operators also face a rapidly changing business environment that includes a shifting competitive landscape and challenges to existing business models. Our OPn Architecture, and the increased network scalability, flexibility and programmability that it enables, is designed to meet these challenges. Our OPn network approach allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and network resources. This approach enables highly configurable infrastructures that can meet the "on-demand" requirements of end-users and the changing services they rely upon. By enhancing software programmability and control, enabling network functions virtually, and reducing required network elements, our OPn approach optimizes network infrastructures to connect content data centers, and users to such content. At the same time, our approach creates business and operational value for our customers by increasing scale at reduced cost and facilitating rapid introduction of new, revenue-generating service offerings. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the "Strategy" section below.

[0000936395-15-000038:mdna:8]
[same as prior period, unchanged from 0000936395-15-000024:mdna:7]

[0000936395-15-000038:mdna:9]
[same as prior period, unchanged from 0000936395-15-000024:mdna:8]

[0000936395-15-000038:mdna:10]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, technology convergence, increased mobility, and evolving cloud-based service offerings and on-demand end-user service expectations. These conditions have created market opportunities and challenges that have impacted how networks are designed and services are consumed. These conditions have also resulted in a diverse set of network operator customer segments, and shifting competitive landscapes for network operators and the vendors that support them. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services. At the same time, network operators continue to seek to manage the costs of their network and to ensure a profitable business model. These dynamics are driving technology convergence of network features, functions and layers, virtualization of certain network functions, and the adoption of software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that these conditions will require vendors and network operators to leverage an open ecosystem of virtualized resources provided by a variety of third parties and will drive increased openness and interoperability of network infrastructures.

[0000936395-15-000038:mdna:11]
In recent periods, we have seen certain of our large service provider customers, including some in North America, take steps to constrain their capital expenditure budgets. This measured spending environment has adversely impacted segments of our market and the spending levels we have experienced from certain of these customers as compared to prior periods. During fiscal 2014 and the first six months of fiscal 2015, we were able to continue to grow total revenue, in part, as a result of our strategy of focusing on certain higher growth segments of the network infrastructure market and the shift in spending toward next-generation solutions that enable network operators to better monetize their network infrastructures. We also benefited from our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers and multi-service operators, and to secure additional service provider customers in geographies including Brazil and India. We believe that our results underscore the importance of having established customer relationships with both traditional communications service providers and Web-scale providers as their purchasing decisions and focus on open, on-demand network environments become increasingly interdependent.

[0000936395-15-000038:mdna:12]
Our broader corporate strategy to capitalize on market dynamics and drive profitable growth of our business includes the initiatives set forth in the "Strategy" section below.

[0000936395-15-000038:mdna:13]
[same as prior period, unchanged from 0000936395-15-000024:mdna:11]

[0000936395-15-000038:mdna:14]
We continue to encounter a highly competitive and and fragmented marketplace. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approach, particularly in metro applications. Our sales of Packet Networking solutions, including our 8700 Packetwave Platform, also face a highly competitive marketplace for data center interconnection and connecting users-to-content, with additional competitors, including traditional IP router

[0000936395-15-000038:mdna:15]
vendors. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-15-000038:mdna:16]
[same as prior period, unchanged from 0000936395-15-000024:mdna:13]

[0000936395-15-000038:mdna:17]
[same as prior period, unchanged from 0000936395-15-000024:mdna:14]

[0000936395-15-000038:mdna:18]
[same as prior period, unchanged from 0000936395-15-000024:mdna:15]

[0000936395-15-000038:mdna:19]
Promotion of Our OPn Architecture.  Our OPn Architecture enables a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Our OPn Architecture leverages this convergence to enable network operators to scale their networks efficiently and cost effectively, while applying advanced software-based network control and network-level software applications for enhanced programmability. The software-driven aspects of this architecture become increasingly important as network operators increasingly seek to leverage an open ecosystem of virtualized resources to enable the real-time analytics and network agility required for on-demand, next-generation network architectures. We see opportunities in offering a portfolio of OPn Architecture solutions that facilitate the transition to these next-generation networks and that are optimized to create new services rapidly and to meet end-user demands.

[0000936395-15-000038:mdna:20]
Research and Development Investment to Expand the Role and Application of Our Solutions. Our product development initiatives are focused on opportunities that enable Ciena to expand its role in customer networks and to address a more diverse set of network applications. We are investing in our OPn Architecture with current development efforts focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnectivity and wide area network applications. Our research and development efforts also seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce Terabit per second and greater transmission speeds. In the packet area, we are increasing the scale, density and capability of our packet offerings, and reducing power and space requirements, for applications in metro networks, user aggregation and data center connectivity. In the software area, we are focusing on Agility Matrix, our network function virtualization (NFV) solution, in order to provide virtual network functions in managed service applications. We are also focused on increasing programmability and software control of networks. These efforts include our joint initiative with Ericsson to develop an expanded software-defined networking (SDN) multilayer WAN controller that spans network layers, as well as Ciena's direct efforts to develop software-based networking control platforms and network-level software applications.

[0000936395-15-000038:mdna:21]
Go-to-Market Model to Expand Our Role and Reach. Our go-to-market model is focused on driving sales growth from the diversification of our business and further penetrating additional customer verticals and international markets. We are also focused on further penetrating Internet content providers, data center operators and other emerging network operators that form the "Web-scale" marketplace, which are changing the ways in which information and services are accessed and provided. To expand the geographic reach of our direct sales resources, we have pursued strategic channel opportunities that enable sales through third parties, including service providers, systems integrators and value-added resellers. Through the packet-optical resale element of our strategic relationship with Ericsson, we are seeking to expand our geographic reach, as well as the application of our products in customer networks. We also remain focused on expanding the application of our products by existing customers, including communications service provider customers and cable and multiservice operators. These sales efforts seek opportunities for our solutions in applications including metro aggregation, data center interconnectivity, managed services offerings, cloud-based services, business Ethernet services and mobile backhaul.

[0000936395-15-000038:mdna:22]
Business Optimization to Yield Operating Leverage. We are actively pursuing initiatives to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and procurement initiatives to consolidate vendors and to ensure that our product cost model remains ahead of market-based price erosion. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs,

[0000936395-15-000038:mdna:23]
reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-15-000038:mdna:24]
Pending Acquisition of Cyan, Inc.

[0000936395-15-000038:mdna:25]
On May 3, 2015, we entered into a definitive merger agreement to acquire Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions with fiscal 2014 revenues of approximately $101.0 million. At the time of the signing of the merger agreement, this stock and cash transaction was valued at approximately $400.0 million (or $335.0 million, net of estimated cash acquired) and inclusive of Cyan’s outstanding $50 million convertible notes on an as-converted basis. This acquisition is intended to advance a strategy that started with the introduction of our OPn architecture and was extended with the launch of our Agility software division in fiscal 2014. Ciena believes that Cyan's complementary, best-in-class software solutions portfolio, when paired with our Agility portfolio, will strengthen Ciena’s software solutions portfolio and provides orchestration and network management capabilities that accelerate Ciena’s software development strategy and present a longer-term market and revenue opportunity.  Ciena believes that this strategic acquisition will accelerate the availability of Ciena to offer a complete, on-demand solution for virtualized networks and services in an open ecosystem, and will enable Ciena to play a leading role in the transformation of the network from the delivery of pure capacity to the creation of capability on-demand.

[0000936395-15-000038:mdna:26]
Subject to the terms and conditions of the merger agreement, at closing each Cyan share will be exchanged for merger consideration equal to the value of 0.224 shares of our common stock, 89% of which will be delivered in our common stock and 11% will be delivered in cash based on the value of our common stock at closing. We plan to pay the cash consideration portion of the merger consideration from cash on hand.  In connection with the acquisition, Ciena will also assume Cyan’s $50 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019.  Under the terms of the indenture governing the notes, for a period following closing, the note holders may elect to convert such notes at an increased conversion rate, or alternatively require that all or a portion of their notes be purchased for cash at a purchase price equal to the principal plus accrued interest. In the event that any note holders do not make either such election, such notes will become obligations of Ciena. Based on the structure of the transaction, Cyan’s outstanding warrants will be deemed to have been automatically exercised upon closing. In addition, Ciena will also assume Cyan’s outstanding equity awards. Certain Cyan officers and directors and affiliated stockholders, including investment funds affiliated with certain directors, who at the time of the signing of the merger agreement collectively controlled approximately 40% of the voting power of the then outstanding shares of Cyan common stock, have entered into voting agreements with Ciena that obligate them to vote in favor of the merger, subject to certain exceptions and limitations. The transaction, which is expected to close in our fourth fiscal quarter of 2015, is subject to approval by Cyan shareholders and satisfaction of certain other customary closing conditions, including the receipt of certain regulatory approvals.

[0000936395-15-000038:mdna:27]
During the second quarter of fiscal 2015, Ciena incurred approximately $1.0 million of acquisition-related costs associated with this pending transaction. We expect to incur a number of non-recurring costs associated with the merger during the remainder of fiscal 2015. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other potential employment-related costs, including payments that may be made to certain Cyan executives. Some of these costs are payable regardless of whether the merger is completed. We currently expect to incur approximately $30.0 million of such expenses, with the substantial majority of such costs to be recognized as acquisition and integration costs and restructuring costs during our third and fourth quarters of fiscal 2015.

[0000936395-15-000038:mdna:28]
Except where specifically indicated, the discussion in this “Management’s Discussion and Analysis of Financial Condition and Results of Operations” does not give effect to the possible consummation of the pending acquisition of Cyan and the effect on our results of operations.

[0000936395-15-000038:mdna:29]
Maturity of 4.0% Convertible Senior Notes due 2015

[0000936395-15-000038:mdna:30]
On March 15, 2015, our outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture governing the 2015 Notes, together with certain private exchange transactions conducted by us prior to maturity, approximately $180.6 million in aggregate principal amount of the 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of the 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, we issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. We repaid in cash approximately $6.9 million in aggregate principal amount of the 2015 Notes at maturity. See Item 2 of Part II of this report for addition information relating to the issuance of shares of Ciena common stock in connection with the 2015 Notes.

[0000936395-15-000038:mdna:31]
New Product Introduction

[0000936395-15-000038:mdna:32]
We have introduced a number of new product platforms and chipsets during fiscal 2015 and in May 2015 launched our new Waveserver™ product. Waveserver is a stackable data center interconnect (DCI) platform that allows network operators, including Web-scale providers and data center operators, to scale bandwidth quickly and to support high-speed data transfer, virtual machine migration and disaster recovery/backup between data centers. Waveserver is a specialized platform, purpose-built for connecting data centers within a single metro area. It is optimized for the capacity, speed, space and power requirements of data center environments. Waveserver is designed to leverage the data server user experience, with open APIs and server-like deployment, provisioning and programmability via smart devices. Revenue from sales of Waveserver will be included in our Converged Packet Optical segment.

[0000936395-15-000038:mdna:33]
[same as prior period, unchanged from 0000936395-15-000024:mdna:20]

[0000936395-15-000038:mdna:34]
Revenue for the second quarter of fiscal 2015 was $621.6 million, representing a sequential increase of 17.5% from $529.2 million in the first quarter of fiscal 2015. Revenue-related details reflecting sequential changes from the first quarter of fiscal 2015 include:

[0000936395-15-000038:mdna:35]
| • | Product revenue for the second quarter of fiscal 2015 increased by $89.6 million, reflecting an increase of $96.4 million in Converged Packet Optical, partially offset by decreases of $5.9 million in Optical Transport and $1.7 million in Packet Networking. |

[0000936395-15-000038:mdna:36]
| • | Service revenue for the second quarter of fiscal 2015 increased by $2.9 million. |

[0000936395-15-000038:mdna:37]
| • | North America revenue for the second quarter of fiscal 2015 was $397.2 million, an increase from $331.5 million in the first quarter of fiscal 2015. This primarily reflects increases of $73.6 million in Converged Packet Optical, partially offset by decreases of $4.6 million in Software and Services, $1.7 million in Packet Networking and $1.6 million in Optical Transport, |

[0000936395-15-000038:mdna:38]
| • | Europe, Middle East and Africa ("EMEA") revenue for the second quarter of fiscal 2015 was $102.2 million, a decrease from $111.0 million in the first quarter of fiscal 2015. This primarily reflects decreases of $3.9 million in Converged Packet Optical, $2.9 million in Optical Transport and $1.5 million in Software and Services. |

[0000936395-15-000038:mdna:39]
| • | Caribbean and Latin America ("CALA") revenue for the second quarter of fiscal 2015 was $47.9 million, an increase from $42.8 million in the first quarter of fiscal 2015. This primarily reflects an increase of $6.7 million in Converged Packet Optical, partially offset by a $1.5 million decrease in Optical Transport. |

[0000936395-15-000038:mdna:40]
| • | Asia Pacific ("APAC") revenue for the second quarter of fiscal 2015 was $74.3 million, an increase from $43.9 million in the first quarter of fiscal 2015. This primarily reflects increases of $19.9 million in Converged Packet Optical and $9.8 million in Software and Services. |

[0000936395-15-000038:mdna:41]
| • | For the second quarter of fiscal 2015, AT&T accounted for 18.9% of total revenue. This compares to 22.0% of total revenue in the first quarter of fiscal 2015. |

[0000936395-15-000038:mdna:42]
Gross margin for the second quarter of fiscal 2015 was 43.8%, an increase from 43.5% in the first quarter of fiscal 2015.

[0000936395-15-000038:mdna:43]
Operating expense was $230.0 million for the second quarter of fiscal 2015, an increase from $226.1 million in the first quarter of fiscal 2015. Second quarter fiscal 2015 operating expense primarily reflects increases of $5.8 million in selling and marketing expense and $4.4 million in research and development expense, partially offset by a decrease of $8.1 million in restructuring expense. Operating expense for the second quarter of fiscal 2015 also reflects $1.0 million in acquisition and integration costs, principally related to legal and accounting service fees, associated with our pending acquisition of Cyan described above.

[0000936395-15-000038:mdna:44]
As a result of the revenue increase discussed above, income from operations for the second quarter of fiscal 2015 was $42.4 million, compared to income from operations of $4.2 million during the first quarter of fiscal 2015. Our net income for the second quarter of fiscal 2015 was $20.7 million, or $0.17 per diluted common share. This compares to a net loss of $18.8 million or $0.17 per diluted common share, for the first quarter of fiscal 2015.

[0000936395-15-000038:mdna:45]
We generated cash from operations of $37.8 million during the second quarter of fiscal 2015, consisting of $79.8 million in cash provided by net income adjusted for non-cash charges and a $42.0 million use of cash related to increases in working capital. This compares with $22.1 million of cash generated from operations during the first quarter of fiscal 2015, consisting of $16.4 million in cash provided by net losses adjusted for non-cash charges and $5.7 million provided by cash related to reductions in working capital.

[0000936395-15-000038:mdna:46]
As of April 30, 2015, we had $586.3 million in cash and cash equivalents, $145.1 million of short-term investments in U.S. treasury securities and commercial paper, and $85.2 million of long-term investments in U.S. treasury securities. This compares

[0000936395-15-000038:mdna:47]
to $325.1 million in cash and cash equivalents, $90.1 million of short-term investments in U.S. treasury securities and commercial paper and $15.0 million of long-term investments in U.S. treasury securities, at April 30, 2014, and $586.7 million in cash and cash equivalents, $140.2 million of short-term investments in U.S. treasury securities and commercial paper, and $50.1 million of long-term investments in U.S. treasury securities at October 31, 2014.

[0000936395-15-000038:mdna:48]
As of April 30, 2015, we had 5,108 employees, a decrease from 5,161 at October 31, 2014 and an increase from 4,998 at April 30, 2014.

[0000936395-15-000038:mdna:49]
[same as prior period, unchanged from 0000936395-15-000024:mdna:37]

[0000936395-15-000038:mdna:50]
[same as prior period, unchanged from 0000936395-15-000024:mdna:38]

[0000936395-15-000038:mdna:51]
[same as prior period, unchanged from 0000936395-15-000024:mdna:39]

[0000936395-15-000038:mdna:52]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. In May 2015, we launched our new Waveserver™ product. Revenue from sales of Waveserver will be included in our Converged Packet Optical segment. |

[0000936395-15-000038:mdna:53]
[same as prior period, unchanged from 0000936395-15-000024:mdna:41]

[0000936395-15-000038:mdna:54]
[same as prior period, unchanged from 0000936395-15-000024:mdna:42]

[0000936395-15-000038:mdna:55]
[same as prior period, unchanged from 0000936395-15-000024:mdna:43]

[0000936395-15-000038:mdna:56]
Quarter ended April 30, 2014 compared to the quarter ended April 30, 2015

[0000936395-15-000038:mdna:57]
[same as prior period, unchanged from 0000936395-15-000024:mdna:45]

[0000936395-15-000038:mdna:58]
During the first quarter of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars during the second quarter of fiscal 2015 was adversely impacted by approximately $22.5 million or 3.5% as compared to the second quarter of fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000038:mdna:59]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 356,840 |  |  | 63.7 |  | $ | 432,911 |  |  | 69.6 |  | $ | 76,071 |  |  | 21.3 |  |
| Packet Networking | 66,526 |  |  | 11.9 |  | 53,288 |  |  | 8.6 |  | (13,238 | ) |  | (19.9 | ) |
| Optical Transport | 29,616 |  |  | 5.3 |  | 16,454 |  |  | 2.7 |  | (13,162 | ) |  | (44.4 | ) |
| Software and Services | 107,079 |  |  | 19.1 |  | 118,949 |  |  | 19.1 |  | 11,870 |  |  | 11.1 |  |
| Consolidated revenue | $ | 560,061 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 61,541 |  |  | 11.0 |  |

[0000936395-15-000038:mdna:60]
[same as prior period, unchanged from 0000936395-15-000024:mdna:48]

[0000936395-15-000038:mdna:61]
[same as prior period, unchanged from 0000936395-15-000024:mdna:49]

[0000936395-15-000038:mdna:62]
[same as prior period, unchanged from 0000936395-15-000024:mdna:50]

[0000936395-15-000038:mdna:63]
| • | Converged Packet Optical revenue increased, primarily reflecting a $74.0 million increase in sales of our 6500 Packet-Optical Platform, largely driven by network operator demand for high-capacity, optical transport for coherent 40G and 100G network infrastructure. Segment revenue also reflects increases of $3.7 million in sales of our 5430 Reconfigurable Switching System and $3.4 million in sales of the OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by a $5.0 million decrease in sales of our CoreDirector® Multiservice Optical Switches. The strong performance of this segment, particularly as compared to the steady declines we have experienced and expect to continue to experience in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000038:mdna:64]
| • | Packet Networking revenue decreased, reflecting a $14.9 million decrease in sales of our 3000 and 5000 families of service delivery and aggregation switches. This decrease was partially offset by increases of $1.2 million in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014, and $1.1 million in sales of our 5410 Service Aggregation Switch. |

[0000936395-15-000038:mdna:65]
| • | Optical Transport revenue decreased, reflecting decreases of $7.3 million in sales of our 4200 Advanced Services Platform, $3.0 million in sales of our other stand-alone transport products and $2.9 million of our 5100/5200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years. We expect this trend to continue, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-15-000038:mdna:66]
| • | Software and Services revenue increased, reflecting increases of $6.0 million in installation and deployment services revenue, $2.7 million in maintenance and support services revenue, $1.8 million in consulting revenue and $1.4 million in software revenue. |

[0000936395-15-000038:mdna:67]
[same as prior period, unchanged from 0000936395-15-000024:mdna:55]

[0000936395-15-000038:mdna:68]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 377,769 |  |  | 67.4 |  | 397,181 |  |  | 63.9 |  | $ | 19,412 |  |  | 5.1 |
| EMEA | 95,114 |  |  | 17.0 |  | 102,194 |  |  | 16.4 |  | 7,080 |  |  | 7.4 |
| CALA | 40,234 |  |  | 7.2 |  | 47,891 |  |  | 7.7 |  | 7,657 |  |  | 19.0 |
| APAC | 46,944 |  |  | 8.4 |  | 74,336 |  |  | 12.0 |  | 27,392 |  |  | 58.4 |
| Total | $ | 560,061 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 61,541 |  |  | 11.0 |

[0000936395-15-000038:mdna:69]
[same as prior period, unchanged from 0000936395-15-000024:mdna:57]

[0000936395-15-000038:mdna:70]
[same as prior period, unchanged from 0000936395-15-000024:mdna:58]

[0000936395-15-000038:mdna:71]
37

[0000936395-15-000038:mdna:72]
[same as prior period, unchanged from 0000936395-15-000024:mdna:59]

[0000936395-15-000038:mdna:73]
| • | North America revenue reflects increases of $38.5 million in Converged Packet Optical sales and $3.9 million in Software and Services sales. These increases were partially offset by decreases of $13.9 million in Packet Networking sales and $9.1 million in Optical Transport sales. Converged Packet Optical sales reflect a $40.6 million increase in sales of our 6500 Packet-Optical Platform, partially offset by a decrease of $2.4 million in sales of our CoreDirector® Multiservice Optical Switches. Sales of our 6500 Packet-Optical Platform reflect increased sales to AT&T, cable and multiservice operator customers and Web-scale providers, partially offset by decreased sales to certain large communication service provider customers. |

[0000936395-15-000038:mdna:74]
| • | EMEA revenue reflects a $14.6 million increase in sales of Converged Packet Optical sales, partially offset by decreases of $4.3 million in Software and Services sales and $3.7 million in Optical Transport sales. Converged Packet Optical sales reflects increases of $13.7 million in sales of our 6500 Packet-Optical Platform and $3.5 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by a $2.3 million decrease in sales of our CoreDirector® Multiservice Optical Switches. Sales of our 6500 Packet-Optical Platform reflect increased sales to submarine network operators, cable and multiservice operator customers and Web-scale providers, partially offset by decreased sales to certain large communication service providers. |

[0000936395-15-000038:mdna:75]
| • | CALA revenue reflects increases of $4.4 million in Converged Packet Optical sales, $2.4 million in Software and Services sales and $1.1 million in Optical Transport sales. Converged Packet Optical sales reflect a $10.7 million increase in sales of our 6500 Packet-Optical Platform, partially offset by a decrease of $5.6 million in sales of our 5430 Reconfigurable Switching System. |

[0000936395-15-000038:mdna:76]
| • | APAC revenue reflects increases of $18.6 million in Converged Packet Optical sales and $10.0 million in Software and Services sales. These increases were partially offset by a $1.6 million decrease in Optical Transport sales. Converged Packet Optical sales reflect increases of $11.7 million in sales of our 5430 Reconfigurable Switching System and $10.5 million in sales of our 6500 Packet-Optical Platform. These increases were partially offset by a $3.4 million decrease in sales of our OTN configuration for the 5410 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to submarine network operators and communication service providers. |

[0000936395-15-000038:mdna:77]
[same as prior period, unchanged from 0000936395-15-000024:mdna:66]

[0000936395-15-000038:mdna:78]
[same as prior period, unchanged from 0000936395-15-000024:mdna:67]

[0000936395-15-000038:mdna:79]
[same as prior period, unchanged from 0000936395-15-000024:mdna:68]

[0000936395-15-000038:mdna:80]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of lower margin "common" equipment sales and higher margin channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. We expect that gross margins will be subject to fluctuation based on our level of success in driving product cost reductions relative to the market-based price erosion we typically encounter. Accordingly gross margin can be adversely affected by the level of pricing pressure and competition that we encounter in the market. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods.

[0000936395-15-000038:mdna:81]
[same as prior period, unchanged from 0000936395-15-000024:mdna:70]

[0000936395-15-000038:mdna:82]
[same as prior period, unchanged from 0000936395-15-000024:mdna:71]

[0000936395-15-000038:mdna:83]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 560,061 |  |  | 100.0 |  | $ | 621,602 |  |  | 100.0 |  | $ | 61,541 |  |  | 11.0 |
| Total cost of goods sold | 322,370 |  |  | 57.6 |  | 349,191 |  |  | 56.2 |  | 26,821 |  |  | 8.3 |
| Gross profit | $ | 237,691 |  |  | 42.4 |  | $ | 272,411 |  |  | 43.8 |  | $ | 34,720 |  |  | 14.6 |

[0000936395-15-000038:mdna:84]
[same as prior period, unchanged from 0000936395-15-000024:mdna:73]

[0000936395-15-000038:mdna:85]
[same as prior period, unchanged from 0000936395-15-000024:mdna:74]

[0000936395-15-000038:mdna:86]
[same as prior period, unchanged from 0000936395-15-000024:mdna:75]

[0000936395-15-000038:mdna:87]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 460,821 |  |  | 100.0 |  | $ | 511,880 |  |  | 100.0 |  | $ | 51,059 |  |  | 11.1 |
| Product cost of goods sold | 257,632 |  |  | 55.9 |  | 286,898 |  |  | 56.0 |  | 29,266 |  |  | 11.4 |
| Product gross profit | $ | 203,189 |  |  | 44.1 |  | $ | 224,982 |  |  | 44.0 |  | $ | 21,793 |  |  | 10.7 |

[0000936395-15-000038:mdna:88]
[same as prior period, unchanged from 0000936395-15-000024:mdna:77]

[0000936395-15-000038:mdna:89]
[same as prior period, unchanged from 0000936395-15-000024:mdna:78]

[0000936395-15-000038:mdna:90]
[same as prior period, unchanged from 0000936395-15-000024:mdna:79]

[0000936395-15-000038:mdna:91]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 99,240 |  |  | 100.0 |  | $ | 109,722 |  |  | 100.0 |  | $ | 10,482 |  |  | 10.6 |  |
| Service cost of goods sold | 64,738 |  |  | 65.2 |  | 62,293 |  |  | 56.8 |  | (2,445 | ) |  | (3.8 | ) |
| Service gross profit | $ | 34,502 |  |  | 34.8 |  | $ | 47,429 |  |  | 43.2 |  | $ | 12,927 |  |  | 37.5 |  |

[0000936395-15-000038:mdna:92]
[same as prior period, unchanged from 0000936395-15-000024:mdna:81]

[0000936395-15-000038:mdna:93]
[same as prior period, unchanged from 0000936395-15-000024:mdna:82]

[0000936395-15-000038:mdna:94]
[same as prior period, unchanged from 0000936395-15-000024:mdna:83]

[0000936395-15-000038:mdna:95]
[same as prior period, unchanged from 0000936395-15-000024:mdna:84]

[0000936395-15-000038:mdna:96]
| • | Gross profit on products as a percentage of product revenue remained relatively unchanged as a result of our relative success in driving product cost reductions and realizing improved manufacturing efficiencies as compared to the market-based price erosion we encountered during the period. |

[0000936395-15-000038:mdna:97]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased sales of higher margin software subscription services and reductions in repair costs to support maintenance contracts. |

[0000936395-15-000038:mdna:98]
[same as prior period, unchanged from 0000936395-15-000024:mdna:87]

[0000936395-15-000038:mdna:99]
[same as prior period, unchanged from 0000936395-15-000024:mdna:88]

[0000936395-15-000038:mdna:100]
[same as prior period, unchanged from 0000936395-15-000024:mdna:89]

[0000936395-15-000038:mdna:101]
[same as prior period, unchanged from 0000936395-15-000024:mdna:90]

[0000936395-15-000038:mdna:102]
[same as prior period, unchanged from 0000936395-15-000024:mdna:91]

[0000936395-15-000038:mdna:103]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, facilities and systems consolidation costs associated with our pending acquisition of Cyan.

[0000936395-15-000038:mdna:104]
[same as prior period, unchanged from 0000936395-15-000024:mdna:92]

[0000936395-15-000038:mdna:105]
[same as prior period, unchanged from 0000936395-15-000024:mdna:93]

[0000936395-15-000038:mdna:106]
[same as prior period, unchanged from 0000936395-15-000024:mdna:94]

[0000936395-15-000038:mdna:107]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 103,492 |  |  | 18.5 |  | $ | 105,202 |  |  | 16.9 |  |  | $ | 1,710 |  |  | 1.7 |  |
| Selling and marketing | 83,662 |  |  | 14.9 |  | 82,471 |  |  | 13.3 |  |  | (1,191 | ) |  | (1.4 | ) |
| General and administrative | 31,882 |  |  | 5.7 |  | 30,302 |  |  | 4.9 |  |  | (1,580 | ) |  | (5.0 | ) |
| Acquisition and integration costs | — |  |  | — |  | 1,020 |  |  | 0.2 |  |  | 1,020 |  |  | 100.0 |  |
| Amortization of intangible assets | 11,493 |  |  | 2.1 |  | 11,019 |  |  | 1.8 |  |  | (474 | ) |  | (4.1 | ) |
| Restructuring costs | — |  |  | — |  | (17 | ) |  | — |  |  | (17 | ) |  | n/a |  |
| Total operating expenses | $ | 230,529 |  |  | 41.2 |  | $ | 229,997 |  |  | 37.1 |  |  | $ | (532 | ) |  | (0.2 | ) |

[0000936395-15-000038:mdna:108]
[same as prior period, unchanged from 0000936395-15-000024:mdna:96]

[0000936395-15-000038:mdna:109]
[same as prior period, unchanged from 0000936395-15-000024:mdna:97]

[0000936395-15-000038:mdna:110]
[same as prior period, unchanged from 0000936395-15-000024:mdna:98]

[0000936395-15-000038:mdna:111]
| • | Research and development expense benefited from $6.4 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the benefit from foreign exchange rates, research and development expenses increased by $1.7 million, primarily reflecting increases of $1.8 million in facilities and information technology costs and a $1.7 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario, partially offset by a $2.0 million decrease in professional services. |

[0000936395-15-000038:mdna:112]
| • | Selling and marketing expense benefited from $5.1 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the benefit from foreign exchange rates, selling and marketing expense decreased by $1.2 million, primarily reflecting a decrease in travel and related costs. |

[0000936395-15-000038:mdna:113]
| • | General and administrative expense benefited from $1.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro. Including the benefit from foreign exchange rates, general and administrative expense decreased by $1.6 million, primarily due to a decrease in legal fees and other consulting services. |

[0000936395-15-000038:mdna:114]
| • | Acquisition and integration costs reflect approximately $1.0 million of legal and accounting costs associated with the pending acquisition of Cyan. |

[0000936395-15-000038:mdna:115]
[same as prior period, unchanged from 0000936395-15-000024:mdna:102]

[0000936395-15-000038:mdna:116]
| • | Restructuring costs remained relatively unchanged. |

[0000936395-15-000038:mdna:117]
[same as prior period, unchanged from 0000936395-15-000024:mdna:104]

[0000936395-15-000038:mdna:118]
[same as prior period, unchanged from 0000936395-15-000024:mdna:105]

[0000936395-15-000038:mdna:119]
|  | Quarter Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (1,905 | ) |  | (0.3 | ) |  | $ | (5,549 | ) |  | (0.9 | ) |  | $ | (3,644 | ) |  | 191.3 |  |
| Interest expense | $ | 11,020 |  |  | 2.0 |  |  | $ | 12,947 |  |  | 2.1 |  |  | $ | 1,927 |  |  | 17.5 |  |
| Provision for income taxes | $ | 4,395 |  |  | 0.8 |  |  | $ | 3,265 |  |  | 0.5 |  |  | $ | (1,130 | ) |  | (25.7 | ) |

[0000936395-15-000038:mdna:120]
[same as prior period, unchanged from 0000936395-15-000024:mdna:107]

[0000936395-15-000038:mdna:121]
[same as prior period, unchanged from 0000936395-15-000024:mdna:108]

[0000936395-15-000038:mdna:122]
[same as prior period, unchanged from 0000936395-15-000024:mdna:109]

[0000936395-15-000038:mdna:123]
| • | Interest and other income (loss), net reflects a $4.2 million loss due to the remeasurement of assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $1.5 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 2015 Notes which matured during the second quarter of fiscal 2015. |

[0000936395-15-000038:mdna:124]
| • | Interest expense increased primarily due to the Term Loan that was entered into in the third quarter of fiscal 2014. For additional information about our Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-15-000038:mdna:125]
| • | Provision for income taxes decreased primarily due to foreign tax expense, which is largely a result of reductions in income from our Brazilian operations. |

[0000936395-15-000038:mdna:126]
Six months ended April 30, 2014 compared to the six months ended April 30, 2015

[0000936395-15-000038:mdna:127]
Revenue

[0000936395-15-000038:mdna:128]
During the first six months of fiscal 2015, as compared to the first six months of fiscal 2014, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars was adversely impacted by approximately $32.8 million or 2.8% as compared to the first six months of fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000038:mdna:129]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 690,241 |  |  | 63.1 |  | $ | 769,471 |  |  | 66.9 |  | $ | 79,230 |  |  | 11.5 |  |
| Packet Networking | 118,235 |  |  | 10.8 |  | 108,271 |  |  | 9.4 |  | (9,964 | ) |  | (8.4 | ) |
| Optical Transport | 69,713 |  |  | 6.4 |  | 38,793 |  |  | 3.4 |  | (30,920 | ) |  | (44.4 | ) |
| Software and Services | 215,575 |  |  | 19.7 |  | 234,229 |  |  | 20.3 |  | 18,654 |  |  | 8.7 |  |
| Consolidated revenue | $ | 1,093,764 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 57,000 |  |  | 5.2 |  |

[0000936395-15-000038:mdna:130]
_____________________________

[0000936395-15-000038:mdna:131]
*    Denotes % of total revenue

[0000936395-15-000038:mdna:132]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:133]
| • | Converged Packet Optical revenue increased reflecting an $88.2 million increase in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of the OTN configuration for the 5410 Reconfigurable Switching System and our 5430 reconfigurable switching system increased by $5.9 million and $1.8 million respectively. These increases were partially offset by a $16.7 million decrease in sales of our CoreDirector® Multiservice Optical Switches.The strong performance of this segment, particularly as compared to the expected revenue declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000038:mdna:134]
| • | Packet Networking revenue decreased reflecting decreases of $10.0 million in sales of our 3000 and 5000 families of service delivery and aggregation switches, $1.9 million in sales of our legacy broadband products and $1.0 million in sales of our 5410 Service Aggregation Switch to support wireless backhaul, Ethernet business services and residential |

[0000936395-15-000038:mdna:135]
broadband applications. These decreases were offset by a $3.0 million increase in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014.

[0000936395-15-000038:mdna:136]
| • | Optical Transport revenue decreased reflecting sales decreases of $12.1 million of 5100/5200 Advanced Services Platform, $11.9 million in our 4200 Advanced Services Platform, and $6.9 million in other stand-alone transport products. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000038:mdna:137]
| • | Software and Services revenue increased reflecting increases of $8.4 million in maintenance and support services, $5.4 million in installation and deployment services, $2.7 million in network transformation consulting services and $2.1 million in software sales. |

[0000936395-15-000038:mdna:138]
Revenue from sales to customers outside of the United States is reflected as International in the geographic distribution of revenue below. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-15-000038:mdna:139]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 733,617 |  |  | 67.1 |  | $ | 728,716 |  |  | 63.3 |  | $ | (4,901 | ) |  | (0.7 | ) |
| EMEA | 183,833 |  |  | 16.8 |  | 213,200 |  |  | 18.5 |  | 29,367 |  |  | 16.0 |  |
| CALA | 92,915 |  |  | 8.5 |  | 90,633 |  |  | 7.9 |  | (2,282 | ) |  | (2.5 | ) |
| APAC | 83,399 |  |  | 7.6 |  | 118,215 |  |  | 10.3 |  | 34,816 |  |  | 41.7 |  |
| Total | $ | 1,093,764 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 57,000 |  |  | 5.2 |  |

[0000936395-15-000038:mdna:140]
[same as prior period, unchanged from 0000936395-15-000024:mdna:116]

[0000936395-15-000038:mdna:141]
*    Denotes % of total revenue

[0000936395-15-000038:mdna:142]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:143]
| • | North America revenue reflects decreases of $22.7 million in Optical Transport sales and $9.1 million in Packet Networking sales. These decreases were partially offset by increases of $19.0 million in Converged Packet Optical sales and $7.9 million in Software and Services sales. Optical Transport sales reflect decreases of $14.1 million of sales of our other stand-alone transport products and $8.4 million of sales of our 4200 Advanced Services Platform. Converged Packet Optical sales reflect an increase of $31.7 million of sales of our 6500 Packet-Optical Platform, partially offset by a decrease of $12.9 million of sales of our CoreDirector® Multiservice Optical Switches. Sales of our 6500 Packet-Optical Platform reflect increased sales to AT&T, cable and multiservice operator customers and Web-scale providers, partially offset by decreased sales to certain large communication service provider customers. |

[0000936395-15-000038:mdna:144]
| • | EMEA revenue reflects a $41.4 million increase in sales of Converged Packet Optical. This increase was partially offset by decreases of $6.2 million in Optical Transport sales and $5.4 million in Software and Services sales. Converged Packet Optical sales reflect increases of $36.9 million of sales of our 6500 Packet-Optical Platform and $4.3 million of sales of our 5430 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to submarine network operators,Web-scale providers, certain large communication service providers and cable and multiservice operator customers. |

[0000936395-15-000038:mdna:145]
| • | CALA revenue reflects a $9.6 million decrease in Converged Packet Optical sales. This decrease was partially offset by increases of $6.6 million in Software and Services sales and $1.1 million in Optical Transport sales. Converged Packet Optical sales reflect a $19.7 million decrease in sales of our 5430 Reconfigurable Switching System. This decrease was partially offset by increases of $8.6 million in sales of our 6500 Packet-Optical Platform and $2.4 million of sales of our 5410 Reconfigurable Switching System. |

[0000936395-15-000038:mdna:146]
| • | APAC revenue reflects increases of $28.4 million in Converged Packet Optical sales and $9.6 million in Software and Services sales. These increases were partially offset by a $3.2 million decrease in sales of Optical Transport. Converged Packet Optical sales reflect increases of $18.7 million of sales of our 5430 Reconfigurable Switching System and $12.2 million of sales of our 6500 Packet-Optical Platform. These increases were partially offset by a decrease of $2.5 million of sales of our 5410 Reconfigurable Switching System. Sales of our 5430 Reconfigurable Switching System reflect increased sales to communication service providers and submarine network operators. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers and sales through our strategic relationship with Ericsson. |

[0000936395-15-000038:mdna:147]
42

[0000936395-15-000038:mdna:148]
Cost of Goods Sold and Gross Profit

[0000936395-15-000038:mdna:149]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-15-000038:mdna:150]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,093,764 |  |  | 100.0 |  | $ | 1,150,764 |  |  | 100.0 |  | $ | 57,000 |  |  | 5.2 |
| Total cost of goods sold | 630,222 |  |  | 57.6 |  | 648,058 |  |  | 56.3 |  | 17,836 |  |  | 2.8 |
| Gross profit | $ | 463,542 |  |  | 42.4 |  | $ | 502,706 |  |  | 43.7 |  | $ | 39,164 |  |  | 8.4 |

[0000936395-15-000038:mdna:151]
[same as prior period, unchanged from 0000936395-15-000024:mdna:167]

[0000936395-15-000038:mdna:152]
*    Denotes % of total revenue

[0000936395-15-000038:mdna:153]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:154]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 893,762 |  |  | 100.0 |  | $ | 934,195 |  |  | 100.0 |  | $ | 40,433 |  |  | 4.5 |
| Product cost of goods sold | 502,848 |  |  | 56.3 |  | 523,446 |  |  | 56.0 |  | 20,598 |  |  | 4.1 |
| Product gross profit | $ | 390,914 |  |  | 43.7 |  | $ | 410,749 |  |  | 44.0 |  | $ | 19,835 |  |  | 5.1 |

[0000936395-15-000038:mdna:155]
_____________________________________

[0000936395-15-000038:mdna:156]
*    Denotes % of product revenue

[0000936395-15-000038:mdna:157]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:158]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 200,002 |  |  | 100.0 |  | $ | 216,569 |  |  | 100.0 |  | $ | 16,567 |  |  | 8.3 |  |
| Service cost of goods sold | 127,374 |  |  | 63.7 |  | 124,612 |  |  | 57.5 |  | (2,762 | ) |  | (2.2 | ) |
| Service gross profit | $ | 72,628 |  |  | 36.3 |  | $ | 91,957 |  |  | 42.5 |  | $ | 19,329 |  |  | 26.6 |  |

[0000936395-15-000038:mdna:159]
_____________________________________

[0000936395-15-000038:mdna:160]
*    Denotes % of services revenue

[0000936395-15-000038:mdna:161]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:162]
| • | Gross profit as a percentage of revenue increased as a result of the factors described below. |

[0000936395-15-000038:mdna:163]
| • | Gross profit on products as a percentage of product revenue remained relatively unchanged as a result of our relative success in driving product cost reductions and realizing improved manufacturing efficiencies as compared to the market-based price erosion we encountered during the period. |

[0000936395-15-000038:mdna:164]
| • | Gross profit on services as a percentage of services revenue increased primarily due to increased sales of higher margin software subscription services and reduced repair costs to support maintenance service contracts. |

[0000936395-15-000038:mdna:165]
Operating Expense

[0000936395-15-000038:mdna:166]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-15-000038:mdna:167]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 204,989 |  |  | 18.7 |  | $ | 205,963 |  |  | 17.9 |  | $ | 974 |  |  | 0.5 |  |
| Selling and marketing | 162,010 |  |  | 14.8 |  | 159,183 |  |  | 13.8 |  | (2,827 | ) |  | (1.7 | ) |
| General and administrative | 61,979 |  |  | 5.7 |  | 59,855 |  |  | 5.2 |  | (2,124 | ) |  | (3.4 | ) |
| Acquisition and integration costs | — |  |  | — |  | 1,020 |  |  | 0.1 |  | 1,020 |  |  | — |  |
| Amortization of intangible assets | 23,932 |  |  | 2.2 |  | 22,038 |  |  | 1.9 |  | (1,894 | ) |  | (7.9 | ) |
| Restructuring costs | 115 |  |  | — |  | 8,068 |  |  | 0.7 |  | 7,953 |  |  | — |  |
| Total operating expenses | $ | 453,025 |  |  | 41.4 |  | $ | 456,127 |  |  | 39.6 |  | $ | 3,102 |  |  | 0.7 |  |

[0000936395-15-000038:mdna:168]
_____________________________________

[0000936395-15-000038:mdna:169]
*    Denotes % of total revenue

[0000936395-15-000038:mdna:170]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:171]
| • | Research and development expense benefited $10.9 million, as a result of foreign exchange rates, net of hedging, primarily due a stronger U.S. dollar in relation to the Canadian dollar. Including this benefit, research and development expenses increased by $1.0 million primarily reflecting increases of $3.5 million in facilities and information systems expense, $1.4 million in employee compensation and related costs, $1.0 million in technology and related costs and a $1.7 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario . These increases were partially offset by decreases of $5.0 million in professional services and $2.0 million in prototype expense. |

[0000936395-15-000038:mdna:172]
| • | Selling and marketing expense benefited $7.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and Canadian dollar. Including this benefit, selling and marketing expenses decreased by $2.8 million, primarily reflecting decreases of $1.8 million of travel and related costs, and $1.0 million in professional services. |

[0000936395-15-000038:mdna:173]
| • | General and administrative expense benefited $1.9 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and Canadian dollar. Including this benefit, general and administrative expense decreased by $2.1 million primarily reflecting a decrease of $4.0 million in professional services, partially offset by an increase of $1.3 million in employee compensation and related costs. |

[0000936395-15-000038:mdna:174]
| • | Acquisition and integration costs reflect approximately $1.0 million of legal and accounting costs associated with the pending acquisition of Cyan. |

[0000936395-15-000038:mdna:175]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-15-000038:mdna:176]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. During fiscal 2015, we have incurred approximately $8.1 million in restructuring costs, reflecting a global workforce reduction of approximately 125 employees in the first quarter of fiscal 2015 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-15-000038:mdna:177]
Other items

[0000936395-15-000038:mdna:178]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-15-000038:mdna:179]
|  | Six Months Ended April 30, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (7,903 | ) |  | (0.7 | ) |  | $ | (13,782 | ) |  | (1.2 | ) |  | $ | (5,879 | ) |  | 74.4 |  |
| Interest expense | $ | 22,048 |  |  | 2.0 |  |  | $ | 26,608 |  |  | 2.3 |  |  | $ | 4,560 |  |  | 20.7 |  |
| Provision for income taxes | $ | 6,660 |  |  | 0.6 |  |  | $ | 4,315 |  |  | 0.4 |  |  | $ | (2,345 | ) |  | (35.2 | ) |

[0000936395-15-000038:mdna:180]
_____________________________________

[0000936395-15-000038:mdna:181]
*    Denotes % of total revenue

[0000936395-15-000038:mdna:182]
**    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:183]
| • | Interest and other income (loss), net reflects a $7.6 million loss due to the remeasurement of assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $2.6 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 2015 Notes that matured in the second quarter of fiscal 2015. |

[0000936395-15-000038:mdna:184]
| • | Interest expense increased primarily due to the Term Loan entered into in the third quarter of fiscal 2014. For additional information about our Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-15-000038:mdna:185]
| • | Provision for income taxes decreased primarily due to foreign tax expense, which is largely a result of reduced income from our Brazilian operations. |

[0000936395-15-000038:mdna:186]
[same as prior period, unchanged from 0000936395-15-000024:mdna:113]

[0000936395-15-000038:mdna:187]
[same as prior period, unchanged from 0000936395-15-000024:mdna:114]

[0000936395-15-000038:mdna:188]
|  | Quarter Ended April 30, |  |  |  |
|  | 2014 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 96,581 |  |  | $ | 121,772 |  |  | $ | 25,191 |  |  | 26.1 |  |
| Packet Networking | $ | 8,196 |  |  | $ | 4,751 |  |  | $ | (3,445 | ) |  | (42.0 | ) |
| Optical Transport | $ | 4,709 |  |  | $ | 4,729 |  |  | $ | 20 |  |  | 0.4 |  |
| Software and Services | $ | 24,713 |  |  | $ | 35,957 |  |  | $ | 11,244 |  |  | 45.5 |  |

[0000936395-15-000038:mdna:189]
_____________________________________

[0000936395-15-000038:mdna:190]
[same as prior period, unchanged from 0000936395-15-000024:mdna:117]

[0000936395-15-000038:mdna:191]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume partially offset by lower gross margin and increased research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-15-000038:mdna:192]
| • | Packet Networking segment profit decreased primarily due to decreased sales volume, partially offset by reductions in research and development costs. |

[0000936395-15-000038:mdna:193]
| • | Optical Transport segment profit remained relatively unchanged as a result of higher gross margin on reduced sales volume. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced in recent years, and we expect will continue to experience, meaningful declines in annual revenue, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000038:mdna:194]
| • | Software and Services segment profit increased primarily due to increases in sales of installation services, software subscription services, support and consulting services, and increased margin due to lower repair costs to support maintenance service contracts. These increases were partially offset by increases in software research and development expense. |

[0000936395-15-000038:mdna:195]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit for the respective periods:

[0000936395-15-000038:mdna:196]
45

[0000936395-15-000038:mdna:197]
|  | Six Months Ended April 30, |  |  |  |  |
|  | 2014 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 175,279 |  |  | $ | 204,429 |  |  | $ | 29,150 |  |  | 16.6 |  |
| Packet Networking | $ | 8,581 |  |  | $ | 11,282 |  |  | $ | 2,701 |  |  | 31.5 |  |
| Optical Transport | $ | 20,359 |  |  | $ | 10,615 |  |  | $ | (9,744 | ) |  | (47.9 | ) |
| Software and Services | $ | 54,334 |  |  | $ | 70,417 |  |  | $ | 16,083 |  |  | 29.6 |  |

[0000936395-15-000038:mdna:198]
_____________________________________

[0000936395-15-000038:mdna:199]
*    Denotes % change from 2014 to 2015

[0000936395-15-000038:mdna:200]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume, partially offset by increased research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-15-000038:mdna:201]
| • | Packet Networking segment profit increased due to reduced research and development costs, partially offset by lower sales volume and lower gross margin. |

[0000936395-15-000038:mdna:202]
| • | Optical Transport segment profit decreased, primarily due to reduced sales volume and decreased gross margin. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000038:mdna:203]
| • | Software and Services segment profit increased primarily due to increases in sales of installation services, software subscription services, support and consulting services, and increased margin due to lower repair costs to support maintenance service contracts. These increases were partially offset by increased software research and development expense. |

[0000936395-15-000038:mdna:204]
[same as prior period, unchanged from 0000936395-15-000024:mdna:122]

[0000936395-15-000038:mdna:205]
At April 30, 2015, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-15-000038:mdna:206]
|  | October 31, 2014 |  | April 30, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 586,338 |  |  | $ | (382 | ) |
| Short-term investments in marketable debt securities | 140,205 |  |  | 145,089 |  |  | 4,884 |  |
| Long-term investments in marketable debt securities | 50,057 |  |  | 85,233 |  |  | 35,176 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 776,982 |  |  | $ | 816,660 |  |  | $ | 39,678 |  |

[0000936395-15-000038:mdna:207]
The change in total cash and cash equivalents and investments in marketable debt securities during the first six months of fiscal 2015 was primarily related to the following:

[0000936395-15-000038:mdna:208]
| • | $59.9 million cash generated from operations, consisting of $96.2 million provided by net income (adjusted for non-cash charges) offset by $36.3 million used in working capital; |

[0000936395-15-000038:mdna:209]
| • | $21.9 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-15-000038:mdna:210]
| • | $10.4 million provided by settlement of foreign currency forward contracts, net; |

[0000936395-15-000038:mdna:211]
| • | $4.7 million used to pay capital lease obligations; |

[0000936395-15-000038:mdna:212]
| • | $2.0 million used for the purchase of a cost method investment; |

[0000936395-15-000038:mdna:213]
| • | $8.2 million used for repayment of long-term debt; |

[0000936395-15-000038:mdna:214]
| • | $10.0 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; and |

[0000936395-15-000038:mdna:215]
| • | $3.3 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-15-000038:mdna:216]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200.0 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of April 30, 2015, letters of credit totaling $60.4 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2015.

[0000936395-15-000038:mdna:217]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. In assessing these liquidity requirements, we have considered the expected payments relating to the cash component of the merger consideration to be paid upon closing of our pending acquisition of Cyan and related acquisition, integration and restructuring costs.

[0000936395-15-000038:mdna:218]
The following sections set forth the components of our $59.9 million of cash generated from operating activities during the first six months of fiscal 2015:

[0000936395-15-000038:mdna:219]
Net income (adjusted for non-cash charges)

[0000936395-15-000038:mdna:220]
The following table sets forth (in thousands) our net income (adjusted for non-cash charges) during the period:

[0000936395-15-000038:mdna:221]
|  | Six months ended |
|  | April 30, 2015 |
| Net income | $ | 1,874 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 27,322 |  |
| Share-based compensation costs | 22,136 |  |
| Amortization of intangible assets | 26,439 |  |
| Provision for inventory excess and obsolescence | 10,834 |  |
| Provision for warranty | 7,658 |  |
| Other | (94 | ) |
| Net income (adjusted for non-cash charges) | $ | 96,169 |  |

[0000936395-15-000038:mdna:222]
[same as prior period, unchanged from 0000936395-15-000024:mdna:139]

[0000936395-15-000038:mdna:223]
[same as prior period, unchanged from 0000936395-15-000024:mdna:140]

[0000936395-15-000038:mdna:224]
Cash used by accounts receivable during the first six months of fiscal 2015, net of a $0.6 million provision for doubtful accounts, was $34.9 million. Our days sales outstanding (DSOs) increased from 85 days for the first six months of fiscal 2014 to 87 days for the first six months of fiscal 2015.

[0000936395-15-000038:mdna:225]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2014 through the end of the second quarter of fiscal 2015:

[0000936395-15-000038:mdna:226]
|  | October 31, 2014 |  | April 30, 2015 |  | Increase(decrease) |
| Accounts receivable, net | $ | 518,981 |  |  | $ | 553,306 |  |  | $ | 34,325 |  |

[0000936395-15-000038:mdna:227]
[same as prior period, unchanged from 0000936395-15-000024:mdna:144]

[0000936395-15-000038:mdna:228]
Cash generated from decreases in inventory during the first six months of fiscal 2015 was $29.2 million. Our inventory turns increased from 3.4 turns during the first six months of fiscal 2014 to 4.9 turns during the first six months of fiscal 2015. Our inventory balance, as reported on our Condensed Consolidated Balance Sheet, decreased by $40.1 million during the first six months of fiscal 2015 reflecting, in part, certain supply chain initiatives to improve manufacturing efficiencies and inventory management and the reduction of deferred costs of sales. The reduction of the deferred costs of sales relates to the completion of certain submarine network projects. This change reflects $29.2 million of cash provided by inventory and a

[0000936395-15-000038:mdna:229]
$10.8 million non-cash provision for excess and obsolescence. The following table sets forth (in thousands) changes to the components of our inventory from the end of fiscal 2014 through the end of the second quarter of fiscal 2015:

[0000936395-15-000038:mdna:230]
|  | October 31, 2014 |  | April 30, 2015 |  | Increase(decrease) |
| Raw materials | $ | 64,853 |  |  | $ | 57,343 |  |  | $ | (7,510 | ) |
| Work-in-process | 8,371 |  |  | 10,567 |  |  | 2,196 |  |
| Finished goods | 165,799 |  |  | 147,825 |  |  | (17,974 | ) |
| Deferred cost of goods sold | 75,763 |  |  | 50,951 |  |  | (24,812 | ) |
| Gross inventory | 314,786 |  |  | 266,686 |  |  | (48,100 | ) |
| Provision for inventory excess and obsolescence | (60,126 | ) |  | (52,093 | ) |  | 8,033 |  |
| Inventory | $ | 254,660 |  |  | $ | 214,593 |  |  | $ | (40,067 | ) |

[0000936395-15-000038:mdna:231]
[same as prior period, unchanged from 0000936395-15-000024:mdna:147]

[0000936395-15-000038:mdna:232]
Cash used in prepaid expense and other during the first six months of fiscal 2015 was $4.1 million, reflecting higher prepaid value added taxes partially offset by lower deferred deployment costs.

[0000936395-15-000038:mdna:233]
[same as prior period, unchanged from 0000936395-15-000024:mdna:149]

[0000936395-15-000038:mdna:234]
Utilization of cash resources for accounts payable, accruals and other obligations during the first six months of fiscal 2015 was $39.8 million. This amount reflects a $16.4 million decrease in our accounts payable, accruals and other obligations plus additional liabilities recorded for the following items: $1.5 million related to our foreign currency forward contracts, $2.2 million related to our forward starting interest rate swap and $7.7 million relating to warranties, $5.3 million for financing activities relating to unpaid capital leases and $6.8 million for investing activities related to equipment purchases.

[0000936395-15-000038:mdna:235]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2014 through the end of the second quarter of fiscal 2015:

[0000936395-15-000038:mdna:236]
|  | October 31, 2014 |  | April 30, 2015 |  | Increase(decrease) |
| Accounts payable | $ | 209,777 |  |  | $ | 210,002 |  |  | $ | 225 |  |
| Accrued liabilities | 276,608 |  |  | 253,871 |  |  | (22,737 | ) |
| Other long-term obligations | 45,390 |  |  | 51,456 |  |  | 6,066 |  |
| Accounts payable, accruals and other obligations | $ | 531,775 |  |  | $ | 515,329 |  |  | $ | (16,446 | ) |

[0000936395-15-000038:mdna:237]
Interest Paid on Convertible Notes, ABL Credit Facility and Term Loan

[0000936395-15-000038:mdna:238]
The final interest payment owing on our 4.0% convertible senior notes, due March 15, 2015, was paid during the second fiscal quarter of 2015. We paid $3.8 million of interest on these convertible notes during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:239]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $2.2 million in interest on these convertible notes during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:240]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. We paid $6.6 million in interest on these convertible notes during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:241]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $3.8 million in interest on these convertible notes during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:242]
Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. We paid $4.7 million in interest on this term loan during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:243]
During the first six months of fiscal 2015, we utilized the ABL Credit Facility to collateralize certain standby letters of credit. We paid $0.9 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility during the first six months of fiscal 2015.

[0000936395-15-000038:mdna:244]
[same as prior period, unchanged from 0000936395-15-000024:mdna:160]

[0000936395-15-000038:mdna:245]
[same as prior period, unchanged from 0000936395-15-000024:mdna:161]

[0000936395-15-000038:mdna:246]
Deferred revenue increased by $13.3 million during the first six months of fiscal 2015. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2014 through the first six months of fiscal 2015:

[0000936395-15-000038:mdna:247]
|  | October 31, 2014 |  | April 30, 2015 |  | Increase(decrease) |
| Products | $ | 50,457 |  |  | $ | 57,481 |  |  | $ | 7,024 |  |
| Services | 95,161 |  |  | 101,484 |  |  | 6,323 |  |
| Total deferred revenue | $ | 145,618 |  |  | $ | 158,965 |  |  | $ | 13,347 |  |

[0000936395-15-000038:mdna:248]
[same as prior period, unchanged from 0000936395-15-000024:mdna:164]

[0000936395-15-000038:mdna:249]
On October 23, 2014, Ciena Canada, Inc., a subsidiary of Ciena, entered into a lease agreement to lease an office building located at 5050 Innovation Drive, Ottawa, Canada. On April 15, 2015, Ciena Canada, Inc. entered into a work letter and a lease agreement related to the construction and lease of two new office buildings in Ottawa, Canada, consisting of a rentable area of approximately 254,318 square feet, that will be built adjacent to the premises subject to the October 2014 lease. These facilities are expected to be part of a future campus that will replace Ciena’s largest facility and a key research and development center located in the “Lab 10” building on the former Nortel Carling Campus in Ottawa, Canada. With respect to the lease entered into in the second quarter of fiscal 2015, the future minimum rental commitments to be paid over the 15-year lease term are approximately CAD$112.9 million.

[0000936395-15-000038:mdna:250]
The following is a summary of our future minimum payments under contractual obligations as of April 30, 2015 (in thousands):

[0000936395-15-000038:mdna:251]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,067,127 |  |  | $ | — |  |  | $ | 500,000 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |
| Principal due on Term Loan | 248,125 |  |  | 2,500 |  |  | 5,000 |  |  | 240,625 |  |  | — |  |
| Interest due on convertible notes | 101,875 |  |  | 25,000 |  |  | 47,813 |  |  | 21,562 |  |  | 7,500 |  |
| Interest due on Term Loan (2) | 39,321 |  |  | 9,428 |  |  | 18,519 |  |  | 11,374 |  |  | — |  |
| Operating leases (3) | 149,020 |  |  | 33,336 |  |  | 52,248 |  |  | 21,121 |  |  | 42,315 |  |
| Purchase obligations (4) | 181,795 |  |  | 181,795 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 7,952 |  |  | 6,252 |  |  | 1,700 |  |  | — |  |  | — |  |
| Capital leases— buildings (5) | 137,981 |  |  | 1,698 |  |  | 8,837 |  |  | 15,938 |  |  | 111,508 |  |
| Other obligations | 4,242 |  |  | 3,339 |  |  | 903 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,937,438 |  |  | $ | 263,348 |  |  | $ | 635,020 |  |  | $ | 660,620 |  |  | $ | 378,450 |  |

[0000936395-15-000038:mdna:252]
_____________________________________

[0000936395-15-000038:mdna:253]
[same as prior period, unchanged from 0000936395-15-000024:mdna:168]

[0000936395-15-000038:mdna:254]
[same as prior period, unchanged from 0000936395-15-000024:mdna:169]

[0000936395-15-000038:mdna:255]
[same as prior period, unchanged from 0000936395-15-000024:mdna:170]

[0000936395-15-000038:mdna:256]
[same as prior period, unchanged from 0000936395-15-000024:mdna:171]

[0000936395-15-000038:mdna:257]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the excepted commencement of the lease term. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-15-000038:mdna:258]
| (6) | As of April 30, 2015, we also had approximately $14.1 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-15-000038:mdna:259]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of April 30, 2015 (in thousands):

[0000936395-15-000038:mdna:260]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years | Thereafter |
| Standby letters of credit | $ | 60,385 |  |  | $ | 31,976 |  |  | $ | 14,133 |  |  | $ | 6,278 |  | $ | 7,998 |  |

[0000936395-15-000038:mdna:261]
[same as prior period, unchanged from 0000936395-15-000024:mdna:175]

[0000936395-15-000038:mdna:262]
[same as prior period, unchanged from 0000936395-15-000024:mdna:176]

[0000936395-15-000038:mdna:263]
[same as prior period, unchanged from 0000936395-15-000024:mdna:177]

[0000936395-15-000038:mdna:264]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-15-000038:mdna:265]
[same as prior period, unchanged from 0000936395-15-000024:mdna:179]

[0000936395-15-000038:mdna:266]
[same as prior period, unchanged from 0000936395-15-000024:mdna:180]

[0000936395-15-000038:mdna:267]
[same as prior period, unchanged from 0000936395-15-000024:mdna:181]

[0000936395-15-000038:mdna:268]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available.

[0000936395-15-000038:mdna:269]
Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the first six months ended April 30, 2014 and April 30, 2015 were 2.9% and 1.7%, respectively.

[0000936395-15-000038:mdna:270]
[same as prior period, unchanged from 0000936395-15-000024:mdna:183]

[0000936395-15-000038:mdna:271]
[same as prior period, unchanged from 0000936395-15-000024:mdna:184]

[0000936395-15-000038:mdna:272]
[same as prior period, unchanged from 0000936395-15-000024:mdna:185]

[0000936395-15-000038:mdna:273]
[same as prior period, unchanged from 0000936395-15-000024:mdna:186]

[0000936395-15-000038:mdna:274]
Our total deferred revenue for products was $50.5 million and $57.5 million as of October 31, 2014 and April 30, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $95.2 million and $101.5 million as of October 31, 2014 and April 30, 2015, respectively.

[0000936395-15-000038:mdna:275]
[same as prior period, unchanged from 0000936395-15-000024:mdna:188]

[0000936395-15-000038:mdna:276]
[same as prior period, unchanged from 0000936395-15-000024:mdna:189]

[0000936395-15-000038:mdna:277]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 18 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of April 30, 2015, total unrecognized compensation expense was $78.9 million, which relates to unvested restricted stock units and this expense is expected to be recognized over a weighted-average period of 1.6 years.

[0000936395-15-000038:mdna:278]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

[0000936395-15-000038:mdna:279]
[same as prior period, unchanged from 0000936395-15-000024:mdna:193]

[0000936395-15-000038:mdna:280]
[same as prior period, unchanged from 0000936395-15-000024:mdna:194]

[0000936395-15-000038:mdna:281]
For fiscal 2015, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2015. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2015 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $26.3 million of expense in the first six months of fiscal 2015 associated with our cash incentive bonus plan for fiscal 2015.

[0000936395-15-000038:mdna:282]
[same as prior period, unchanged from 0000936395-15-000024:mdna:196]

[0000936395-15-000038:mdna:283]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $13.0 million and $10.8 million in the first six months of fiscal 2014 and 2015, respectively. The charges in fiscal 2015 primarily related to the discontinuance of certain parts and components used in the manufacture of Converged Packet Optical products and decreases in forecasted demand for our legacy, stand-alone WDM and SONET/SDH-based transport platforms and our 5410 Service Aggregation Switch. Our inventory net of allowance for excess and obsolescence was $254.7 million and $214.6 million as of October 31, 2014 and April 30, 2015, respectively.

[0000936395-15-000038:mdna:284]
[same as prior period, unchanged from 0000936395-15-000024:mdna:198]

[0000936395-15-000038:mdna:285]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $519.0 million and $553.3 million as of

[0000936395-15-000038:mdna:286]
October 31, 2014 and April 30, 2015, respectively. Our allowance for doubtful accounts was $2.1 million and $2.4 million as of October 31, 2014 and April 30, 2015, respectively.

[0000936395-15-000038:mdna:287]
[same as prior period, unchanged from 0000936395-15-000024:mdna:200]

[0000936395-15-000038:mdna:288]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2014 and April 30, 2015, these assets totaled $309.4 million and $302.8 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-15-000038:mdna:289]
[same as prior period, unchanged from 0000936395-15-000024:mdna:203]

[0000936395-15-000038:mdna:290]
As of April 30, 2015, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of  $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-15-000038:mdna:291]
[same as prior period, unchanged from 0000936395-15-000024:mdna:205]

[0000936395-15-000038:mdna:292]
Our liability for product warranties, included in other accrued liabilities, was $56.0 million and $54.0 million as of October 31, 2014 and April 30, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $12.4 million and $7.7 million for the first six months of fiscal 2014 and 2015, respectively. See Note 12 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
