# CIEN notes — 0000936395-15-000038


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-15-000038:notes:1]
ABL CREDIT FACILITY

[0000936395-15-000038:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of April 30, 2015, letters of credit totaling $60.4 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of April 30, 2015.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-15-000038:notes:3]
[same as prior period, unchanged from 0000936395-15-000024:notes:3]

[0000936395-15-000038:notes:4]
[same as prior period, unchanged from 0000936395-15-000024:notes:4]

[0000936395-15-000038:notes:5]
[same as prior period, unchanged from 0000936395-15-000024:notes:5]


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-15-000038:notes:6]
[same as prior period, unchanged from 0000936395-15-000024:notes:6]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-15-000038:notes:7]
[same as prior period, unchanged from 0000936395-15-000024:notes:7]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-15-000038:notes:8]
[same as prior period, unchanged from 0000936395-15-000024:notes:8]

[0000936395-15-000038:notes:9]
[same as prior period, unchanged from 0000936395-15-000024:notes:9]

[0000936395-15-000038:notes:10]
|  | October 31, 2014 |  | April 30, 2015 |
| Prepaid VAT and other taxes | $ | 86,464 |  |  | $ | 90,734 |  |
| Product demonstration equipment, net | 42,385 |  |  | 40,906 |  |
| Deferred deployment expense | 27,991 |  |  | 20,930 |  |
| Prepaid expenses | 23,539 |  |  | 21,959 |  |
| Other non-trade receivables | 10,683 |  |  | 8,128 |  |
| Derivative assets | 1,562 |  |  | 855 |  |
|  | $ | 192,624 |  |  | $ | 183,512 |  |

[0000936395-15-000038:notes:11]
Depreciation of product demonstration equipment was $4.2 million and $4.8 million for the first six months of fiscal 2014 and 2015, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-15-000038:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-15-000038:notes:13]
Term Loan

[0000936395-15-000038:notes:14]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):

[0000936395-15-000038:notes:15]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,125 |  |  | $ | 1,131 |  |  | $ | 246,994 |  |

[0000936395-15-000038:notes:16]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-15-000038:notes:17]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,994 |  |  | $ | 249,366 |  |

[0000936395-15-000038:notes:18]
| (1) | Includes unamortized bond discount. |

[0000936395-15-000038:notes:19]
| (2) | The Term Loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000038:notes:20]
Maturity of 2015 Convertible Notes

[0000936395-15-000038:notes:21]
On March 15, 2015, Ciena's outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture, together with certain private exchange transactions conducted by Ciena prior to maturity, approximately $180.6 million in aggregate principal amount of 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, Ciena issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. Ciena repaid in cash approximately $6.9 million in aggregate principal amount of 2015 Notes at maturity.

[0000936395-15-000038:notes:22]
Outstanding Convertible Notes Payable

[0000936395-15-000038:notes:23]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of April 30, 2015:

[0000936395-15-000038:notes:24]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 195,778 |  |  | $ | 14,165 |  |  | $ | 181,613 |  |  | $ | 43,131 |  |

[0000936395-15-000038:notes:25]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

[0000936395-15-000038:notes:26]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 504,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 456,531 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 181,613 |  |  | 248,841 |  |
|  |  | $ | 1,031,613 |  |  | $ | 1,209,747 |  |

[0000936395-15-000038:notes:27]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000038:notes:28]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-15-000038:notes:29]
[same as prior period, unchanged from 0000936395-15-000024:notes:28]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-15-000038:notes:30]
[same as prior period, unchanged from 0000936395-15-000024:notes:29]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-15-000038:notes:31]
COMMITMENTS AND CONTINGENCIES

[0000936395-15-000038:notes:32]
Ontario Grant

[0000936395-15-000038:notes:33]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2015, Ciena has recorded a CAD$25.0 million benefit to date, as a reduction in research and development expenses. As of April 30, 2015, the amount receivable from this grant was CAD$1.9 million.

[0000936395-15-000038:notes:34]
Foreign Tax Contingencies

[0000936395-15-000038:notes:35]
As of October 31, 2014 and April 30, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of April 30, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-15-000038:notes:36]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-15-000038:notes:37]
Litigation

[0000936395-15-000038:notes:38]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s pending acquisition of Cyan, Inc. ("Cyan") were filed in the Court of Chancery of the State of Delaware:

[0000936395-15-000038:notes:39]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

[0000936395-15-000038:notes:40]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

[0000936395-15-000038:notes:41]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

[0000936395-15-000038:notes:42]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

[0000936395-15-000038:notes:43]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

[0000936395-15-000038:notes:44]
Each of the complaints names as defendants Cyan (except for the Canzano complaint), members of the Cyan board of directors, Ciena and Neptune Acquisition Subsidiary, Inc. (“Merger Sub”). The complaints allege, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding for Cyan, failing to properly value Cyan and obtain the best exchange ratio from Ciena, and ignoring or not protecting against certain conflicts of interest. The complaints also allege that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The complaints seek the following: (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger; (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages; and (iii) monetary damages and costs, including attorneys fees and experts fees. These lawsuits are at a preliminary stage. However, Ciena believes that the lawsuits are without merit and intends to defend them vigorously.

[0000936395-15-000038:notes:45]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-15-000038:notes:46]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-15-000038:notes:47]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-15-000038:notes:48]
[same as prior period, unchanged from 0000936395-15-000024:notes:40]

[0000936395-15-000038:notes:49]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the six months ending April 30, 2015:

[0000936395-15-000038:notes:50]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | $ | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income (loss) before reclassifications | (24 | ) |  | (4,233 | ) |  | (2,218 | ) |  | (3,411 | ) |  | (9,886 | ) |
| Amounts reclassified from AOCI | — |  |  | 2,761 |  |  | — |  |  | — |  |  | 2,761 |  |
| Balance at April 30, 2015 | $ | 47 |  |  | $ | (1,645 | ) |  | $ | (4,301 | ) |  | $ | (15,894 | ) |  | $ | (21,793 | ) |

[0000936395-15-000038:notes:51]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the six months ending April 30, 2014:

[0000936395-15-000038:notes:52]
|  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Derivative Instruments |  | Translation Adjustment |  | Total |
| Balance at October 31, 2013 | $ | 30 |  |  | $ | (261 | ) |  | $ | (7,543 | ) |  | $ | (7,774 | ) |
| Other comprehensive income(loss) before reclassifications | 31 |  |  | (1,242 | ) |  | (4,165 | ) |  | (5,376 | ) |
| Amounts reclassified from AOCI | — |  |  | 892 |  |  | — |  |  | 892 |  |
| Balance at April 30, 2014 | $ | 61 |  |  | $ | (611 | ) |  | $ | (11,708 | ) |  | $ | (12,258 | ) |

[0000936395-15-000038:notes:53]
[same as prior period, unchanged from 0000936395-15-000024:notes:45]


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-15-000038:notes:54]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-15-000038:notes:55]
[same as prior period, unchanged from 0000936395-15-000024:notes:47]

[0000936395-15-000038:notes:56]
|  | October 31, 2014 |  | April 30, 2015 |
| Products | $ | 50,457 |  |  | $ | 57,481 |  |
| Services | 95,161 |  |  | 101,484 |  |
|  | 145,618 |  |  | 158,965 |  |
| Less current portion | (104,688 | ) |  | (109,120 | ) |
| Long-term deferred revenue | $ | 40,930 |  |  | $ | 49,845 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-15-000038:notes:57]
[same as prior period, unchanged from 0000936395-15-000024:notes:49]

[0000936395-15-000038:notes:58]
[same as prior period, unchanged from 0000936395-15-000024:notes:50]

[0000936395-15-000038:notes:59]
As of April 30, 2015 and October 31, 2014, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $26.5 million and $51.5 million as of April 30, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-15-000038:notes:60]
During the first six months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount. During the first six months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. The notional amount of these contracts was approximately $176.4 million and $194.5 million as of April 30, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-15-000038:notes:61]
[same as prior period, unchanged from 0000936395-15-000024:notes:53]

[0000936395-15-000038:notes:62]
During fiscal 2014, Ciena entered into interest rate cap arrangements to limit interest paid under the Term Loan to a maximum of 0.75% plus a spread of 300 basis points through July 2015. The total notional amount of interest rate caps outstanding as of April 30, 2015 and October 31, 2014 was $248.1 million and $249.4 million, respectively.  Also in fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004%, for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of April 30, 2015 and October 31, 2014 was $247.5 million.

[0000936395-15-000038:notes:63]
[same as prior period, unchanged from 0000936395-15-000024:notes:55]

[0000936395-15-000038:notes:64]
[same as prior period, unchanged from 0000936395-15-000024:notes:56]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-15-000038:notes:65]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations, See Note 4 below.

[0000936395-15-000038:notes:66]
[same as prior period, unchanged from 0000936395-15-000024:notes:58]

[0000936395-15-000038:notes:67]
[same as prior period, unchanged from 0000936395-15-000024:notes:59]

[0000936395-15-000038:notes:68]
[same as prior period, unchanged from 0000936395-15-000024:notes:60]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-15-000038:notes:69]
[same as prior period, unchanged from 0000936395-15-000024:notes:61]

[0000936395-15-000038:notes:70]
Ciena grants equity awards under its 2008 Omnibus Incentive Plan (the "2008 Plan") and makes shares of its common stock available for purchase under its Amended and Restated Employee Stock Purchase Plan (the “ESPP”). These plans were approved by stockholders and are described in Ciena’s Annual Report on Form 10-K for the fiscal year ended October 31, 2014.

[0000936395-15-000038:notes:71]
[same as prior period, unchanged from 0000936395-15-000024:notes:63]

[0000936395-15-000038:notes:72]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of April 30, 2015, approximately 6.4 million shares remained available for issuance under the 2008 Plan.

[0000936395-15-000038:notes:73]
[same as prior period, unchanged from 0000936395-15-000024:notes:65]

[0000936395-15-000038:notes:74]
Outstanding stock option awards to employees are generally subject to service-based vesting conditions and vest incrementally over a four-year period. As of April 30, 2015, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-15-000038:notes:75]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2014 | 1,288 |  |  | $ | 25.43 |  |
| Exercised | (135 | ) |  | 14.71 |  |
| Canceled | (89 | ) |  | 25.83 |  |
| Balance at April 30, 2015 | 1,064 |  |  | $ | 26.75 |  |

[0000936395-15-000038:notes:76]
The total intrinsic value of options exercised during the first six months of fiscal 2014 and fiscal 2015 was $0.7 million and $0.8 million, respectively. Ciena did not grant any stock options during the first six months of fiscal 2014 or fiscal 2015.

[0000936395-15-000038:notes:77]
The following table summarizes information with respect to stock options outstanding at April 30, 2015, based on Ciena’s closing stock price on the last trading day of Ciena’s second fiscal quarter of 2015 (shares and intrinsic value in thousands):

[0000936395-15-000038:notes:78]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | April 30, 2015 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 111 |  |  | 3.16 |  | $ | 7.42 |  |  | $ | 1,540 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 117 |  |  | 0.54 |  | 16.56 |  |  | 556 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 121 |  |  | 1.13 |  | 18.62 |  |  | 350 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 269 |  |  | 1.89 |  | 27.37 |  |  | — |  |
| $ | 28.61 |  |  | — |  |  | $ | 32.55 |  |  | 98 |  |  | 2.30 |  | 29.99 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 246 |  |  | 2.54 |  | 35.23 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 47.32 |  |  | 102 |  |  | 2.21 |  | 44.11 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 47.32 |  |  | 1,064 |  |  | 2.00 |  | $ | 26.75 |  |  | $ | 2,446 |  |

[0000936395-15-000038:notes:79]
[same as prior period, unchanged from 0000936395-15-000024:notes:71]

[0000936395-15-000038:notes:80]
[same as prior period, unchanged from 0000936395-15-000024:notes:72]

[0000936395-15-000038:notes:81]
[same as prior period, unchanged from 0000936395-15-000024:notes:73]

[0000936395-15-000038:notes:82]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three- or four-year period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-15-000038:notes:83]
[same as prior period, unchanged from 0000936395-15-000024:notes:75]

[0000936395-15-000038:notes:84]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2014 | 4,012 |  |  | $ | 18.02 |  |  | $ | 67,241 |  |
| Granted | 2,284 |  |  |  |  |  |
| Vested | (1,163 | ) |  |  |  |  |
| Canceled or forfeited | (200 | ) |  |  |  |  |
| Balance at April 30, 2015 | 4,933 |  |  | $ | 18.51 |  |  | $ | 105,018 |  |

[0000936395-15-000038:notes:85]
The total fair value of restricted stock units that vested and were converted into common stock during the first six months of fiscal 2014 and fiscal 2015 was $29.1 million and $23.0 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first six months of fiscal 2014 and fiscal 2015 was $21.95 and $18.68 respectively.

[0000936395-15-000038:notes:86]
[same as prior period, unchanged from 0000936395-15-000024:notes:78]

[0000936395-15-000038:notes:87]
[same as prior period, unchanged from 0000936395-15-000024:notes:79]

[0000936395-15-000038:notes:88]
[same as prior period, unchanged from 0000936395-15-000024:notes:80]

[0000936395-15-000038:notes:89]
[same as prior period, unchanged from 0000936395-15-000024:notes:81]

[0000936395-15-000038:notes:90]
[same as prior period, unchanged from 0000936395-15-000024:notes:82]

[0000936395-15-000038:notes:91]
[same as prior period, unchanged from 0000936395-15-000024:notes:83]

[0000936395-15-000038:notes:92]
During the first six months of fiscal 2015, Ciena issued 0.5 million shares under the ESPP. At April 30, 2015, 6.9 million shares remained available for issuance under the ESPP.

[0000936395-15-000038:notes:93]
[same as prior period, unchanged from 0000936395-15-000024:notes:85]

[0000936395-15-000038:notes:94]
[same as prior period, unchanged from 0000936395-15-000024:notes:86]

[0000936395-15-000038:notes:95]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Product costs | $ | 741 |  |  | $ | 653 |  |  | $ | 1,247 |  |  | $ | 1,140 |  |
| Service costs | 568 |  |  | 574 |  |  | 1,148 |  |  | 1,093 |  |
| Share-based compensation expense included in cost of sales | 1,309 |  |  | 1,227 |  |  | 2,395 |  |  | 2,233 |  |
| Research and development | 2,782 |  |  | 2,534 |  |  | 5,354 |  |  | 4,701 |  |
| Sales and marketing | 4,246 |  |  | 3,841 |  |  | 8,309 |  |  | 7,500 |  |
| General and administrative | 3,661 |  |  | 3,723 |  |  | 7,167 |  |  | 7,642 |  |
| Share-based compensation expense included in operating expense | 10,689 |  |  | 10,098 |  |  | 20,830 |  |  | 19,843 |  |
| Share-based compensation expense capitalized in inventory, net | 53 |  |  | 4 |  |  | 218 |  |  | 60 |  |
| Total share-based compensation | $ | 12,051 |  |  | $ | 11,329 |  |  | $ | 23,443 |  |  | $ | 22,136 |  |

[0000936395-15-000038:notes:96]
As of April 30, 2015, total unrecognized share-based compensation expense related to unvested restricted stock units was approximately $78.9 million, and this expense is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-15-000038:notes:97]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement.


## us-gaap:EarningsPerShareTextBlock

[0000936395-15-000038:notes:98]
[same as prior period, unchanged from 0000936395-15-000024:notes:90]

[0000936395-15-000038:notes:99]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units, (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method, and (iv) shares underlying Ciena’s outstanding convertible notes.

[0000936395-15-000038:notes:100]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Numerator | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Net income (loss) | $ | (10,158 | ) |  | $ | 20,653 |  |  | $ | (26,094 | ) |  | $ | 1,874 |  |
| Add: Interest expense associated with 0.875% convertible senior notes due 2017 | — |  |  | 1,387 |  |  | $ | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | (10,158 | ) |  | $ | 22,040 |  |  | $ | (26,094 | ) |  | $ | 1,874 |  |

[0000936395-15-000038:notes:101]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| Denominator | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Basic weighted average shares outstanding | 105,451 |  |  | 113,555 |  |  | 104,977 |  |  | 110,578 |  |
| Add: Shares underlying outstanding stock options, employees stock purchase plan and restricted stock units | — |  |  | 1,354 |  |  | — |  |  | 1,184 |  |
| Add: Shares underlying 0.875% convertible senior notes due 2017 | — |  |  | 13,108 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 105,451 |  |  | 128,017 |  |  | 104,977 |  |  | 111,762 |  |

[0000936395-15-000038:notes:102]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
| EPS | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Basic EPS | $ | (0.10 | ) |  | $ | 0.18 |  |  | $ | (0.25 | ) |  | $ | 0.02 |  |
| Diluted EPS | $ | (0.10 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.02 |  |

[0000936395-15-000038:notes:103]
[same as prior period, unchanged from 0000936395-15-000024:notes:95]

[0000936395-15-000038:notes:104]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Shares underlying stock options and restricted stock units | 3,256 |  |  | 961 |  |  | 3,430 |  |  | 1,923 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 9,198 |  |  | 4,346 |  |  | 9,198 |  |  | 6,772 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 13,108 |  |  | — |  |  | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 52,116 |  |  | 31,861 |  |  | 52,290 |  |  | 48,357 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-15-000038:notes:105]
As of the date indicated, the following table summarizes the assets and liabilities that are recorded at fair value on a recurring basis (in thousands):

[0000936395-15-000038:notes:106]
|  | April 30, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 462,870 |  |  | $ | — |  |  | $ | — |  |  | $ | 462,870 |  |
| U.S. government obligations | — |  |  | 190,335 |  |  | — |  |  | 190,335 |  |
| Commercial paper | — |  |  | 84,983 |  |  | — |  |  | 84,983 |  |
| Foreign currency forward contracts | — |  |  | 855 |  |  | — |  |  | 855 |  |
| Total assets measured at fair value | $ | 462,870 |  |  | $ | 276,173 |  |  | $ | — |  |  | $ | 739,043 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,644 |  |  | $ | — |  |  | $ | 1,644 |  |
| Forward starting interest rate swap | — |  |  | 4,302 |  |  | — |  |  | 4,302 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,946 |  |  | $ | — |  |  | $ | 5,946 |  |

[0000936395-15-000038:notes:107]
[same as prior period, unchanged from 0000936395-15-000024:notes:99]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-15-000038:notes:108]
[same as prior period, unchanged from 0000936395-15-000024:notes:100]

[0000936395-15-000038:notes:109]
|  | April 30, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 462,870 |  |  | $ | 44,996 |  |  | $ | — |  |  | $ | 507,866 |  |
| Short-term investments | — |  |  | 145,089 |  |  | — |  |  | 145,089 |  |
| Prepaid expenses and other | — |  |  | 855 |  |  | — |  |  | 855 |  |
| Long-term investments | — |  |  | 85,233 |  |  | — |  |  | 85,233 |  |
| Total assets measured at fair value | $ | 462,870 |  |  | $ | 276,173 |  |  | $ | — |  |  | $ | 739,043 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,644 |  |  | $ | — |  |  | $ | 1,644 |  |
| Other long-term obligations | — |  |  | 4,302 |  |  | — |  |  | 4,302 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 5,946 |  |  | $ | — |  |  | $ | 5,946 |  |

[0000936395-15-000038:notes:110]
[same as prior period, unchanged from 0000936395-15-000024:notes:102]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-15-000038:notes:111]
[same as prior period, unchanged from 0000936395-15-000024:notes:103]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-15-000038:notes:112]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-15-000038:notes:113]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-15-000038:notes:114]
[same as prior period, unchanged from 0000936395-15-000024:notes:106]

[0000936395-15-000038:notes:115]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2011), United Kingdom (2012), Canada (2010) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-15-000038:notes:116]
[same as prior period, unchanged from 0000936395-15-000024:notes:108]

[0000936395-15-000038:notes:117]
[same as prior period, unchanged from 0000936395-15-000024:notes:109]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-15-000038:notes:118]
[same as prior period, unchanged from 0000936395-15-000024:notes:110]

[0000936395-15-000038:notes:119]
[same as prior period, unchanged from 0000936395-15-000024:notes:111]

[0000936395-15-000038:notes:120]
|  | October 31, 2014 |  | April 30, 2015 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (351,929 | ) |  | $ | 65,904 |  |  | $ | 417,833 |  |  | $ | (365,428 | ) |  | $ | 52,405 |  |
| Patents and licenses | 46,538 |  |  | (45,908 | ) |  | 630 |  |  | 46,538 |  |  | (45,990 | ) |  | 548 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (261,430 | ) |  | 62,143 |  |  | 323,573 |  |  | (274,288 | ) |  | 49,285 |  |
| Total other intangible assets | $ | 787,944 |  |  | $ | (659,267 | ) |  | $ | 128,677 |  |  | $ | 787,944 |  |  | $ | (685,706 | ) |  | $ | 102,238 |  |

[0000936395-15-000038:notes:121]
The amortization of finite-lived other intangible assets was $30.7 million and $26.4 million for the first six months of fiscal 2014 and 2015, respectively. Expected future amortization of finite-lived other intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-15-000038:notes:122]
| Period ended October 31, |  |
| 2015 (remaining six months) | $ | 26,439 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 137 |  |
|  | $ | 102,238 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-15-000038:notes:123]
[same as prior period, unchanged from 0000936395-15-000024:notes:115]

[0000936395-15-000038:notes:124]
[same as prior period, unchanged from 0000936395-15-000024:notes:116]

[0000936395-15-000038:notes:125]
|  | October 31, 2014 |  | April 30, 2015 |
| Raw materials | $ | 64,853 |  |  | $ | 57,343 |  |
| Work-in-process | 8,371 |  |  | 10,567 |  |
| Finished goods | 165,799 |  |  | 147,825 |  |
| Deferred cost of goods sold | 75,763 |  |  | 50,951 |  |
|  | 314,786 |  |  | 266,686 |  |
| Provision for excess and obsolescence | (60,126 | ) |  | (52,093 | ) |
|  | $ | 254,660 |  |  | $ | 214,593 |  |

[0000936395-15-000038:notes:126]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first six months of fiscal 2015, Ciena recorded a provision for excess and obsolescence of $10.8 million, primarily related to the discontinuance of certain parts and components used in the manufacture of its Converged Packet Optical products and a decrease in the forecasted demand for both its legacy, stand-alone WDM and SONET/SDH-based transport platforms and its 5410 Service Aggregation Switch. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-15-000038:notes:127]
[same as prior period, unchanged from 0000936395-15-000024:notes:119]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-15-000038:notes:128]
[same as prior period, unchanged from 0000936395-15-000024:notes:120]

[0000936395-15-000038:notes:129]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-15-000038:notes:130]
The following table summarizes final legal maturities of debt investments at April 30, 2015 (in thousands):

[0000936395-15-000038:notes:131]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 145,043 |  |  | $ | 145,089 |  |
| Due in 1-2 years | 85,233 |  |  | 85,233 |  |
|  | $ | 230,276 |  |  | $ | 230,322 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-15-000038:notes:132]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-15-000038:notes:133]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-15-000038:notes:134]
|  | April 30, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,056 |  |  | $ | 46 |  |  | — |  |  | $ | 105,102 |  |
| Included in long-term investments | 85,233 |  |  | — |  |  | — |  |  | 85,233 |  |
|  | $ | 190,289 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 190,335 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 39,987 |  |  | — |  |  | — |  |  | 39,987 |  |
|  | $ | 39,987 |  |  | $ | — |  |  | $ | — |  |  | $ | 39,987 |  |

[0000936395-15-000038:notes:135]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,994 |  |  | — |  |  | — |  |  | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-15-000038:notes:136]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-15-000038:notes:137]
[same as prior period, unchanged from 0000936395-15-000024:notes:128]

[0000936395-15-000038:notes:138]
As of October 31, 2014, there were no individual customers that accounted for greater than 10% of net accounts receivable. As of April 30, 2015, one customer accounted for 11.8% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $2.1 million and $2.4 million as of October 31, 2014 and April 30, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-15-000038:notes:139]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. Based on the current expected adoption date, the standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-15-000038:notes:140]
In August 2014, the FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.

[0000936395-15-000038:notes:141]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the Ciena’s consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-15-000038:notes:142]
[same as prior period, unchanged from 0000936395-15-000024:notes:132]

[0000936395-15-000038:notes:143]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by GAAP . However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.

[0000936395-15-000038:notes:144]
[same as prior period, unchanged from 0000936395-15-000024:notes:134]


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-15-000038:notes:145]
[same as prior period, unchanged from 0000936395-15-000024:notes:135]

[0000936395-15-000038:notes:146]
|  | October 31, 2014 |  | April 30, 2015 |
| Income tax liability | $ | 14,342 |  |  | $ | 14,147 |  |
| Deferred tenant allowance | 10,839 |  |  | 10,312 |  |
| Straight-line rent | 5,174 |  |  | 5,366 |  |
| Capital lease obligations | 4,589 |  |  | 11,449 |  |
| Forward starting interest rate swap | 2,083 |  |  | 4,302 |  |
| Other | 8,363 |  |  | 5,880 |  |
|  | $ | 45,390 |  |  | $ | 51,456 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-15-000038:notes:147]
[same as prior period, unchanged from 0000936395-15-000024:notes:137]

[0000936395-15-000038:notes:148]
[same as prior period, unchanged from 0000936395-15-000024:notes:138]

[0000936395-15-000038:notes:149]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Interest income | $ | 69 |  |  | $ | 246 |  |  | $ | 147 |  |  | $ | 465 |  |
| Change in fair value of embedded derivative | (1,460 | ) |  | — |  |  | (2,550 | ) |  | — |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts | (11,547 | ) |  | 14,351 |  |  | (10,194 | ) |  | 10,002 |  |
| Foreign currency exchange gain (loss) | 11,249 |  |  | (18,832 | ) |  | 5,333 |  |  | (22,485 | ) |
| Other | (216 | ) |  | (1,314 | ) |  | (639 | ) |  | (1,764 | ) |
| Interest and other income (loss), net | $ | (1,905 | ) |  | $ | (5,549 | ) |  | $ | (7,903 | ) |  | $ | (13,782 | ) |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-15-000038:notes:150]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES

[0000936395-15-000038:notes:151]
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-15-000038:notes:152]
|  | October 31, 2014 |  | April 30, 2015 |
| Equipment, furniture and fixtures | $ | 383,059 |  |  | $ | 384,712 |  |
| Building subject to capital lease | — |  |  | 10,032 |  |
| Leasehold improvements | 46,354 |  |  | 46,513 |  |
|  | 429,413 |  |  | 441,257 |  |
| Accumulated depreciation and amortization | (302,781 | ) |  | (302,193 | ) |
|  | $ | 126,632 |  |  | $ | 139,064 |  |

[0000936395-15-000038:notes:153]
On October 23, 2014, Ciena entered into a lease agreement to lease an office building located in Ottawa, Canada. During the second quarter of fiscal 2015, Ciena gained access to a portion of the building and recorded a capital lease asset and liability.

[0000936395-15-000038:notes:154]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $22.9 million and $22.5 million for the first six months of fiscal 2014 and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-15-000038:notes:155]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the shorter of its useful life or the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

[0000936395-15-000038:notes:156]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct and and Ciena will lease two new office buildings at its new Ottawa, Canada campus.The landlord will construct the buildings and contribute up to a maximum of $290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of April 30, 2015, there were no costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease.


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-15-000038:notes:157]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-15-000038:notes:158]
The table below (in thousands) sets forth Ciena’s segment profit and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-15-000038:notes:159]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 96,581 |  |  | $ | 121,772 |  |  | $ | 175,279 |  |  | $ | 204,429 |  |
| Packet Networking | 8,196 |  |  | 4,751 |  |  | 8,581 |  |  | 11,282 |  |
| Optical Transport | 4,709 |  |  | 4,729 |  |  | 20,359 |  |  | 10,615 |  |
| Software and Services | 24,713 |  |  | 35,957 |  |  | 54,334 |  |  | 70,417 |  |
| Total segment profit | 134,199 |  |  | 167,209 |  |  | 258,553 |  |  | 296,743 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 83,662 |  |  | 82,471 |  |  | 162,010 |  |  | 159,183 |  |
| General and administrative | 31,882 |  |  | 30,302 |  |  | 61,979 |  |  | 59,855 |  |
| Acquisition and integration costs | — |  |  | 1,020 |  |  | — |  |  | 1,020 |  |
| Amortization of intangible assets | 11,493 |  |  | 11,019 |  |  | 23,932 |  |  | 22,038 |  |
| Restructuring costs | — |  |  | (17 | ) |  | 115 |  |  | 8,068 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (12,925 | ) |  | (18,496 | ) |  | (29,951 | ) |  | (40,390 | ) |
| Less: Provision for income taxes | 4,395 |  |  | 3,265 |  |  | 6,660 |  |  | 4,315 |  |
| Consolidated net income (loss) | $ | (10,158 | ) |  | $ | 20,653 |  |  | $ | (26,094 | ) |  | $ | 1,874 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-15-000038:notes:160]
[same as prior period, unchanged from 0000936395-15-000024:notes:148]

[0000936395-15-000038:notes:161]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 356,840 |  |  | $ | 432,911 |  |  | $ | 690,241 |  |  | $ | 769,471 |  |
| Packet Networking | 66,526 |  |  | 53,288 |  |  | 118,235 |  |  | 108,271 |  |
| Optical Transport | 29,616 |  |  | 16,454 |  |  | 69,713 |  |  | 38,793 |  |
| Software and Services | 107,079 |  |  | 118,949 |  |  | 215,575 |  |  | 234,229 |  |
| Consolidated revenue | $ | 560,061 |  |  | $ | 621,602 |  |  | $ | 1,093,764 |  |  | $ | 1,150,764 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-15-000038:notes:162]
[same as prior period, unchanged from 0000936395-15-000024:notes:150]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-15-000038:notes:163]
[same as prior period, unchanged from 0000936395-15-000024:notes:151]

[0000936395-15-000038:notes:164]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2015 (in thousands):

[0000936395-15-000038:notes:165]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,068 |  | (a) | — |  |  | 8,068 |  |
| Cash payments | (7,518 | ) |  | (260 | ) |  | (7,778 | ) |
| Balance at April 30, 2015 | $ | 731 |  |  | $ | 874 |  |  | $ | 1,605 |  |
| Current restructuring liabilities | $ | 731 |  |  | $ | 391 |  |  | $ | 1,122 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 483 |  |  | $ | 483 |  |

[0000936395-15-000038:notes:166]
(a) During the fiscal quarter ended January 31, 2015, Ciena recorded a charge of $8.1 million of severance and other employee-related costs associated with a global workforce reduction of approximately 125 employees.

[0000936395-15-000038:notes:167]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the six months ended April 30, 2014 (in thousands):

[0000936395-15-000038:notes:168]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2013 | $ | 80 |  |  | $ | 1,936 |  |  | $ | 2,016 |  |
| Additional liability recorded | 106 |  |  | 9 |  |  | 115 |  |
| Cash payments | (136 | ) |  | (178 | ) |  | (314 | ) |
| Balance at April 30, 2014 | $ | 50 |  |  | $ | 1,767 |  |  | $ | 1,817 |  |
| Current restructuring liabilities | $ | 50 |  |  | $ | 627 |  |  | $ | 677 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,140 |  |  | $ | 1,140 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-15-000038:notes:169]
[same as prior period, unchanged from 0000936395-15-000024:notes:157]

[0000936395-15-000038:notes:170]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2014 and April 30, 2015 was 2.9% and 1.7%, respectively.

[0000936395-15-000038:notes:171]
[same as prior period, unchanged from 0000936395-15-000024:notes:159]

[0000936395-15-000038:notes:172]
[same as prior period, unchanged from 0000936395-15-000024:notes:160]

[0000936395-15-000038:notes:173]
[same as prior period, unchanged from 0000936395-15-000024:notes:161]

[0000936395-15-000038:notes:174]
[same as prior period, unchanged from 0000936395-15-000024:notes:162]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-15-000038:notes:175]
[same as prior period, unchanged from 0000936395-15-000024:notes:163]

[0000936395-15-000038:notes:176]
|  | October 31, 2014 |  | April 30, 2015 |
| Compensation, payroll related tax and benefits | 82,207 |  |  | 63,713 |  |
| Warranty | 55,997 |  |  | 53,959 |  |
| Vacation | 35,126 |  |  | 35,002 |  |
| Capital lease obligations | 7,788 |  |  | 6,178 |  |
| Interest payable | 6,409 |  |  | 5,423 |  |
| Other | 89,081 |  |  | 89,596 |  |
|  | $ | 276,608 |  |  | $ | 253,871 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-15-000038:notes:177]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-15-000038:notes:178]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of April 30, 2015 (in thousands):

[0000936395-15-000038:notes:179]
| Period ended October 31, |  |
| 2015 (remaining 6 months) | 3,710 |  |
| 2016 | 5,454 |  |
| 2017 | 1,105 |  |
| 2018 | 926 |  |
| 2019 | 926 |  |
| Thereafter | 14,218 |  |
| Net minimum capital lease payments | 26,339 |  |
| Less: Amount representing interest | (8,712 | ) |
| Present value of minimum lease payments | 17,627 |  |
| Less: Current portion of present value of minimum lease payments | (6,178 | ) |
| Long-term portion of present value of minimum lease payments | 11,449 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-15-000038:notes:180]
[same as prior period, unchanged from 0000936395-15-000024:notes:166]

[0000936395-15-000038:notes:181]
|  | October 31, 2014 |  | April 30, 2015 |
| Maintenance spares, net | $ | 54,101 |  |  | $ | 61,497 |  |
| Deferred debt issuance costs, net | 15,160 |  |  | 12,926 |  |
| Other | 4,815 |  |  | 7,768 |  |
|  | $ | 74,076 |  |  | $ | 82,191 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-15-000038:notes:182]
[same as prior period, unchanged from 0000936395-15-000024:notes:168]

[0000936395-15-000038:notes:183]
| Six months ended | Beginning |  |  |  |  |  | Ending |
| April 30, | Balance |  | Provisions |  | Settlements |  | Balance |
| 2014 | $ | 56,303 |  |  | 12,424 |  |  | (12,560 | ) |  | $ | 56,167 |  |
| 2015 | $ | 55,997 |  |  | 7,658 |  |  | (9,696 | ) |  | $ | 53,959 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-15-000038:notes:184]
|  | October 31, 2014 |  | April 30, 2015 |
| United States | $ | 73,420 |  |  | $ | 76,113 |  |
| Canada | 42,015 |  |  | 52,045 |  |
| Other International | 11,197 |  |  | 10,906 |  |
| Total | $ | 126,632 |  |  | $ | 139,064 |  |

[0000936395-15-000038:notes:185]
[same as prior period, unchanged from 0000936395-15-000024:notes:172]

[0000936395-15-000038:notes:186]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| North America | $ | 377,769 |  |  | $ | 397,181 |  |  | $ | 733,617 |  |  | $ | 728,716 |  |
| EMEA | 95,114 |  |  | 102,194 |  |  | 183,833 |  |  | 213,200 |  |
| CALA | 40,234 |  |  | 47,891 |  |  | 92,915 |  |  | 90,633 |  |
| APAC | 46,944 |  |  | 74,336 |  |  | 83,399 |  |  | 118,215 |  |
| Total | $ | 560,061 |  |  | $ | 621,602 |  |  | $ | 1,093,764 |  |  | $ | 1,150,764 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-15-000038:notes:187]
[same as prior period, unchanged from 0000936395-15-000024:notes:174]

[0000936395-15-000038:notes:188]
[same as prior period, unchanged from 0000936395-15-000024:notes:175]

[0000936395-15-000038:notes:189]
[same as prior period, unchanged from 0000936395-15-000024:notes:176]

[0000936395-15-000038:notes:190]
| • | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. In May 2015, Ciena launched its new Waveserver™ product. Revenue from sales of Waveserver will be included in our Converged Packet Optical segment. |

[0000936395-15-000038:notes:191]
[same as prior period, unchanged from 0000936395-15-000024:notes:178]

[0000936395-15-000038:notes:192]
[same as prior period, unchanged from 0000936395-15-000024:notes:179]

[0000936395-15-000038:notes:193]
[same as prior period, unchanged from 0000936395-15-000024:notes:180]

[0000936395-15-000038:notes:194]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of April 30, 2015, equipment, building, furniture and fixtures totaling $139.1 million primarily support asset groups within Ciena's Converged Packet Optical, Packet Networking, and Software and Services segments and support Ciena's unallocated selling and general and administrative activities. As of April 30, 2015, all of Ciena's finite-lived intangible assets totaling $102.2 million were assigned to asset groups within Ciena's Converged Packet Optical segment. As of April 30, 2015, all of the maintenance spares totaling $61.5 million were assigned to asset groups within Ciena's Software and Services segment.

[0000936395-15-000038:notes:195]
[same as prior period, unchanged from 0000936395-15-000024:notes:182]

[0000936395-15-000038:notes:196]
[same as prior period, unchanged from 0000936395-15-000024:notes:183]

[0000936395-15-000038:notes:197]
Segment profit is determined based on internal performance measures used by the chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; acquisition and integration costs; amortization of intangible assets; restructuring costs; interest and other income (loss), net; interest expense; and provisions for income taxes.

[0000936395-15-000038:notes:198]
[same as prior period, unchanged from 0000936395-15-000024:notes:185]

[0000936395-15-000038:notes:199]
[same as prior period, unchanged from 0000936395-15-000024:notes:186]

[0000936395-15-000038:notes:200]
North America includes $324.0 million and $367.6 million of United States revenue for fiscal quarters ended April 30, 2014 and 2015, respectively. For the six months ended April 30, 2014 and 2015, United States revenue was $641.4 million and $665.3 million No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-15-000038:notes:201]
The following table reflects Ciena's geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for a significant percentage of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-15-000038:notes:202]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal quarters ended April 30, 2014 and 2015 with  total revenue of $120.6 million and $117.4 million, respectively. AT&T also accounted for greater than 10% of Ciena's revenue for the six months ended April 30, 2014 and 2015 with total revenue of $221.0 million and $234.0 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-15-000038:notes:203]
[same as prior period, unchanged from 0000936395-15-000024:notes:190]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-15-000038:notes:204]
[same as prior period, unchanged from 0000936395-15-000024:notes:191]

[0000936395-15-000038:notes:205]
[same as prior period, unchanged from 0000936395-15-000024:notes:192]

[0000936395-15-000038:notes:206]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-15-000038:notes:207]
[same as prior period, unchanged from 0000936395-15-000024:notes:195]

[0000936395-15-000038:notes:208]
[same as prior period, unchanged from 0000936395-15-000024:notes:196]

[0000936395-15-000038:notes:209]
[same as prior period, unchanged from 0000936395-15-000024:notes:197]

[0000936395-15-000038:notes:210]
[same as prior period, unchanged from 0000936395-15-000024:notes:198]

[0000936395-15-000038:notes:211]
[same as prior period, unchanged from 0000936395-15-000024:notes:199]

[0000936395-15-000038:notes:212]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-15-000038:notes:213]
[same as prior period, unchanged from 0000936395-15-000024:notes:201]

[0000936395-15-000038:notes:214]
[same as prior period, unchanged from 0000936395-15-000024:notes:202]

[0000936395-15-000038:notes:215]
[same as prior period, unchanged from 0000936395-15-000024:notes:203]

[0000936395-15-000038:notes:216]
[same as prior period, unchanged from 0000936395-15-000024:notes:204]

[0000936395-15-000038:notes:217]
[same as prior period, unchanged from 0000936395-15-000024:notes:205]

[0000936395-15-000038:notes:218]
[same as prior period, unchanged from 0000936395-15-000024:notes:206]

[0000936395-15-000038:notes:219]
[same as prior period, unchanged from 0000936395-15-000024:notes:207]

[0000936395-15-000038:notes:220]
[same as prior period, unchanged from 0000936395-15-000024:notes:208]

[0000936395-15-000038:notes:221]
[same as prior period, unchanged from 0000936395-15-000024:notes:209]

[0000936395-15-000038:notes:222]
[same as prior period, unchanged from 0000936395-15-000024:notes:210]

[0000936395-15-000038:notes:223]
[same as prior period, unchanged from 0000936395-15-000024:notes:211]

[0000936395-15-000038:notes:224]
[same as prior period, unchanged from 0000936395-15-000024:notes:212]

[0000936395-15-000038:notes:225]
[same as prior period, unchanged from 0000936395-15-000024:notes:213]

[0000936395-15-000038:notes:226]
[same as prior period, unchanged from 0000936395-15-000024:notes:214]

[0000936395-15-000038:notes:227]
[same as prior period, unchanged from 0000936395-15-000024:notes:215]

[0000936395-15-000038:notes:228]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 18 below.

[0000936395-15-000038:notes:229]
[same as prior period, unchanged from 0000936395-15-000024:notes:217]

[0000936395-15-000038:notes:230]
Loss Contingencies

[0000936395-15-000038:notes:231]
[same as prior period, unchanged from 0000936395-15-000024:notes:219]

[0000936395-15-000038:notes:232]
[same as prior period, unchanged from 0000936395-15-000024:notes:220]

[0000936395-15-000038:notes:233]
[same as prior period, unchanged from 0000936395-15-000024:notes:221]

[0000936395-15-000038:notes:234]
[same as prior period, unchanged from 0000936395-15-000024:notes:222]

[0000936395-15-000038:notes:235]
[same as prior period, unchanged from 0000936395-15-000024:notes:223]

[0000936395-15-000038:notes:236]
[same as prior period, unchanged from 0000936395-15-000024:notes:224]

[0000936395-15-000038:notes:237]
[same as prior period, unchanged from 0000936395-15-000024:notes:225]

[0000936395-15-000038:notes:238]
[same as prior period, unchanged from 0000936395-15-000024:notes:226]

[0000936395-15-000038:notes:239]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-15-000038:notes:240]
[same as prior period, unchanged from 0000936395-15-000024:notes:227]

[0000936395-15-000038:notes:241]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000038:notes:242]
[same as prior period, unchanged from 0000936395-15-000024:notes:229]

[0000936395-15-000038:notes:243]
[same as prior period, unchanged from 0000936395-15-000024:notes:230]

[0000936395-15-000038:notes:244]
[same as prior period, unchanged from 0000936395-15-000024:notes:231]

[0000936395-15-000038:notes:245]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.

[0000936395-15-000038:notes:246]
[same as prior period, unchanged from 0000936395-15-000024:notes:233]

[0000936395-15-000038:notes:247]
[same as prior period, unchanged from 0000936395-15-000024:notes:234]

[0000936395-15-000038:notes:248]
[same as prior period, unchanged from 0000936395-15-000024:notes:235]


## us-gaap:SubsequentEventsTextBlock

[0000936395-15-000038:notes:249]
SUBSEQUENT EVENTS

[0000936395-15-000038:notes:250]
Pending Acquisition of Cyan, Inc.

[0000936395-15-000038:notes:251]
On May 3, 2015, Ciena entered into a definitive merger agreement to acquire Cyan, Inc. (“Cyan”), a Delaware corporation and leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction.  Subject to the terms and conditions set forth in the merger agreement, at closing each outstanding Cyan share will be exchanged for consideration equal to the value of 0.224 shares of Ciena common stock, 89% of which will be delivered in Ciena common stock and 11% will be delivered in cash based on the value of Ciena common stock at closing. Ciena also will assume Cyan’s outstanding convertible notes, subject to certain conversion and repurchase rights of the holders triggered by the acquisition, as well as Cyan’s outstanding equity awards. At the time of signing of the merger agreement, the transaction was valued at approximately $400.0 million (or $335.0 million, net of estimated cash acquired) and inclusive of Cyan’s $50 million outstanding convertible notes on an as-converted basis. Certain Cyan officers and directors and affiliated stockholders, including investment funds affiliated with certain directors, who, at the time of signing of the merger agreement collectively controlled approximately 40% of the voting power of the then outstanding shares of Cyan common stock, have entered into voting agreements with Ciena that obligate them to vote in favor of the merger, subject to certain exceptions and limitations. The transaction, which is expected to close in Ciena’s fourth fiscal quarter of 2015, is subject to approval by Cyan shareholders and satisfaction of certain other customary closing conditions, including the receipt of certain regulatory approvals.

[0000936395-15-000038:notes:252]
During the second quarter of fiscal 2015, Ciena incurred approximately $1.0 million of acquisition-related costs associated with this pending transaction.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-15-000038:notes:253]
[same as prior period, unchanged from 0000936395-15-000024:notes:236]

[0000936395-15-000038:notes:254]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 15 below), Term Loan (described in Note 15 below) and our ABL Credit Facility (described in Note 16 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $2.4 million and $2.5 million during the first six months of fiscal 2014 and fiscal 2015, respectively.

[0000936395-15-000038:notes:255]
The decrease in the first six months of fiscal 2015 warranty provision compared to the first six months of fiscal 2014 was due to lower failure rates and reduced component and labor repair costs.
