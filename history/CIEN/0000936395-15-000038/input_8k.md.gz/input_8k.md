# CIEN 8-K — 0000936395-15-000035 filed 2015-06-04

## item codes, every 8-K on or before 2015-06-10

- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2015-06-10

- none on or before 2015-06-10

## item 2.02 — earnings release, exhibit 99.1

[0000936395-15-000035:8k_2_02:1]
EX-99.1
2
exhibit-2015q2earningspres.htm
EXHIBIT 99.1

[0000936395-15-000035:8k_2_02:2]
Exhibit - 2015 Q2 Earnings Press Release

[0000936395-15-000035:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-15-000035:8k_2_02:4]
Ciena Reports Fiscal Second Quarter 2015 Financial Results

[0000936395-15-000035:8k_2_02:5]
Grows revenue 11% year-over-year and delivers 11% adjusted operating margin

[0000936395-15-000035:8k_2_02:6]
HANOVER, Md. - June 4, 2015 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal second quarter ended April 30, 2015.

[0000936395-15-000035:8k_2_02:7]
For the fiscal second quarter 2015, Ciena reported revenue of $621.6 million as compared to $560.1 million for the fiscal second quarter 2014.

[0000936395-15-000035:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal second quarter 2015 was $20.7 million, or $0.17 per diluted common share, which compares to a GAAP net loss of $(10.2) million, or $(0.10) per diluted common share, for the fiscal second quarter 2014.

[0000936395-15-000035:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal second quarter 2015 was $47.3 million, or $0.35 per diluted common share, which compares to an adjusted (non-GAAP) net income of $19.4 million, or $0.17 per diluted common share, for the fiscal second quarter 2014.

[0000936395-15-000035:8k_2_02:10]
"We delivered outstanding second quarter results that, when combined with our strong financial performance during the past several quarters, demonstrate increased operating leverage and sustained momentum in our business," said Gary B. Smith, president and CEO, Ciena. “This performance also reflects our industry-leading ability to deliver open, on-demand, software-driven networks for an increasingly diverse set of customers across the globe.”

[0000936395-15-000035:8k_2_02:11]
Fiscal Second Quarter 2015 Performance Summary

[0000936395-15-000035:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-15-000035:8k_2_02:13]
|  |  | GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 621.6 |  |  | $ | 529.2 |  |  | $ | 560.1 |  |  | 17.5 | % |  | 11.0 | % |
| Gross margin |  | 43.8 | % |  | 43.5 | % |  | 42.4 | % |  | 0.3 | % |  | 1.4 | % |
| Operating expense |  | $ | 230.0 |  |  | $ | 226.1 |  |  | $ | 230.5 |  |  | 1.7 | % |  | (0.2 | )% |
| Operating margin |  | 6.8 | % |  | 0.8 | % |  | 1.3 | % |  | 6.0 | % |  | 5.5 | % |

[0000936395-15-000035:8k_2_02:14]
|  |  | Non-GAAP Results |
|  |  | Q2 |  | Q1 |  | Q2 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 621.6 |  |  | $ | 529.2 |  |  | $ | 560.1 |  |  | 17.5 | % |  | 11.0 | % |
| Adj. gross margin |  | 44.4 | % |  | 44.1 | % |  | 43.1 | % |  | 0.3 | % |  | 1.3 | % |
| Adj. operating expense |  | $ | 207.9 |  |  | $ | 197.3 |  |  | $ | 206.3 |  |  | 5.4 | % |  | 0.8 | % |
| Adj. operating margin |  | 10.9 | % |  | 6.8 | % |  | 6.2 | % |  | 4.1 | % |  | 4.7 | % |

[0000936395-15-000035:8k_2_02:15]
|  |  | Revenue by Segment |
|  |  | Q2 FY 2015 |  | Q1 FY 2015 |  | Q2 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 432.9 |  |  | 69.6 |  | $ | 336.6 |  |  | 63.6 |  | $ | 356.8 |  |  | 63.7 |
| Packet Networking |  | 53.3 |  |  | 8.6 |  | 55.0 |  |  | 10.4 |  | 66.6 |  |  | 11.9 |
| Optical Transport |  | 16.5 |  |  | 2.7 |  | 22.3 |  |  | 4.2 |  | 29.6 |  |  | 5.3 |
| Software and Services |  | 118.9 |  |  | 19.1 |  | 115.3 |  |  | 21.8 |  | 107.1 |  |  | 19.1 |
| Total |  | $ | 621.6 |  |  | 100.0 |  | $ | 529.2 |  |  | 100.0 |  | $ | 560.1 |  |  | 100.0 |

[0000936395-15-000035:8k_2_02:16]
| * Denotes % change, or in the case of margin, absolute change |

[0000936395-15-000035:8k_2_02:17]
Additional Performance Metrics for Fiscal Second Quarter 2015

[0000936395-15-000035:8k_2_02:18]
|  |  | Revenue by Geographic Region |
|  |  | Q2 FY 2015 |  | Q1 FY 2015 |  | Q2 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 397.2 |  |  | 63.9 |  | 331.5 |  |  | 62.6 |  | 377.8 |  |  | 67.4 |
| Europe, Middle East and Africa |  | 102.2 |  |  | 16.4 |  | 111.0 |  |  | 21.0 |  | 95.1 |  |  | 17.0 |
| Caribbean and Latin America |  | 47.9 |  |  | 7.7 |  | 42.8 |  |  | 8.1 |  | 40.2 |  |  | 7.2 |
| Asia Pacific |  | 74.3 |  |  | 12.0 |  | 43.9 |  |  | 8.3 |  | 47.0 |  |  | 8.4 |
| Total |  | $ | 621.6 |  |  | 100.0 |  | $ | 529.2 |  |  | 100.0 |  | $ | 560.1 |  |  | 100.0 |

[0000936395-15-000035:8k_2_02:19]
| • | U.S. customers contributed 59.1% of total revenue |

[0000936395-15-000035:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 19% of total revenue |

[0000936395-15-000035:8k_2_02:21]
| • | Cash and investments totaled $816.7 million |

[0000936395-15-000035:8k_2_02:22]
| • | Cash flow from operations totaled $37.8 million |

[0000936395-15-000035:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 80 |

[0000936395-15-000035:8k_2_02:24]
| • | Accounts receivable balance was $553.3 million |

[0000936395-15-000035:8k_2_02:25]
| • | Inventories totaled $214.6 million, including: |

[0000936395-15-000035:8k_2_02:26]
| ◦ | Raw materials: $57.3 million |

[0000936395-15-000035:8k_2_02:27]
| ◦ | Work in process: $10.6 million |

[0000936395-15-000035:8k_2_02:28]
| ◦ | Finished goods: $147.8 million |

[0000936395-15-000035:8k_2_02:29]
| ◦ | Deferred cost of sales: $51.0 million |

[0000936395-15-000035:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(52.1) million |

[0000936395-15-000035:8k_2_02:31]
| • | Product inventory turns were 5.3 |

[0000936395-15-000035:8k_2_02:32]
| • | Headcount totaled 5,108 |

[0000936395-15-000035:8k_2_02:33]
Business Outlook for Fiscal Third Quarter 2015

[0000936395-15-000035:8k_2_02:34]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-15-000035:8k_2_02:35]
Ciena expects fiscal third quarter 2015 financial performance to include:

[0000936395-15-000035:8k_2_02:36]
| • | Revenue in the range of $610 to $640 million |

[0000936395-15-000035:8k_2_02:37]
| • | Adjusted (non-GAAP) gross margin of approximately 43 percent |

[0000936395-15-000035:8k_2_02:38]
| • | Adjusted (non-GAAP) operating expense to be approximately $210 million |

[0000936395-15-000035:8k_2_02:39]
Live Web Broadcast of Unaudited Fiscal Second Quarter 2015 Results

[0000936395-15-000035:8k_2_02:40]
Ciena will host a discussion of its unaudited fiscal second quarter 2015 results with investors and financial analysts today, Thursday, June 4, 2015 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-15-000035:8k_2_02:41]
Notes to Investors

[0000936395-15-000035:8k_2_02:42]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered outstanding second quarter results that, when combined with our strong financial performance during the past several quarters, demonstrate increased operating leverage and sustained momentum in our business"; "This performance also reflects our industry-leading ability to deliver open, on-demand, software-driven networks for an increasingly diverse set of customers across the globe”; "Ciena expects fiscal third quarter 2015 financial performance to include: Revenue in the range of $610 to $640 million; Adjusted (non-GAAP) gross margin of approximately 43 percent; Adjusted (non-GAAP) operating expense to be approximately $210 million."

[0000936395-15-000035:8k_2_02:43]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on March 12, 2015. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-15-000035:8k_2_02:44]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and

[0000936395-15-000035:8k_2_02:45]
investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-15-000035:8k_2_02:46]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-15-000035:8k_2_02:47]
CIENA CORPORATION

[0000936395-15-000035:8k_2_02:48]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-15-000035:8k_2_02:49]
(in thousands, except per share data)

[0000936395-15-000035:8k_2_02:50]
(unaudited)

[0000936395-15-000035:8k_2_02:51]
|  | Quarter Ended April 30, |  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 460,821 |  |  | $ | 511,880 |  |  | $ | 893,762 |  |  | $ | 934,195 |  |
| Services | 99,240 |  |  | 109,722 |  |  | 200,002 |  |  | 216,569 |  |
| Total revenue | 560,061 |  |  | 621,602 |  |  | 1,093,764 |  |  | 1,150,764 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 257,632 |  |  | 286,898 |  |  | 502,848 |  |  | 523,446 |  |
| Services | 64,738 |  |  | 62,293 |  |  | 127,374 |  |  | 124,612 |  |
| Total cost of goods sold | 322,370 |  |  | 349,191 |  |  | 630,222 |  |  | 648,058 |  |
| Gross profit | 237,691 |  |  | 272,411 |  |  | 463,542 |  |  | 502,706 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 103,492 |  |  | 105,202 |  |  | 204,989 |  |  | 205,963 |  |
| Selling and marketing | 83,662 |  |  | 82,471 |  |  | 162,010 |  |  | 159,183 |  |
| General and administrative | 31,882 |  |  | 30,302 |  |  | 61,979 |  |  | 59,855 |  |
| Acquisition and integration costs | — |  |  | 1,020 |  |  | — |  |  | 1,020 |  |
| Amortization of intangible assets | 11,493 |  |  | 11,019 |  |  | 23,932 |  |  | 22,038 |  |
| Restructuring costs | — |  |  | (17 | ) |  | 115 |  |  | 8,068 |  |
| Total operating expenses | 230,529 |  |  | 229,997 |  |  | 453,025 |  |  | 456,127 |  |
| Income from operations | 7,162 |  |  | 42,414 |  |  | 10,517 |  |  | 46,579 |  |
| Interest and other income (loss), net | (1,905 | ) |  | (5,549 | ) |  | (7,903 | ) |  | (13,782 | ) |
| Interest expense | (11,020 | ) |  | (12,947 | ) |  | (22,048 | ) |  | (26,608 | ) |
| Income (loss) before income taxes | (5,763 | ) |  | 23,918 |  |  | (19,434 | ) |  | 6,189 |  |
| Provision for income taxes | 4,395 |  |  | 3,265 |  |  | 6,660 |  |  | 4,315 |  |
| Net income (loss) | $ | (10,158 | ) |  | $ | 20,653 |  |  | $ | (26,094 | ) |  | $ | 1,874 |  |
| Net Income (loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income (loss) per common share | $ | (0.10 | ) |  | $ | 0.18 |  |  | $ | (0.25 | ) |  | $ | 0.02 |  |
| Diluted net income (loss) per potential common share1 | $ | (0.10 | ) |  | $ | 0.17 |  |  | $ | (0.25 | ) |  | $ | 0.02 |  |
| Weighted average basic common shares outstanding | 105,451 |  |  | 113,555 |  |  | 104,977 |  |  | 110,578 |  |
| Weighted average dilutive potential common shares outstanding2 | 105,451 |  |  | 128,017 |  |  | 104,977 |  |  | 111,762 |  |

[0000936395-15-000035:8k_2_02:52]
| 1. | The calculation of GAAP diluted net income per common share for the second quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation. |

[0000936395-15-000035:8k_2_02:53]
| 2. | Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the second quarter of fiscal 2015 includes 1.4 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-15-000035:8k_2_02:54]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first six months of fiscal 2015 includes 1.2 million shares underlying certain stock options and restricted stock units.

[0000936395-15-000035:8k_2_02:55]
CIENA CORPORATION

[0000936395-15-000035:8k_2_02:56]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-15-000035:8k_2_02:57]
(in thousands, except share data)

[0000936395-15-000035:8k_2_02:58]
(unaudited)

[0000936395-15-000035:8k_2_02:59]
|  | October 31, 2014 |  | April 30, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 586,338 |  |
| Short-term investments | 140,205 |  |  | 145,089 |  |
| Accounts receivable, net | 518,981 |  |  | 553,306 |  |
| Inventories | 254,660 |  |  | 214,593 |  |
| Prepaid expenses and other | 192,624 |  |  | 183,512 |  |
| Total current assets | 1,693,190 |  |  | 1,682,838 |  |
| Long-term investments | 50,057 |  |  | 85,233 |  |
| Equipment, building, furniture and fixtures, net | 126,632 |  |  | 139,064 |  |
| Other intangible assets, net | 128,677 |  |  | 102,238 |  |
| Other long-term assets | 74,076 |  |  | 82,191 |  |
| Total assets | $ | 2,072,632 |  |  | $ | 2,091,564 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 209,777 |  |  | $ | 210,002 |  |
| Accrued liabilities | 276,608 |  |  | 253,871 |  |
| Deferred revenue | 104,688 |  |  | 109,120 |  |
| Current portion of long-term debt | 190,063 |  |  | 2,500 |  |
| Total current liabilities | 781,136 |  |  | 575,493 |  |
| Long-term deferred revenue | 40,930 |  |  | 49,845 |  |
| Other long-term obligations | 45,390 |  |  | 51,456 |  |
| Long-term debt, net | 1,274,791 |  |  | 1,276,107 |  |
| Total liabilities | $2,142,247 |  | $1,952,901 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 106,979,960 and 117,695,169 shares issued and outstanding | 1,070 |  |  | 1,177 |  |
| Additional paid-in capital | 5,954,440 |  |  | 6,167,862 |  |
| Accumulated other comprehensive loss | (14,668 | ) |  | (21,793 | ) |
| Accumulated deficit | (6,010,457 | ) |  | (6,008,583 | ) |
| Total stockholders’ equity (deficit) | (69,615 | ) |  | 138,663 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 2,072,632 |  |  | $ | 2,091,564 |  |

[0000936395-15-000035:8k_2_02:60]
CIENA CORPORATION

[0000936395-15-000035:8k_2_02:61]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-15-000035:8k_2_02:62]
(in thousands)

[0000936395-15-000035:8k_2_02:63]
(unaudited)

[0000936395-15-000035:8k_2_02:64]
|  | Six Months Ended April 30, |
|  | 2014 |  | 2015 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income (loss) | $ | (26,094 | ) |  | $ | 1,874 |  |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 27,143 |  |  | 27,322 |  |
| Share-based compensation costs | 23,443 |  |  | 22,136 |  |
| Amortization of intangible assets | 30,712 |  |  | 26,439 |  |
| Provision for inventory excess and obsolescence | 12,972 |  |  | 10,834 |  |
| Provision for warranty | 12,424 |  |  | 7,658 |  |
| Other | 10,164 |  |  | (94 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (27,548 | ) |  | (34,903 | ) |
| Inventories | (57,821 | ) |  | 29,233 |  |
| Prepaid expenses and other | (19,054 | ) |  | (4,129 | ) |
| Accounts payable, accruals and other obligations | (51,631 | ) |  | (39,775 | ) |
| Deferred revenue | 30,123 |  |  | 13,347 |  |
| Net cash provided by (used in) operating activities | (35,167 | ) |  | 59,942 |  |
| Cash flows provided by (used in) investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (26,485 | ) |  | (21,899 | ) |
| Restricted cash | 1,912 |  |  | (44 | ) |
| Purchase of available for sale securities | (95,033 | ) |  | (130,239 | ) |
| Proceeds from maturities of available for sale securities | 130,000 |  |  | 90,000 |  |
| Settlement of foreign currency forward contracts, net | (4,029 | ) |  | 10,364 |  |
| Purchase of cost method investment | — |  |  | (2,000 | ) |
| Net cash provided by (used in) investing activities | 6,365 |  |  | (53,818 | ) |
| Cash flows provided by (used in) financing activities: |  |  |  |
| Payment of long term debt | — |  |  | (8,190 | ) |
| Payment for debt and equity issuance costs | — |  |  | (247 | ) |
| Payment of capital lease obligations | (1,520 | ) |  | (4,745 | ) |
| Proceeds from issuance of common stock | 8,970 |  |  | 9,980 |  |
| Net cash provided by (used in) financing activities | 7,450 |  |  | (3,202 | ) |
| Effect of exchange rate changes on cash and cash equivalents | (52 | ) |  | (3,304 | ) |
| Net increase (decrease) in cash and cash equivalents | (21,352 | ) |  | 2,922 |  |
| Cash and cash equivalents at beginning of period | 346,487 |  |  | 586,720 |  |
| Cash and cash equivalents at end of period | $ | 325,083 |  |  | $ | 586,338 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 17,047 |  |  | $ | 21,882 |  |
| Cash paid during the period for income taxes, net | $ | 7,221 |  |  | $ | 5,811 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,799 |  |  | $ | 11,733 |  |
| Building acquired under capital lease | $ | — |  |  | $ | 10,032 |  |

[0000936395-15-000035:8k_2_02:65]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |
|  |  | Quarter Ended |
|  |  | April 30, |
|  |  | 2014 |  | 2015 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 237,691 |  |  | $ | 272,411 |  |
| Share-based compensation-products |  | 741 |  |  | 653 |  |
| Share-based compensation-services |  | 568 |  |  | 574 |  |
| Amortization of intangible assets |  | 2,328 |  |  | 2,201 |  |
| Total adjustments related to gross profit |  | 3,637 |  |  | 3,428 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 241,328 |  |  | $ | 275,839 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.1 | % |  | 44.4 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 230,529 |  |  | $ | 229,997 |  |
| Share-based compensation-research and development |  | 2,782 |  |  | 2,534 |  |
| Share-based compensation-sales and marketing |  | 4,246 |  |  | 3,841 |  |
| Share-based compensation-general and administrative |  | 3,661 |  |  | 3,723 |  |
| Acquisition and integration costs |  | — |  |  | 1,020 |  |
| Amortization of intangible assets |  | 11,493 |  |  | 11,019 |  |
| Restructuring costs |  | — |  |  | (17 | ) |
| Settlement of patent litigation |  | 2,000 |  |  | — |  |
| Total adjustments related to operating expense |  | 24,182 |  |  | 22,120 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 206,347 |  |  | $ | 207,877 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 7,162 |  |  | $ | 42,414 |  |
| Total adjustments related to gross profit |  | 3,637 |  |  | 3,428 |  |
| Total adjustments related to operating expense |  | 24,182 |  |  | 22,120 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 34,981 |  |  | 67,962 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 6.2 | % |  | 10.9 | % |
| Net Income (Loss) Reconciliation |  |  |  |  |
| GAAP net income (loss) |  | $ | (10,158 | ) |  | $ | 20,653 |  |
| Total adjustments related to gross profit |  | 3,637 |  |  | 3,428 |  |
| Total adjustments related to operating expense |  | 24,182 |  |  | 22,120 |  |
| Non-cash expense associated with the conversion of convertible notes |  | — |  |  | 768 |  |
| Non-cash interest expense |  | 302 |  |  | 371 |  |
| Change in fair value of embedded redemption feature |  | 1,460 |  |  | — |  |
| Adjusted (non-GAAP) net income |  | $ | 19,423 |  |  | $ | 47,340 |  |
| Weighted average basic common shares outstanding |  | 105,451 |  |  | 113,555 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 120,628 |  |  | 158,917 |  |
| Net Income (Loss) per Common Share |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | (0.10 | ) |  | $ | 0.17 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.17 |  |  | $ | 0.35 |  |

[0000936395-15-000035:8k_2_02:66]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2014 includes 2.1 million shares underlying certain stock options and restricted stock units, and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-15-000035:8k_2_02:67]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2015 includes 1.4 million shares underlying certain stock options and restricted stock units, 4.3 million shares underlying Ciena's 4.0% convertible senior notes, due March 15, 2015, 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-15-000035:8k_2_02:68]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the fiscal second quarter of 2014 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-15-000035:8k_2_02:69]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the second quarter of fiscal 2015 requires adding back interest expense of approximately $1.1 million associated with Ciena's 4.0% convertible senior notes, due March 15, 2015, approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000035:8k_2_02:70]
* * *

[0000936395-15-000035:8k_2_02:71]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-15-000035:8k_2_02:72]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-15-000035:8k_2_02:73]
| • | Acquisition and integration costs - reflects non-recurring legal and accounting costs associated with the pending acquisition of Cyan. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-15-000035:8k_2_02:74]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-15-000035:8k_2_02:75]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-15-000035:8k_2_02:76]
| • | Settlement of patent litigation - included in general and administrative expense during the second quarter of fiscal 2014 is a $2.0 million patent litigation settlement. |

[0000936395-15-000035:8k_2_02:77]
| • | Non-cash expense associated with the conversion of convertible notes - a non-cash expense related to certain private exchange offers conducted with several holders of Ciena's 4.0% senior convertible notes due March 15, 2015 prior to maturity of such notes. |

[0000936395-15-000035:8k_2_02:78]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-15-000035:8k_2_02:79]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |
