# CIEN note change history — 0000936395-15-000024 → 0000936395-15-000038


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2015, Ciena has recorded a CAD$25.0 million benefit to date, as a reduction in research and development expenses. As of April 30, 2015, the amount receivable from this grant was CAD$1.9 million.
  (was, 2015-03-12, similarity 0.983):
[0000936395-15-000024:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2015, Ciena has recorded a CAD$24.6 million benefit to date, as a reduction in research and development expenses. As of January 31, 2015, the amount receivable from this grant was CAD$4.6 million.

- added (2015-06-10):
[0000936395-15-000038:note_history:2]
As of October 31, 2014 and April 30, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of April 30, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

- added (2015-06-10):
[0000936395-15-000038:note_history:3]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s pending acquisition of Cyan, Inc. ("Cyan") were filed in the Court of Chancery of the State of Delaware:

- added (2015-06-10):
[0000936395-15-000038:note_history:4]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

- added (2015-06-10):
[0000936395-15-000038:note_history:5]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

- added (2015-06-10):
[0000936395-15-000038:note_history:6]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

- added (2015-06-10):
[0000936395-15-000038:note_history:7]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

- added (2015-06-10):
[0000936395-15-000038:note_history:8]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

- added (2015-06-10):
[0000936395-15-000038:note_history:9]
Each of the complaints names as defendants Cyan (except for the Canzano complaint), members of the Cyan board of directors, Ciena and Neptune Acquisition Subsidiary, Inc. (“Merger Sub”). The complaints allege, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding for Cyan, failing to properly value Cyan and obtain the best exchange ratio from Ciena, and ignoring or not protecting against certain conflicts of interest. The complaints also allege that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The complaints seek the following: (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger; (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages; and (iii) monetary damages and costs, including attorneys fees and experts fees. These lawsuits are at a preliminary stage. However, Ciena believes that the lawsuits are without merit and intends to defend them vigorously.

- removed (2015-06-10):
[0000936395-15-000024:note_history:10]
As of October 31, 2014 and January 31, 2015, Ciena had accrued liabilities of $1.1 million related to a preliminary assessment notice from the India tax authorities asserting deficiencies in payments for the tax year 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $5.5 million, it has not accrued a liability of such amount as of January 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:11]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by GAAP . However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.
  (was, 2015-03-12, similarity 0.9251):
[0000936395-15-000024:note_history:11]
The interim financial statements included herein for Ciena Corporation (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with generally accepted accounting principles ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States of America. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2015-06-10):
[0000936395-15-000038:note_history:12]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- added (2015-06-10):
[0000936395-15-000038:note_history:13]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2015-06-10):
[0000936395-15-000038:note_history:14]
Long-lived assets include: equipment, building, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.
  (was, 2015-03-12, similarity 0.991):
[0000936395-15-000024:note_history:14]
Long-lived assets include: equipment, furniture and fixtures; intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset's carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena's long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

- changed (2015-06-10):
[0000936395-15-000038:note_history:15]
Equipment, Building, Furniture and Fixtures and Internal Use Software
  (was, 2015-03-12, similarity 0.9219):
[0000936395-15-000024:note_history:15]
Equipment, Furniture and Fixtures and Internal Use Software

- added (2015-06-10):
[0000936395-15-000038:note_history:16]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the shorter of its useful life or the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

- added (2015-06-10):
[0000936395-15-000038:note_history:17]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct and and Ciena will lease two new office buildings at its new Ottawa, Canada campus.The landlord will construct the buildings and contribute up to a maximum of $290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of April 30, 2015, there were no costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease.

- changed (2015-06-10):
[0000936395-15-000038:note_history:18]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2014 and April 30, 2015 was 2.9% and 1.7%, respectively.
  (was, 2015-03-12, similarity 0.9625):
[0000936395-15-000024:note_history:18]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.

- changed (2015-06-10):
[0000936395-15-000038:note_history:19]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.
  (was, 2015-03-12, similarity 0.9892):
[0000936395-15-000024:note_history:19]
Ciena's allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from its customers. In determining the appropriate balance for Ciena's allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer's financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.

- changed (2015-06-10):
[0000936395-15-000038:note_history:20]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 18 below.
  (was, 2015-03-12, similarity 0.9973):
[0000936395-15-000024:note_history:20]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon its determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 18 below.

- changed (2015-06-10):
[0000936395-15-000038:note_history:21]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.
  (was, 2015-03-12, similarity 0.9929):
[0000936395-15-000024:note_history:21]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. dollar as their functional currency because Ciena, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

- added (2015-06-10):
[0000936395-15-000038:note_history:22]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations, See Note 4 below.

- changed (2015-06-10):
[0000936395-15-000038:note_history:23]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.
  (was, 2015-03-12, similarity 0.9983):
[0000936395-15-000024:note_history:23]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted-average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 17 below.

- changed (2015-06-10):
[0000936395-15-000038:note_history:24]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. Based on the current expected adoption date, the standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2015-03-12, similarity 0.8378):
[0000936395-15-000024:note_history:24]
In May 2014, FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this accounting standard update on its Consolidated Financial Statements and disclosures.

- changed (2015-06-10):
[0000936395-15-000038:note_history:25]
In August 2014, the FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.
  (was, 2015-03-12, similarity 0.9971):
[0000936395-15-000024:note_history:25]
In August 2014, FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.

- added (2015-06-10):
[0000936395-15-000038:note_history:26]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the Ciena’s consolidated financial statements and related disclosures.

- removed (2015-06-10):
[0000936395-15-000024:note_history:27]
The preparation of the financial statements and related disclosures in conformity with accounting principles generally

- removed (2015-06-10):
[0000936395-15-000024:note_history:28]
accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

- removed (2015-06-10):
[0000936395-15-000024:note_history:29]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment, furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

- removed (2015-06-10):
[0000936395-15-000024:note_history:30]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") includes a redemption feature that is accounted for as a separate embedded derivative. The embedded redemption feature was recorded at fair value on a recurring basis, and these changes are included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:31]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):
  (was, 2015-03-12, similarity 0.9585):
[0000936395-15-000024:note_history:31]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:

- changed (2015-06-10):
[0000936395-15-000038:note_history:32]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,125 |  |  | $ | 1,131 |  |  | $ | 246,994 |  |
  (was, 2015-03-12, similarity 0.8788):
[0000936395-15-000024:note_history:32]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |
|  |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |

- changed (2015-06-10):
[0000936395-15-000038:note_history:33]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,994 |  |  | $ | 249,366 |  |
  (was, 2015-03-12, similarity 0.8667):
[0000936395-15-000024:note_history:33]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 247,640 |  |  | $ | 247,817 |  |
|  |  | $ | 247,640 |  |  | $ | 247,817 |  |

- added (2015-06-10):
[0000936395-15-000038:note_history:34]
Maturity of 2015 Convertible Notes

- added (2015-06-10):
[0000936395-15-000038:note_history:35]
On March 15, 2015, Ciena's outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture, together with certain private exchange transactions conducted by Ciena prior to maturity, approximately $180.6 million in aggregate principal amount of 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, Ciena issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. Ciena repaid in cash approximately $6.9 million in aggregate principal amount of 2015 Notes at maturity.

- changed (2015-06-10):
[0000936395-15-000038:note_history:36]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of April 30, 2015:
  (was, 2015-03-12, similarity 0.9792):
[0000936395-15-000024:note_history:36]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of January 31, 2015:

- changed (2015-06-10):
[0000936395-15-000038:note_history:37]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 504,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 456,531 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 181,613 |  |  | 248,841 |  |
|  |  | $ | 1,031,613 |  |  | $ | 1,209,747 |  |
  (was, 2015-03-12, similarity 0.8132):
[0000936395-15-000024:note_history:37]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,520 |  |  | $ | 191,016 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 495,625 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 180,343 |  |  | 228,516 |  |
|  |  | $ | 1,217,863 |  |  | $ | 1,331,220 |  |

- removed (2015-06-10):
[0000936395-15-000024:note_history:38]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:39]
|  | April 30, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,056 |  |  | $ | 46 |  |  | — |  |  | $ | 105,102 |  |
| Included in long-term investments | 85,233 |  |  | — |  |  | — |  |  | 85,233 |  |
|  | $ | 190,289 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 190,335 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 39,987 |  |  | — |  |  | — |  |  | 39,987 |  |
|  | $ | 39,987 |  |  | $ | — |  |  | $ | — |  |  | $ | 39,987 |  |
  (was, 2015-03-12, similarity 0.9864):
[0000936395-15-000024:note_history:39]
|  | January 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 115,129 |  |  | $ | 39 |  |  | — |  |  | $ | 115,168 |  |
| Included in long-term investments | 55,085 |  |  | 68 |  |  | — |  |  | 55,153 |  |
|  | $ | 170,214 |  |  | $ | 107 |  |  | $ | — |  |  | $ | 170,321 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,986 |  |  | — |  |  | — |  |  | 29,986 |  |
|  | $ | 29,986 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,986 |  |

- changed (2015-06-10):
[0000936395-15-000038:note_history:40]
The following table summarizes final legal maturities of debt investments at April 30, 2015 (in thousands):
  (was, 2015-03-12, similarity 0.9612):
[0000936395-15-000024:note_history:40]
The following table summarizes final legal maturities of debt investments at January 31, 2015 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:41]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):
  (was, 2015-03-12, similarity 0.9084):
[0000936395-15-000024:note_history:41]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of January 31, 2015:

- changed (2015-06-10):
[0000936395-15-000038:note_history:42]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,125 |  |  | $ | 1,131 |  |  | $ | 246,994 |  |
  (was, 2015-03-12, similarity 0.8788):
[0000936395-15-000024:note_history:42]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |
|  |  | $ | 248,750 |  |  | $ | 1,110 |  |  | $ | 247,640 |  |

- changed (2015-06-10):
[0000936395-15-000038:note_history:43]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,994 |  |  | $ | 249,366 |  |
  (was, 2015-03-12, similarity 0.8667):
[0000936395-15-000024:note_history:43]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 247,640 |  |  | $ | 247,817 |  |
|  |  | $ | 247,640 |  |  | $ | 247,817 |  |

- changed (2015-06-10):
[0000936395-15-000038:note_history:44]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 504,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 456,531 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 181,613 |  |  | 248,841 |  |
|  |  | $ | 1,031,613 |  |  | $ | 1,209,747 |  |
  (was, 2015-03-12, similarity 0.8132):
[0000936395-15-000024:note_history:44]
|  |  | January 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| 4.0% Convertible Senior Notes, due March 15, 2015 (1) |  | $ | 187,520 |  |  | $ | 191,016 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 495,625 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,063 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (3) |  | 180,343 |  |  | 228,516 |  |
|  |  | $ | 1,217,863 |  |  | $ | 1,331,220 |  |

- removed (2015-06-10):
[0000936395-15-000024:note_history:45]
| (1) | Includes unamortized bond premium related to embedded redemption feature. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:46]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of April 30, 2015:
  (was, 2015-03-12, similarity 0.9792):
[0000936395-15-000024:note_history:46]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of January 31, 2015:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-06-10):
[0000936395-15-000038:note_history:47]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2014 and April 30, 2015 was 2.9% and 1.7%, respectively.
  (was, 2015-03-12, similarity 0.9625):
[0000936395-15-000024:note_history:47]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of revenue recognized using the percentage-of-completion method for the three months ended January 31, 2014 and January 31, 2015 were 5.1% and 1.0%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2015-06-10):
[0000936395-15-000038:note_history:48]
SUBSEQUENT EVENTS

- added (2015-06-10):
[0000936395-15-000038:note_history:49]
Pending Acquisition of Cyan, Inc.

- added (2015-06-10):
[0000936395-15-000038:note_history:50]
On May 3, 2015, Ciena entered into a definitive merger agreement to acquire Cyan, Inc. (“Cyan”), a Delaware corporation and leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction.  Subject to the terms and conditions set forth in the merger agreement, at closing each outstanding Cyan share will be exchanged for consideration equal to the value of 0.224 shares of Ciena common stock, 89% of which will be delivered in Ciena common stock and 11% will be delivered in cash based on the value of Ciena common stock at closing. Ciena also will assume Cyan’s outstanding convertible notes, subject to certain conversion and repurchase rights of the holders triggered by the acquisition, as well as Cyan’s outstanding equity awards. At the time of signing of the merger agreement, the transaction was valued at approximately $400.0 million (or $335.0 million, net of estimated cash acquired) and inclusive of Cyan’s $50 million outstanding convertible notes on an as-converted basis. Certain Cyan officers and directors and affiliated stockholders, including investment funds affiliated with certain directors, who, at the time of signing of the merger agreement collectively controlled approximately 40% of the voting power of the then outstanding shares of Cyan common stock, have entered into voting agreements with Ciena that obligate them to vote in favor of the merger, subject to certain exceptions and limitations. The transaction, which is expected to close in Ciena’s fourth fiscal quarter of 2015, is subject to approval by Cyan shareholders and satisfaction of certain other customary closing conditions, including the receipt of certain regulatory approvals.

- added (2015-06-10):
[0000936395-15-000038:note_history:51]
During the second quarter of fiscal 2015, Ciena incurred approximately $1.0 million of acquisition-related costs associated with this pending transaction.
