# CIEN notes — 0000936395-22-000065


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000936395-22-000065:notes:1]
Part III of the Form 10-K incorporates by reference certain portions of the registrant’s definitive proxy statement for its 2023 Annual Meeting of Stockholders to be filed with the Commission not later than 120 days after the end of the fiscal year covered by this report.


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-22-000065:notes:2]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0000936395-22-000065:notes:3]
Ciena Corporation (“Ciena” or the “Company”) is a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. Ciena provides hardware, software and services that support the delivery of video, data and voice traffic over core, metro, aggregation and access communications networks. Ciena’s solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, and enterprises across multiple industry verticals.

[0000936395-22-000065:notes:4]
Ciena’s portfolio is designed to enable the Adaptive Network™, Ciena’s vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that are informed by analytics and intelligence. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end-user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network performance and maximize the return on their network infrastructure investment.

[0000936395-22-000065:notes:5]
Ciena’s solutions include Networking Platforms, including its Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. Ciena’s Converged Packet Optical portfolio includes products that support long haul and regional networks, submarine and data center interconnect networks, and metro and edge networks. Ciena’s Routing and Switching portfolio includes products and solutions that enable efficient internet protocol (“IP”) transport in next-generation metro edge, access and aggregation networks.

[0000936395-22-000065:notes:6]
To complement its Networking Platforms, Ciena offers Platform Software, which includes its Manage, Control and Plan (“MCP”) applications that deliver advanced multi-layer domain control and operations. Ciena, through its Blue Planet® Software, also enables complete service lifecycle management automation with productized operational support systems (“OSSs”) and service assurance solutions that help its customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-22-000065:notes:7]
In addition to its systems and software, Ciena also offers a broad range of services that help its customers build, operate and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, network operations center (“NOC”) management, learning, and optimization services.

[0000936395-22-000065:notes:8]
Basis of Presentation

[0000936395-22-000065:notes:9]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000936395-22-000065:notes:10]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October in each year (October 29, 2022, October 30, 2021 and October 31, 2020 for the periods reported). Fiscal 2022, fiscal 2021 and fiscal 2020 each consisted of a 52-week fiscal year.

[0000936395-22-000065:notes:11]
Business Combinations

[0000936395-22-000065:notes:12]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and

[0000936395-22-000065:notes:13]
estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-22-000065:notes:14]
Use of Estimates

[0000936395-22-000065:notes:15]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-22-000065:notes:16]
Cash and Cash Equivalents

[0000936395-22-000065:notes:17]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending on the duration of the restriction.

[0000936395-22-000065:notes:18]
Investments

[0000936395-22-000065:notes:19]
Ciena’s investments in debt securities are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-22-000065:notes:20]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 29, 2022, the combined carrying value of these investments was $20.7 million. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena evaluates these investments for impairment or observable price changes quarterly and records adjustments to interest and other income (loss), net on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:21]
Inventories

[0000936395-22-000065:notes:22]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-22-000065:notes:23]
Segment Reporting

[0000936395-22-000065:notes:24]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the Company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 25 below.

[0000936395-22-000065:notes:25]
Goodwill

[0000936395-22-000065:notes:26]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-22-000065:notes:27]
Annually, Ciena tests goodwill impairment qualitatively, or quantitatively by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-22-000065:notes:28]
Long-lived Assets

[0000936395-22-000065:notes:29]
Long-lived assets include: equipment, building, furniture and fixtures, operating right-of-use (“ROU”) assets, finite-lived intangible assets and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0000936395-22-000065:notes:30]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-22-000065:notes:31]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method, generally over useful lives of three years to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-22-000065:notes:32]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0000936395-22-000065:notes:33]
Leases

[0000936395-22-000065:notes:34]
At the inception of a contract, Ciena must determine whether the contract is or contains a lease. The contract is or contains a lease if the contract conveys the right to control the use of the property, plant, or equipment for a designated term in exchange for consideration. Ciena’s evaluation of its contracts follows the assessment of whether there is a right to obtain substantially all of the economic benefits from the use and the right to direct the use of the identified asset in the contract. Operating leases are included in the Operating ROU assets, Operating lease liabilities and Long-term operating lease liabilities in the Consolidated Balance Sheets. Finance leases are included in Equipment, building, furniture and fixtures, net (“Finance ROU assets”), Accrued liabilities and other short-term obligations and Other long-term obligations in the Consolidated Balance Sheets.

[0000936395-22-000065:notes:35]
Ciena has operating and finance leases that primarily relate to real property. Ciena has elected not to capitalize leases with a term of 12 months or less without a purchase option that it is likely to exercise. Ciena has elected not to separate lease and non-lease components of operating and finance leases. Lease components are payment items directly attributable to the use of the underlying asset, while non-lease components are explicit elements of a contract not directly related to the use of the underlying asset, including pass-through operating expenses like common area maintenance and utilities.

[0000936395-22-000065:notes:36]
Operating ROU assets and lease liabilities and Finance ROU assets and lease liabilities are recognized on the Consolidated Balance Sheets at the present value of the future lease payments over the life of the lease term. Ciena uses discount rates based on incremental borrowing rates, on a collateralized basis, for the respective underlying assets, for terms similar to the respective leases when implicit rates for leases are not determinable. Operating lease costs are included as rent expense in the Consolidated Statements of Operations. Fixed base payments on operating leases paid directly to the lessor are recorded as lease expense on a straight-line basis. Related variable payments based on usage, changes in an index, or market rate are expensed as incurred. Finance ROU assets are generally amortized on a straight-line basis over the lease term with the interest expense on the lease liability recorded using the interest method. The amortization and interest expense are recorded separately in the Consolidated Statements of Operations.

[0000936395-22-000065:notes:37]
Intangible Assets

[0000936395-22-000065:notes:38]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-22-000065:notes:39]
Maintenance Spares

[0000936395-22-000065:notes:40]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.

[0000936395-22-000065:notes:41]
Concentrations

[0000936395-22-000065:notes:42]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-22-000065:notes:43]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers and Web-scale providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 2 below.

[0000936395-22-000065:notes:44]
Additionally, Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0000936395-22-000065:notes:45]
Revenue Recognition

[0000936395-22-000065:notes:46]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-22-000065:notes:47]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-22-000065:notes:48]
•identification of the contract, or contracts, with a customer;

[0000936395-22-000065:notes:49]
•identification of the performance obligations in the contract;

[0000936395-22-000065:notes:50]
•determination of the transaction price;

[0000936395-22-000065:notes:51]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-22-000065:notes:52]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-22-000065:notes:53]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-22-000065:notes:54]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena’s transfer of the products or services to the customer and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to

[0000936395-22-000065:notes:55]
customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-22-000065:notes:56]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-22-000065:notes:57]
Significant Judgments

[0000936395-22-000065:notes:58]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-22-000065:notes:59]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-22-000065:notes:60]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-22-000065:notes:61]
Capitalized Contract Acquisition Costs

[0000936395-22-000065:notes:62]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the Financial Accounting Standards Board (“FASB”) Transition Resource Group for Revenue Recognition with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-22-000065:notes:63]
For the additional disclosures on capitalized contract acquisition costs, see Note 2 below.

[0000936395-22-000065:notes:64]
Warranty Accruals

[0000936395-22-000065:notes:65]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-22-000065:notes:66]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-22-000065:notes:67]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-22-000065:notes:68]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-22-000065:notes:69]
Accounts Receivable Factoring

[0000936395-22-000065:notes:70]
Ciena has entered into factoring agreements to sell certain receivables to unrelated third-party financial institution on a non-recourse basis. These transactions are accounted for in accordance with ASC Topic 860, “Transfers and Servicing” and result in a reduction in accounts receivable because the agreements transfer effective control over and risk related to the receivables to the buyers. Ciena's factoring agreements do not allow for recourse in the event of uncollectability, and Ciena does not retain any interest in the underlying accounts receivable once sold. Trade accounts receivables balances sold are removed from the consolidated balance sheets and cash received is reflected as cash provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest and other income (loss), net on the Consolidated Statements of Operations. See Note 9 below.

[0000936395-22-000065:notes:71]
Research and Development

[0000936395-22-000065:notes:72]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-22-000065:notes:73]
Government Grants

[0000936395-22-000065:notes:74]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates. See Notes 3 below.

[0000936395-22-000065:notes:75]
Advertising Costs

[0000936395-22-000065:notes:76]
Ciena expenses all advertising costs as incurred.

[0000936395-22-000065:notes:77]
Legal Costs

[0000936395-22-000065:notes:78]
Ciena expenses legal costs associated with litigation as incurred.

[0000936395-22-000065:notes:79]
Share-Based Compensation Expense

[0000936395-22-000065:notes:80]
Ciena measures and recognizes compensation expense for share-based awards and employee stock purchases related to its Amended and Restated 2003 Employee Stock Purchase Plan (the “ESPP”) based on estimated fair values on the date of grant. Ciena estimates the fair value of employee stock purchases related to the ESPP using the Black-Scholes option-pricing model. Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. In each case, Ciena only recognizes expense in its Consolidated Statements of Operations for those restricted stock units that ultimately vest. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. See Note 24 below.

[0000936395-22-000065:notes:81]
Stock Repurchase Program

[0000936395-22-000065:notes:82]
Shares repurchased pursuant to Ciena’s stock repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena’s accounting policy related to its share repurchases is to reduce its common stock based on the par value of the shares and to reduce its capital surplus for the excess of the repurchase price over the par value. Since the inception of its stock repurchase programs, Ciena has had an accumulated deficit balance; therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0000936395-22-000065:notes:83]
Income Taxes

[0000936395-22-000065:notes:84]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities (“DTA”) for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-22-000065:notes:85]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 through 2021, in Canada for 2014 through 2016 and 2020 through 2021, and in the United Kingdom for 2016 through 2020. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2019), United Kingdom (2016), Canada (2014), and India (2012). Limited adjustments can be made to federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-22-000065:notes:86]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 29, 2022, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized totaled approximately $477.0 million. If these earnings were distributed to the U.S. in the form of dividends, or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, Ciena would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Ciena would also be subject to additional foreign withholding taxes of approximately $33.0 million. Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-22-000065:notes:87]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-22-000065:notes:88]
The Tax Cuts and Jobs Act (the “Tax Act”) includes provisions that affected Ciena starting in fiscal 2019, including a provision designed to tax global intangible low-taxed income (“GILTI”). An accounting policy choice is allowed to either treat taxes due on future U.S. inclusions related to GILTI in taxable income as a current-period expense when incurred (the “period cost method”) or factor such amounts into the measurement of deferred taxes (the “deferred method”). The calculation of the deferred balance with respect to the GILTI tax provisions will depend, in part, on analyzing global income to determine whether future U.S. inclusions in taxable income are expected related to GILTI and, if so, what the impact is expected to be. Ciena is electing to use the period cost method for future GILTI inclusions. Additionally, Ciena is electing to use the incremental cash tax savings approach when determining whether a valuation allowance needs to be recorded against the U.S. net operating loss (“NOL”) due to the GILTI inclusions.

[0000936395-22-000065:notes:89]
The Tax Act also introduced an alternative tax known as the base erosion and anti-abuse tax (“BEAT”). An accounting policy choice has been made to consider BEAT as a period cost when incurred.

[0000936395-22-000065:notes:90]
Loss Contingencies

[0000936395-22-000065:notes:91]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-22-000065:notes:92]
Fair Value of Financial Instruments

[0000936395-22-000065:notes:93]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s short-term and long-term debt, see Note 19 below.

[0000936395-22-000065:notes:94]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-22-000065:notes:95]
•Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities;

[0000936395-22-000065:notes:96]
•Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and

[0000936395-22-000065:notes:97]
•Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data.

[0000936395-22-000065:notes:98]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-22-000065:notes:99]
Restructuring

[0000936395-22-000065:notes:100]
From time to time, Ciena takes actions to align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions and redesign business processes. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 5 below.

[0000936395-22-000065:notes:101]
Foreign Currency

[0000936395-22-000065:notes:102]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statements of Operations. See Note 6 below.

[0000936395-22-000065:notes:103]
Derivatives

[0000936395-22-000065:notes:104]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statements of Operations to which the hedged transaction relates.

[0000936395-22-000065:notes:105]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-22-000065:notes:106]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:107]
See Notes 8 and 16 below.

[0000936395-22-000065:notes:108]
Computation of Net Income per Share

[0000936395-22-000065:notes:109]
Ciena calculates basic earnings per share by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic net income per common share (“Basic EPS”) and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 21 below.

[0000936395-22-000065:notes:110]
Software Development Costs

[0000936395-22-000065:notes:111]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-22-000065:notes:112]
Newly Issued Accounting Standards - Effective

[0000936395-22-000065:notes:113]
In June 2016, the FASB issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets for unbilled accounts receivable, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-22-000065:notes:114]
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general

[0000936395-22-000065:notes:115]
principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena adopted ASU 2019-12 on a prospective basis in the first quarter of fiscal 2022. The adoption of ASU 2019-12 did not have a material impact on Ciena’s consolidated financial statements and related disclosures.

[0000936395-22-000065:notes:116]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena adopted ASU 2020-04 and ASU 2021-01 on a prospective basis in fiscal 2022. The adoption of ASU 2020-04 and ASU 2021-01 did not have a material impact on Ciena’s consolidated financial statements and related disclosures.

[0000936395-22-000065:notes:117]
In November 2021, the FASB issued ASU No. 2021-10 (“ASU 2021-10”), Government Assistance, to increase transparency of government assistance including the disclosure of (1) the types of assistance, (2) an entity’s accounting for the assistance, and (3) the effect of the assistance on an entity’s financial statements. ASU 2021-10 is effective for annual periods beginning after December 15, 2021. Early adoption is permitted. Ciena early adopted ASU 2021-10 during fiscal 2022. The adoption of ASU 2021-10 did not have a material impact on Ciena’s consolidated financial statements and related disclosures.

[0000936395-22-000065:notes:118]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-22-000065:notes:119]
In October 2021, the FASB issued ASU No. 2021-08 (“ASU 2021-08”), Business Combinations (Topic 805): Accounting for Contract Assets and Contract Liabilities from Contracts with Customers to improve the accounting for acquired revenue contracts with customers in a business combination to address recognition of an acquired contract liability and payment terms and their effect on subsequent revenue recognized by the acquirer. ASU 2021-08 is effective for annual periods beginning after December 15, 2022 on a prospective basis. Early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:InventoryPolicyTextBlock

[0000936395-22-000065:notes:120]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-22-000065:notes:121]
REVENUE
Disaggregation of Revenue

[0000936395-22-000065:notes:122]
Ciena’s disaggregated revenue as presented below depicts the nature, amount, and timing of revenue and cash flows for similar groupings of Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-22-000065:notes:123]
The tables below set forth Ciena’s disaggregated revenue for the respective period (in thousands):

[0000936395-22-000065:notes:124]
|  | Year Ended October 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,379,931 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,379,931 |  |
| Routing and Switching | 398,439 |  |  | — |  |  | — |  |  | — |  |  | 398,439 |  |
| Platform Software and Services | — |  |  | 277,191 |  |  | — |  |  | — |  |  | 277,191 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 76,567 |  |  | — |  |  | 76,567 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 292,375 |  |  | 292,375 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 157,443 |  |  | 157,443 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 50,715 |  |  | 50,715 |  |
| Total revenue by product line | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,778,370 |  |  | $ | 85,691 |  |  | $ | 25,540 |  |  | $ | 44,091 |  |  | $ | 2,933,692 |  |
| Products and services transferred over time | — |  |  | 191,500 |  |  | 51,027 |  |  | 456,442 |  |  | 698,969 |  |
| Total revenue by timing of revenue recognition | $ | 2,778,370 |  |  | $ | 277,191 |  |  | $ | 76,567 |  |  | $ | 500,533 |  |  | $ | 3,632,661 |  |

[0000936395-22-000065:notes:125]
|  | Year Ended October 30, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,553,509 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,553,509 |  |
| Routing and Switching | 271,796 |  |  | — |  |  | — |  |  | — |  |  | 271,796 |  |
| Platform Software and Services | — |  |  | 229,588 |  |  | — |  |  | — |  |  | 229,588 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 77,247 |  |  | — |  |  | 77,247 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 283,350 |  |  | 283,350 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 171,489 |  |  | 171,489 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 33,705 |  |  | 33,705 |  |
| Total revenue by product line | $ | 2,825,305 |  |  | $ | 229,588 |  |  | $ | 77,247 |  |  | $ | 488,544 |  |  | $ | 3,620,684 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,825,305 |  |  | $ | 80,359 |  |  | $ | 27,621 |  |  | $ | 14,923 |  |  | $ | 2,948,208 |  |
| Products and services transferred over time | — |  |  | 149,229 |  |  | 49,626 |  |  | 473,621 |  |  | 672,476 |  |
| Total revenue by timing of revenue recognition | $ | 2,825,305 |  |  | $ | 229,588 |  |  | $ | 77,247 |  |  | $ | 488,544 |  |  | $ | 3,620,684 |  |

[0000936395-22-000065:notes:126]
|  | Year Ended October 31, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,547,647 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,547,647 |  |
| Routing and Switching | 267,416 |  |  | — |  |  | — |  |  | — |  |  | 267,416 |  |
| Platform Software and Services | — |  |  | 197,809 |  |  | — |  |  | — |  |  | 197,809 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 62,632 |  |  | — |  |  | 62,632 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 269,354 |  |  | 269,354 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 152,003 |  |  | 152,003 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 35,296 |  |  | 35,296 |  |
| Total revenue by product line | $ | 2,815,063 |  |  | $ | 197,809 |  |  | $ | 62,632 |  |  | $ | 456,653 |  |  | $ | 3,532,157 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,815,063 |  |  | $ | 69,099 |  |  | $ | 19,583 |  |  | $ | 14,363 |  |  | $ | 2,918,108 |  |
| Products and services transferred over time | — |  |  | 128,710 |  |  | 43,049 |  |  | 442,290 |  |  | 614,049 |  |
| Total revenue by timing of revenue recognition | $ | 2,815,063 |  |  | $ | 197,809 |  |  | $ | 62,632 |  |  | $ | 456,653 |  |  | $ | 3,532,157 |  |

[0000936395-22-000065:notes:127]
Ciena reports its sales geographically around the following markets: (i) the United States, Canada, the Caribbean and Latin America (“Americas”); (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-22-000065:notes:128]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-22-000065:notes:129]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Geographic distribution: |  |  |  |  |  |
| Americas | $ | 2,636,840 |  |  | $ | 2,525,619 |  |  | $ | 2,469,278 |  |
| EMEA | 555,215 |  |  | 670,462 |  |  | 591,468 |  |
| APAC | 440,606 |  |  | 424,603 |  |  | 471,411 |  |
| Total revenue by geographic distribution | $ | 3,632,661 |  |  | $ | 3,620,684 |  |  | $ | 3,532,157 |  |

[0000936395-22-000065:notes:130]
Ciena’s revenue includes United States revenue of $2.42 billion for fiscal 2022, $2.27 billion for fiscal 2021 and $2.25 billion for fiscal 2020. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-22-000065:notes:131]
For the periods below, the only customers that accounted for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-22-000065:notes:132]
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| AT&T | $ | 433,418 |  |  | $ | 447,403 |  |  | $ | 373,163 |  |
| Verizon | 402,787 |  |  | n/a |  | n/a |
| Total | $ | 836,205 |  |  | $ | 447,403 |  |  | $ | 373,163 |  |

[0000936395-22-000065:notes:133]
________________________________

[0000936395-22-000065:notes:134]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-22-000065:notes:135]
The customers identified above purchased products and services from each of Ciena’s operating segments.

[0000936395-22-000065:notes:136]
While Ciena has benefited from the diversification of its business and customer base, its ten largest customers contributed 56.3% of fiscal 2022 revenue, 55.5% of fiscal 2021 revenue and 54.5% of fiscal 2020 revenue.

[0000936395-22-000065:notes:137]
◦Networking Platforms revenue reflects sales of Ciena’s Converged Packet Optical and Routing and Switching product lines.

[0000936395-22-000065:notes:138]
▪Converged Packet Optical - includes the 6500 Packet-Optical Platform, the Waveserver® modular interconnect system, the 6500 Reconfigurable Line System (RLS), the 5400 family of Packet-Optical Platforms, and the Coherent ELS open line system (OLS). This product line includes the WL5n 100G-400G coherent pluggable transceivers. This product line also includes sales of the Z-Series Packet-Optical Platform.

[0000936395-22-000065:notes:139]
▪Routing and Switching - includes the 3000 family of service delivery platforms and the 5000 family of service aggregation. This product line also includes the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics, the 8100 Coherent Routing platforms, and the 8700 Packetwave Platform. This product line also includes the Vyatta (as defined in Note 4 below) virtual routing and switching products acquired from AT&T during the first quarter of fiscal 2022.

[0000936395-22-000065:notes:140]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statements of Operations. Operating system software and enhanced software features embedded in Ciena hardware are each considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-22-000065:notes:141]
◦Platform Software and Services offerings provide domain control management, analytics, data and planning tools and applications to assist customers in managing their networks, including by creating more efficient operations and more proactive visibility into their networks. Ciena’s platform software includes its MCP domain controller solution, its suite of MCP applications, and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:142]
◦Blue Planet® Automation Software and Services is a comprehensive, cloud native, and standards-based software portfolio, together with related services, that enables customers to realize digital transformation through the automation of the services lifecycle. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:143]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered distinct performance obligations where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support is recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-22-000065:notes:144]
◦Global Services revenue reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:145]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-22-000065:notes:146]
Contract Balances

[0000936395-22-000065:notes:147]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-22-000065:notes:148]
|  |  | Balance at October 29, 2022 |  | Balance at October 30, 2021 |
| Accounts receivable, net |  | $ | 920,772 |  |  | $ | 884,958 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 156,039 |  |  | $ | 101,355 |  |
| Deferred revenue |  | $ | 200,235 |  |  | $ | 175,464 |  |

[0000936395-22-000065:notes:149]
Ciena’s contract assets represent unbilled accounts receivable, net, where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred, but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other in the Consolidated Balance Sheets. See Note 11 below.

[0000936395-22-000065:notes:150]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $111.3 million and $106.5 million of revenue during fiscal 2022 and 2021, respectively, that was included in the deferred revenue balance at October 29, 2022 and October 30, 2021, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2022 and 2021.

[0000936395-22-000065:notes:151]
Capitalized contract acquisition costs consist of deferred sales commissions and were $39.7 million and $27.6 million as of October 29, 2022 and October 30, 2021, respectively, and are included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $27.3 million and $24.6 million during fiscal 2022 and fiscal 2021, respectively, and are included in sales and marketing expense on the Consolidated Statements of Operations.

[0000936395-22-000065:notes:152]
Remaining Performance Obligations
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of October 29, 2022, the aggregate amount of RPO was $2.8 billion. As of October 29, 2022, Ciena expects approximately 91% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-22-000065:notes:153]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-22-000065:notes:154]
|  | October 29, 2022 |  | October 30, 2021 |
| Products | $ | 19,814 |  |  | $ | 12,859 |  |
| Services | 180,421 |  |  | 162,605 |  |
| Total deferred revenue | 200,235 |  |  | 175,464 |  |
| Less current portion | (137,899) |  |  | (118,007) |  |
| Long-term deferred revenue | $ | 62,336 |  |  | $ | 57,457 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-22-000065:notes:155]
CANADIAN EMERGENCY WAGE SUBSIDY
In April 2020, the Canadian government introduced the Canada Emergency Wage Subsidy (“CEWS”) to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. The CEWS program expired in October 2021. The subsidy covered employers of all sizes and across all sectors.

[0000936395-22-000065:notes:156]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statements of Operations to which the grant activity relates. Amounts from the CEWS program positively impacted Ciena’s operating expense and measures of profit in the year ended October 30, 2021. For the fiscal year ended October 30, 2021, Ciena recorded a CAD$52.2 million ($41.3 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($35.4 million) related to employee wages during fiscal 2020. There was no CEWS activity in fiscal 2020 or 2022.

[0000936395-22-000065:notes:157]
The following table summarizes CEWS for the period indicated (in thousands):

[0000936395-22-000065:notes:158]
|  |  |  | Year Ended October 30, 2021 |  |  |
| Product |  |  | $ | 4,283 |  |  |  |
| Service |  |  | 2,667 |  |  |  |
| CEWS benefit in cost of goods sold |  |  | 6,950 |  |  |  |
| Research and development |  |  | 29,519 |  |  |  |
| Sales and marketing |  |  | 2,604 |  |  |  |
| General and administrative |  |  | 2,207 |  |  |  |
| CEWS benefit in operating expense |  |  | 34,330 |  |  |  |
| Total CEWS benefit |  |  | $ | 41,280 |  |  |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-22-000065:notes:159]
BUSINESS COMBINATIONS
Fiscal 2022 Acquisitions: Vyatta and Xelic

[0000936395-22-000065:notes:160]
On November 1, 2021, Ciena acquired AT&T’s Vyatta Software Technology (“Vyatta”), a provider of software-based virtual routing and switching technology. AT&T is a customer of Ciena, see Note 2 above. On March 9, 2022, Ciena acquired Xelic, Inc., a provider and developer of field programmable gate array (FPGA) and application-specific integrated circuit (ASIC) technology and optical networking IP cores. These businesses were acquired for an aggregate of approximately $64.1 million, of which $63.3 million was paid in cash and $0.8 million represents a future payable arrangement. These transactions have each been accounted for as the acquisition of a business.

[0000936395-22-000065:notes:161]
Ciena incurred approximately $1.7 million in acquisition-related costs associated with these acquisitions. These costs and expenses primarily include fees associated with financial, legal and accounting advisors. These costs were recorded in acquisition and integration costs in the Consolidated Statements of Operations.

[0000936395-22-000065:notes:162]
The following table summarizes the final purchase price allocation related to the acquisitions based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-22-000065:notes:163]
|  | Amount |
| Cash and cash equivalents | $ | 201 |  |
| Prepaid expenses and other | 1,614 |  |
| Equipment, furniture and fixtures | 694 |  |
| Customer relationships and contracts | 15,800 |  |
| Developed technology | 32,491 |  |
| Goodwill | 17,698 |  |
| Accrued liabilities | (4,434) |  |
| Total purchase consideration | $ | 64,064 |  |

[0000936395-22-000065:notes:164]
Customer relationships and contracts represent agreements with existing Vyatta customers and have an estimated useful life of two years.

[0000936395-22-000065:notes:165]
Developed technology represents purchased technology that has reached technological feasibility and for which the acquired companies had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-22-000065:notes:166]
The goodwill generated from these acquisitions are primarily related to expected economic synergies. The total goodwill amount was recorded in the Networking Platforms segment. The goodwill is not deductible for income tax purposes.

[0000936395-22-000065:notes:167]
Pro forma disclosures have not been included due to immateriality. The amounts of revenue and earnings for these acquisitions since the acquisition dates, which are included in the Consolidated Statements of Operations for the reporting period are immaterial.

[0000936395-22-000065:notes:168]
Fiscal 2020 Acquisitions: Centina Systems, Inc.

[0000936395-22-000065:notes:169]
On November 2, 2019, Ciena acquired Centina Systems, Inc. (“Centina”), a provider of service assurance analytics and network performance management solutions, for approximately $34.0 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-22-000065:notes:170]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-22-000065:notes:171]
|  | Amount |
| Cash and cash equivalents | $ | 5,718 |  |
| Accounts receivable | 610 |  |
| Prepaid expenses and other | 536 |  |
| Equipment, furniture and fixtures | 17 |  |
| Goodwill | 13,055 |  |
| Customer relationships and contracts | 400 |  |
| Developed technology | 22,200 |  |
| Accounts payable | (47) |  |
| Accrued liabilities | (286) |  |
| Deferred revenue | (1,493) |  |
| Deferred tax liability | (6,692) |  |
| Total purchase consideration | $ | 34,018 |  |

[0000936395-22-000065:notes:172]
Customer relationships and contracts represent agreements with existing Centina customers and have an estimated useful life of two years.

[0000936395-22-000065:notes:173]
Developed technology represents purchased technology that has reached technological feasibility and for which Centina had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight-line basis over its estimated useful life of five years.

[0000936395-22-000065:notes:174]
The goodwill generated from the acquisition of Centina is primarily related to expected economic synergies. The total goodwill amount was recorded in the Blue Planet Automation Software and Services segment. The goodwill is not deductible for income tax purposes.

[0000936395-22-000065:notes:175]
Pro forma disclosures have not been included due to immateriality.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-22-000065:notes:176]
SIGNIFICANT ASSET IMPAIRMENT AND RESTRUCTURING COSTSCiena has undertaken a number of restructuring activities intended to reduce expense and align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in accrued liabilities and other short-term obligations on Ciena’s Consolidated Balance Sheets, for the fiscal years indicated (in thousands):

[0000936395-22-000065:notes:177]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at November 2, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 7,282 |  | (1) | 15,370 |  | (2) | 22,652 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160) |  | (3) | (11,160) |  |
| Cash payments | (8,350) |  |  | (15,370) |  |  | (23,720) |  |
| Balance at October 31, 2020 | 2,915 |  |  | — |  |  | 2,915 |  |
| Charges | 5,938 |  | (1) | 23,627 |  | (2) | 29,565 |  |
| Cash payments | (8,072) |  |  | (23,627) |  |  | (31,699) |  |
| Balance at October 30, 2021 | 781 |  |  | — |  |  | 781 |  |
| Charges | 3,156 |  | (1) | 26,814 |  | (2) | 29,970 |  |
| Cash payments | (2,722) |  |  | (22,194) |  |  | (24,916) |  |
| Balance at October 29, 2022 | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |
| Current restructuring liabilities | $ | 1,215 |  |  | $ | 4,620 |  |  | $ | 5,835 |  |

[0000936395-22-000065:notes:178]
_________________________________

[0000936395-22-000065:notes:179]
(1) Reflects employee costs associated with workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-22-000065:notes:180]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization and costs related to restructured real estate facilities.

[0000936395-22-000065:notes:181]
(3) Represents restructuring reserve liability recognized as a reduction to Operating ROU assets, net in relation to adoption of ASC 842.

[0000936395-22-000065:notes:182]
Significant Asset Impairments

[0000936395-22-000065:notes:183]
In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions. On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia immediately. As a result, Ciena recorded impairment charges of approximately $3.8 million of which $1.8 million was a provision for credit losses.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-22-000065:notes:184]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-22-000065:notes:185]
|  |  | Year Ended |
|  |  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Interest income |  | $ | 10,060 |  |  | $ | 2,051 |  |  | $ | 6,860 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts |  | (4,018) |  |  | 11,172 |  |  | 5,551 |  |
| Foreign currency exchange gains (losses) |  | 2,501 |  |  | (14,622) |  |  | (13,022) |  |
| Unrealized gain on cost method equity investment |  | 4,120 |  |  | — |  |  | 2,681 |  |
| Other |  | (5,916) |  |  | (369) |  |  | (1,106) |  |
| Interest and other income (loss), net |  | $ | 6,747 |  |  | $ | (1,768) |  |  | $ | 964 |  |

[0000936395-22-000065:notes:186]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2022, Ciena recorded $2.5 million in exchange rate gains as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. During fiscal 2021 and 2020, Ciena recorded $14.6 million and $13.0 million, respectively, in exchange rate losses as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net on the Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge certain of these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is also reported in interest and other income (loss), net on the Consolidated Statements of 
Operations. During fiscal 2022, Ciena recorded losses of $4.0 million from non-hedge designated foreign currency forward contracts. During fiscal 2021 and fiscal 2020, Ciena recorded gains of $11.2 million and $5.6 million, respectively, from non-hedge designated foreign currency forward contracts. During fiscal 2022 and fiscal 2020, Ciena recorded an unrealized gain of $4.1 million and $2.7 million, respectively, on its cost method equity investment.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-22-000065:notes:187]
CASH EQUIVALENT, SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments classified as available-for-sale are comprised of the following (in thousands):

[0000936395-22-000065:notes:188]
|  | October 29, 2022 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 137,963 |  |  | $ | — |  |  | $ | (3,379) |  |  | $ | 134,584 |  |
| Corporate debt securities | 54,899 |  |  | 1 |  |  | (405) |  |  | 54,495 |  |
| Time deposits | 55,889 |  |  | — |  |  | (64) |  |  | 55,825 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |
| Included in cash equivalents | $ | 55,530 |  |  | $ | — |  |  | $ | — |  |  | $ | 55,530 |  |
| Included in short-term investments | 156,430 |  |  | 1 |  |  | (2,442) |  |  | 153,989 |  |
| Included in long-term investments | 36,791 |  |  | — |  |  | (1,406) |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 1 |  |  | $ | (3,848) |  |  | $ | 244,904 |  |

[0000936395-22-000065:notes:189]
|  | October 30, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations | $ | 251,713 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 251,521 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |
| Included in cash equivalents | $ | 71,226 |  |  | $ | — |  |  | $ | — |  |  | $ | 71,226 |  |
| Included in short-term investments | 181,488 |  |  | 5 |  |  | (10) |  |  | 181,483 |  |
| Included in long-term investments | 70,225 |  |  | — |  |  | (187) |  |  | 70,038 |  |
|  | $ | 322,939 |  |  | $ | 5 |  |  | $ | (197) |  |  | $ | 322,747 |  |

[0000936395-22-000065:notes:190]
The following table summarizes the legal maturities of debt investments at October 29, 2022 (in thousands):

[0000936395-22-000065:notes:191]
|  | October 29, 2022 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 211,960 |  |  | $ | 209,519 |  |
| Due in 1-2 years | 36,791 |  |  | 35,385 |  |
|  | $ | 248,751 |  |  | $ | 244,904 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-22-000065:notes:192]
FAIR VALUE MEASUREMENTSAs of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-22-000065:notes:193]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 639,024 |  |  | $ | — |  |  | $ | — |  |  | $ | 639,024 |  |
| Bond mutual fund | 71,145 |  |  | — |  |  | — |  |  | 71,145 |  |
| Time deposits | 55,825 |  |  | — |  |  | — |  |  | 55,825 |  |
| Deferred compensation plan assets | 12,751 |  |  | — |  |  | — |  |  | 12,751 |  |
| U.S. government obligations | — |  |  | 134,584 |  |  | — |  |  | 134,584 |  |
| Corporate debt securities | — |  |  | 54,495 |  |  | — |  |  | 54,495 |  |
| Foreign currency forward contracts | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Forward starting interest rate swaps | — |  |  | 12,306 |  |  | — |  |  | 12,306 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-22-000065:notes:194]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 1,120,851 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,120,851 |  |
| Bond mutual fund | 75,425 |  |  | — |  |  | — |  |  | 75,425 |  |
| Time deposits | 71,226 |  |  | — |  |  | — |  |  | 71,226 |  |
| Deferred compensation plan assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| U.S. government obligations | — |  |  | 251,521 |  |  | — |  |  | 251,521 |  |
| Foreign currency forward contracts | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Total assets measured at fair value | $ | 1,280,470 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,546,926 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Forward starting interest rate swaps | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000065:notes:195]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheets as follows (in thousands):

[0000936395-22-000065:notes:196]
|  | October 29, 2022 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 757,725 |  |  | $ | 7,974 |  |  | $ | — |  |  | $ | 765,699 |  |
| Short-term investments | 8,269 |  |  | 145,720 |  |  | — |  |  | 153,989 |  |
| Prepaid expenses and other | — |  |  | 251 |  |  | — |  |  | 251 |  |
| Long-term investments | — |  |  | 35,385 |  |  | — |  |  | 35,385 |  |
| Other long-term assets | 12,751 |  |  | 12,306 |  |  | — |  |  | 25,057 |  |
| Total assets measured at fair value | $ | 778,745 |  |  | $ | 201,636 |  |  | $ | — |  |  | $ | 980,381 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 15,605 |  |  | $ | — |  |  | $ | 15,605 |  |

[0000936395-22-000065:notes:197]
|  | October 30, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,267,502 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,267,502 |  |
| Short-term investments | — |  |  | 181,483 |  |  | — |  |  | 181,483 |  |
| Prepaid expenses and other | — |  |  | 14,935 |  |  | — |  |  | 14,935 |  |
| Long-term investments | — |  |  | 70,038 |  |  | — |  |  | 70,038 |  |
| Other long-term assets | 12,968 |  |  | — |  |  | — |  |  | 12,968 |  |
| Total assets measured at fair value | $ | 1,280,470 |  |  | $ | 266,456 |  |  | $ | — |  |  | $ | 1,546,926 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 716 |  |  | $ | — |  |  | $ | 716 |  |
| Other long-term obligations | — |  |  | 15,928 |  |  | — |  |  | 15,928 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 16,644 |  |  | $ | — |  |  | $ | 16,644 |  |

[0000936395-22-000065:notes:198]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-22-000065:notes:199]
ACCOUNTS RECEIVABLE
As of October 29, 2022, two customers accounted for 13.0% and 11.0% of net accounts receivable, respectively. As of October 30, 2021, two customers accounted for 15.0% and 10.0% of net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. The following table summarizes the activity in Ciena’s allowance for credit losses for the fiscal years indicated (in thousands):

[0000936395-22-000065:notes:200]
| Year Ended |  | Beginning Balance |  | Effect of adoption of new accounting standard (Note 1) |  | Provisions |  | Net Deductions |  | Ending Balance |
| October 31, 2020(1) |  | $ | 20,101 |  |  | $ | — |  |  | $ | 8,855 |  |  | $ | 18,358 |  |  | $ | 10,598 |  |
| October 30, 2021 |  | $ | 10,598 |  |  | $ | 2,206 |  |  | $ | 2,346 |  |  | $ | 4,238 |  |  | $ | 10,912 |  |
| October 29, 2022(2) |  | $ | 10,912 |  |  | $ | — |  |  | $ | 4,199 |  |  | $ | 4,153 |  |  | $ | 10,958 |  |

[0000936395-22-000065:notes:201]
(1)The net deduction in Ciena’s allowance for credit losses as of October 31, 2020 is primarily due to the final settlement from a significant asset impairment of $12.2 million for a trade receivable related to a single customer in the APAC region recorded in fiscal 2017.

[0000936395-22-000065:notes:202]
(2)On March 7, 2022, Ciena announced its decision to suspend its business operations in Russia immediately. As a result, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $1.8 million for a trade receivable related to this decision.

[0000936395-22-000065:notes:203]
Accounts Receivable Factoring
During fiscal 2022, the gross amount of trade accounts receivables sold totaled approximately $11.8 million. Prior to the start of fiscal 2022, Ciena had not entered into any factoring arrangements. Factoring related interest expense recorded to interest and other income (loss), net  was $0.6 million for fiscal 2022.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-22-000065:notes:204]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-22-000065:notes:205]
|  | October 29, 2022 |  | October 30, 2021 |
| Raw materials | $ | 664,916 |  |  | $ | 175,399 |  |
| Work-in-process | 18,232 |  |  | 10,260 |  |
| Finished goods | 258,584 |  |  | 180,800 |  |
| Deferred cost of goods sold | 41,084 |  |  | 44,765 |  |
| Gross inventories | 982,816 |  |  | 411,224 |  |
| Reserve for excess and obsolescence | (36,086) |  |  | (36,959) |  |
| Inventories, net | $ | 946,730 |  |  | $ | 374,265 |  |

[0000936395-22-000065:notes:206]
Ciena has been expanding its manufacturing capacity and accumulating raw materials inventory of components that are available, in some cases with expanded lead times, in an effort to prepare Ciena to produce finished goods more quickly when supply constraints ease for certain common components, including integrated circuit components, for which delivery continues to be delayed. The increase in raw materials inventory is related to these steps to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts.

[0000936395-22-000065:notes:207]
Ciena makes estimates about future customer demand for its products when establishing the appropriate reserve for excess and obsolete inventory. For fiscal 2022, future demand was calculated primarily based on customer backlog. Generally, Ciena’s customers may cancel or change their orders with limited advance notice, or they may decide not to accept its products and services, although instances of both cancellation and non-acceptance are rare. Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During fiscal 2022, fiscal 2021 and fiscal 2020, Ciena recorded a provision for excess and obsolescence of $16.2 million, $17.9 million, and $24.7 million, respectively, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to the sale of previously reserved items and disposal activities.

[0000936395-22-000065:notes:208]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-22-000065:notes:209]
| Year Ended |  | Beginning Balance |  | Provisions |  | Disposals |  | Ending Balance |
| October 31, 2020 |  | $ | 47,322 |  |  | $ | 24,701 |  |  | $ | 32,386 |  |  | $ | 39,637 |  |
| October 30, 2021 |  | $ | 39,637 |  |  | $ | 17,850 |  |  | $ | 20,528 |  |  | $ | 36,959 |  |
| October 29, 2022 |  | $ | 36,959 |  |  | $ | 16,184 |  |  | $ | 17,057 |  |  | $ | 36,086 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-22-000065:notes:210]
PREPAID EXPENSES AND OTHERAs of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-22-000065:notes:211]
|  | October 29, 2022 |  | October 30, 2021 |
| Contract assets for unbilled accounts receivable, net | $ | 156,039 |  |  | $ | 101,355 |  |
| Prepaid VAT and other taxes | 63,975 |  |  | 77,388 |  |
| Prepaid expenses | 55,440 |  |  | 62,189 |  |
| Product demonstration equipment, net | 35,929 |  |  | 29,362 |  |
| Capitalized contract acquisition costs | 33,516 |  |  | 21,753 |  |
| Other non-trade receivables | 24,026 |  |  | 18,408 |  |
| Deferred deployment expense | 877 |  |  | 264 |  |
| Derivative assets | 251 |  |  | 14,935 |  |
|  | $ | 370,053 |  |  | $ | 325,654 |  |

[0000936395-22-000065:notes:212]
Depreciation of product demonstration equipment was $8.7 million, $9.8 million and $9.0 million for fiscal 2022, 2021 and 2020, respectively.

[0000936395-22-000065:notes:213]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-22-000065:notes:214]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-22-000065:notes:215]
|  | October 29, 2022 |  | October 30, 2021 |
| Equipment, furniture and fixtures | $ | 619,160 |  |  | $ | 599,672 |  |
| Building subject to finance lease | 69,247 |  |  | 76,123 |  |
| Leasehold improvements | 80,415 |  |  | 100,270 |  |
| Equipment, building, furniture and fixtures | 768,822 |  |  | 776,065 |  |
| Accumulated depreciation and amortization | (501,043) |  |  | (491,097) |  |
| Equipment, building, furniture and fixtures, net | $ | 267,779 |  |  | $ | 284,968 |  |

[0000936395-22-000065:notes:216]
During fiscal 2022, fiscal 2021 and fiscal 2020, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $87.2 million, $86.5 million and $84.9 million, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-22-000065:notes:217]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-22-000065:notes:218]
|  | October 29, 2022 |  | October 30, 2021 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 428,218 |  |  | $ | (386,300) |  |  | $ | 41,918 |  |  | $ | 395,726 |  |  | $ | (359,828) |  |  | $ | 35,898 |  |
| Patents and licenses | 8,415 |  |  | (4,228) |  |  | 4,187 |  |  | 7,815 |  |  | (3,321) |  |  | 4,494 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 390,271 |  |  | (366,859) |  |  | 23,412 |  |  | 375,329 |  |  | (350,407) |  |  | 24,922 |  |
| Total intangible assets | $ | 826,904 |  |  | $ | (757,387) |  |  | $ | 69,517 |  |  | $ | 778,870 |  |  | $ | (713,556) |  |  | $ | 65,314 |  |

[0000936395-22-000065:notes:219]
The aggregate amortization expense of intangible assets was $44.3 million, $36.0 million and $38.6 million for fiscal 2022, fiscal 2021 and fiscal 2020, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-22-000065:notes:220]
| Fiscal Year | Amount |  |
| 2023 | $ | 28,828 |  |  |
| 2024 | 19,194 |  |  |
| 2025 | 13,337 |  |  |
| 2026 | 7,191 |  |  |
| 2027 | 709 |  |  |
| Thereafter | 258 |  |  |
|  | $ | 69,517 |  |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-22-000065:notes:221]
GOODWILL
The following table presents the goodwill allocated to Ciena’s operating segments as of October 29, 2022 and October 30, 2021, as well as the changes to goodwill during fiscal 2022 (in thousands):

[0000936395-22-000065:notes:222]
|  | Balance at October 30, 2021 |  | Acquisitions |  |  |  | Translation |  | Balance at October 29, 2022 |
| Platform Software and Services | $ | 156,191 |  |  | $ | — |  |  |  |  | $ | — |  |  | $ | 156,191 |  |
| Blue Planet Automation Software and Services | 89,049 |  |  | — |  |  |  |  | — |  |  | 89,049 |  |
| Networking Platforms | 66,405 |  |  | 17,698 |  |  |  |  | (1,021) |  |  | 83,082 |  |
| Total | $ | 311,645 |  |  | $ | 17,698 |  |  |  |  | $ | (1,021) |  |  | $ | 328,322 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-22-000065:notes:223]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-22-000065:notes:224]
|  | October 29, 2022 |  | October 30, 2021 |
| Maintenance spares inventory, net | $ | 44,815 |  |  | $ | 55,696 |  |
| Cost method equity investments(1) | 20,698 |  |  | 8,578 |  |
| Deferred compensation plan assets | 12,751 |  |  | 12,968 |  |
| Forward starting interest rate swaps | 12,306 |  |  | — |  |
| Capitalized contract acquisition costs | 6,151 |  |  | 5,803 |  |
| Deferred debt issuance costs, net(2) | 781 |  |  | 1,188 |  |
| Restricted cash | 26 |  |  | 58 |  |
| Other | 16,089 |  |  | 15,600 |  |
|  | $ | 113,617 |  |  | $ | 99,891 |  |

[0000936395-22-000065:notes:225]
(1)Ciena recorded an unrealized gain of $4.1 million to the carrying value of its cost method equity investment to interest and other income (loss), net on the Consolidated Statements of Operations during the first quarter of fiscal 2022.

[0000936395-22-000065:notes:226]
(2) Deferred debt issuance costs relate to Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”) entered into during fiscal 2019 and its predecessor credit facility (described in Note 20 below). The amortization of deferred debt issuance costs for the ABL Credit Facility and its predecessor is included in interest expense, and was $0.4 million for fiscal 2022, fiscal 2021 and fiscal 2020.

[0000936395-22-000065:notes:227]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-22-000065:notes:228]
|  | October 29, 2022 |  | October 30, 2021 |
| Compensation, payroll related tax and benefits (1) | $ | 126,338 |  |  | $ | 201,119 |  |
| Warranty | 45,503 |  |  | 48,019 |  |
| Vacation | 26,396 |  |  | 31,200 |  |
| Foreign currency forward contracts | 15,604 |  |  | 716 |  |
| Income taxes payable | 11,472 |  |  | 13,577 |  |
| Interest payable | 4,793 |  |  | 598 |  |
| Finance lease liabilities | 3,758 |  |  | 3,620 |  |
| Other | 126,918 |  |  | 110,436 |  |
|  | $ | 360,782 |  |  | $ | 409,285 |  |

[0000936395-22-000065:notes:229]
(1) Reduction is primarily due to a lower accrual rate related to Ciena’s 2022 annual cash incentive compensation plan.

[0000936395-22-000065:notes:230]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-22-000065:notes:231]
| Year Ended |  | Beginning Balance |  |  |  | Current Year Provisions |  |  |  | Settlements |  | Ending Balance |
| October 31, 2020 |  | $ | 48,498 |  |  |  |  | $ | 22,417 |  |  |  |  | $ | 21,047 |  |  | $ | 49,868 |  |
| October 30, 2021 |  | $ | 49,868 |  |  |  |  | $ | 17,093 |  |  |  |  | $ | 18,942 |  |  | $ | 48,019 |  |
| October 29, 2022 |  | $ | 48,019 |  |  |  |  | $ | 17,440 |  |  |  |  | $ | 19,956 |  |  | $ | 45,503 |  |

[0000936395-22-000065:notes:232]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-22-000065:notes:233]
|  | October 29, 2022 |  | October 30, 2021 |
| Finance lease liabilities | $ | 53,176 |  |  | $ | 62,583 |  |
| Interest rate swap liability | — |  |  | 15,928 |  |
| Income tax liability | 72,644 |  |  | 63,412 |  |
| Deferred compensation plan liability | 12,535 |  |  | 12,877 |  |
| Other | 11,980 |  |  | 12,003 |  |
|  | $ | 150,335 |  |  | $ | 166,803 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-22-000065:notes:234]
DERIVATIVE INSTRUMENTS
Foreign Currency Derivatives

[0000936395-22-000065:notes:235]
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena entered into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-22-000065:notes:236]
As of October 29, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability that is principally related to research and development activities. The notional amount of these contracts was approximately $272.2 million and $288.6 million as of October 29, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-22-000065:notes:237]
As of October 29, 2022 and October 30, 2021, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $108.0 million and $296.1 million as of October 29, 2022 and October 30, 2021, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-22-000065:notes:238]
Interest Rate Derivatives

[0000936395-22-000065:notes:239]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 19 below) and has hedged such risk by entering into floating-to-fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate of approximately $350.0 million of the principal amount of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of these interest rate swaps in effect as of October 29, 2022 was $350.0 million.

[0000936395-22-000065:notes:240]
In April 2022, Ciena entered into floating-to-fixed forward starting interest rate swap arrangements (“forward starting swaps”). The forward starting swaps fix the Secured Overnight Funding Rate (“SOFR”) for $350.0 million of the 2025 Term Loan (as defined in Note 19 below) at 2.968% from September 2023 through the 2025 Term Loan maturity. The total notional amount of forward starting swaps effective September 2023 was $350.0 million as of October 29, 2022. Ciena entered into the forward starting swaps to hedge its anticipated SOFR rate risk from the 2025 Term Loan because the LIBOR rate is expected to be discontinued in 2023.

[0000936395-22-000065:notes:241]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps and forward starting swaps to offset exactly the forecasted variable rate payments on the equivalent notional amount of the 2025 Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-22-000065:notes:242]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 6 and 8 above.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-22-000065:notes:243]
ACCUMULATED OTHER COMPREHENSIVE INCOME (LOSS)
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax (in thousands):

[0000936395-22-000065:notes:244]
|  |  | Unrealized Gain/(Loss) on |  | Cumulative |  |  |
|  |  | Available-for-Sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 2, 2019 |  | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686) |  |  | $ | (9,475) |  |  | $ | (22,084) |  |
| Other comprehensive loss before reclassifications |  | (107) |  |  | (3,891) |  |  | (12,302) |  |  | (4,174) |  |  | (20,474) |  |
| Amounts reclassified from AOCI |  | — |  |  | 2,747 |  |  | 4,453 |  |  | — |  |  | 7,200 |  |
| Balance at October 31, 2020 |  | 45 |  |  | (219) |  |  | (21,535) |  |  | (13,649) |  |  | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications |  | (209) |  |  | 16,856 |  |  | (261) |  |  | 20,215 |  |  | 36,601 |  |
| Amounts reclassified from AOCI |  | — |  |  | (10,421) |  |  | 9,617 |  |  | — |  |  | (804) |  |
| Balance at October 30, 2021 |  | (164) |  |  | 6,216 |  |  | (12,179) |  |  | 6,566 |  |  | 439 |  |
| Other comprehensive gain (loss) before reclassifications |  | (2,801) |  |  | (16,299) |  |  | 14,512 |  |  | (49,446) |  |  | (54,034) |  |
| Amounts reclassified from AOCI |  | — |  |  | (114) |  |  | 7,064 |  |  | — |  |  | 6,950 |  |
| Balance at October 29, 2022 |  | $ | (2,965) |  |  | $ | (10,197) |  |  | $ | 9,397 |  |  | $ | (42,880) |  |  | $ | (46,645) |  |

[0000936395-22-000065:notes:245]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## us-gaap:LesseeFinanceLeasesTextBlock

[0000936395-22-000065:notes:246]
LEASESCiena leases over 1.3 million square feet of facilities globally. Ciena’s corporate headquarters are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering facilities located in San Jose, California; Alpharetta, Georgia; Quebec, Canada; and Pune and Bangalore, 
India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 10 years. Certain leases provide for options to extend up to 10 years and/or options to terminate within four years.

[0000936395-22-000065:notes:247]
Leases included in the Consolidated Balance Sheets for the fiscal periods indicated were as follows (in thousands):

[0000936395-22-000065:notes:248]
|  | Classification |  | Balance at October 29, 2022 |  | Balance at October 30, 2021 |
| Operating leases: |  |  |  |  |  |
| Operating ROU Assets | Operating right-of-use assets |  | $ | 45,108 |  |  | $ | 44,285 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | $ | 61,317 |  |  | $ | 60,196 |  |
| Finance leases: |  |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 69,247 |  |  | $ | 76,123 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (26,266) |  |  | (24,027) |  |
| Buildings, net |  |  | $ | 42,981 |  |  | $ | 52,096 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 56,934 |  |  | $ | 66,203 |  |

[0000936395-22-000065:notes:249]
ROU assets that involve subleased or vacant space aggregate $7.1 million as of October 29, 2022. Finance lease buildings, net, that involve subleased or vacant space aggregate $6.8 million as of October 29, 2022. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized, either of which may be more likely as COVID-19 impacts evolve.

[0000936395-22-000065:notes:250]
For the periods indicated, the components of lease expense included in the Consolidated Statements of Operations were as follows (in thousands):

[0000936395-22-000065:notes:251]
|  |  |  | Year Ended |  | Year Ended |  | Year Ended |
|  | Classification |  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Operating lease costs | Operating expense |  | $ | 17,966 |  |  | $ | 16,602 |  |  | $ | 17,544 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 4,592 |  |  | 4,773 |  |  | 4,465 |  |
| Interest on finance lease liabilities | Interest expense |  | 4,601 |  |  | 4,882 |  |  | 4,777 |  |
| Total finance lease cost |  |  | 9,193 |  |  | 9,655 |  |  | 9,242 |  |
| Non-capitalized lease cost | Operating expense |  | 917 |  |  | 1,152 |  |  | 2,976 |  |
| Variable lease cost(1) | Operating expense |  | 5,898 |  |  | 5,690 |  |  | 5,185 |  |
| Net lease cost(2) |  |  | $ | 33,974 |  |  | $ | 33,099 |  |  | $ | 34,947 |  |

[0000936395-22-000065:notes:252]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-22-000065:notes:253]
(2) Excludes other operating expense of $12.8 million, $8.8 million, and $11.0 million for the fiscal years ended October 29, 2022, October 30, 2021, and October 31, 2020, respectively, related to amortization of leasehold improvements.

[0000936395-22-000065:notes:254]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of October 29, 2022 were as follows (in thousands):

[0000936395-22-000065:notes:255]
|  | Operating Leases |  | Finance Leases |  | Total |
| 2023 | $ | 20,401 |  |  | $ | 7,791 |  |  | $ | 28,192 |  |
| 2024 | 16,795 |  |  | 7,791 |  |  | 24,586 |  |
| 2025 | 12,387 |  |  | 7,947 |  |  | 20,334 |  |
| 2026 | 8,879 |  |  | 7,979 |  |  | 16,858 |  |
| 2027 | 4,435 |  |  | 8,255 |  |  | 12,690 |  |
| Thereafter | 2,245 |  |  | 40,588 |  |  | 42,833 |  |
| Total lease payments | 65,142 |  |  | 80,351 |  |  | 145,493 |  |
| Less: Imputed interest | (3,825) |  |  | (23,417) |  |  | (27,242) |  |
| Present value of lease liabilities | 61,317 |  |  | 56,934 |  |  | 118,251 |  |
| Less: Current portion of present value of minimum lease payments | 18,925 |  |  | 3,758 |  |  | 22,683 |  |
| Long-term portion of present value of minimum lease payments | $ | 42,392 |  |  | $ | 53,176 |  |  | $ | 95,568 |  |

[0000936395-22-000065:notes:256]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows (in thousands):

[0000936395-22-000065:notes:257]
| Weighted-average remaining lease term in years: | As of October 29, 2022 |  | As of October 30, 2021 |
| Operating leases | 3.85 |  | 4.06 |
| Finance leases | 9.71 |  | 10.71 |
| Weighted-average discount rates: |  |  |  |
| Operating leases | 2.97 | % |  | 2.49 | % |
| Finance leases | 7.56 | % |  | 7.56 | % |


## us-gaap:DebtDisclosureTextBlock

[0000936395-22-000065:notes:258]
SHORT-TERM AND LONG-TERM DEBT
2025 Term Loan

[0000936395-22-000065:notes:259]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”). The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of fiscal 2022, the interest rate on the 2025 Term Loan was 5.24%. Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing.

[0000936395-22-000065:notes:260]
The net carrying value of the 2025 Term Loan was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-22-000065:notes:261]
|  |  | October 29, 2022 |  | October 30, 2021 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 675,675 |  |  | $ | (928) |  |  | $ | (1,737) |  |  | $ | 673,010 |  |  | $ | 677,285 |  |

[0000936395-22-000065:notes:262]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $1.7 million at October 29, 2022 and $2.3 million at October 30, 2021. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.6 million for fiscal 2022 and fiscal 2021. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-22-000065:notes:263]
As of October 29, 2022, the estimated fair value of the 2025 Term Loan was $668.9 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-22-000065:notes:264]
2030 Notes

[0000936395-22-000065:notes:265]
On January 18, 2022, Ciena entered into an Indenture (the “Indenture”) among Ciena, as issuer, certain domestic subsidiaries of Ciena, as guarantors (collectively, the “Guarantors”), and U.S. Bank National Association, as trustee (the “Trustee”), pursuant to which Ciena issued $400.0 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”).

[0000936395-22-000065:notes:266]
Ciena’s obligations under the 2030 Notes and the Indenture are irrevocably and unconditionally guaranteed, jointly and severally, on an unsecured senior basis by each of its domestic subsidiaries that is a borrower under or guarantor with respect to the 2025 Term Loan and ABL Credit Facility.

[0000936395-22-000065:notes:267]
The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $394.5 million.

[0000936395-22-000065:notes:268]
The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022.

[0000936395-22-000065:notes:269]
The 2030 Notes and related subsidiary guarantees are the general unsubordinated unsecured senior obligations of Ciena and the Guarantors, respectively, and (i) rank equally in right of payment with all other existing and future senior indebtedness of Ciena and the Guarantors; (ii) are effectively subordinated to all existing and future secured indebtedness of Ciena and the Guarantors, including indebtedness under the 2025 Term Loan and the ABL Credit Facility, to the extent of the value of the assets securing such indebtedness; (iii) are structurally subordinated to all existing and future obligations, including indebtedness, of Ciena’s subsidiaries that do not guarantee the 2030 Notes; and (iv) are senior in right of payment to all of Ciena’s existing and future unsecured indebtedness that is, by its terms, expressly subordinated in right of payment to the 2030 Notes.

[0000936395-22-000065:notes:270]
The Indenture contains restrictive covenants that limit the ability of Ciena and the Restricted Subsidiaries (as defined in the Indenture) or the Guarantors, as applicable, to, among other things, create certain liens or consolidate or merge with or into, or sell, lease, transfer, convey or otherwise dispose of all or substantially all the assets of Ciena or Ciena and its subsidiaries taken as a whole. These covenants are subject to a number of important exceptions and qualifications as set forth in the Indenture.

[0000936395-22-000065:notes:271]
The Indenture provides for events of default (subject in certain cases to customary grace and cure periods) that include, among others, nonpayment of principal or interest when due, breach of covenants or other agreements in the Indenture, defaults in payment of certain other indebtedness and certain events of bankruptcy or insolvency. Generally, if an event of default occurs, the Trustee or the holders of at least 25% in principal amount of the outstanding 2030 Notes may declare the principal amount of and accrued but unpaid interest on all of the 2030 Notes to be due and payable immediately, provided that such amounts become due and payable without any further action or notice in the case of an event of bankruptcy or insolvency that constitutes an event of default.

[0000936395-22-000065:notes:272]
Prior to January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at a price equal to 100% of the principal amount thereof, plus a “make-whole” of 102% of the principal amount of the notes to be redeemed, and any accrued and unpaid interest. On or after January 31, 2025, Ciena may redeem the 2030 Notes, in whole or part, at the redemption prices set forth in the Indenture and form of the 2030 Notes, plus any accrued and unpaid interest. In addition, until January 31, 2025, Ciena may redeem up to 40% of the aggregate principal amount of the 2030 Notes with the net cash proceeds of certain equity offerings, as described in the Indenture, at a redemption price equal to 104% of the principal amount of the 2030 Notes to be redeemed, plus any accrued and unpaid interest. If a change of control triggering event occurs, as described in the Indenture, Ciena must offer to repurchase all of the 2030 Notes (unless otherwise redeemed) at a price equal to 101% of the principal amount thereof, plus any accrued and unpaid interest.

[0000936395-22-000065:notes:273]
The net carrying value of the 2030 Notes was comprised of the following for the period indicated (in thousands):

[0000936395-22-000065:notes:274]
|  |  | October 29, 2022 |  |  |
|  |  | Principal Balance |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  |  |
| 2030 Senior Notes 4.00% fixed-rate |  | $ | 400,000 |  |  | $ | (4,955) |  |  | $ | 395,045 |  |  |  |

[0000936395-22-000065:notes:275]
Deferred debt issuance costs that were deducted from the carrying amount of the 2030 Notes totaled $5.0 million as of October 29, 2022. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the 2030 Notes. The amortization of deferred debt issuance costs for the 2030 Notes is included in interest expense, and was $0.5 million during fiscal 2022. 
As of October 29, 2022, the estimated fair value of the 2030 Notes was $337.0 million. The 2030 Notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2030 Notes using a market approach based on observable inputs, such as current market transactions involving comparable securities.ABL CREDIT FACILITY
Ciena Corporation and certain of its subsidiaries are parties to the ABL Credit Facility, which provides for a total commitment of $300 million with a maturity date of October 28, 2024. The ABL Credit Facility contains customary covenants that limit, absent lender approval, the ability of Ciena and certain of its subsidiaries to, among other things, pay cash dividends, incur debt, create liens and encumbrances, and redeem or repurchase stock. In addition, Ciena is required to maintain a minimum consolidated fixed charge coverage ratio of not less than 1.0 to 1.0 when excess availability under the ABL Credit Facility is less than the greater of (i) 10.0% of the lesser of the total borrowing base and the aggregate revolving commitments and (ii) $15,000,000. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-22-000065:notes:276]
As of October 29, 2022, letters of credit totaling $85.6 million were outstanding under the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 29, 2022.


## us-gaap:EarningsPerShareTextBlock

[0000936395-22-000065:notes:277]
EARNINGS PER SHARE CALCULATION
Basic net income per common share (“Basic EPS”) is computed using the weighted average number of common shares outstanding. Diluted net income per potential common share (“Diluted EPS”) is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-22-000065:notes:278]
The following table presents the calculation of Basic and Diluted EPS (in thousands except per share amounts):

[0000936395-22-000065:notes:279]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Net income | $ | 152,902 |  |  | $ | 500,196 |  |  | $ | 361,291 |  |
| Basic weighted average shares outstanding | 151,208 |  |  | 155,279 |  |  | 154,287 |  |
| Effect of dilutive potential common shares | 985 |  |  | 1,464 |  |  | 1,668 |  |
| Diluted weighted average shares | 152,193 |  |  | 156,743 |  |  | 155,955 |  |
| Basic EPS | $ | 1.01 |  |  | $ | 3.22 |  |  | $ | 2.34 |  |
| Diluted EPS | $ | 1.00 |  |  | $ | 3.19 |  |  | $ | 2.32 |  |
| Antidilutive employee share-based awards, excluded | 1,370 |  | 110 |  | 263 |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-22-000065:notes:280]
STOCKHOLDERS’ EQUITY
Stock Repurchase Program and Accelerated Share Repurchase Agreement

[0000936395-22-000065:notes:281]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock.

[0000936395-22-000065:notes:282]
During fiscal 2020, Ciena repurchased 1.9 million shares of its common stock, for an aggregate purchase price of $74.5 million at an average price of $39.81 per share. During fiscal 2021, Ciena repurchased an additional 1.7 million shares of its common stock, for an aggregate purchase price of $92.1 million at an average price of $54.27 per share. Under this program, Ciena repurchased a total of 7.4 million shares of its common stock, for an aggregate purchase price of $316.7 million at an average price of $42.75 per share.

[0000936395-22-000065:notes:283]
On December 9, 2021, Ciena announced that its Board of Directors replaced its previously authorized program with a program to repurchase up to $1.0 billion of its common stock. On December 13, 2021, Ciena entered into an accelerated share repurchase agreement (the “ASR Agreement”) with Goldman, Sachs & Co. LLC (“Goldman”) to repurchase $250.0 million (the “Repurchase Price”) of its common stock as part of the repurchase program. Under the terms of the ASR Agreement, Ciena paid the Repurchase Price to Goldman, and received approximately 3.6 million shares of its common stock from Goldman, calculated based on the average of the volume-weighted average prices of Ciena’s common stock of $69.78 for the period from December 14, 2021 to February 11, 2022, less a discount, which completed the repurchases contemplated by the ASR Agreement. Shares repurchased pursuant to the ASR Agreement were immediately retired upon receipt.

[0000936395-22-000065:notes:284]
During fiscal 2022, Ciena repurchased an additional 4.8 million shares of its common stock, for an aggregate purchase price of $250.0 million at an average price of $51.53 per share. As of October 29, 2022, Ciena has repurchased an aggregate of 8.4 million shares for an aggregate purchase price of $500.0 million at an average price of $59.28 per share and has an aggregate of $500.0 million of authorized funds remaining under its stock repurchase program.

[0000936395-22-000065:notes:285]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-22-000065:notes:286]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-22-000065:notes:287]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The related purchase price of $48.5 million for the shares of Ciena’s stock repurchased during fiscal 2022 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-22-000065:notes:288]
INCOME TAXES
For the periods indicated, the provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-22-000065:notes:289]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Provision (benefit) for income taxes: |  |  |  |  |  |
| Current: |  |  |  |  |  |
| Federal | $ | 27,479 |  |  | $ | 72,603 |  |  | $ | 4,363 |  |
| State | 10,289 |  |  | 21,400 |  |  | 13,328 |  |
| Foreign | 19,337 |  |  | 25,021 |  |  | 12,640 |  |
| Total current | 57,105 |  |  | 119,024 |  |  | 30,331 |  |
| Deferred: |  |  |  |  |  |
| Federal | (30,032) |  |  | (21,942) |  |  | 60,679 |  |
| State | 520 |  |  | (11,546) |  |  | 4,607 |  |
| Foreign | 2,010 |  |  | (122,981) |  |  | (947) |  |
| Total deferred | (27,502) |  |  | (156,469) |  |  | 64,339 |  |
| Provision (benefit) for income taxes | $ | 29,603 |  |  | $ | (37,445) |  |  | $ | 94,670 |  |

[0000936395-22-000065:notes:290]
For the periods indicated, income before provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-22-000065:notes:291]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| United States | $ | 28,784 |  |  | $ | 298,514 |  |  | $ | 387,697 |  |
| Foreign | 153,721 |  |  | 164,237 |  |  | 68,264 |  |
| Total | $ | 182,505 |  |  | $ | 462,751 |  |  | $ | 455,961 |  |

[0000936395-22-000065:notes:292]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-22-000065:notes:293]
For the periods indicated, the tax provision reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2022, fiscal 2021 and fiscal 2020 as follows:

[0000936395-22-000065:notes:294]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Provision at statutory rate | 21.00 | % |  | 21.00 | % |  | 21.00 | % |
| Intercompany IP Restructuring Transaction | — | % |  | (25.85) | % |  | — | % |
| Base Erosion and Anti-Abuse Tax | — | % |  | — | % |  | (1.02) | % |
| State taxes | 2.31 | % |  | 3.73 | % |  | 2.21 | % |
| Foreign taxes | (1.37) | % |  | 2.76 | % |  | 0.51 | % |
| Research and development credit | (23.66) | % |  | (7.99) | % |  | (7.74) | % |
| Non-deductible compensation | 5.26 | % |  | 1.68 | % |  | 1.79 | % |
| Foreign derived intangible income | — | % |  | (1.82) | % |  | (2.07) | % |
| Global intangible low taxed income | 1.73 | % |  | — | % |  | — | % |
| Foreign Nontaxable interest | (1.90) | % |  | — | % |  | — | % |
| Taxation on foreign inflation | 1.41 | % |  | 0.16 | % |  | (0.01) | % |
| Transition tax | — | % |  | — | % |  | 0.02 | % |
| Rate change | 1.27 | % |  | (4.33) | % |  | 3.04 | % |
| Valuation allowance | 8.35 | % |  | 1.77 | % |  | 3.58 | % |
| Other | 1.82 | % |  | 0.80 | % |  | (0.55) | % |
| Effective income tax rate | 16.22 | % |  | (8.09) | % |  | 20.76 | % |

[0000936395-22-000065:notes:295]
Our future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and utilizability of tax attributes and changes in tax laws and business reorganizations. Ciena continues to monitor these items.

[0000936395-22-000065:notes:296]
In fiscal 2021, Ciena began implementation of a plan to reorganize its global supply chain and distribution structure more substantially, which included a legal entity reorganization and related system upgrade. Ciena completed the first phase of this plan in fiscal 2021, and substantially completed the reorganization during fiscal 2022. As part of this reorganization, Ciena completed an internal transfer of certain of its non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in Ciena’s effective tax rate for the year ended October 30, 2021, which had a significant, one-time impact on its net income for the period.

[0000936395-22-000065:notes:297]
Ciena is also required to make accounting policy elections as a result of the Tax Act. These include whether a valuation allowance is recorded for the estimated effect of the application of GILTI and BEAT or if these will be treated as period costs when incurred. Ciena had made the incremental cash tax cost policy election with respect to analyzing the impact of GILTI on the assessment of the realizability of net operating losses. The realizability of U.S. tax carryforwards is not impacted by the BEAT, and the BEAT is a period cost when incurred. Ciena is also required to elect to treat taxes due on future GILTI inclusions in U.S. taxable income either as a current period expense when incurred or reflect such portion of the future GILTI inclusions in U.S. taxable income that relate to existing basis differences in Ciena’s current measurement of deferred taxes. Ciena’s accounting policy election is to treat the taxes due on future U.S. inclusions in taxable income under GILTI as a period cost when incurred.

[0000936395-22-000065:notes:298]
The significant components of deferred tax assets are as follows (in thousands):

[0000936395-22-000065:notes:299]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 76,839 |  |  | $ | 69,950 |  |
| Depreciation and amortization | 690,636 |  |  | 677,729 |  |
| NOL and credit carry forward | 154,707 |  |  | 165,087 |  |
| Other | 63,902 |  |  | 47,048 |  |
| Gross deferred tax assets | 986,084 |  |  | 959,814 |  |
| Valuation allowance | (162,076) |  |  | (159,634) |  |
| Deferred tax asset, net of valuation allowance | $ | 824,008 |  |  | $ | 800,180 |  |

[0000936395-22-000065:notes:300]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-22-000065:notes:301]
|  | Amount |
| Unrecognized tax benefits at November 2, 2019 | $ | 94,604 |  |
| Increase related to positions taken in prior period | 653 |  |
| Increase related to positions taken in current period | 1,151 |  |
| Reductions related to expiration of statute of limitations | (660) |  |
| Unrecognized tax benefits at October 31, 2020 | 95,748 |  |
| Decrease related to positions taken in prior period | (22,854) |  |
| Reductions related to settlements with taxing authorities | (654) |  |
| Increase related to positions taken in current period | 5,510 |  |
| Reductions related to expiration of statute of limitations | (659) |  |
| Unrecognized tax benefits at October 30, 2021 | 77,091 |  |
| Increase related to positions taken in prior period | 4,732 |  |
| Reductions related to settlements with taxing authorities | (3,229) |  |
| Increase related to positions taken in current period | 2,959 |  |
| Reductions related to expiration of statute of limitations | (1,039) |  |
| Unrecognized tax benefits at October 29, 2022 | $ | 80,514 |  |

[0000936395-22-000065:notes:302]
As of October 29, 2022 and October 30, 2021, Ciena had accrued $5.2 million and $3.8 million of interest and penalties, respectively, related to unrecognized tax benefits included in other long-term obligations in the Consolidated Balance Sheets. Interest and penalties of $1.7 million and $0.9 million were recorded as a net expense to the provision for income taxes during fiscal 2022 and 2020, respectively. During fiscal 2021, Ciena recorded a net benefit to the provision for interest and penalties in its provision for income taxes of $0.1 million. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-22-000065:notes:303]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 29, 2022, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized is an estimated $477.0 million. If these earnings were distributed to the U.S., Ciena would be subject to additional foreign withholding taxes of approximately $33.0 million. Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-22-000065:notes:304]
As of October 29, 2022, Ciena continues to maintain a valuation allowance of $162.1 million against its gross deferred tax assets primarily. The valuation allowance is primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.

[0000936395-22-000065:notes:305]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-22-000065:notes:306]
| Year Ended |  | Beginning Balance |  | Additions |  | Deductions |  | Ending Balance |
| October 31, 2020 |  | $ | 135,978 |  |  | $ | 25,749 |  |  | $ | 10,300 |  |  | $ | 151,427 |  |
| October 30, 2021 |  | $ | 151,427 |  |  | $ | 17,897 |  |  | $ | 9,690 |  |  | $ | 159,634 |  |
| October 29, 2022 |  | $ | 159,634 |  |  | $ | 15,245 |  |  | $ | 12,803 |  |  | $ | 162,076 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-22-000065:notes:307]
SHARE-BASED COMPENSATION EXPENSE
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under the ESPP. Each of the 2017 Plan and the ESPP are described below.

[0000936395-22-000065:notes:308]
2017 Plan

[0000936395-22-000065:notes:309]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-22-000065:notes:310]
The 2017 Plan authorizes and reserves 21.1 million shares for issuance. The number of shares available under the 2017 Plan are also increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 29, 2022, the total number of shares authorized for issuance under the 2017 Plan was 21.1 million and approximately 9.4 million shares remained available for issuance thereunder.

[0000936395-22-000065:notes:311]
Stock Options

[0000936395-22-000065:notes:312]
There were no stock options granted by Ciena during fiscal 2022, fiscal 2021 or fiscal 2020. Outstanding stock option awards granted to employees in prior periods are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-22-000065:notes:313]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 30, 2021 | 83 |  |  | $ | 32.46 |  |
| Granted | — |  |  | — |  |
| Exercised | (46) |  |  | $ | 31.44 |  |
| Canceled | (5) |  |  | $ | 51.64 |  |
| Balance at October 29, 2022 | 32 |  |  | $ | 30.98 |  |

[0000936395-22-000065:notes:314]
The total intrinsic value of options exercised during fiscal 2022, fiscal 2021 and fiscal 2020 was $1.6 million, $0.5 million and $1.3 million, respectively.

[0000936395-22-000065:notes:315]
The following table summarizes information with respect to stock options outstanding at October 29, 2022, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2022 (shares and intrinsic value in thousands):

[0000936395-22-000065:notes:316]
|  |  |  |  |  |  | Options Outstanding and Vested at |  |  |
|  |  |  |  |  |  | October 29, 2022 |  |  |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  |  |  |  |  |  |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  |  |  |  |  |  |  |  |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  |  |  |  |  |  |  |  |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  |  |  |  |  |  |  |  |
| $ | 14.38 |  |  | — |  |  | $ | 18.22 |  |  | 13 |  |  | 1.56 |  | $ | 16.02 |  |  | $ | 401 |  |  |  |  |  |  |  |  |  |
| $ | 32.06 |  |  | — |  |  | $ | 46.30 |  |  | 19 |  |  | 0.43 |  | $ | 40.67 |  |  | 145 |  |  |  |  |  |  |  |  |  |
| $ | 14.38 |  |  | — |  |  | $ | 46.30 |  |  | 32 |  |  | 0.87 |  | $ | 30.98 |  |  | $ | 546 |  |  |  |  |  |  |  |  |  |

[0000936395-22-000065:notes:317]
Assumptions for Option-Based Awards

[0000936395-22-000065:notes:318]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2022, fiscal 2021 or fiscal 2020.

[0000936395-22-000065:notes:319]
Restricted Stock Units

[0000936395-22-000065:notes:320]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total stockholder return as compared to an index of peer companies, in whole or in part.

[0000936395-22-000065:notes:321]
Assumptions for Restricted Stock Unit Awards

[0000936395-22-000065:notes:322]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-22-000065:notes:323]
Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total stockholder return, by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Share-based compensation expense is recognized over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-22-000065:notes:324]
Share-based compensation expense for restricted stock units subject only to service-based vesting conditions and restricted stock units subject to performance-based vesting conditions other than total stockholder return, is recognized only for those awards that ultimately vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0000936395-22-000065:notes:325]
Ciena recognizes the estimated fair value of performance based awards subject to total stockholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model. Ciena reverses share-based compensation expense on performance based awards subject to total shareholder return only when the requisite service period is not reached. Assumptions for awards granted during fiscal 2022, fiscal 2021 and fiscal 2020 included the following:

[0000936395-22-000065:notes:326]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 38.27% |  | 41.00% |  | 31.77% |
| Historical volatility of Ciena common stock | 42.17% |  | 42.80% |  | 36.29% |
| Historical volatility of S&P Networking Index | 27.22% |  | 27.30% |  | 18.40% |
| Correlation coefficient | 0.7049 |  | 0.6800 |  | 0.5891 |
| Expected life in years | 2.89 |  | 2.87 |  | 2.87 |
| Risk-free interest rate | 0.94% |  | 0.17% |  | 1.65% |
| Expected dividend yield | 0.0% |  | 0.0% |  | 0.0% |

[0000936395-22-000065:notes:327]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-22-000065:notes:328]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance at October 30, 2021 | 4,084 |  |  | $ | 43.67 |  |  | $ | 221,733 |  |
| Granted | 2,361 |  |  |  |  |  |
| Vested | (2,030) |  |  |  |  |  |
| Canceled or forfeited | (312) |  |  |  |  |  |
| Balance at October 29, 2022 | 4,103 |  |  | $ | 55.16 |  |  | $ | 197,960 |  |

[0000936395-22-000065:notes:329]
As of October 29, 2022 and October 30, 2021, 0.3 million of the total restricted stock units outstanding are performance based awards subject to total stockholder return. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2022, fiscal 2021 and fiscal 2020 was $119.0 million, $110.0 million and $83.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2022, fiscal 2021 and fiscal 2020 was $67.03, $48.70 and $41.61, respectively.

[0000936395-22-000065:notes:330]
Amended and Restated ESPP

[0000936395-22-000065:notes:331]
Ciena makes shares of its common stock available for purchase under the ESPP under which, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0000936395-22-000065:notes:332]
During fiscal 2022, fiscal 2021 and fiscal 2020, Ciena issued 0.7 million shares under the ESPP, for each year. At October 29, 2022, 12.2 million shares remained available for issuance under the ESPP.

[0000936395-22-000065:notes:333]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-22-000065:notes:334]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Products | $ | 3,867 |  |  | $ | 3,408 |  |  | $ | 3,182 |  |
| Services | 7,533 |  |  | 5,181 |  |  | 3,853 |  |
| Share-based compensation expense included in cost of goods sold | 11,400 |  |  | 8,589 |  |  | 7,035 |  |
| Research and development | 31,879 |  |  | 21,863 |  |  | 16,987 |  |
| Sales and marketing | 31,280 |  |  | 25,152 |  |  | 20,194 |  |
| General and administrative | 30,435 |  |  | 28,804 |  |  | 23,424 |  |
| Share-based compensation expense included in operating expense | 93,594 |  |  | 75,819 |  |  | 60,605 |  |
| Share-based compensation expense capitalized in inventory, net | 137 |  |  | (72) |  |  | 118 |  |
| Total share-based compensation | $ | 105,131 |  |  | $ | 84,336 |  |  | $ | 67,758 |  |

[0000936395-22-000065:notes:335]
As of October 29, 2022, total unrecognized share-based compensation expense was $185.7 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.51 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-22-000065:notes:336]
SEGMENT AND ENTITY WIDE DISCLOSURES
Segment Reporting

[0000936395-22-000065:notes:337]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services.

[0000936395-22-000065:notes:338]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, operating ROU assets, finite-lived intangible assets, and maintenance spares, are not reviewed by Ciena’s chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 29, 2022, equipment, building, furniture and fixtures, net, totaled $267.8 million, and operating ROU assets totaled $45.1 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of October 29, 2022, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-22-000065:notes:339]
|  | October 29, 2022 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 38,163 |  |  | $ | — |  |  | $ | 31,354 |  |  | $ | — |  |  | $ | 69,517 |  |
| Goodwill | $ | 83,082 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 328,322 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 44,815 |  |  | $ | 44,815 |  |

[0000936395-22-000065:notes:340]
Segment Profit (Loss)

[0000936395-22-000065:notes:341]
Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision (benefit) for income taxes.

[0000936395-22-000065:notes:342]
The table below sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income for the respective periods indicated (in thousands):

[0000936395-22-000065:notes:343]
|  | Year Ended |
|  | October 29, 2022 |  | October 30, 2021 |  | October 31, 2020 |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 572,305 |  |  | $ | 850,901 |  |  | $ | 827,105 |  |
| Platform Software and Services | 175,108 |  |  | 136,602 |  |  | 105,609 |  |
| Blue Planet Automation Software and Services | (22,388) |  |  | (711) |  |  | (12,446) |  |
| Global Services | 210,663 |  |  | 198,521 |  |  | 202,735 |  |
| Total segment profit | 935,688 |  |  | 1,185,313 |  |  | 1,123,003 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 466,565 |  |  | 452,214 |  |  | 416,425 |  |
| General and administrative | 179,382 |  |  | 181,874 |  |  | 169,548 |  |
| Significant asset impairments and restructuring costs | 33,824 |  |  | 29,565 |  |  | 22,652 |  |
| Amortization of intangible assets | 32,511 |  |  | 23,732 |  |  | 23,383 |  |
| Acquisition and integration costs | 598 |  |  | 2,572 |  |  | 4,031 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income (loss), net | 6,747 |  |  | (1,768) |  |  | 964 |  |
| Interest expense | (47,050) |  |  | (30,837) |  |  | (31,321) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | (646) |  |
| Less: Provision (benefit) for income taxes | 29,603 |  |  | (37,445) |  |  | 94,670 |  |
| Consolidated net income | $ | 152,902 |  |  | $ | 500,196 |  |  | $ | 361,291 |  |

[0000936395-22-000065:notes:344]
Entity Wide Reporting

[0000936395-22-000065:notes:345]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, and operating ROU assets specifically identified. Equipment, building, furniture and fixtures, net, and operating ROU assets attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, and operating ROU assets was as follows (in thousands):

[0000936395-22-000065:notes:346]
|  | October 29, 2022 |  | October 30, 2021 |  |  |
| Canada | $ | 226,451 |  |  | $ | 240,968 |  |  |  |
| United States | 47,515 |  |  | 50,744 |  |  |  |
| Other International | 38,921 |  |  | 37,541 |  |  |  |
| Total | $ | 312,887 |  |  | $ | 329,253 |  |  |  |


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-22-000065:notes:347]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit of CAD$29,210 (approximately $21,305 for 2022). This plan includes a required employer contribution of 1% for all participants and an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. During fiscal 2022, 2021 and 2020, Ciena made matching contributions of approximately CAD$10.1 million (approximately $7.4 million), CAD$8.3 million (approximately $6.7 million) and CAD$7.0 million (approximately $5.7 million), respectively.

[0000936395-22-000065:notes:348]
Ciena has a 401(k) defined contribution profit sharing plan that covers a majority of its United States-based employees. Participants may contribute up to 60% of base pay through pre-tax or Roth contributions, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 8% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2022, 2021 and 2020, Ciena made matching contributions of approximately $9.2 million, $8.4 million and $7.5 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-22-000065:notes:349]
COMMITMENTS AND CONTINGENCIES
Tax Contingencies

[0000936395-22-000065:notes:350]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-22-000065:notes:351]
Litigation

[0000936395-22-000065:notes:352]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-22-000065:notes:353]
Purchase Order Obligations

[0000936395-22-000065:notes:354]
Ciena has certain advanced orders for supply of certain long lead time components. As of October 29, 2022, Ciena had $2.6 billion in outstanding purchase order commitments to contract manufacturers and component suppliers for inventory. In certain instances, Ciena is permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.


## us-gaap:SubsequentEventsTextBlock

[0000936395-22-000065:notes:355]
SUBSEQUENT EVENTS
Acquisitions

[0000936395-22-000065:notes:356]
During the first quarter of fiscal 2023, Ciena closed on the acquisition of Benu Networks, a portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), that complement Ciena’s existing portfolio of broadband access solutions.

[0000936395-22-000065:notes:357]
On November 22, 2022, Ciena entered into a definitive agreement to acquire Tibit Communications, Inc. Tibit combines passive optical network (PON)-specific hardware and operating software into a micro pluggable transceiver that can be integrated into a carrier-grade Ethernet switch and which will strengthen Ciena’s portfolio to deliver next-generation PON solutions that support residential, enterprise and mobility use cases. Ciena will acquire the remaining shares of Tibit that it does not already own in a cash-free, debt-free transaction currently valued at approximately $210 million, subject to adjustments for cash and debt, with the merger consideration to be paid in cash. In addition, Ciena will enter into certain employee retention arrangements in connection with the transaction. The transaction is expected to close during Ciena’s first quarter fiscal 2023.
