# CIEN 8-K — 0000936395-22-000058 filed 2022-12-08

## item codes, every 8-K on or before 2022-12-16

- 2022-12-08 0000936395-22-000058 — 2.02, 9.01
- 2022-11-22 0000936395-22-000055 — 7.01, 8.01, 9.01
- 2022-09-01 0000936395-22-000049 — 2.02, 9.01
- 2022-06-02 0000936395-22-000042 — 2.02, 9.01
- 2022-04-20 0000936395-22-000035 — 5.07
- 2022-03-07 0000936395-22-000024 — 2.02, 9.01
- 2022-02-15 0000936395-22-000016 — 2.02, 9.01
- 2022-01-18 0001193125-22-011373 — 1.01, 2.03, 9.01
- 2022-01-12 0000936395-22-000006 — 8.01, 9.01
- 2022-01-10 0000936395-22-000004 — 8.01, 9.01
- 2021-12-14 0001193125-21-356718 — 1.01, 7.01, 9.01
- 2021-12-09 0000936395-21-000048 — 2.02, 8.01, 9.01
- 2021-11-03 0000936395-21-000046 — 8.01
- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2022-12-16

- none on or before 2022-12-16

## item 2.02 — earnings release, exhibit 99.1

[0000936395-22-000058:8k_2_02:1]
EX-99.1
2
ex9912022q4earningspressre.htm
EX-99.1

[0000936395-22-000058:8k_2_02:2]
Document

[0000936395-22-000058:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-22-000058:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2022 and Year-End Financial Results

[0000936395-22-000058:8k_2_02:5]
HANOVER, Md. - December 8, 2022 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter ended October 29, 2022.

[0000936395-22-000058:8k_2_02:6]
•Q4 Revenue: $971.0 million

[0000936395-22-000058:8k_2_02:7]
•Q4 Net Income per Share: $0.39 GAAP; $0.61 adjusted (non-GAAP)

[0000936395-22-000058:8k_2_02:8]
•Share Repurchases: Repurchased approximately 154,200 shares of common stock for an aggregate price of $8.0 million during the quarter.

[0000936395-22-000058:8k_2_02:9]
"Our strong fiscal fourth quarter financial results were better than expected as we benefited from some favorable supply chain developments in the second half of the quarter," said Gary Smith, president and CEO of Ciena. "Looking ahead, we expect to deliver outsized revenue growth in fiscal 2023 given our significant backlog and continued signs of gradual supply improvement. And, we remain confident that the durability of secular demand drivers and our strategic investments to expand our addressable market position us to deliver strong revenue growth over the next several years."

[0000936395-22-000058:8k_2_02:10]
For fiscal fourth quarter 2022, Ciena reported revenue of $971.0 million as compared to $1.04 billion for the fiscal fourth quarter 2021. For fiscal year 2022, Ciena reported revenue of $3.63 billion, as compared to $3.62 billion for fiscal year 2021.

[0000936395-22-000058:8k_2_02:11]
Ciena's GAAP net income for the fiscal fourth quarter 2022 was $57.6 million, or $0.39 per diluted common share, which compares to a GAAP net income of $103.5 million, or $0.66 per diluted common share, for the fiscal fourth quarter 2021. For fiscal year 2022, Ciena's GAAP net income was $152.9 million, or $1.00 per diluted common share, as compared to GAAP net income of $500.2 million, or $3.19 per diluted common share, for fiscal year 2021.

[0000936395-22-000058:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2022 was $90.9 million, or $0.61 per diluted common share, which compares to an adjusted (non-GAAP) net income of $132.7 million, or $0.85 per diluted common share, for the fiscal fourth quarter 2021. For fiscal year 2022, Ciena's adjusted (non-GAAP) net income was $288.9 million, or $1.90 per diluted common share, as compared to adjusted (non-GAAP) net income of $456.5 million, or $2.91 per diluted common share, for fiscal year 2021.

[0000936395-22-000058:8k_2_02:13]
Performance Summary for Fiscal Fourth Quarter and the Year Ended October 29, 2022

[0000936395-22-000058:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-22-000058:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 29, |  | October 30, |  | Change |  | October 29, |  | October 30, |  | Change |
|  |  | 2022 |  | 2021 |  | Y-T-Y* |  | 2022 |  | 2021 |  | Y-T-Y* |
| Revenue |  | $ | 971.0 |  |  | $ | 1,041.5 |  |  | (6.8) | % |  | $ | 3,632.7 |  |  | $ | 3,620.7 |  |  | 0.3 | % |
| Gross margin |  | 44.7 | % |  | 45.8 | % |  | (1.1) | % |  | 43.0 | % |  | 47.6 | % |  | (4.6) | % |
| Operating expense |  | $ | 356.3 |  |  | $ | 339.7 |  |  | 4.9 | % |  | $ | 1,337.5 |  |  | $ | 1,226.6 |  |  | 9.0 | % |
| Operating margin |  | 8.0 | % |  | 13.2 | % |  | (5.2) | % |  | 6.1 | % |  | 13.7 | % |  | (7.6) | % |

[0000936395-22-000058:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended |  | Period |  | Year Ended |  | Period |
|  |  | October 29, |  | October 30, |  | Change |  | October 29, |  | October 30, |  | Change |
|  |  | 2022 |  | 2021 |  | Y-T-Y* |  | 2022 |  | 2021 |  | Y-T-Y* |
| Revenue |  | $ | 971.0 |  |  | $ | 1,041.5 |  |  | (6.8) | % |  | $ | 3,632.7 |  |  | $ | 3,620.7 |  |  | 0.3 | % |
| Adj. gross margin |  | 45.2 | % |  | 46.3 | % |  | (1.1) | % |  | 43.6 | % |  | 47.9 | % |  | (4.3) | % |
| Adj. operating expense |  | $ | 312.8 |  |  | $ | 307.1 |  |  | 1.9 | % |  | $ | 1,177.0 |  |  | $ | 1,129.3 |  |  | 4.2 | % |
| Adj. operating margin |  | 13.0 | % |  | 16.8 | % |  | (3.8) | % |  | 11.2 | % |  | 16.8 | % |  | (5.6) | % |
| Adj. EBITDA |  | $ | 153.5 |  |  | $ | 199.2 |  |  | (22.9) | % |  | $ | 502.4 |  |  | $ | 702.8 |  |  | (28.5) | % |

[0000936395-22-000058:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-22-000058:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended |
|  |  | October 29, 2022 |  | October 30, 2021 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 649.9 |  |  | 66.9 |  |  | $ | 754.6 |  |  | 72.5 |  |
| Routing and Switching |  | 102.8 |  |  | 10.6 |  |  | 74.2 |  |  | 7.1 |  |
| Total Networking Platforms |  | 752.7 |  |  | 77.5 |  |  | 828.8 |  |  | 79.6 |  |
| Platform Software and Services |  | 71.6 |  |  | 7.4 |  |  | 66.1 |  |  | 6.3 |  |
| Blue Planet Automation Software and Services |  | 21.2 |  |  | 2.2 |  |  | 19.8 |  |  | 1.9 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 73.1 |  |  | 7.5 |  |  | 71.3 |  |  | 6.9 |  |
| Installation and Deployment |  | 36.9 |  |  | 3.8 |  |  | 47.2 |  |  | 4.5 |  |
| Consulting and Network Design |  | 15.5 |  |  | 1.6 |  |  | 8.3 |  |  | 0.8 |  |
| Total Global Services |  | 125.5 |  |  | 12.9 |  |  | 126.8 |  |  | 12.2 |  |
| Total |  | $ | 971.0 |  |  | 100.0 |  |  | $ | 1,041.5 |  |  | 100.0 |  |

[0000936395-22-000058:8k_2_02:19]
2

[0000936395-22-000058:8k_2_02:20]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended |
|  |  | October 29, 2022 |  | October 30, 2021 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 2,380.0 |  |  | 65.5 |  |  | $ | 2,553.5 |  |  | 70.5 |  |
| Routing and Switching |  | 398.4 |  |  | 11.0 |  |  | 271.8 |  |  | 7.5 |  |
| Total Networking Platforms |  | 2,778.4 |  |  | 76.5 |  |  | 2,825.3 |  |  | 78.0 |  |
| Platform Software and Services |  | 277.2 |  |  | 7.6 |  |  | 229.6 |  |  | 6.4 |  |
| Blue Planet Automation Software and Services |  | 76.6 |  |  | 2.1 |  |  | 77.2 |  |  | 2.1 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 292.4 |  |  | 8.1 |  |  | 283.4 |  |  | 7.8 |  |
| Installation and Deployment |  | 157.4 |  |  | 4.3 |  |  | 171.5 |  |  | 4.7 |  |
| Consulting and Network Design |  | 50.7 |  |  | 1.4 |  |  | 33.7 |  |  | 1.0 |  |
| Total Global Services |  | 500.5 |  |  | 13.8 |  |  | 488.6 |  |  | 13.5 |  |
| Total |  | $ | 3,632.7 |  |  | 100.0 |  |  | $ | 3,620.7 |  |  | 100.0 |  |

[0000936395-22-000058:8k_2_02:21]
**  Denotes %  of total revenue

[0000936395-22-000058:8k_2_02:22]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended October 29, 2022

[0000936395-22-000058:8k_2_02:23]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended |
|  |  | October 29, 2022 |  | October 30, 2021 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 723.5 |  |  | 74.5 |  |  | $ | 748.7 |  |  | 71.9 |  |
| Europe, Middle East and Africa |  | 135.1 |  |  | 13.9 |  |  | 170.8 |  |  | 16.4 |  |
| Asia Pacific |  | 112.4 |  |  | 11.6 |  |  | 122.0 |  |  | 11.7 |  |
| Total |  | $ | 971.0 |  |  | 100.0 |  |  | $ | 1,041.5 |  |  | 100.0 |  |

[0000936395-22-000058:8k_2_02:24]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended |
|  |  | October 29, 2022 |  | October 30, 2021 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 2,636.9 |  |  | 72.6 |  |  | $ | 2,525.6 |  |  | 69.8 |  |
| Europe, Middle East and Africa |  | 555.2 |  |  | 15.3 |  |  | 670.5 |  |  | 18.5 |  |
| Asia Pacific |  | 440.6 |  |  | 12.1 |  |  | 424.6 |  |  | 11.7 |  |
| Total |  | $ | 3,632.7 |  |  | 100.0 |  |  | $ | 3,620.7 |  |  | 100.0 |  |

[0000936395-22-000058:8k_2_02:25]
**  Denotes %  of total revenue

[0000936395-22-000058:8k_2_02:26]
3

[0000936395-22-000058:8k_2_02:27]
•Two customers each represented 10%-plus of revenue for the fiscal fourth quarter and fiscal year 2022, combining for a total of 25.6% of revenue for the fiscal fourth quarter and 23.0% of revenue for the fiscal year 2022

[0000936395-22-000058:8k_2_02:28]
•Cash and investments at the end of fiscal year 2022 totaled $1.2 billion

[0000936395-22-000058:8k_2_02:29]
•Cash flow used in operations totaled $14.5 million and $167.8 million for the fiscal fourth quarter and the fiscal year 2022, respectively

[0000936395-22-000058:8k_2_02:30]
•Average days' sales outstanding (DSOs) were 100 and 107 for the fiscal fourth quarter and the fiscal year 2022, respectively

[0000936395-22-000058:8k_2_02:31]
•Accounts receivable, net balance was $920.8 million

[0000936395-22-000058:8k_2_02:32]
•Unbilled contract asset, net balance was $156.0 million

[0000936395-22-000058:8k_2_02:33]
•Inventories totaled $946.7 million, including:

[0000936395-22-000058:8k_2_02:34]
◦Raw materials: $664.9 million

[0000936395-22-000058:8k_2_02:35]
◦Work in process: $18.2 million

[0000936395-22-000058:8k_2_02:36]
◦Finished goods: $258.6 million

[0000936395-22-000058:8k_2_02:37]
◦Deferred cost of sales: $41.1 million

[0000936395-22-000058:8k_2_02:38]
◦Reserve for excess and obsolescence: $(36.1) million

[0000936395-22-000058:8k_2_02:39]
•Product inventory turns were 1.9 and 1.8 for the fiscal fourth quarter and the fiscal year 2022, respectively

[0000936395-22-000058:8k_2_02:40]
•Headcount totaled 8,079 at the end of fiscal year 2022

[0000936395-22-000058:8k_2_02:41]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2022 Results

[0000936395-22-000058:8k_2_02:42]
Today, Thursday, December 08, 2022, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter and fiscal year 2022 results.

[0000936395-22-000058:8k_2_02:43]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-22-000058:8k_2_02:44]
Notes to Investors

[0000936395-22-000058:8k_2_02:45]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "Our strong fiscal fourth quarter financial results were better than expected as we benefited from some favorable supply chain developments in the second half of the quarter," said Gary Smith, president and CEO of Ciena. "Looking ahead, we expect to deliver outsized revenue growth in fiscal 2023 given our significant backlog and continued signs of gradual supply improvement. And, we remain confident that the durability of secular demand drivers and our strategic investments to expand our addressable market position us to deliver strong revenue growth over the next several years."

[0000936395-22-000058:8k_2_02:46]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader

[0000936395-22-000058:8k_2_02:47]
economic and market conditions on our customers and their business; our ability to execute our business and growth strategies; the impact of supply chain constraints or disruptions; the duration and severity of the COVID-19 pandemic and the impact of countermeasures taken to mitigate its spread on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity and financial results; changes in network spending or network strategy by our customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; changes in foreign currency exchange rates; factors beyond our control such as natural disasters, climate change, acts of war or terrorism, geopolitical events, including but not limited to the ongoing conflict between Ukraine and Russia, and public health emergencies; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; and the other risk factors disclosed in Ciena’s periodic reports filed with the Securities and Exchange Commission (SEC) including its Quarterly Report on Form 10-Q filed with the SEC on September 7, 2022 and its Annual report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-22-000058:8k_2_02:48]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-22-000058:8k_2_02:49]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-22-000058:8k_2_02:50]
5

[0000936395-22-000058:8k_2_02:51]
CIENA CORPORATION

[0000936395-22-000058:8k_2_02:52]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-22-000058:8k_2_02:53]
(in thousands, except per share data)

[0000936395-22-000058:8k_2_02:54]
(unaudited)

[0000936395-22-000058:8k_2_02:55]
|  | Quarter Ended |  | Year Ended |
|  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 779,609 |  |  | $ | 860,925 |  |  | $ | 2,888,848 |  |  | $ | 2,932,602 |  |
| Services | 191,401 |  |  | 180,561 |  |  | 743,813 |  |  | 688,082 |  |
| Total revenue | 971,010 |  |  | 1,041,486 |  |  | 3,632,661 |  |  | 3,620,684 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 440,253 |  |  | 470,334 |  |  | 1,699,631 |  |  | 1,545,269 |  |
| Services | 97,160 |  |  | 94,033 |  |  | 372,686 |  |  | 353,436 |  |
| Total cost of goods sold | 537,413 |  |  | 564,367 |  |  | 2,072,317 |  |  | 1,898,705 |  |
| Gross profit | 433,597 |  |  | 477,119 |  |  | 1,560,344 |  |  | 1,721,979 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 166,898 |  |  | 147,454 |  |  | 624,656 |  |  | 536,666 |  |
| Selling and marketing | 121,865 |  |  | 129,625 |  |  | 466,565 |  |  | 452,214 |  |
| General and administrative | 48,191 |  |  | 49,383 |  |  | 179,382 |  |  | 181,874 |  |
| Significant asset impairments and restructuring costs | 13,621 |  |  | 5,700 |  |  | 33,824 |  |  | 29,565 |  |
| Amortization of intangible assets | 5,754 |  |  | 5,836 |  |  | 32,511 |  |  | 23,732 |  |
| Acquisition and integration costs | — |  |  | 1,712 |  |  | 598 |  |  | 2,572 |  |
| Total operating expenses | 356,329 |  |  | 339,710 |  |  | 1,337,536 |  |  | 1,226,623 |  |
| Income from operations | 77,268 |  |  | 137,409 |  |  | 222,808 |  |  | 495,356 |  |
| Interest and other income (loss), net | 1,887 |  |  | (168) |  |  | 6,747 |  |  | (1,768) |  |
| Interest expense | (13,775) |  |  | (7,916) |  |  | (47,050) |  |  | (30,837) |  |
| Income before income taxes | 65,380 |  |  | 129,325 |  |  | 182,505 |  |  | 462,751 |  |
| Provision (benefit) for income taxes | 7,735 |  |  | 25,826 |  |  | 29,603 |  |  | (37,445) |  |
| Net income | $ | 57,645 |  |  | $ | 103,499 |  |  | $ | 152,902 |  |  | $ | 500,196 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.39 |  |  | $ | 0.67 |  |  | $ | 1.01 |  |  | $ | 3.22 |  |
| Diluted net income per potential common share | $ | 0.39 |  |  | $ | 0.66 |  |  | $ | 1.00 |  |  | $ | 3.19 |  |
| Weighted average basic common shares outstanding | 148,548 |  |  | 155,232 |  |  | 151,208 |  |  | 155,279 |  |
| Weighted average dilutive potential common shares outstanding 1 | 149,111 |  |  | 156,689 |  |  | 152,193 |  |  | 156,743 |  |

[0000936395-22-000058:8k_2_02:56]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i)  0.6 million and 1.0 million for the fourth quarter of fiscal 2022 and fiscal 2022, respectively; and (ii) 1.5 million shares for each of the fourth quarter of fiscal 2021 and fiscal 2021.

[0000936395-22-000058:8k_2_02:57]
CIENA CORPORATION

[0000936395-22-000058:8k_2_02:58]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-22-000058:8k_2_02:59]
(in thousands, except share data)

[0000936395-22-000058:8k_2_02:60]
(unaudited)

[0000936395-22-000058:8k_2_02:61]
|  | October 29,2022 |  | October 30,2021 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 994,352 |  |  | $ | 1,422,546 |  |
| Short-term investments | 153,989 |  |  | 181,483 |  |
| Accounts receivable, net | 920,772 |  |  | 884,958 |  |
| Inventories | 946,730 |  |  | 374,265 |  |
| Prepaid expenses and other | 370,053 |  |  | 325,654 |  |
| Total current assets | 3,385,896 |  |  | 3,188,906 |  |
| Long-term investments | 35,385 |  |  | 70,038 |  |
| Equipment, building, furniture and fixtures, net | 267,779 |  |  | 284,968 |  |
| Operating lease right-of-use assets | 45,108 |  |  | 44,285 |  |
| Goodwill | 328,322 |  |  | 311,645 |  |
| Other intangible assets, net | 69,517 |  |  | 65,314 |  |
| Deferred tax asset, net | 824,008 |  |  | 800,180 |  |
| Other long-term assets | 113,617 |  |  | 99,891 |  |
| Total assets | $ | 5,069,632 |  |  | $ | 4,865,227 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 516,047 |  |  | $ | 356,176 |  |
| Accrued liabilities and other short-term obligations | 360,782 |  |  | 409,285 |  |
| Deferred revenue | 137,899 |  |  | 118,007 |  |
| Operating lease liabilities | 18,925 |  |  | 18,632 |  |
| Current portion of long-term debt | 6,930 |  |  | 6,930 |  |
| Total current liabilities | 1,040,583 |  |  | 909,030 |  |
| Long-term deferred revenue | 62,336 |  |  | 57,457 |  |
| Other long-term obligations | 150,335 |  |  | 166,803 |  |
| Long-term operating lease liabilities | 42,392 |  |  | 41,564 |  |
| Long-term debt, net | 1,061,125 |  |  | 670,355 |  |
| Total liabilities | $ | 2,356,771 |  |  | $ | 1,845,209 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 148,412,943 and 154,858,981 shares issued and outstanding | 1,484 |  |  | 1,549 |  |
| Additional paid-in capital | 6,390,252 |  |  | 6,803,162 |  |
| Accumulated other comprehensive income (loss) | (46,645) |  |  | 439 |  |
| Accumulated deficit | (3,632,230) |  |  | (3,785,132) |  |
| Total stockholders’ equity | 2,712,861 |  |  | 3,020,018 |  |
| Total liabilities and stockholders’ equity | $ | 5,069,632 |  |  | $ | 4,865,227 |  |

[0000936395-22-000058:8k_2_02:62]
7

[0000936395-22-000058:8k_2_02:63]
CIENA CORPORATION

[0000936395-22-000058:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-22-000058:8k_2_02:65]
(in thousands) (unaudited)

[0000936395-22-000058:8k_2_02:66]
|  | Year Ended |
|  | October 29, |  | October 30, |
|  | 2022 |  | 2021 |
| Cash flows provided by (used in) operating activities: |  |  |  |
| Net income | $ | 152,902 |  |  | $ | 500,196 |  |
| Adjustments to reconcile net income to net cash provided by (used in) operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 95,922 |  |  | 96,233 |  |
| Share-based compensation expense | 105,131 |  |  | 84,336 |  |
| Amortization of intangible assets | 44,281 |  |  | 36,033 |  |
| Deferred taxes | (27,502) |  |  | (156,469) |  |
| Provision for inventory excess and obsolescence | 16,184 |  |  | 17,850 |  |
| Provision for warranty | 17,440 |  |  | 17,093 |  |
| Other | — |  |  | 14,525 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (47,069) |  |  | (174,377) |  |
| Inventories | (589,113) |  |  | (47,567) |  |
| Prepaid expenses and other | (58,996) |  |  | (19,691) |  |
| Operating lease right-of-use assets | 16,453 |  |  | 16,632 |  |
| Accounts payable, accruals and other obligations | 100,327 |  |  | 162,134 |  |
| Deferred revenue | 26,380 |  |  | 16,822 |  |
| Short and long-term operating lease liabilities | (20,096) |  |  | (22,104) |  |
| Net cash provided by (used in) operating activities | (167,756) |  |  | 541,646 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (90,818) |  |  | (79,550) |  |
| Purchase of available for sale securities | (643,971) |  |  | (172,778) |  |
| Proceeds from maturities of available for sale securities | 698,642 |  |  | 152,253 |  |
| Settlement of foreign currency forward contracts, net | 4,942 |  |  | 4,680 |  |
| Acquisition of business, net of cash acquired | (62,043) |  |  | — |  |
| Purchase of cost method equity investments | (8,000) |  |  | — |  |
| Proceeds from sale of cost method equity investments | — |  |  | 4,678 |  |
| Net cash used in investing activities | (101,248) |  |  | (90,717) |  |
| Cash flows used in financing activities: |  |  |  |
| Proceeds from issuance of senior notes | 400,000 |  |  | — |  |
| Payment of long term debt | (5,197) |  |  | (6,929) |  |
| Payment of debt issuance costs | (5,484) |  |  | — |  |
| Payment of finance lease obligations | (3,468) |  |  | (3,004) |  |
| Shares repurchased for tax withholdings on vesting of stock unit awards | (48,454) |  |  | (44,071) |  |
| Repurchases of common stock - repurchase program | (500,800) |  |  | (91,288) |  |
| Proceeds from issuance of common stock | 30,348 |  |  | 28,457 |  |
| Net cash used in financing activities | (133,055) |  |  | (116,835) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | (26,167) |  |  | (198) |  |
| Net increase (decrease) in cash, cash equivalents and restricted cash | (428,226) |  |  | 333,896 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,422,604 |  |  | 1,088,708 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 994,378 |  |  | $ | 1,422,604 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 42,812 |  |  | $ | 29,864 |  |
| Cash paid during the period for income taxes, net | $ | 34,967 |  |  | $ | 73,127 |  |
| Operating lease payments | $ | 21,661 |  |  | $ | 24,058 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 12,373 |  |  | $ | 10,138 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | — |  |  | $ | 800 |  |
| Operating right-of-use assets subject to lease liability | $ | 23,242 |  |  | $ | 4,356 |  |
| Unrealized gain on equity investment | $ | 4,120 |  |  | $ | — |  |

[0000936395-22-000058:8k_2_02:67]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 433,597 |  |  | $ | 477,119 |  |  | $ | 1,560,344 |  |  | $ | 1,721,979 |  |
| Share-based compensation-products |  | 907 |  |  | 920 |  |  | 3,867 |  |  | 3,408 |  |
| Share-based compensation-services |  | 2,066 |  |  | 1,240 |  |  | 7,533 |  |  | 5,181 |  |
| Canadian Emergency Wage Subsidy-products |  | — |  |  | — |  |  | — |  |  | (4,283) |  |
| Canadian Emergency Wage Subsidy-services |  | — |  |  | — |  |  | — |  |  | (2,667) |  |
| Amortization of intangible assets |  | 2,005 |  |  | 2,856 |  |  | 11,770 |  |  | 12,301 |  |
| Total adjustments related to gross profit |  | 4,978 |  |  | 5,016 |  |  | 23,170 |  |  | 13,940 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 438,575 |  |  | $ | 482,135 |  |  | $ | 1,583,514 |  |  | $ | 1,735,919 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 45.2 | % |  | 46.3 | % |  | 43.6 | % |  | 47.9 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 356,329 |  |  | $ | 339,710 |  |  | $ | 1,337,536 |  |  | $ | 1,226,623 |  |
| Share-based compensation-research and development |  | 8,507 |  |  | 5,684 |  |  | 31,879 |  |  | 21,863 |  |
| Share-based compensation-sales and marketing |  | 8,084 |  |  | 6,192 |  |  | 31,280 |  |  | 25,152 |  |
| Share-based compensation-general and administrative |  | 7,610 |  |  | 7,466 |  |  | 30,435 |  |  | 28,804 |  |
| Canadian Emergency Wage Subsidy-research and development |  | — |  |  | — |  |  | — |  |  | (29,519) |  |
| Canadian Emergency Wage Subsidy-sales and marketing |  | — |  |  | — |  |  | — |  |  | (2,604) |  |
| Canadian Emergency Wage Subsidy-general and administrative |  | — |  |  | — |  |  | — |  |  | (2,207) |  |
| Significant asset impairments and restructuring costs |  | 13,621 |  |  | 5,700 |  |  | 33,824 |  |  | 29,565 |  |
| Amortization of intangible assets |  | 5,754 |  |  | 5,836 |  |  | 32,511 |  |  | 23,732 |  |
| Acquisition and integration costs |  | — |  |  | 1,712 |  |  | 598 |  |  | 2,572 |  |
| Total adjustments related to operating expense |  | 43,576 |  |  | 32,590 |  |  | 160,527 |  |  | 97,358 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 312,753 |  |  | $ | 307,120 |  |  | $ | 1,177,009 |  |  | $ | 1,129,265 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 77,268 |  |  | $ | 137,409 |  |  | $ | 222,808 |  |  | $ | 495,356 |  |
| Total adjustments related to gross profit |  | 4,978 |  |  | 5,016 |  |  | 23,170 |  |  | 13,940 |  |
| Total adjustments related to operating expense |  | 43,576 |  |  | 32,590 |  |  | 160,527 |  |  | 97,358 |  |
| Total adjustments related to income from operations |  | 48,554 |  |  | 37,606 |  |  | 183,697 |  |  | 111,298 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 125,822 |  |  | $ | 175,015 |  |  | $ | 406,505 |  |  | $ | 606,654 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.0 | % |  | 16.8 | % |  | 11.2 | % |  | 16.8 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income |  | $ | 57,645 |  |  | $ | 103,499 |  |  | $ | 152,902 |  |  | $ | 500,196 |  |
| Exclude GAAP provision (benefit) for income taxes |  | 7,735 |  |  | 25,826 |  |  | 29,603 |  |  | (37,445) |  |
| Income before income taxes |  | 65,380 |  |  | 129,325 |  |  | 182,505 |  |  | 462,751 |  |
| Total adjustments related to income from operations |  | 48,554 |  |  | 37,606 |  |  | 183,697 |  |  | 111,298 |  |
| Unrealized (gain) loss on cost method equity investment |  | — |  |  | — |  |  | (4,120) |  |  | 165 |  |
| Adjusted income before income taxes |  | 113,934 |  |  | 166,931 |  |  | 362,082 |  |  | 574,214 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 23,015 |  |  | 34,221 |  |  | 73,141 |  |  | 117,714 |  |
| Adjusted (non-GAAP) net income |  | $ | 90,919 |  |  | $ | 132,710 |  |  | $ | 288,941 |  |  | $ | 456,500 |  |

[0000936395-22-000058:8k_2_02:68]
9

[0000936395-22-000058:8k_2_02:69]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Measurements |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Weighted average basic common shares outstanding |  | 148,548 |  | 155,232 |  | 151,208 |  | 155,279 |
| Weighted average dilutive potential common shares outstanding 1 |  | 149,111 |  | 156,689 |  | 152,193 |  | 156,743 |
| Net Income per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income per potential common share |  | $ | 0.39 |  |  | $ | 0.66 |  |  | $ | 1.00 |  |  | $ | 3.19 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.61 |  |  | $ | 0.85 |  |  | $ | 1.90 |  |  | $ | 2.91 |  |

[0000936395-22-000058:8k_2_02:70]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share includes the following number of shares underlying certain stock option and stock unit awards: (i) 0.6 million and 1.0 million for the fourth quarter of fiscal 2022 and fiscal 2022, respectively; and (ii) 1.5 million each for the fourth quarter of fiscal 2021 and fiscal 2021.

[0000936395-22-000058:8k_2_02:71]
10

[0000936395-22-000058:8k_2_02:72]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 29, |  | October 30, |  | October 29, |  | October 30, |
|  |  | 2022 |  | 2021 |  | 2022 |  | 2021 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (GAAP) |  | $ | 57,645 |  |  | $ | 103,499 |  |  | $ | 152,902 |  |  | $ | 500,196 |  |
| Add: Interest expense |  | 13,775 |  |  | 7,916 |  |  | 47,050 |  |  | 30,837 |  |
| Less: Interest and other income (loss), net |  | 1,887 |  |  | (168) |  |  | 6,747 |  |  | (1,768) |  |
| Add: Provision (benefit) for income taxes |  | 7,735 |  |  | 25,826 |  |  | 29,603 |  |  | (37,445) |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 27,642 |  |  | 24,315 |  |  | 95,922 |  |  | 96,233 |  |
| Add: Amortization of intangible assets |  | 7,759 |  |  | 8,692 |  |  | 44,281 |  |  | 36,033 |  |
| EBITDA |  | $ | 112,669 |  |  | $ | 170,416 |  |  | $ | 363,011 |  |  | $ | 627,622 |  |
| Less: Canadian Emergency Wage Subsidy |  | — |  |  | — |  |  | — |  |  | 41,280 |  |
| Add: Share-based compensation cost |  | 27,174 |  |  | 21,366 |  |  | 104,994 |  |  | 84,336 |  |
| Add: Significant asset impairments and restructuring costs |  | 13,621 |  |  | 5,700 |  |  | 33,824 |  |  | 29,565 |  |
| Add: Acquisition and integration costs |  | — |  |  | 1,712 |  |  | 598 |  |  | 2,572 |  |
| Adjusted EBITDA |  | $ | 153,464 |  |  | $ | 199,194 |  |  | $ | 502,427 |  |  | $ | 702,815 |  |

[0000936395-22-000058:8k_2_02:73]
* * *

[0000936395-22-000058:8k_2_02:74]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-22-000058:8k_2_02:75]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-22-000058:8k_2_02:76]
•Canadian Emergency Wage Subsidy -  a program introduced by the Government of Canada to offset a portion of employee wages for a limited period in response to COVID-19 outbreak.

[0000936395-22-000058:8k_2_02:77]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities, the redesign of business processes and, in fiscal 2022, a $3.8 million impairment charge due to Ciena's decision to suspend its business operations in Russia in response to the conflict in Ukraine.

[0000936395-22-000058:8k_2_02:78]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-22-000058:8k_2_02:79]
•Acquisition and integration costs  - includes financial, legal and accounting advisor expenses related to our acquisition activity in fiscal 2022. Acquisition and integration costs for fiscal 2021 include costs of acquisition compensation associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018.

[0000936395-22-000058:8k_2_02:80]
•Unrealized (gain)loss on cost method equity investment - reflects a change in the carrying value of a certain cost method equity investment.

[0000936395-22-000058:8k_2_02:81]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20.2% for fiscal quarter 2022 and 20.5% for fiscal quarter 2021. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy.
