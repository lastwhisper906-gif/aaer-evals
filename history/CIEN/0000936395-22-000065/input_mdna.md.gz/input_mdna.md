# CIEN MD&A — 0000936395-22-000065


## mdna

[0000936395-22-000065:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-22-000065:mdna:2]
The following discussion and analysis should be read in conjunction with our consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-22-000065:mdna:3]
Overview

[0000936395-22-000065:mdna:4]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that support the delivery of video, data and voice traffic over core, metro, aggregation and access communications networks. Our solutions are used globally by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, and enterprises across multiple industry verticals.

[0000936395-22-000065:mdna:5]
Our portfolio is designed to enable the Adaptive Network, which is our vision for a network end state that leverages a programmable and scalable network infrastructure, driven by software control and automation capabilities, that are informed by analytics and intelligence. By transforming network infrastructures into dynamic, programmable environments driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end-user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network performance and maximize the return on their network infrastructure investment.

[0000936395-22-000065:mdna:6]
Our solutions include Networking Platforms, including our Converged Packet Optical and Routing and Switching portfolios, which can be applied from the network core to end-user access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic efficiently and adapt dynamically to changing end-user service demands. Our Converged Packet Optical portfolio includes products that support long haul and regional networks, submarine and data center interconnect networks, and metro and edge networks. Our Routing and Switching portfolio includes products and solutions that enable efficient IP transport in next-generation metro edge, access and aggregation networks.

[0000936395-22-000065:mdna:7]
To complement our Networking Platforms, we offer Platform Software, which includes our MCP applications that deliver advanced multi-layer domain control and operations. Through our Blue Planet Software we also enable complete service lifecycle management automation with productized OSS and service assurance solutions that help our customers to achieve closed loop automation across multi-vendor and multi-domain environments.

[0000936395-22-000065:mdna:8]
In addition to our systems and software, we also offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments. These include network transformation, consulting, implementation, systems integration, maintenance, NOC management, learning, and optimization services.

[0000936395-22-000065:mdna:9]
Demand Environment

[0000936395-22-000065:mdna:10]
Since the second quarter of fiscal 2021, we have experienced unprecedented demand for our products and services. Our quarterly order volumes during this period have significantly exceeded our revenue and historical order volumes, with some concentration of orders among certain existing Webscale and North America-based service provider customers. We believe that we are benefiting from certain shifts in business and consumer behaviors, in part accelerated by the COVID-19 pandemic, that represent positive, long-term trends for our business. These include 5G, enterprise and consumer cloud network adoption, increasing demands on the network edge, and network operator focus on resilience and automation. We believe some portion of these orders also reflects customer acceleration of future orders due to lengthened lead times or the implementation of security of supply strategies to address the supply constraints described below. As a result, our backlog has grown from $2.2 billion at the end of fiscal 2021 to $4.2 billion at the end of fiscal 2022. However, our order growth relative to revenue has begun to moderate from the first half of fiscal 2022 and we expect it to continue to moderate over time. As a result, our backlog should not necessarily be viewed as an accurate indicator of revenue for any particular period. See “Risk Factors” in Item 1A of Part I of this report for further discussion of risks related to the demand environment.

[0000936395-22-000065:mdna:11]
Supply Chain Constraints

[0000936395-22-000065:mdna:12]
In the face of extraordinary demand across a range of industries, global supply for certain raw materials and components, including, in particular, semiconductor, integrated circuits and other electronic components used in most of our products, has experienced substantial constraint and disruption in recent periods. As a result, we have experienced significant component shortages, extended lead times, increased costs, and unexpected cancellation or delay of previously committed supply of key components across our supplier base. Beginning in the second half of fiscal 2021, we started placing significant, advanced

[0000936395-22-000065:mdna:13]
orders for supply of certain long lead time components to address our expected customer demand for fiscal 2022 and the then-emerging supply chain challenges. Since that time, we have continued to extend the duration of our purchase commitments, or placed non-cancellable, advanced orders with or through suppliers, particularly for long lead time components. As of October 29, 2022, we had $2.6 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory.

[0000936395-22-000065:mdna:14]
During the second half of fiscal 2022, reliability of supply improved gradually, and the majority of our suppliers were able to deliver components by their promised, though in many cases, extended, lead times. However, we continued to experience substantial delays and lower-than-expected component deliveries from a small group of our suppliers of integrated circuit components that represent a small fraction of our overall materials, but which are essential for delivering finished products. Although we benefited from some favorable supply chain developments during the fourth quarter of fiscal 2022, including receiving more integrated circuits than expected, as well as our investment in expanded manufacturing capacity described below, ongoing supply constraints and the unpredictable performance of our supply chain adversely impacted our ability to meet customer demand and our level of revenue and growth in fiscal 2022, in particular for our Converged Packet Optical products. At the same time, increased supply chain costs, including purchase price increases, supply premiums, expediting fees and freight and logistics, adversely impacted our gross margin and profitability in fiscal 2022. We expect these constrained supply conditions to increase our costs of goods sold in the near term and to adversely impact our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. We believe these supply chain challenges will continue at least through fiscal 2023 and expect that the extended lead times and elevated supply chain costs we have experienced will persist for the reasonably foreseeable future. It is unclear when the supply environment will become less volatile and what impacts the supply environment will have on our business and results of operations in future periods.

[0000936395-22-000065:mdna:15]
To mitigate the impact of these supply conditions on our business and customers, in addition to placing advance orders for inventory, we have been expanding our manufacturing capacity and accumulating components that are in available supply, in some cases with expanded lead times. We believe that this approach positions us to produce finished goods more quickly when supply constraints ease for those components for which delivery continues to be delayed. As a result of this strategy, our inventory has increased from $374.3 million at the end of fiscal 2021 to $946.7 million at the end of fiscal 2022. We have also implemented additional mitigation strategies, including multi-sourcing activities, qualifying alternative parts, and product redesign, and expect, over time, to realize certain benefits of these mitigation activities. Together with increased costs of supply, these mitigation strategies have impacted, and can be expected to continue to impact, our result of operations and cash from operations. See “Risk Factors” in Item 1A of Part I of this report for further discussion of risks related to our supply chain, inventory and our mitigation activities.

[0000936395-22-000065:mdna:16]
Impact of Global Events on our Business and Operations

[0000936395-22-000065:mdna:17]
COVID-19 Pandemic. The impact of the COVID-19 pandemic and of countermeasures taken to contain its spread remain dynamic. We continue to monitor the situation and actively assess further implications for our business, supply chain, fulfillment operations and customer demand. For example, we gradually reopened a significant number of our offices globally during fiscal 2022. We continue to take meaningful precautions in accordance with relevant guidelines to protect the health and safety of our employees. Variants continue to emerge, efforts to mitigate or contain the impacts of the pandemic continue to evolve, and the duration and severity of the impact of the pandemic on our business and results of operations in future periods remain uncertain. The COVID-19 pandemic and related countermeasures have previously impacted our operations and disrupted the manufacturing operations of our supply chain business partners. If the COVID-19 pandemic or its adverse effects, including the effects of extended government-mandated lockdowns in several cities in China, become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, our business and results of operations could be adversely impacted. If we experience more pronounced, COVID-19 related disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-22-000065:mdna:18]
Russia and Ukraine Conflict. In February 2022, armed conflict escalated between Russia and Ukraine. The United States and certain other countries have imposed sanctions on Russia and could impose further sanctions, which could damage or disrupt international commerce and the global economy. We are complying with a broad range of United States and international sanctions and export control requirements imposed on Russia and, on March 7, 2022, we announced our decision to suspend our business operations in Russia immediately. Due to the limited amount of business that we have conducted in Russia historically, this decision did not materially impact our results of operations for fiscal 2022 and we do not expect it to materially impact our results of operations going forward. See Note 5 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on the impact of suspending our business operations in Russia.

[0000936395-22-000065:mdna:19]
Market Opportunity

[0000936395-22-000065:mdna:20]
The market in which we sell our communications networking solutions is dynamic and characterized by a high rate of change, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Emerging services and applications, including 5G mobile communications, fiber-based access networks and the Internet of Things, are further impacting or expected to impact wireline network infrastructures, particularly at the edge of networks, where increased capacity, computing power and automation are required to provide the quality of experience demanded by end users. Many network operators are under pressure to constrain their capital expenditure budgets, as they cannot grow their network spending at the rate of bandwidth growth. To address these growing service demands and manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation. Other network operators are pursuing a diverse range of consumption models in their design and procurement of network infrastructure solutions. Our Adaptive Network vision and our business strategy to capitalize on these changing market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part I of this annual report.

[0000936395-22-000065:mdna:21]
Strategic and Financial Initiatives

[0000936395-22-000065:mdna:22]
Strategic Acquisitions. During fiscal 2022, we acquired AT&T’s Vyatta virtual routing and switching technology, which is intended to expand and accelerate our Adaptive IP solutions and address the growing market opportunity to transform the network edge, including 5G networks and cloud environments. During fiscal 2022, we also acquired Xelic, a provider and developer of FPGA and ASIC technology and optical networking IP cores, to enhance development of our WaveLogic coherent modem technology. See Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on these acquisitions and the related accounting.

[0000936395-22-000065:mdna:23]
During the first quarter of fiscal 2023, we acquired Benu and its portfolio of cloud-native software solutions, including a virtual Broadband Network Gateway ((v)BNG), which complement our existing portfolio of broadband access solutions. In the first quarter of fiscal 2023, we also entered into a definitive agreement to acquire Tibit Communications, Inc., a provider of passive optical network solutions. See Note 28 “Subsequent Events” to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on this acquisition.

[0000936395-22-000065:mdna:24]
Stock Repurchase Program. On December 9, 2021, we announced that our Board of Directors had authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety our previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into an accelerated share repurchase agreement (the “ASR Agreement”) for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During fiscal 2022, we repurchased an additional $250.0 million of our common stock under the stock repurchase program, and we had $500.0 million remaining under the current repurchase authorization as of October 29, 2022. The amount and timing of any further repurchases under our stock purchase program are subject to a variety of factors, including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Item 5 of Part II of this report and Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on our stock repurchase program.

[0000936395-22-000065:mdna:25]
Senior Notes Due 2030. On January 18, 2022, we issued $400 million in aggregate principal amount of 4.00% senior notes due 2030 (the “2030 Notes”). The net proceeds from the sale of the 2030 Notes, after deducting costs, were approximately $394.5 million with the use of proceeds intended for general corporate purposes. The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year, commencing on July 31, 2022. See Note 19 to our Consolidated Financial Statements included in Item 8 of Part II of this report for more information on our 2030 Notes.

[0000936395-22-000065:mdna:26]
Fiscal Year-End Backlog

[0000936395-22-000065:mdna:27]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These agreements do not obligate customers to purchase any minimum or guaranteed order quantities. In calculating backlog, we only include (i) customer purchase orders for products that have not been shipped and for services that have not yet been performed; and (ii) customer orders relating to products that have been delivered and services that have been performed, but are awaiting customer acceptance under the applicable contract terms. Generally, our customers may cancel, delay or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. Backlog may be fulfilled several quarters following receipt of a purchase order, or in the case of certain service obligations,

[0000936395-22-000065:mdna:28]
may relate to multi-year support period. As a result, backlog should not necessarily be viewed as an accurate indicator of future revenue for any particular period.

[0000936395-22-000065:mdna:29]
Our backlog was $4.2 billion as of October 29, 2022, as compared to $2.2 billion as of October 30, 2021. Backlog includes product and service orders from commercial and government customers combined, and our significant annual growth reflects the demand dynamics described above. Backlog at October 29, 2022 includes approximately $251.8 million primarily related to orders for products and maintenance and support services that are not expected to be filled or performed within fiscal 2023. Because backlog can be defined in different ways by different companies, our presentation of backlog may not be comparable with figures presented by other companies in our industry.

[0000936395-22-000065:mdna:30]
Consolidated Results of Operations

[0000936395-22-000065:mdna:31]
A discussion regarding our financial condition and results of operations for fiscal 2022 compared to fiscal 2021 is presented below. A discussion of fiscal 2021 compared to fiscal 2020 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended October 30, 2021, filed with the SEC on December 17, 2021, which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-22-000065:mdna:32]
Operating Segments

[0000936395-22-000065:mdna:33]
Our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Notes 2 and 25 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information on our segment reporting.

[0000936395-22-000065:mdna:34]
Fiscal 2022 Compared to Fiscal 2021

[0000936395-22-000065:mdna:35]
Revenue

[0000936395-22-000065:mdna:36]
Currency Fluctuations

[0000936395-22-000065:mdna:37]
During fiscal 2022, approximately 13.7% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Canadian Dollars and British Pounds. During fiscal 2022, as compared to fiscal 2021, the U.S. Dollar primarily strengthened against these and other currencies. Consequently, our revenue reported in U.S. Dollars was adversely impacted by approximately $32.0 million, or 0.9%, as compared to fiscal 2021.

[0000936395-22-000065:mdna:38]
Operating Segment Revenue

[0000936395-22-000065:mdna:39]
The table below sets forth the changes in our operating segment revenue for the periods indicated (in thousands, except percentage data):

[0000936395-22-000065:mdna:40]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,379,931 |  |  | 65.5 |  | $ | 2,553,509 |  |  | 70.5 |  | $ | (173,578) |  |  | (6.8) |
| Routing and Switching | 398,439 |  |  | 11.0 |  | 271,796 |  |  | 7.5 |  | 126,643 |  |  | 46.6 |
| Total Networking Platforms | 2,778,370 |  |  | 76.5 |  | 2,825,305 |  |  | 78.0 |  | (46,935) |  |  | (1.7) |
| Platform Software and Services | 277,191 |  |  | 7.6 |  | 229,588 |  |  | 6.4 |  | 47,603 |  |  | 20.7 |
| Blue Planet Automation Software and Services | 76,567 |  |  | 2.1 |  | 77,247 |  |  | 2.1 |  | (680) |  |  | (0.9) |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 292,375 |  |  | 8.1 |  | 283,350 |  |  | 7.8 |  | 9,025 |  |  | 3.2 |
| Installation and Deployment | 157,443 |  |  | 4.3 |  | 171,489 |  |  | 4.7 |  | (14,046) |  |  | (8.2) |
| Consulting and Network Design | 50,715 |  |  | 1.4 |  | 33,705 |  |  | 1.0 |  | 17,010 |  |  | 50.5 |
| Total Global Services | 500,533 |  |  | 13.8 |  | 488,544 |  |  | 13.5 |  | 11,989 |  |  | 2.5 |
| Consolidated revenue | $ | 3,632,661 |  |  | 100.0 |  | $ | 3,620,684 |  |  | 100.0 |  | $ | 11,977 |  |  | 0.3 |

[0000936395-22-000065:mdna:41]
_________________________________

[0000936395-22-000065:mdna:42]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:43]
•Networking Platforms segment revenue decreased by $46.9 million, reflecting product line sales decreases of $173.6 million of our Converged Packet Optical products, offset by product line sales increases of $126.6 million of our Routing and Switching products. Converged Packet Optical sales were adversely impacted by the current constrained supply environment, including the current market shortage for semiconductor components, as described in more detail in “Overview” above.

[0000936395-22-000065:mdna:44]
◦Converged Packet Optical sales decreased, primarily reflecting sales decreases of $128.9 million of our 6500 Packet-Optical Platform, primarily to communications service providers and Web-scale providers, $73.2 million of our Waveserver® modular interconnect system, primarily to Web-scale providers, $26.5 million of our 5400 family of Packet-Optical Platforms and $25.1 million of our Z-Series Packet-Optical Platform, both primarily to communications service providers. These sales decreases were partially offset by a sales increase of $79.8 million of our 6500 RLS products, primarily to Web-scale providers and communications service providers.

[0000936395-22-000065:mdna:45]
◦Routing and Switching sales increased, primarily reflecting sales of $86.1 million of our Virtualization Edge software, which was acquired in the acquisition of the Vyatta virtual routing and switching technology in the first quarter of fiscal 2022, and a sales increase of $50.5 million of our 3000 and 5000 families of service delivery and aggregation switches to communications service providers. The increase in Routing and Switching sales was partially offset by a sales decrease of $14.7 million of our 8700 Packetwave Platform, primarily to communications service providers.

[0000936395-22-000065:mdna:46]
•Platform Software and Services segment revenue increased by $47.6 million, reflecting increases of $41.2 million in software services and $6.4 million in sales of software platforms. The increase in our software services was primarily due to increased sales of subscription services. The software sales increase was primarily due to increased sales of our MCP software platform.

[0000936395-22-000065:mdna:47]
•Blue Planet Automation Software and Services segment revenue remained relatively unchanged.

[0000936395-22-000065:mdna:48]
•Global Services segment revenue increased by $12.0 million, primarily reflecting sales increases of $17.0 million of our consulting and network design services and $9.0 million of our maintenance support and training, partially offset by a sales decrease of $14.0 million of our installation and deployment services. Installation and deployment services were adversely impacted by the current constrained supply environment, which resulted in delayed delivery of

[0000936395-22-000065:mdna:49]
Converged Packet Optical products for which installation and deployment services were ordered by customers, as described in more detail in “Overview” above.

[0000936395-22-000065:mdna:50]
Revenue by Geographic Region

[0000936395-22-000065:mdna:51]
Our operating segments engage in business and operations across three geographic regions: Americas; EMEA and APAC. The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our Americas region revenue for fiscal 2022 was primarily driven by increased sales in the United States partially offset by decreased sales in Brazil. The decrease in our EMEA region revenue for fiscal 2022 was primarily driven by decreased sales in the Netherlands, France and Russia. Our Russia operations were suspended in March 2022. The increase in our APAC region revenue for fiscal 2022 was primarily driven by increased sales in India and Australia, partially offset by decreased sales in Japan. The following table reflects our geographic distribution of revenue, which is principally based on the relevant location for our delivery of products and performance of services. The table below sets forth the changes in geographic distribution of revenue for the periods indicated (in thousands, except percentage data):

[0000936395-22-000065:mdna:52]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Americas | $ | 2,636,840 |  |  | 72.6 |  | $ | 2,525,619 |  |  | 69.8 |  | $ | 111,221 |  |  | 4.4 |
| EMEA | 555,215 |  |  | 15.3 |  | 670,462 |  |  | 18.5 |  | (115,247) |  |  | (17.2) |
| APAC | 440,606 |  |  | 12.1 |  | 424,603 |  |  | 11.7 |  | 16,003 |  |  | 3.8 |
| Total | $ | 3,632,661 |  |  | 100.0 |  | $ | 3,620,684 |  |  | 100.0 |  | $ | 11,977 |  |  | 0.3 |

[0000936395-22-000065:mdna:53]
_________________________________

[0000936395-22-000065:mdna:54]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:55]
•Americas revenue increased by $111.2 million, reflecting sales increases of $47.1 million within our Networking Platforms segment, $33.2 million within our Platform Software and Services segment, $25.5 million within our Global Services segment, and $5.4 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $130.5 million of Routing and Switching products, partially offset by product line sales decreases of $83.3 million of Converged Packet Optical products. Routing and Switching product line sales reflect $86.1 million of our Virtualization Edge software, and a sales increase of $53.6 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to communications service providers. Our Converged Packet Optical revenue decrease primarily reflects sales decreases of $89.9 million of our 6500 Packet-Optical Platform, primarily to communications service providers and Web-scale providers, and $25.5 million of our 5400 family of Packet-Optical Platforms and $23.5 million of our Z-Series Packet-Optical Platform, primarily to communications service providers. These sales decreases were partially offset by sales increases of $49.6 million of our 6500 RLS products, primarily to Web-Scale providers.

[0000936395-22-000065:mdna:56]
•EMEA revenue decreased by $115.2 million, reflecting sales decreases of $107.7 million within our Networking Platforms segment, $14.2 million within our Global Services segment and $4.4 million within our Blue Planet Automation Software and Services segment. These sales decreases were offset by a sales increase of $11.1 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects product line sales decreases of $110.8 million of Converged Packet Optical products, primarily reflecting sales decreases of $65.5 million of our 6500 Packet-Optical Platform, primarily to communications service providers and Web-scale providers, and $59.2 million of our Waveserver modular interconnect system primarily to Web-scale providers. Sales decreased by $13.8 million from customers in Russia.

[0000936395-22-000065:mdna:57]
•APAC revenue increased by $16.0 million, primarily reflecting sales increases of $13.7 million within our Networking Platforms segment and $3.3 million within our Platform Software and Services segment, partially offset by sales decreases of $1.7 million within our Blue Planet Automation Software and Services segment. Our Networking Platforms segment revenue increase reflects product line sales increases of $20.5 million of Converged Packet Optical products, primarily reflecting sales increases of $26.4 million of our 6500 Packet-Optical Platform, primarily to enterprise customers and communications service providers.

[0000936395-22-000065:mdna:58]
In fiscal 2022 and fiscal 2021, our top ten customers contributed 56.3% and 55.5% of our revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting the businesses of those customers. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Sales to AT&T were $433.4 million, or 11.9% of total revenue, in fiscal 2022, and $447.4 million, or 12.4% of total revenue, in fiscal 2021. Verizon accounted for $402.8 million, or 11.1% of total revenue, in fiscal 2022. No other customer accounted for greater than 10% of our revenue in fiscal 2022 or fiscal 2021.

[0000936395-22-000065:mdna:59]
While drivers of bandwidth growth and network evolution remain strong, many of our network operator customers are under pressure to constrain their capital expenditure budgets, and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or add features, there is a market expectation for solutions that are more cost-effective than existing or competing solutions and that new products consistently deliver lower price per bit performance. The combination of this regular technology-driven price compression, price competition in our markets and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-22-000065:mdna:60]
Cost of Goods Sold and Gross Profit

[0000936395-22-000065:mdna:61]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-22-000065:mdna:62]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-22-000065:mdna:63]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive annual product cost reductions relative to the price erosion that we regularly encounter in our markets. This can be challenging, particularly within the current constrained supply environment. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to customers as they add capacity and need to monitor their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-22-000065:mdna:64]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-22-000065:mdna:65]
In fiscal 2021, we recorded Canada Emergency Wage Subsidy (“CEWS”) benefits of $7.0 million, net of certain fees, related to the particular line item within costs of goods sold in our Consolidated Statements of Operations to which the grant activity related. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-22-000065:mdna:66]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 3,632,661 |  |  | 100.0 |  | $ | 3,620,684 |  |  | 100.0 |  | $ | 11,977 |  |  | 0.3 |
| Total cost of goods sold | 2,072,317 |  |  | 57.0 |  | 1,898,705 |  |  | 52.4 |  | 173,612 |  |  | 9.1 |
| Gross profit | $ | 1,560,344 |  |  | 43.0 |  | $ | 1,721,979 |  |  | 47.6 |  | $ | (161,635) |  |  | (9.4) |

[0000936395-22-000065:mdna:67]
_________________________________

[0000936395-22-000065:mdna:68]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:69]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,888,848 |  |  | 100.0 |  | $ | 2,932,602 |  |  | 100.0 |  | $ | (43,754) |  |  | (1.5) |
| Product cost of goods sold | 1,699,631 |  |  | 58.8 |  | 1,545,269 |  |  | 52.7 |  | 154,362 |  |  | 10.0 |
| Product gross profit | $ | 1,189,217 |  |  | 41.2 |  | $ | 1,387,333 |  |  | 47.3 |  | $ | (198,116) |  |  | (14.3) |

[0000936395-22-000065:mdna:70]
_________________________________

[0000936395-22-000065:mdna:71]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:72]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Services revenue | $ | 743,813 |  |  | 100.0 |  | $ | 688,082 |  |  | 100.0 |  | $ | 55,731 |  |  | 8.1 |
| Services cost of goods sold | 372,686 |  |  | 50.1 |  | 353,436 |  |  | 51.4 |  | 19,250 |  |  | 5.4 |
| Services gross profit | $ | 371,127 |  |  | 49.9 |  | $ | 334,646 |  |  | 48.6 |  | $ | 36,481 |  |  | 10.9 |

[0000936395-22-000065:mdna:73]
_________________________________

[0000936395-22-000065:mdna:74]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:75]
•Gross profit decreased by $161.6 million. Gross margin decreased by 460 basis points, primarily due to increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix, slightly offset by a larger percentage of higher margin services revenue. As described in “Overview” above, we expect the current constrained supply environment, including the current market shortage for semiconductor components, to increase our costs of goods sold and to adversely impact our gross margin during fiscal 2023.

[0000936395-22-000065:mdna:76]
•Gross profit on products decreased by $198.1 million. Product gross margin decreased by 610 basis points, primarily due to increased costs of components resulting from global supply chain shortages and a higher concentration of lower margin product mix.

[0000936395-22-000065:mdna:77]
•Gross profit on services increased by $36.5 million. Service gross margin increased by 130 basis points, primarily due to higher revenues with relatively lower incremental costs on all services.

[0000936395-22-000065:mdna:78]
Operating Expense

[0000936395-22-000065:mdna:79]
Currency Fluctuations

[0000936395-22-000065:mdna:80]
During fiscal 2022, approximately 50.0% of our operating expense was non-U.S. Dollar denominated, including Canadian Dollars, Indian Rupees, and Euros. During fiscal 2022 as compared to fiscal 2021, the U.S. Dollar primarily strengthened against these and other currencies. Consequently, our operating expense reported in U.S. Dollars decreased by approximately $25.5 million, or 1.9%, net of hedging.

[0000936395-22-000065:mdna:81]
CEWS Program Benefits

[0000936395-22-000065:mdna:82]
In fiscal 2021, we recorded CEWS benefits of $34.3 million, net of certain fees, related to the particular line item within operating expense in our Consolidated Statements of Operations to which the grant activity related. The CEWS program expired in fiscal 2021. For further information relating to our receipt of amounts under the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-22-000065:mdna:83]
Operating expense increased in fiscal 2022 from the level reported for fiscal 2021 primarily due to increases in employee headcount and variable compensation costs related to sales commissions, the expiration of the CEWS program, and increases in travel and entertainment costs, partially offset by decreases in employee variable compensation costs related to lower costs associated with our annual cash incentive compensation plan. We have also experienced, and are continuing to experience, increases in the cost of labor and other costs of doing business due to inflation, and continued inflationary pressures could have an adverse impact on our profitability. We expect operating expense to continue to increase from the level reported in fiscal 2022 primarily due to planned investment in research and development to advance our strategy and higher employee compensation costs.

[0000936395-22-000065:mdna:84]
Operating expense consists of the component elements described below.

[0000936395-22-000065:mdna:85]
•Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs.

[0000936395-22-000065:mdna:86]
•Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs.

[0000936395-22-000065:mdna:87]
•General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services.

[0000936395-22-000065:mdna:88]
•Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions, the redesign of certain business processes and significant impairments of assets.

[0000936395-22-000065:mdna:89]
•Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions.

[0000936395-22-000065:mdna:90]
•Acquisition and integration costs primarily consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition activity. For more information on our acquisitions, see Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-22-000065:mdna:91]
The table below sets forth the changes in operating expense for the periods indicated (in thousands, except percentage data):

[0000936395-22-000065:mdna:92]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 624,656 |  |  | 17.2 |  | $ | 536,666 |  |  | 14.8 |  | $ | 87,990 |  |  | 16.4 |
| Selling and marketing | 466,565 |  |  | 12.9 |  | 452,214 |  |  | 12.5 |  | 14,351 |  |  | 3.2 |
| General and administrative | 179,382 |  |  | 4.9 |  | 181,874 |  |  | 5.0 |  | (2,492) |  |  | (1.4) |
| Significant asset impairments and restructuring costs | 33,824 |  |  | 0.9 |  | 29,565 |  |  | 0.8 |  | 4,259 |  |  | 14.4 |
| Amortization of intangible assets | 32,511 |  |  | 0.9 |  | 23,732 |  |  | 0.7 |  | 8,779 |  |  | 37.0 |
| Acquisition and integration costs | 598 |  |  | — |  | 2,572 |  |  | 0.1 |  | (1,974) |  |  | (76.7) |
| Total operating expenses | $ | 1,337,536 |  |  | 36.8 |  | $ | 1,226,623 |  |  | 33.9 |  | $ | 110,913 |  |  | 9.0 |

[0000936395-22-000065:mdna:93]
_________________________________

[0000936395-22-000065:mdna:94]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:95]
•Research and development expense benefited from $13.5 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, net of hedging, research and development expenses increased by $88.0 million. This increase primarily reflects the effect of a $29.5 million benefit received from the now-expired CEWS program recorded in fiscal 2021 and increases in employee headcount and related compensation costs and professional services, partially offset by lower costs associated with our annual cash incentive compensation plan.

[0000936395-22-000065:mdna:96]
•Selling and marketing expense benefited from $9.6 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro and Australian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased by $14.4 million. This increase primarily reflects an increase in travel and entertainment costs, employee headcount and compensation costs related to sales commission, partially offset by lower costs associated with our annual cash incentive compensation plan.

[0000936395-22-000065:mdna:97]
•General and administrative expense benefited from $2.4 million as a result of foreign exchange rates, primarily due to a stronger U.S. Dollar in relation to the Euro. Including the effect of foreign exchange rates, general and administrative expense decreased by $2.5 million. This decrease primarily reflects decreases in employee-related compensation costs primarily related to lower costs associated with our annual cash incentive compensation plan and legal fees, offset by increased professional services.

[0000936395-22-000065:mdna:98]
•Significant asset impairments and restructuring costs increased by $4.3 million, reflecting alignment of our global workforce and facilities and a $3.8 million impairment charge due to our suspended operations in Russia, partially offset by reduced costs associated with actions that we have taken to redesign certain business processes as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-22-000065:mdna:99]
•Amortization of intangible assets increased by $8.8 million due to additional intangibles acquired in connection with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic during the second quarter of fiscal 2022.

[0000936395-22-000065:mdna:100]
•Acquisition and integration costs primarily consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs, associated with our acquisition of Vyatta during the first quarter of fiscal 2022 and our acquisition of Xelic during the second quarter of fiscal 2022.

[0000936395-22-000065:mdna:101]
Other Items

[0000936395-22-000065:mdna:102]
The table below sets forth the changes in other items for the periods indicated (in thousands, except percentage data):

[0000936395-22-000065:mdna:103]
|  | Fiscal Year |  |  |  |  |
|  | 2022 |  | %* |  | 2021 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | 6,747 |  |  | 0.2 |  | $ | (1,768) |  |  | — |  | $ | 8,515 |  |  | 481.6 |
| Interest expense | $ | (47,050) |  |  | (1.3) |  | $ | (30,837) |  |  | (0.9) |  | $ | 16,213 |  |  | 52.6 |
| Provision (benefit) for income taxes | $ | 29,603 |  |  | 0.8 |  | $ | (37,445) |  |  | (1.0) |  | $ | 67,048 |  |  | 179.1 |

[0000936395-22-000065:mdna:104]
_________________________________

[0000936395-22-000065:mdna:105]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:106]
•Interest and other income (loss), net increased, primarily reflecting higher interest income and the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-22-000065:mdna:107]
•Interest expense increased, primarily due to additional outstanding indebtedness, including the 2030 Notes, and increased interest on the unhedged portion of the 2025 Term Loan (as defined below) interest.

[0000936395-22-000065:mdna:108]
•Provision (benefit) for income taxes increased due to the tax benefit associated with recording a deferred tax asset in fiscal 2021. The effective tax rate for fiscal 2022 was higher than the effective tax rate for fiscal 2021, primarily due to the tax benefit associated with recording a deferred tax asset in fiscal 2021.

[0000936395-22-000065:mdna:109]
Segment Profit (Loss)

[0000936395-22-000065:mdna:110]
The table below sets forth the changes in our segment profit (loss) for the respective periods (in thousands, except percentage data):

[0000936395-22-000065:mdna:111]
|  | Fiscal Year |  |  |
|  | 2022 |  | 2021 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 572,305 |  |  | $ | 850,901 |  |  | $ | (278,596) |  |  | (32.7) |
| Platform Software and Services | $ | 175,108 |  |  | $ | 136,602 |  |  | $ | 38,506 |  |  | 28.2 |
| Blue Planet Automation Software and Services | $ | (22,388) |  |  | $ | (711) |  |  | $ | (21,677) |  |  | (3,048.8) |
| Global Services | $ | 210,663 |  |  | $ | 198,521 |  |  | $ | 12,142 |  |  | 6.1 |

[0000936395-22-000065:mdna:112]
_________________________________

[0000936395-22-000065:mdna:113]
| * | Denotes % change from 2021 to 2022 |

[0000936395-22-000065:mdna:114]
Segment profit (loss) includes CEWS benefits of $36.5 million in fiscal 2021, net of certain fees. For further discussion of benefits from the CEWS program, see Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-22-000065:mdna:115]
•Networking Platforms segment profit decreased by $278.6 million, primarily due to lower gross margin as described above, higher research and development costs, including the effect of a $30.4 million benefit received from the now-expired CEWS program recorded in fiscal 2021 and lower sales volume.

[0000936395-22-000065:mdna:116]
•Platform Software and Services segment profit increased by $38.5 million, primarily due to higher sales volume, as described above.

[0000936395-22-000065:mdna:117]
•Blue Planet Automation Software and Services segment loss increased by $21.7 million, which reflects lower software sales volume, reduced gross margin on software-related services, and higher research and development costs including the effect of a $1.2 million benefit received from the now-expired CEWS program recorded in fiscal 2021.

[0000936395-22-000065:mdna:118]
•Global Services segment profit increased by $12.1 million, primarily due to higher sales volume and higher gross margin as described above, partially offset by the effect of a $2.3 million benefit received from the now-expired CEWS program recorded in fiscal 2021.

[0000936395-22-000065:mdna:119]
Liquidity and Capital Resources

[0000936395-22-000065:mdna:120]
Overview. For the fiscal year ended October 29, 2022, we used $167.8 million of cash from operations, as our working capital requirements of $572.1 million exceeded our net income (adjusted for non-cash charges) of $404.3 million. For additional details on our cash used in operating activities, see the discussion below under the caption “Cash Used in Operating Activities.”

[0000936395-22-000065:mdna:121]
Cash, cash equivalents and investments decreased by $490.3 million during fiscal 2022. In addition to the cash used in operations above, the following items also contributed to the decrease in cash: (i) cash used to fund our investing activities for capital expenditures totaling $90.8 million; (ii) cash used for stock repurchase under our stock repurchase program of $500.8 million; (iii) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $48.5 million; (iv) cash used for acquisition of businesses of $62.0 million, net of cash acquired; (v) cash used for payments on our term loan due September 28, 2025 (the “2025 Term Loan”) of $5.2 million; (vi) purchase of a cost method equity investment of $8.0 million; and (vii) net decreases due to the impact of exchange rate changes on cash and cash equivalents of $26.2 million. Proceeds from the issuance of the 2030 Notes provided $394.5 million in cash, net of paid debt issuance costs, while the issuance of equity under our employee stock purchase plans provided $30.3 million in cash during fiscal 2022.

[0000936395-22-000065:mdna:122]
See Notes 4, 19, and 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-22-000065:mdna:123]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-22-000065:mdna:124]
|  | October 29, 2022 |  | October 30, 2021 |  | Increase (decrease) |
| Cash and cash equivalents | $ | 994,352 |  |  | $ | 1,422,546 |  |  | $ | (428,194) |  |
| Short-term investments in marketable debt securities | 153,989 |  |  | 181,483 |  |  | (27,494) |  |
| Long-term investments in marketable debt securities | 35,385 |  |  | 70,038 |  |  | (34,653) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,183,726 |  |  | $ | 1,674,067 |  |  | $ | (490,341) |  |

[0000936395-22-000065:mdna:125]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of October 29, 2022 totaled $1.18 billion, as well as the senior secured asset-based revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility, which we and certain of our subsidiaries entered into on October 28, 2019, replaced a predecessor senior secured asset-based revolving credit facility and provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 29, 2022, letters of credit totaling $85.6 million were outstanding under our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 29, 2022.

[0000936395-22-000065:mdna:126]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $280.1 million as of October 29, 2022. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $33.0 million. See Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-22-000065:mdna:127]
Stock Repurchase Authorization. On December 9, 2021, we announced that our Board of Directors authorized a program to repurchase up to $1.0 billion of our common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2019. On December 13, 2021, in connection with this repurchase program, we entered into the ASR Agreement for the repurchase of $250.0 million of our common stock. We made an upfront payment of $250.0 million under the ASR Agreement during the first quarter of fiscal 2022, and the repurchases contemplated by the ASR Agreement were completed on February 15, 2022. During fiscal 2022, we repurchased an additional $250.0 million of our common stock under the stock repurchase program, and we had $500.0 million remaining under the current repurchase authorization as of October 29, 2022. The amount and timing of any further repurchases under our stock repurchase program are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. See Note 22 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-22-000065:mdna:128]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our currently anticipated working capital needs, capital expenditures, and other liquidity requirements associated with our operations through the next 12 months and the reasonably foreseeable future. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We have historically been successful in our ability to secure such sources of financing, however, our access to these sources of capital could be materially and adversely impacted and we may not be able to receive terms as favorable as we have historically received, whether due to inflation or otherwise. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility.

[0000936395-22-000065:mdna:129]
Cash Used in Operating Activities

[0000936395-22-000065:mdna:130]
The following sections set forth the components of our $167.8 million of cash used in operating activities for fiscal 2022:

[0000936395-22-000065:mdna:131]
Net Income (adjusted for non-cash charges)

[0000936395-22-000065:mdna:132]
The following table sets forth our net income (adjusted for non-cash charges) during fiscal 2022 (in thousands):

[0000936395-22-000065:mdna:133]
|  | Year Ended |
|  | October 29, 2022 |
| Net income | $ | 152,902 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 95,922 |  |
| Share-based compensation costs | 105,131 |  |
| Amortization of intangible assets | 44,281 |  |
| Deferred taxes | (27,502) |  |
| Provision for inventory excess and obsolescence | 16,184 |  |
| Provision for warranty | 17,440 |  |
| Net income (adjusted for non-cash charges) | $ | 404,358 |  |

[0000936395-22-000065:mdna:134]
Working Capital

[0000936395-22-000065:mdna:135]
We used $572.1 million of cash for working capital during fiscal 2022. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-22-000065:mdna:136]
|  | Year Ended |
|  | October 29, 2022 |
| Cash used in accounts receivable | $ | (47,069) |  |
| Cash used in inventories | (589,113) |  |
| Cash used in prepaid expenses and other | (58,996) |  |
| Cash provided by accounts payable, accruals and other obligations | 100,327 |  |
| Cash provided by deferred revenue | 26,380 |  |
| Cash used in operating lease assets and liabilities, net | (3,643) |  |
| Total cash used for working capital | $ | (572,114) |  |

[0000936395-22-000065:mdna:137]
As compared to the end of fiscal 2021:

[0000936395-22-000065:mdna:138]
•The $47.1 million of cash used in accounts receivable during fiscal 2022 primarily reflects increased sales volume at the end of the fourth quarter of fiscal 2022;

[0000936395-22-000065:mdna:139]
•The $589.1 million of cash used in inventory during fiscal 2022 primarily reflects increases in raw materials inventory related to the steps we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-22-000065:mdna:140]
•The $59.0 million of cash used in prepaid expenses and other during fiscal 2022 primarily reflects increases in contract assets and capitalized commissions, partially offset by decreases in prepaid foreign currency forward contracts and lower prepaid value added taxes;

[0000936395-22-000065:mdna:141]
•The $100.3 million of cash provided by accounts payable, accruals and other obligations during fiscal 2022 primarily reflects the timing of payments for inventory purchases partially offset by a lower accrual rate related to Ciena’s 2022 annual cash incentive compensation plan;

[0000936395-22-000065:mdna:142]
•The $26.4 million of cash provided by deferred revenue during fiscal 2022 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-22-000065:mdna:143]
•The $3.6 million of cash used in operating lease assets and liabilities, net, during fiscal 2022 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-22-000065:mdna:144]
Our days sales outstanding (“DSOs”) were 107 for fiscal 2022, as compared to 98 for fiscal 2021. The calculation of DSOs includes accounts receivable, net and contract assets for unbilled receivables, net included in prepaid expenses and other. Our inventory turns decreased from 4.1 during fiscal 2021 to 1.8 during fiscal 2022 due to the increases in inventory as described in “Overview” above.

[0000936395-22-000065:mdna:145]
Cash Paid for Interest

[0000936395-22-000065:mdna:146]
The following table sets forth the cash paid for interest during fiscal 2022 (in thousands):

[0000936395-22-000065:mdna:147]
|  | Year Ended |
|  | October 29, 2022 |
| Term Loan due September 28, 2025(1) | $ | 20,393 |  |
| Interest rate swaps(2) | 6,873 |  |
| ABL Credit Facilities(3) | 2,368 |  |
| Senior Notes due January 31, 2030(4) | 8,578 |  |
| Finance leases | 4,600 |  |
| Cash paid during period | $ | 42,812 |  |

[0000936395-22-000065:mdna:148]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at the London Interbank Offered Rate (“LIBOR”) for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of fiscal 2022, the interest rate on the 2025 Term Loan was 5.24%.

[0000936395-22-000065:mdna:149]
(2) The interest rate swaps fix the floating rate for $350.0 million of the 2025 Term Loan at 2.957% through September 2023, and at 2.968% for the period from October 2023 through September 2025.

[0000936395-22-000065:mdna:150]
(3) During fiscal 2022, we utilized the ABL Credit Facility and its predecessor to collateralize certain standby letters of credit and paid $2.4 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-22-000065:mdna:151]
(4)The 2030 Notes bear interest at a rate of 4.00% per annum and mature on January 31, 2030. Interest is payable on the 2030 Notes in arrears on January 31 and July 31 of each year.

[0000936395-22-000065:mdna:152]
For additional information about the 2025 Term Loan, 2030 Notes, ABL Credit Facility and interest rate swaps, see Notes 16, 19 and 20 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-22-000065:mdna:153]
Contractual Obligations

[0000936395-22-000065:mdna:154]
Debt. As of October 29, 2022, we had $675.7 million outstanding principal associated with our 2025 Term Loan, with $6.9 million payable within 12 months. Interest on the 2025 Term Loan and payments due under the interest rate swaps is variable and is calculated using the rate in effect on the balance sheet date. Future interest payments associated with the 2025 Term Loan Notes total $103.9 million, with $35.7 million payable within 12 months. As of October 29, 2022, we had $400.0 million outstanding principal associated with the 2030 Notes payable January 31, 2030. Future interest payments associated with the 2030 Notes total $120.0 million, with $16.0 million payable within 12 months. Future interest payments associated with the interest rate swaps total $5.4 million, with $1.9 million payable within 12 months. For additional information about our term loan and the interest rate swaps, see Notes 16 and 19 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-22-000065:mdna:155]
Purchase Order Obligations. As of October 29, 2022, we had $2.6 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of this amount relates to firm, non-cancelable and unconditional obligations.

[0000936395-22-000065:mdna:156]
Leases. We have lease arrangements for facilities including research and development centers, engineering facilities and smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. As of October 29, 2022, we had fixed lease payment obligations of $145.5 million, with $28.2 million payable within 12 months. See Note 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-22-000065:mdna:157]
Off-Balance Sheet Arrangements

[0000936395-22-000065:mdna:158]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-22-000065:mdna:159]
Critical Accounting Policies and Estimates

[0000936395-22-000065:mdna:160]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-22-000065:mdna:161]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-22-000065:mdna:162]
Revenue Recognition

[0000936395-22-000065:mdna:163]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-22-000065:mdna:164]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-22-000065:mdna:165]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-22-000065:mdna:166]
Our total deferred revenue for products was $19.8 million and $12.9 million as of October 29, 2022 and October 30, 2021, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $180.4 million and $162.6 million as of October 29, 2022 and October 30, 2021, respectively.

[0000936395-22-000065:mdna:167]
Business Combinations

[0000936395-22-000065:mdna:168]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital,

[0000936395-22-000065:mdna:169]
and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur that may affect the accuracy or validity of such estimates. During fiscal 2020, we completed the acquisition of Centina Systems, Inc. (“Centina”) for a purchase price of $34.0 million. During fiscal 2022, we completed the acquisitions of Vyatta and Xelic for an aggregate purchase price of $64.1 million. See Note 4 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions.

[0000936395-22-000065:mdna:170]
Share-Based Compensation

[0000936395-22-000065:mdna:171]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-22-000065:mdna:172]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 24 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 29, 2022, total unrecognized compensation expense was $185.7 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.51 years.

[0000936395-22-000065:mdna:173]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-22-000065:mdna:174]
Reserve for Inventory Obsolescence

[0000936395-22-000065:mdna:175]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. For fiscal 2022, future demand was calculated primarily based on customer backlog as described in “Overview” above. Generally, our customers may cancel or change their orders with limited advance notice, or they may decide not to accept our products and services, although instances of both cancellation and non-acceptance are rare. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. Beginning in the second half of fiscal 2021, we started placing significant, advanced orders for supply of certain long lead time components to address our expected customer demand for fiscal 2022 and the then-emerging supply chain challenges. Since that time, we have continued to extend the duration of our purchase commitments, or placed non-cancellable, advanced orders with or through suppliers, particularly for long lead time components. As of October 29, 2022, we had $2.6 billion in outstanding purchase order commitments to our contract manufacturers and component suppliers for inventory. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-22-000065:mdna:176]
We recorded charges for excess and obsolete inventory of $16.2 million, $17.9 million and $24.7 million in fiscal 2022, 2021 and 2020, respectively. Our inventory, net of allowance for excess and obsolescence, was $946.7 million and $374.3 million as of October 29, 2022 and October 30, 2021, respectively.

[0000936395-22-000065:mdna:177]
Allowance for Credit Losses for Accounts Receivable and Contract Assets

[0000936395-22-000065:mdna:178]
We estimate our allowances for credit losses using relevant available information from internal and external sources. This information is related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the probability that asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-22-000065:mdna:179]
Probability of default rates is published by third-party credit rating agencies. Adjustments to our exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-22-000065:mdna:180]
Our accounts receivable, net of allowance for credit losses, was $920.8 million and $885.0 million as of October 29, 2022 and October 30, 2021, respectively. Our allowance for credit losses was $11.0 million and $10.9 million as of October 29, 2022 and October 30, 2021, respectively.

[0000936395-22-000065:mdna:181]
Our contract assets for unbilled accounts receivable, net of allowance for credit losses, was $156.0 million and $101.4 million as of October 29, 2022 and October 30, 2021, respectively. Our allowance for credit losses was $0.2 million and $0.1 million as of October 29, 2022 and October 30, 2021, respectively.

[0000936395-22-000065:mdna:182]
Goodwill

[0000936395-22-000065:mdna:183]
Our goodwill was generated from the acquisitions of (i) Cyan, Inc. during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion, Inc. during fiscal 2016, (iii) Packet Design, LLC on July 2, 2018, (iv) DonRiver Holdings, LLC on October 1, 2018, (v) Centina on November 2, 2019, (vi) Vyatta on November 1, 2021, and (vii) Xelic on March 9, 2022. The goodwill from these acquisitions is primarily related to expected economic synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be as of the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-22-000065:mdna:184]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 29, 2022 and October 30, 2021, the goodwill balance was $328.3 million and $311.6 million, respectively. There were no goodwill impairments resulting from our fiscal 2022 and 2021 impairment tests and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-22-000065:mdna:185]
Long-lived Assets

[0000936395-22-000065:mdna:186]
Our long-lived assets include equipment, building, furniture and fixtures, operating right-of-use assets, finite-lived intangible assets and maintenance spares. As of October 29, 2022 and October 30, 2021 these assets totaled $427.2 million and $450.3 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-22-000065:mdna:187]
Deferred Tax Assets

[0000936395-22-000065:mdna:188]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the

[0000936395-22-000065:mdna:189]
periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-22-000065:mdna:190]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The valuation allowance balances at October 29, 2022 and October 30, 2021 were $162.1 million and $159.6 million, respectively. The corresponding net deferred tax assets were $824.0 million and $800.2 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy.

[0000936395-22-000065:mdna:191]
During fiscal 2021, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $119.3 million deferred tax asset with a corresponding tax benefit. The recognition of the deferred tax asset from the internal transfer of the non-U.S. intangible assets requires management to make estimates and assumptions to determine the fair value of the intangible assets transferred and significant judgments in evaluating the application of tax laws in the applicable jurisdictions, including where the deferred tax asset will be recovered. Estimates in valuing the intangible assets include, but are not limited to, internal revenue and expense forecasts, the estimated life of the intangible assets, and discount rates, which are affected by expectations about future market or economic conditions. Although we believe the assumptions and estimates that we have made are reasonable and appropriate, they are based, in part, on historical experience and are inherently uncertain.

[0000936395-22-000065:mdna:192]
For further discussion, see Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-22-000065:mdna:193]
Warranty

[0000936395-22-000065:mdna:194]
Our liability for product warranties, included in accrued liabilities and other short-term obligations, was $45.5 million and $48.0 million as of October 29, 2022 and October 30, 2021, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support customer repairs within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $17.4 million, $17.1 million and $22.4 million for fiscal 2022, 2021 and 2020, respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 15 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-22-000065:mdna:195]
Effects of Recent Accounting Pronouncements

[0000936395-22-000065:mdna:196]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.
