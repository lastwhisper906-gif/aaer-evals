# CIEN 8-K — 0000936395-16-000112 filed 2016-09-01

## item codes, every 8-K on or before 2016-09-07

- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2016-09-07

- none on or before 2016-09-07

## item 2.02 — earnings release, exhibit 99.1

[0000936395-16-000112:8k_2_02:1]
EX-99.1
2
exhibit991-2016q3earningsp.htm
EXHIBIT 99.1

[0000936395-16-000112:8k_2_02:2]
Exhibit

[0000936395-16-000112:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-16-000112:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2016 Financial Results

[0000936395-16-000112:8k_2_02:5]
HANOVER, Md. - September 1, 2016 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal third quarter ended July 31, 2016.

[0000936395-16-000112:8k_2_02:6]
For the fiscal third quarter 2016, Ciena reported revenue of $670.6 million as compared to $602.9 million for the fiscal third quarter 2015.

[0000936395-16-000112:8k_2_02:7]
On the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal third quarter 2016 was $33.5 million, or $0.23 per diluted common share, which compares to a GAAP net income of $23.6 million, or $0.19 per diluted common share, for the fiscal third quarter 2015.

[0000936395-16-000112:8k_2_02:8]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2016 was $67.6 million, or $0.42 per diluted common share, which compares to an adjusted (non-GAAP) net income of $50.7 million, or $0.37 per diluted common share, for the fiscal third quarter 2015.

[0000936395-16-000112:8k_2_02:9]
“We posted strong results on all financial operating metrics in our fiscal third quarter, continuing a trend of consistently improving financial performance and demonstrating the value of having a diversified business to manage through market dynamics,” said Gary B. Smith, president and CEO, Ciena. “Through strategic investments to broaden our portfolio, market application and customer and geographic base, we have positioned Ciena to deliver sustainable long-term growth and increased profitability.”

[0000936395-16-000112:8k_2_02:10]
Fiscal Third Quarter 2016 Performance Summary

[0000936395-16-000112:8k_2_02:11]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-16-000112:8k_2_02:12]
|  |  | GAAP Results |
|  |  | Q3 |  | Q2 |  | Q3 |  | Period Change |
|  |  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 670.6 |  |  | $ | 640.7 |  |  | $ | 602.9 |  |  | 4.7 | % |  | 11.2 | % |
| Gross margin |  | 46.0 | % |  | 44.2 | % |  | 44.8 | % |  | 1.8 | % |  | 1.2 | % |
| Operating expense |  | $ | 251.5 |  |  | $ | 254.9 |  |  | $ | 225.4 |  |  | (1.3 | )% |  | 11.6 | % |
| Operating margin |  | 8.5 | % |  | 4.4 | % |  | 7.4 | % |  | 4.1 | % |  | 1.1 | % |

[0000936395-16-000112:8k_2_02:13]
|  |  | Non-GAAP Results |
|  |  | Q3 |  | Q2 |  | Q3 |  | Period Change |
|  |  | FY 2016 |  | FY 2016 |  | FY 2015 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 670.6 |  |  | $ | 640.7 |  |  | $ | 602.9 |  |  | 4.7 | % |  | 11.2 | % |
| Adj. gross margin |  | 46.8 | % |  | 45.1 | % |  | 45.3 | % |  | 1.7 | % |  | 1.5 | % |
| Adj. operating expense |  | $ | 223.4 |  |  | $ | 222.6 |  |  | $ | 202.1 |  |  | 0.4 | % |  | 10.5 | % |
| Adj. operating margin |  | 13.5 | % |  | 10.3 | % |  | 11.8 | % |  | 3.2 | % |  | 1.7 | % |

[0000936395-16-000112:8k_2_02:14]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-16-000112:8k_2_02:15]
|  |  | Revenue by Segment |
|  |  | Q3 FY 2016 |  | Q2 FY 2016 |  | Q3 FY 2015 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 467.6 |  |  | 69.7 |  | $ | 435.2 |  |  | 67.9 |  | $ | 408.0 |  |  | 67.7 |
| Packet Networking |  | 63.7 |  |  | 9.5 |  | 68.5 |  |  | 10.7 |  | 57.2 |  |  | 9.5 |
| Optical Transport |  | 9.6 |  |  | 1.4 |  | 8.5 |  |  | 1.3 |  | 17.5 |  |  | 2.9 |
| Total Networking Platforms |  | 540.9 |  |  | 80.6 |  | 512.2 |  |  | 79.9 |  | 482.7 |  |  | 80.1 |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms |  | 12.6 |  |  | 1.9 |  | 11.8 |  |  | 1.9 |  | 11.2 |  |  | 1.9 |
| Software-Related Services |  | 19.0 |  |  | 2.8 |  | 18.7 |  |  | 2.9 |  | 15.3 |  |  | 2.5 |
| Total Software and Software-Related Services |  | 31.6 |  |  | 4.7 |  | 30.5 |  |  | 4.8 |  | 26.5 |  |  | 4.4 |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 56.0 |  |  | 8.4 |  | 57.1 |  |  | 8.9 |  | 59.9 |  |  | 9.9 |
| Installation and Deployment |  | 31.2 |  |  | 4.7 |  | 30.2 |  |  | 4.7 |  | 25.2 |  |  | 4.2 |
| Consulting and Network Design |  | 10.9 |  |  | 1.6 |  | 10.7 |  |  | 1.7 |  | 8.6 |  |  | 1.4 |
| Total Global Services |  | 98.1 |  |  | 14.7 |  | 98.0 |  |  | 15.3 |  | 93.7 |  |  | 15.5 |
| Total |  | $ | 670.6 |  |  | 100.0 |  | $ | 640.7 |  |  | 100.0 |  | $ | 602.9 |  |  | 100.0 |

[0000936395-16-000112:8k_2_02:16]
Additional Performance Metrics for Fiscal Third Quarter 2016

[0000936395-16-000112:8k_2_02:17]
|  |  | Revenue by Geographic Region |
|  |  | Q3 FY 2016 |  | Q2 FY 2016 |  | Q3 FY 2015 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 438.0 |  |  | 65.3 |  | $ | 395.5 |  |  | 61.7 |  | $ | 389.6 |  |  | 64.6 |
| Europe, Middle East and Africa |  | 104.3 |  |  | 15.5 |  | 96.2 |  |  | 15.0 |  | 93.2 |  |  | 15.5 |
| Caribbean and Latin America |  | 46.6 |  |  | 7.0 |  | 57.9 |  |  | 9.0 |  | 65.1 |  |  | 10.8 |
| Asia Pacific |  | 81.7 |  |  | 12.2 |  | 91.1 |  |  | 14.3 |  | 55.0 |  |  | 9.1 |
| Total |  | $ | 670.6 |  |  | 100.0 |  | $ | 640.7 |  |  | 100.0 |  | $ | 602.9 |  |  | 100.0 |

[0000936395-16-000112:8k_2_02:18]
**  Denotes %  of total revenue

[0000936395-16-000112:8k_2_02:19]
| • | U.S. customers contributed 61.1% of total revenue |

[0000936395-16-000112:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 16% of total revenue |

[0000936395-16-000112:8k_2_02:21]
| • | Cash and investments totaled $1.27 billion |

[0000936395-16-000112:8k_2_02:22]
| • | Cash flow from operations totaled $77.1 million |

[0000936395-16-000112:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 79 |

[0000936395-16-000112:8k_2_02:24]
| • | Accounts receivable balance was $588.4 million |

[0000936395-16-000112:8k_2_02:25]
| • | Inventories totaled $221.6 million, including: |

[0000936395-16-000112:8k_2_02:26]
| ◦ | Raw materials: $45.6 million |

[0000936395-16-000112:8k_2_02:27]
| ◦ | Work in process: $13.8 million |

[0000936395-16-000112:8k_2_02:28]
| ◦ | Finished goods: $158.8 million |

[0000936395-16-000112:8k_2_02:29]
| ◦ | Deferred cost of sales: $67.2 million |

[0000936395-16-000112:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(63.8) million |

[0000936395-16-000112:8k_2_02:31]
| • | Product inventory turns were 5.4 |

[0000936395-16-000112:8k_2_02:32]
| • | Headcount totaled 5,559 |

[0000936395-16-000112:8k_2_02:33]
Business Outlook for Fiscal Fourth Quarter 2016

[0000936395-16-000112:8k_2_02:34]
Ciena expects fiscal fourth quarter 2016 financial performance to include:

[0000936395-16-000112:8k_2_02:35]
| • | Revenue in the range of $700 to $730 million |

[0000936395-16-000112:8k_2_02:36]
| • | Adjusted (non-GAAP) gross margin in the mid-40s percentage range |

[0000936395-16-000112:8k_2_02:37]
| • | Adjusted (non-GAAP) operating expense of approximately $230 to $235 million |

[0000936395-16-000112:8k_2_02:38]
Live Web Broadcast of Unaudited Fiscal Third Quarter 2016 Results

[0000936395-16-000112:8k_2_02:39]
Ciena will host a discussion of its unaudited fiscal third quarter 2016 results with investors and financial analysts today, Thursday, September 1, 2016 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-16-000112:8k_2_02:40]
Notes to Investors

[0000936395-16-000112:8k_2_02:41]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: “We posted strong results on all financial operating metrics in our fiscal third quarter, continuing a trend of consistently improving financial performance and demonstrating the value of having a diversified business to manage through market dynamics."; "Through strategic investments to broaden our portfolio, market application and customer and geographic base, we have positioned Ciena to deliver sustainable long-term growth and increased profitability."; "Ciena expects fiscal fourth quarter 2016 financial performance to include: Revenue in the range of $700 to $730 million; Adjusted (non-GAAP) gross margin in the mid-40s percentage range; Adjusted (non-GAAP) operating expense of approximately $230 to $235 million."

[0000936395-16-000112:8k_2_02:42]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on June 8, 2016. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-16-000112:8k_2_02:43]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-16-000112:8k_2_02:44]
With respect to Ciena’s expectations under “Business Outlook for Fiscal Fourth Quarter 2016” above, Ciena is not able to provide a quantitative reconciliation of the adjusted (non-GAAP) gross margin and adjusted (non-GAAP) operating expense guidance measures to the corresponding gross profit and gross profit percentage, and operating expense GAAP measures without unreasonable efforts. Ciena cannot provide meaningful estimates of the non-recurring charges and credits excluded from these non-GAAP measures due to the forward-looking nature of these estimates and their inherent variability and uncertainty.  For the same reasons, Ciena is unable to address the probable significance of the unavailable information.

[0000936395-16-000112:8k_2_02:45]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn.

[0000936395-16-000112:8k_2_02:46]
CIENA CORPORATION

[0000936395-16-000112:8k_2_02:47]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-16-000112:8k_2_02:48]
(in thousands, except per share data)

[0000936395-16-000112:8k_2_02:49]
(unaudited)

[0000936395-16-000112:8k_2_02:50]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 553,450 |  |  | $ | 493,919 |  |  | $ | 1,535,017 |  |  | $ | 1,428,114 |  |
| Services | 117,100 |  |  | 109,013 |  |  | 349,365 |  |  | 325,582 |  |
| Total revenue | 670,550 |  |  | 602,932 |  |  | 1,884,382 |  |  | 1,753,696 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 299,381 |  |  | 273,837 |  |  | 851,641 |  |  | 797,283 |  |
| Services | 62,684 |  |  | 59,226 |  |  | 189,713 |  |  | 183,838 |  |
| Total cost of goods sold | 362,065 |  |  | 333,063 |  |  | 1,041,354 |  |  | 981,121 |  |
| Gross profit | 308,485 |  |  | 269,869 |  |  | 843,028 |  |  | 772,575 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 116,697 |  |  | 100,379 |  |  | 339,346 |  |  | 306,342 |  |
| Selling and marketing | 83,732 |  |  | 81,650 |  |  | 252,878 |  |  | 240,833 |  |
| General and administrative | 34,336 |  |  | 29,743 |  |  | 100,681 |  |  | 89,598 |  |
| Acquisition and integration costs | 1,029 |  |  | 2,435 |  |  | 4,613 |  |  | 3,455 |  |
| Amortization of intangible assets | 14,529 |  |  | 11,019 |  |  | 46,957 |  |  | 33,057 |  |
| Restructuring costs | 1,138 |  |  | 192 |  |  | 2,057 |  |  | 8,260 |  |
| Total operating expenses | 251,461 |  |  | 225,418 |  |  | 746,532 |  |  | 681,545 |  |
| Income from operations | 57,024 |  |  | 44,451 |  |  | 96,496 |  |  | 91,030 |  |
| Interest and other income (loss), net | (3,647 | ) |  | (5,491 | ) |  | (11,456 | ) |  | (19,273 | ) |
| Interest expense | (15,967 | ) |  | (11,883 | ) |  | (41,285 | ) |  | (38,491 | ) |
| Income before income taxes | 37,410 |  |  | 27,077 |  |  | 43,755 |  |  | 33,266 |  |
| Provision for income taxes | 3,864 |  |  | 3,452 |  |  | 7,758 |  |  | 7,767 |  |
| Net income | $ | 33,546 |  |  | $ | 23,625 |  |  | $ | 35,997 |  |  | $ | 25,499 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.26 |  |  | $ | 0.23 |  |
| Diluted net income per potential common share1 | $ | 0.23 |  |  | $ | 0.19 |  |  | $ | 0.26 |  |  | $ | 0.22 |  |
| Weighted average basic common shares outstanding | 138,881 |  |  | 118,413 |  |  | 137,835 |  |  | 113,189 |  |
| Weighted average dilutive potential common shares outstanding2 | 169,349 |  |  | 133,233 |  |  | 139,053 |  |  | 114,549 |  |

[0000936395-16-000112:8k_2_02:51]
| 1. | The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2016 requires adding back interest expense of approximately $1.3 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 and approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation. |

[0000936395-16-000112:8k_2_02:52]
The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-16-000112:8k_2_02:53]
| 2. | Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2016 includes 0.9 million shares underlying certain stock options and restricted stock units, 12.2 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017 and 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018. |

[0000936395-16-000112:8k_2_02:54]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2016 includes 1.2 million shares underlying certain stock options and restricted stock units.

[0000936395-16-000112:8k_2_02:55]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-16-000112:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2015 includes 1.4 million shares underlying certain stock options and restricted stock units.

[0000936395-16-000112:8k_2_02:57]
CIENA CORPORATION

[0000936395-16-000112:8k_2_02:58]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-16-000112:8k_2_02:59]
(in thousands, except share data)

[0000936395-16-000112:8k_2_02:60]
(unaudited)

[0000936395-16-000112:8k_2_02:61]
|  | July 31, 2016 |  | October 31, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 854,918 |  |  | $ | 790,971 |  |
| Short-term investments | 295,322 |  |  | 135,107 |  |
| Accounts receivable, net | 588,389 |  |  | 550,792 |  |
| Inventories | 221,598 |  |  | 191,162 |  |
| Prepaid expenses and other | 189,947 |  |  | 196,178 |  |
| Total current assets | 2,150,174 |  |  | 1,864,210 |  |
| Long-term investments | 115,366 |  |  | 95,105 |  |
| Equipment, building, furniture and fixtures, net | 272,955 |  |  | 191,973 |  |
| Goodwill | 267,261 |  |  | 256,434 |  |
| Other intangible assets, net | 165,169 |  |  | 202,673 |  |
| Other long-term assets | 72,733 |  |  | 84,656 |  |
| Total assets | $ | 3,043,658 |  |  | $ | 2,695,051 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 232,736 |  |  | $ | 222,140 |  |
| Accrued liabilities | 297,123 |  |  | 316,283 |  |
| Deferred revenue | 117,952 |  |  | 126,111 |  |
| Current portion of long-term debt | 455,465 |  |  | 2,500 |  |
| Total current liabilities | 1,103,276 |  |  | 667,034 |  |
| Long-term deferred revenue | 70,287 |  |  | 62,962 |  |
| Other long-term obligations | 122,852 |  |  | 72,540 |  |
| Long-term debt, net | 1,025,684 |  |  | 1,271,639 |  |
| Total liabilities | $2,322,099 |  | $2,074,175 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 139,253,617 and 135,612,217 shares issued and outstanding | 1,393 |  |  | 1,356 |  |
| Additional paid-in capital | 6,704,349 |  |  | 6,640,436 |  |
| Accumulated other comprehensive loss | (21,390 | ) |  | (22,126 | ) |
| Accumulated deficit | (5,962,793 | ) |  | (5,998,790 | ) |
| Total stockholders’ equity | 721,559 |  |  | 620,876 |  |
| Total liabilities and stockholders’ equity | $ | 3,043,658 |  |  | $ | 2,695,051 |  |

[0000936395-16-000112:8k_2_02:62]
CIENA CORPORATION

[0000936395-16-000112:8k_2_02:63]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-16-000112:8k_2_02:64]
(in thousands)

[0000936395-16-000112:8k_2_02:65]
(unaudited)

[0000936395-16-000112:8k_2_02:66]
|  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 35,997 |  |  | $ | 25,499 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 46,624 |  |  | 41,601 |  |
| Share-based compensation costs | 41,832 |  |  | 32,402 |  |
| Amortization of intangible assets | 59,428 |  |  | 39,659 |  |
| Provision for inventory excess and obsolescence | 26,663 |  |  | 18,010 |  |
| Provision for warranty | 13,114 |  |  | 12,549 |  |
| Other | 15,706 |  |  | 17,818 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (37,768 | ) |  | (33,362 | ) |
| Inventories | (56,267 | ) |  | 40,372 |  |
| Prepaid expenses and other | 16,687 |  |  | (24,297 | ) |
| Accounts payable, accruals and other obligations | (5,087 | ) |  | (21,937 | ) |
| Deferred revenue | (4,120 | ) |  | 29,170 |  |
| Net cash provided by operating activities | 152,809 |  |  | 177,484 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (81,161 | ) |  | (39,729 | ) |
| Restricted cash | — |  |  | (42 | ) |
| Purchase of available for sale securities | (340,168 | ) |  | (180,203 | ) |
| Proceeds from maturities of available for sale securities | 160,606 |  |  | 140,000 |  |
| Settlement of foreign currency forward contracts, net | (9,982 | ) |  | 16,289 |  |
| Acquisition of business, net of cash acquired | (32,000 | ) |  | — |  |
| Purchase of cost method investment | — |  |  | (2,000 | ) |
| Net cash used in investing activities | (302,705 | ) |  | (65,685 | ) |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | 248,750 |  |  | — |  |
| Payment of long term debt | (45,990 | ) |  | (8,901 | ) |
| Payment of debt issuance costs | (3,980 | ) |  | (420 | ) |
| Payment of capital lease obligations | (5,359 | ) |  | (6,441 | ) |
| Proceeds from issuance of common stock | 22,118 |  |  | 19,622 |  |
| Net cash provided by financing activities | 215,539 |  |  | 3,860 |  |
| Effect of exchange rate changes on cash and cash equivalents | (1,696 | ) |  | (5,288 | ) |
| Net increase in cash and cash equivalents | 63,947 |  |  | 110,371 |  |
| Cash and cash equivalents at beginning of period | 790,971 |  |  | 586,720 |  |
| Cash and cash equivalents at end of period | $ | 854,918 |  |  | $ | 697,091 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 31,787 |  |  | $ | 31,566 |  |
| Cash paid during the period for income taxes, net | $ | 9,947 |  |  | $ | 8,526 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 10,204 |  |  | $ | 16,717 |  |
| Equipment acquired under capital lease | $ | 5,322 |  |  | $ | 464 |  |
| Building subject to capital lease | $ | 8,993 |  |  | $ | 14,939 |  |
| Construction in progress subject to build-to-suit lease | $ | 35,875 |  |  | $ | 8,770 |  |
| Non-cash financing activities |  |  |  |
| Conversion of 4.0% convertible senior notes, due March 15, 2015 into 8,898,387 shares of common stock | — |  |  | 180,645 |  |

[0000936395-16-000112:8k_2_02:67]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |  |  |
|  |  | Quarter Ended July 31, |
|  |  | 2016 |  | 2015 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 308,485 |  |  | $ | 269,869 |  |
| Share-based compensation-products |  | 645 |  |  | 671 |  |
| Share-based compensation-services |  | 637 |  |  | 490 |  |
| Amortization of intangible assets |  | 4,328 |  |  | 2,200 |  |
| Total adjustments related to gross profit |  | 5,610 |  |  | 3,361 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 314,095 |  |  | $ | 273,230 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 46.8 | % |  | 45.3 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 251,461 |  |  | $ | 225,418 |  |
| Share-based compensation-research and development |  | 3,479 |  |  | 2,114 |  |
| Share-based compensation-sales and marketing |  | 3,590 |  |  | 3,571 |  |
| Share-based compensation-general and administrative |  | 4,284 |  |  | 3,516 |  |
| Acquisition and integration costs |  | 1,029 |  |  | 2,435 |  |
| Amortization of intangible assets |  | 14,529 |  |  | 11,019 |  |
| Restructuring costs |  | 1,138 |  |  | 192 |  |
| Settlement of patent litigation |  | — |  |  | 500 |  |
| Total adjustments related to operating expense |  | 28,049 |  |  | 23,347 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 223,412 |  |  | $ | 202,071 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 57,024 |  |  | $ | 44,451 |  |
| Total adjustments related to gross profit |  | 5,610 |  |  | 3,361 |  |
| Total adjustments related to operating expense |  | 28,049 |  |  | 23,347 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 90,683 |  |  | $ | 71,159 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.5 | % |  | 11.8 | % |
| Net Income Reconciliation |  |  |  |  |
| GAAP net income |  | $ | 33,546 |  |  | $ | 23,625 |  |
| Total adjustments related to gross profit |  | 5,610 |  |  | 3,361 |  |
| Total adjustments related to operating expense |  | 28,049 |  |  | 23,347 |  |
| Gain on extinguishment of debt |  | (44 | ) |  | — |  |
| Non-cash interest expense |  | 480 |  |  | 397 |  |
| Adjusted (non-GAAP) net income |  | $ | 67,641 |  |  | $ | 50,730 |  |
| Weighted average basic common shares outstanding |  | 138,881 |  |  | 118,413 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 178,547 |  |  | 159,787 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.23 |  |  | $ | 0.19 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.42 |  |  | $ | 0.37 |  |

[0000936395-16-000112:8k_2_02:68]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2016 includes 0.9 million shares underlying certain stock options and restricted stock units, 12.2 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020. |

[0000936395-16-000112:8k_2_02:69]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units, 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-16-000112:8k_2_02:70]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2016 requires adding back interest expense of approximately $1.3 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.9 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-16-000112:8k_2_02:71]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-16-000112:8k_2_02:72]
* * *

[0000936395-16-000112:8k_2_02:73]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-16-000112:8k_2_02:74]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-16-000112:8k_2_02:75]
| • | Acquisition and integration costs - consist of expenses for financial, legal and accounting advisors and severance and other employee related costs, associated with our acquisition of Cyan, Inc. on August 3, 2015 and our acquisition of certain high-speed photonic component assets from TeraXion, Inc. on February 1, 2016. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-16-000112:8k_2_02:76]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-16-000112:8k_2_02:77]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-16-000112:8k_2_02:78]
| • | Settlement of patent litigation - included in general and administrative expense is a $0.5 million patent litigation settlement during the third quarter of fiscal 2015. |

[0000936395-16-000112:8k_2_02:79]
| • | Gain on extinguishment of debt - a gain related to certain private repurchases conducted with several holders of Ciena's 0.875% convertible senior notes, due June 15, 2017. |

[0000936395-16-000112:8k_2_02:80]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |
