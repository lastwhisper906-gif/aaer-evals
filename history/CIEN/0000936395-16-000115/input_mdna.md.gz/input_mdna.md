# CIEN MD&A — 0000936395-16-000115


## mdna

[0000936395-16-000115:mdna:1]
[same as prior period, unchanged from 0000936395-16-000104:mdna:1]

[0000936395-16-000115:mdna:2]
[same as prior period, unchanged from 0000936395-16-000104:mdna:2]

[0000936395-16-000115:mdna:3]
[same as prior period, unchanged from 0000936395-16-000104:mdna:3]

[0000936395-16-000115:mdna:4]
[same as prior period, unchanged from 0000936395-16-000104:mdna:4]

[0000936395-16-000115:mdna:5]
[same as prior period, unchanged from 0000936395-16-000104:mdna:5]

[0000936395-16-000115:mdna:6]
[same as prior period, unchanged from 0000936395-16-000104:mdna:6]

[0000936395-16-000115:mdna:7]
[same as prior period, unchanged from 0000936395-16-000104:mdna:7]

[0000936395-16-000115:mdna:8]
[same as prior period, unchanged from 0000936395-16-000104:mdna:8]

[0000936395-16-000115:mdna:9]
[same as prior period, unchanged from 0000936395-16-000104:mdna:9]

[0000936395-16-000115:mdna:10]
| • | our ability to diversify our customer base and broaden the application for our solutions in communications networks; |

[0000936395-16-000115:mdna:11]
[same as prior period, unchanged from 0000936395-16-000104:mdna:11]

[0000936395-16-000115:mdna:12]
[same as prior period, unchanged from 0000936395-16-000104:mdna:12]

[0000936395-16-000115:mdna:13]
[same as prior period, unchanged from 0000936395-16-000104:mdna:13]

[0000936395-16-000115:mdna:14]
[same as prior period, unchanged from 0000936395-16-000104:mdna:14]

[0000936395-16-000115:mdna:15]
[same as prior period, unchanged from 0000936395-16-000104:mdna:15]

[0000936395-16-000115:mdna:16]
[same as prior period, unchanged from 0000936395-16-000104:mdna:16]

[0000936395-16-000115:mdna:17]
[same as prior period, unchanged from 0000936395-16-000104:mdna:17]

[0000936395-16-000115:mdna:18]
[same as prior period, unchanged from 0000936395-16-000104:mdna:18]

[0000936395-16-000115:mdna:19]
[same as prior period, unchanged from 0000936395-16-000104:mdna:19]

[0000936395-16-000115:mdna:20]
[same as prior period, unchanged from 0000936395-16-000104:mdna:20]

[0000936395-16-000115:mdna:21]
[same as prior period, unchanged from 0000936395-16-000104:mdna:21]

[0000936395-16-000115:mdna:22]
[same as prior period, unchanged from 0000936395-16-000104:mdna:22]

[0000936395-16-000115:mdna:23]
[same as prior period, unchanged from 0000936395-16-000104:mdna:23]

[0000936395-16-000115:mdna:24]
[same as prior period, unchanged from 0000936395-16-000104:mdna:24]

[0000936395-16-000115:mdna:25]
[same as prior period, unchanged from 0000936395-16-000104:mdna:25]

[0000936395-16-000115:mdna:26]
[same as prior period, unchanged from 0000936395-16-000104:mdna:26]

[0000936395-16-000115:mdna:27]
[same as prior period, unchanged from 0000936395-16-000104:mdna:27]

[0000936395-16-000115:mdna:28]
[same as prior period, unchanged from 0000936395-16-000104:mdna:28]

[0000936395-16-000115:mdna:29]
[same as prior period, unchanged from 0000936395-16-000104:mdna:29]

[0000936395-16-000115:mdna:30]
[same as prior period, unchanged from 0000936395-16-000104:mdna:30]

[0000936395-16-000115:mdna:31]
[same as prior period, unchanged from 0000936395-16-000104:mdna:31]

[0000936395-16-000115:mdna:32]
| • | adverse results in litigation matters. |

[0000936395-16-000115:mdna:33]
[same as prior period, unchanged from 0000936395-16-000104:mdna:33]

[0000936395-16-000115:mdna:34]
We are a network specialist focused on providing solutions that enable a wide range of network operators to adopt next-generation communication architectures. We have optimized our solutions to enable network operators to create and deliver a broad array of high-bandwidth services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. In addition to our high-capacity hardware platforms, we offer network management and control software platforms that help network operators simplify and automate their networks and virtualize certain network functions. Our solutions are designed to enable network operators to adopt open, multi-vendor, software-programmable network infrastructures that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to introduce new, revenue-generating services and to reduce network complexity and expense.

[0000936395-16-000115:mdna:35]
[same as prior period, unchanged from 0000936395-16-000104:mdna:35]

[0000936395-16-000115:mdna:36]
The rapid proliferation of communications services and devices, together with increased mobility and growth in video, cloud-based services and data center interconnect, have fundamentally affected the bandwidth and service demands placed upon communications networks. As the capacity of their network infrastructures is pressured, many network operators also face a rapidly changing business environment and shifting competitive landscape. Newer market entrants, such as cloud service and

[0000936395-16-000115:mdna:37]
[same as prior period, unchanged from 0000936395-16-000104:mdna:37]

[0000936395-16-000115:mdna:38]
over-the-top content providers, are challenging certain traditional business models. Our OPn Architecture, which enables increased network scalability, flexibility and programmability, is designed to meet these challenges. It allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and other network resources. This approach enables highly configurable network infrastructures that can meet the “on-demand” service requirements of both our customers and their end-users. By enhancing software-based management and control, enabling network functions to be provided virtually, and reducing required network elements, our OPn approach optimizes network infrastructures. At the same time, it increases network scale at reduced cost and simplifies the management, deployment and orchestration of multi-vendor hardware and software elements. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the “Strategy” section below.

[0000936395-16-000115:mdna:39]
[same as prior period, unchanged from 0000936395-16-000104:mdna:39]

[0000936395-16-000115:mdna:40]
[same as prior period, unchanged from 0000936395-16-000104:mdna:40]

[0000936395-16-000115:mdna:41]
The market for communications networking solutions has been subject to significant changes in recent years, including rapid growth in network traffic, increased mobility, and evolving cloud-based service offerings and end-user service demands. These changes have placed significant demands on network infrastructures, challenged the business models of our service provider customers, and altered the overall competitive landscape. Network operators are competing to distinguish their service offerings and to rapidly introduce differentiated, revenue-generating services, while at the same time seeking to manage the costs of their networks and to ensure profitable business models. These dynamics are driving the convergence of network features, functions and layers, the virtualization of certain network functions, and the implementation of solutions that leverage increased software-based network control and programmability. We believe that these dynamics are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that network operators and vendors alike will be required to utilize an ecosystem of physical and virtual network resources provided by a variety of third parties, which will further drive increased openness and interoperability of network infrastructures.

[0000936395-16-000115:mdna:42]
In recent periods, certain of our customers, including several of our larger service provider customers in North America and EMEA, have taken steps to constrain their capital expenditure budgets. As a result of this measured spending environment, some of our market segments have been adversely impacted and we have experienced lower spending levels on networking equipment from these customers as compared to prior periods. Notwithstanding these market dynamics, and certain customer-specific factors affecting spending, we continue to experience market growth and have increased our revenue in fiscal 2016, in part as a result of our continued efforts to diversify our business. Specifically, we continue to diversify our customer base to include additional customer segments, such as Web-scale providers, cable and multiservice operators, and additional service providers in geographies including Brazil and India. We have also sought to diversify our business by broadening our solutions portfolio and focusing on certain higher growth applications for our network infrastructure products, including metro networking, data center interconnect and submarine networks.

[0000936395-16-000115:mdna:43]
[same as prior period, unchanged from 0000936395-16-000104:mdna:42]

[0000936395-16-000115:mdna:44]
[same as prior period, unchanged from 0000936395-16-000104:mdna:43]

[0000936395-16-000115:mdna:45]
We compete in markets that are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to displace incumbent vendors and to capture market share. The markets for our solutions are both highly competitive and fragmented. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approaches. We expect the competitive landscape in which we operate to remain challenging and dynamic. As we have expanded our solutions offerings, including with Packet Networking solutions, such as our 8700 Packetwave Platform, and data center interconnect (DCI) solutions, such as our Waveserver DCI platform, our solutions have become increasingly competitive with a new set of competitors — including IP router vendors, data center switch providers, and other suppliers or integrators. In addition, as we seek increased customer adoption of our Blue Planet software platform, and network operator demands for software programmability, management and control increase, we expect to compete more directly with software vendors and information technology vendors or integrators of these solutions. We may

[0000936395-16-000115:mdna:46]
also face competition from system and component vendors, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware; particularly where a customer's network strategy seeks to emphasize deployment of such product offerings or adopt a disaggregated approach to the procurement of hardware and software.  Against both this intense competitive landscape and the market-based price erosion for our products that we regularly encounter, we expect that in order to achieve sustained revenue growth we will be required to continue to increase our volume of product shipments, to continue to diversify our customer base, and to introduce new technology solutions that address bandwidth consumption and evolving service demands.

[0000936395-16-000115:mdna:47]
In addition, in order to maintain incumbency with key customers and to secure new opportunities with a diverse set of network operators, we are often required to agree to aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously, and may in the future, adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also lengthen our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-16-000115:mdna:48]
[same as prior period, unchanged from 0000936395-16-000104:mdna:46]

[0000936395-16-000115:mdna:49]
[same as prior period, unchanged from 0000936395-16-000104:mdna:47]

[0000936395-16-000115:mdna:50]
[same as prior period, unchanged from 0000936395-16-000104:mdna:48]

[0000936395-16-000115:mdna:51]
Extend Technology Leaderships and Expand Application of Our Solutions. Our product development strategy is focused on maintaining our technology leadership and expanding our role in customer networks to support service delivery and additional network applications. Our research and development efforts seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce terabit per second and greater transmission speeds. We are also focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnect and WAN applications. Separately, we are increasing the scale, density and capability of our packet offerings, reducing power and space requirements, and enabling NFV capabilities for applications in metro networks, user aggregation and data center connectivity. We are also focused on increasing software programmability of networks and enabling network operators to automate and accelerate the creation and delivery of new, cloud-based services. These efforts include investments in our Blue Planet software platform — which is designed to automate, orchestrate, and manage physical network resources and virtualized services across data centers and the WAN — and its integration across our portfolio and with additional third party network resources.

[0000936395-16-000115:mdna:52]
Expand our Role and Reach through Go-to-Market Model. To address the industry dynamics described above, we believe that it is important to secure customer relationships with a diverse set of communications service providers and Web-scale providers, as we expect that their purchasing and network decisions will become increasingly interdependent. As such, our go-to-market model is focused on driving sales growth by diversifying our business with existing customers and penetrating additional customer segments and international markets.

[0000936395-16-000115:mdna:53]
Our sales and marketing efforts seek to promote increased sales to existing customers, particularly through opportunities that expand our role or the application of our solutions within their network and business. We are pursuing opportunities to increase adoption of our packet access and aggregation solutions, and to secure market share of our Blue Planet software platform, including within our existing customer base. We are also focused on opportunities to support metro aggregation, data center interconnect, managed services offerings, cloud-based services, submarine networks, business Ethernet services and mobile backhaul. We intend to leverage our existing customer relationships to increase sales and promote the adoption of our solutions as our customers scale and evolve their networks.

[0000936395-16-000115:mdna:54]
[same as prior period, unchanged from 0000936395-16-000104:mdna:52]

[0000936395-16-000115:mdna:55]
Optimize Business to Yield Operating Leverage. We are actively pursuing initiatives to improve our operating margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and supply procurement initiatives to ensure that our product cost model remains ahead of the market-based price erosion that we regularly encounter. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs, reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-16-000115:mdna:56]
Repurchase of Convertible Notes

[0000936395-16-000115:mdna:57]
During fiscal 2016, we have repurchased approximately $248.6 million of the outstanding aggregate principal amount of our 0.875% Convertible Senior Notes due June 15, 2017 (the “2017 Notes”) in private transactions, for cash purchase prices slightly below par. Following these transactions, $245.3 million in aggregate principal amount of the 2017 Notes remain outstanding. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-16-000115:mdna:58]
[same as prior period, unchanged from 0000936395-16-000104:mdna:59]

[0000936395-16-000115:mdna:59]
Revenue for the third quarter of fiscal 2016 was $670.6 million, representing a sequential increase of 4.7% from $640.7 million in the second quarter of fiscal 2016. Revenue for the third and second quarters of fiscal 2016 includes $32.9 million and $24.8 million, respectively, from products and services relating to the business of Cyan, Inc. ("Cyan"), which we acquired on August 3, 2015. Revenue-related details reflecting sequential changes from the second quarter of fiscal 2016 include:

[0000936395-16-000115:mdna:60]
| • | Product revenue for the third quarter of fiscal 2016 increased by $29.5 million, primarily reflecting revenue increases within our Networking Platforms segment, with product line increases of $32.4 million in Converged Packet Optical and $1.2 million in Optical Transport, partially offset by a product line decrease of $4.9 million in Packet Networking. |

[0000936395-16-000115:mdna:61]
| • | Service revenue for the third quarter of fiscal 2016 increased by $0.4 million. |

[0000936395-16-000115:mdna:62]
| • | North America revenue for the third quarter of fiscal 2016 was $438.0 million, an increase from $395.5 million in the second quarter of fiscal 2016. This primarily reflects a revenue increase of $44.6 million within our Networking Platforms segment, partially offset by a decrease of $2.3 million within our Global Services segment. The increase in Networking Platforms reflects a product line increase of $51.9 million in Converged Packet Optical, offset by a product line decrease of $7.3 million in Packet Networking. |

[0000936395-16-000115:mdna:63]
| • | Europe, Middle East and Africa ("EMEA") revenue for the third quarter of fiscal 2016 was $104.3 million, an increase from $96.2 million in the second quarter of fiscal 2016. This primarily reflects an $11.1 million increase within our Networking Platforms segment, partially offset by a decrease of $3.3 million within our Global Services segment. The increase in Networking Platforms reflects product line increases of $7.4 million in Converged Packet Optical, $2.4 million in Packet Networking and $1.3 million in Optical Transport. |

[0000936395-16-000115:mdna:64]
| • | Caribbean and Latin America ("CALA") revenue for the third quarter of fiscal 2016 was $46.6 million, a decrease from $57.9 million in the second quarter of fiscal 2016. This primarily reflects an $18.2 million decrease within our Networking Platforms segment, partially offset by a revenue increase of $6.5 million within our Global Services segment. The decrease in Networking Platforms primarily reflects a product line decrease of $17.0 million in Converged Packet Optical. |

[0000936395-16-000115:mdna:65]
39

[0000936395-16-000115:mdna:66]
| • | Asia Pacific ("APAC") revenue for the third quarter of fiscal 2016 was $81.7 million, a decrease from $91.1 million in the second quarter of fiscal 2016. This primarily reflects an $8.9 million decrease within our Networking Platforms segment, with a product line decrease of $9.8 million in Converged Packet Optical. |

[0000936395-16-000115:mdna:67]
| • | For the third quarter and second quarter of fiscal 2016, AT&T accounted for 15.7% and 18.1% of total revenue, respectively. |

[0000936395-16-000115:mdna:68]
Gross margin for the third quarter of fiscal 2016 was 46.0%, an increase from 44.2% in the second quarter of fiscal 2016. Improved gross margin for the third quarter of fiscal 2016 primarily reflects improved services gross margin and a sequential reduction in our provision for excess and obsolete inventory expense. In recent periods our gross margin has improved as a result of cost reductions in our solutions, improved services margin and, in particular, favorable product mix, including software.

[0000936395-16-000115:mdna:69]
Operating expense was $251.5 million for the third quarter of fiscal 2016, a decrease from $254.9 million in the second quarter of fiscal 2016. Third quarter fiscal 2016 operating expense primarily reflects decreases of $2.9 million in selling and marketing expense and $0.9 million in general and administrative expense, partially offset by an increase of $2.1 million in research and development expense.

[0000936395-16-000115:mdna:70]
Income from operations for the third quarter of fiscal 2016 was $57.0 million, compared to income from operations of $28.2 million during the second quarter of fiscal 2016. Our net income for the third quarter of fiscal 2016 was $33.5 million, or $0.23 per diluted common share, compared to a net income of $14.0 million or $0.10 per diluted common share, for the second quarter of fiscal 2016.

[0000936395-16-000115:mdna:71]
We generated cash from operations of $77.1 million during the third quarter of fiscal 2016, compared to $60.7 million of cash generated from operations during the second quarter of fiscal 2016. As of July 31, 2016, we had $854.9 million in cash and cash equivalents, $295.3 million of short-term investments in U.S. treasury securities and commercial paper and $115.4 million of long-term investments in U.S. treasury securities. This compares to $922.0 million in cash and cash equivalents, $195.2 million of short-term investments in U.S. treasury securities and commercial paper and $125.2 million of long-term investments in U.S. treasury securities, at April 30, 2016.

[0000936395-16-000115:mdna:72]
As of July 31, 2016, we had 5,559 employees, which reflects an increase from 5,345 at October 31, 2015 and an increase from 5,196 at July 31, 2015.

[0000936395-16-000115:mdna:73]
[same as prior period, unchanged from 0000936395-16-000104:mdna:74]

[0000936395-16-000115:mdna:74]
[same as prior period, unchanged from 0000936395-16-000104:mdna:75]

[0000936395-16-000115:mdna:75]
[same as prior period, unchanged from 0000936395-16-000104:mdna:76]

[0000936395-16-000115:mdna:76]
Quarter ended July 31, 2016 compared to the quarter ended July 31, 2015

[0000936395-16-000115:mdna:77]
[same as prior period, unchanged from 0000936395-16-000104:mdna:78]

[0000936395-16-000115:mdna:78]
Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as "book to revenue") has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results.

[0000936395-16-000115:mdna:79]
We expect that our total revenue in fiscal 2016 will be adversely impacted by the strengthening of the U.S. Dollar, particularly against the Canadian Dollar, Euro and Brazilian Real. During the third quarter of fiscal 2016, as compared to the third quarter of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Brazilian Real, in which we have our most significant foreign currency revenue exposure. Our total revenue reported in U.S. dollars during the third quarter of fiscal 2016 was slightly impacted by approximately $2.5 million or 0.4% as compared to the third quarter of fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000115:mdna:80]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 467,615 |  |  | 69.7 |  | $ | 407,970 |  |  | 67.7 |  | $ | 59,645 |  |  | 14.6 |  |
| Packet Networking | 63,658 |  |  | 9.5 |  | 57,209 |  |  | 9.5 |  | 6,449 |  |  | 11.3 |  |
| Optical Transport | 9,619 |  |  | 1.4 |  | 17,482 |  |  | 2.9 |  | (7,863 | ) |  | (45.0 | ) |
| Total Networking Platforms | 540,892 |  |  | 80.6 |  | 482,661 |  |  | 80.1 |  | 58,231 |  |  | 12.1 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 12,558 |  |  | 1.9 |  | 11,258 |  |  | 1.9 |  | 1,300 |  |  | 11.5 |  |
| Software-Related Services | 19,011 |  |  | 2.8 |  | 15,338 |  |  | 2.5 |  | 3,673 |  |  | 23.9 |  |
| Total Software and Software-Related Services | 31,569 |  |  | 4.7 |  | 26,596 |  |  | 4.4 |  | 4,973 |  |  | 18.7 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 55,996 |  |  | 8.4 |  | 59,894 |  |  | 9.9 |  | (3,898 | ) |  | (6.5 | ) |
| Installation and Deployment | 31,245 |  |  | 4.7 |  | 25,161 |  |  | 4.2 |  | 6,084 |  |  | 24.2 |  |
| Consulting and Network Design | 10,848 |  |  | 1.6 |  | 8,620 |  |  | 1.4 |  | 2,228 |  |  | 25.8 |  |
| Total Global Services | 98,089 |  |  | 14.7 |  | 93,675 |  |  | 15.5 |  | 4,414 |  |  | 4.7 |  |
| Consolidated revenue | $ | 670,550 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | 67,618 |  |  | 11.2 |  |

[0000936395-16-000115:mdna:81]
[same as prior period, unchanged from 0000936395-16-000104:mdna:83]

[0000936395-16-000115:mdna:82]
[same as prior period, unchanged from 0000936395-16-000104:mdna:84]

[0000936395-16-000115:mdna:83]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:84]
| • | Networking Platforms segment revenue increased, primarily reflecting increases of $59.6 million in sales of our Converged Packet Optical products and $6.5 million in sales of our Packet Networking products, partially offset by a decrease of $7.9 million in sales of our Optical Transport products. |

[0000936395-16-000115:mdna:85]
| ◦ | Converged Packet Optical sales reflect the addition of $28.3 million in sales relating to the Z-Series Packet-Optical Platform acquired from Cyan. Converged Packet Optical sales also reflect increases of $39.7 million in sales of our 6500 Packet-Optical Platform and $3.9 million in sales of our 5430 Reconfigurable Switching System. These increases within our Converged Packet Optical product line were partially offset by decreases of $9.0 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $3.6 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-16-000115:mdna:86]
| ◦ | Packet Networking sales primarily reflects an increase of $7.8 million in sales of our 3000 family of service delivery switches. |

[0000936395-16-000115:mdna:87]
[same as prior period, unchanged from 0000936395-16-000104:mdna:89]

[0000936395-16-000115:mdna:88]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting increases of $3.7 million in software-related services sales and $1.3 million in sales of our software platforms. The increase in software-related services sales is primarily due to increased sales of software subscription services. The increase in software platform sales reflects $0.9 million in initial sales of our Blue Planet network virtualization, service orchestration and network management software platform. Segment revenue also includes $0.5 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-16-000115:mdna:89]
| • | Global Services segment revenue increased, primarily reflecting increases of $6.1 million in sales of our installation and deployment services and $2.2 million in sales of our consulting and network design services. These increases were |

[0000936395-16-000115:mdna:90]
[same as prior period, unchanged from 0000936395-16-000104:mdna:92]

[0000936395-16-000115:mdna:91]
partially offset by a decrease of $3.9 million in sales of our maintenance support and training. Segment revenue includes $4.1 million in services revenue related to Cyan.

[0000936395-16-000115:mdna:92]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as Brazil and India. We believe that this is an important part of our strategy and required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly from quarter to quarter as a result of the factors described elsewhere in this report including "Risk Factors." Among other things, the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-16-000115:mdna:93]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 438,013 |  |  | 65.3 |  | $ | 389,593 |  |  | 64.6 |  | $ | 48,420 |  |  | 12.4 |  |
| EMEA | 104,266 |  |  | 15.5 |  | 93,168 |  |  | 15.5 |  | 11,098 |  |  | 11.9 |  |
| CALA | 46,606 |  |  | 7.0 |  | 65,152 |  |  | 10.8 |  | (18,546 | ) |  | (28.5 | ) |
| APAC | 81,665 |  |  | 12.2 |  | 55,019 |  |  | 9.1 |  | 26,646 |  |  | 48.4 |  |
| Total | $ | 670,550 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | 67,618 |  |  | 11.2 |  |

[0000936395-16-000115:mdna:94]
[same as prior period, unchanged from 0000936395-16-000104:mdna:95]

[0000936395-16-000115:mdna:95]
[same as prior period, unchanged from 0000936395-16-000104:mdna:96]

[0000936395-16-000115:mdna:96]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:97]
| • | North America revenue primarily reflects increases of $41.7 million within our Networking Platforms segment, $5.0 million within our Software and Software-Related Services segment and $1.7 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects increases of $41.3 million of Converged Packet Optical sales and $6.0 million of Packet Networking sales, partially offset by a decrease of $5.6 million in Optical Transport sales. Converged Packet Optical sales reflect an increase of $15.0 million in sales of our 6500 Packet-Optical Platform due to increased sales to Web-scale providers, communication service providers and enterprise customers, partially offset by decreased sales to AT&T and government-related customers. Converged Packet Optical sales also reflect $25.7 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000115:mdna:98]
| • | EMEA revenue primarily reflects an increase of $14.8 million within our Networking Platform segment, partially offset by revenue decreases of $2.3 million within our Global Services segment and $1.5 million within our Software and Software-Related Services segment. Networking Platform segment revenue reflects a product line increase of $15.4 million in Converged Packet Optical sales, primarily due to increased sales of the 6500 Packet-Optical Platform to certain Web-scale providers. Despite this increase, in recent periods we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000115:mdna:99]
| • | CALA revenue primarily reflects a decrease of $23.6 million within our Networking Platform segment, partially offset by an increase of $4.7 million within our Global Services segment. CALA revenue reflects decreased sales to communication service providers, primarily in Brazil, and submarine network operators. |

[0000936395-16-000115:mdna:100]
| • | APAC revenue primarily reflects increases of $25.3 million within our Networking Platform segment and $1.0 million within our Software and Software-Related Services segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to communication service providers, particularly in India, submarine network operators and sales through our strategic relationship with Ericsson. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-16-000115:mdna:101]
[same as prior period, unchanged from 0000936395-16-000104:mdna:102]

[0000936395-16-000115:mdna:102]
[same as prior period, unchanged from 0000936395-16-000104:mdna:103]

[0000936395-16-000115:mdna:103]
[same as prior period, unchanged from 0000936395-16-000104:mdna:104]

[0000936395-16-000115:mdna:104]
[same as prior period, unchanged from 0000936395-16-000104:mdna:105]

[0000936395-16-000115:mdna:105]
[same as prior period, unchanged from 0000936395-16-000104:mdna:106]

[0000936395-16-000115:mdna:106]
[same as prior period, unchanged from 0000936395-16-000104:mdna:107]

[0000936395-16-000115:mdna:107]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 670,550 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | 67,618 |  |  | 11.2 |
| Total cost of goods sold | 362,065 |  |  | 54.0 |  | 333,063 |  |  | 55.2 |  | 29,002 |  |  | 8.7 |
| Gross profit | $ | 308,485 |  |  | 46.0 |  | $ | 269,869 |  |  | 44.8 |  | $ | 38,616 |  |  | 14.3 |

[0000936395-16-000115:mdna:108]
[same as prior period, unchanged from 0000936395-16-000104:mdna:109]

[0000936395-16-000115:mdna:109]
[same as prior period, unchanged from 0000936395-16-000104:mdna:110]

[0000936395-16-000115:mdna:110]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:111]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 553,450 |  |  | 100.0 |  | $ | 493,919 |  |  | 100.0 |  | $ | 59,531 |  |  | 12.1 |
| Product cost of goods sold | 299,381 |  |  | 54.1 |  | 273,837 |  |  | 55.4 |  | 25,544 |  |  | 9.3 |
| Product gross profit | $ | 254,069 |  |  | 45.9 |  | $ | 220,082 |  |  | 44.6 |  | $ | 33,987 |  |  | 15.4 |

[0000936395-16-000115:mdna:112]
[same as prior period, unchanged from 0000936395-16-000104:mdna:113]

[0000936395-16-000115:mdna:113]
[same as prior period, unchanged from 0000936395-16-000104:mdna:114]

[0000936395-16-000115:mdna:114]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:115]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 117,100 |  |  | 100.0 |  | $ | 109,013 |  |  | 100.0 |  | $ | 8,087 |  |  | 7.4 |
| Service cost of goods sold | 62,684 |  |  | 53.5 |  | 59,226 |  |  | 54.3 |  | 3,458 |  |  | 5.8 |
| Service gross profit | $ | 54,416 |  |  | 46.5 |  | $ | 49,787 |  |  | 45.7 |  | $ | 4,629 |  |  | 9.3 |

[0000936395-16-000115:mdna:116]
[same as prior period, unchanged from 0000936395-16-000104:mdna:117]

[0000936395-16-000115:mdna:117]
[same as prior period, unchanged from 0000936395-16-000104:mdna:118]

[0000936395-16-000115:mdna:118]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:119]
[same as prior period, unchanged from 0000936395-16-000104:mdna:120]

[0000936395-16-000115:mdna:120]
| • | Gross profit on products as a percentage of product revenue increased, as a result of product cost reductions partially offset by the impact of market-based price erosion. |

[0000936395-16-000115:mdna:121]
| • | Gross profit on services as a percentage of services revenue increased, primarily due to increased sales of higher margin software subscription services and improved efficiencies for installation and consulting and network design services. |

[0000936395-16-000115:mdna:122]
[same as prior period, unchanged from 0000936395-16-000104:mdna:123]

[0000936395-16-000115:mdna:123]
[same as prior period, unchanged from 0000936395-16-000104:mdna:124]

[0000936395-16-000115:mdna:124]
[same as prior period, unchanged from 0000936395-16-000104:mdna:125]

[0000936395-16-000115:mdna:125]
[same as prior period, unchanged from 0000936395-16-000104:mdna:126]

[0000936395-16-000115:mdna:126]
[same as prior period, unchanged from 0000936395-16-000104:mdna:127]

[0000936395-16-000115:mdna:127]
[same as prior period, unchanged from 0000936395-16-000104:mdna:128]

[0000936395-16-000115:mdna:128]
[same as prior period, unchanged from 0000936395-16-000104:mdna:129]

[0000936395-16-000115:mdna:129]
[same as prior period, unchanged from 0000936395-16-000104:mdna:130]

[0000936395-16-000115:mdna:130]
[same as prior period, unchanged from 0000936395-16-000104:mdna:131]

[0000936395-16-000115:mdna:131]
[same as prior period, unchanged from 0000936395-16-000104:mdna:132]

[0000936395-16-000115:mdna:132]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 116,697 |  |  | 17.4 |  | $ | 100,379 |  |  | 16.6 |  | $ | 16,318 |  |  | 16.3 |  |
| Selling and marketing | 83,732 |  |  | 12.5 |  | 81,650 |  |  | 13.5 |  | 2,082 |  |  | 2.5 |  |
| General and administrative | 34,336 |  |  | 5.1 |  | 29,743 |  |  | 4.9 |  | 4,593 |  |  | 15.4 |  |
| Acquisition and integration costs | 1,029 |  |  | 0.2 |  | 2,435 |  |  | 0.4 |  | (1,406 | ) |  | (57.7 | ) |
| Amortization of intangible assets | 14,529 |  |  | 2.2 |  | 11,019 |  |  | 1.8 |  | 3,510 |  |  | 31.9 |  |
| Restructuring costs | 1,138 |  |  | 0.2 |  | 192 |  |  | — |  | 946 |  |  | 492.7 |  |
| Total operating expenses | $ | 251,461 |  |  | 37.6 |  | $ | 225,418 |  |  | 37.2 |  | $ | 26,043 |  |  | 11.6 |  |

[0000936395-16-000115:mdna:133]
[same as prior period, unchanged from 0000936395-16-000104:mdna:134]

[0000936395-16-000115:mdna:134]
[same as prior period, unchanged from 0000936395-16-000104:mdna:135]

[0000936395-16-000115:mdna:135]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:136]
| • | Research and development expense benefited $3.0 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $16.3 million. This change reflects increases of $8.0 million in employee and compensation costs, $3.8 million in facilities and information technology costs, $3.1 million in professional services, $1.2 million in depreciation expense and $1.2 million in technology and related costs. These increases were partially offset by a decrease of $1.2 million in prototype expense. |

[0000936395-16-000115:mdna:137]
| • | Selling and marketing expense increased by $2.1 million, primarily reflecting increases of $0.7 million in facilities and information technology costs, $0.5 million in professional services and $0.5 million in employee and compensation costs. |

[0000936395-16-000115:mdna:138]
| • | General and administrative expense increased by $4.6 million, primarily reflecting increases of $2.7 million in employee and compensation costs and $1.0 million for professional services and legal fees. |

[0000936395-16-000115:mdna:139]
[same as prior period, unchanged from 0000936395-16-000104:mdna:140]

[0000936395-16-000115:mdna:140]
[same as prior period, unchanged from 0000936395-16-000104:mdna:141]

[0000936395-16-000115:mdna:141]
[same as prior period, unchanged from 0000936395-16-000104:mdna:142]

[0000936395-16-000115:mdna:142]
[same as prior period, unchanged from 0000936395-16-000104:mdna:143]

[0000936395-16-000115:mdna:143]
[same as prior period, unchanged from 0000936395-16-000104:mdna:144]

[0000936395-16-000115:mdna:144]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (3,647 | ) |  | (0.5 | ) |  | $ | (5,491 | ) |  | (0.9 | ) |  | $ | 1,844 |  |  | 33.6 |
| Interest expense | $ | 15,967 |  |  | 2.4 |  |  | $ | 11,883 |  |  | 2.0 |  |  | $ | 4,084 |  |  | 34.4 |
| Provision for income taxes | $ | 3,864 |  |  | 0.6 |  |  | $ | 3,452 |  |  | 0.6 |  |  | $ | 412 |  |  | 11.9 |

[0000936395-16-000115:mdna:145]
[same as prior period, unchanged from 0000936395-16-000104:mdna:146]

[0000936395-16-000115:mdna:146]
[same as prior period, unchanged from 0000936395-16-000104:mdna:147]

[0000936395-16-000115:mdna:147]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:148]
| • | Interest and other income (loss), net primarily reflects an increase in investment interest income. |

[0000936395-16-000115:mdna:149]
| • | Interest expense increased primarily due to the 2021 Term Loan that was entered into in the second quarter of fiscal 2016. For additional information about our term loans, see Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-16-000115:mdna:150]
| • | Provision for income taxes increased primarily due to state tax expense in the United States. |

[0000936395-16-000115:mdna:151]
Nine months ended July 31, 2016 compared to the nine months ended July 31, 2015

[0000936395-16-000115:mdna:152]
[same as prior period, unchanged from 0000936395-16-000104:mdna:153]

[0000936395-16-000115:mdna:153]
During the first nine months of fiscal 2016, as compared to the first nine months of fiscal 2015, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar, Euro, and Brazilian Real in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars was adversely impacted by approximately $18.0 million or 0.9% as compared to the first nine months of fiscal 2015. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-16-000115:mdna:154]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,291,956 |  |  | 68.6 |  | $ | 1,177,441 |  |  | 67.2 |  | $ | 114,515 |  |  | 9.7 |  |
| Packet Networking | 180,437 |  |  | 9.6 |  | 165,480 |  |  | 9.4 |  | 14,957 |  |  | 9.0 |  |
| Optical Transport | 30,215 |  |  | 1.6 |  | 56,275 |  |  | 3.2 |  | (26,060 | ) |  | (46.3 | ) |
| Total Networking Platforms | 1,502,608 |  |  | 79.8 |  | 1,399,196 |  |  | 79.8 |  | 103,412 |  |  | 7.4 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 32,409 |  |  | 1.7 |  | 28,918 |  |  | 1.6 |  | 3,491 |  |  | 12.1 |  |
| Software-Related Services | 55,059 |  |  | 2.9 |  | 45,119 |  |  | 2.6 |  | 9,940 |  |  | 22.0 |  |
| Total Software and Software-Related Services | 87,468 |  |  | 4.6 |  | 74,037 |  |  | 4.2 |  | 13,431 |  |  | 18.1 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 169,123 |  |  | 9.0 |  | 166,880 |  |  | 9.5 |  | 2,243 |  |  | 1.3 |  |
| Installation and Deployment | 92,317 |  |  | 4.9 |  | 82,045 |  |  | 4.7 |  | 10,272 |  |  | 12.5 |  |
| Consulting and Network Design | 32,866 |  |  | 1.7 |  | 31,538 |  |  | 1.8 |  | 1,328 |  |  | 4.2 |  |
| Total Global Services | 294,306 |  |  | 15.6 |  | 280,463 |  |  | 16.0 |  | 13,843 |  |  | 4.9 |  |
| Consolidated revenue | $ | 1,884,382 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 130,686 |  |  | 7.5 |  |

[0000936395-16-000115:mdna:155]
[same as prior period, unchanged from 0000936395-16-000104:mdna:156]

[0000936395-16-000115:mdna:156]
[same as prior period, unchanged from 0000936395-16-000104:mdna:157]

[0000936395-16-000115:mdna:157]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:158]
| • | Networking Platforms segment revenue increased, primarily reflecting sales increases of $114.5 million in our Converged Packet Optical products and $15.0 million of Packet Networking products, partially offset by a decrease of $26.1 million in sales of our Optical Transport products. |

[0000936395-16-000115:mdna:159]
| ◦ | Converged Packet Optical sales reflect increases of $52.0 million of our 6500 Packet-Optical Platform, $2.0 million of our 5430 Reconfigurable Switching System and $1.5 million of our Waveserver stackable interconnect system. Increased sales from Converged Packet Optical also reflects the addition of $82.4 million in sales relating to the Z-Series Packet-Optical Platform acquired from Cyan. The 6500 Packet-Optical Platform increase is primarily due to increased sales to Web-scale providers, enterprise customers and sales through our strategic relationship with Ericsson partially offset by decreases in sales of our 6500 Packet-Optical Platform to AT&T and cable and multiservice operators. These increases within our Converged Packet Optical product line were partially offset by decreases of $16.7 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System and $6.8 million in sales of our CoreDirector® Multiservice Optical Switches. |

[0000936395-16-000115:mdna:160]
[same as prior period, unchanged from 0000936395-16-000104:mdna:162]

[0000936395-16-000115:mdna:161]
| ◦ | Packet Networking sales reflect increases of $10.5 million in sales of our 3000 family of service delivery switches and $7.1 million in sales of our 8700 Packetwave Platform, partially offset by a decrease of $2.1 million in sales of our 5410 Service Aggregation Switch. |

[0000936395-16-000115:mdna:162]
[same as prior period, unchanged from 0000936395-16-000104:mdna:163]

[0000936395-16-000115:mdna:163]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting increases of $9.9 million in software-related services sales and $3.5 million in sales of our software platforms. The increase in software-related services sales is primarily due to increased sales of software subscription services. The increase in software platform sales reflects $3.2 million in initial sales of our Blue Planet network virtualization, service orchestration and network management software platform. Segment revenue also includes $1.4 million in sales of Planet Operate software acquired from Cyan. |

[0000936395-16-000115:mdna:164]
| • | Global Services segment revenue increased, primarily reflecting increases of $10.3 million in sales of our installation and deployment services, $2.2 million in sales of our maintenance and support services and $1.3 million in sales of our consulting and network design services. Global Services segment revenue includes $14.3 million of services revenue acquired from Cyan. |

[0000936395-16-000115:mdna:165]
[same as prior period, unchanged from 0000936395-16-000104:mdna:166]

[0000936395-16-000115:mdna:166]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,226,222 |  |  | 65.1 |  | $ | 1,118,309 |  |  | 63.7 |  | $ | 107,913 |  |  | 9.6 |  |
| EMEA | 281,163 |  |  | 14.9 |  | 306,368 |  |  | 17.5 |  | (25,205 | ) |  | (8.2 | ) |
| CALA | 148,312 |  |  | 7.9 |  | 155,785 |  |  | 8.9 |  | (7,473 | ) |  | (4.8 | ) |
| APAC | 228,685 |  |  | 12.1 |  | 173,234 |  |  | 9.9 |  | 55,451 |  |  | 32.0 |  |
| Total | $ | 1,884,382 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 130,686 |  |  | 7.5 |  |

[0000936395-16-000115:mdna:167]
[same as prior period, unchanged from 0000936395-16-000104:mdna:168]

[0000936395-16-000115:mdna:168]
[same as prior period, unchanged from 0000936395-16-000104:mdna:169]

[0000936395-16-000115:mdna:169]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:170]
| • | North America revenue primarily reflects increases of $84.6 million within our Networking Platforms segment, $13.2 million within our Software and Software-Related Services segment and $10.1 million within our Global Services segment. The revenue increase within our Networking Platforms segment primarily reflects increases of $93.9 million of Converged Packet Optical sales and $4.0 million of Packet Networking sales partially offset by a decrease of $13.3 million in Optical Transport sales. Converged Packet Optical sales reflect an increase of $27.3 million in sales of our 6500 Packet-Optical Platform, which reflects increased sales to Web-scale providers, communication service providers and enterprise customers, partially offset by reduced sales to AT&T, cable and multiservice operators and government customers. Converged Packet Optical sales also include $71.9 million of sales for our Z-Series Packet-Optical Platform acquired from Cyan. |

[0000936395-16-000115:mdna:171]
| • | EMEA revenue primarily reflects a decrease of $24.4 million within our Networking Platform segment. Networking Platform segment revenue reflects a product line decrease of $18.6 million in Converged Packet Optical sales, primarily for the 6500 Packet-Optical Platform. In recent periods, we have seen certain of our large service provider customers in EMEA take steps to constrain their capital expenditure budgets. This measured spending environment, together with macroeconomic conditions, has adversely impacted the spending levels we have experienced from certain customers in this region as compared to prior periods. |

[0000936395-16-000115:mdna:172]
| • | CALA revenue primarily reflects a decrease of $11.6 million within our Networking Platform segment, partially offset by an increase of $4.4 million within our Global Services segment. CALA revenue reflects decreased sales to certain communication service providers, primarily in Brazil, partially offset by higher sales AT&T in Mexico. |

[0000936395-16-000115:mdna:173]
| • | APAC revenue primarily reflects an increase of $54.8 million within our Networking Platform segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to certain communications service providers, particularly in India, enterprise customers, submarine network |

[0000936395-16-000115:mdna:174]
operators and sales through our strategic partnership with Ericsson. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter.

[0000936395-16-000115:mdna:175]
[same as prior period, unchanged from 0000936395-16-000104:mdna:175]

[0000936395-16-000115:mdna:176]
[same as prior period, unchanged from 0000936395-16-000104:mdna:176]

[0000936395-16-000115:mdna:177]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,884,382 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 130,686 |  |  | 7.5 |
| Total cost of goods sold | 1,041,354 |  |  | 55.3 |  | 981,121 |  |  | 55.9 |  | 60,233 |  |  | 6.1 |
| Gross profit | $ | 843,028 |  |  | 44.7 |  | $ | 772,575 |  |  | 44.1 |  | $ | 70,453 |  |  | 9.1 |

[0000936395-16-000115:mdna:178]
[same as prior period, unchanged from 0000936395-16-000104:mdna:178]

[0000936395-16-000115:mdna:179]
[same as prior period, unchanged from 0000936395-16-000104:mdna:179]

[0000936395-16-000115:mdna:180]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:181]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,535,017 |  |  | 100.0 |  | $ | 1,428,114 |  |  | 100.0 |  | $ | 106,903 |  |  | 7.5 |
| Product cost of goods sold | 851,641 |  |  | 55.5 |  | 797,283 |  |  | 55.8 |  | 54,358 |  |  | 6.8 |
| Product gross profit | $ | 683,376 |  |  | 44.5 |  | $ | 630,831 |  |  | 44.2 |  | $ | 52,545 |  |  | 8.3 |

[0000936395-16-000115:mdna:182]
[same as prior period, unchanged from 0000936395-16-000104:mdna:182]

[0000936395-16-000115:mdna:183]
[same as prior period, unchanged from 0000936395-16-000104:mdna:183]

[0000936395-16-000115:mdna:184]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:185]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 349,365 |  |  | 100.0 |  | $ | 325,582 |  |  | 100.0 |  | $ | 23,783 |  |  | 7.3 |
| Service cost of goods sold | 189,713 |  |  | 54.3 |  | 183,838 |  |  | 56.5 |  | 5,875 |  |  | 3.2 |
| Service gross profit | $ | 159,652 |  |  | 45.7 |  | $ | 141,744 |  |  | 43.5 |  | $ | 17,908 |  |  | 12.6 |

[0000936395-16-000115:mdna:186]
[same as prior period, unchanged from 0000936395-16-000104:mdna:186]

[0000936395-16-000115:mdna:187]
[same as prior period, unchanged from 0000936395-16-000104:mdna:187]

[0000936395-16-000115:mdna:188]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:189]
[same as prior period, unchanged from 0000936395-16-000104:mdna:189]

[0000936395-16-000115:mdna:190]
| • | Gross profit on products as a percentage of product revenue increased as a result of product cost reductions, higher software revenue and improved manufacturing efficiencies partially offset by market-based price erosion and an increased provision for excess and obsolete inventory expense. |

[0000936395-16-000115:mdna:191]
| • | Gross profit on services as a percentage of services revenue increased primarily due to increased sales of higher margin software subscription services and reduced repair costs to support maintenance service contracts and improved margin on installation consulting services. |

[0000936395-16-000115:mdna:192]
[same as prior period, unchanged from 0000936395-16-000104:mdna:192]

[0000936395-16-000115:mdna:193]
[same as prior period, unchanged from 0000936395-16-000104:mdna:193]

[0000936395-16-000115:mdna:194]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 339,346 |  |  | 18.0 |  | $ | 306,342 |  |  | 17.5 |  | $ | 33,004 |  |  | 10.8 |  |
| Selling and marketing | 252,878 |  |  | 13.4 |  | 240,833 |  |  | 13.7 |  | 12,045 |  |  | 5.0 |  |
| General and administrative | 100,681 |  |  | 5.3 |  | 89,598 |  |  | 5.1 |  | 11,083 |  |  | 12.4 |  |
| Acquisition and integration costs | 4,613 |  |  | 0.2 |  | 3,455 |  |  | 0.2 |  | 1,158 |  |  | 33.5 |  |
| Amortization of intangible assets | 46,957 |  |  | 2.5 |  | 33,057 |  |  | 1.9 |  | 13,900 |  |  | 42.0 |  |
| Restructuring costs | 2,057 |  |  | 0.1 |  | 8,260 |  |  | 0.5 |  | (6,203 | ) |  | (75.1 | ) |
| Total operating expenses | $ | 746,532 |  |  | 39.6 |  | $ | 681,545 |  |  | 38.9 |  | $ | 64,987 |  |  | 9.5 |  |

[0000936395-16-000115:mdna:195]
[same as prior period, unchanged from 0000936395-16-000104:mdna:195]

[0000936395-16-000115:mdna:196]
[same as prior period, unchanged from 0000936395-16-000104:mdna:196]

[0000936395-16-000115:mdna:197]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:198]
| • | Research and development expense benefited $16.6 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $33.0 million. This change reflects increases of $18.8 million in employee and compensation costs, $8.0 million in facilities and information technology costs, $4.9 million in professional services, $3.0 million in depreciation expense and $1.3 million in technology and related costs. Research and development expense for fiscal 2016 also reflects a $1.7 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario, due to the maximum funding limit being met in the second quarter of fiscal 2015. These increases were partially offset by a decrease of $5.5 million in prototype expense. |

[0000936395-16-000115:mdna:199]
| • | Selling and marketing expense benefited $5.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro, Canadian Dollar and Brazilian Real. Including the effect of foreign exchange rates, selling and marketing expense increased by $12.0 million, primarily reflecting increases of $8.1 million in employee and compensation costs, $2.6 million in professional services, $2.1 million in facilities and information technology costs and $1.3 million in travel and related costs. These increases were partially offset by a decrease of $2.1 million in trade shows and related costs. |

[0000936395-16-000115:mdna:200]
| • | General and administrative expense benefited $1.8 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Brazilian Real, Canadian Dollar and Euro. Including the effect of foreign exchange rates, general and administrative expense increased by $11.1 million, primarily due to increases of $7.9 million for employee and compensation costs, $1.3 million for professional services and $1.1 million for facilities and information technology costs. |

[0000936395-16-000115:mdna:201]
[same as prior period, unchanged from 0000936395-16-000104:mdna:201]

[0000936395-16-000115:mdna:202]
[same as prior period, unchanged from 0000936395-16-000104:mdna:202]

[0000936395-16-000115:mdna:203]
[same as prior period, unchanged from 0000936395-16-000104:mdna:203]

[0000936395-16-000115:mdna:204]
[same as prior period, unchanged from 0000936395-16-000104:mdna:204]

[0000936395-16-000115:mdna:205]
[same as prior period, unchanged from 0000936395-16-000104:mdna:205]

[0000936395-16-000115:mdna:206]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2016 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (11,456 | ) |  | (0.6 | ) |  | $ | (19,273 | ) |  | (1.1 | ) |  | $ | 7,817 |  |  | 40.6 |  |
| Interest expense | $ | 41,285 |  |  | 2.2 |  |  | $ | 38,491 |  |  | 2.2 |  |  | $ | 2,794 |  |  | 7.3 |  |
| Provision for income taxes | $ | 7,758 |  |  | 0.4 |  |  | $ | 7,767 |  |  | 0.4 |  |  | $ | (9 | ) |  | (0.1 | ) |

[0000936395-16-000115:mdna:207]
[same as prior period, unchanged from 0000936395-16-000104:mdna:207]

[0000936395-16-000115:mdna:208]
[same as prior period, unchanged from 0000936395-16-000104:mdna:208]

[0000936395-16-000115:mdna:209]
**    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:210]
| • | Interest and other income (loss), net reflects the improved impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. Interest and other income (loss), net also reflects an increase in investment interest income. |

[0000936395-16-000115:mdna:211]
| • | Interest expense increased, primarily due to the 2021 Term Loan that was entered into in the second quarter of fiscal 2016. For additional information about our term loans, see Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-16-000115:mdna:212]
| • | Provision for income taxes remained relatively unchanged. |

[0000936395-16-000115:mdna:213]
[same as prior period, unchanged from 0000936395-16-000104:mdna:213]

[0000936395-16-000115:mdna:214]
[same as prior period, unchanged from 0000936395-16-000104:mdna:214]

[0000936395-16-000115:mdna:215]
|  | Quarter Ended July 31, |  |  |  |
|  | 2016 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 150,521 |  |  | $ | 128,664 |  |  | $ | 21,857 |  |  | 17.0 |  |
| Software and Software-Related Services | $ | 2,412 |  |  | $ | 3,926 |  |  | $ | (1,514 | ) |  | (38.6 | ) |
| Global Services | $ | 38,855 |  |  | $ | 36,900 |  |  | $ | 1,955 |  |  | 5.3 |  |

[0000936395-16-000115:mdna:216]
[same as prior period, unchanged from 0000936395-16-000104:mdna:216]

[0000936395-16-000115:mdna:217]
*    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:218]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin partially offset by higher research and development costs. The improved gross margin was the result of product cost reductions, including innovation on our WaveLogic coherent optical processor for 100G and 200G optical transport, partially offset by market-based price erosion. |

[0000936395-16-000115:mdna:219]
[same as prior period, unchanged from 0000936395-16-000104:mdna:219]

[0000936395-16-000115:mdna:220]
| • | Global Services segment profit increased, primarily due to higher sales volume, as described above, and improved gross margin. The improved gross margin was the result of improved efficiencies for installation and consulting and network design services. |

[0000936395-16-000115:mdna:221]
[same as prior period, unchanged from 0000936395-16-000104:mdna:221]

[0000936395-16-000115:mdna:222]
|  | Nine Months Ended July 31, |  |  |  |  |
|  | 2016 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 390,109 |  |  | $ | 354,990 |  |  | $ | 35,119 |  |  | 9.9 |  |
| Software and Software-Related Services | $ | (970 | ) |  | $ | 7,320 |  |  | $ | (8,290 | ) |  | (113.3 | ) |
| Global Services | $ | 114,543 |  |  | $ | 103,923 |  |  | $ | 10,620 |  |  | 10.2 |  |

[0000936395-16-000115:mdna:223]
[same as prior period, unchanged from 0000936395-16-000104:mdna:223]

[0000936395-16-000115:mdna:224]
*    Denotes % change from 2016 to 2015

[0000936395-16-000115:mdna:225]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume as described above and improved gross margin. The increases were partially offset by higher research and development costs. The improved gross margin was the result of product cost reductions, including innovation on our WaveLogic coherent optical processor for 100G and 200G optical transport, and improved manufacturing efficiencies, partially offset by market-based price erosion and an increased provision for excess and obsolete inventory expense. |

[0000936395-16-000115:mdna:226]
[same as prior period, unchanged from 0000936395-16-000104:mdna:226]

[0000936395-16-000115:mdna:227]
| • | Global Services segment profit increased, primarily due to higher sales volume and improved gross margin. The improved gross margin reflects reduced repair costs to support maintenance service contracts and improved margin on installation consulting services. |

[0000936395-16-000115:mdna:228]
[same as prior period, unchanged from 0000936395-16-000104:mdna:228]

[0000936395-16-000115:mdna:229]
At July 31, 2016, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-16-000115:mdna:230]
|  | July 31, 2016 |  | October 31, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 854,918 |  |  | $ | 790,971 |  |  | $ | 63,947 |  |
| Short-term investments in marketable debt securities | 295,322 |  |  | 135,107 |  |  | 160,215 |  |
| Long-term investments in marketable debt securities | 115,366 |  |  | 95,105 |  |  | 20,261 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,265,606 |  |  | $ | 1,021,183 |  |  | $ | 244,423 |  |

[0000936395-16-000115:mdna:231]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $47.4 million as of July 31, 2016. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-16-000115:mdna:232]
As more fully described in Note 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report, during the second quarter of fiscal 2016 we entered into an Incremental Term Loan Credit Agreement that provided for a new tranche of senior secured term loans under the Credit Agreement dated July 15, 2014 in an aggregate principal amount of $250 million maturing on April 25, 2021. The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% Senior Convertible Notes due June 15, 2017.

[0000936395-16-000115:mdna:233]
The change in total cash and cash equivalents and investments in marketable debt securities during the first nine months of fiscal 2016 was also related to the following:

[0000936395-16-000115:mdna:234]
| • | $152.8 million cash generated from operations, consisting of $239.4 million provided by net income (adjusted for non-cash charges) offset by $86.6 million used in working capital; |

[0000936395-16-000115:mdna:235]
| • | $81.2 million used for purchases of equipment, furniture and fixtures and intellectual property; |

[0000936395-16-000115:mdna:236]
| • | $10.0 million used for settlement of foreign currency forward contracts, net; |

[0000936395-16-000115:mdna:237]
| • | $5.4 million used to pay capital lease obligations; |

[0000936395-16-000115:mdna:238]
[same as prior period, unchanged from 0000936395-16-000104:mdna:238]

[0000936395-16-000115:mdna:239]
| • | $46.0 million used for repayment of long-term debt, including repurchases of outstanding convertible notes; |

[0000936395-16-000115:mdna:240]
| • | $22.1 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; |

[0000936395-16-000115:mdna:241]
| • | $1.0 million used for payment of debt issuance costs; and |

[0000936395-16-000115:mdna:242]
| • | $1.7 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-16-000115:mdna:243]
[same as prior period, unchanged from 0000936395-16-000104:mdna:244]

[0000936395-16-000115:mdna:244]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the "ABL Credit Facility") providing for a total commitment of $250 million with a maturity date of December 31, 2020. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of July 31, 2016, letters of credit totaling $69.0 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2016.

[0000936395-16-000115:mdna:245]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. During fiscal 2016, we have repurchased approximately $248.6 million in aggregate principal amount of our outstanding 0.875% Convertible Senior Notes due June 15, 2017 (the "2017 Notes"). For additional information about our convertible notes, including certain repurchases during the fourth quarter of fiscal 2016, see Notes 17 and 23 to our Condensed Consolidated Financial Statements included in in Item 1 of Part I of this report. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, the repayment of the 2017 Notes and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-16-000115:mdna:246]
The following sections set forth the components of our $152.8 million of cash generated from operating activities during the first nine months of fiscal 2016:

[0000936395-16-000115:mdna:247]
[same as prior period, unchanged from 0000936395-16-000104:mdna:247]

[0000936395-16-000115:mdna:248]
[same as prior period, unchanged from 0000936395-16-000104:mdna:248]

[0000936395-16-000115:mdna:249]
|  | Nine months ended |
|  | July 31, 2016 |
| Net income | $ | 35,997 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 46,624 |  |
| Share-based compensation costs | 41,832 |  |
| Amortization of intangible assets | 59,428 |  |
| Provision for inventory excess and obsolescence | 26,663 |  |
| Provision for warranty | 13,114 |  |
| Other | 15,706 |  |
| Net income (adjusted for non-cash charges) | $ | 239,364 |  |

[0000936395-16-000115:mdna:250]
[same as prior period, unchanged from 0000936395-16-000104:mdna:250]

[0000936395-16-000115:mdna:251]
We used $86.6 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-16-000115:mdna:252]
|  | Nine months ended |
|  | July 31, 2016 |
| Cash used in accounts receivable | $ | (37,768 | ) |
| Cash used in inventories | (56,267 | ) |
| Cash provided by prepaid expenses and other | 16,687 |  |
| Cash used in accounts payable, accruals and other obligations | (5,087 | ) |
| Cash used in deferred revenue | (4,120 | ) |
| Total cash used for working capital | $ | (86,555 | ) |

[0000936395-16-000115:mdna:253]
[same as prior period, unchanged from 0000936395-16-000104:mdna:253]

[0000936395-16-000115:mdna:254]
| • | The $37.8 million of cash used by accounts receivable during the first nine months of fiscal 2016 reflects higher proportional sales volume at the end of the third quarter of fiscal 2016; |

[0000936395-16-000115:mdna:255]
| • | The $56.3 million of cash used in inventory during the first nine months of fiscal 2016 primarily reflects increases in finished goods to meet customer delivery schedules for the beginning of the fourth quarter of fiscal 2016; |

[0000936395-16-000115:mdna:256]
| • | Cash provided by prepaid expense and other during the first nine months of fiscal 2016 was $16.7 million, primarily reflecting payment of a financing receivable; |

[0000936395-16-000115:mdna:257]
| • | The $5.1 million of cash used in accounts payable, accruals and other obligations during the first nine months of fiscal 2016 reflects a slight increase in payments to our suppliers; and |

[0000936395-16-000115:mdna:258]
| • | The $4.1 million of cash used in deferred revenue during the first nine months of fiscal 2016 represents an increase in the recognition of revenue for which we received advanced payments from customers. |

[0000936395-16-000115:mdna:259]
Our days sales outstanding (DSOs) for the first nine months of fiscal 2016 were 84 days and our inventory turns for the first nine months of fiscal 2016 were 5.1.

[0000936395-16-000115:mdna:260]
[same as prior period, unchanged from 0000936395-16-000104:mdna:260]

[0000936395-16-000115:mdna:261]
[same as prior period, unchanged from 0000936395-16-000104:mdna:261]

[0000936395-16-000115:mdna:262]
|  | Nine months ended |
|  | July 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 4,262 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | 6,562 |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 7,500 |  |
| Term Loan due July 15, 2019(4) | 7,005 |  |
| Term Loan due April 25, 2021(5) | 2,654 |  |
| Interest rate swaps(6) | 2,479 |  |
| ABL Credit Facility(7) | 1,325 |  |
| Cash paid during period | $ | 31,787 |  |

[0000936395-16-000115:mdna:263]
[same as prior period, unchanged from 0000936395-16-000104:mdna:263]

[0000936395-16-000115:mdna:264]
[same as prior period, unchanged from 0000936395-16-000104:mdna:264]

[0000936395-16-000115:mdna:265]
[same as prior period, unchanged from 0000936395-16-000104:mdna:265]

[0000936395-16-000115:mdna:266]
| (4) | Interest on our outstanding 2019 Term Loan is payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bears interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of 0.75%. During the first nine months of fiscal 2016, the interest rate on the 2019 Term Loan was 3.75%. |

[0000936395-16-000115:mdna:267]
| (5) | Interest on our outstanding 2021 Term Loan is is payable periodically based on the underlying market index rate selected for borrowing. The 2021 Term Loan bears interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. At the end of the third quarter of fiscal 2016, the interest rate on the 2021 Term Loan was 4.25%. |

[0000936395-16-000115:mdna:268]
| (6) | Payments on our interest rate swaps are variable and effectively fix the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. |

[0000936395-16-000115:mdna:269]
| (7) | During the first nine months of fiscal 2016, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.3 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-16-000115:mdna:270]
For additional information about our convertible notes and term loans, ABL Credit Facility and interest rate swaps, see Notes 15, 17 and 18 to our Condensed Consolidated Financial Statements included in in Item 1 of Part I of this report.

[0000936395-16-000115:mdna:271]
[same as prior period, unchanged from 0000936395-16-000104:mdna:271]

[0000936395-16-000115:mdna:272]
[same as prior period, unchanged from 0000936395-16-000104:mdna:273]

[0000936395-16-000115:mdna:273]
The following is a summary of our future minimum payments under contractual obligations as of July 31, 2016 (in thousands):

[0000936395-16-000115:mdna:274]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,017,592 |  |  | $ | 450,465 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on term loans | 494,375 |  |  | 5,000 |  |  | 247,500 |  |  | 241,875 |  |  | — |  |
| Interest due on convertible notes | 70,505 |  |  | 24,567 |  |  | 34,688 |  |  | 11,250 |  |  | — |  |
| Interest due on term loans (2) | 77,545 |  |  | 19,993 |  |  | 39,385 |  |  | 18,167 |  |  | — |  |
| Payments due under interest rate swaps (2) | 12,166 |  |  | 4,652 |  |  | 6,131 |  |  | 1,383 |  |  | — |  |
| Operating leases (3) | 148,311 |  |  | 37,025 |  |  | 44,323 |  |  | 26,961 |  |  | 40,002 |  |
| Purchase obligations (4) | 207,983 |  |  | 207,983 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 5,726 |  |  | 2,176 |  |  | 3,266 |  |  | 284 |  |  | — |  |
| Capital leases— buildings (5) | 126,732 |  |  | 2,158 |  |  | 14,346 |  |  | 15,092 |  |  | 95,136 |  |
| Other obligations | 3,587 |  |  | 1,481 |  |  | 2,030 |  |  | 76 |  |  | — |  |
| Total (6) | $ | 2,164,522 |  |  | $ | 755,500 |  |  | $ | 741,669 |  |  | $ | 532,215 |  |  | $ | 135,138 |  |

[0000936395-16-000115:mdna:275]
[same as prior period, unchanged from 0000936395-16-000104:mdna:275]

[0000936395-16-000115:mdna:276]
[same as prior period, unchanged from 0000936395-16-000104:mdna:276]

[0000936395-16-000115:mdna:277]
[same as prior period, unchanged from 0000936395-16-000104:mdna:277]

[0000936395-16-000115:mdna:278]
[same as prior period, unchanged from 0000936395-16-000104:mdna:278]

[0000936395-16-000115:mdna:279]
[same as prior period, unchanged from 0000936395-16-000104:mdna:279]

[0000936395-16-000115:mdna:280]
[same as prior period, unchanged from 0000936395-16-000104:mdna:280]

[0000936395-16-000115:mdna:281]
| (6) | As of July 31, 2016, we also had approximately $12.5 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-16-000115:mdna:282]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of July 31, 2016 (in thousands):

[0000936395-16-000115:mdna:283]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 71,552 |  |  | $ | 35,179 |  |  | $ | 15,774 |  |  | $ | 10,105 |  |  | $ | 10,494 |  |

[0000936395-16-000115:mdna:284]
[same as prior period, unchanged from 0000936395-16-000104:mdna:284]

[0000936395-16-000115:mdna:285]
[same as prior period, unchanged from 0000936395-16-000104:mdna:285]

[0000936395-16-000115:mdna:286]
[same as prior period, unchanged from 0000936395-16-000104:mdna:286]

[0000936395-16-000115:mdna:287]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-16-000115:mdna:288]
[same as prior period, unchanged from 0000936395-16-000104:mdna:289]

[0000936395-16-000115:mdna:289]
[same as prior period, unchanged from 0000936395-16-000104:mdna:290]

[0000936395-16-000115:mdna:290]
[same as prior period, unchanged from 0000936395-16-000104:mdna:291]

[0000936395-16-000115:mdna:291]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the first nine months ended July 31, 2016 and July 31, 2015 were 0.3% and 1.9%, respectively.

[0000936395-16-000115:mdna:292]
[same as prior period, unchanged from 0000936395-16-000104:mdna:293]

[0000936395-16-000115:mdna:293]
[same as prior period, unchanged from 0000936395-16-000104:mdna:294]

[0000936395-16-000115:mdna:294]
[same as prior period, unchanged from 0000936395-16-000104:mdna:295]

[0000936395-16-000115:mdna:295]
[same as prior period, unchanged from 0000936395-16-000104:mdna:296]

[0000936395-16-000115:mdna:296]
Our total deferred revenue for products was $48.8 million and $66.5 million as of July 31, 2016 and October 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $139.4 million and $122.5 million as of July 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000115:mdna:297]
[same as prior period, unchanged from 0000936395-16-000104:mdna:299]

[0000936395-16-000115:mdna:298]
[same as prior period, unchanged from 0000936395-16-000104:mdna:300]

[0000936395-16-000115:mdna:299]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 20 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of July 31, 2016, total unrecognized compensation expense was $75.1 million: (i) $0.8 million, which related to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years; and (ii) $74.3 million which related to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.

[0000936395-16-000115:mdna:300]
[same as prior period, unchanged from 0000936395-16-000104:mdna:302]

[0000936395-16-000115:mdna:301]
[same as prior period, unchanged from 0000936395-16-000104:mdna:303]

[0000936395-16-000115:mdna:302]
[same as prior period, unchanged from 0000936395-16-000104:mdna:304]

[0000936395-16-000115:mdna:303]
For fiscal 2016, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2016. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2016 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or

[0000936395-16-000115:mdna:304]
operational performance are better or worse than expected. We incurred an aggregate of $42.5 million of expense in the first nine months of fiscal 2016 associated with our cash incentive bonus plan for fiscal 2016.

[0000936395-16-000115:mdna:305]
[same as prior period, unchanged from 0000936395-16-000104:mdna:306]

[0000936395-16-000115:mdna:306]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $26.7 million and $18.0 million in the first nine months of fiscal 2016 and 2015, respectively. The charges in fiscal 2016 primarily were related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Our inventory net of allowance for excess and obsolescence was $221.6 million and $191.2 million as of July 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000115:mdna:307]
[same as prior period, unchanged from 0000936395-16-000104:mdna:308]

[0000936395-16-000115:mdna:308]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $588.4 million and $550.8 million as of July 31, 2016 and October 31, 2015, respectively. Our allowance for doubtful accounts was $3.8 million and $3.0 million as of July 31, 2016 and October 31, 2015, respectively.

[0000936395-16-000115:mdna:309]
[same as prior period, unchanged from 0000936395-16-000104:mdna:310]

[0000936395-16-000115:mdna:310]
[same as prior period, unchanged from 0000936395-16-000104:mdna:311]

[0000936395-16-000115:mdna:311]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing our earnings or increasing our losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of the end of third quarter of fiscal 2015, there was no goodwill balance. At the end of third quarter of fiscal 2016, the goodwill balance was $267.3 million.

[0000936395-16-000115:mdna:312]
[same as prior period, unchanged from 0000936395-16-000104:mdna:313]

[0000936395-16-000115:mdna:313]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets, in-process research and development and maintenance spares. As of July 31, 2016 and October 31, 2015, these assets totaled $488.6 million and $449.9 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-16-000115:mdna:314]
[same as prior period, unchanged from 0000936395-16-000104:mdna:315]

[0000936395-16-000115:mdna:315]
As of July 31, 2016, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to evaluate whether sufficient positive evidence exists to support a reversal of the valuation allowance. For this evaluation, management considers its recent financial results and trends, and makes judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies, and tax planning strategies. We will release all or a portion of this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-16-000115:mdna:316]
[same as prior period, unchanged from 0000936395-16-000104:mdna:317]

[0000936395-16-000115:mdna:317]
Our liability for product warranties, included in other accrued liabilities, was $54.5 million and $56.7 million as of July 31, 2016 and October 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $13.1 million and $12.5 million for the first nine months of fiscal 2016 and 2015, respectively. See Note 14 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
