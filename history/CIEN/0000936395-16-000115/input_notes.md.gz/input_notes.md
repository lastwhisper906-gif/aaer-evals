# CIEN notes — 0000936395-16-000115


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-16-000115:notes:1]
ABL CREDIT FACILITY

[0000936395-16-000115:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-16-000115:notes:3]
On January 8, 2016, Ciena amended the ABL Credit Facility to, among other things:

[0000936395-16-000115:notes:4]
| • | increase the total commitment from $200 million to $250 million, of which $200 million is available for issuances of letters of credit; |

[0000936395-16-000115:notes:5]
| • | extend the maturity date from December 31, 2016 to December 31, 2020, provided an earlier maturity date would apply in the event that Ciena and its subsidiaries are unable to satisfy a minimum liquidity test 90 days prior to the maturity date of any debt equal to $100 million or greater; |

[0000936395-16-000115:notes:6]
| • | reduce the minimum aggregate amount of unrestricted cash and cash equivalents that Ciena and its domestic subsidiaries are required to maintain at all times from $150 million to $100 million; and |

[0000936395-16-000115:notes:7]
| • | reduce the interest rate by 0.25% on borrowings to either (a) LIBOR plus a margin ranging from 1.25% to 1.75% (instead of the previous 1.50% to 2.0%) or (b) a base rate plus a margin ranging from 0.25% to 0.75% (instead of the previous 0.50% to 1.0%), in each case with the actual margin determined according to the Ciena’s utilization of the facility. |

[0000936395-16-000115:notes:8]
As of July 31, 2016, letters of credit totaling $69.0 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2016.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-16-000115:notes:9]
[same as prior period, unchanged from 0000936395-16-000104:notes:9]

[0000936395-16-000115:notes:10]
[same as prior period, unchanged from 0000936395-16-000104:notes:10]

[0000936395-16-000115:notes:11]
[same as prior period, unchanged from 0000936395-16-000104:notes:11]


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-16-000115:notes:12]
[same as prior period, unchanged from 0000936395-16-000104:notes:12]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-16-000115:notes:13]
[same as prior period, unchanged from 0000936395-16-000104:notes:13]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-16-000115:notes:14]
[same as prior period, unchanged from 0000936395-16-000104:notes:14]

[0000936395-16-000115:notes:15]
[same as prior period, unchanged from 0000936395-16-000104:notes:15]

[0000936395-16-000115:notes:16]
|  | July 31, 2016 |  | October 31, 2015 |
| Prepaid VAT and other taxes | $ | 86,821 |  |  | $ | 74,754 |  |
| Product demonstration equipment, net | 47,392 |  |  | 41,611 |  |
| Deferred deployment expense | 24,662 |  |  | 26,193 |  |
| Prepaid expenses | 26,903 |  |  | 25,074 |  |
| Other non-trade receivables | 3,137 |  |  | 8,588 |  |
| Financing receivable | 771 |  |  | 19,869 |  |
| Derivative assets | 261 |  |  | 89 |  |
|  | $ | 189,947 |  |  | $ | 196,178 |  |

[0000936395-16-000115:notes:17]
Depreciation of product demonstration equipment was $8.1 million and $7.3 million for the first nine months of fiscal 2016 and 2015, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-16-000115:notes:18]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-16-000115:notes:19]
Term Loan due 2021

[0000936395-16-000115:notes:20]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the "Term Loan Credit Agreement"), dated July 15, 2014. The Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% senior convertible notes due June 15, 2017.

[0000936395-16-000115:notes:21]
The 2021 Term Loan will, among other things:

[0000936395-16-000115:notes:22]
| • | mature on April 25, 2021; |

[0000936395-16-000115:notes:23]
| • | amortize in equal quarterly installments in aggregate amounts of $0.6 million (equal to 0.25% of the original principal amount), with the balance payable at maturity; |

[0000936395-16-000115:notes:24]
| • | be subject to mandatory prepayment on the same basis as Ciena’s existing 2019 Term Loan under the Term Loan Credit Agreement; |

[0000936395-16-000115:notes:25]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus a margin ranging from 3.25% to 3.50%, or (b) a base rate (subject to a floor of 1.75%) plus a margin ranging from 2.25% to 2.50%, in each case, with the actual margin determined according to Ciena’s total net leverage ratio; |

[0000936395-16-000115:notes:26]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2021 Term Loan with proceeds of certain indebtedness prior to October 25, 2016 shall require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and |

[0000936395-16-000115:notes:27]
| • | except as described above or otherwise set forth in the Incremental Term Loan Credit Agreement, have identical terms as the existing 2019 Term Loan under the Term Loan Credit Agreement. |

[0000936395-16-000115:notes:28]
Except as amended by the Incremental Term Loan Credit Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

[0000936395-16-000115:notes:29]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of July 31, 2016 (in thousands):

[0000936395-16-000115:notes:30]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 249,375 |  |  | $ | 1,183 |  |  | $ | 248,192 |  |

[0000936395-16-000115:notes:31]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):

[0000936395-16-000115:notes:32]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,192 |  |  | $ | 251,557 |  |

[0000936395-16-000115:notes:33]
| (1) | Includes unamortized bond discount. |

[0000936395-16-000115:notes:34]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000115:notes:35]
Term Loan due 2019

[0000936395-16-000115:notes:36]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):

[0000936395-16-000115:notes:37]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 245,000 |  |  | $ | 856 |  |  | $ | 244,144 |  |

[0000936395-16-000115:notes:38]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

[0000936395-16-000115:notes:39]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,144 |  |  | $ | 247,144 |  |

[0000936395-16-000115:notes:40]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000115:notes:41]
Outstanding Convertible Notes Payable

[0000936395-16-000115:notes:42]
During the first nine months of fiscal 2016, Ciena entered into certain private transactions to repurchase $43.5 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for cash purchase prices slightly below par. See Note 23 below for information regarding a repurchase transaction in the fourth quarter of fiscal 2016.

[0000936395-16-000115:notes:43]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of July 31, 2016:

[0000936395-16-000115:notes:44]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 200,315 |  |  | $ | 11,967 |  |  | $ | 188,348 |  |  | $ | 43,131 |  |

[0000936395-16-000115:notes:45]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2016:

[0000936395-16-000115:notes:46]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 450,465 |  |  | $ | 449,339 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,938 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 188,348 |  |  | 239,072 |  |
|  |  | $ | 988,813 |  |  | $ | 1,105,349 |  |

[0000936395-16-000115:notes:47]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-16-000115:notes:48]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-16-000115:notes:49]
[same as prior period, unchanged from 0000936395-16-000104:notes:49]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-16-000115:notes:50]
[same as prior period, unchanged from 0000936395-16-000104:notes:50]

[0000936395-16-000115:notes:51]
On February 1, 2016, Ciena, through a Canadian subsidiary, acquired certain high-speed photonics components ("HSPC") assets of TeraXion Inc. ("TeraXion") and its wholly-owned subsidiary for approximately $32 million in cash. The assets purchased include TeraXion’s high-speed indium phosphide and silicon photonics technologies, as well as the underlying intellectual property. These technologies support development of Ciena's WaveLogic coherent optical chipsets. This transaction has been accounted for as the acquisition of a business.

[0000936395-16-000115:notes:52]
[same as prior period, unchanged from 0000936395-16-000104:notes:52]

[0000936395-16-000115:notes:53]
[same as prior period, unchanged from 0000936395-16-000104:notes:53]

[0000936395-16-000115:notes:54]
[same as prior period, unchanged from 0000936395-16-000104:notes:54]

[0000936395-16-000115:notes:55]
[same as prior period, unchanged from 0000936395-16-000104:notes:55]

[0000936395-16-000115:notes:56]
[same as prior period, unchanged from 0000936395-16-000104:notes:56]

[0000936395-16-000115:notes:57]
[same as prior period, unchanged from 0000936395-16-000104:notes:57]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-16-000115:notes:58]
[same as prior period, unchanged from 0000936395-16-000104:notes:58]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-16-000115:notes:59]
COMMITMENTS AND CONTINGENCIES

[0000936395-16-000115:notes:60]
Foreign Tax Contingencies

[0000936395-16-000115:notes:61]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-16-000115:notes:62]
Litigation

[0000936395-16-000115:notes:63]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-16-000115:notes:64]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-16-000115:notes:65]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-16-000115:notes:66]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-16-000115:notes:67]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-16-000115:notes:68]
[same as prior period, unchanged from 0000936395-16-000104:notes:74]

[0000936395-16-000115:notes:69]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the nine months ending July 31, 2016:

[0000936395-16-000115:notes:70]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | $ | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 425 |  |  | (70 | ) |  | (4,655 | ) |  | 1,969 |  |  | (2,331 | ) |
| Amounts reclassified from AOCI | — |  |  | 588 |  |  | 2,479 |  |  | — |  |  | 3,067 |  |
| Balance at July 31, 2016 | $ | 347 |  |  | $ | 250 |  |  | $ | (7,698 | ) |  | $ | (14,289 | ) |  | $ | (21,390 | ) |

[0000936395-16-000115:notes:71]
The following table summarizes the changes in AOCI for the nine months ending July 31, 2015:

[0000936395-16-000115:notes:72]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income (loss) before reclassifications | (37 | ) |  | (5,451 | ) |  | (2,885 | ) |  | (6,919 | ) |  | (15,292 | ) |
| Amounts reclassified from AOCI | — |  |  | 3,825 |  |  | — |  |  | — |  |  | 3,825 |  |
| Balance at July 31, 2015 | $ | 34 |  |  | $ | (1,799 | ) |  | $ | (4,968 | ) |  | $ | (19,402 | ) |  | $ | (26,135 | ) |

[0000936395-16-000115:notes:73]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-16-000115:notes:74]
[same as prior period, unchanged from 0000936395-16-000104:notes:80]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-16-000115:notes:75]
[same as prior period, unchanged from 0000936395-16-000104:notes:81]

[0000936395-16-000115:notes:76]
|  | July 31, 2016 |  | October 31, 2015 |
| Products | $ | 48,826 |  |  | $ | 66,527 |  |
| Services | 139,413 |  |  | 122,546 |  |
|  | 188,239 |  |  | 189,073 |  |
| Less current portion | (117,952 | ) |  | (126,111 | ) |
| Long-term deferred revenue | $ | 70,287 |  |  | $ | 62,962 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-16-000115:notes:77]
[same as prior period, unchanged from 0000936395-16-000104:notes:83]

[0000936395-16-000115:notes:78]
[same as prior period, unchanged from 0000936395-16-000104:notes:84]

[0000936395-16-000115:notes:79]
As of July 31, 2016 and October 31, 2015, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $50.4 million and $68.1 million as of July 31, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-16-000115:notes:80]
During the first nine months of fiscal 2016 and fiscal 2015, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $80.2 million and $146.5 million as of July 31, 2016 and October 31, 2015, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-16-000115:notes:81]
[same as prior period, unchanged from 0000936395-16-000104:notes:87]

[0000936395-16-000115:notes:82]
During fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swaps") that fix the interest rate under the 2019 Term Loan (as defined in Note 17) at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of July 31, 2016 and October 31, 2015 was $245.0 million and $246.9 million, respectively.

[0000936395-16-000115:notes:83]
In May 2016, Ciena entered into interest rate swaps that fix the total interest rate under the 2021 Term Loan (as defined in Note 17) at 4.62% to 4.87%, depending on the applicable margin, for the period commencing on June 20, 2016 through June 22, 2020. The total notional amount of these derivatives as of July 31, 2016 was $249.4 million.

[0000936395-16-000115:notes:84]
[same as prior period, unchanged from 0000936395-16-000104:notes:90]

[0000936395-16-000115:notes:85]
[same as prior period, unchanged from 0000936395-16-000104:notes:91]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-16-000115:notes:86]
[same as prior period, unchanged from 0000936395-16-000104:notes:92]

[0000936395-16-000115:notes:87]
[same as prior period, unchanged from 0000936395-16-000104:notes:93]

[0000936395-16-000115:notes:88]
[same as prior period, unchanged from 0000936395-16-000104:notes:94]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-16-000115:notes:89]
[same as prior period, unchanged from 0000936395-16-000104:notes:95]

[0000936395-16-000115:notes:90]
[same as prior period, unchanged from 0000936395-16-000104:notes:96]

[0000936395-16-000115:notes:91]
[same as prior period, unchanged from 0000936395-16-000104:notes:97]

[0000936395-16-000115:notes:92]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of July 31, 2016, approximately 3.7 million shares remained available for issuance under the 2008 Plan.

[0000936395-16-000115:notes:93]
[same as prior period, unchanged from 0000936395-16-000104:notes:99]

[0000936395-16-000115:notes:94]
[same as prior period, unchanged from 0000936395-16-000104:notes:100]

[0000936395-16-000115:notes:95]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2015 | 2,293 |  |  | $ | 24.45 |  |
| Exercised | (471 | ) |  | 10.57 |  |
| Canceled | (304 | ) |  | 38.46 |  |
| Balance at July 31, 2016 | 1,518 |  |  | $ | 25.95 |  |

[0000936395-16-000115:notes:96]
The total intrinsic value of options exercised during the first nine months of fiscal 2016 and fiscal 2015 was $4.6 million and $1.8 million, respectively. Ciena did not grant any stock options during the first nine months of fiscal 2016 or fiscal 2015.

[0000936395-16-000115:notes:97]
The following table summarizes information with respect to stock options outstanding at July 31, 2016, based on Ciena’s closing stock price on the last trading day of Ciena’s third fiscal quarter of 2016 (shares and intrinsic value in thousands):

[0000936395-16-000115:notes:98]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | July 31, 2016 |  | July 31, 2016 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.05 |  |  | — |  |  | $ | 11.16 |  |  | 190 |  |  | 2.72 |  | $ | 6.05 |  |  | $ | 2,490 |  |  | 188 |  |  | 2.68 |  | $ | 6.01 |  |  | $ | 2,476 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 355 |  |  | 5.25 |  | 13.34 |  |  | 2,080 |  |  | 330 |  |  | 5.09 |  | 13.22 |  |  | 1,967 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.52 |  |  | 393 |  |  | 1.50 |  | 26.58 |  |  | 38 |  |  | 372 |  |  | 1.15 |  | 27.02 |  |  | 19 |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 331 |  |  | 2.55 |  | 35.18 |  |  | — |  |  | 321 |  |  | 2.43 |  | 35.16 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 249 |  |  | 4.99 |  | 45.81 |  |  | — |  |  | 211 |  |  | 4.66 |  | 45.83 |  |  | — |  |
| $ | 0.05 |  |  | — |  |  | $ | 55.63 |  |  | 1,518 |  |  | 3.33 |  | $ | 25.95 |  |  | $ | 4,608 |  |  | 1,422 |  |  | 3.07 |  | $ | 25.68 |  |  | $ | 4,462 |  |

[0000936395-16-000115:notes:99]
[same as prior period, unchanged from 0000936395-16-000104:notes:105]

[0000936395-16-000115:notes:100]
[same as prior period, unchanged from 0000936395-16-000104:notes:106]

[0000936395-16-000115:notes:101]
[same as prior period, unchanged from 0000936395-16-000104:notes:107]

[0000936395-16-000115:notes:102]
[same as prior period, unchanged from 0000936395-16-000104:notes:108]

[0000936395-16-000115:notes:103]
[same as prior period, unchanged from 0000936395-16-000104:notes:109]

[0000936395-16-000115:notes:104]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2015 | 4,886 |  |  | $ | 20.02 |  |  | $ | 117,951 |  |
| Granted | 2,161 |  |  |  |  |  |
| Vested | (2,099 | ) |  |  |  |  |
| Canceled or forfeited | (272 | ) |  |  |  |  |
| Balance at July 31, 2016 | 4,676 |  |  | $ | 19.93 |  |  | $ | 89,727 |  |

[0000936395-16-000115:notes:105]
The total fair value of restricted stock units that vested and were converted into common stock during the first nine months of fiscal 2016 and fiscal 2015 was $41.3 million and $33.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first nine months of fiscal 2016 and fiscal 2015 was $19.72 and $19.15 respectively.

[0000936395-16-000115:notes:106]
[same as prior period, unchanged from 0000936395-16-000104:notes:112]

[0000936395-16-000115:notes:107]
[same as prior period, unchanged from 0000936395-16-000104:notes:113]

[0000936395-16-000115:notes:108]
[same as prior period, unchanged from 0000936395-16-000104:notes:114]

[0000936395-16-000115:notes:109]
[same as prior period, unchanged from 0000936395-16-000104:notes:115]

[0000936395-16-000115:notes:110]
[same as prior period, unchanged from 0000936395-16-000104:notes:116]

[0000936395-16-000115:notes:111]
[same as prior period, unchanged from 0000936395-16-000104:notes:117]

[0000936395-16-000115:notes:112]
During the first nine months of fiscal 2016, Ciena issued 1.1 million shares under the ESPP. At July 31, 2016, 5.9 million shares remained available for issuance under the ESPP.

[0000936395-16-000115:notes:113]
[same as prior period, unchanged from 0000936395-16-000104:notes:119]

[0000936395-16-000115:notes:114]
[same as prior period, unchanged from 0000936395-16-000104:notes:120]

[0000936395-16-000115:notes:115]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Product costs | $ | 645 |  |  | $ | 671 |  |  | $ | 1,845 |  |  | $ | 1,811 |  |
| Service costs | 637 |  |  | 490 |  |  | 1,922 |  |  | 1,583 |  |
| Share-based compensation expense included in cost of sales | 1,282 |  |  | 1,161 |  |  | 3,767 |  |  | 3,394 |  |
| Research and development | 3,479 |  |  | 2,114 |  |  | 10,698 |  |  | 6,815 |  |
| Sales and marketing | 3,590 |  |  | 3,571 |  |  | 12,248 |  |  | 11,071 |  |
| General and administrative | 4,284 |  |  | 3,516 |  |  | 14,381 |  |  | 11,158 |  |
| Acquisition and integration costs | — |  |  | — |  |  | 714 |  |  | — |  |
| Share-based compensation expense included in operating expense | 11,353 |  |  | 9,201 |  |  | 38,041 |  |  | 29,044 |  |
| Share-based compensation expense capitalized in inventory, net | (13 | ) |  | (96 | ) |  | 24 |  |  | (36 | ) |
| Total share-based compensation | $ | 12,622 |  |  | $ | 10,266 |  |  | $ | 41,832 |  |  | $ | 32,402 |  |

[0000936395-16-000115:notes:116]
As of July 31, 2016, total unrecognized share-based compensation expense was approximately $75.1 million: (i) $0.8 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.4 years, and (ii) $74.3 million,which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.4 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-16-000115:notes:117]
[same as prior period, unchanged from 0000936395-16-000104:notes:123]


## us-gaap:EarningsPerShareTextBlock

[0000936395-16-000115:notes:118]
[same as prior period, unchanged from 0000936395-16-000104:notes:124]

[0000936395-16-000115:notes:119]
[same as prior period, unchanged from 0000936395-16-000104:notes:125]

[0000936395-16-000115:notes:120]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Net income | $ | 33,546 |  |  | $ | 23,625 |  |  | $ | 35,997 |  |  | $ | 25,499 |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | 1,326 |  |  | 1,384 |  |  | — |  |  | — |  |
| Add: Interest expense associated with 3.75% convertible senior notes due 2018 | 3,572 |  |  | — |  |  | — |  |  | — |  |
| Net income used to calculate Diluted EPS | $ | 38,444 |  |  | $ | 25,009 |  |  | $ | 35,997 |  |  | $ | 25,499 |  |

[0000936395-16-000115:notes:121]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Basic weighted average shares outstanding | 138,881 |  |  | 118,413 |  |  | 137,835 |  |  | 113,189 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 895 |  |  | 1,712 |  |  | 1,218 |  |  | 1,360 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | 12,217 |  |  | 13,108 |  |  | — |  |  | — |  |
| Add: Shares underlying 3.75% convertible senior notes due 2018 | 17,356 |  |  | — |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 169,349 |  |  | 133,233 |  |  | 139,053 |  |  | 114,549 |  |

[0000936395-16-000115:notes:122]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Basic EPS | $ | 0.24 |  |  | $ | 0.20 |  |  | $ | 0.26 |  |  | $ | 0.23 |  |
| Diluted EPS | $ | 0.23 |  |  | $ | 0.19 |  |  | $ | 0.26 |  |  | $ | 0.22 |  |

[0000936395-16-000115:notes:123]
[same as prior period, unchanged from 0000936395-16-000104:notes:129]

[0000936395-16-000115:notes:124]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Shares underlying stock options and restricted stock units | 2,082 |  |  | 755 |  |  | 2,089 |  |  | 1,534 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | — |  |  | — |  |  | — |  |  | 4,515 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | — |  |  | 12,571 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | — |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 11,280 |  |  | 27,309 |  |  | 41,214 |  |  | 45,711 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-16-000115:notes:125]
[same as prior period, unchanged from 0000936395-16-000104:notes:131]

[0000936395-16-000115:notes:126]
|  | July 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 665,581 |  |  | $ | — |  |  | $ | — |  |  | $ | 665,581 |  |
| U.S. government obligations | — |  |  | 380,718 |  |  | — |  |  | 380,718 |  |
| Commercial paper | — |  |  | 94,944 |  |  | — |  |  | 94,944 |  |
| Foreign currency forward contracts | — |  |  | 261 |  |  | — |  |  | 261 |  |
| Total assets measured at fair value | $ | 665,581 |  |  | $ | 475,923 |  |  | $ | — |  |  | $ | 1,141,504 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,485 |  |  | $ | — |  |  | $ | 1,485 |  |
| Forward starting interest rate swap | — |  |  | 7,698 |  |  | — |  |  | 7,698 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,183 |  |  | $ | — |  |  | $ | 9,183 |  |

[0000936395-16-000115:notes:127]
[same as prior period, unchanged from 0000936395-16-000104:notes:133]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-16-000115:notes:128]
[same as prior period, unchanged from 0000936395-16-000104:notes:134]

[0000936395-16-000115:notes:129]
|  | July 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 665,581 |  |  | $ | 64,974 |  |  | $ | — |  |  | $ | 730,555 |  |
| Short-term investments | — |  |  | 295,322 |  |  | — |  |  | 295,322 |  |
| Prepaid expenses and other | — |  |  | 261 |  |  | — |  |  | 261 |  |
| Long-term investments | — |  |  | 115,366 |  |  | — |  |  | 115,366 |  |
| Total assets measured at fair value | $ | 665,581 |  |  | $ | 475,923 |  |  | $ | — |  |  | $ | 1,141,504 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,485 |  |  | $ | — |  |  | $ | 1,485 |  |
| Other long-term obligations | — |  |  | 7,698 |  |  | — |  |  | 7,698 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,183 |  |  | $ | — |  |  | $ | 9,183 |  |

[0000936395-16-000115:notes:130]
[same as prior period, unchanged from 0000936395-16-000104:notes:136]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-16-000115:notes:131]
[same as prior period, unchanged from 0000936395-16-000104:notes:137]

[0000936395-16-000115:notes:132]
[same as prior period, unchanged from 0000936395-16-000104:notes:138]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-16-000115:notes:133]
[same as prior period, unchanged from 0000936395-16-000104:notes:139]


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-16-000115:notes:134]
[same as prior period, unchanged from 0000936395-16-000104:notes:140]

[0000936395-16-000115:notes:135]
[same as prior period, unchanged from 0000936395-16-000104:notes:141]

[0000936395-16-000115:notes:136]
|  |  | Balance at October 31, 2015 |  | Acquisitions |  | Impairments |  | Translation(1) |  | Balance at July 31, 2016 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 55,006 |  |  | 10,083 |  |  | — |  |  | 744 |  |  | 65,833 |  |
| Total |  | $ | 256,434 |  |  | $ | 10,083 |  |  | $ | — |  |  | $ | 744 |  |  | $ | 267,261 |  |

[0000936395-16-000115:notes:137]
[same as prior period, unchanged from 0000936395-16-000104:notes:143]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-16-000115:notes:138]
[same as prior period, unchanged from 0000936395-16-000104:notes:144]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-16-000115:notes:139]
[same as prior period, unchanged from 0000936395-16-000104:notes:145]

[0000936395-16-000115:notes:140]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2010 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2013), Canada (2010) and India (2010). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-16-000115:notes:141]
[same as prior period, unchanged from 0000936395-16-000104:notes:147]

[0000936395-16-000115:notes:142]
[same as prior period, unchanged from 0000936395-16-000104:notes:148]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-16-000115:notes:143]
[same as prior period, unchanged from 0000936395-16-000104:notes:149]

[0000936395-16-000115:notes:144]
[same as prior period, unchanged from 0000936395-16-000104:notes:150]

[0000936395-16-000115:notes:145]
|  | July 31, 2016 |  | October 31, 2015 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 347,897 |  |  | $ | (237,318 | ) |  | $ | 110,579 |  |  | $ | 506,647 |  |  | $ | (382,130 | ) |  | $ | 124,517 |  |
| In-process research and development | 4,241 |  |  | — |  |  | 4,241 |  |  | — |  |  | — |  |  | — |  |
| Patents and licenses | 6,565 |  |  | (6,223 | ) |  | 342 |  |  | 46,538 |  |  | (46,072 | ) |  | 466 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 358,647 |  |  | (308,640 | ) |  | 50,007 |  |  | 388,621 |  |  | (310,931 | ) |  | 77,690 |  |
| Total other intangible assets | $ | 717,350 |  |  | $ | (552,181 | ) |  | $ | 165,169 |  |  | $ | 941,806 |  |  | $ | (739,133 | ) |  | $ | 202,673 |  |

[0000936395-16-000115:notes:146]
In the second quarter of fiscal 2016, certain fully amortized intangible assets of approximately $246.4 million have been eliminated from gross intangible assets and accumulated amortization during the period, with no corresponding impact to the income statement. These assets were primarily technology for products no longer being sold by Ciena. The aggregate amortization expense of intangible assets was $59.4 million and $39.7 million for the first nine months of fiscal 2016 and 2015, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-16-000115:notes:147]
| Period ended October 31, |  |  |
| 2016 (remaining three months) | $ | 18,851 |  |  |
| 2017 | 45,309 |  |  |
| 2018 | 22,629 |  |  |
| 2019 | 22,081 |  |  |
| 2020 | 21,055 |  |  |
| Thereafter | 31,003 |  |  |
|  | $ | 160,928 |  | (1) |

[0000936395-16-000115:notes:148]
[same as prior period, unchanged from 0000936395-16-000104:notes:154]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-16-000115:notes:149]
[same as prior period, unchanged from 0000936395-16-000104:notes:155]

[0000936395-16-000115:notes:150]
[same as prior period, unchanged from 0000936395-16-000104:notes:156]

[0000936395-16-000115:notes:151]
|  | July 31, 2016 |  | October 31, 2015 |
| Raw materials | $ | 45,655 |  |  | $ | 53,082 |  |
| Work-in-process | 13,813 |  |  | 9,120 |  |
| Finished goods | 158,756 |  |  | 125,966 |  |
| Deferred cost of goods sold | 67,176 |  |  | 55,995 |  |
|  | 285,400 |  |  | 244,163 |  |
| Provision for excess and obsolescence | (63,802 | ) |  | (53,001 | ) |
|  | $ | 221,598 |  |  | $ | 191,162 |  |

[0000936395-16-000115:notes:152]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2016, Ciena recorded a provision for excess and obsolescence of $26.7 million, primarily related to a decrease in the forecasted demand for certain Converged Packet Optical and Optical Transport products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-16-000115:notes:153]
[same as prior period, unchanged from 0000936395-16-000104:notes:159]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-16-000115:notes:154]
[same as prior period, unchanged from 0000936395-16-000104:notes:160]

[0000936395-16-000115:notes:155]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-16-000115:notes:156]
The following table summarizes the final legal maturities of debt investments at July 31, 2016 (in thousands):

[0000936395-16-000115:notes:157]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 295,138 |  |  | $ | 295,322 |  |
| Due in 1-2 years | 115,182 |  |  | 115,366 |  |
|  | $ | 410,320 |  |  | $ | 410,688 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-16-000115:notes:158]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-16-000115:notes:159]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-16-000115:notes:160]
|  | July 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 265,168 |  |  | $ | 187 |  |  | (3 | ) |  | $ | 265,352 |  |
| Included in long-term investments | 115,182 |  |  | 186 |  |  | (2 | ) |  | 115,366 |  |
|  | $ | 380,350 |  |  | $ | 373 |  |  | $ | (5 | ) |  | $ | 380,718 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,970 |  |  | — |  |  | — |  |  | $ | 29,970 |  |
|  | $ | 29,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,970 |  |

[0000936395-16-000115:notes:161]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,989 |  |  | — |  |  | — |  |  | $ | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-16-000115:notes:162]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-16-000115:notes:163]
[same as prior period, unchanged from 0000936395-16-000104:notes:169]

[0000936395-16-000115:notes:164]
As of July 31, 2016 and October 31, 2015, one customer accounted for 10.7% and 10.4% of Ciena's net accounts receivable, respectively. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $3.8 million and $3.0 million as of July 31, 2016 and October 31, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-16-000115:notes:165]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-16-000115:notes:166]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.

[0000936395-16-000115:notes:167]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-16-000115:notes:168]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-16-000115:notes:169]
[same as prior period, unchanged from 0000936395-16-000104:notes:175]

[0000936395-16-000115:notes:170]
[same as prior period, unchanged from 0000936395-16-000104:notes:176]

[0000936395-16-000115:notes:171]
[same as prior period, unchanged from 0000936395-16-000104:notes:177]

[0000936395-16-000115:notes:172]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in assets and liabilities” of $19.0 million for the nine-month period ending July 31, 2015.


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-16-000115:notes:173]
[same as prior period, unchanged from 0000936395-16-000104:notes:179]

[0000936395-16-000115:notes:174]
|  | July 31, 2016 |  | October 31, 2015 |
| Construction liability | $ | 55,023 |  |  | $ | 18,663 |  |
| Capital lease obligations | 25,402 |  |  | 13,794 |  |
| Income tax liability | 12,522 |  |  | 13,308 |  |
| Deferred tenant allowance | 9,312 |  |  | 9,807 |  |
| Straight-line rent | 6,627 |  |  | 6,237 |  |
| Forward starting interest rate swap | 7,698 |  |  | 5,522 |  |
| Other | 6,268 |  |  | 5,209 |  |
|  | $ | 122,852 |  |  | $ | 72,540 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-16-000115:notes:175]
[same as prior period, unchanged from 0000936395-16-000104:notes:181]

[0000936395-16-000115:notes:176]
[same as prior period, unchanged from 0000936395-16-000104:notes:182]

[0000936395-16-000115:notes:177]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Interest income | $ | 1,250 |  |  | $ | 323 |  |  | $ | 2,918 |  |  | $ | 788 |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts | (4,787 | ) |  | 4,924 |  |  | (20,000 | ) |  | 14,925 |  |
| Foreign currency exchange gain (loss) | (839 | ) |  | (10,424 | ) |  | 5,291 |  |  | (32,910 | ) |
| Other | 729 |  |  | (314 | ) |  | 335 |  |  | (2,076 | ) |
| Interest and other income (loss), net | $ | (3,647 | ) |  | $ | (5,491 | ) |  | $ | (11,456 | ) |  | $ | (19,273 | ) |

[0000936395-16-000115:notes:178]
Ciena Corporation, as the U.S. parent entity, uses the U.S. dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first nine months of fiscal 2016 and the first nine months of fiscal 2015, Ciena recorded $5.3 million of foreign currency exchange rate gains and $32.9 million in foreign currency exchange rate losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first nine months of fiscal 2016 and fiscal 2015, Ciena recorded losses of $20.0 million and gains of $14.9 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-16-000115:notes:179]
[same as prior period, unchanged from 0000936395-16-000104:notes:185]

[0000936395-16-000115:notes:180]
[same as prior period, unchanged from 0000936395-16-000104:notes:186]

[0000936395-16-000115:notes:181]
|  | July 31, 2016 |  | October 31, 2015 |
| Equipment, furniture and fixtures | $ | 436,852 |  |  | $ | 404,935 |  |
| Building subject to capital lease | 23,143 |  |  | 13,459 |  |
| Construction in progress subject to build-to-suit lease | 55,023 |  |  | 18,663 |  |
| Leasehold improvements | 67,990 |  |  | 49,196 |  |
|  | 583,008 |  |  | 486,253 |  |
| Accumulated depreciation and amortization | (310,053 | ) |  | (294,280 | ) |
|  | $ | 272,955 |  |  | $ | 191,973 |  |

[0000936395-16-000115:notes:182]
[same as prior period, unchanged from 0000936395-16-000104:notes:188]

[0000936395-16-000115:notes:183]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease, two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of July 31, 2016, there were $55.0 million in costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful life or the lease term.

[0000936395-16-000115:notes:184]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $38.5 million and $34.3 million for the first nine months of fiscal 2016 and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-16-000115:notes:185]
[same as prior period, unchanged from 0000936395-16-000104:notes:191]

[0000936395-16-000115:notes:186]
[same as prior period, unchanged from 0000936395-16-000104:notes:192]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-16-000115:notes:187]
[same as prior period, unchanged from 0000936395-16-000104:notes:193]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-16-000115:notes:188]
[same as prior period, unchanged from 0000936395-16-000104:notes:194]

[0000936395-16-000115:notes:189]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 150,521 |  |  | $ | 128,664 |  |  | $ | 390,109 |  |  | $ | 354,990 |  |
| Software and Software-Related Services | 2,412 |  |  | 3,926 |  |  | (970 | ) |  | 7,320 |  |
| Global Services | 38,855 |  |  | 36,900 |  |  | 114,543 |  |  | 103,923 |  |
| Total segment profit | 191,788 |  |  | 169,490 |  |  | 503,682 |  |  | 466,233 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 83,732 |  |  | 81,650 |  |  | 252,878 |  |  | 240,833 |  |
| General and administrative | 34,336 |  |  | 29,743 |  |  | 100,681 |  |  | 89,598 |  |
| Acquisition and integration costs | 1,029 |  |  | 2,435 |  |  | 4,613 |  |  | 3,455 |  |
| Amortization of intangible assets | 14,529 |  |  | 11,019 |  |  | 46,957 |  |  | 33,057 |  |
| Restructuring costs | 1,138 |  |  | 192 |  |  | 2,057 |  |  | 8,260 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (19,614 | ) |  | (17,374 | ) |  | (52,741 | ) |  | (57,764 | ) |
| Less: Provision for income taxes | 3,864 |  |  | 3,452 |  |  | 7,758 |  |  | 7,767 |  |
| Consolidated net income | $ | 33,546 |  |  | $ | 23,625 |  |  | $ | 35,997 |  |  | $ | 25,499 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-16-000115:notes:190]
[same as prior period, unchanged from 0000936395-16-000104:notes:196]

[0000936395-16-000115:notes:191]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 467,615 |  |  | $ | 407,970 |  |  | $ | 1,291,956 |  |  | $ | 1,177,441 |  |
| Packet Networking | 63,658 |  |  | 57,209 |  |  | 180,437 |  |  | 165,480 |  |
| Optical Transport | 9,619 |  |  | 17,482 |  |  | 30,215 |  |  | 56,275 |  |
| Total Networking Platforms | 540,892 |  |  | 482,661 |  |  | 1,502,608 |  |  | 1,399,196 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |
| Software Platforms | 12,558 |  |  | 11,258 |  |  | 32,409 |  |  | 28,918 |  |
| Software-Related Services | 19,011 |  |  | 15,338 |  |  | 55,059 |  |  | 45,119 |  |
| Total Software and Software-Related Services | 31,569 |  |  | 26,596 |  |  | 87,468 |  |  | 74,037 |  |
| Global Services |  |  |  |  |  |  |  |
| Maintenance Support and Training | 55,996 |  |  | 59,894 |  |  | 169,123 |  |  | 166,880 |  |
| Installation and Deployment | 31,245 |  |  | 25,161 |  |  | 92,317 |  |  | 82,045 |  |
| Consulting and Network Design | 10,848 |  |  | 8,620 |  |  | 32,866 |  |  | 31,538 |  |
| Total Global Services | 98,089 |  |  | 93,675 |  |  | 294,306 |  |  | 280,463 |  |
| Consolidated revenue | $ | 670,550 |  |  | $ | 602,932 |  |  | $ | 1,884,382 |  |  | $ | 1,753,696 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-16-000115:notes:192]
[same as prior period, unchanged from 0000936395-16-000104:notes:198]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-16-000115:notes:193]
[same as prior period, unchanged from 0000936395-16-000104:notes:199]

[0000936395-16-000115:notes:194]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2016 (in thousands):

[0000936395-16-000115:notes:195]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 2,067 |  |  | (9 | ) |  | 2,058 |  |
| Cash payments | (1,736 | ) |  | (316 | ) |  | (2,052 | ) |
| Balance at July 31, 2016 | $ | 922 |  |  | $ | 363 |  |  | $ | 1,285 |  |
| Current restructuring liabilities | $ | 922 |  |  | $ | 363 |  |  | $ | 1,285 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000936395-16-000115:notes:196]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2015 (in thousands):

[0000936395-16-000115:notes:197]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,260 |  | (a) | — |  |  | 8,260 |  |
| Cash payments | (7,748 | ) |  | (370 | ) |  | (8,118 | ) |
| Balance at July 31, 2015 | $ | 693 |  |  | $ | 764 |  |  | $ | 1,457 |  |
| Current restructuring liabilities | $ | 693 |  |  | $ | 396 |  |  | $ | 1,089 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 368 |  |  | $ | 368 |  |

[0000936395-16-000115:notes:198]
[same as prior period, unchanged from 0000936395-16-000104:notes:204]


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-16-000115:notes:199]
[same as prior period, unchanged from 0000936395-16-000104:notes:205]

[0000936395-16-000115:notes:200]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2016 and July 31, 2015 was 0.3% and 1.9%, respectively.

[0000936395-16-000115:notes:201]
[same as prior period, unchanged from 0000936395-16-000104:notes:207]

[0000936395-16-000115:notes:202]
[same as prior period, unchanged from 0000936395-16-000104:notes:208]

[0000936395-16-000115:notes:203]
[same as prior period, unchanged from 0000936395-16-000104:notes:209]

[0000936395-16-000115:notes:204]
[same as prior period, unchanged from 0000936395-16-000104:notes:210]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-16-000115:notes:205]
[same as prior period, unchanged from 0000936395-16-000104:notes:211]

[0000936395-16-000115:notes:206]
|  | July 31, 2016 |  | October 31, 2015 |
| Compensation, payroll related tax and benefits | $ | 92,492 |  |  | $ | 109,466 |  |
| Warranty | 54,479 |  |  | 56,654 |  |
| Vacation | 36,640 |  |  | 34,189 |  |
| Capital lease obligations | 2,443 |  |  | 4,923 |  |
| Interest payable | 5,909 |  |  | 5,389 |  |
| Other | 105,160 |  |  | 105,662 |  |
|  | $ | 297,123 |  |  | $ | 316,283 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-16-000115:notes:207]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-16-000115:notes:208]
The following is a schedule by fiscal year of future minimum lease payments under capital leases and the present value of minimum lease payments as of July 31, 2016 (in thousands):

[0000936395-16-000115:notes:209]
| Period ended October 31, |  |
| 2016 (remaining three months) | $ | 1,100 |  |
| 2017 | 4,200 |  |
| 2018 | 3,862 |  |
| 2019 | 3,440 |  |
| 2020 | 2,460 |  |
| Thereafter | 30,806 |  |
| Net minimum capital lease payments | 45,868 |  |
| Less: Amount representing interest | (18,023 | ) |
| Present value of minimum lease payments | 27,845 |  |
| Less: Current portion of present value of minimum lease payments | (2,443 | ) |
| Long-term portion of present value of minimum lease payments | $ | 25,402 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-16-000115:notes:210]
[same as prior period, unchanged from 0000936395-16-000104:notes:216]

[0000936395-16-000115:notes:211]
|  | July 31, 2016 |  | October 31, 2015 |
| Maintenance spares, net | $ | 50,510 |  |  | $ | 55,259 |  |
| Deferred debt issuance costs, net | 11,676 |  |  | 10,820 |  |
| Financing receivable | 385 |  |  | 10,107 |  |
| Other | 10,162 |  |  | 8,470 |  |
|  | $ | 72,733 |  |  | $ | 84,656 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-16-000115:notes:212]
[same as prior period, unchanged from 0000936395-16-000104:notes:218]

[0000936395-16-000115:notes:213]
| Nine months ended |  | Beginning |  |  |  |  |  | Ending |
| July 31, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2015 |  | $ | 55,997 |  |  | 12,549 |  |  | (14,712 | ) |  | $ | 53,834 |  |
| 2016 |  | $ | 56,654 |  |  | 13,114 |  |  | (15,289 | ) |  | $ | 54,479 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-16-000115:notes:214]
[same as prior period, unchanged from 0000936395-16-000104:notes:222]

[0000936395-16-000115:notes:215]
|  | July 31, 2016 |  | October 31, 2015 |
| United States | $ | 99,566 |  |  | $ | 96,292 |  |
| Canada | 162,586 |  |  | 84,318 |  |
| Other International | 10,803 |  |  | 11,363 |  |
| Total | $ | 272,955 |  |  | $ | 191,973 |  |

[0000936395-16-000115:notes:216]
[same as prior period, unchanged from 0000936395-16-000104:notes:220]

[0000936395-16-000115:notes:217]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2016 |  | 2015 |  | 2016 |  | 2015 |
| North America | $ | 438,013 |  |  | $ | 389,593 |  |  | $ | 1,226,222 |  |  | $ | 1,118,309 |  |
| EMEA | 104,266 |  |  | 93,168 |  |  | 281,163 |  |  | 306,368 |  |
| CALA | 46,606 |  |  | 65,152 |  |  | 148,312 |  |  | 155,785 |  |
| APAC | 81,665 |  |  | 55,019 |  |  | 228,685 |  |  | 173,234 |  |
| Total | $ | 670,550 |  |  | $ | 602,932 |  |  | $ | 1,884,382 |  |  | $ | 1,753,696 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-16-000115:notes:218]
[same as prior period, unchanged from 0000936395-16-000104:notes:224]

[0000936395-16-000115:notes:219]
[same as prior period, unchanged from 0000936395-16-000104:notes:225]

[0000936395-16-000115:notes:220]
[same as prior period, unchanged from 0000936395-16-000104:notes:226]

[0000936395-16-000115:notes:221]
[same as prior period, unchanged from 0000936395-16-000104:notes:227]

[0000936395-16-000115:notes:222]
[same as prior period, unchanged from 0000936395-16-000104:notes:228]

[0000936395-16-000115:notes:223]
[same as prior period, unchanged from 0000936395-16-000104:notes:229]

[0000936395-16-000115:notes:224]
[same as prior period, unchanged from 0000936395-16-000104:notes:230]

[0000936395-16-000115:notes:225]
[same as prior period, unchanged from 0000936395-16-000104:notes:231]

[0000936395-16-000115:notes:226]
[same as prior period, unchanged from 0000936395-16-000104:notes:232]

[0000936395-16-000115:notes:227]
[same as prior period, unchanged from 0000936395-16-000104:notes:233]

[0000936395-16-000115:notes:228]
[same as prior period, unchanged from 0000936395-16-000104:notes:234]

[0000936395-16-000115:notes:229]
[same as prior period, unchanged from 0000936395-16-000104:notes:235]

[0000936395-16-000115:notes:230]
[same as prior period, unchanged from 0000936395-16-000104:notes:236]

[0000936395-16-000115:notes:231]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2016, equipment, building, furniture and fixtures, net totaling $272.9 million primarily supported asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supported Ciena's unallocated selling and general and administrative activities. As of July 31, 2016, $84.5 million of Ciena's intangible assets, net were assigned to Ciena's Networking Platforms segment and $80.7 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of July 31, 2016, all of the maintenance spares, net, totaling $50.5 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-16-000115:notes:232]
[same as prior period, unchanged from 0000936395-16-000104:notes:238]

[0000936395-16-000115:notes:233]
[same as prior period, unchanged from 0000936395-16-000104:notes:239]

[0000936395-16-000115:notes:234]
[same as prior period, unchanged from 0000936395-16-000104:notes:240]

[0000936395-16-000115:notes:235]
[same as prior period, unchanged from 0000936395-16-000104:notes:241]

[0000936395-16-000115:notes:236]
[same as prior period, unchanged from 0000936395-16-000104:notes:242]

[0000936395-16-000115:notes:237]
North America includes $410.0 million and $360.7 million of United States revenue for fiscal quarters ended July 31, 2016 and 2015, respectively. For the nine months ended July 31, 2016 and 2015, United States revenue was $1.1 billion and $1.0 billion, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-16-000115:notes:238]
[same as prior period, unchanged from 0000936395-16-000104:notes:244]

[0000936395-16-000115:notes:239]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal quarters ended July 31, 2016 and 2015 with  total revenue of $105.4 million and $121.6 million, respectively. AT&T also accounted for greater than 10% of Ciena's revenue for the nine months ended July 31, 2016 and 2015 with total revenue of $348.0 million and $355.6 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-16-000115:notes:240]
[same as prior period, unchanged from 0000936395-16-000104:notes:246]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-16-000115:notes:241]
[same as prior period, unchanged from 0000936395-16-000104:notes:247]

[0000936395-16-000115:notes:242]
[same as prior period, unchanged from 0000936395-16-000104:notes:248]

[0000936395-16-000115:notes:243]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-16-000115:notes:244]
[same as prior period, unchanged from 0000936395-16-000104:notes:250]

[0000936395-16-000115:notes:245]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-16-000115:notes:246]
[same as prior period, unchanged from 0000936395-16-000104:notes:252]

[0000936395-16-000115:notes:247]
[same as prior period, unchanged from 0000936395-16-000104:notes:253]

[0000936395-16-000115:notes:248]
[same as prior period, unchanged from 0000936395-16-000104:notes:254]

[0000936395-16-000115:notes:249]
[same as prior period, unchanged from 0000936395-16-000104:notes:255]

[0000936395-16-000115:notes:250]
[same as prior period, unchanged from 0000936395-16-000104:notes:256]

[0000936395-16-000115:notes:251]
[same as prior period, unchanged from 0000936395-16-000104:notes:257]

[0000936395-16-000115:notes:252]
[same as prior period, unchanged from 0000936395-16-000104:notes:258]

[0000936395-16-000115:notes:253]
[same as prior period, unchanged from 0000936395-16-000104:notes:259]

[0000936395-16-000115:notes:254]
[same as prior period, unchanged from 0000936395-16-000104:notes:260]

[0000936395-16-000115:notes:255]
[same as prior period, unchanged from 0000936395-16-000104:notes:261]

[0000936395-16-000115:notes:256]
[same as prior period, unchanged from 0000936395-16-000104:notes:262]

[0000936395-16-000115:notes:257]
[same as prior period, unchanged from 0000936395-16-000104:notes:263]

[0000936395-16-000115:notes:258]
[same as prior period, unchanged from 0000936395-16-000104:notes:264]

[0000936395-16-000115:notes:259]
[same as prior period, unchanged from 0000936395-16-000104:notes:265]

[0000936395-16-000115:notes:260]
[same as prior period, unchanged from 0000936395-16-000104:notes:266]

[0000936395-16-000115:notes:261]
[same as prior period, unchanged from 0000936395-16-000104:notes:267]

[0000936395-16-000115:notes:262]
[same as prior period, unchanged from 0000936395-16-000104:notes:268]

[0000936395-16-000115:notes:263]
[same as prior period, unchanged from 0000936395-16-000104:notes:269]

[0000936395-16-000115:notes:264]
[same as prior period, unchanged from 0000936395-16-000104:notes:270]

[0000936395-16-000115:notes:265]
[same as prior period, unchanged from 0000936395-16-000104:notes:271]

[0000936395-16-000115:notes:266]
[same as prior period, unchanged from 0000936395-16-000104:notes:272]

[0000936395-16-000115:notes:267]
[same as prior period, unchanged from 0000936395-16-000104:notes:273]

[0000936395-16-000115:notes:268]
[same as prior period, unchanged from 0000936395-16-000104:notes:274]

[0000936395-16-000115:notes:269]
[same as prior period, unchanged from 0000936395-16-000104:notes:275]

[0000936395-16-000115:notes:270]
[same as prior period, unchanged from 0000936395-16-000104:notes:276]

[0000936395-16-000115:notes:271]
[same as prior period, unchanged from 0000936395-16-000104:notes:277]

[0000936395-16-000115:notes:272]
[same as prior period, unchanged from 0000936395-16-000104:notes:278]

[0000936395-16-000115:notes:273]
Loss Contingencies

[0000936395-16-000115:notes:274]
[same as prior period, unchanged from 0000936395-16-000104:notes:280]

[0000936395-16-000115:notes:275]
[same as prior period, unchanged from 0000936395-16-000104:notes:281]

[0000936395-16-000115:notes:276]
[same as prior period, unchanged from 0000936395-16-000104:notes:282]

[0000936395-16-000115:notes:277]
[same as prior period, unchanged from 0000936395-16-000104:notes:283]

[0000936395-16-000115:notes:278]
[same as prior period, unchanged from 0000936395-16-000104:notes:284]

[0000936395-16-000115:notes:279]
[same as prior period, unchanged from 0000936395-16-000104:notes:285]

[0000936395-16-000115:notes:280]
[same as prior period, unchanged from 0000936395-16-000104:notes:286]

[0000936395-16-000115:notes:281]
[same as prior period, unchanged from 0000936395-16-000104:notes:287]

[0000936395-16-000115:notes:282]
[same as prior period, unchanged from 0000936395-16-000104:notes:288]

[0000936395-16-000115:notes:283]
[same as prior period, unchanged from 0000936395-16-000104:notes:289]

[0000936395-16-000115:notes:284]
[same as prior period, unchanged from 0000936395-16-000104:notes:290]

[0000936395-16-000115:notes:285]
[same as prior period, unchanged from 0000936395-16-000104:notes:291]

[0000936395-16-000115:notes:286]
[same as prior period, unchanged from 0000936395-16-000104:notes:292]

[0000936395-16-000115:notes:287]
[same as prior period, unchanged from 0000936395-16-000104:notes:293]

[0000936395-16-000115:notes:288]
[same as prior period, unchanged from 0000936395-16-000104:notes:294]

[0000936395-16-000115:notes:289]
[same as prior period, unchanged from 0000936395-16-000104:notes:295]

[0000936395-16-000115:notes:290]
[same as prior period, unchanged from 0000936395-16-000104:notes:296]

[0000936395-16-000115:notes:291]
[same as prior period, unchanged from 0000936395-16-000104:notes:297]


## us-gaap:SubsequentEventsTextBlock

[0000936395-16-000115:notes:292]
SUBSEQUENT EVENT

[0000936395-16-000115:notes:293]
On August 5, 2016, Ciena repurchased approximately $205 million in aggregate principal amount of its outstanding 0.875% Convertible Senior Notes due 2017 (the “2017 Notes”) in a private transaction, for an aggregate purchase price of approximately $205 million, inclusive of accrued interest. Following the transaction, $245.3 million in aggregate principal amount of the 2017 Notes remain outstanding.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-16-000115:notes:294]
[same as prior period, unchanged from 0000936395-16-000104:notes:298]

[0000936395-16-000115:notes:295]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 17 below), term loans (described in Note 17 below) and ABL Credit Facility (described in Note 18 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $3.1 million and $3.6 million during the first nine months of fiscal 2016 and 2015, respectively.

[0000936395-16-000115:notes:296]
[same as prior period, unchanged from 0000936395-16-000104:notes:300]
