# CIEN MD&A — 0000936395-21-000040


## mdna

[0000936395-21-000040:mdna:1]
[same as prior period, unchanged from 0000936395-21-000034:mdna:1]

[0000936395-21-000040:mdna:2]
[same as prior period, unchanged from 0000936395-21-000034:mdna:2]

[0000936395-21-000040:mdna:3]
[same as prior period, unchanged from 0000936395-21-000034:mdna:3]

[0000936395-21-000040:mdna:4]
[same as prior period, unchanged from 0000936395-21-000034:mdna:4]

[0000936395-21-000040:mdna:5]
This Management’s Discussion and Analysis of Financial Condition and Results of Operations (“MD&A”) should be read in conjunction with our Condensed Consolidated Financial Statements and the accompanying notes thereto included in Item 1 of Part I of this report and our 2020 Annual Report.

[0000936395-21-000040:mdna:6]
[same as prior period, unchanged from 0000936395-21-000034:mdna:6]

[0000936395-21-000040:mdna:7]
[same as prior period, unchanged from 0000936395-21-000034:mdna:7]

[0000936395-21-000040:mdna:8]
Demand for Products & Services. The demand environment for our products and services remains dynamic and continues to be impacted by the effects of the COVID-19 pandemic. For example, we experienced a constrained spending environment during the second half of fiscal 2020 and the first quarter of fiscal 2021 that adversely impacted our revenue during that period. During the second and third quarters of fiscal 2021, we experienced significantly stronger order volumes for our products and services, particularly among a concentrated set of larger customers with which we have existing positions as a supplier. This improved demand environment and growth in order volumes contributed to our increased revenue in the third quarter of fiscal 2021 compared to the second quarter of fiscal 2021. We believe some portion of these orders reflects certain short-term customer purchasing behaviors, including network operators addressing capacity and network requirements following a period of constrained spending in previous quarters, and possible acceleration of future orders due to the implementation of security of supply strategies amidst global supply constraints for semiconductor components. Over the longer term, we continue to believe that the increased demands placed on network infrastructures as a result of the COVID-19 pandemic, and the related increase in remote working worldwide, have accelerated certain trends, including cloud network adoption, networking resilience and flexibility, and enhanced network automation.

[0000936395-21-000040:mdna:9]
Services and Customer Fulfillment. We continue to experience some disruption in our ability to provide installation, professional and fulfillment services to customers due to site readiness and access limitations, limited customer availability, project delays or re-prioritization by customers, and travel bans or restrictions on movement or gatherings. We have also experienced some disruption and delays in our supply chain operations and logistics, including shipping delays and higher transport costs. We expect these conditions to persist in the short term and, as a result, to continue to adversely impact our revenue and results of operations.

[0000936395-21-000040:mdna:10]
[same as prior period, unchanged from 0000936395-21-000034:mdna:10]

[0000936395-21-000040:mdna:11]
Canada Emergency Wage Subsidy (“CEWS”). In April 2020, the government of Canada introduced the CEWS program to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. Amounts from the CEWS program positively impacted our operating expense and measures of profit in the quarter and nine months ended July 31, 2021. For the third quarter of fiscal 2021, we recorded CEWS benefits of

[0000936395-21-000040:mdna:12]
CAD$1.1 million ($0.8 million), net of certain fees. For the nine months ended July 31, 2021, we recorded CEWS benefits of CAD$52.2 million ($41.3 million), net of certain fees, related to claim periods beginning March 15, 2020, including CAD$43.9 million ($35.2 million) related to employee wages from fiscal 2020. The CEWS program is of a limited duration. We do not anticipate a similar proportionate impact on our financial results in future periods and may not receive any benefits from the CEWS program in the future.

[0000936395-21-000040:mdna:13]
The COVID-19 pandemic and countermeasures taken to contain its spread have caused economic and financial disruptions globally. We continue to monitor the situation and actively assess further implications to our business, supply chain, fulfillment operations and customer demand. However, the COVID-19 situation remains dynamic. Variants continue to emerge and the duration and severity of the impact of COVID-19 on our business and results of operations in future periods remains uncertain. If the COVID-19 pandemic or its adverse effects become more severe or prevalent or are prolonged in the locations where we, our customers, suppliers or manufacturers conduct business, or we experience more pronounced disruptions in our business or operations, or in economic activity and demand for our products and services generally, our business and results of operations in future periods could be materially adversely affected.

[0000936395-21-000040:mdna:14]
Supply Chain Constraints

[0000936395-21-000040:mdna:15]
Due to increased demand across a range of industries, the global supply market for certain raw materials and components, including in particular the semiconductor components used in most of our products, has experienced significant strain in recent periods. These conditions, which worsened during our third quarter of fiscal 2021, have been exacerbated in part by the COVID-19 pandemic. As a result, we have experienced ongoing component shortages, longer lead times and increased cost of components. In turn, these conditions have impacted the lead times for our products, and could adversely impact our ability to meet customer demand where we cannot timely secure supply of these components. In response, we have implemented mitigation strategies and increased our purchases of inventory for certain components. In some cases, we have incurred higher costs to secure available inventory, or have extended our purchase commitments or placed non-cancellable orders with suppliers, which introduces inventory risk if our forecasts and assumptions are inaccurate. Despite our attempts to mitigate the impact on our business, these constrained supply conditions are expected to adversely impact our costs of goods sold, including our ability to continue to reduce the cost to produce our products in a manner consistent with prior periods. In addition, some of our suppliers have indicated that, as a result of current constraints, they intend to cease manufacturing of certain components used in our products. These dynamics and our resulting mitigating actions may result in increased materials costs or use of cash, and could adversely impact our growth, gross margin and results of operations. We believe these supply chain challenges and their adverse impact on our business will persist at least through the first half of fiscal 2022. See “Risk Factors” in Item 1A of Part II of this report and Item 1A of Part I of our 2020 Annual Report for further discussion of risks related to our supply chain.

[0000936395-21-000040:mdna:16]
Supply Chain and Distribution Structure; Recognition of Deferred Tax Asset in Third Quarter of Fiscal 2021

[0000936395-21-000040:mdna:17]
To better accommodate the requirements of a global business, we are implementing a plan to reorganize our global supply chain and distribution structure more substantially, which includes a legal entity reorganization and related system upgrade. We completed the first phase of this plan in the third quarter of fiscal 2021 and expect to continue to implement the plan during the remainder of fiscal 2021. As part of this reorganization, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $124.2 million deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in our effective tax rate for the quarter and nine months ended July 31, 2021, which had a significant, one-time impact on our net income for these periods.

[0000936395-21-000040:mdna:18]
[same as prior period, unchanged from 0000936395-21-000034:mdna:16]

[0000936395-21-000040:mdna:19]
[same as prior period, unchanged from 0000936395-21-000034:mdna:17]

[0000936395-21-000040:mdna:20]
[same as prior period, unchanged from 0000936395-21-000034:mdna:18]

[0000936395-21-000040:mdna:21]
[same as prior period, unchanged from 0000936395-21-000034:mdna:19]

[0000936395-21-000040:mdna:22]
[same as prior period, unchanged from 0000936395-21-000034:mdna:20]

[0000936395-21-000040:mdna:23]
[same as prior period, unchanged from 0000936395-21-000034:mdna:21]

[0000936395-21-000040:mdna:24]
Approximately 16.3% and 17.3% of our revenue was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2021, respectively, primarily including sales in Euros, Canadian Dollars and Brazilian Reais. During the third quarter of fiscal 2021, as compared to the third quarter of fiscal 2020, and during the first nine months of fiscal 2021, as compared to the first nine months of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue for the third quarter and first nine months of fiscal 2021 reported in U.S. Dollars was adversely impacted by approximately $9.8 million, or 1.0%, and $18.5 million, or 0.7%, respectively.

[0000936395-21-000040:mdna:25]
[same as prior period, unchanged from 0000936395-21-000034:mdna:23]

[0000936395-21-000040:mdna:26]
[same as prior period, unchanged from 0000936395-21-000034:mdna:24]

[0000936395-21-000040:mdna:27]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | 722,512 |  |  |  |  | (1.3) | % |  | $ | 1,798,888 |  |  | $ | 1,968,355 |  |  |  |  | (8.6) | % |
| %** | 72.1 | % |  | 74.0 | % |  |  |  |  |  | 69.7 | % |  | 72.8 | % |  |  |  |  |
| Routing and Switching | 69,698 |  |  | 79,756 |  |  |  |  | (12.6) | % |  | 197,632 |  |  | 211,432 |  |  |  |  | (6.5) | % |
| %** | 7.1 | % |  | 8.1 | % |  |  |  |  |  | 7.7 | % |  | 7.8 | % |  |  |  |  |
| Total Networking Platforms | 782,604 |  |  | 802,268 |  |  |  |  | (2.5) | % |  | 1,996,520 |  |  | 2,179,787 |  |  |  |  | (8.4) | % |
| %** | 79.2 | % |  | 82.1 | % |  |  |  |  |  | 77.4 | % |  | 80.6 | % |  |  |  |  |
| Platform Software and Services | 56,945 |  |  | 46,422 |  |  |  |  | 22.7 | % |  | 163,472 |  |  | 143,295 |  |  |  |  | 14.1 | % |
| %** | 5.8 | % |  | 4.8 | % |  |  |  |  |  | 6.4 | % |  | 5.3 | % |  |  |  |  |
| Blue Planet Automation Software and Services | 16,607 |  |  | 11,297 |  |  |  |  | 47.0 | % |  | 57,499 |  |  | 41,779 |  |  |  |  | 37.6 | % |
| %** | 1.7 | % |  | 1.1 | % |  |  |  |  |  | 2.2 | % |  | 1.6 | % |  |  |  |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 74,006 |  |  | 69,099 |  |  |  |  | 7.1 | % |  | 212,054 |  |  | 202,370 |  |  |  |  | 4.8 | % |
| %** | 7.5 | % |  | 7.1 | % |  |  |  |  |  | 8.2 | % |  | 7.5 | % |  |  |  |  |
| Installation and Deployment | 46,653 |  |  | 39,798 |  |  |  |  | 17.2 | % |  | 124,263 |  |  | 108,994 |  |  |  |  | 14.0 | % |
| %** | 4.7 | % |  | 4.1 | % |  |  |  |  |  | 4.8 | % |  | 4.0 | % |  |  |  |  |
| Consulting and Network Design | 11,326 |  |  | 7,828 |  |  |  |  | 44.7 | % |  | 25,390 |  |  | 27,452 |  |  |  |  | (7.5) | % |
| %** | 1.1 | % |  | 0.8 | % |  |  |  |  |  | 1.0 | % |  | 1.0 | % |  |  |  |  |
| Total Global Services | 131,985 |  |  | 116,725 |  |  |  |  | 13.1 | % |  | 361,707 |  |  | 338,816 |  |  |  |  | 6.8 | % |
| %** | 13.3 | % |  | 12.0 | % |  |  |  |  |  | 14.0 | % |  | 12.5 | % |  |  |  |  |
| Consolidated revenue | $ | 988,141 |  |  | $ | 976,712 |  |  |  |  | 1.2 | % |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |  |  |  | (4.6) | % |

[0000936395-21-000040:mdna:28]
[same as prior period, unchanged from 0000936395-21-000034:mdna:26]

[0000936395-21-000040:mdna:29]
[same as prior period, unchanged from 0000936395-21-000034:mdna:27]

[0000936395-21-000040:mdna:30]
[same as prior period, unchanged from 0000936395-21-000034:mdna:28]

[0000936395-21-000040:mdna:31]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:32]
•Networking Platforms segment revenue decreased by $19.7 million, reflecting product line sales decreases of $10.1 million of our Routing and Switching products and $9.6 million of our Converged Packet Optical products.

[0000936395-21-000040:mdna:33]
◦Routing and Switching sales decreased, primarily reflecting a sales decrease of $9.0 million of our 3000 and 5000 families of service delivery and aggregation switches to enterprise customers and cable and multiservice operators.

[0000936395-21-000040:mdna:34]
◦Converged Packet Optical sales decreased, primarily reflecting a sales decrease of $35.8 million of our Waveserver® products to Web-scale providers. This sales decrease was partially offset by sales increases of $14.0 million of our 6500 Reconfigurable Line System (RLS) products to communications service providers and cable and multiservice operators and $8.0 million of our 6500 Packet-Optical Platform primarily to communications service providers and Web-scale providers.

[0000936395-21-000040:mdna:35]
•Platform Software and Services segment revenue increased by $10.5 million, reflecting sales increases of $9.4 million in software services and $1.1 million in sales of software platforms.

[0000936395-21-000040:mdna:36]
•Blue Planet Automation Software and Services segment revenue increased by $5.3 million, reflecting sales increases of $4.0 million in sales of software platforms and $1.3 million in related services.

[0000936395-21-000040:mdna:37]
•Global Services segment revenue increased by $15.3 million, reflecting sales increases of $6.9 million of our installation and deployment services, $4.9 million of our maintenance support and training services and $3.5 million of our consulting and network design services.

[0000936395-21-000040:mdna:38]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:39]
•Networking Platforms segment revenue decreased by $183.3 million, reflecting product line sales decreases of $169.5 million of our Converged Packet Optical products and $13.8 million of our Routing and Switching products.

[0000936395-21-000040:mdna:40]
◦Converged Packet Optical sales decreased, primarily reflecting decreases of $181.9 million of our 6500 Packet-Optical Platform and $42.1 million of our 5430 Reconfigurable Switching Systems, each primarily to communications service providers. These sales decreases, related to the demand environment conditions described above, were partially offset by sales increases of $31.3 million of our 6500 RLS products and $27.4 million of our Waveserver® products, each of which primarily benefited from increased sales to communications service providers.

[0000936395-21-000040:mdna:41]
◦Routing and Switching sales decreased, primarily reflecting sales decreases of $15.7 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily to cable and multiservice operators, and $7.1 million of our 6500 Packet Transport System (PTS) to communications service providers. These decreases were offset by a sales increase of $9.0 million of our platform independent software to a communications service provider.

[0000936395-21-000040:mdna:42]
•Platform Software and Services segment revenue increased by $20.2 million, reflecting an increase of $24.2 million in software services, offset by a decrease of $4.0 million in sales of software platforms.

[0000936395-21-000040:mdna:43]
•Blue Planet Automation Software and Services segment revenue increased by $15.7 million, reflecting increases of $12.8 million in sales of software platforms and $2.9 million in related services.

[0000936395-21-000040:mdna:44]
•Global Services segment revenue increased by $22.9 million, primarily reflecting sales increases of $15.3 million of our installation and deployment services and $9.7 million of our maintenance support and training, partially offset by a sales decrease of $2.1 million of our consulting and network design services.

[0000936395-21-000040:mdna:45]
[same as prior period, unchanged from 0000936395-21-000034:mdna:43]

[0000936395-21-000040:mdna:46]
Our operating segments engage in business and operations across three geographic regions: Americas; Europe, Middle East and Africa (“EMEA”); and Asia Pacific, Japan and India (“APAC”). The geographic distribution of our revenue can fluctuate significantly from period to period, and the timing of revenue recognition for large network projects, particularly outside of the United States, can result in large variations in geographic revenue results in any particular period. The increase in our EMEA region revenue for the quarter and nine months ended July 31, 2021 was primarily driven by increased sales in France and The Netherlands. The increase in our APAC region revenue for the quarter ended July 31, 2021 was primarily driven by increased sales in India. The decrease in our APAC region revenue for the nine months ended July 31, 2021 was primarily driven by decreased sales in Singapore and Japan, partially offset by increased sales in India. The decrease in our Americas region revenue for the quarter and nine months ended July 31, 2021 was primarily driven by decreased sales in the United States, partially offset by increased sales in Canada.

[0000936395-21-000040:mdna:47]
[same as prior period, unchanged from 0000936395-21-000034:mdna:45]

[0000936395-21-000040:mdna:48]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Americas | $ | 692,853 |  |  | $ | 713,340 |  |  |  |  | (2.9) | % |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |  |  |  | (8.3) | % |
| %** | 70.1 | % |  | 73.0 | % |  |  |  |  |  | 68.9 | % |  | 71.7 | % |  |  |  |  |
| EMEA | 189,180 |  |  | 162,465 |  |  |  |  | 16.4 | % |  | 499,652 |  |  | 433,861 |  |  |  |  | 15.2 | % |
| %** | 19.2 | % |  | 16.6 | % |  |  |  |  |  | 19.4 | % |  | 16.0 | % |  |  |  |  |
| APAC | 106,108 |  |  | 100,907 |  |  |  |  | 5.2 | % |  | 302,607 |  |  | 332,091 |  |  |  |  | (8.9) | % |
| %** | 10.7 | % |  | 10.4 | % |  |  |  |  |  | 11.7 | % |  | 12.3 | % |  |  |  |  |
| Total | $ | 988,141 |  |  | $ | 976,712 |  |  |  |  | 1.2 | % |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |  |  |  | (4.6) | % |

[0000936395-21-000040:mdna:49]
[same as prior period, unchanged from 0000936395-21-000034:mdna:47]

[0000936395-21-000040:mdna:50]
[same as prior period, unchanged from 0000936395-21-000034:mdna:48]

[0000936395-21-000040:mdna:51]
[same as prior period, unchanged from 0000936395-21-000034:mdna:49]

[0000936395-21-000040:mdna:52]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:53]
•Americas revenue decreased by $20.5 million, primarily reflecting a sales decrease of $34.8 million within our Networking Platforms segment, partially offset by sales increases of $5.9 million within our Global Services segment, $5.4 million within our Platform Software and Services segment, and $3.0 million within our Blue Planet Automation Software and Services segment. The decrease within our Networking Platforms segment primarily reflects a product line sales decrease of $28.4 million of our Converged Packet Optical products, primarily related to a sales decrease of $55.8 million of our Waveserver® products to Web-scale providers.

[0000936395-21-000040:mdna:54]
•EMEA revenue increased by $26.7 million, primarily reflecting sales increases of $14.3 million within our Networking Platforms segment, $7.9 million within our Global Services segment, $2.3 million within our Platform Software and Services segment, and $2.2 million within our Blue Planet Automation Software and Services segment. These sales increases were primarily due to increased sales to Web-scale providers in the Netherlands.

[0000936395-21-000040:mdna:55]
•APAC revenue increased by $5.2 million, primarily reflecting sales increases of $2.8 million within our Platform Software and Services segment, $1.4 million within our Global Services segment, and $1.0 million within our Networking Platforms segment.

[0000936395-21-000040:mdna:56]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:57]
•Americas revenue decreased by $160.8 million, primarily reflecting a sales decrease of $184.1 million within our Networking Platforms segment, which was partially offset by sales increases of $10.1 million within our Blue Planet Automation Software and Services segment, $7.8 million within our Global Services segment and $5.4 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease reflects product line sales decreases of $169.7 million of Converged Packet Optical products and $14.4 million of Routing and Switching products. Our Converged Packet Optical revenue decrease primarily reflects sales decreases of $134.9 million of our 6500 Packet-Optical Platform and $33.3 million of our Waveserver® products, partially offset by a sales increase of $28.4 million of our 6500 RLS products. Our 6500 Packet-Optical Platform revenue decrease primarily reflects decreased sales to communications service providers.

[0000936395-21-000040:mdna:58]
•EMEA revenue increased by $65.8 million, reflecting increases of $35.3 million within our Networking Platforms segment, $15.4 million within our Global Services segment, $7.6 million within our Platform Software and Services segment and $7.4 million within our Blue Planet Automation Software and Services segment. These sales increases were primarily due to increased sales to Web-scale providers in the Netherlands and communications service providers in France.

[0000936395-21-000040:mdna:59]
•APAC revenue decreased by $29.5 million, primarily reflecting decreases of $34.5 million within our Networking Platforms segment and $1.8 million within our Blue Planet Automation Software and Services segment. These decreases were partially offset by a sales increase of $7.2 million within our Platform Software and Services segment. Our Networking Platforms segment revenue decrease primarily reflects a decrease of $45.8 million in sales of our 6500 Packet-Optical Platform to communications service providers in Japan, partially offset by an increase of $14.4 million in sales of our Waveserver® products, primarily to communications service providers and submarine network operators.

[0000936395-21-000040:mdna:60]
[same as prior period, unchanged from 0000936395-21-000034:mdna:59]

[0000936395-21-000040:mdna:61]
[same as prior period, unchanged from 0000936395-21-000034:mdna:60]

[0000936395-21-000040:mdna:62]
For the third quarter of fiscal 2021, and first nine months of fiscal 2021, we recorded CEWS benefits of $0.1 million, net of certain fees, and $7.0 million, net of certain fees, respectively, related to the particular line item within cost of goods sold in our Condensed Consolidated Statement of Operations to which the activity relates. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The tables below set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated (in thousands, except percentage data):

[0000936395-21-000040:mdna:63]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Total revenue | $ | 988,141 |  |  | $ | 976,712 |  |  |  |  | 1.2 | % |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |  |  |  | (4.6) | % |
| Total cost of goods sold | 513,591 |  |  | 512,031 |  |  |  |  | 0.3 | % |  | 1,334,338 |  |  | 1,455,135 |  |  |  |  | (8.3) | % |
| Gross profit | $ | 474,550 |  |  | $ | 464,681 |  |  |  |  | 2.1 | % |  | $ | 1,244,860 |  |  | $ | 1,248,542 |  |  |  |  | (0.3) | % |
| %** | 48.0 | % |  | 47.6 | % |  |  |  |  |  | 48.3 | % |  | 46.2 | % |  |  |  |  |

[0000936395-21-000040:mdna:64]
[same as prior period, unchanged from 0000936395-21-000034:mdna:63]

[0000936395-21-000040:mdna:65]
[same as prior period, unchanged from 0000936395-21-000034:mdna:64]

[0000936395-21-000040:mdna:66]
[same as prior period, unchanged from 0000936395-21-000034:mdna:65]

[0000936395-21-000040:mdna:67]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Product revenue | $ | 804,414 |  |  | $ | 819,022 |  |  |  |  | (1.8) | % |  | $ | 2,071,677 |  |  | $ | 2,246,129 |  |  |  |  | (7.8) | % |
| Product cost of goods sold | 420,236 |  |  | 436,227 |  |  |  |  | (3.7) | % |  | 1,074,935 |  |  | 1,230,378 |  |  |  |  | (12.6) | % |
| Product gross profit | $ | 384,178 |  |  | $ | 382,795 |  |  |  |  | 0.4 | % |  | $ | 996,742 |  |  | $ | 1,015,751 |  |  |  |  | (1.9) | % |
| %** | 47.8 | % |  | 46.7 | % |  |  |  |  |  | 48.1 | % |  | 45.2 | % |  |  |  |  |

[0000936395-21-000040:mdna:68]
[same as prior period, unchanged from 0000936395-21-000034:mdna:67]

[0000936395-21-000040:mdna:69]
[same as prior period, unchanged from 0000936395-21-000034:mdna:68]

[0000936395-21-000040:mdna:70]
[same as prior period, unchanged from 0000936395-21-000034:mdna:69]

[0000936395-21-000040:mdna:71]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Service revenue | $ | 183,727 |  |  | $ | 157,690 |  |  |  |  | 16.5 | % |  | $ | 507,521 |  |  | $ | 457,548 |  |  |  |  | 10.9 | % |
| Service cost of goods sold | 93,355 |  |  | 75,804 |  |  |  |  | 23.2 | % |  | 259,403 |  |  | 224,757 |  |  |  |  | 15.4 | % |
| Service gross profit | $ | 90,372 |  |  | $ | 81,886 |  |  |  |  | 10.4 | % |  | $ | 248,118 |  |  | $ | 232,791 |  |  |  |  | 6.6 | % |
| % ** | 49.2 | % |  | 51.9 | % |  |  |  |  |  | 48.9 | % |  | 50.9 | % |  |  |  |  |

[0000936395-21-000040:mdna:72]
[same as prior period, unchanged from 0000936395-21-000034:mdna:71]

[0000936395-21-000040:mdna:73]
[same as prior period, unchanged from 0000936395-21-000034:mdna:72]

[0000936395-21-000040:mdna:74]
[same as prior period, unchanged from 0000936395-21-000034:mdna:73]

[0000936395-21-000040:mdna:75]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:76]
•Gross profit increased by $9.9 million. Gross profit as a percentage of total revenue (“gross margin”) increased by 40 basis points. Our gross margin benefited slightly from a favorable mix of customers and products. Due to the impact of COVID-19 and related restrictions on sales and marketing activities described in “Overview” above, we continue to see a higher proportion of our revenue consisting of sales of existing technology offerings deployed in the networks of existing customers, as compared to sales to new customers, early stage network deployments for recent design wins, or the introduction of new platforms, which tend to carry lower margins. We expect our gross margins to reduce from these elevated short-term levels as the adverse impact of the pandemic on new business lessens and our overall

[0000936395-21-000040:mdna:77]
revenue resumes a more typical composition of revenue from existing and new business. Moreover, consistent with the discussion in “Overview” above, we expect the current market shortage for semiconductor components and constrained supply environment to continue during our fourth quarter of fiscal 2021 and at least through the first half of fiscal 2022. These conditions, and our attempts to mitigate their impact on our business, are expected to adversely impact our costs of goods sold on products and ability to continue to reduce the cost to produce our products consistent with prior periods.

[0000936395-21-000040:mdna:78]
•Gross profit on products increased by $1.4 million. Gross profit on products as a percentage of product revenue (“product gross margin”) increased by 110 basis points, primarily due to a favorable mix of customer and products and product cost reductions, partially offset by market-based price compression we encountered during the period.

[0000936395-21-000040:mdna:79]
•Gross profit on services increased by $8.5 million. Gross profit as a percentage of services revenue (“services gross margin”) decreased by 270 basis points, primarily due to higher provisions associated with our annual cash incentive compensation plan.

[0000936395-21-000040:mdna:80]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:81]
•Gross profit decreased by $3.7 million, largely due to lower revenues. Gross margin increased by 210 basis points, as our gross margin benefited significantly from product cost reductions and a $7.0 million benefit from the CEWS program, partially offset by market-based price compression we encountered during the period and a reduction in our services gross margin.

[0000936395-21-000040:mdna:82]
•Gross profit on products decreased by $19.0 million. Product gross margin increased by 290 basis points, primarily due to product cost reductions, a favorable mix of customers and product lines as described above and a $4.3 million benefit from the CEWS program, partially offset by market-based price compression we encountered during the period.

[0000936395-21-000040:mdna:83]
•Gross profit on services increased by $15.3 million. Services gross margin decreased by 200 basis points, primarily due to lower installation and deployment margins. The lower margins on installation and deployment services were primarily due to certain customer site readiness delays that caused cost inefficiencies and higher provisions associated with our annual cash incentive compensation plan. These lower margins were partially offset by a $2.7 million benefit from the CEWS program.

[0000936395-21-000040:mdna:84]
[same as prior period, unchanged from 0000936395-21-000034:mdna:82]

[0000936395-21-000040:mdna:85]
[same as prior period, unchanged from 0000936395-21-000034:mdna:83]

[0000936395-21-000040:mdna:86]
Approximately 51.6% and 48.9% of our operating expense was non-U.S. Dollar-denominated during the third quarter and first nine months of fiscal 2021, respectively, including expenses in Canadian Dollars, Indian Rupees and British Pounds. During the third quarter of fiscal 2021, as compared to the third quarter of fiscal 2020, and the first nine months of fiscal 2021, as compared to the first nine months of fiscal 2020, the U.S. Dollar fluctuated against these currencies. Consequently, our operating expense reported in U.S. Dollars slightly increased by approximately $8.3 million, or 2.0%, and $13.1 million, or 1.3%, respectively.

[0000936395-21-000040:mdna:87]
CEWS Program Benefits

[0000936395-21-000040:mdna:88]
In the third quarter of fiscal 2021, and the first nine months of fiscal 2021, we recorded CEWS benefits of $0.7 million, net of certain fees and $34.3 million, net of certain fees, respectively, related to the particular line item within operating expense in our Condensed Consolidated Statement of Operations to which the activity relates. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:89]
[same as prior period, unchanged from 0000936395-21-000034:mdna:87]

[0000936395-21-000040:mdna:90]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Research and development | $ | 146,225 |  |  | $ | 130,221 |  |  |  |  | 12.3 | % |  | $ | 389,212 |  |  | $ | 392,651 |  |  |  |  | (0.9) | % |
| %** | 14.8 | % |  | 13.3 | % |  |  |  |  |  | 15.1 | % |  | 14.5 | % |  |  |  |  |
| Selling and marketing | 114,924 |  |  | 94,763 |  |  |  |  | 21.3 | % |  | 322,589 |  |  | 303,043 |  |  |  |  | 6.4 | % |
| %** | 11.6 | % |  | 9.7 | % |  |  |  |  |  | 12.5 | % |  | 11.2 | % |  |  |  |  |
| General and administrative | 48,863 |  |  | 41,635 |  |  |  |  | 17.4 | % |  | 132,491 |  |  | 126,133 |  |  |  |  | 5.0 | % |
| %** | 4.9 | % |  | 4.3 | % |  |  |  |  |  | 5.1 | % |  | 4.7 | % |  |  |  |  |
| Significant asset impairments and restructuring costs | 9,789 |  |  | 6,515 |  |  |  |  | 50.3 | % |  | 23,865 |  |  | 14,798 |  |  |  |  | 61.3 | % |
| %** | 1.0 | % |  | 0.7 | % |  |  |  |  |  | 0.9 | % |  | 0.5 | % |  |  |  |  |
| Amortization of intangible assets | 5,967 |  |  | 5,840 |  |  |  |  | 2.2 | % |  | 17,896 |  |  | 17,532 |  |  |  |  | 2.1 | % |
| %** | 0.6 | % |  | 0.6 | % |  |  |  |  |  | 0.7 | % |  | 0.6 | % |  |  |  |  |
| Acquisition and integration costs (recoveries) | 259 |  |  | (2,329) |  |  |  |  | (111.1) | % |  | 860 |  |  | 904 |  |  |  |  | (4.9) | % |
| %** | — | % |  | (0.2) | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Total operating expenses | $ | 326,027 |  |  | $ | 276,645 |  |  |  |  | 17.9 | % |  | $ | 886,913 |  |  | $ | 855,061 |  |  |  |  | 3.7 | % |
| %** | 33.0 | % |  | 28.4 | % |  |  |  |  |  | 34.4 | % |  | 31.5 | % |  |  |  |  |

[0000936395-21-000040:mdna:91]
[same as prior period, unchanged from 0000936395-21-000034:mdna:89]

[0000936395-21-000040:mdna:92]
[same as prior period, unchanged from 0000936395-21-000034:mdna:90]

[0000936395-21-000040:mdna:93]
[same as prior period, unchanged from 0000936395-21-000034:mdna:91]

[0000936395-21-000040:mdna:94]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:95]
•Research and development expense was adversely affected by $4.8 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, net of hedging, research and development expense increased by $16.0 million. This primarily reflects an increase in employee headcount and related compensation costs, and higher provisions associated with our annual cash incentive compensation plan, partially offset by a decrease in professional services.

[0000936395-21-000040:mdna:96]
•Selling and marketing expense was adversely affected by $2.8 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $20.2 million. This increase primarily reflects an increase in employee related compensation costs due to higher commission expense and higher provisions associated with our annual cash incentive compensation plan.

[0000936395-21-000040:mdna:97]
•General and administrative expense increased by $7.2 million, primarily as a result of higher provisions associated with our annual cash incentive compensation plan, partially offset by decreased bad debt expense.

[0000936395-21-000040:mdna:98]
•Significant asset impairments and restructuring costs reflects actions we have taken to redesign certain business processes and better align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-21-000040:mdna:99]
[same as prior period, unchanged from 0000936395-21-000034:mdna:97]

[0000936395-21-000040:mdna:100]
•Acquisition and integration costs (recoveries) primarily reflects reduced acquisition compensation and recoveries of acquisition consideration associated with a three-year earn-out arrangement in the third quarter of fiscal 2020 related to the acquisition of DonRiver Holdings, LLC (“Don River”) in fiscal 2018.

[0000936395-21-000040:mdna:101]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:102]
•Research and development expense was adversely affected by $5.3 million as a result of foreign exchange rates, net of hedging, primarily due to fluctuations in the U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, net of hedging, research and development expenses decreased by $3.4 million. This decrease primarily reflects $29.5 million received from the CEWS program and decreases in professional services, partially offset by higher provisions associated with our annual cash incentive compensation plan.

[0000936395-21-000040:mdna:103]
•Selling and marketing expense was adversely affected by $6.4 million as a result of foreign exchange rates, primarily due to fluctuations in the U.S. Dollar in relation to the Euro, Canadian Dollar and Australian Dollar. Including the

[0000936395-21-000040:mdna:104]
effect of foreign exchange rates, sales and marketing expense increased by $19.5 million. This increase primarily reflects an increase in compensation costs, partially offset by decreases in travel and entertainment costs due to restrictions on travel as a result of COVID-19, and $2.6 million received from the CEWS program.

[0000936395-21-000040:mdna:105]
•General and administrative expense was adversely affected by $1.5 million as a result of foreign exchange rates, primarily due to a weaker U.S. Dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expenses increased by $6.4 million. This increase primarily reflects higher provisions associated with our annual cash incentive compensation plan and legal fees, partially offset by reduced bad debt expense.

[0000936395-21-000040:mdna:106]
•Significant asset impairments and restructuring costs reflects actions we have taken to redesign certain business processes and better align our global workforce and facilities as part of a business optimization strategy to improve gross margin and constrain operating expense.

[0000936395-21-000040:mdna:107]
[same as prior period, unchanged from 0000936395-21-000034:mdna:104]

[0000936395-21-000040:mdna:108]
•Acquisition and integration costs (recoveries) primarily reflects reduced acquisition compensation and recoveries of acquisition consideration associated with a three-year earn-out arrangement in the third quarter of fiscal 2020 related to the acquisition of DonRiver in fiscal 2018, and other fees related to the acquisition of Centina Systems, Inc. in the first quarter of fiscal 2020.

[0000936395-21-000040:mdna:109]
[same as prior period, unchanged from 0000936395-21-000034:mdna:107]

[0000936395-21-000040:mdna:110]
[same as prior period, unchanged from 0000936395-21-000034:mdna:108]

[0000936395-21-000040:mdna:111]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Interest and other income (loss), net | $ | 795 |  |  | $ | 232 |  |  |  |  | 242.7 | % |  | $ | (1,600) |  |  | $ | 1,213 |  |  |  |  | (231.9) | % |
| %** | 0.1 | % |  | — | % |  |  |  |  |  | (0.1) | % |  | — | % |  |  |  |  |
| Interest expense | $ | 7,776 |  |  | $ | 7,251 |  |  |  |  | 7.2 | % |  | $ | 22,921 |  |  | $ | 23,926 |  |  |  |  | (4.2) | % |
| %** | 0.8 | % |  | 0.7 | % |  |  |  |  |  | 0.9 | % |  | 0.9 | % |  |  |  |  |
| Loss on extinguishment and modification of debt | $ | — |  |  | $ | — |  |  |  |  | — | % |  | $ | — |  |  | $ | 646 |  |  |  |  | (100.0) | % |
| %** | — | % |  | — | % |  |  |  |  |  | — | % |  | — | % |  |  |  |  |
| Provision (benefit) for income taxes | $ | (96,690) |  |  | $ | 38,750 |  |  |  |  | (349.5) | % |  | $ | (63,271) |  |  | $ | 73,872 |  |  |  |  | (185.6) | % |
| %** | (9.8) | % |  | 4.0 | % |  |  |  |  |  | (2.5) | % |  | 2.7 | % |  |  |  |  |

[0000936395-21-000040:mdna:112]
[same as prior period, unchanged from 0000936395-21-000034:mdna:110]

[0000936395-21-000040:mdna:113]
[same as prior period, unchanged from 0000936395-21-000034:mdna:111]

[0000936395-21-000040:mdna:114]
[same as prior period, unchanged from 0000936395-21-000034:mdna:112]

[0000936395-21-000040:mdna:115]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:116]
•Interest and other income (loss), net remained relatively unchanged.

[0000936395-21-000040:mdna:117]
[same as prior period, unchanged from 0000936395-21-000034:mdna:115]

[0000936395-21-000040:mdna:118]
•Provision (benefit) for income taxes decreased by $135.4 million, primarily due to the $124.2 million tax benefit associated with recording a deferred tax asset in the third quarter of fiscal 2021. The effective tax rate for the third quarter of 2021 was lower as compared to the third quarter of fiscal 2020, primarily due to the tax benefit associated with recording a deferred tax asset. For further discussion, see Note 7 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:119]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:120]
•Interest and other income (loss), net decreased by $2.8 million, primarily reflecting lower interest income due to reduced interest rates on our investments partially offset by the impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity.

[0000936395-21-000040:mdna:121]
•Interest expense decreased by $1.0 million, primarily due to a reduction of LIBOR rates impacting our new senior secured term loan, entered into on January 23, 2020, in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-21-000040:mdna:122]
[same as prior period, unchanged from 0000936395-21-000034:mdna:120]

[0000936395-21-000040:mdna:123]
•Provision for income taxes decreased by $137.1 million, primarily due to the $124.2 million tax benefit associated with recording a deferred tax asset for the first nine months of fiscal 2021. The effective tax rate for the first nine months of fiscal 2021 was lower as compared to the first nine months of fiscal 2020, primarily due to the tax benefit associated with recording a deferred tax asset. For further discussion, see Note 7 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:124]
[same as prior period, unchanged from 0000936395-21-000034:mdna:122]

[0000936395-21-000040:mdna:125]
[same as prior period, unchanged from 0000936395-21-000034:mdna:123]

[0000936395-21-000040:mdna:126]
|  | Quarter Ended |  |  |  |  |  | Nine Months Ended |  |  |  |  |
|  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |  | July 31, 2021 |  | August 1, 2020 |  |  |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms | $ | 244,535 |  |  | $ | 262,801 |  |  |  |  | (7.0) | % |  | $ | 612,378 |  |  | $ | 642,057 |  |  |  |  | (4.6) | % |
| Platform Software and Services | $ | 31,526 |  |  | $ | 24,299 |  |  |  |  | 29.7 | % |  | $ | 95,692 |  |  | $ | 74,918 |  |  |  |  | 27.7 | % |
| Blue Planet Automation Software and Services | $ | (3,243) |  |  | $ | (5,316) |  |  |  |  | 39.0 | % |  | $ | 11 |  |  | $ | (12,828) |  |  |  |  | 100.1 | % |
| Global Services | $ | 55,507 |  |  | $ | 52,676 |  |  |  |  | 5.4 | % |  | $ | 147,567 |  |  | $ | 151,744 |  |  |  |  | (2.8) | % |

[0000936395-21-000040:mdna:127]
[same as prior period, unchanged from 0000936395-21-000034:mdna:125]

[0000936395-21-000040:mdna:128]
[same as prior period, unchanged from 0000936395-21-000034:mdna:126]

[0000936395-21-000040:mdna:129]
Segment profit (loss) includes CEWS benefits of $0.7 million in the third quarter of fiscal 2021 and $36.5 million in the first nine months of fiscal 2021, net of certain fees. For further discussion of benefits from the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:130]
Quarter ended July 31, 2021 as compared to the quarter ended August 1, 2020

[0000936395-21-000040:mdna:131]
•Networking Platforms segment profit decreased by $18.3 million, primarily due to lower sales volume as described above and higher research and development costs, partially offset by improved gross margin.

[0000936395-21-000040:mdna:132]
•Platform Software and Services segment profit increased by $7.2 million, primarily due to higher sales volume, partially offset by higher research and development costs.

[0000936395-21-000040:mdna:133]
•Blue Planet Automation Software and Services segment loss decreased by $2.1 million, primarily due to higher sales volume and higher gross margin on software platform sales, partially offset by lower gross margin on software-related services.

[0000936395-21-000040:mdna:134]
•Global Services segment profit increased by $2.8 million, primarily due higher sales volume, partially offset by reduced gross margin, as described above.

[0000936395-21-000040:mdna:135]
Nine months ended July 31, 2021 as compared to the nine months ended August 1, 2020

[0000936395-21-000040:mdna:136]
•Networking Platforms segment profit decreased by $29.7 million, primarily due to lower sales volume as described above, partially offset by a CEWS benefit of $30.4 million and improved gross margin.

[0000936395-21-000040:mdna:137]
•Platform Software and Services segment profit increased by $20.8 million, primarily due to higher sales volume, a CEWS benefit of $2.6 million, and improved gross margin as described above.

[0000936395-21-000040:mdna:138]
•Blue Planet Automation Software and Services segment profit increased by $12.8 million, primarily due to higher sales volume, higher gross margin on software platform sales, and a CEWS benefit of $1.2 million, partially offset by lower gross margin on software-related services.

[0000936395-21-000040:mdna:139]
•Global Services segment profit decreased by $4.2 million, primarily due to reduced gross margin as described above, partially offset by higher sales volume and a CEWS benefit of $2.3 million.

[0000936395-21-000040:mdna:140]
[same as prior period, unchanged from 0000936395-21-000034:mdna:138]

[0000936395-21-000040:mdna:141]
Overview. For the nine months ended July 31, 2021, we generated $286.8 million of cash in operating activities, which included $40.1 million of cash from a CEWS benefit. Our net income (adjusted for non-cash charges) of $451.9 million exceeded our working capital requirements of $165.1 million. For additional details, see “Cash Provided By Operating Activities” below. For further information relating to our receipt of amounts under the CEWS program, see Note 4 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:142]
Cash, cash equivalents and investments increased by $151.8 million during the first nine months of fiscal 2021. The cash from operations above was partially offset by the following items: (i) cash used to fund our investing activities for capital expenditures totaling $67.3 million; (ii) cash used for stock repurchases under our stock repurchase program of $64.6 million; and (iii) stock repurchases on vesting of our stock unit awards to employees relating to tax withholding of $36.5 million. Proceeds from the issuance of equity under our employee stock purchase plan provided $28.3 million in cash during the nine months ended July 31, 2021.

[0000936395-21-000040:mdna:143]
[same as prior period, unchanged from 0000936395-21-000034:mdna:142]

[0000936395-21-000040:mdna:144]
|  | July 31,2021 |  | October 31,2020 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 1,230,441 |  |  | $ | 1,088,624 |  |  | $ | 141,817 |  |
| Short-term investments in marketable debt securities | 182,010 |  |  | 150,667 |  |  | 31,343 |  |
| Long-term investments in marketable debt securities | 60,888 |  |  | 82,226 |  |  | (21,338) |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,473,339 |  |  | $ | 1,321,517 |  |  | $ | 151,822 |  |

[0000936395-21-000040:mdna:145]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of July 31, 2021 totaled $1.5 billion, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $300.0 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of July 31, 2021, letters of credit totaling $84.6 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2021.

[0000936395-21-000040:mdna:146]
Foreign Liquidity. Cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $254.9 million as of July 31, 2021. We intend to reinvest our foreign earnings indefinitely. If we were to repatriate the accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $26.0 million.

[0000936395-21-000040:mdna:147]
Stock Repurchase Authorization. On December 13, 2018, we announced that the Board of Directors authorized a program to repurchase up to $500.0 million of our common stock. After temporarily suspending repurchases of our common stock during fiscal 2020, we reinstituted our stock repurchase program in the first quarter of 2021. We repurchased $65.4 million under this program during the first nine months of fiscal 2021, and had $210.0 million remaining under the current authorization as of July 31, 2021. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be reinstated, modified, suspended, or discontinued at any time.

[0000936395-21-000040:mdna:148]
Liquidity Position. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans, and will continue to consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and market opportunities to enhance our liquidity and provide further operational and strategic flexibility. While the COVID-19 pandemic has not materially impacted our liquidity and capital resources to date, it has led to disruptions and volatility in capital markets and credit markets. The duration and severity of any further economic or market impact of the COVID-19 pandemic remains uncertain and there can be no assurance that it will not have an adverse effect on our liquidity and capital resources, including our ability to access capital markets, in the future.

[0000936395-21-000040:mdna:149]
[same as prior period, unchanged from 0000936395-21-000034:mdna:148]

[0000936395-21-000040:mdna:150]
The following sections set forth the components of our $286.8 million of cash provided by operating activities during the first nine months of fiscal 2021:

[0000936395-21-000040:mdna:151]
[same as prior period, unchanged from 0000936395-21-000034:mdna:150]

[0000936395-21-000040:mdna:152]
[same as prior period, unchanged from 0000936395-21-000034:mdna:151]

[0000936395-21-000040:mdna:153]
|  | Nine Months Ended |
|  | July 31, 2021 |
| Net income | $ | 396,697 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 71,918 |  |
| Share-based compensation costs | 62,970 |  |
| Amortization of intangible assets | 27,341 |  |
| Provision for inventory excess and obsolescence | 13,460 |  |
| Provision for warranty | 12,726 |  |
| Deferred taxes | (139,543) |  |
| Other | 6,350 |  |
| Net income (adjusted for non-cash charges) | $ | 451,919 |  |

[0000936395-21-000040:mdna:154]
[same as prior period, unchanged from 0000936395-21-000034:mdna:153]

[0000936395-21-000040:mdna:155]
We used $165.1 million of cash for working capital during the period. The following table sets forth the major components of the cash used in working capital (in thousands):

[0000936395-21-000040:mdna:156]
|  | Nine Months Ended |
|  | July 31, 2021 |
| Cash used in accounts receivable | $ | (163,149) |  |
| Cash used in inventories | (38,821) |  |
| Cash used in prepaid expenses and other | (17,272) |  |
| Cash provided by accounts payable, accruals and other obligations | 31,388 |  |
| Cash provided by deferred revenue | 24,969 |  |
| Cash used in operating lease assets and liabilities, net | (2,278) |  |
| Total cash used for working capital | $ | (165,163) |  |

[0000936395-21-000040:mdna:157]
[same as prior period, unchanged from 0000936395-21-000034:mdna:156]

[0000936395-21-000040:mdna:158]
•The $163.1 million cash used in accounts receivable during the first nine months of fiscal 2021 reflects increased sales volume at the end of the third quarter of fiscal 2021;

[0000936395-21-000040:mdna:159]
•The $38.8 million of cash used in inventories during the first nine months of fiscal 2021 primarily reflects increases in raw materials inventory related to the steps we are taking to mitigate the impact of current supply chain constraints and the global market shortage of semiconductor parts described in “Overview” above;

[0000936395-21-000040:mdna:160]
•The $17.3 million of cash used in prepaid expense and other during the first nine months of fiscal 2021 primarily reflects increases in contract assets and increases in foreign currency forward contracts;

[0000936395-21-000040:mdna:161]
•The $31.4 million of cash provided by accounts payable, accruals and other obligations during the first nine months of fiscal 2021 primarily reflects higher provisions under our annual cash incentive compensation plan, and increased income taxes payable;

[0000936395-21-000040:mdna:162]
•The $25.0 million of cash provided by deferred revenue during the first nine months of fiscal 2021 represents an increase in advanced payments received from customers prior to revenue recognition; and

[0000936395-21-000040:mdna:163]
•The $2.3 million of cash used in operating lease assets and liabilities, net, during the first nine months of fiscal 2021 represents cash paid for operating lease payments in excess of operating lease costs. For more details, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-21-000040:mdna:164]
Our days sales outstanding (“DSOs”) for the first nine months of fiscal 2021 were 102 days, and our inventory turns for the first nine months of fiscal 2021 were 3.9. The calculation of DSOs includes accounts receivables, net and contract assets for unbilled receivables, net included in prepaid expenses and other.

[0000936395-21-000040:mdna:165]
[same as prior period, unchanged from 0000936395-21-000034:mdna:164]

[0000936395-21-000040:mdna:166]
[same as prior period, unchanged from 0000936395-21-000034:mdna:165]

[0000936395-21-000040:mdna:167]
|  | Nine Months Ended |
|  | July 31, 2021 |
| Term Loan due September 28, 2025(1) | $ | 9,754 |  |
| Interest rate swaps(2) | 7,520 |  |
| ABL Credit Facility(3) | 1,447 |  |
| Finance leases | 3,671 |  |
| Cash paid during period | $ | 22,392 |  |

[0000936395-21-000040:mdna:168]
(1) Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR for the chosen borrowing period plus a spread of 1.75% subject to a minimum LIBOR rate of 0.00%. At the end of the third quarter of fiscal 2021, the interest rate on the 2025 Term Loan was 1.83%.

[0000936395-21-000040:mdna:169]
[same as prior period, unchanged from 0000936395-21-000034:mdna:168]

[0000936395-21-000040:mdna:170]
(3) During the first nine months of fiscal 2021, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $1.4 million in commitment fees, interest expense and other administrative charges relating to the ABL Credit Facility.

[0000936395-21-000040:mdna:171]
[same as prior period, unchanged from 0000936395-21-000034:mdna:170]

[0000936395-21-000040:mdna:172]
[same as prior period, unchanged from 0000936395-21-000034:mdna:171]

[0000936395-21-000040:mdna:173]
[same as prior period, unchanged from 0000936395-21-000034:mdna:172]

[0000936395-21-000040:mdna:174]
[same as prior period, unchanged from 0000936395-21-000034:mdna:173]

[0000936395-21-000040:mdna:175]
[same as prior period, unchanged from 0000936395-21-000034:mdna:174]

[0000936395-21-000040:mdna:176]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. The inputs into certain of our judgments, assumptions, and estimates reflect, among other things, the information available to us regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on our business and on our critical and significant accounting estimates. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected. In addition, because the duration, severity, and impact of the COVID-19 pandemic remain uncertain, certain of our estimates could require further judgment or modification, and therefore carry a higher degree of variability and volatility. As events continue to evolve, our estimates may change materially in future periods.

[0000936395-21-000040:mdna:177]
[same as prior period, unchanged from 0000936395-21-000034:mdna:176]

[0000936395-21-000040:mdna:178]
Deferred Tax Assets

[0000936395-21-000040:mdna:179]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-21-000040:mdna:180]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. The valuation allowance balances at July 31, 2021 and October 31, 2020 were $159.2 million and $151.4 million, respectively. The corresponding net deferred tax assets were $784.7 million and $647.8 million, respectively. We will continue to evaluate future financial performance to determine whether such performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy.

[0000936395-21-000040:mdna:181]
In the third quarter of fiscal 2021, we completed an internal transfer of certain of our non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $124.2 million deferred tax asset with a corresponding tax benefit. The recognition of the deferred tax asset from the internal transfer of the non-U.S. intangible assets requires management to make significant estimates and assumptions to determine the fair value of the intangible assets transferred and judgments concerning the jurisdiction where the deferred tax asset will be recovered. Critical estimates in valuing the intangible assets include, but are not limited to, internal revenue and expense forecasts, the estimated life of the intangible assets, and discount rates, which are affected by expectations about future market or economic conditions. Although we believe the assumptions and estimates we have made are reasonable and appropriate, they are based, in part, on historical experience and are inherently uncertain. Unanticipated events and circumstances may occur that could affect either the accuracy or validity of such assumptions, estimates or actual results. For further discussion, see Note 7 to our Condensed Consolidated Financial Statements included in Item I of Part I of this report.

[0000936395-21-000040:mdna:182]
[same as prior period, unchanged from 0000936395-21-000034:mdna:177]

[0000936395-21-000040:mdna:183]
See Note 2 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for information regarding the change in our allowance for credit losses for accounts receivable and contract assets accounting policies as a result of our adoption of ASU 2016-13, Financial Instruments - Credit Losses.

[0000936395-21-000040:mdna:184]
[same as prior period, unchanged from 0000936395-21-000034:mdna:179]

[0000936395-21-000040:mdna:185]
[same as prior period, unchanged from 0000936395-21-000034:mdna:180]
