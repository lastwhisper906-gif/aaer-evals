# CIEN 8-K — 0000936395-21-000036 filed 2021-09-02

## item codes, every 8-K on or before 2021-09-08

- 2021-09-02 0000936395-21-000036 — 2.02, 9.01
- 2021-06-03 0000936395-21-000027 — 2.02, 9.01
- 2021-04-06 0000936395-21-000015 — 5.02, 5.07, 9.01
- 2021-03-04 0000936395-21-000006 — 2.02, 9.01
- 2020-12-10 0000936395-20-000038 — 2.02, 9.01
- 2020-09-03 0000936395-20-000033 — 2.02, 9.01
- 2020-07-01 0000936395-20-000030 — 5.02, 9.01
- 2020-06-04 0000936395-20-000025 — 2.02, 9.01
- 2020-04-06 0000936395-20-000014 — 5.02, 5.07, 9.01
- 2020-03-05 0000936395-20-000006 — 2.02, 9.01
- 2020-01-28 0001193125-20-017079 — 1.01, 2.03, 9.01
- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2021-09-08

- none on or before 2021-09-08

## item 2.02 — earnings release, exhibit 99.1

[0000936395-21-000036:8k_2_02:1]
EX-99.1
2
ex991-2021q3earningspressr.htm
EX-99.1

[0000936395-21-000036:8k_2_02:2]
Document

[0000936395-21-000036:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-21-000036:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2021 Financial Results

[0000936395-21-000036:8k_2_02:5]
HANOVER, Md. - September 2, 2021 - Ciena® Corporation (NYSE:  CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal third quarter ended July 31, 2021.

[0000936395-21-000036:8k_2_02:6]
•Q3 Revenue: $988.1 million

[0000936395-21-000036:8k_2_02:7]
•Q3 Net Income per Share: $1.52 GAAP; $0.92 adjusted (non-GAAP)

[0000936395-21-000036:8k_2_02:8]
•Share Repurchases: Repurchased approximately 0.5 million shares of common stock for an aggregate price of $26.0 million during the quarter

[0000936395-21-000036:8k_2_02:9]
“We delivered outstanding fiscal third quarter results that reflect continued momentum in our business as well as our differentiated position in the market,” said Gary Smith, president and CEO of Ciena. “These results combined with a robust demand environment give us confidence that we will deliver our expected strong second half performance.”

[0000936395-21-000036:8k_2_02:10]
For the fiscal third quarter 2021, Ciena reported revenue of $988.1 million as compared to $976.7 million for the fiscal third quarter 2020.

[0000936395-21-000036:8k_2_02:11]
Ciena's GAAP net income for the fiscal third quarter 2021 was $238.2 million, or $1.52 per diluted common share, which compares to a GAAP net income of $142.3 million, or $0.91 per diluted common share, for the fiscal third quarter 2020. Ciena's GAAP net income for the third quarter of 2021 benefited from the recording of a $124.2 million tax benefit related to an internal transfer of non-U.S. intangible assets. See APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures for more information and a reconciliation of our adjusted (non-GAAP) net income which excludes the effect of these amounts.

[0000936395-21-000036:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2021 was $144.9 million, or $0.92 per diluted common share, which compares to an adjusted (non-GAAP) net income of $166.4 million, or $1.06 per diluted common share, for the fiscal third quarter 2020.

[0000936395-21-000036:8k_2_02:13]
Fiscal Third Quarter 2021 Performance Summary

[0000936395-21-000036:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-21-000036:8k_2_02:15]
|  |  | GAAP Results |
|  |  | Q3 |  | Q3 |  |  |
|  |  | FY 2021 |  | FY 2020 |  | Y-T-Y* |
| Revenue |  | $ | 988.1 |  |  | $ | 976.7 |  |  | 1.2 | % |
| Gross margin |  | 48.0 | % |  | 47.6 | % |  | 0.4 | % |
| Operating expense |  | $ | 326.0 |  |  | $ | 276.6 |  |  | 17.9 | % |
| Operating margin |  | 15.0 | % |  | 19.3 | % |  | (4.3) | % |

[0000936395-21-000036:8k_2_02:16]
|  |  | Non-GAAP Results |
|  |  | Q3 |  | Q3 |  |  |
|  |  | FY 2021 |  | FY 2020 |  | Y-T-Y* |
| Revenue |  | $ | 988.1 |  |  | $ | 976.7 |  |  | 1.2 | % |
| Adj. gross margin |  | 48.5 | % |  | 48.2 | % |  | 0.3 | % |
| Adj. operating expense |  | $ | 290.4 |  |  | $ | 251.2 |  |  | 15.6 | % |
| Adj. operating margin |  | 19.1 | % |  | 22.4 | % |  | (3.3) | % |
| Adj. EBITDA |  | $ | 213.7 |  |  | $ | 241.1 |  |  | (11.4) | % |

[0000936395-21-000036:8k_2_02:17]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-21-000036:8k_2_02:18]
|  |  | Revenue by Segment |
|  |  | Q3 FY 2021 |  | Q3 FY 2020 |
|  |  | Revenue |  | %** |  | Revenue |  | %** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 712.9 |  |  | 72.1 |  |  | $ | 722.5 |  |  | 74.0 |  |
| Routing and Switching (1) |  | 69.7 |  |  | 7.1 |  |  | 79.8 |  |  | 8.1 |  |
| Total Networking Platforms |  | 782.6 |  |  | 79.2 |  |  | 802.3 |  |  | 82.1 |  |
| Platform Software and Services |  | 56.9 |  |  | 5.8 |  |  | 46.4 |  |  | 4.8 |  |
| Blue Planet Automation Software and Services |  | 16.6 |  |  | 1.7 |  |  | 11.3 |  |  | 1.1 |  |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 74.0 |  |  | 7.5 |  |  | 69.1 |  |  | 7.1 |  |
| Installation and Deployment |  | 46.7 |  |  | 4.7 |  |  | 39.8 |  |  | 4.1 |  |
| Consulting and Network Design |  | 11.3 |  |  | 1.1 |  |  | 7.8 |  |  | 0.8 |  |
| Total Global Services |  | 132.0 |  |  | 13.3 |  |  | 116.7 |  |  | 12.0 |  |
| Total |  | $ | 988.1 |  |  | 100.0 |  |  | $ | 976.7 |  |  | 100.0 |  |

[0000936395-21-000036:8k_2_02:19]
**  Denotes %  of total revenue

[0000936395-21-000036:8k_2_02:20]
(1)  Ciena renamed its former “Packet Networking” product line “Routing and Switching” effective as of the beginning of fiscal 2021. This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results or the composition of this product category.

[0000936395-21-000036:8k_2_02:21]
2

[0000936395-21-000036:8k_2_02:22]
Additional Performance Metrics for Fiscal Third Quarter 2021

[0000936395-21-000036:8k_2_02:23]
|  |  | Revenue by Geographic Region |
|  |  | Q3 FY 2021 |  | Q3 FY 2020 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| Americas |  | $ | 692.8 |  |  | 70.1 |  |  | $ | 713.3 |  |  | 73.0 |  |
| Europe, Middle East and Africa |  | 189.2 |  |  | 19.2 |  |  | 162.5 |  |  | 16.6 |  |
| Asia Pacific |  | 106.1 |  |  | 10.7 |  |  | 100.9 |  |  | 10.4 |  |
| Total |  | $ | 988.1 |  |  | 100.0 |  |  | $ | 976.7 |  |  | 100.0 |  |

[0000936395-21-000036:8k_2_02:24]
**  Denotes %  of total revenue

[0000936395-21-000036:8k_2_02:25]
•Three 10%-plus customers represented a total of 37.5% of revenue

[0000936395-21-000036:8k_2_02:26]
•Cash and investments totaled $1.5 billion

[0000936395-21-000036:8k_2_02:27]
•Cash flow from operations totaled $69.1 million

[0000936395-21-000036:8k_2_02:28]
•Average days' sales outstanding (DSOs) were 89

[0000936395-21-000036:8k_2_02:29]
•Accounts receivable, net balance was $878.2 million

[0000936395-21-000036:8k_2_02:30]
•Unbilled contract asset, net balance was $98.8 million

[0000936395-21-000036:8k_2_02:31]
•Inventories totaled $370.2 million, including:

[0000936395-21-000036:8k_2_02:32]
◦Raw materials: $139.3 million

[0000936395-21-000036:8k_2_02:33]
◦Work in process: $10.6 million

[0000936395-21-000036:8k_2_02:34]
◦Finished goods: $204.6 million

[0000936395-21-000036:8k_2_02:35]
◦Deferred cost of sales: $53.8 million

[0000936395-21-000036:8k_2_02:36]
◦Reserve for excess and obsolescence: $(38.1) million

[0000936395-21-000036:8k_2_02:37]
•Product inventory turns were 4.5

[0000936395-21-000036:8k_2_02:38]
•Headcount totaled 7,251

[0000936395-21-000036:8k_2_02:39]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Third Quarter 2021 Results

[0000936395-21-000036:8k_2_02:40]
Today, Thursday, September 2, 2021, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website an accompanying investor presentation for its unaudited fiscal third quarter 2021 results.

[0000936395-21-000036:8k_2_02:41]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-21-000036:8k_2_02:42]
Notes to Investors

[0000936395-21-000036:8k_2_02:43]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, Securities and Exchange Commission ("SEC") filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include:

[0000936395-21-000036:8k_2_02:44]
“We delivered outstanding fiscal third quarter results that reflect continued momentum in our business as well as our differentiated position in the market” and "These results combined with a robust demand environment give us confidence that we will deliver our expected strong second half performance.”

[0000936395-21-000036:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; our ability to execute successfully our business and growth strategies; the duration and severity of the COVID-19 pandemic and its impact on macroeconomic conditions, economic activity, demand for our technology solutions, short- and long-term changes in customer or end user needs, continuity of supply chain, our business operations, liquidity, and financial results; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions; changes in foreign currency exchange rates affecting revenue and operating expense; factors beyond our control such as natural disasters, acts of war or terrorism, and public health emergencies; the impact of the Tax Cuts and Jobs Act; changes in tax or trade regulations, including the imposition of tariffs, duties or efforts to withdraw from or materially modify international trade agreements; changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise; and the other risk factors disclosed in its Annual Report on Form 10-K filed with the SEC on December 18, 2020 and included in its Quarterly Report on Form 10-Q for the third quarter of fiscal 2021 to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-21-000036:8k_2_02:46]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendices A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-21-000036:8k_2_02:47]
About Ciena. Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our customers create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-21-000036:8k_2_02:48]
4

[0000936395-21-000036:8k_2_02:49]
CIENA CORPORATION

[0000936395-21-000036:8k_2_02:50]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-21-000036:8k_2_02:51]
(in thousands, except per share data)

[0000936395-21-000036:8k_2_02:52]
(unaudited)

[0000936395-21-000036:8k_2_02:53]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 804,414 |  |  | $ | 819,022 |  |  | $ | 2,071,677 |  |  | $ | 2,246,129 |  |
| Services | 183,727 |  |  | 157,690 |  |  | 507,521 |  |  | 457,548 |  |
| Total revenue | 988,141 |  |  | 976,712 |  |  | 2,579,198 |  |  | 2,703,677 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 420,236 |  |  | 436,227 |  |  | 1,074,935 |  |  | 1,230,378 |  |
| Services | 93,355 |  |  | 75,804 |  |  | 259,403 |  |  | 224,757 |  |
| Total cost of goods sold | 513,591 |  |  | 512,031 |  |  | 1,334,338 |  |  | 1,455,135 |  |
| Gross profit | 474,550 |  |  | 464,681 |  |  | 1,244,860 |  |  | 1,248,542 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 146,225 |  |  | 130,221 |  |  | 389,212 |  |  | 392,651 |  |
| Selling and marketing | 114,924 |  |  | 94,763 |  |  | 322,589 |  |  | 303,043 |  |
| General and administrative | 48,863 |  |  | 41,635 |  |  | 132,491 |  |  | 126,133 |  |
| Significant asset impairments and restructuring costs | 9,789 |  |  | 6,515 |  |  | 23,865 |  |  | 14,798 |  |
| Amortization of intangible assets | 5,967 |  |  | 5,840 |  |  | 17,896 |  |  | 17,532 |  |
| Acquisition and integration costs (recoveries) | 259 |  |  | (2,329) |  |  | 860 |  |  | 904 |  |
| Total operating expenses | 326,027 |  |  | 276,645 |  |  | 886,913 |  |  | 855,061 |  |
| Income from operations | 148,523 |  |  | 188,036 |  |  | 357,947 |  |  | 393,481 |  |
| Interest and other income (loss), net | 795 |  |  | 232 |  |  | (1,600) |  |  | 1,213 |  |
| Interest expense | (7,776) |  |  | (7,251) |  |  | (22,921) |  |  | (23,926) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | (646) |  |
| Income before income taxes | 141,542 |  |  | 181,017 |  |  | 333,426 |  |  | 370,122 |  |
| Provision (benefit) for income taxes | (96,690) |  |  | 38,750 |  |  | (63,271) |  |  | 73,872 |  |
| Net income | $ | 238,232 |  |  | $ | 142,267 |  |  | $ | 396,697 |  |  | $ | 296,250 |  |
| Net Income per Common Share |  |  |  |  |  |  |  |
| Basic net income per common share | $ | 1.53 |  |  | $ | 0.92 |  |  | $ | 2.55 |  |  | $ | 1.92 |  |
| Diluted net income per potential common share | $ | 1.52 |  |  | $ | 0.91 |  |  | $ | 2.53 |  |  | $ | 1.90 |  |
| Weighted average basic common shares outstanding | 155,271 |  |  | 154,184 |  |  | 155,277 |  |  | 154,136 |  |
| Weighted average dilutive potential common shares outstanding 1 | 156,744 |  |  | 156,318 |  |  | 156,742 |  |  | 155,741 |  |

[0000936395-21-000036:8k_2_02:54]
1 Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the third quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:55]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first nine months of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the third quarter of fiscal 2020 includes 2.1 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:57]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per potential common share for the first nine months of fiscal 2020 includes 1.6 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:58]
CIENA CORPORATION

[0000936395-21-000036:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-21-000036:8k_2_02:60]
(in thousands, except share data)

[0000936395-21-000036:8k_2_02:61]
(unaudited)

[0000936395-21-000036:8k_2_02:62]
|  | July 31,2021 |  | October 31,2020 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 1,230,441 |  |  | $ | 1,088,624 |  |
| Short-term investments | 182,010 |  |  | 150,667 |  |
| Accounts receivable, net | 878,229 |  |  | 719,405 |  |
| Inventories | 370,170 |  |  | 344,379 |  |
| Prepaid expenses and other | 323,283 |  |  | 308,084 |  |
| Total current assets | 2,984,133 |  |  | 2,611,159 |  |
| Long-term investments | 60,888 |  |  | 82,226 |  |
| Equipment, building, furniture and fixtures, net | 288,937 |  |  | 272,377 |  |
| Operating lease right-of-use assets | 48,937 |  |  | 57,026 |  |
| Goodwill | 311,569 |  |  | 310,847 |  |
| Other intangible assets, net | 73,974 |  |  | 96,647 |  |
| Deferred tax asset, net | 784,702 |  |  | 647,805 |  |
| Other long-term assets | 102,728 |  |  | 102,830 |  |
| Total assets | $ | 4,655,868 |  |  | $ | 4,180,917 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 301,606 |  |  | $ | 291,904 |  |
| Accrued liabilities and other short-term obligations | 373,291 |  |  | 334,132 |  |
| Deferred revenue | 126,179 |  |  | 108,700 |  |
| Operating lease liabilities | 19,085 |  |  | 19,035 |  |
| Current portion of long-term debt | 6,930 |  |  | 6,930 |  |
| Total current liabilities | 827,091 |  |  | 760,701 |  |
| Long-term deferred revenue | 57,720 |  |  | 49,663 |  |
| Other long-term obligations | 123,731 |  |  | 123,185 |  |
| Long-term operating lease liabilities | 51,235 |  |  | 61,415 |  |
| Long-term debt, net | 671,855 |  |  | 676,356 |  |
| Total liabilities | $ | 1,731,632 |  |  | $ | 1,671,320 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 155,103,315and 154,563,005 shares issued and outstanding | 1,551 |  |  | 1,546 |  |
| Additional paid-in capital | 6,815,946 |  |  | 6,826,531 |  |
| Accumulated other comprehensive loss | (4,630) |  |  | (35,358) |  |
| Accumulated deficit | (3,888,631) |  |  | (4,283,122) |  |
| Total stockholders’ equity | 2,924,236 |  |  | 2,509,597 |  |
| Total liabilities and stockholders’ equity | $ | 4,655,868 |  |  | $ | 4,180,917 |  |

[0000936395-21-000036:8k_2_02:63]
6

[0000936395-21-000036:8k_2_02:64]
CIENA CORPORATION

[0000936395-21-000036:8k_2_02:65]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-21-000036:8k_2_02:66]
(in thousands) (unaudited)

[0000936395-21-000036:8k_2_02:67]
|  | Nine Months Ended |
|  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |
| Cash flows provided by operating activities: |  |  |  |
| Net income | $ | 396,697 |  |  | $ | 296,250 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 71,918 |  |  | 70,370 |  |
| Share-based compensation costs | 62,970 |  |  | 50,838 |  |
| Amortization of intangible assets | 27,341 |  |  | 29,035 |  |
| Deferred taxes | (139,543) |  |  | 57,636 |  |
| Provision for inventory excess and obsolescence | 13,460 |  |  | 20,176 |  |
| Provision for warranty | 12,726 |  |  | 19,172 |  |
| Other | 6,350 |  |  | 15,085 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (163,149) |  |  | (6,688) |  |
| Inventories | (38,821) |  |  | (39,568) |  |
| Prepaid expenses and other | (17,272) |  |  | (52,945) |  |
| Operating lease right-of-use assets | 12,340 |  |  | 12,816 |  |
| Accounts payable, accruals and other obligations | 31,388 |  |  | (131,647) |  |
| Deferred revenue | 24,969 |  |  | (19,039) |  |
| Short and long-term operating lease liabilities | (14,618) |  |  | (15,132) |  |
| Net cash provided by operating activities | 286,756 |  |  | 306,359 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (67,290) |  |  | (61,333) |  |
| Purchase of available for sale securities | (132,895) |  |  | (39,859) |  |
| Proceeds from maturities of available for sale securities | 122,063 |  |  | 90,000 |  |
| Settlement of foreign currency forward contracts, net | 7,326 |  |  | 3,067 |  |
| Acquisition of business, net of cash acquired | — |  |  | (28,300) |  |
| Proceeds from sale of equity investment | 4,678 |  |  | — |  |
| Net cash used in investing activities | (66,118) |  |  | (36,425) |  |
| Cash flows used in financing activities: |  |  |  |
| Payment of long term debt | (5,197) |  |  | (3,465) |  |
| Payment of debt issuance costs | — |  |  | (382) |  |
| Payment of finance lease obligations | (2,243) |  |  | (2,030) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (36,484) |  |  | (26,328) |  |
| Repurchases of common stock - repurchase program | (64,555) |  |  | (74,535) |  |
| Proceeds from issuance of common stock | 28,289 |  |  | 27,986 |  |
| Net cash used in financing activities | (80,190) |  |  | (78,754) |  |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 1,344 |  |  | (1,526) |  |
| Net increase in cash, cash equivalents and restricted cash | 141,792 |  |  | 189,654 |  |
| Cash, cash equivalents and restricted cash at beginning of period | 1,088,708 |  |  | 904,161 |  |
| Cash, cash equivalents and restricted cash at end of period | $ | 1,230,500 |  |  | $ | 1,093,815 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 22,392 |  |  | $ | 25,278 |  |
| Cash paid during the period for income taxes, net | $ | 46,165 |  |  | $ | 41,316 |  |
| Operating lease payments | $ | 16,162 |  |  | $ | 16,762 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 5,517 |  |  | $ | 4,200 |  |
| Repurchase of common stock in accrued liabilities from repurchase program | $ | 800 |  |  | $ | — |  |
| Operating lease right-of-use assets subject to lease liability | $ | 4,182 |  |  | $ | 11,404 |  |

[0000936395-21-000036:8k_2_02:68]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |
|  |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP gross profit |  | $ | 474,550 |  |  | $ | 464,681 |  |
| Share-based compensation-products |  | 1,037 |  |  | 960 |  |
| Share-based compensation-services |  | 1,315 |  |  | 1,007 |  |
| Canadian Emergency Wage Subsidy-products |  | (94) |  |  | — |  |
| Canadian Emergency Wage Subsidy-services |  | (47) |  |  | — |  |
| Amortization of intangible assets |  | 2,857 |  |  | 3,834 |  |
| Total adjustments related to gross profit |  | 5,068 |  |  | 5,801 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 479,618 |  |  | $ | 470,482 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 48.5 | % |  | 48.2 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP operating expense |  | $ | 326,027 |  |  | $ | 276,645 |  |
| Share-based compensation-research and development |  | 5,541 |  |  | 4,286 |  |
| Share-based compensation-sales and marketing |  | 6,534 |  |  | 5,180 |  |
| Share-based compensation-general and administrative |  | 8,237 |  |  | 5,940 |  |
| Canadian Emergency Wage Subsidy-research and development |  | (596) |  |  | — |  |
| Canadian Emergency Wage Subsidy-sales and marketing |  | (53) |  |  | — |  |
| Canadian Emergency Wage Subsidy-general and administrative |  | (46) |  |  | — |  |
| Significant asset impairments and restructuring costs |  | 9,789 |  |  | 6,515 |  |
| Amortization of intangible assets |  | 5,967 |  |  | 5,840 |  |
| Acquisition and integration costs (recoveries) |  | 259 |  |  | (2,329) |  |
| Total adjustments related to operating expense |  | 35,632 |  |  | 25,432 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 290,395 |  |  | $ | 251,213 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP income from operations |  | $ | 148,523 |  |  | $ | 188,036 |  |
| Total adjustments related to gross profit |  | 5,068 |  |  | 5,801 |  |
| Total adjustments related to operating expense |  | 35,632 |  |  | 25,432 |  |
| Total adjustments related to income from operations |  | 40,700 |  |  | 31,233 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 189,223 |  |  | $ | 219,269 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 19.1 | % |  | 22.4 | % |
| Net Income Reconciliation (GAAP/non-GAAP) |  |  |  |  |
| GAAP net income |  | $ | 238,232 |  |  | $ | 142,267 |  |
| Exclude GAAP provision (benefit) for income taxes |  | (96,690) |  |  | 38,750 |  |
| Income before income taxes |  | 141,542 |  |  | 181,017 |  |
| Total adjustments related to income from operations |  | 40,700 |  |  | 31,233 |  |
| Adjusted income before income taxes |  | 182,242 |  |  | 212,250 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 37,360 |  |  | 45,846 |  |
| Adjusted (non-GAAP) net income |  | $ | 144,882 |  |  | $ | 166,404 |  |
| Weighted average basic common shares outstanding |  | 155,271 |  | 154,184 |
| Weighted average dilutive potential common shares outstanding 1 |  | 156,744 |  | 156,318 |

[0000936395-21-000036:8k_2_02:69]
8

[0000936395-21-000036:8k_2_02:70]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measures |
| (in thousands, except per share data) (unaudited) |
|  |  | Quarter Ended |
|  |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 1.52 |  |  | $ | 0.91 |  |
| Adjusted (non-GAAP) diluted net income per potential common share |  | $ | 0.92 |  |  | $ | 1.06 |  |

[0000936395-21-000036:8k_2_02:71]
1 Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the third quarter of fiscal 2021 includes 1.5 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per potential common share for the third quarter of fiscal 2020 includes 2.1 million shares underlying certain stock option and stock unit awards.

[0000936395-21-000036:8k_2_02:73]
9

[0000936395-21-000036:8k_2_02:74]
| APPENDIX B - Calculation of EBITDA and Adjusted EBITDA (unaudited) |
| (in thousands) (unaudited) |
|  |  | Quarter Ended |
|  |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |
| Net income (GAAP) |  | $ | 238,232 |  |  | $ | 142,267 |  |
| Add: Interest expense |  | 7,776 |  |  | 7,251 |  |
| Less: Interest and other income, net |  | 795 |  |  | 232 |  |
| Add: Provision (benefit) for income taxes |  | (96,690) |  |  | 38,750 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 24,623 |  |  | 21,989 |  |
| Add: Amortization of intangible assets |  | 8,824 |  |  | 9,674 |  |
| EBITDA |  | $ | 181,970 |  |  | $ | 219,699 |  |
| Less: Canadian Emergency Wage Subsidy |  | 836 |  |  | — |  |
| Add: Share-based compensation cost |  | 22,471 |  |  | 17,259 |  |
| Add: Significant asset impairments and restructuring costs |  | 9,789 |  |  | 6,515 |  |
| Add: Acquisition and integration costs (recoveries) |  | 259 |  |  | (2,329) |  |
| Adjusted EBITDA |  | $ | 213,653 |  |  | $ | 241,144 |  |

[0000936395-21-000036:8k_2_02:75]
* * *

[0000936395-21-000036:8k_2_02:76]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-21-000036:8k_2_02:77]
•Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance.

[0000936395-21-000036:8k_2_02:78]
•Canadian Emergency Wage Subsidy - a program introduced by the Government of Canada to offset a portion of employee wages for a limited period in response to COVID-19 outbreak.

[0000936395-21-000036:8k_2_02:79]
•Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities and the redesign of business processes.

[0000936395-21-000036:8k_2_02:80]
•Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life.

[0000936395-21-000036:8k_2_02:81]
•Acquisition and integration costs (recoveries) - includes costs and recoveries of acquisition consideration and compensation associated with a three-year earn-out arrangement related to the DonRiver acquisition in fiscal 2018. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities.

[0000936395-21-000036:8k_2_02:82]
•Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 20.5% for the third fiscal quarter of 2021 and 21.6% for the third fiscal quarter of 2020. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. Ciena's GAAP tax provision for the third quarter of 2021 benefited from recording a $124.2 million tax benefit related to an internal transfer of non-U.S. intangible assets that was recognized as a result of the step-up in basis of such rights for tax purposes. The Non-GAAP tax provision for the periods presented do not include this tax benefit or the corresponding deferred tax asset.
