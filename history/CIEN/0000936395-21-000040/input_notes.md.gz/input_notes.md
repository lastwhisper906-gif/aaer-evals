# CIEN notes — 0000936395-21-000040


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-21-000040:notes:1]
[same as prior period, unchanged from 0000936395-21-000034:notes:1]

[0000936395-21-000040:notes:2]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, because the duration and severity of COVID-19 pandemic are uncertain, certain of these estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.

[0000936395-21-000040:notes:3]
[same as prior period, unchanged from 0000936395-21-000034:notes:3]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-21-000040:notes:4]
[same as prior period, unchanged from 0000936395-21-000034:notes:4]

[0000936395-21-000040:notes:5]
[same as prior period, unchanged from 0000936395-21-000034:notes:5]

[0000936395-21-000040:notes:6]
In June 2016, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

[0000936395-21-000040:notes:7]
[same as prior period, unchanged from 0000936395-21-000034:notes:7]

[0000936395-21-000040:notes:8]
[same as prior period, unchanged from 0000936395-21-000034:notes:8]

[0000936395-21-000040:notes:9]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the

[0000936395-21-000040:notes:10]
probability the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.

[0000936395-21-000040:notes:11]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000936395-21-000040:notes:12]
[same as prior period, unchanged from 0000936395-21-000034:notes:12]

[0000936395-21-000040:notes:13]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-21-000040:notes:14]
[same as prior period, unchanged from 0000936395-21-000034:notes:14]

[0000936395-21-000040:notes:15]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to “Routing and Switching.”

[0000936395-21-000040:notes:16]
[same as prior period, unchanged from 0000936395-21-000034:notes:16]

[0000936395-21-000040:notes:17]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |

[0000936395-21-000040:notes:18]
|  | Quarter Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Routing and Switching | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |

[0000936395-21-000040:notes:19]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |

[0000936395-21-000040:notes:20]
|  | Nine Months Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Routing Switching | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |

[0000936395-21-000040:notes:21]
Ciena reports its sales geographically using the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

[0000936395-21-000040:notes:22]
[same as prior period, unchanged from 0000936395-21-000034:notes:22]

[0000936395-21-000040:notes:23]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 692,853 |  |  | $ | 713,340 |  |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |
| EMEA |  | 189,180 |  |  | 162,465 |  |  | 499,652 |  |  | 433,861 |  |
| APAC |  | 106,108 |  |  | 100,907 |  |  | 302,607 |  |  | 332,091 |  |
| Total revenue by geographic distribution |  | $ | 988,141 |  |  | $ | 976,712 |  |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |

[0000936395-21-000040:notes:24]
Ciena’s revenue includes $623.9 million and $647.0 million of United States revenue for the third quarter of fiscal 2021 and 2020, respectively. For the nine months ended July 31, 2021 and August 1, 2020, United States revenue was $1.6 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

[0000936395-21-000040:notes:25]
[same as prior period, unchanged from 0000936395-21-000034:notes:25]

[0000936395-21-000040:notes:26]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Verizon | $ | 131,892 |  |  | n/a |  | n/a |  | $ | 272,200 |  |
| Web-scale provider | 119,728 |  |  | n/a |  | n/a |  | n/a |
| AT&T | 119,199 |  |  | 114,963 |  |  | 313,140 |  |  | 304,645 |  |
| Total | $ | 370,819 |  |  | $ | 114,963 |  |  | $ | 313,140 |  |  | $ | 576,845 |  |

[0000936395-21-000040:notes:27]
[same as prior period, unchanged from 0000936395-21-000034:notes:27]

[0000936395-21-000040:notes:28]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.

[0000936395-21-000040:notes:29]
[same as prior period, unchanged from 0000936395-21-000034:notes:29]

[0000936395-21-000040:notes:30]
[same as prior period, unchanged from 0000936395-21-000034:notes:30]

[0000936395-21-000040:notes:31]
[same as prior period, unchanged from 0000936395-21-000034:notes:31]

[0000936395-21-000040:notes:32]
[same as prior period, unchanged from 0000936395-21-000034:notes:32]

[0000936395-21-000040:notes:33]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000040:notes:34]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-21-000040:notes:35]
[same as prior period, unchanged from 0000936395-21-000034:notes:36]

[0000936395-21-000040:notes:36]
[same as prior period, unchanged from 0000936395-21-000034:notes:37]

[0000936395-21-000040:notes:37]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services is recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-21-000040:notes:38]
[same as prior period, unchanged from 0000936395-21-000034:notes:39]

[0000936395-21-000040:notes:39]
[same as prior period, unchanged from 0000936395-21-000034:notes:40]

[0000936395-21-000040:notes:40]
|  |  | Balance at July 31, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 878,229 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 98,812 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 183,899 |  |  | $ | 158,363 |  |

[0000936395-21-000040:notes:41]
[same as prior period, unchanged from 0000936395-21-000034:notes:42]

[0000936395-21-000040:notes:42]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $94.7 million and $91.8 million of revenue during the first nine months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2021 and August 1, 2020.

[0000936395-21-000040:notes:43]
[same as prior period, unchanged from 0000936395-21-000034:notes:44]

[0000936395-21-000040:notes:44]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $20.4 million and $15.3 million as of July 31, 2021 and October 31, 2020, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $16.8 million and $16.2 million during the first nine months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

[0000936395-21-000040:notes:45]
[same as prior period, unchanged from 0000936395-21-000034:notes:46]

[0000936395-21-000040:notes:46]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2021, the aggregate amount of RPO was $1.4 billion. As of July 31, 2021, Ciena expects approximately 85% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-21-000040:notes:47]
[same as prior period, unchanged from 0000936395-21-000034:notes:48]

[0000936395-21-000040:notes:48]
|  | July 31,2021 |  | October 31,2020 |
| Products | $ | 13,380 |  |  | $ | 17,534 |  |
| Services | 170,519 |  |  | 140,829 |  |
|  | 183,899 |  |  | 158,363 |  |
| Less current portion | (126,179) |  |  | (108,700) |  |
| Long-term deferred revenue | $ | 57,720 |  |  | $ | 49,663 |  |


## us-gaap:UnusualOrInfrequentItemsDisclosureTextBlock

[0000936395-21-000040:notes:49]
CANADIAN EMERGENCY WAGE SUBSIDY
In April 2020, the Canadian government introduced the Canada Emergency Wage Subsidy (“CEWS”) to help employers offset a portion of their employee wages for a limited period in response to the COVID-19 outbreak, retroactive to March 15, 2020. The CEWS program has been extended through October 23, 2021. The subsidy covers employers of all sizes and across all sectors.

[0000936395-21-000040:notes:50]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. Amounts from the CEWS program positively impacted our operating expense and measures of profit in the third quarter of fiscal 2021 and nine months ended July 31, 2021. For the third quarter of fiscal 2021, Ciena recorded CEWS benefits of CAD$1.1 million ($0.8 million), net of certain fees. For the nine months ended July 31, 2021, Ciena recorded a CAD$52.2 million ($41.3 million) benefit, net of certain fees, related to CEWS for claim periods beginning March 15, 2020, including CAD$43.9 million ($35.2 million) related to employee wages during fiscal 2020. As of July 31, 2021, amounts receivable from this subsidy were CAD$1.5 million ($1.2 million).

[0000936395-21-000040:notes:51]
[same as prior period, unchanged from 0000936395-21-000034:notes:52]

[0000936395-21-000040:notes:52]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Product | $ | 94 |  |  | $ | — |  |  | $ | 4,283 |  |  | $ | — |  |
| Service | 47 |  |  | — |  |  | 2,667 |  |  | — |  |
| CEWS benefit in cost of goods sold | 141 |  |  | — |  |  | 6,950 |  |  | — |  |
| Research and development | 596 |  |  | — |  |  | 29,519 |  |  | — |  |
| Sales and marketing | 53 |  |  | — |  |  | 2,604 |  |  | — |  |
| General and administrative | 46 |  |  | — |  |  | 2,207 |  |  | — |  |
| CEWS benefit in operating expense | 695 |  |  | — |  |  | 34,330 |  |  | — |  |
| Total CEWS benefit | $ | 836 |  |  | $ | — |  |  | $ | 41,280 |  |  | $ | — |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-21-000040:notes:53]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and to ensure better alignment of its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets, for the nine months ended July 31, 2021 (in thousands):

[0000936395-21-000040:notes:54]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at October 31, 2020 | $ | 2,915 |  |  | $ | — |  |  | $ | 2,915 |  |
| Charges | 5,306 |  | (1) | 18,558 |  | (2) | 23,864 |  |
| Cash payments | (7,051) |  |  | (18,558) |  |  | (25,609) |  |
| Balance at July 31, 2021 | $ | 1,170 |  |  | $ | — |  |  | $ | 1,170 |  |
| Current restructuring liabilities | $ | 1,170 |  |  | $ | — |  |  | $ | 1,170 |  |

[0000936395-21-000040:notes:55]
(1) Reflects a global workforce reduction of 120 employees during the nine months ended July 31, 2021 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000040:notes:56]
(2) Primarily represents the redesign of certain business processes associated with Ciena’s supply chain and distribution structure reorganization, and costs related to restructured facilities.

[0000936395-21-000040:notes:57]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts, which are included in Accrued liabilities and other short-term obligations on Ciena’s Condensed Consolidated Balance Sheets for the nine months ended August 1, 2020 (in thousands):

[0000936395-21-000040:notes:58]
|  | Workforcereduction |  | Other restructuring activities |  | Total |
| Balance at November 2, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Charges | 5,015 |  | (1) | 9,783 |  | (2) | 14,798 |  |
| Adjustments related to ASC 842 | — |  |  | (11,160) |  | (3) | (11,160) |  |
| Cash payments | (7,335) |  |  | (9,783) |  |  | (17,118) |  |
| Balance at August 1, 2020 | $ | 1,663 |  |  | $ | — |  |  | $ | 1,663 |  |
| Current restructuring liabilities | $ | 1,663 |  |  | $ | — |  |  | $ | 1,663 |  |

[0000936395-21-000040:notes:59]
(1) Reflects a global workforce reduction of approximately 79 employees during the nine months ended August 1, 2020 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes.

[0000936395-21-000040:notes:60]
[same as prior period, unchanged from 0000936395-21-000034:notes:61]

[0000936395-21-000040:notes:61]
[same as prior period, unchanged from 0000936395-21-000034:notes:62]


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-21-000040:notes:62]
[same as prior period, unchanged from 0000936395-21-000034:notes:63]

[0000936395-21-000040:notes:63]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Interest income | $ | 465 |  |  | $ | 849 |  |  | $ | 1,553 |  |  | $ | 6,262 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | (4,414) |  |  | 1,282 |  |  | 5,295 |  |  | 3,005 |  |
| Foreign currency exchange gains (losses) | 4,959 |  |  | (2,537) |  |  | (8,534) |  |  | (7,376) |  |
| Other | (215) |  |  | 638 |  |  | 86 |  |  | (678) |  |
| Interest and other income (loss), net | $ | 795 |  |  | $ | 232 |  |  | $ | (1,600) |  |  | $ | 1,213 |  |

[0000936395-21-000040:notes:64]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $8.5 million and $7.4 million in foreign currency exchange rate losses during the first nine months of fiscal 2021 and 2020, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than Ciena’s functional currency. The related remeasurement adjustments were recorded in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net, on the Condensed Consolidated Statements of Operations. During the first nine months of fiscal 2021 and 2020, respectively, Ciena recorded gains of $5.3 million and $3.0 million from non-hedge designated foreign currency forward contracts.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-21-000040:notes:65]
INCOME TAXESThe effective tax rate for the quarter and nine months ended July 31, 2021 was lower than the effective tax rate for the quarter and nine months ended August 1, 2020, primarily due to the tax benefit associated with recording a deferred tax asset.
To accommodate the requirements of a global business, Ciena has begun reorganizing its global supply chain and distribution structure, which includes a legal entity reorganization and related system upgrade. During the quarter, Ciena completed an internal transfer of certain of its non-U.S. intangible assets, which created amortizable tax basis resulting in the discrete recognition of a $124.2 million deferred tax asset with a corresponding tax benefit. The impact of this transfer is reflected in Ciena’s effective tax rate for the quarter and nine months ended July 31, 2021, which had a significant, one-time impact on its net income for these periods.

[0000936395-21-000040:notes:66]
Ciena’s future income tax provisions and deferred tax balances may be affected by the amount of pre-tax income, the jurisdictions where it is earned, the existence and ability to utilize tax attributes and changes in tax laws and business reorganizations. Ciena continues to monitor these items and will adopt strategies to address their impact as appropriate.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-21-000040:notes:67]
SHORT-TERM AND LONG-TERM INVESTMENTS
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-21-000040:notes:68]
|  | July 31, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,966 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 182,010 |  |
| Included in long-term investments | 60,887 |  |  | 7 |  |  | (6) |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 51 |  |  | $ | (6) |  |  | $ | 242,898 |  |

[0000936395-21-000040:notes:69]
|  | October 31, 2020 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 150,559 |  |  | $ | 109 |  |  | $ | (1) |  |  | $ | 150,667 |  |
| Included in long-term investments | 82,252 |  |  | — |  |  | (26) |  |  | 82,226 |  |
|  | $ | 232,811 |  |  | $ | 109 |  |  | $ | (27) |  |  | $ | 232,893 |  |

[0000936395-21-000040:notes:70]
The following table summarizes the final legal maturities of debt investments at July 31, 2021 (in thousands):

[0000936395-21-000040:notes:71]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 181,966 |  |  | $ | 182,010 |  |
| Due in 1-2 years | 60,887 |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 242,898 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-21-000040:notes:72]
[same as prior period, unchanged from 0000936395-21-000034:notes:73]

[0000936395-21-000040:notes:73]
|  | July 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 909,976 |  |  | $ | — |  |  | $ | — |  |  | $ | 909,976 |  |
| Bond mutual fund | 75,398 |  |  | — |  |  | — |  |  | 75,398 |  |
| Time deposits | 30,029 |  |  | — |  |  | — |  |  | 30,029 |  |
| Deferred compensation plan assets | 12,380 |  |  | — |  |  | — |  |  | 12,380 |  |
| U.S. government obligations | — |  |  | 242,898 |  |  | — |  |  | 242,898 |  |
| Foreign currency forward contracts | — |  |  | 8,598 |  |  | — |  |  | 8,598 |  |
| Total assets measured at fair value | $ | 1,027,783 |  |  | $ | 251,496 |  |  | $ | — |  |  | $ | 1,279,279 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,709 |  |  | $ | — |  |  | $ | 3,709 |  |
| Forward starting interest rate swaps | — |  |  | 20,682 |  |  | — |  |  | 20,682 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 24,391 |  |  | $ | — |  |  | $ | 24,391 |  |

[0000936395-21-000040:notes:74]
[same as prior period, unchanged from 0000936395-21-000034:notes:75]

[0000936395-21-000040:notes:75]
[same as prior period, unchanged from 0000936395-21-000034:notes:76]

[0000936395-21-000040:notes:76]
|  | July 31, 2021 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 1,015,403 |  |  | $ | — |  |  | $ | — |  |  | $ | 1,015,403 |  |
| Short-term investments | — |  |  | 182,010 |  |  | — |  |  | 182,010 |  |
| Prepaid expenses and other | — |  |  | 8,598 |  |  | — |  |  | 8,598 |  |
| Long-term investments | — |  |  | 60,888 |  |  | — |  |  | 60,888 |  |
| Other long-term assets | 12,380 |  |  | — |  |  | — |  |  | 12,380 |  |
| Total assets measured at fair value | $ | 1,027,783 |  |  | $ | 251,496 |  |  | $ | — |  |  | $ | 1,279,279 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities and other short-term obligations | $ | — |  |  | $ | 3,709 |  |  | $ | — |  |  | $ | 3,709 |  |
| Other long-term obligations | — |  |  | 20,682 |  |  | — |  |  | 20,682 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 24,391 |  |  | $ | — |  |  | $ | 24,391 |  |

[0000936395-21-000040:notes:77]
[same as prior period, unchanged from 0000936395-21-000034:notes:78]

[0000936395-21-000040:notes:78]
[same as prior period, unchanged from 0000936395-21-000034:notes:79]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-21-000040:notes:79]
[same as prior period, unchanged from 0000936395-21-000034:notes:80]

[0000936395-21-000040:notes:80]
|  | July 31,2021 |  | October 31,2020 |
| Raw materials | $ | 139,338 |  |  | $ | 119,481 |  |
| Work-in-process | 10,556 |  |  | 13,738 |  |
| Finished goods | 204,580 |  |  | 210,050 |  |
| Deferred cost of goods sold | 53,826 |  |  | 40,747 |  |
| Gross inventories | 408,300 |  |  | 384,016 |  |
| Provision for excess and obsolescence | (38,130) |  |  | (39,637) |  |
| Inventories, net | $ | 370,170 |  |  | $ | 344,379 |  |

[0000936395-21-000040:notes:81]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During the first nine months of fiscal 2021, Ciena recorded a provision for excess and obsolescence of $13.5 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-21-000040:notes:82]
[same as prior period, unchanged from 0000936395-21-000034:notes:83]

[0000936395-21-000040:notes:83]
|  | July 31,2021 |  | October 31,2020 |
| Contract assets for unbilled accounts receivable, net | $ | 98,812 |  |  | $ | 85,843 |  |
| Prepaid expenses | 75,287 |  |  | 70,647 |  |
| Prepaid VAT and other taxes | 70,735 |  |  | 72,838 |  |
| Product demonstration equipment, net | 35,411 |  |  | 44,793 |  |
| Other non-trade receivables | 17,808 |  |  | 21,981 |  |
| Capitalized contract acquisition costs | 15,067 |  |  | 11,296 |  |
| Derivative assets | 8,598 |  |  | 82 |  |
| CEWS receivable | 1,229 |  |  | — |  |
| Deferred deployment expense | 336 |  |  | 604 |  |
|  | $ | 323,283 |  |  | $ | 308,084 |  |

[0000936395-21-000040:notes:84]
Depreciation of product demonstration equipment was $7.6 million during the first nine months of fiscal 2021 and $6.5 million during the first nine months of fiscal 2020.

[0000936395-21-000040:notes:85]
[same as prior period, unchanged from 0000936395-21-000034:notes:86]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-21-000040:notes:86]
[same as prior period, unchanged from 0000936395-21-000034:notes:87]

[0000936395-21-000040:notes:87]
|  | July 31,2021 |  | October 31,2020 |
| Compensation, payroll related tax and benefits | $ | 142,713 |  |  | $ | 135,462 |  |
| Warranty | 48,139 |  |  | 49,868 |  |
| Income taxes payable | 36,526 |  |  | 6,348 |  |
| Vacation | 30,986 |  |  | 26,945 |  |
| Finance lease obligations | 3,395 |  |  | 2,836 |  |
| Other | 111,532 |  |  | 112,673 |  |
|  | $ | 373,291 |  |  | $ | 334,132 |  |

[0000936395-21-000040:notes:88]
[same as prior period, unchanged from 0000936395-21-000034:notes:90]

[0000936395-21-000040:notes:89]
|  |  | Beginning Balance |  |  |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| Nine Months Ended August 1, 2020 |  | $ | 48,498 |  |  |  |  | 19,172 |  |  | (15,504) |  |  | $ | 52,166 |  |
| Nine Months Ended July 31, 2021 |  | $ | 49,868 |  |  |  |  | 12,726 |  |  | (14,455) |  |  | $ | 48,139 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-21-000040:notes:90]
DERIVATIVE INSTRUMENTSForeign Currency Derivatives 
Ciena conducts business globally in numerous currencies, and thus is exposed to adverse foreign currency exchange rate changes. To limit this exposure, Ciena enters into foreign currency contracts. Ciena does not enter into such contracts for speculative purposes.

[0000936395-21-000040:notes:91]
As of July 31, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce variability principally related to research and development activities. The notional amount of these contracts was approximately $219.1 million and $254.9 million as of July 31, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-21-000040:notes:92]
As of July 31, 2021 and October 31, 2020, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in various currencies of certain balance sheet items. The notional amount of these contracts was approximately $241.8 million and $212.0 million as of July 31, 2021 and October 31, 2020, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-21-000040:notes:93]
[same as prior period, unchanged from 0000936395-21-000034:notes:96]

[0000936395-21-000040:notes:94]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 16 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350.0 million of the 2025 Term Loan (as defined in Note 16 below) at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of July 31, 2021 and October 31, 2020.

[0000936395-21-000040:notes:95]
[same as prior period, unchanged from 0000936395-21-000034:notes:98]

[0000936395-21-000040:notes:96]
[same as prior period, unchanged from 0000936395-21-000034:notes:99]


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-21-000040:notes:97]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the nine months ended July 31, 2021 (in thousands):

[0000936395-21-000040:notes:98]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2020 | $ | 45 |  |  | $ | (219) |  |  | $ | (21,535) |  |  | $ | (13,649) |  |  | $ | (35,358) |  |
| Other comprehensive gain (loss) before reclassifications | (28) |  |  | 13,574 |  |  | (1,399) |  |  | 19,439 |  |  | 31,586 |  |
| Amounts reclassified from AOCI | — |  |  | (7,907) |  |  | 7,049 |  |  | — |  |  | (858) |  |
| Balance at July 31, 2021 | $ | 17 |  |  | $ | 5,448 |  |  | $ | (15,885) |  |  | $ | 5,790 |  |  | $ | (4,630) |  |

[0000936395-21-000040:notes:99]
The following table summarizes the changes in AOCI, net of tax, for the nine months ended August 1, 2020 (in thousands):

[0000936395-21-000040:notes:100]
|  | Unrealized Gain (Loss) on |  | Cumulative |  |  |
|  | Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at November 2, 2019 | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686) |  |  | $ | (9,475) |  |  | $ | (22,084) |  |
| Other comprehensive loss before reclassifications | 69 |  |  | (4,515) |  |  | (12,507) |  |  | (6,321) |  |  | (23,274) |  |
| Amounts reclassified from AOCI | — |  |  | 2,742 |  |  | 2,427 |  |  | — |  |  | 5,169 |  |
| Balance at August 1, 2020 | $ | 221 |  |  | $ | (848) |  |  | $ | (23,766) |  |  | $ | (15,796) |  |  | $ | (40,189) |  |

[0000936395-21-000040:notes:101]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Condensed Consolidated Statements of Operations. All 
amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net, on the Condensed Consolidated Statements of Operations.


## us-gaap:LesseeOperatingLeasesTextBlock

[0000936395-21-000040:notes:102]
LEASES
Ciena leases over 1.3 million square feet of facilities globally. Ciena’s principal executive offices are located in Hanover, Maryland. Ciena’s largest facilities are research and development centers located in Ottawa, Canada and Gurgaon, India. Ciena also has engineering and/or service delivery facilities located in San Jose, California; Alpharetta, Georgia; Quebec, Canada; and Pune and Bangalore, India. In addition, Ciena leases various smaller offices in regions throughout the world to support sales and services operations. Office facilities are leased under various non-cancelable operating or finance leases. Ciena's current leases have remaining terms that vary up to 11 years. Certain leases provide for options to extend up to ten years and/or options to terminate within five years.

[0000936395-21-000040:notes:103]
Leases included in the Condensed Consolidated Balance Sheets were as follows (in thousands):

[0000936395-21-000040:notes:104]
|  | Classification |  | As of July 31, 2021 | As of October 31, 2020 |
| Operating leases: |  |  |  |  |
| Operating ROU assets | Operating right-of-use assets |  | $ | 48,937 |  | $ | 57,026 |  |
| Operating lease liabilities | Operating lease liabilities and Long-term operating lease liabilities |  | 70,320 |  | 80,450 |  |
| Finance leases: |  |  |  |  |
| Buildings, gross | Equipment, building, furniture and fixtures, net |  | $ | 75,616 |  | $ | 70,791 |  |
| Less: accumulated depreciation | Equipment, building, furniture and fixtures, net |  | (22,664) |  | (17,837) |  |
| Buildings, net |  |  | $ | 52,952 |  | $ | 52,954 |  |
| Finance lease liabilities | Accrued liabilities and other short-term obligations and other long-term obligations |  | $ | 66,530 |  | $ | 64,401 |  |

[0000936395-21-000040:notes:105]
ROU assets that involve subleased or vacant space aggregate to $4.3 million as of July 31, 2021. These assets may become impaired if tenants are unable to service their obligations under the sublease, and/or if the estimates as to occupancy are not realized, either of which may be more likely as COVID-19 impacts evolve.

[0000936395-21-000040:notes:106]
The components of lease expense included in the Condensed Consolidated Statement of Operations were as follows (in thousands):

[0000936395-21-000040:notes:107]
|  |  |  | Quarter Ended |  | Nine Months Ended |
|  |  |  | July 31, | August 1, |  | July 31, | August 1, |
|  | Classification |  | 2021 | 2020 |  | 2021 | 2020 |
| Operating lease costs | Operating expense |  | $ | 4,085 |  | $ | 4,234 |  |  | $ | 12,516 |  | $ | 13,435 |  |
| Finance lease cost: |  |  |  |  |  |  |  |
| Amortization of finance ROU asset | Operating expense |  | 1,224 |  | 1,097 |  |  | 3,580 |  | 3,330 |  |
| Interest on finance lease liabilities | Interest expense |  | 1,243 |  | 1,162 |  |  | 3,671 |  | 3,574 |  |
| Total finance lease cost |  |  | 2,467 |  | 2,259 |  |  | 7,251 |  | 6,904 |  |
| Non-capitalized lease cost | Operating expense |  | 216 |  | 883 |  |  | 842 |  | 2,211 |  |
| Variable lease cost(1) | Operating expense |  | 1,393 |  | 1,265 |  |  | 4,444 |  | 3,900 |  |
| Net lease cost(2) |  |  | $ | 8,161 |  | $ | 8,641 |  |  | $ | 25,053 |  | $ | 26,450 |  |

[0000936395-21-000040:notes:108]
(1) Variable lease costs include expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. Variable lease costs are determined by whether they are to be included in base rent and if amounts are based on a consumer price index.

[0000936395-21-000040:notes:109]
(2) Excludes other operating expense of $2.3 million and $2.2 million for the third quarter of fiscal 2021 and 2020, respectively and $7.2 million and $8.7 million for the nine months ended July 31, 2021 and August 1, 2020, respectively, related to amortization of leasehold improvements.

[0000936395-21-000040:notes:110]
Future minimum lease payments and the present value of minimum lease payments related to operating and finance leases as of July 31, 2021 were as follows (in thousands):

[0000936395-21-000040:notes:111]
|  | Operating Leases |  | Finance Leases |  | Total |
| Remaining fiscal 2021 | $ | 5,472 |  |  | $ | 8,146 |  |  | $ | 13,618 |  |
| 2022 | 19,862 |  |  | 8,500 |  |  | 28,362 |  |
| 2023 | 16,087 |  |  | 8,500 |  |  | 24,587 |  |
| 2024 | 13,768 |  |  | 8,620 |  |  | 22,388 |  |
| 2025 | 9,437 |  |  | 8,706 |  |  | 18,143 |  |
| Thereafter | 10,272 |  |  | 55,532 |  |  | 65,804 |  |
| Total lease payments | 74,898 |  |  | 98,004 |  |  | 172,902 |  |
| Less: Imputed interest | (4,578) |  |  | (31,474) |  |  | (36,052) |  |
| Present value of lease liabilities | 70,320 |  |  | 66,530 |  |  | 136,850 |  |
| Less: Current portion of present value of minimum lease payments | (19,085) |  |  | (3,395) |  |  | (22,480) |  |
| Long-term portion of present value of minimum lease payments | $ | 51,235 |  |  | $ | 63,135 |  |  | $ | 114,370 |  |

[0000936395-21-000040:notes:112]
The weighted average remaining lease terms and weighted average discount rates for operating and finance leases were as follows:

[0000936395-21-000040:notes:113]
|  | As of July 31, 2021 | As of October 31, 2020 |
| Weighted-average remaining lease term in years: |  |  |
| Operating leases | 4.35 | 4.87 |
| Finance leases | 10.97 | 11.71 |
| Weighted-average discount rates: |  |  |
| Operating leases | 2.75 | % | 2.82 | % |
| Finance leases | 7.56 | % | 7.56 | % |


## cien:TermLoanAndConvertibleNotesPayableDisclosureTextBlock

[0000936395-21-000040:notes:114]
SHORT-TERM AND LONG-TERM DEBT 
2025 Term Loan

[0000936395-21-000040:notes:115]
On January 23, 2020, Ciena entered into a Refinancing Amendment to Credit Agreement pursuant to which Ciena refinanced the entire outstanding amount of its then existing senior secured term loan and incurred a new senior secured term loan in an aggregate principal amount of $693.0 million and maturing on September 28, 2025 (the “2025 Term Loan”).

[0000936395-21-000040:notes:116]
The net carrying value of Ciena’s term loan was comprised of the following for the periods indicated (in thousands):

[0000936395-21-000040:notes:117]
|  |  | July 31, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 682,605 |  |  | $ | (1,332) |  |  | $ | (2,488) |  |  | $ | 678,785 |  |  | $ | 683,286 |  |

[0000936395-21-000040:notes:118]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.5 million as of July 31, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

[0000936395-21-000040:notes:119]
As of July 31, 2021, the estimated fair value of the 2025 Term Loan was $680.9 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:EarningsPerShareTextBlock

[0000936395-21-000040:notes:120]
[same as prior period, unchanged from 0000936395-21-000034:notes:123]

[0000936395-21-000040:notes:121]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Net income | $ | 238,232 |  |  | $ | 142,267 |  |  | $ | 396,697 |  |  | $ | 296,250 |  |
| Basic weighted average shares outstanding | 155,271 |  |  | 154,184 |  |  | 155,277 |  |  | 154,136 |  |
| Effect of dilutive potential common shares | 1,473 |  |  | 2,134 |  |  | 1,465 |  |  | 1,605 |  |
| Diluted weighted average shares | 156,744 |  |  | 156,318 |  |  | 156,742 |  |  | 155,741 |  |
| Basic EPS | $ | 1.53 |  |  | $ | 0.92 |  |  | $ | 2.55 |  |  | $ | 1.92 |  |
| Diluted EPS | $ | 1.52 |  |  | $ | 0.91 |  |  | $ | 2.53 |  |  | $ | 1.90 |  |
| Antidilutive employee share-based awards, excluded | 131 |  |  | 13 |  |  | 99 |  |  | 316 |  |

[0000936395-21-000040:notes:122]
[same as prior period, unchanged from 0000936395-21-000034:notes:125]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-21-000040:notes:123]
[same as prior period, unchanged from 0000936395-21-000034:notes:126]

[0000936395-21-000040:notes:124]
[same as prior period, unchanged from 0000936395-21-000034:notes:127]

[0000936395-21-000040:notes:125]
[same as prior period, unchanged from 0000936395-21-000034:notes:128]

[0000936395-21-000040:notes:126]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2020 | 5,710,912 |  |  | $ | 39.33 |  |  | $ | 224,611 |  |
| Repurchase of common stock under the stock repurchase program | 1,203,439 |  |  | 54.31 |  |  | 65,356 |  |
| Cumulative balance at July 31, 2021 | 6,914,351 |  |  | $ | 41.94 |  |  | $ | 289,967 |  |

[0000936395-21-000040:notes:127]
[same as prior period, unchanged from 0000936395-21-000034:notes:130]

[0000936395-21-000040:notes:128]
[same as prior period, unchanged from 0000936395-21-000034:notes:131]

[0000936395-21-000040:notes:129]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due on vesting of stock unit awards. The purchase price of $36.5 million for the shares of Ciena’s stock repurchased during the first nine months of fiscal 2021 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-21-000040:notes:130]
SHARE-BASED COMPENSATION EXPENSEAmended and Restated ESPP
Ciena makes shares of its common stock available for purchase under its Amended and Restated Ciena Corporation Employee Stock Purchase Plan (the “ESPP”). Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. On January 29, 2021, Ciena’s Board of Directors adopted an amendment and restatement of the ESPP to increase the number of shares available for issuance thereunder by 8.7 million and eliminate the evergreen mechanism thereunder, which became effective upon its approval by Ciena’s stockholders on April 1, 2021. Unless earlier terminated, the ESPP will terminate on April 1, 2031.

[0000936395-21-000040:notes:131]
[same as prior period, unchanged from 0000936395-21-000034:notes:134]

[0000936395-21-000040:notes:132]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Product | $ | 1,037 |  |  | $ | 960 |  |  | $ | 2,488 |  |  | $ | 2,458 |  |
| Service | 1,315 |  |  | 1,007 |  |  | 3,941 |  |  | 2,885 |  |
| Share-based compensation expense included in cost of goods sold | 2,352 |  |  | 1,967 |  |  | 6,429 |  |  | 5,343 |  |
| Research and development | 5,541 |  |  | 4,286 |  |  | 16,179 |  |  | 12,957 |  |
| Sales and marketing | 6,534 |  |  | 5,180 |  |  | 18,960 |  |  | 15,057 |  |
| General and administrative | 8,237 |  |  | 5,940 |  |  | 21,338 |  |  | 17,442 |  |
| Share-based compensation expense included in operating expense | 20,312 |  |  | 15,406 |  |  | 56,477 |  |  | 45,456 |  |
| Share-based compensation expense capitalized in inventory, net | (193) |  |  | (114) |  |  | 64 |  |  | 39 |  |
| Total share-based compensation | $ | 22,471 |  |  | $ | 17,259 |  |  | $ | 62,970 |  |  | $ | 50,838 |  |

[0000936395-21-000040:notes:133]
As of July 31, 2021, total unrecognized share-based compensation expense was approximately $160.6 million, which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.58 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-21-000040:notes:134]
[same as prior period, unchanged from 0000936395-21-000034:notes:137]

[0000936395-21-000040:notes:135]
[same as prior period, unchanged from 0000936395-21-000034:notes:138]

[0000936395-21-000040:notes:136]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, ROU assets, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2021, equipment, building, furniture and fixtures, net, totaled $288.9 million, and operating ROU assets totaled $48.9 million both of which support asset groups within Ciena’s four operating segments and unallocated selling and general and administrative activities. As of July 31, 2021, finite-lived intangible assets, goodwill and maintenance spares are assigned to asset groups within the following segments (in thousands):

[0000936395-21-000040:notes:137]
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Other intangible assets, net | $ | 9,865 |  |  | $ | — |  |  | $ | 64,109 |  |  | $ | — |  |  | $ | 73,974 |  |
| Goodwill | $ | 66,329 |  |  | $ | 156,191 |  |  | $ | 89,049 |  |  | $ | — |  |  | $ | 311,569 |  |
| Maintenance spares, net | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 61,048 |  |  | $ | 61,048 |  |

[0000936395-21-000040:notes:138]
[same as prior period, unchanged from 0000936395-21-000034:notes:141]

[0000936395-21-000040:notes:139]
[same as prior period, unchanged from 0000936395-21-000034:notes:142]

[0000936395-21-000040:notes:140]
officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs (recoveries); interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt and provision (benefit) for income taxes.

[0000936395-21-000040:notes:141]
[same as prior period, unchanged from 0000936395-21-000034:notes:144]

[0000936395-21-000040:notes:142]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 244,535 |  |  | $ | 262,801 |  |  | $ | 612,378 |  |  | $ | 642,057 |  |
| Platform Software and Services | 31,526 |  |  | 24,299 |  |  | 95,692 |  |  | 74,918 |  |
| Blue Planet Automation Software and Services | (3,243) |  |  | (5,316) |  |  | 11 |  |  | (12,828) |  |
| Global Services | 55,507 |  |  | 52,676 |  |  | 147,567 |  |  | 151,744 |  |
| Total segment profit | 328,325 |  |  | 334,460 |  |  | 855,648 |  |  | 855,891 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 114,924 |  |  | 94,763 |  |  | 322,589 |  |  | 303,043 |  |
| General and administrative | 48,863 |  |  | 41,635 |  |  | 132,491 |  |  | 126,133 |  |
| Significant asset impairments and restructuring costs | 9,789 |  |  | 6,515 |  |  | 23,865 |  |  | 14,798 |  |
| Amortization of intangible assets | 5,967 |  |  | 5,840 |  |  | 17,896 |  |  | 17,532 |  |
| Acquisition and integration costs (recoveries) | 259 |  |  | (2,329) |  |  | 860 |  |  | 904 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (6,981) |  |  | (7,019) |  |  | (24,521) |  |  | (22,713) |  |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | (646) |  |
| Less: Provision (benefit) for income taxes | (96,690) |  |  | 38,750 |  |  | (63,271) |  |  | 73,872 |  |
| Consolidated net income | $ | 238,232 |  |  | $ | 142,267 |  |  | $ | 396,697 |  |  | $ | 296,250 |  |

[0000936395-21-000040:notes:143]
[same as prior period, unchanged from 0000936395-21-000034:notes:146]

[0000936395-21-000040:notes:144]
[same as prior period, unchanged from 0000936395-21-000034:notes:147]

[0000936395-21-000040:notes:145]
|  | July 31,2021 |  | October 31,2020 |
| Canada | $ | 242,495 |  |  | $ | 214,188 |  |
| United States | 54,050 |  |  | 65,321 |  |
| Other International | 41,329 |  |  | 49,894 |  |
| Total | $ | 337,874 |  |  | $ | 329,403 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-21-000040:notes:146]
COMMITMENTS AND CONTINGENCIES
Canadian Grant

[0000936395-21-000040:notes:147]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.2 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31,

[0000936395-21-000040:notes:148]
2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2021, Ciena has recorded CAD$48.6 million (approximately $39.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$8.0 million ($6.3 million) was recorded in the first nine months of fiscal 2021. As of July 31, 2021, amounts receivable from this grant were CAD$5.8 million ($4.7 million).

[0000936395-21-000040:notes:149]
Tax Contingencies

[0000936395-21-000040:notes:150]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-21-000040:notes:151]
Litigation

[0000936395-21-000040:notes:152]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-21-000040:notes:153]
SUBSEQUENT EVENTS
Stock Repurchase Program

[0000936395-21-000040:notes:154]
From the end of the third quarter of fiscal 2021 through September 3, 2021, Ciena repurchased an additional 176,815 shares of its common stock, for an aggregate purchase price of $10.0 million at an average price of $56.57 per share, inclusive of repurchases pending settlement. As of September 3, 2021, Ciena has repurchased an aggregate of 7,091,166 shares and has an aggregate of $200.0 million of authorized funds remaining under its stock repurchase program.

[0000936395-21-000040:notes:155]
Vyatta Routing and Switching Technology Acquisition

[0000936395-21-000040:notes:156]
On August 31, 2021, Ciena entered into a definitive agreement with AT&T to acquire its Vyatta virtual routing and switching technology. The acquisition reflects Ciena’s continued investment in its Routing and Switching solutions roadmap and resources. Ciena plans to integrate the engineering personnel to be hired through this transaction into its Routing and Switching research and development (R&D) organization.
