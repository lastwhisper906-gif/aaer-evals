# CIEN note change history — 0000936395-21-000034 → 0000936395-21-000040


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.2 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31,
  (was, 2021-06-09, similarity 0.9206):
[0000936395-21-000034:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $46.9 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject

- added (2021-09-08):
[0000936395-21-000040:note_history:2]
2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2021, Ciena has recorded CAD$48.6 million (approximately $39.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$8.0 million ($6.3 million) was recorded in the first nine months of fiscal 2021. As of July 31, 2021, amounts receivable from this grant were CAD$5.8 million ($4.7 million).

- removed (2021-09-08):
[0000936395-21-000034:note_history:3]
to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of May 1, 2021, Ciena has recorded CAD$45.5 million (approximately $37.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$4.9 million ($3.8 million) was recorded in the first six months of fiscal 2021. As of May 1, 2021, amounts receivable from this grant were CAD$2.7 million ($2.2 million).


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:4]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, because the duration and severity of COVID-19 pandemic are uncertain, certain of these estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.
  (was, 2021-06-09, similarity 0.9928):
[0000936395-21-000034:note_history:4]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States of America (“GAAP”) requires Ciena to make judgments, assumptions, and estimates that affect the amounts reported in the Condensed Consolidated Financial Statements and accompanying notes. The inputs into certain of Ciena’s judgments, assumptions, and estimates reflect, among other things, the information available to Ciena regarding the economic implications of the COVID-19 pandemic, and expectations as to its impact on Ciena’s business. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ materially from these estimates under different assumptions or conditions. To the extent that there are material differences between Ciena’s estimates and actual results, Ciena’s consolidated financial statements will be affected. In addition, including because the duration and severity of COVID-19 pandemic are uncertain, certain of such estimates could require further judgment or modification and therefore carry a higher degree of variability and volatility. As events continue to evolve, Ciena’s estimates may change materially in future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:5]
In June 2016, the Financial Accounting Standards Board (the ”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.
  (was, 2021-06-09, similarity 0.9976):
[0000936395-21-000034:note_history:5]
In June 2016, the Financial Accounting Standards Board (”FASB”) issued Accounting Standards Update No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectability of the reported amount. Ciena adopted ASU 2016-13 on a modified retrospective basis in the first quarter of fiscal year 2021 through a cumulative-effect adjustment at the beginning of the period of adoption and did not restate prior periods. The standard primarily impacts the value of Ciena’s accounts receivable, net and contract assets, net. Adoption of ASU 2016-13 did not have a material effect on Ciena’s financial position or results of operations.

- changed (2021-09-08):
[0000936395-21-000040:note_history:6]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default (the
  (was, 2021-06-09, similarity 0.9922):
[0000936395-21-000034:note_history:6]
Ciena estimates its allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, Ciena determines collectability by pooling assets with similar characteristics. The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. The allowances for credit losses are each measured by multiplying the exposure probability of default, the

- changed (2021-09-08):
[0000936395-21-000040:note_history:7]
probability the asset will default within a given time frame) by the loss given default rate (the percentage of the asset not expected to be collected due to default) based on the pool of assets.
  (was, 2021-06-09, similarity 0.9846):
[0000936395-21-000034:note_history:7]
probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

- changed (2021-09-08):
[0000936395-21-000040:note_history:8]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account a number of factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.
  (was, 2021-06-09, similarity 0.8113):
[0000936395-21-000034:note_history:8]
Probability of default rates are published by third-party credit rating agencies. Adjustments to Ciena’s exposure probability may take into account including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

- changed (2021-09-08):
[0000936395-21-000040:note_history:9]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
  (was, 2021-06-09, similarity 0.9985):
[0000936395-21-000034:note_history:9]
In March 2020, the FASB issued ASU No. 2020-04 (“ASU 2020-04”), Reference Rate Reform (Topic 848): Facilitation of the Effects of Reference Rate Reform on Financial Reporting. ASU 2020-04 provides temporary optional guidance on contract modifications and hedging accounting to ease the financial reporting burdens of the expected market transition from the London Interbank Offered Rate (“LIBOR”) to alternative reference rates. In January 2021, the FASB issued ASU 2021-01, which refines the scope of Topic 848 and clarifies some of its guidance as part of the FASB’s monitoring of global reference rate activities. The new guidance was effective upon issuance, and Ciena is allowed to elect to apply the amendments prospectively through December 31, 2022. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.
In December 2019, the FASB issued ASU No. 2019-12 (“ASU 2019-12”), Income Taxes (ASC 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing certain exceptions to the general principles in ASC 740. The amendments also improve consistent application of and simplify U.S. GAAP for other areas of ASC 740 by clarifying and amending existing guidance. ASU 2019-12 is effective for Ciena beginning in the first quarter of fiscal year 2022, and early adoption is permitted. Most amendments within this standard are required to be applied on a prospective basis, while certain amendments must be applied on a retrospective or modified retrospective basis. Ciena is currently evaluating the impact of this accounting standard update on its consolidated financial statements and related disclosures.


## cien:TermLoanAndConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: title_similarity, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:10]
|  |  | July 31, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 682,605 |  |  | $ | (1,332) |  |  | $ | (2,488) |  |  | $ | 678,785 |  |  | $ | 683,286 |  |
  (was, 2021-06-09, similarity 0.9896):
[0000936395-21-000034:note_history:10]
|  |  | May 1, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 684,337 |  |  | $ | (1,414) |  |  | $ | (2,638) |  |  | $ | 680,285 |  |  | $ | 683,286 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:11]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.5 million as of July 31, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.5 million during the first nine months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.
  (was, 2021-06-09, similarity 0.9901):
[0000936395-21-000034:note_history:11]
Deferred debt issuance costs that were deducted from the carrying amounts of the term loan totaled $2.6 million as of May 1, 2021 and $2.9 million at October 31, 2020. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.3 million during the first six months of each of fiscal 2021 and fiscal 2020. The carrying value of the term loan listed above is also net of any unamortized debt discounts.

- changed (2021-09-08):
[0000936395-21-000040:note_history:12]
As of July 31, 2021, the estimated fair value of the 2025 Term Loan was $680.9 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.
  (was, 2021-06-09, similarity 0.9921):
[0000936395-21-000034:note_history:12]
As of May 1, 2021, the estimated fair value of the 2025 Term Loan was $685.2 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:13]
|  | July 31, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,966 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 182,010 |  |
| Included in long-term investments | 60,887 |  |  | 7 |  |  | (6) |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 51 |  |  | $ | (6) |  |  | $ | 242,898 |  |
  (was, 2021-06-09, similarity 0.9932):
[0000936395-21-000034:note_history:13]
|  | May 1, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,764 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 151,816 |  |
| Included in long-term investments | 91,695 |  |  | 22 |  |  | (2) |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 74 |  |  | $ | (2) |  |  | $ | 243,531 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:14]
|  | July 31, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 181,966 |  |  | $ | 44 |  |  | $ | — |  |  | $ | 182,010 |  |
| Included in long-term investments | 60,887 |  |  | 7 |  |  | (6) |  |  | 60,888 |  |
|  | $ | 242,853 |  |  | $ | 51 |  |  | $ | (6) |  |  | $ | 242,898 |  |
  (was, 2021-06-09, similarity 0.9932):
[0000936395-21-000034:note_history:14]
|  | May 1, 2021 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 151,764 |  |  | $ | 52 |  |  | $ | — |  |  | $ | 151,816 |  |
| Included in long-term investments | 91,695 |  |  | 22 |  |  | (2) |  |  | 91,715 |  |
|  | $ | 243,459 |  |  | $ | 74 |  |  | $ | (2) |  |  | $ | 243,531 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:15]
The following table summarizes the final legal maturities of debt investments at July 31, 2021 (in thousands):
  (was, 2021-06-09, similarity 0.9761):
[0000936395-21-000034:note_history:15]
The following table summarizes the final legal maturities of debt investments at May 1, 2021 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:16]
|  |  | July 31, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 682,605 |  |  | $ | (1,332) |  |  | $ | (2,488) |  |  | $ | 678,785 |  |  | $ | 683,286 |  |
  (was, 2021-06-09, similarity 0.9896):
[0000936395-21-000034:note_history:16]
|  |  | May 1, 2021 |  | October 31, 2020 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 2025 Term Loan |  | $ | 684,337 |  |  | $ | (1,414) |  |  | $ | (2,638) |  |  | $ | 680,285 |  |  | $ | 683,286 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:17]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
  (was, 2021-06-09, similarity 0.9979):
[0000936395-21-000034:note_history:17]
|  | Quarter Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:18]
|  | Quarter Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Routing and Switching | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
  (was, 2021-06-09, similarity 0.9961):
[0000936395-21-000034:note_history:18]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Routing and Switching | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:19]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
  (was, 2021-06-09, similarity 0.9949):
[0000936395-21-000034:note_history:19]
|  | Six Months Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:20]
|  | Nine Months Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Routing Switching | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
  (was, 2021-06-09, similarity 0.9931):
[0000936395-21-000034:note_history:20]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Routing Switching | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,519 |  |  | $ | 30,092 |  |  | $ | 8,481 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:21]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 692,853 |  |  | $ | 713,340 |  |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |
| EMEA |  | 189,180 |  |  | 162,465 |  |  | 499,652 |  |  | 433,861 |  |
| APAC |  | 106,108 |  |  | 100,907 |  |  | 302,607 |  |  | 332,091 |  |
| Total revenue by geographic distribution |  | $ | 988,141 |  |  | $ | 976,712 |  |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |
  (was, 2021-06-09, similarity 0.8986):
[0000936395-21-000034:note_history:21]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 587,475 |  |  | $ | 650,381 |  |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |
| EMEA |  | 155,054 |  |  | 141,431 |  |  | 310,472 |  |  | 271,396 |  |
| APAC |  | 91,398 |  |  | 102,241 |  |  | 196,499 |  |  | 231,184 |  |
| Total revenue by geographic distribution |  | $ | 833,927 |  |  | $ | 894,053 |  |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |

- added (2021-09-08):
[0000936395-21-000040:note_history:22]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Verizon | $ | 131,892 |  |  | n/a |  | n/a |  | $ | 272,200 |  |
| Web-scale provider | 119,728 |  |  | n/a |  | n/a |  | n/a |
| AT&T | 119,199 |  |  | 114,963 |  |  | 313,140 |  |  | 304,645 |  |
| Total | $ | 370,819 |  |  | $ | 114,963 |  |  | $ | 313,140 |  |  | $ | 576,845 |  |

- removed (2021-09-08):
[0000936395-21-000034:note_history:23]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| AT&T | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 189,640 |  |
| Verizon | n/a |  | n/a |  | n/a |  | 203,630 |  |
| Total | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 393,270 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:24]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to “Routing and Switching.”
  (was, 2021-06-09, similarity 0.9993):
[0000936395-21-000034:note_history:24]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product lines, resulting in different economic risk profiles for each line. Effective as of the beginning of fiscal 2021, Ciena renamed its “Packet Networking” product line to “Routing and Switching.” This change, affecting only the presentation of such information, was made on a prospective basis and does not impact comparability of previous financial results. References to prior reported “Packet Networking” product line have been changed herein to“Routing and Switching.”

- changed (2021-09-08):
[0000936395-21-000040:note_history:25]
|  | Quarter Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 712,906 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 712,906 |  |
| Routing and Switching | 69,698 |  |  | — |  |  | — |  |  | — |  |  | 69,698 |  |
| Platform Software and Services | — |  |  | 56,945 |  |  | — |  |  | — |  |  | 56,945 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 16,607 |  |  | — |  |  | 16,607 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 74,006 |  |  | 74,006 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 46,653 |  |  | 46,653 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 11,326 |  |  | 11,326 |  |
| Total revenue by product line | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 782,604 |  |  | $ | 17,928 |  |  | $ | 4,558 |  |  | $ | 6,508 |  |  | $ | 811,598 |  |
| Services transferred over time | — |  |  | 39,017 |  |  | 12,049 |  |  | 125,477 |  |  | 176,543 |  |
| Total revenue by timing of revenue recognition | $ | 782,604 |  |  | $ | 56,945 |  |  | $ | 16,607 |  |  | $ | 131,985 |  |  | $ | 988,141 |  |
  (was, 2021-06-09, similarity 0.9979):
[0000936395-21-000034:note_history:25]
|  | Quarter Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 573,657 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 573,657 |  |
| Routing and Switching | 63,628 |  |  | — |  |  | — |  |  | — |  |  | 63,628 |  |
| Platform Software and Services | — |  |  | 56,688 |  |  | — |  |  | — |  |  | 56,688 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 23,958 |  |  | — |  |  | 23,958 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 70,418 |  |  | 70,418 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 37,999 |  |  | 37,999 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,579 |  |  | 7,579 |  |
| Total revenue by product line | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 637,285 |  |  | $ | 20,765 |  |  | $ | 10,765 |  |  | $ | 1,411 |  |  | $ | 670,226 |  |
| Services transferred over time | — |  |  | 35,923 |  |  | 13,193 |  |  | 114,585 |  |  | 163,701 |  |
| Total revenue by timing of revenue recognition | $ | 637,285 |  |  | $ | 56,688 |  |  | $ | 23,958 |  |  | $ | 115,996 |  |  | $ | 833,927 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:26]
|  | Quarter Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 722,512 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 722,512 |  |
| Routing and Switching | 79,756 |  |  | — |  |  | — |  |  | — |  |  | 79,756 |  |
| Platform Software and Services | — |  |  | 46,422 |  |  | — |  |  | — |  |  | 46,422 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 11,297 |  |  | — |  |  | 11,297 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 69,099 |  |  | 69,099 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 39,798 |  |  | 39,798 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 7,828 |  |  | 7,828 |  |
| Total revenue by product line | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 802,268 |  |  | $ | 15,838 |  |  | $ | 410 |  |  | $ | 3,300 |  |  | $ | 821,816 |  |
| Services transferred over time | — |  |  | 30,584 |  |  | 10,887 |  |  | 113,425 |  |  | 154,896 |  |
| Total revenue by timing of revenue recognition | $ | 802,268 |  |  | $ | 46,422 |  |  | $ | 11,297 |  |  | $ | 116,725 |  |  | $ | 976,712 |  |
  (was, 2021-06-09, similarity 0.9961):
[0000936395-21-000034:note_history:26]
|  | Quarter Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 654,294 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 654,294 |  |
| Routing and Switching | 64,167 |  |  | — |  |  | — |  |  | — |  |  | 64,167 |  |
| Platform Software and Services | — |  |  | 44,985 |  |  | — |  |  | — |  |  | 44,985 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 15,017 |  |  | — |  |  | 15,017 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 71,479 |  |  | 71,479 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 34,242 |  |  | 34,242 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 9,869 |  |  | 9,869 |  |
| Total revenue by product line | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 718,461 |  |  | $ | 16,978 |  |  | $ | 4,745 |  |  | $ | 4,677 |  |  | $ | 744,861 |  |
| Services transferred over time | — |  |  | 28,007 |  |  | 10,272 |  |  | 110,913 |  |  | 149,192 |  |
| Total revenue by timing of revenue recognition | $ | 718,461 |  |  | $ | 44,985 |  |  | $ | 15,017 |  |  | $ | 115,590 |  |  | $ | 894,053 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:27]
|  | Nine Months Ended July 31, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,798,888 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,798,888 |  |
| Routing and Switching | 197,632 |  |  | — |  |  | — |  |  | — |  |  | 197,632 |  |
| Platform Software and Services | — |  |  | 163,472 |  |  | — |  |  | — |  |  | 163,472 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 57,499 |  |  | — |  |  | 57,499 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 212,054 |  |  | 212,054 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 124,263 |  |  | 124,263 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 25,390 |  |  | 25,390 |  |
| Total revenue by product line | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,996,520 |  |  | $ | 54,756 |  |  | $ | 20,497 |  |  | $ | 9,776 |  |  | $ | 2,081,549 |  |
| Services transferred over time | — |  |  | 108,716 |  |  | 37,002 |  |  | 351,931 |  |  | 497,649 |  |
| Total revenue by timing of revenue recognition | $ | 1,996,520 |  |  | $ | 163,472 |  |  | $ | 57,499 |  |  | $ | 361,707 |  |  | $ | 2,579,198 |  |
  (was, 2021-06-09, similarity 0.9949):
[0000936395-21-000034:note_history:27]
|  | Six Months Ended May 1, 2021 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,085,981 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,085,981 |  |
| Routing and Switching | 127,934 |  |  | — |  |  | — |  |  | — |  |  | 127,934 |  |
| Platform Software and Services | — |  |  | 106,527 |  |  | — |  |  | — |  |  | 106,527 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 40,892 |  |  | — |  |  | 40,892 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 138,049 |  |  | 138,049 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 77,610 |  |  | 77,610 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 14,064 |  |  | 14,064 |  |
| Total revenue by product line | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,213,915 |  |  | $ | 36,828 |  |  | $ | 15,939 |  |  | $ | 3,268 |  |  | $ | 1,269,950 |  |
| Services transferred over time | — |  |  | 69,699 |  |  | 24,953 |  |  | 226,455 |  |  | 321,107 |  |
| Total revenue by timing of revenue recognition | $ | 1,213,915 |  |  | $ | 106,527 |  |  | $ | 40,892 |  |  | $ | 229,723 |  |  | $ | 1,591,057 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:28]
|  | Nine Months Ended August 1, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,968,355 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,968,355 |  |
| Routing Switching | 211,432 |  |  | — |  |  | — |  |  | — |  |  | 211,432 |  |
| Platform Software and Services | — |  |  | 143,295 |  |  | — |  |  | — |  |  | 143,295 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 41,779 |  |  | — |  |  | 41,779 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 202,370 |  |  | 202,370 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 108,994 |  |  | 108,994 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 27,452 |  |  | 27,452 |  |
| Total revenue by product line | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,179,787 |  |  | $ | 45,930 |  |  | $ | 8,891 |  |  | $ | 12,174 |  |  | $ | 2,246,782 |  |
| Services transferred over time | — |  |  | 97,365 |  |  | 32,888 |  |  | 326,642 |  |  | 456,895 |  |
| Total revenue by timing of revenue recognition | $ | 2,179,787 |  |  | $ | 143,295 |  |  | $ | 41,779 |  |  | $ | 338,816 |  |  | $ | 2,703,677 |  |
  (was, 2021-06-09, similarity 0.9931):
[0000936395-21-000034:note_history:28]
|  | Six Months Ended May 2, 2020 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,245,844 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 1,245,844 |  |
| Routing Switching | 131,675 |  |  | — |  |  | — |  |  | — |  |  | 131,675 |  |
| Platform Software and Services | — |  |  | 96,873 |  |  | — |  |  | — |  |  | 96,873 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 30,482 |  |  | — |  |  | 30,482 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 133,271 |  |  | 133,271 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 69,196 |  |  | 69,196 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 19,624 |  |  | 19,624 |  |
| Total revenue by product line | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 1,377,519 |  |  | $ | 30,092 |  |  | $ | 8,481 |  |  | $ | 8,874 |  |  | $ | 1,424,966 |  |
| Services transferred over time | — |  |  | 66,781 |  |  | 22,001 |  |  | 213,217 |  |  | 301,999 |  |
| Total revenue by timing of revenue recognition | $ | 1,377,519 |  |  | $ | 96,873 |  |  | $ | 30,482 |  |  | $ | 222,091 |  |  | $ | 1,726,965 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:29]
Ciena reports its sales geographically using the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.
  (was, 2021-06-09, similarity 0.9874):
[0000936395-21-000034:note_history:29]
Ciena reflects its sales geographically around the following markets: (i) Americas; (ii) Europe, Middle East and Africa (“EMEA”); and (iii) Asia Pacific, Japan and India (“APAC”). Americas includes activities in North America and South America. Within each geographic area, Ciena maintains specific teams or personnel that focus on a particular region, country, customer or market vertical. These teams include sales management, account salespersons and sales engineers, as well as services professionals and commercial management personnel. The following table reflects Ciena’s geographic distribution of revenue based principally on the relevant location for Ciena’s delivery of products and performance of services.

- changed (2021-09-08):
[0000936395-21-000040:note_history:30]
|  |  | Quarter Ended |  | Nine Months Ended |
|  |  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 692,853 |  |  | $ | 713,340 |  |  | $ | 1,776,939 |  |  | $ | 1,937,725 |  |
| EMEA |  | 189,180 |  |  | 162,465 |  |  | 499,652 |  |  | 433,861 |  |
| APAC |  | 106,108 |  |  | 100,907 |  |  | 302,607 |  |  | 332,091 |  |
| Total revenue by geographic distribution |  | $ | 988,141 |  |  | $ | 976,712 |  |  | $ | 2,579,198 |  |  | $ | 2,703,677 |  |
  (was, 2021-06-09, similarity 0.8986):
[0000936395-21-000034:note_history:30]
|  |  | Quarter Ended |  | Six Months Ended |
|  |  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  |  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Geographic distribution: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 587,475 |  |  | $ | 650,381 |  |  | $ | 1,084,086 |  |  | $ | 1,224,385 |  |
| EMEA |  | 155,054 |  |  | 141,431 |  |  | 310,472 |  |  | 271,396 |  |
| APAC |  | 91,398 |  |  | 102,241 |  |  | 196,499 |  |  | 231,184 |  |
| Total revenue by geographic distribution |  | $ | 833,927 |  |  | $ | 894,053 |  |  | $ | 1,591,057 |  |  | $ | 1,726,965 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:31]
Ciena’s revenue includes $623.9 million and $647.0 million of United States revenue for the third quarter of fiscal 2021 and 2020, respectively. For the nine months ended July 31, 2021 and August 1, 2020, United States revenue was $1.6 billion and $1.8 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.
  (was, 2021-06-09, similarity 0.8839):
[0000936395-21-000034:note_history:31]
Ciena’s revenue includes $518.6 million and $598.4 million of United States revenue for the second quarter of fiscal 2021 and 2020, respectively. For the six months ended May 1, 2021 and May 2, 2020, United States revenue was $1.0 billion and $1.1 billion, respectively. No other country accounted for 10% or more of total revenue for the periods presented above.

- added (2021-09-08):
[0000936395-21-000040:note_history:32]
|  | Quarter Ended |  | Nine Months Ended |
|  | July 31, |  | August 1, |  | July 31, |  | August 1, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| Verizon | $ | 131,892 |  |  | n/a |  | n/a |  | $ | 272,200 |  |
| Web-scale provider | 119,728 |  |  | n/a |  | n/a |  | n/a |
| AT&T | 119,199 |  |  | 114,963 |  |  | 313,140 |  |  | 304,645 |  |
| Total | $ | 370,819 |  |  | $ | 114,963 |  |  | $ | 313,140 |  |  | $ | 576,845 |  |

- added (2021-09-08):
[0000936395-21-000040:note_history:33]
The Web-scale provider noted in the above table purchased products from each of Ciena’s operating segments excluding Blue Planet® Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.

- changed (2021-09-08):
[0000936395-21-000040:note_history:34]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution and its OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2021-06-09, similarity 0.9954):
[0000936395-21-000034:note_history:34]
•Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, as well as planning tools and a number of legacy software solutions that support Ciena’s installed base of network solutions. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-09-08):
[0000936395-21-000040:note_history:35]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.
  (was, 2021-06-09, similarity 0.7354):
[0000936395-21-000034:note_history:35]
includes multi-domain service orchestration (MDSO), inventory management (BPI), route optimization and analysis (ROA), network function virtualization orchestration (NFVO), and unified assurance and analytics (UAA). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- changed (2021-09-08):
[0000936395-21-000040:note_history:36]
|  |  | Balance at July 31, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 878,229 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 98,812 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 183,899 |  |  | $ | 158,363 |  |
  (was, 2021-06-09, similarity 0.9893):
[0000936395-21-000034:note_history:36]
|  |  | Balance at May 1, 2021 |  | Balance at October 31, 2020 |
| Accounts receivable, net |  | $ | 716,779 |  |  | $ | 719,405 |  |
| Contract assets for unbilled accounts receivable, net |  | $ | 81,437 |  |  | $ | 85,843 |  |
| Deferred revenue |  | $ | 204,299 |  |  | $ | 158,363 |  |

- changed (2021-09-08):
[0000936395-21-000040:note_history:37]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $94.7 million and $91.8 million of revenue during the first nine months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the nine months ended July 31, 2021 and August 1, 2020.
  (was, 2021-06-09, similarity 0.9286):
[0000936395-21-000034:note_history:37]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $78.0 million and $76.5 million of revenue during the first six months of fiscal 2021 and 2020, respectively, that was included in the deferred revenue balance as of October 31, 2020 and November 2, 2019, respectively. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during the six months ended May 1, 2021 and May 2, 2020.

- changed (2021-09-08):
[0000936395-21-000040:note_history:38]
Capitalized contract acquisition costs consist of deferred sales commissions, and were $20.4 million and $15.3 million as of July 31, 2021 and October 31, 2020, respectively. Capitalized contract acquisition costs were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $16.8 million and $16.2 million during the first nine months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.
  (was, 2021-06-09, similarity 0.9308):
[0000936395-21-000034:note_history:38]
Capitalized contract acquisition costs consist of deferred sales commissions, were $18.4 million and $15.3 million as of May 1, 2021 and October 31, 2020, respectively, and were included in prepaid expenses and other and other long-term assets. The amortization expense associated with these costs was $10.7 million and $10.1 million during the first six months of fiscal 2021 and 2020, respectively, and was included in sales and marketing expense.

- changed (2021-09-08):
[0000936395-21-000040:note_history:39]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of July 31, 2021, the aggregate amount of RPO was $1.4 billion. As of July 31, 2021, Ciena expects approximately 85% of the RPO to be recognized as revenue within the next twelve months.
  (was, 2021-06-09, similarity 0.9874):
[0000936395-21-000034:note_history:39]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of May 1, 2021, the 
aggregate amount of RPO was $1.4 billion. As of May 1, 2021, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.

- removed (2021-09-08):
[0000936395-21-000034:note_history:40]
|  | Quarter Ended |  | Six Months Ended |
|  | May 1, |  | May 2, |  | May 1, |  | May 2, |
|  | 2021 |  | 2020 |  | 2021 |  | 2020 |
| AT&T | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 189,640 |  |
| Verizon | n/a |  | n/a |  | n/a |  | 203,630 |  |
| Total | $ | 125,138 |  |  | $ | 105,630 |  |  | $ | 193,941 |  |  | $ | 393,270 |  |

- removed (2021-09-08):
[0000936395-21-000034:note_history:41]
The customers identified above purchased products and services from each of Ciena’s operating segments.

- removed (2021-09-08):
[0000936395-21-000034:note_history:42]
•Blue Planet® Automation Software and Services is a comprehensive, micro-services, standards-based open software suite, together with related services, that enables customers to implement large-scale software and IT-led operations support system (OSS) transformations by transforming legacy networks into “service ready” networks, accelerating the creation, delivery and lifecycle management of new, cloud-based services. Ciena’s Blue Planet Automation Platform


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-09-08):
[0000936395-21-000040:note_history:43]
From the end of the third quarter of fiscal 2021 through September 3, 2021, Ciena repurchased an additional 176,815 shares of its common stock, for an aggregate purchase price of $10.0 million at an average price of $56.57 per share, inclusive of repurchases pending settlement. As of September 3, 2021, Ciena has repurchased an aggregate of 7,091,166 shares and has an aggregate of $200.0 million of authorized funds remaining under its stock repurchase program.
  (was, 2021-06-09, similarity 0.9584):
[0000936395-21-000034:note_history:43]
From the end of the second quarter of fiscal 2021 through June 4, 2021, Ciena repurchased an additional 195,920 shares of its common stock, for an aggregate purchase price of $10.4 million at an average price of $52.84 per share, inclusive of repurchases pending settlement. As of June 4, 2021, Ciena has repurchased an aggregate of 6,641,907 shares and has an aggregate of $225.6 million of authorized funds remaining under its stock repurchase program.

- added (2021-09-08):
[0000936395-21-000040:note_history:44]
Vyatta Routing and Switching Technology Acquisition

- added (2021-09-08):
[0000936395-21-000040:note_history:45]
On August 31, 2021, Ciena entered into a definitive agreement with AT&T to acquire its Vyatta virtual routing and switching technology. The acquisition reflects Ciena’s continued investment in its Routing and Switching solutions roadmap and resources. Ciena plans to integrate the engineering personnel to be hired through this transaction into its Routing and Switching research and development (R&D) organization.
