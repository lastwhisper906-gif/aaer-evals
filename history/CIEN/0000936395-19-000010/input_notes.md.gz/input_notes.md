# CIEN notes — 0000936395-19-000010


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-19-000010:notes:1]
PREPAID EXPENSES AND OTHER

[0000936395-19-000010:notes:2]
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-19-000010:notes:3]
|  | January 31, 2019 |  | October 31, 2018 |
| Prepaid VAT and other taxes | $ | 71,941 |  |  | $ | 82,518 |  |
| Contract assets for unbilled accounts receivable | 47,541 |  |  | — |  |
| Product demonstration equipment, net | 39,875 |  |  | 37,623 |  |
| Prepaid expenses | 29,146 |  |  | 32,987 |  |
| Other non-trade receivables | 19,866 |  |  | 25,716 |  |
| Capitalized commissions - short term | 8,650 |  |  | — |  |
| Financing receivable | 289 |  |  | 626 |  |
| Deferred deployment expense | 62 |  |  | 19,342 |  |
| Derivative assets | 52 |  |  | 133 |  |
|  | $ | 217,422 |  |  | $ | 198,945 |  |

[0000936395-19-000010:notes:4]
Depreciation of product demonstration equipment was $2.2 million and $2.4 million first three months of fiscal 2019 and 2018, respectively.


## cien:ScheduleOfStockRepurchaseProgramTableTextBlock

[0000936395-19-000010:notes:5]
[same as prior period, unchanged from 0000936395-18-000037:notes:3]

[0000936395-19-000010:notes:6]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2018 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 591,897 |  |  | 35.75 |  |  | 21,162 |  |
| Cumulative balance at January 31, 2019 | 591,897 |  |  | $ | 35.75 |  |  | $ | 21,162 |  |


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-19-000010:notes:7]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-19-000010:notes:8]
Outstanding Term Loan Payable

[0000936395-19-000010:notes:9]
2025 Term Loan

[0000936395-19-000010:notes:10]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-19-000010:notes:11]
|  |  | January 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 691,939 |  |  | $ | 693,450 |  |

[0000936395-19-000010:notes:12]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $4.1 million at January 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.

[0000936395-19-000010:notes:13]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of January 31, 2019 (in thousands):

[0000936395-19-000010:notes:14]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 698,250 |  |  | $ | (2,215 | ) |  | $ | (4,096 | ) |  | $ | 691,939 |  |  | $ | 694,759 |  |

[0000936395-19-000010:notes:15]
| (1) | The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-19-000010:notes:16]
COMMITMENTS AND CONTINGENCIES

[0000936395-19-000010:notes:17]
Canadian Grant

[0000936395-19-000010:notes:18]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $44.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2019, Ciena recorded a CAD$19.1 million (approximately $14.8 million) benefit as a reduction in research and development expense of which CAD$2.5 million (approximately $1.9 million) was recorded in the first three months of fiscal 2019. As of January 31, 2019, amounts receivable from this grant were CAD$10.1 million (approximately $7.7 million).

[0000936395-19-000010:notes:19]
Foreign Tax Contingencies

[0000936395-19-000010:notes:20]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-19-000010:notes:21]
Litigation

[0000936395-19-000010:notes:22]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement is subject to notice to class members and approval by the court. The terms of the proposed settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to the Ciena’s financial results. There is no assurance that the court will ultimately approve the settlement.

[0000936395-19-000010:notes:23]
Internal Investigation

[0000936395-19-000010:notes:24]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it has declined to prosecute this matter and that its investigation into the matter is now closed. Ciena continues to cooperate fully with the SEC in its investigation into this matter.

[0000936395-19-000010:notes:25]
Ciena’s operations in the relevant country constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year from 2012 through 2017. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

[0000936395-19-000010:notes:26]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-19-000010:notes:27]
[same as prior period, unchanged from 0000936395-18-000037:notes:47]

[0000936395-19-000010:notes:28]
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”), net of tax, for the three months ended January 31, 2019:

[0000936395-19-000010:notes:29]
|  | Unrealized |  | Unrealized Loss on |  | Unrealized Loss on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2018 | $ | (425 | ) |  | $ | (3,060 | ) |  | $ | 6,417 |  |  | $ | (8,712 | ) |  | $ | (5,780 | ) |
| Other comprehensive income (loss) before reclassifications | 301 |  |  | 402 |  |  | (7,593 | ) |  | 1,150 |  |  | (5,740 | ) |
| Amounts reclassified from AOCI | — |  |  | 1,158 |  |  | (278 | ) |  | — |  |  | 880 |  |
| Balance at January 31, 2019 | $ | (124 | ) |  | $ | (1,500 | ) |  | $ | (1,454 | ) |  | $ | (7,562 | ) |  | $ | (10,640 | ) |

[0000936395-19-000010:notes:30]
The following table summarizes the changes in AOCI, net of tax, for the three months ended January 31, 2018:

[0000936395-19-000010:notes:31]
|  | Unrealized |  | Unrealized Gainon |  | Unrealized Gain on |  | Cumulative |  |  |
|  | Loss on Available-for-sale Securities |  | Foreign Currency Forward Contracts |  | Forward Starting Interest Rate Swaps |  | Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2017 | $ | (451 | ) |  | $ | (1,386 | ) |  | $ | 218 |  |  | $ | (9,398 | ) |  | $ | (11,017 | ) |
| Other comprehensive income (loss) before reclassifications | (261 | ) |  | 1,624 |  |  | 3,479 |  |  | 8,202 |  |  | 13,044 |  |
| Amounts reclassified from AOCI | — |  |  | (71 | ) |  | 419 |  |  | — |  |  | 348 |  |
| Balance at January 31, 2018 | $ | (712 | ) |  | $ | 167 |  |  | $ | 4,116 |  |  | $ | (1,196 | ) |  | $ | 2,375 |  |

[0000936395-19-000010:notes:32]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue and research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income, net on the Condensed Consolidated Statements of Operations.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-19-000010:notes:33]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-19-000010:notes:34]
|  |  | Balance at January 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 761,186 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 47,542 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 136,141 |  |  | $ | 140,704 |  |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock

[0000936395-19-000010:notes:35]
[same as prior period, unchanged from 0000936395-18-000037:notes:53]

[0000936395-19-000010:notes:36]
|  | January 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,245 |  |  | $ | — |  |  | (102 | ) |  | $ | 119,143 |  |
|  | $ | 119,245 |  |  | $ | — |  |  | $ | (102 | ) |  | $ | 119,143 |  |

[0000936395-19-000010:notes:37]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | — |  |  | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-19-000010:notes:38]
[same as prior period, unchanged from 0000936395-18-000037:notes:56]

[0000936395-19-000010:notes:39]
[same as prior period, unchanged from 0000936395-18-000037:notes:57]

[0000936395-19-000010:notes:40]
As of January 31, 2019 and October 31, 2018, Ciena had forward contracts to hedge its foreign exchange exposure in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $155.7 million and $163.2 million as of January 31, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-19-000010:notes:41]
During the first three months of fiscal 2019 and fiscal 2018, in order to hedge foreign exchange exposures of certain balance sheet items, Ciena entered into forward contracts to mitigate risk due to variability in the Brazilian Real, Canadian Dollar, Euro, Australian Dollar and British Pound Sterling. The notional amount of these contracts was approximately $120.0 million and $162.6 million as of January 31, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-19-000010:notes:42]
[same as prior period, unchanged from 0000936395-18-000037:notes:60]

[0000936395-19-000010:notes:43]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 14 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). The interest rate swaps fix the LIBOR rate for $350 million of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of interest rate swaps in effect was $350.0 million as of January 31, 2019 and October 31, 2018.

[0000936395-19-000010:notes:44]
[same as prior period, unchanged from 0000936395-18-000037:notes:62]

[0000936395-19-000010:notes:45]
[same as prior period, unchanged from 0000936395-18-000037:notes:63]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000936395-19-000010:notes:46]
The tables below (in thousands) sets forth Ciena’s disaggregated revenue for the respective period:

[0000936395-19-000010:notes:47]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 22,272 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 34,300 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

[0000936395-19-000010:notes:48]
|  |  | Quarter Ended January 31, 2019 |
| Geographic distribution: |  |  |
| North America |  | $ | 485,506 |  |
| EMEA |  | 129,190 |  |
| CALA |  | 30,975 |  |
| APAC |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 778,527 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-19-000010:notes:49]
[same as prior period, unchanged from 0000936395-18-000037:notes:64]

[0000936395-19-000010:notes:50]
[same as prior period, unchanged from 0000936395-18-000037:notes:65]

[0000936395-19-000010:notes:51]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| Product costs | $ | 637 |  |  | $ | 672 |  |
| Service costs | 770 |  |  | 625 |  |
| Share-based compensation expense included in cost of sales | 1,407 |  |  | 1,297 |  |
| Research and development | 3,391 |  |  | 3,255 |  |
| Sales and marketing | 3,785 |  |  | 3,328 |  |
| General and administrative | 5,112 |  |  | 4,474 |  |
| Share-based compensation expense included in operating expense | 12,288 |  |  | 11,057 |  |
| Share-based compensation expense capitalized in inventory, net | 60 |  |  | 39 |  |
| Total share-based compensation | $ | 13,755 |  |  | $ | 12,393 |  |

[0000936395-19-000010:notes:52]
As of January 31, 2019, total unrecognized share-based compensation expense was approximately $119.7 million which relates to unvested stock unit awards and is expected to be recognized over a weighted-average period of 1.7 years.


## us-gaap:EarningsPerShareTextBlock

[0000936395-19-000010:notes:53]
[same as prior period, unchanged from 0000936395-18-000037:notes:68]

[0000936395-19-000010:notes:54]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income (loss) per common share (“Basic EPS”) and the diluted net income (loss) per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of stock unit awards; and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-19-000010:notes:55]
|  | Quarter Ended January 31, |
| Numerator | 2019 |  | 2018 |
| Net income (loss) | $ | 33,616 |  |  | $ | (473,363 | ) |

[0000936395-19-000010:notes:56]
|  | Quarter Ended January 31, |
| Denominator | 2019 |  | 2018 |
| Basic weighted average shares outstanding | 156,314 |  |  | 143,922 |  |
| Add: Shares underlying outstanding stock options and stock unit awards and issuable under employee stock purchase plan | 1,860 |  |  | — |  |
| Dilutive weighted average shares outstanding | 158,174 |  |  | 143,922 |  |

[0000936395-19-000010:notes:57]
|  | Quarter Ended January 31, |
| EPS | 2019 |  | 2018 |
| Basic EPS | $ | 0.22 |  |  | $ | (3.29 | ) |
| Diluted EPS | $ | 0.21 |  |  | $ | (3.29 | ) |

[0000936395-19-000010:notes:58]
[same as prior period, unchanged from 0000936395-18-000037:notes:73]

[0000936395-19-000010:notes:59]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| Shares underlying stock options and stock unit awards | 401 |  |  | 3,414 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) | — |  |  | 3,038 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) | — |  |  | 691 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 401 |  |  | 16,341 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-19-000010:notes:60]
[same as prior period, unchanged from 0000936395-18-000037:notes:77]

[0000936395-19-000010:notes:61]
|  | January 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 530,110 |  |  | $ | — |  |  | $ | — |  |  | $ | 530,110 |  |
| U.S. government obligations | — |  |  | 119,143 |  |  | — |  |  | 119,143 |  |
| Commercial paper | — |  |  | 19,998 |  |  | — |  |  | 19,998 |  |
| Foreign currency forward contracts | — |  |  | 52 |  |  | — |  |  | 52 |  |
| Total assets measured at fair value | $ | 530,110 |  |  | $ | 139,193 |  |  | $ | — |  |  | $ | 669,303 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,587 |  |  | $ | — |  |  | $ | 1,587 |  |
| Forward starting interest rate swap | — |  |  | 8,084 |  |  | — |  |  | 8,084 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,671 |  |  | $ | 10,900 |  |  | $ | 20,571 |  |

[0000936395-19-000010:notes:62]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 590,684 |  |  | $ | — |  |  | $ | — |  |  | $ | 590,684 |  |
| U.S. government obligations | — |  |  | 197,988 |  |  | — |  |  | 197,988 |  |
| Commercial paper | — |  |  | 69,888 |  |  | — |  |  | 69,888 |  |
| Foreign currency forward contracts | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Forward starting interest rate swaps | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-19-000010:notes:63]
[same as prior period, unchanged from 0000936395-18-000037:notes:80]

[0000936395-19-000010:notes:64]
|  | January 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 530,110 |  |  | $ | 19,998 |  |  | $ | — |  |  | $ | 550,108 |  |
| Short-term investments | — |  |  | 119,143 |  |  | — |  |  | 119,143 |  |
| Prepaid expenses and other | — |  |  | 52 |  |  | — |  |  | 52 |  |
| Total assets measured at fair value | $ | 530,110 |  |  | $ | 139,193 |  |  | $ | — |  |  | $ | 669,303 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,587 |  |  | $ | 7,491 |  |  | $ | 9,078 |  |
| Other long-term obligations | — |  |  | 8,084 |  |  | 3,409 |  |  | 11,493 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 9,671 |  |  | $ | 10,900 |  |  | $ | 20,571 |  |

[0000936395-19-000010:notes:65]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 590,684 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 650,609 |  |
| Short-term investments | — |  |  | 148,981 |  |  | — |  |  | 148,981 |  |
| Prepaid expenses and other | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Long-term investments | — |  |  | 58,970 |  |  | — |  |  | 58,970 |  |
| Other long-term assets | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Other long-term obligations | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-19-000010:notes:66]
[same as prior period, unchanged from 0000936395-18-000037:notes:83]

[0000936395-19-000010:notes:67]
[same as prior period, unchanged from 0000936395-18-000037:notes:84]

[0000936395-19-000010:notes:68]
Ciena’s Level 3 liability is included in both accrued liabilities and other long-term obligations and reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. The contingent consideration is valued by applying the income approach based upon a discounted cash flow technique using Monte Carlo simulations. As of January 31, 2019, there was no material change to the fair value.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-19-000010:notes:69]
[same as prior period, unchanged from 0000936395-18-000037:notes:85]

[0000936395-19-000010:notes:70]
On December 22, 2017, the Tax Cuts and Jobs Act (the "Tax Act") was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. The enactment of the Tax Act resulted in Ciena recording a provisional tax expense of $472.8 million in fiscal 2018. In the first quarter of fiscal 2019, the measurement period under the Tax Act concluded, which resulted in immaterial adjustments to our provisional estimates. In addition, the realizability of U.S. tax carryforwards is not impacted by the base erosion and anti-abuse tax (BEAT), and the BEAT is a period cost when incurred.

[0000936395-19-000010:notes:71]
The effective tax rate for the three months ended January 31, 2019 was lower than the effective tax rate for the three months ended January 31, 2018, primarily due to the impact of the Tax Act which reduced the U.S. federal corporate income tax rate from 35% to 21% effective January 1, 2018. The reduction of the U.S. federal corporate income tax rate during the three months ended January 31, 2018, required the remeasurement of the net deferred tax assets and liabilities (“DTA”). Also, Ciena recorded U.S. transition tax in the three months ended January 31, 2018.


## us-gaap:InventoryDisclosureTextBlock

[0000936395-19-000010:notes:72]
[same as prior period, unchanged from 0000936395-18-000037:notes:94]

[0000936395-19-000010:notes:73]
[same as prior period, unchanged from 0000936395-18-000037:notes:95]

[0000936395-19-000010:notes:74]
|  | January 31, 2019 |  | October 31, 2018 |
| Raw materials | $ | 75,525 |  |  | $ | 67,468 |  |
| Work-in-process | 10,045 |  |  | 9,589 |  |
| Finished goods | 225,937 |  |  | 188,575 |  |
| Deferred cost of goods sold | 60,616 |  |  | 48,057 |  |
|  | 372,123 |  |  | 313,689 |  |
| Provision for excess and obsolescence | (49,017 | ) |  | (50,938 | ) |
|  | $ | 323,106 |  |  | $ | 262,751 |  |

[0000936395-19-000010:notes:75]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first three months of fiscal 2019, Ciena recorded a provision for excess and obsolescence of $4.7 million, primarily related to a decrease in the forecasted demand for certain Networking Platforms products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-19-000010:notes:76]
The following table summarizes the final legal maturities of debt investments at January 31, 2019 (in thousands):

[0000936395-19-000010:notes:77]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 119,245 |  |  | $ | 119,143 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-19-000010:notes:78]
SHORT-TERM AND LONG-TERM INVESTMENTS


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-19-000010:notes:79]
Newly Issued Accounting Standards - Effective

[0000936395-19-000010:notes:80]
Revenue Recognition

[0000936395-19-000010:notes:81]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-19-000010:notes:82]
ASC 606 allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). Effective upon the start of its first quarter of fiscal 2019, Ciena adopted ASC 606 using the modified retrospective method and accordingly recognized the cumulative effect in accumulated deficit for those contracts that were not completed as of October 31, 2018. Accordingly, results for the reporting periods after October 31, 2018 are presented under ASC 606, while prior periods have not been adjusted and continue to be reported in accordance with Ciena’s historical revenue recognition practices. Refer to Opening Balance Adjustments below for the impact of ASC 606 adoption on Ciena’s Condensed Consolidated Financial Statements. In connection with its adoption of ASC 606, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 606.

[0000936395-19-000010:notes:83]
Revenue Recognition Timing Differences

[0000936395-19-000010:notes:84]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services.  Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-19-000010:notes:85]
Revenue Recognition Policy Under ASC 606

[0000936395-19-000010:notes:86]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration that Ciena expects to be entitled to in exchange for those products or services.

[0000936395-19-000010:notes:87]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-19-000010:notes:88]
•identification of the contract, or contracts, with a customer;

[0000936395-19-000010:notes:89]
•identification of the performance obligations in the contract;

[0000936395-19-000010:notes:90]
•determination of the transaction price;

[0000936395-19-000010:notes:91]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-19-000010:notes:92]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-19-000010:notes:93]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-19-000010:notes:94]
Purchase orders are invoiced based upon the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-19-000010:notes:95]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-19-000010:notes:96]
Significant Judgments

[0000936395-19-000010:notes:97]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price that Ciena would expect to sell that product or service on a stand alone basis at contract inception and be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-19-000010:notes:98]
Ciena applies judgment in determining the transaction price as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-19-000010:notes:99]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-19-000010:notes:100]
Capitalized Contract Acquisition Costs

[0000936395-19-000010:notes:101]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services, with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-19-000010:notes:102]
For the additional disclosures required as part of ASC 606 see Note 3 below.

[0000936395-19-000010:notes:103]
Impact of ASC 606 Adoption

[0000936395-19-000010:notes:104]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statement of Operations (in millions):

[0000936395-19-000010:notes:105]
|  |  | Quarter Ended January 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 778,527 |  |  | $ | (10,900 | ) |  | $ | 767,627 |  |
| Total cost of goods sold |  | $ | 455,186 |  |  | $ | (9,129 | ) |  | $ | 446,057 |  |
| Net income |  | $ | 33,616 |  |  | $ | (399 | ) |  | $ | 33,217 |  |
| Diluted net income per potential common share |  | $ | 0.21 |  |  | $ | — |  |  | $ | 0.21 |  |

[0000936395-19-000010:notes:106]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheet or any impact on net cash provided by operating activities as of January 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

[0000936395-19-000010:notes:107]
Opening Balance Adjustments

[0000936395-19-000010:notes:108]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 606 (in millions):

[0000936395-19-000010:notes:109]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

[0000936395-19-000010:notes:110]
| (1) | Unpaid accounts receivable and related deferred revenue related to rights and obligations in a contract are interdependent and therefore recorded net within Ciena’s balance sheet. This represents an increase of $12.5 million from the reversal of certain net unpaid accounts receivable and related deferred revenue. |

[0000936395-19-000010:notes:111]
| (2) | Represents a decrease of $2.5 million in deferred costs of goods sold due to change in revenue recognition for certain product sales. |

[0000936395-19-000010:notes:112]
| (3) | Represents increases of $27.5 million in unbilled accounts receivable for change in recognizing revenue for installation services, $3.9 million in unbilled accounts receivable from change in recognizing revenue for certain product sales and $9.6 million related to short-term capitalized acquisition costs (e.g., commissions) and a decrease of $19.5 million related to prepaid cost of installation services. |

[0000936395-19-000010:notes:113]
| (4) | Represents a decrease of $14.4 million in deferred tax asset, net, related to the unrecognized income tax effects of the net adjustments from the new revenue recognition standard. |

[0000936395-19-000010:notes:114]
| (5) | Represents an increase of $4.0 million related to long-term capitalized acquisition costs (e.g., commissions). |

[0000936395-19-000010:notes:115]
| (6) | Represents decreases of $23.6 million in deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue primarily due to a change in revenue recognition for certain product sales and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

[0000936395-19-000010:notes:116]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

[0000936395-19-000010:notes:117]
| (8) | Accumulated deficit impact from the adjustments noted above. |

[0000936395-19-000010:notes:118]
Intangibles

[0000936395-19-000010:notes:119]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.

[0000936395-19-000010:notes:120]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-19-000010:notes:121]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-19-000010:notes:122]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-19-000010:notes:123]
[same as prior period, unchanged from 0000936395-18-000037:notes:116]

[0000936395-19-000010:notes:124]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (the “SEC”). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America (“GAAP”) have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2018 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.

[0000936395-19-000010:notes:125]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-19-000010:notes:126]
INTEREST AND OTHER INCOME, NET

[0000936395-19-000010:notes:127]
The components of interest and other income, net, are as follows (in thousands):

[0000936395-19-000010:notes:128]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| Interest income | $ | 3,872 |  |  | $ | 2,444 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 22 |  |  | (699 | ) |
| Foreign currency exchange gains | 783 |  |  | 13 |  |
| Other | (424 | ) |  | (183 | ) |
| Interest and other income, net | $ | 4,253 |  |  | $ | 1,575 |  |

[0000936395-19-000010:notes:129]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use local currencies as their functional currencies. Ciena recorded $0.8 million in foreign currency exchange rate gains during the first three months of fiscal 2019 as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the remeasurement adjustments were recorded in interest and other income, net on the Condensed Consolidated Statements of Operations. Ciena recorded minimal gains in foreign currency exchange rates for the first three months of fiscal 2018. From time to time, Ciena uses foreign currency forwards to hedge this type of balance sheet exposure. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income, net on the Condensed Consolidated Statements of Operations. During the first three months of fiscal 2019, Ciena recorded minimal gains from non-hedge designated foreign currency forward contracts. During the first three months of fiscal 2018, Ciena recorded losses of $0.7 million from non-hedge designated foreign currency forward contracts.


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-19-000010:notes:130]
[same as prior period, unchanged from 0000936395-18-000037:notes:123]

[0000936395-19-000010:notes:131]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| Segment profit: |  |  |  |
| Networking Platforms | $ | 136,590 |  |  | $ | 88,569 |  |
| Software and Software-Related Services | 18,417 |  |  | 23,635 |  |
| Global Services | 39,701 |  |  | 41,037 |  |
| Total segment profit | 194,708 |  |  | 153,241 |  |
| Less: Non-performance operating expenses |  |  |  |
| Selling and marketing | 98,113 |  |  | 88,515 |  |
| General and administrative | 39,243 |  |  | 38,406 |  |
| Significant asset impairments and restructuring costs | 2,273 |  |  | 5,961 |  |
| Amortization of intangible assets | 5,528 |  |  | 3,623 |  |
| Acquisition and integration costs | 1,608 |  |  | — |  |
| Add: Other non-performance financial items |  |  |  |
| Interest expense and other income, net | (5,188 | ) |  | (12,159 | ) |
| Less: Provision for income taxes | 9,139 |  |  | 477,940 |  |
| Consolidated net income (loss) | $ | 33,616 |  |  | $ | (473,363 | ) |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-19-000010:notes:132]
[same as prior period, unchanged from 0000936395-18-000037:notes:125]

[0000936395-19-000010:notes:133]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| Revenue: |  |  |  |
| Networking Platforms |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | 427,401 |  |
| Packet Networking | 71,569 |  |  | 68,632 |  |
| Total Networking Platforms | 620,566 |  |  | 496,033 |  |
| Software and Software-Related Services |  |  |  |
| Platform Software and Services | 41,598 |  |  | 44,136 |  |
| Blue Planet Automation Software and Services | 14,974 |  |  | 9,351 |  |
| Total Software and Software-Related Services | 56,572 |  |  | 53,487 |  |
| Global Services |  |  |  |
| Maintenance Support and Training | 61,277 |  |  | 55,958 |  |
| Installation and Deployment | 30,622 |  |  | 30,016 |  |
| Consulting and Network Design | 9,490 |  |  | 10,641 |  |
| Total Global Services | 101,389 |  |  | 96,615 |  |
| Consolidated revenue | $ | 778,527 |  |  | $ | 646,135 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-19-000010:notes:134]
[same as prior period, unchanged from 0000936395-18-000037:notes:127]

[0000936395-19-000010:notes:135]
Ciena has undertaken a number of restructuring activities intended to reduce expense and to better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2019 (in thousands):

[0000936395-19-000010:notes:136]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2018 | $ | 2,108 |  |  | $ | 1,739 |  |  | $ | 3,847 |  |
| Additional liability recorded | 1,752 |  | (1) | 521 |  | (2) | 2,273 |  |
| Cash payments | (3,009 | ) |  | (548 | ) |  | (3,557 | ) |
| Balance at January 31, 2019 | $ | 851 |  |  | $ | 1,712 |  |  | $ | 2,563 |  |
| Current restructuring liabilities | $ | 851 |  |  | $ | 525 |  |  | $ | 1,376 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,187 |  |  | $ | 1,187 |  |

[0000936395-19-000010:notes:137]
| (1) | Reflects a global workforce reduction of approximately 10 employees during the first quarter of fiscal 2019 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000010:notes:138]
| (2) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and in Spokane, Washington. |

[0000936395-19-000010:notes:139]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2018 (in thousands):

[0000936395-19-000010:notes:140]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2017 | $ | 1,291 |  |  | $ | 1,648 |  |  | $ | 2,939 |  |
| Additional liability recorded | 4,413 |  | (1) | 1,548 |  | (2) | 5,961 |  |
| Cash payments | (4,459 | ) |  | (1,282 | ) |  | (5,741 | ) |
| Balance at January 31, 2018 | $ | 1,245 |  |  | $ | 1,914 |  |  | $ | 3,159 |  |
| Current restructuring liabilities | $ | 1,245 |  |  | $ | 590 |  |  | $ | 1,835 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,324 |  |  | $ | 1,324 |  |

[0000936395-19-000010:notes:141]
| (1) | Reflects a global workforce reduction of approximately 100 employees during the first quarter of fiscal 2018 as part of a business optimization strategy to improve gross margin, constrain operating expense and redesign certain business processes. |

[0000936395-19-000010:notes:142]
| (2) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California. |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-19-000010:notes:143]
REVENUE

[0000936395-19-000010:notes:144]
Disaggregation of Revenue

[0000936395-19-000010:notes:145]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-19-000010:notes:146]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

[0000936395-19-000010:notes:147]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-19-000010:notes:148]
| • | Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics. |

[0000936395-19-000010:notes:149]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-19-000010:notes:150]
•Software and Software-Related Services reflects sales of the following:

[0000936395-19-000010:notes:151]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design. Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver. Services includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

[0000936395-19-000010:notes:152]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

[0000936395-19-000010:notes:153]
Revenue from the software portions of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

[0000936395-19-000010:notes:154]
Ciena’s software platform revenue typically reflects either a perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, build-operate-transfer services relating to our software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-19-000010:notes:155]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

[0000936395-19-000010:notes:156]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services are generally recognized at a point in time upon completion of the service.

[0000936395-19-000010:notes:157]
Contract Balances

[0000936395-19-000010:notes:158]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.

[0000936395-19-000010:notes:159]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $39.4 million of revenue during the first three months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial in the first quarter of fiscal 2019.

[0000936395-19-000010:notes:160]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.4 million and $13.6 million as of January 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $4.1 million during the first three months of fiscal 2019 and was included in sales and marketing expense.

[0000936395-19-000010:notes:161]
Remaining Performance Obligations

[0000936395-19-000010:notes:162]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2019, the aggregate amount of RPO was $1.07 billion. As of January 31, 2019, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-19-000010:notes:163]
[same as prior period, unchanged from 0000936395-18-000037:notes:136]

[0000936395-19-000010:notes:164]
|  | January 31, 2019 |  | October 31, 2018 |
| Compensation, payroll related tax and benefits (1) | $ | 63,788 |  |  | $ | 140,277 |  |
| Warranty | 44,448 |  |  | 44,740 |  |
| Vacation | 43,614 |  |  | 42,507 |  |
| Contingent consideration | 7,491 |  |  | — |  |
| Capital lease obligations | 3,314 |  |  | 3,547 |  |
| Interest payable | 1,005 |  |  | 1,072 |  |
| Other | 109,052 |  |  | 107,932 |  |
|  | $ | 272,712 |  |  | $ | 340,075 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-19-000010:notes:165]
[same as prior period, unchanged from 0000936395-18-000037:notes:139]

[0000936395-19-000010:notes:166]
| Three Months Ended January 31, |  | Beginning Balance |  | Current Period Provisions |  | Settlements |  | Ending Balance |
| 2018 |  | $ | 42,456 |  |  | 4,657 |  |  | (4,587 | ) |  | $ | 42,526 |  |
| 2019 |  | $ | 44,740 |  |  | 3,891 |  |  | (4,183 | ) |  | $ | 44,448 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-19-000010:notes:167]
For the periods below, AT&T, a Web-scale provider and Verizon were the only customers that accounted for at least 10% of Ciena’s revenue as follows (in thousands):

[0000936395-19-000010:notes:168]
|  | Quarter Ended January 31, |
|  | 2019 |  | 2018 |
| AT&T | $ | 94,172 |  |  | $ | 90,645 |  |
| Web-scale provider | 89,514 |  |  | n/a |  |
| Verizon | 88,775 |  |  | 68,445 |  |
| Total | $ | 272,461 |  |  | $ | 159,090 |  |

[0000936395-19-000010:notes:169]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-19-000010:notes:170]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net was as follows (in thousands):

[0000936395-19-000010:notes:171]
|  | January 31, 2019 |  | October 31, 2018 |
| Canada | $ | 199,441 |  |  | $ | 198,028 |  |
| United States | 71,256 |  |  | 75,479 |  |
| Other International | 18,016 |  |  | 18,560 |  |
| Total | $ | 288,713 |  |  | $ | 292,067 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-19-000010:notes:172]
[same as prior period, unchanged from 0000936395-18-000037:notes:146]

[0000936395-19-000010:notes:173]
[same as prior period, unchanged from 0000936395-18-000037:notes:147]

[0000936395-19-000010:notes:174]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Software and Software-Related Services; and (iii) Global Services. See Note 3 to Ciena’s Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-19-000010:notes:175]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by Ciena's chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2019, equipment, building, furniture and fixtures, net totaled $288.7 million primarily supporting asset groups within Ciena’s Networking Platforms and Software and Software-Related Services segments and supporting Ciena’s unallocated selling and general and administrative activities. As of January 31, 2019, $27.4 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Networking Platforms segment and $111.6 million of Ciena’s intangible assets, net were assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of January 31, 2019, $65.8 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Networking Platforms segment and $232.2 million of Ciena’s Goodwill was assigned to asset groups within Ciena’s Software and Software-Related Services segment. As of January 31, 2019, all of the maintenance spares, net, totaling $46.1 million, were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-19-000010:notes:176]
[same as prior period, unchanged from 0000936395-18-000037:notes:161]

[0000936395-19-000010:notes:177]
[same as prior period, unchanged from 0000936395-18-000037:notes:162]

[0000936395-19-000010:notes:178]
Segment profit is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; significant asset impairments and restructuring costs; amortization of intangible assets; acquisition and integration costs; interest and other income, net; interest expense; and provision for income taxes.

[0000936395-19-000010:notes:179]
[same as prior period, unchanged from 0000936395-18-000037:notes:164]

[0000936395-19-000010:notes:180]
Ciena’s revenue includes $464.1 million and $383.4 million of United States revenue for the first quarter of fiscal 2019 and 2018, respectively. No other country accounted for 10% or more of total revenue in the first quarter of fiscal 2019 and 2018.

[0000936395-19-000010:notes:181]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the U.S. and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net was as follows (in thousands):

[0000936395-19-000010:notes:182]
[same as prior period, unchanged from 0000936395-18-000037:notes:168]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-19-000010:notes:183]
[same as prior period, unchanged from 0000936395-18-000037:notes:169]

[0000936395-19-000010:notes:184]
Except for the changes in certain policies described below, there have been no material changes to Ciena’s significant accounting policies, compared to the accounting policies described in Note 1, Ciena Corporation and Significant Accounting Policies and Estimates, in Notes to Consolidated Financial Statements in Item 8 of Part II of Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2018.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-19-000010:notes:185]
[same as prior period, unchanged from 0000936395-18-000037:notes:172]

[0000936395-19-000010:notes:186]
[same as prior period, unchanged from 0000936395-18-000037:notes:175]

[0000936395-19-000010:notes:187]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-19-000010:notes:188]
[same as prior period, unchanged from 0000936395-18-000037:notes:177]

[0000936395-19-000010:notes:189]
Stock Repurchases Related to Stock Unit Award Tax Withholdings

[0000936395-19-000010:notes:190]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The purchase price of $10.0 million for the shares of Ciena’s stock repurchased during the first quarter of fiscal 2019 is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:SubsequentEventsTextBlock

[0000936395-19-000010:notes:191]
SUBSEQUENT EVENTS

[0000936395-19-000010:notes:192]
From the end of the first quarter of fiscal 2019 through March 6, 2019, Ciena repurchased an additional 390,902 shares of its common stock, for an aggregate purchase price of $15.8 million at an average price of $40.54 per share, inclusive of repurchases pending settlement. As of March 6, 2019, Ciena has repurchased an aggregate of 982,799 shares and has an aggregate of $463.0 million of authorized funds remaining under its Stock Repurchase Program.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-19-000010:notes:193]
[same as prior period, unchanged from 0000936395-18-000037:notes:186]

[0000936395-19-000010:notes:194]
(1) Reduction is primarily due to the timing of bonus payments to employees under Ciena's annual cash incentive compensation plan.

[0000936395-19-000010:notes:195]
Settlement of Conversions of New Notes

[0000936395-19-000010:notes:196]
Debt Conversion Liability Associated With 3.75% Convertible Senior Notes due October 15, 2018 (“New Notes”)

[0000936395-19-000010:notes:197]
The New Notes provided Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares equal to the aggregate amount due upon conversion. On August 30, 2018, Ciena notified the noteholders that it had elected to settle conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of $400 million. Ciena became obligated to settle a portion of the conversion feature in cash and reclassified the cash conversion feature from equity to a derivative liability at its fair value of $164.2 million. On November 15, 2018, Ciena paid approximately $111.3 million in cash and issued 1.6 million shares in settlement of this embedded conversion feature.
