# CIEN note change history — 0000936395-18-000037 → 0000936395-19-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2019-03-11):
[0000936395-19-000010:note_history:1]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $44.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of January 31, 2019, Ciena recorded a CAD$19.1 million (approximately $14.8 million) benefit as a reduction in research and development expense of which CAD$2.5 million (approximately $1.9 million) was recorded in the first three months of fiscal 2019. As of January 31, 2019, amounts receivable from this grant were CAD$10.1 million (approximately $7.7 million).

- added (2019-03-11):
[0000936395-19-000010:note_history:2]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, the first of two purported stockholder class action lawsuits was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. The cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. During the fourth quarter of fiscal 2018, the parties agreed to the terms of a settlement of the action, which settlement is subject to notice to class members and approval by the court. The terms of the proposed settlement, which include a release and dismissal of all claims against all defendants without any liability or wrongdoing attributed to them, are not material to the Ciena’s financial results. There is no assurance that the court will ultimately approve the settlement.

- changed (2019-03-11):
[0000936395-19-000010:note_history:3]
Internal Investigation
  (was, 2018-09-05, similarity 0.9778):
[0000936395-18-000037:note_history:3]
Internal Investigations

- changed (2019-03-11):
[0000936395-19-000010:note_history:4]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. On December 10, 2018, the DOJ advised that it has declined to prosecute this matter and that its investigation into the matter is now closed. Ciena continues to cooperate fully with the SEC in its investigation into this matter.
  (was, 2018-09-05, similarity 0.8051):
[0000936395-18-000037:note_history:4]
During fiscal 2017, one of Ciena’s third-party vendors raised allegations about certain questionable payments to one or more individuals employed by a customer in a country in the ASEAN region. Ciena promptly initiated an internal investigation into the matter, with the assistance of outside counsel, which investigation corroborated direct and indirect payments to one such individual and sought to determine whether the payments may have violated applicable laws and regulations, including the U.S. Foreign Corrupt Practices Act (“FCPA”). In September 2017, Ciena voluntarily contacted the SEC and the U.S. Department of Justice (“DOJ”) to advise them of the relevant events and the findings of Ciena’s internal investigation. With the direct oversight of Ciena’s Board of Directors, Ciena continues to cooperate fully with the SEC and DOJ in their review of the investigation.

- changed (2019-03-11):
[0000936395-19-000010:note_history:5]
Ciena’s operations in the relevant country constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year from 2012 through 2017. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.
  (was, 2018-09-05, similarity 0.9807):
[0000936395-18-000037:note_history:5]
Ciena’s operations in the relevant country have constituted less than 1.5% of consolidated revenues as reported by Ciena in each fiscal year since 2012. Ciena does not currently anticipate that this matter will have a material adverse effect on its business, financial condition or results of operations. However, as discussions with the SEC and DOJ are ongoing, the ultimate outcome of this matter cannot be predicted at this time. As of the filing of this Report, no provision with respect to this matter has been made in Ciena’s consolidated financial statements. Any determination that Ciena’s operations or activities are not in compliance with the FCPA or other applicable laws or regulations could result in the imposition of fines, civil and criminal penalties, and equitable remedies, including disgorgement or injunctive relief.

- changed (2019-03-11):
[0000936395-19-000010:note_history:6]
In addition to the matters described in “Litigation” and “Internal Investigation” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.
  (was, 2018-09-05, similarity 0.9992):
[0000936395-18-000037:note_history:6]
In addition to the matters described in “Litigation” and “Internal Investigations” above, Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

- removed (2019-03-11):
[0000936395-18-000037:note_history:7]
During the second quarter of fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million ($45.0 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. During the nine months ended July 31,2018, Ciena recorded a CAD$13.5 million ($10.5 million) benefit as a reduction in research and development expense, related to eligible costs that it incurred from the commencement date of February 20, 2017 to July 31, 2018, because it believes it has complied with the conditions of the agreements entitling it to this amount. In future periods, through the term of these agreements, Ciena expects to record a quarterly benefit to operating expense of approximately CAD$2.95 million (approximately $2.3 million) related to these grants. As of July 31, 2018, amounts receivable from this grant were CAD$8.3 million ($6.3 million).

- removed (2019-03-11):
[0000936395-18-000037:note_history:8]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases were consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the U.S. Supreme Court, which petition was granted on June 27, 2017. The matter was stayed by the Superior Court pending the outcome of the Supreme Court’s decision. On March 20, 2018, the Supreme Court held that the Superior Court had subject matter jurisdiction over the case. A case management conference was held before the Superior Court during the third quarter of fiscal 2018. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-03-11):
[0000936395-19-000010:note_history:9]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2019 is a 52-week fiscal year. Fiscal 2018 was a 53-week fiscal year with the additional week occurring in the fourth quarter. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.

- removed (2019-03-11):
[0000936395-18-000037:note_history:10]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2018 is a 53-week fiscal year with the additional week occurring in the fourth quarter. Fiscal 2017 was a 52-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2019-03-11):
[0000936395-19-000010:note_history:11]
Revenue Recognition

- added (2019-03-11):
[0000936395-19-000010:note_history:12]
In May 2014, the Financial Accounting Standards Board ("FASB") issued Accounting Standards Codification (“ASC”) 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

- added (2019-03-11):
[0000936395-19-000010:note_history:13]
ASC 606 allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). Effective upon the start of its first quarter of fiscal 2019, Ciena adopted ASC 606 using the modified retrospective method and accordingly recognized the cumulative effect in accumulated deficit for those contracts that were not completed as of October 31, 2018. Accordingly, results for the reporting periods after October 31, 2018 are presented under ASC 606, while prior periods have not been adjusted and continue to be reported in accordance with Ciena’s historical revenue recognition practices. Refer to Opening Balance Adjustments below for the impact of ASC 606 adoption on Ciena’s Condensed Consolidated Financial Statements. In connection with its adoption of ASC 606, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 606.

- added (2019-03-11):
[0000936395-19-000010:note_history:14]
Revenue Recognition Timing Differences

- added (2019-03-11):
[0000936395-19-000010:note_history:15]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services.  Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to such amount not contingent upon future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence (“VSOE”) of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

- added (2019-03-11):
[0000936395-19-000010:note_history:16]
Revenue Recognition Policy Under ASC 606

- added (2019-03-11):
[0000936395-19-000010:note_history:17]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration that Ciena expects to be entitled to in exchange for those products or services.

- added (2019-03-11):
[0000936395-19-000010:note_history:18]
Ciena determines revenue recognition by applying the following five-step approach:

- added (2019-03-11):
[0000936395-19-000010:note_history:19]
•identification of the contract, or contracts, with a customer;

- added (2019-03-11):
[0000936395-19-000010:note_history:20]
•identification of the performance obligations in the contract;

- added (2019-03-11):
[0000936395-19-000010:note_history:21]
•determination of the transaction price;

- added (2019-03-11):
[0000936395-19-000010:note_history:22]
•allocation of the transaction price to the performance obligations in the contract; and

- added (2019-03-11):
[0000936395-19-000010:note_history:23]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

- added (2019-03-11):
[0000936395-19-000010:note_history:24]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

- added (2019-03-11):
[0000936395-19-000010:note_history:25]
Purchase orders are invoiced based upon the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

- added (2019-03-11):
[0000936395-19-000010:note_history:26]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

- added (2019-03-11):
[0000936395-19-000010:note_history:27]
Significant Judgments

- added (2019-03-11):
[0000936395-19-000010:note_history:28]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price that Ciena would expect to sell that product or service on a stand alone basis at contract inception and be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

- added (2019-03-11):
[0000936395-19-000010:note_history:29]
Ciena applies judgment in determining the transaction price as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

- added (2019-03-11):
[0000936395-19-000010:note_history:30]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

- added (2019-03-11):
[0000936395-19-000010:note_history:31]
Capitalized Contract Acquisition Costs

- added (2019-03-11):
[0000936395-19-000010:note_history:32]
Ciena has considered the impact of the guidance in ASC 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (“TRG”) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services, with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

- added (2019-03-11):
[0000936395-19-000010:note_history:33]
For the additional disclosures required as part of ASC 606 see Note 3 below.

- added (2019-03-11):
[0000936395-19-000010:note_history:34]
Impact of ASC 606 Adoption

- added (2019-03-11):
[0000936395-19-000010:note_history:35]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Condensed Consolidated Statement of Operations (in millions):

- added (2019-03-11):
[0000936395-19-000010:note_history:36]
|  |  | Quarter Ended January 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 778,527 |  |  | $ | (10,900 | ) |  | $ | 767,627 |  |
| Total cost of goods sold |  | $ | 455,186 |  |  | $ | (9,129 | ) |  | $ | 446,057 |  |
| Net income |  | $ | 33,616 |  |  | $ | (399 | ) |  | $ | 33,217 |  |
| Diluted net income per potential common share |  | $ | 0.21 |  |  | $ | — |  |  | $ | 0.21 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:37]
The increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services, where revenue was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Condensed Consolidated Balance Sheet or any impact on net cash provided by operating activities as of January 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 3 below.

- added (2019-03-11):
[0000936395-19-000010:note_history:38]
Opening Balance Adjustments

- added (2019-03-11):
[0000936395-19-000010:note_history:39]
The following table summarizes the cumulative effect of the changes made to Ciena’s Condensed Consolidated Balance Sheet in connection with the adoption of ASC 606 (in millions):

- added (2019-03-11):
[0000936395-19-000010:note_history:40]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:41]
| (1) | Unpaid accounts receivable and related deferred revenue related to rights and obligations in a contract are interdependent and therefore recorded net within Ciena’s balance sheet. This represents an increase of $12.5 million from the reversal of certain net unpaid accounts receivable and related deferred revenue. |

- added (2019-03-11):
[0000936395-19-000010:note_history:42]
| (2) | Represents a decrease of $2.5 million in deferred costs of goods sold due to change in revenue recognition for certain product sales. |

- added (2019-03-11):
[0000936395-19-000010:note_history:43]
| (3) | Represents increases of $27.5 million in unbilled accounts receivable for change in recognizing revenue for installation services, $3.9 million in unbilled accounts receivable from change in recognizing revenue for certain product sales and $9.6 million related to short-term capitalized acquisition costs (e.g., commissions) and a decrease of $19.5 million related to prepaid cost of installation services. |

- added (2019-03-11):
[0000936395-19-000010:note_history:44]
| (4) | Represents a decrease of $14.4 million in deferred tax asset, net, related to the unrecognized income tax effects of the net adjustments from the new revenue recognition standard. |

- added (2019-03-11):
[0000936395-19-000010:note_history:45]
| (5) | Represents an increase of $4.0 million related to long-term capitalized acquisition costs (e.g., commissions). |

- added (2019-03-11):
[0000936395-19-000010:note_history:46]
| (6) | Represents decreases of $23.6 million in deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue primarily due to a change in revenue recognition for certain product sales and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

- added (2019-03-11):
[0000936395-19-000010:note_history:47]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

- added (2019-03-11):
[0000936395-19-000010:note_history:48]
| (8) | Accumulated deficit impact from the adjustments noted above. |

- added (2019-03-11):
[0000936395-19-000010:note_history:49]
Intangibles

- changed (2019-03-11):
[0000936395-19-000010:note_history:50]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena's Condensed Consolidated Financial Statements.
  (was, 2018-09-05, similarity 0.7048):
[0000936395-18-000037:note_history:50]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. ASU 2018-15 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.

- removed (2019-03-11):
[0000936395-18-000037:note_history:51]
Government Grants

- removed (2019-03-11):
[0000936395-18-000037:note_history:52]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Condensed Consolidated Statement of Operations to which the grant activity relates. See Note 18 below.

- removed (2019-03-11):
[0000936395-18-000037:note_history:53]
In January 2017, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) No. 2017-01 (“ASU 2017-01”), Business Combinations: Clarifying the Definition of a Business, which clarifies the definition of a business with the objective of adding guidance to assist entities with evaluating whether transactions should be accounted for as acquisition or disposal of assets or businesses. The amendments in this update provide a screen to determine when a set of assets is not a business. The screen requires that when substantially all of the fair value of the gross assets acquired (or disposed of) is concentrated in a single identifiable asset or a group of similar identifiable assets, the set of assets is not a business. Ciena will evaluate the effect of the update at the time of any future acquisition or disposal. Ciena adopted ASU 2017-01 during the first quarter of fiscal 2018.

- removed (2019-03-11):
[0000936395-18-000037:note_history:54]
In August 2017, the FASB issued ASU No. 2017-12 (“ASU 2017-12”), Derivatives and Hedging: Targeted Improvements to Accounting for Hedging Activities, which improves the financial reporting of hedging relationships to better portray the economic results of an entity’s risk management activities in its financial statements and make certain targeted improvements to simplify the application of the hedge accounting guidance in current GAAP. The amendments in this update better align an entity’s risk management activities and financial reporting for hedging relationships, through changes to both the designation and measurement guidance for qualifying hedging relationships and presentation of hedge results. Ciena adopted ASU 2017-12 during the first quarter of fiscal 2018. For hedges for which Ciena has elected to exclude the spot-forward difference from assessment of effectiveness, Ciena has elected to amortize the difference on a straight-line basis. Ciena will record amortization in earnings each period with an offsetting entry to other comprehensive income, and all changes in fair value over the term of the derivative in other comprehensive income. The application of this accounting standard did not have a material impact on Ciena’s Condensed Consolidated Financial Statements.

- removed (2019-03-11):
[0000936395-18-000037:note_history:55]
In March 2016, the FASB issued ASU No. 2016-09 (“ASU 2016-09”), Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. Ciena adopted ASU 2016-09 during the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018. Additionally, the consolidated statements of cash flows will include excess tax benefits as an operating activity, on a prospective basis as a result of the adoption. Finally, Ciena has elected to recognize forfeitures when they occur, rather than to estimate the impact of forfeitures when the award is granted. Accordingly, Ciena recognized approximately $0.8 million for this change through a cumulative effect adjustment recorded to opening retained earnings in the first quarter of fiscal 2018.

- removed (2019-03-11):
[0000936395-18-000037:note_history:56]
In May 2014, the FASB issued ASU No. 2014-09 (“ASU 2014-09”), Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. ASU 2014-09 affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. ASU 2014-09 will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. ASU 2014-09 also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.

- removed (2019-03-11):
[0000936395-18-000037:note_history:57]
For multiple element software arrangements where vendor-specific objective evidence (“VSOE”) of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. The adoption of ASU 2014-09 will require Ciena to determine the stand alone selling price for each of the software and software-related deliverables at contract inception, and Ciena consequently expects certain software deliverables will be recognized at a point in time rather than over a period of time.

- removed (2019-03-11):
[0000936395-18-000037:note_history:58]
Ciena also expects certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

- removed (2019-03-11):
[0000936395-18-000037:note_history:59]
Ciena has considered the impact of the guidance in Accounting Standards Codification (“ASC”) 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the FASB Transition Resource Group for Revenue Recognition (TRG) with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena has elected to implement the practical expedient clause allowing for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less, and amortized over the period of performance, if the period of the asset recognition is greater than one year.

- removed (2019-03-11):
[0000936395-18-000037:note_history:60]
Ciena expects to implement ASU 2014-09 using the modified retrospective approach whereby the cumulative effect at adoption will be presented as an adjustment to the opening balance of retained earnings. The comparative information will not be restated and will continue to be reported under the accounting standards in effect for those periods. ASU 2014-09 will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- removed (2019-03-11):
[0000936395-18-000037:note_history:61]
In August 2018, the FASB issued ASU No. 2018-09 (“ASU 2018-09”), Codification Improvements which does not prescribe any new accounting guidance, but instead makes minor improvements and clarifications of several different FASB Accounting Standards Codification areas based on comments and suggestions made by various stakeholders. Certain updates are applicable immediately while others provide for a transition period to adopt as part of the next fiscal year beginning after December 15, 2018.  Ciena is currently evaluating this guidance to determine the impact it may have on the consolidated financial statements.

- removed (2019-03-11):
[0000936395-18-000037:note_history:62]
In August 2018, the FASB issued ASU No. 2018-14 (“ASU 2018-14”), Compensation -Retirement Benefits - Defined Benefit Plans which modifies the disclosure requirements on company-sponsored defined benefit plans. ASU 2018-14 is effective for Ciena beginning in the first quarter of fiscal year 2021, early adoption is permitted. Ciena is currently evaluating this guidance to determine the impact on its disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:63]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-09-05, similarity 0.9563):
[0000936395-18-000037:note_history:63]
The net carrying value of Ciena’s Term Loan due January 30, 2022 (the “2022 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2019-03-11):
[0000936395-19-000010:note_history:64]
|  |  | January 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 691,939 |  |  | $ | 693,450 |  |
  (was, 2018-09-05, similarity 0.9016):
[0000936395-18-000037:note_history:64]
|  |  | July 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 392,972 |  |

- changed (2019-03-11):
[0000936395-19-000010:note_history:65]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2025 Term Loan totaled $4.1 million at January 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2025 Term Loan. The amortization of deferred debt issuance costs for the 2025 Term Loan is included in interest expense, and was $0.2 million during the first three months of fiscal 2019. The carrying value of the 2025 Term Loan listed above is also net of any unamortized debt discounts.
  (was, 2018-09-05, similarity 0.9086):
[0000936395-18-000037:note_history:65]
Deferred debt issuance costs that were deducted from the carrying amounts of the 2022 Term Loan totaled $2.6 million at July 31, 2018 and $3.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the 2022 Term Loan. The amortization of deferred debt issuance costs for the 2022 Term Loan is included in interest expense, and was $0.5 million and $0.4 million during the first nine months of fiscal 2018 and 2017, respectively. The carrying values of the 2022 Term Loan listed above are also net of any unamortized debt discounts.

- changed (2019-03-11):
[0000936395-19-000010:note_history:66]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of January 31, 2019 (in thousands):
  (was, 2018-09-05, similarity 0.8806):
[0000936395-18-000037:note_history:66]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of the 2022 Term Loan were as follows as of July 31, 2018 (in thousands):

- changed (2019-03-11):
[0000936395-19-000010:note_history:67]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 698,250 |  |  | $ | (2,215 | ) |  | $ | (4,096 | ) |  | $ | 691,939 |  |  | $ | 694,759 |  |
  (was, 2018-09-05, similarity 0.8847):
[0000936395-18-000037:note_history:67]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 395,000 |  |  | $ | (1,580 | ) |  | $ | (2,557 | ) |  | $390,863 |

- removed (2019-03-11):
[0000936395-18-000037:note_history:68]
The following table sets forth the carrying value and the estimated fair value of the 2022 Term Loan (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:69]
|  |  | July 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 396,481 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:70]
Outstanding Convertible Notes Payable

- removed (2019-03-11):
[0000936395-18-000037:note_history:71]
The net carrying values of Ciena’s outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:72]
|  |  | July 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,435 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 194,717 |  |
|  |  | $ | 549,311 |  |  | $ | 543,009 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:73]
Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $0.9 million at July 31, 2018 and $2.1 million at October 31, 2017. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $1.2 million during both the first nine months of fiscal 2018 and 2017. The carrying values of the convertible notes payable listed above also include accretion of principal and are net of any unamortized debt discounts.

- removed (2019-03-11):
[0000936395-18-000037:note_history:74]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of July 31, 2018 (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:75]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (36 | ) |  | $ | 61,234 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (125 | ) |  | $ | (170 | ) |  | $ | 288,435 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 207,809 |  |  | $ | (7,437 | ) |  | $ | (730 | ) |  | $ | 199,642 |  |  | $ | 43,131 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:76]
| (1) | Includes accretion of principal at a rate of 1.85% per year. |

- removed (2019-03-11):
[0000936395-18-000037:note_history:77]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2018:

- removed (2019-03-11):
[0000936395-18-000037:note_history:78]
|  |  | July 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 77,047 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,435 |  |  | 363,078 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 233,269 |  |
|  |  | $ | 549,311 |  |  | $ | 673,394 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:79]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:DebtSecuritiesAvailableForSaleTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:80]
|  | January 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,245 |  |  | $ | — |  |  | (102 | ) |  | $ | 119,143 |  |
|  | $ | 119,245 |  |  | $ | — |  |  | $ | (102 | ) |  | $ | 119,143 |  |
  (was, 2018-09-05, similarity 0.6409):
[0000936395-18-000037:note_history:80]
|  | July 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 199,415 |  |  | $ | — |  |  | (418 | ) |  | $ | 198,997 |  |
| Included in long-term investments | 29,538 |  |  | — |  |  | (73 | ) |  | 29,465 |  |
|  | $ | 228,953 |  |  | $ | — |  |  | $ | (491 | ) |  | $ | 228,462 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,941 |  |  | 2 |  |  | — |  |  | $ | 29,943 |  |
|  | $ | 29,941 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,943 |  |

- changed (2019-03-11):
[0000936395-19-000010:note_history:81]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | — |  |  | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
  (was, 2018-09-05, similarity 0.9069):
[0000936395-18-000037:note_history:81]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:82]
|  | January 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 119,245 |  |  | $ | — |  |  | (102 | ) |  | $ | 119,143 |  |
|  | $ | 119,245 |  |  | $ | — |  |  | $ | (102 | ) |  | $ | 119,143 |  |
  (was, 2018-09-05, similarity 0.6409):
[0000936395-18-000037:note_history:82]
|  | July 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 199,415 |  |  | $ | — |  |  | (418 | ) |  | $ | 198,997 |  |
| Included in long-term investments | 29,538 |  |  | — |  |  | (73 | ) |  | 29,465 |  |
|  | $ | 228,953 |  |  | $ | — |  |  | $ | (491 | ) |  | $ | 228,462 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,941 |  |  | 2 |  |  | — |  |  | $ | 29,943 |  |
|  | $ | 29,941 |  |  | $ | 2 |  |  | $ | — |  |  | $ | 29,943 |  |

- changed (2019-03-11):
[0000936395-19-000010:note_history:83]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | — |  |  | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
  (was, 2018-09-05, similarity 0.9069):
[0000936395-18-000037:note_history:83]
|  | October 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 249,498 |  |  | $ | — |  |  | $ | (305 | ) |  | $ | 249,193 |  |
| Included in long-term investments | 49,910 |  |  | — |  |  | (127 | ) |  | 49,783 |  |
|  | $ | 299,408 |  |  | $ | — |  |  | $ | (432 | ) |  | $ | 298,976 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,939 |  |  | 1 |  |  | — |  |  | $ | 29,940 |  |
|  | $ | 29,939 |  |  | $ | 1 |  |  | $ | — |  |  | $ | 29,940 |  |

- changed (2019-03-11):
[0000936395-19-000010:note_history:84]
The following table summarizes the final legal maturities of debt investments at January 31, 2019 (in thousands):
  (was, 2018-09-05, similarity 0.9765):
[0000936395-18-000037:note_history:84]
The following table summarizes the final legal maturities of debt investments at July 31, 2018 (in thousands):

- changed (2019-03-11):
[0000936395-19-000010:note_history:85]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 119,245 |  |  | $ | 119,143 |  |
  (was, 2018-09-05, similarity 0.7426):
[0000936395-18-000037:note_history:85]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 229,356 |  |  | $ | 228,940 |  |
| Due in 1-2 years | 29,538 |  |  | 29,465 |  |
|  | $ | 258,894 |  |  | $ | 258,405 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:86]
The net carrying value of Ciena’s Term Loan due September 28, 2025 (the “2025 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):
  (was, 2018-09-05, similarity 0.9563):
[0000936395-18-000037:note_history:86]
The net carrying value of Ciena’s Term Loan due January 30, 2022 (the “2022 Term Loan”) was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2019-03-11):
[0000936395-19-000010:note_history:87]
|  |  | January 31, 2019 |  | October 31, 2018 |
| Term Loan Payable due September 28, 2025 |  | $ | 691,939 |  |  | $ | 693,450 |  |
  (was, 2018-09-05, similarity 0.9016):
[0000936395-18-000037:note_history:87]
|  |  | July 31, 2018 |  | October 31, 2017 |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 392,972 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:88]
The following table sets forth, in thousands, the net carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2018:

- removed (2019-03-11):
[0000936395-18-000037:note_history:89]
|  |  | July 31, 2018 |
|  |  | Net Carrying Value |  | Fair Value(1) |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 77,047 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) |  | 288,435 |  |  | 363,078 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 233,269 |  |
|  |  | $ | 549,311 |  |  | $ | 673,394 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:90]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimates the fair value of its outstanding convertible notes using a market approach based on observable inputs, such as current market transactions involving comparable securities. |

- removed (2019-03-11):
[0000936395-18-000037:note_history:91]
The net carrying values of Ciena’s outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:92]
|  |  | July 31, 2018 |  | October 31, 2017 |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original) |  | $ | 61,234 |  |  | $ | 61,071 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (New) |  | 288,435 |  |  | 287,221 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 199,642 |  |  | 194,717 |  |
|  |  | $ | 549,311 |  |  | $ | 543,009 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:93]
The following table sets forth the carrying value and the estimated fair value of the 2022 Term Loan (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:94]
|  |  | July 31, 2018 |
|  |  | Carrying Value |  | Fair Value(1) |
| Term Loan Payable due January 30, 2022 |  | $ | 390,863 |  |  | $ | 396,481 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:95]
| (1) | The 2022 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2022 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:96]
The principal balance, unamortized debt discount, deferred debt issuance costs, net carrying value and fair value of the 2025 Term Loan were as follows as of January 31, 2019 (in thousands):
  (was, 2018-09-05, similarity 0.8806):
[0000936395-18-000037:note_history:96]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability components of the 2022 Term Loan were as follows as of July 31, 2018 (in thousands):

- changed (2019-03-11):
[0000936395-19-000010:note_history:97]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Fair Value(1) |
| Term Loan Payable due September 28, 2025 | $ | 698,250 |  |  | $ | (2,215 | ) |  | $ | (4,096 | ) |  | $ | 691,939 |  |  | $ | 694,759 |  |
  (was, 2018-09-05, similarity 0.8847):
[0000936395-18-000037:note_history:97]
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |
| Term Loan Payable due January 30, 2022 | $ | 395,000 |  |  | $ | (1,580 | ) |  | $ | (2,557 | ) |  | $390,863 |

- added (2019-03-11):
[0000936395-19-000010:note_history:98]
| (1) | The 2025 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of the 2025 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2019-03-11):
[0000936395-18-000037:note_history:99]
The principal balance, unamortized debt discount, deferred debt issuance costs and net carrying value of the liability and equity components of Ciena’s outstanding issues of convertible notes were as follows as of July 31, 2018 (in thousands):

- removed (2019-03-11):
[0000936395-18-000037:note_history:100]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Debt Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| 3.75% Convertible Senior Notes, due October 15, 2018 (Original) | $ | 61,270 |  |  | $ | — |  |  | $ | (36 | ) |  | $ | 61,234 |  |  | $ | — |  |
| 3.75% Convertible Senior Notes, due October 15, 2018 (New) | $ | 288,730 |  |  | $ | (125 | ) |  | $ | (170 | ) |  | $ | 288,435 |  |  | $ | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (1) | $ | 207,809 |  |  | $ | (7,437 | ) |  | $ | (730 | ) |  | $ | 199,642 |  |  | $ | 43,131 |  |

- removed (2019-03-11):
[0000936395-18-000037:note_history:101]
| (1) | Includes accretion of principal at a rate of 1.85% per year |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-03-11):
[0000936395-19-000010:note_history:102]
The tables below (in thousands) sets forth Ciena’s disaggregated revenue for the respective period:

- added (2019-03-11):
[0000936395-19-000010:note_history:103]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 22,272 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 34,300 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:104]
|  |  | Quarter Ended January 31, 2019 |
| Geographic distribution: |  |  |
| North America |  | $ | 485,506 |  |
| EMEA |  | 129,190 |  |
| CALA |  | 30,975 |  |
| APAC |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 778,527 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: no_prior_note, score: 0.0

- added (2019-03-11):
[0000936395-19-000010:note_history:105]
REVENUE

- added (2019-03-11):
[0000936395-19-000010:note_history:106]
Disaggregation of Revenue

- added (2019-03-11):
[0000936395-19-000010:note_history:107]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

- added (2019-03-11):
[0000936395-19-000010:note_history:108]
The tables below (in thousands) sets forth Ciena’s disaggregated revenue for the respective period:

- added (2019-03-11):
[0000936395-19-000010:note_history:109]
|  | Quarter Ended January 31, 2019 |
|  | Networking Platforms |  | Software and Software-Related Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | $ | — |  |  | $ | — |  |  | $ | 548,997 |  |
| Packet Networking | 71,569 |  |  | — |  |  | — |  |  | 71,569 |  |
| Platform Software and Services | — |  |  | 41,598 |  |  | — |  |  | 41,598 |  |
| Blue Planet Automation Software and Services | — |  |  | 14,974 |  |  | — |  |  | 14,974 |  |
| Maintenance Support and Training | — |  |  | — |  |  | 61,277 |  |  | 61,277 |  |
| Installation and Deployment | — |  |  | — |  |  | 30,622 |  |  | 30,622 |  |
| Consulting and Network Design | — |  |  | — |  |  | 9,490 |  |  | 9,490 |  |
| Total revenue by product line | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 620,566 |  |  | $ | 22,272 |  |  | $ | 3,566 |  |  | $ | 646,404 |  |
| Services transferred over time | — |  |  | 34,300 |  |  | 97,823 |  |  | 132,123 |  |
| Total revenue by timing of revenue recognition | $ | 620,566 |  |  | $ | 56,572 |  |  | $ | 101,389 |  |  | $ | 778,527 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:110]
|  |  | Quarter Ended January 31, 2019 |
| Geographic distribution: |  |  |
| North America |  | $ | 485,506 |  |
| EMEA |  | 129,190 |  |
| CALA |  | 30,975 |  |
| APAC |  | 132,856 |  |
| Total revenue by geographic distribution |  | $ | 778,527 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:111]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

- added (2019-03-11):
[0000936395-19-000010:note_history:112]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, the 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

- added (2019-03-11):
[0000936395-19-000010:note_history:113]
| • | Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics. |

- added (2019-03-11):
[0000936395-19-000010:note_history:114]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

- added (2019-03-11):
[0000936395-19-000010:note_history:115]
•Software and Software-Related Services reflects sales of the following:

- added (2019-03-11):
[0000936395-19-000010:note_history:116]
| • | Ciena’s Blue Planet Automation Software and Services, which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their network to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design. Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver. Services includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. |

- added (2019-03-11):
[0000936395-19-000010:note_history:117]
| • | Ciena’s Platform Software and Services, which provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks further adoption of its MCP software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other platform software solutions. Software-related services includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms and operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. |

- added (2019-03-11):
[0000936395-19-000010:note_history:118]
Revenue from the software portions of this segment is included in product revenue on the Condensed Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Condensed Consolidated Statements of Operations.

- added (2019-03-11):
[0000936395-19-000010:note_history:119]
Ciena’s software platform revenue typically reflects either a perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, build-operate-transfer services relating to our software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

- added (2019-03-11):
[0000936395-19-000010:note_history:120]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations. |

- added (2019-03-11):
[0000936395-19-000010:note_history:121]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services are generally recognized at a point in time upon completion of the service.

- added (2019-03-11):
[0000936395-19-000010:note_history:122]
Contract Balances

- added (2019-03-11):
[0000936395-19-000010:note_history:123]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

- added (2019-03-11):
[0000936395-19-000010:note_history:124]
|  |  | Balance at January 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 761,186 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 47,542 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 136,141 |  |  | $ | 140,704 |  |

- added (2019-03-11):
[0000936395-19-000010:note_history:125]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional upon completion of future performance obligations. These amounts are primarily related to installation and deployment services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer.

- added (2019-03-11):
[0000936395-19-000010:note_history:126]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $39.4 million of revenue during the first three months of fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods were immaterial in the first quarter of fiscal 2019.

- added (2019-03-11):
[0000936395-19-000010:note_history:127]
Capitalized Contract Acquisition Costs

- added (2019-03-11):
[0000936395-19-000010:note_history:128]
Capitalized contract acquisition costs consist of deferred sales commissions and were $12.4 million and $13.6 million as of January 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $4.1 million during the first three months of fiscal 2019 and was included in sales and marketing expense.

- added (2019-03-11):
[0000936395-19-000010:note_history:129]
Remaining Performance Obligations

- added (2019-03-11):
[0000936395-19-000010:note_history:130]
Remaining Performance Obligations (RPO) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of January 31, 2019, the aggregate amount of RPO was $1.07 billion. As of January 31, 2019, Ciena expects approximately 80% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-03-11):
[0000936395-19-000010:note_history:131]
From the end of the first quarter of fiscal 2019 through March 6, 2019, Ciena repurchased an additional 390,902 shares of its common stock, for an aggregate purchase price of $15.8 million at an average price of $40.54 per share, inclusive of repurchases pending settlement. As of March 6, 2019, Ciena has repurchased an aggregate of 982,799 shares and has an aggregate of $463.0 million of authorized funds remaining under its Stock Repurchase Program.
  (was, 2018-09-05, similarity 0.9617):
[0000936395-18-000037:note_history:131]
From the end of the third quarter of fiscal 2018 through August 31, 2018, Ciena repurchased an additional 472,542 shares of its common stock, for an aggregate purchase price of $12.4 million at an average price of $26.25 per share, inclusive of repurchases pending settlement. As of August 31, 2018, Ciena has repurchased an aggregate of 3,500,660 shares and has an aggregate of $212.8 million of authorized funds remaining under its Stock Repurchase Program.

- removed (2019-03-11):
[0000936395-18-000037:note_history:132]
Stock Repurchases Related to Restricted Stock Unit Tax Withholding

- removed (2019-03-11):
[0000936395-18-000037:note_history:133]
Historically, Ciena satisfied employee tax withholding obligations due upon the vesting of restricted stock units (RSUs) through directed open market sales to cover the employee tax obligations. Beginning in the fourth quarter of fiscal 2018, Ciena will change this practice to repurchase shares of common stock delivered with respect to such RSUs in settlement of employee tax withholding obligations due upon the vesting of RSUs. The purchase price for the shares of Ciena’s stock repurchased will be reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.

- removed (2019-03-11):
[0000936395-18-000037:note_history:134]
Settlement of Conversions of New Notes

- removed (2019-03-11):
[0000936395-18-000037:note_history:135]
Ciena has elected to settle any conversion of the New Notes prior to maturity in a combination of cash and shares, with the cash portion not to exceed an aggregate amount of approximately $400 million. Per the settlement provisions of the indenture governing conversion of the New Notes, an amount of $288.7 million (representing the aggregate principal amount) will be paid in cash on October 15, 2018. To the extent Ciena’s shares trade during the relevant settlement period in excess of the $20.17 per share conversion price, Ciena will pay up to approximately $111.3 million of any amounts due in excess of the aggregate principal amount in cash, and any remaining amounts due will be settled in shares. These amounts will be settled during the first quarter of fiscal 2019.

- removed (2019-03-11):
[0000936395-18-000037:note_history:136]
DonRiver Acquisition

- removed (2019-03-11):
[0000936395-18-000037:note_history:137]
On August 31, 2018, Ciena entered into a definitive agreement to acquire privately-held DonRiver Holdings, LLC, a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. The transaction is expected to close during Ciena’s fourth quarter of fiscal 2018 and is subject to customary closing conditions.
