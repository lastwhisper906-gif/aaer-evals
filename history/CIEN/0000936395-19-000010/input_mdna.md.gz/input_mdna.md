# CIEN MD&A — 0000936395-19-000010


## mdna

[0000936395-19-000010:mdna:1]
[same as prior period, unchanged from 0000936395-18-000037:mdna:1]

[0000936395-19-000010:mdna:2]
[same as prior period, unchanged from 0000936395-18-000037:mdna:2]

[0000936395-19-000010:mdna:3]
This quarterly report contains statements that discuss future events or expectations, projections of results of operations or financial condition, changes in the markets for our products and services, trends in our business, business prospects and strategies and other “forward-looking” information. In some cases, you can identify “forward-looking statements” by words like “may,” “will,” “can,” “should,” “could,” “expects,” “future,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential,” “projects,” “targets,” or “continue” or the negative of those words and other comparable words. These statements may relate to, among other things, our competitive landscape; market conditions and growth opportunities; factors impacting our industry and markets; factors impacting the businesses of network operators and their network architectures; adoption of next-generation network technology and software programmability and automation of networks; our strategy, including our research and development, supply chain and go-to-market initiatives; efforts to increase application of our solutions in customer networks and to increase the reach of our business into new or growing customer and geographic markets; our backlog and seasonality in our business; expectations for our financial results, revenue, gross margin, operating expense and key operating measures in future periods; the adequacy of our sources of liquidity to satisfy our working capital needs, capital expenditures, and other liquidity requirements; business initiatives including information technology (IT) transitions or initiatives; the impact of the Tax Cuts and Jobs Act and changes in our effective tax rates; and market risks associated with financial instruments and foreign currency exchange rates. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially due to factors such as:

[0000936395-19-000010:mdna:4]
[same as prior period, unchanged from 0000936395-18-000037:mdna:4]

[0000936395-19-000010:mdna:5]
[same as prior period, unchanged from 0000936395-18-000037:mdna:5]

[0000936395-19-000010:mdna:6]
[same as prior period, unchanged from 0000936395-18-000037:mdna:6]

[0000936395-19-000010:mdna:7]
[same as prior period, unchanged from 0000936395-18-000037:mdna:7]

[0000936395-19-000010:mdna:8]
[same as prior period, unchanged from 0000936395-18-000037:mdna:8]

[0000936395-19-000010:mdna:9]
[same as prior period, unchanged from 0000936395-18-000037:mdna:9]

[0000936395-19-000010:mdna:10]
[same as prior period, unchanged from 0000936395-18-000037:mdna:10]

[0000936395-19-000010:mdna:11]
[same as prior period, unchanged from 0000936395-18-000037:mdna:11]

[0000936395-19-000010:mdna:12]
[same as prior period, unchanged from 0000936395-18-000037:mdna:12]

[0000936395-19-000010:mdna:13]
| • | the international scale of our operations; |

[0000936395-19-000010:mdna:14]
| • | fluctuations in currency exchange rates; |

[0000936395-19-000010:mdna:15]
[same as prior period, unchanged from 0000936395-18-000037:mdna:14]

[0000936395-19-000010:mdna:16]
[same as prior period, unchanged from 0000936395-18-000037:mdna:15]

[0000936395-19-000010:mdna:17]
[same as prior period, unchanged from 0000936395-18-000037:mdna:16]

[0000936395-19-000010:mdna:18]
[same as prior period, unchanged from 0000936395-18-000037:mdna:17]

[0000936395-19-000010:mdna:19]
[same as prior period, unchanged from 0000936395-18-000037:mdna:18]

[0000936395-19-000010:mdna:20]
[same as prior period, unchanged from 0000936395-18-000037:mdna:19]

[0000936395-19-000010:mdna:21]
[same as prior period, unchanged from 0000936395-18-000037:mdna:20]

[0000936395-19-000010:mdna:22]
[same as prior period, unchanged from 0000936395-18-000037:mdna:21]

[0000936395-19-000010:mdna:23]
[same as prior period, unchanged from 0000936395-18-000037:mdna:22]

[0000936395-19-000010:mdna:24]
[same as prior period, unchanged from 0000936395-18-000037:mdna:23]

[0000936395-19-000010:mdna:25]
[same as prior period, unchanged from 0000936395-18-000037:mdna:24]

[0000936395-19-000010:mdna:26]
[same as prior period, unchanged from 0000936395-18-000037:mdna:25]

[0000936395-19-000010:mdna:27]
[same as prior period, unchanged from 0000936395-18-000037:mdna:26]

[0000936395-19-000010:mdna:28]
[same as prior period, unchanged from 0000936395-18-000037:mdna:27]

[0000936395-19-000010:mdna:29]
[same as prior period, unchanged from 0000936395-18-000037:mdna:28]

[0000936395-19-000010:mdna:30]
[same as prior period, unchanged from 0000936395-18-000037:mdna:29]

[0000936395-19-000010:mdna:31]
[same as prior period, unchanged from 0000936395-18-000037:mdna:30]

[0000936395-19-000010:mdna:32]
| • | our ability to commercialize and grow our software business and address networking strategies including software-defined networking and network function virtualization; |

[0000936395-19-000010:mdna:33]
[same as prior period, unchanged from 0000936395-18-000037:mdna:32]

[0000936395-19-000010:mdna:34]
| • | the impact of the Tax Cuts and Jobs Act, changes in tax regulations and related accounting, and changes in our effective tax rates; |

[0000936395-19-000010:mdna:35]
[same as prior period, unchanged from 0000936395-18-000037:mdna:34]

[0000936395-19-000010:mdna:36]
[same as prior period, unchanged from 0000936395-18-000037:mdna:35]

[0000936395-19-000010:mdna:37]
[same as prior period, unchanged from 0000936395-18-000037:mdna:36]

[0000936395-19-000010:mdna:38]
| • | adverse results in litigation matters. |

[0000936395-19-000010:mdna:39]
[same as prior period, unchanged from 0000936395-18-000037:mdna:40]

[0000936395-19-000010:mdna:40]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide network hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions and other emerging network operators.

[0000936395-19-000010:mdna:41]
Our solutions include a diverse portfolio of high-capacity Networking Platform products, which can be applied from the network core to network access points, and which allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We also offer Platform Software that provides management and domain control of our next-generation packet and optical platforms and automates network lifecycle operations including provisioning equipment and services. In addition, through our comprehensive suite of Blue Planet Automation Software, we enable network operators to use network data and analytics to drive enhanced automation across multi-vendor and multi-domain network environments, accelerate service delivery and enable an increasingly predictive and autonomous network infrastructure. To complement our hardware and software solutions, we offer a broad range of attached

[0000936395-19-000010:mdna:42]
[same as prior period, unchanged from 0000936395-18-000037:mdna:39]

[0000936395-19-000010:mdna:43]
and software-related services that help our customers design, optimize, integrate, deploy, manage and maintain their networks and associated operational environments. Through our complete portfolio of solutions, we enable our customers to transform their network into a dynamic, programmable environment driven by automation and analytics, which we refer to as the Adaptive Network. Our solutions for the Adaptive Network create business and operational value for our customers, enabling them to introduce new revenue-generating services, reduce costs and maximize the return on their network infrastructure investment.

[0000936395-19-000010:mdna:44]
Increased Stock Repurchase Program. On December 13, 2018, we announced that our Board of Directors authorized a new program to repurchase up to $500 million of our common stock. This program replaces our previously authorized repurchase program, under which we were authorized to repurchase up to $300 million of our common stock through the end of fiscal 2020. We may purchase shares at management’s discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. We may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time. For additional information, including our repurchase activities under the previously authorized program, see Note 16 and Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report and Item 2 of Part II of this report.

[0000936395-19-000010:mdna:45]
Settlement Upon Conversion of 3.75% Convertible Senior Notes due October 15, 2018 (New). During the fourth quarter of fiscal 2018, we elected to settle conversion of our 3.75% Convertible Senior Notes due October 15, 2018 (New) (the “New Notes”) in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of approximately $400 million. Upon conversion of the New Notes by the holders in advance of maturity, on October 15, 2018, we paid in cash an amount of $288.7 million representing the aggregate principal amount outstanding of the New Notes. The New Notes thereafter ceased to be outstanding. In addition, because Ciena common stock traded in excess of the $20.17 per share conversion price during an observation period from October 15, 2018 through November 9, 2018, on November 15, 2018, we paid an additional $111.3 million in cash and issued approximately 1.6 million shares with respect to the “in the money” portion of the notes in settlement of the conversion. See Note 11 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for more information relating to the settlement of our New Notes.

[0000936395-19-000010:mdna:46]
[same as prior period, unchanged from 0000936395-18-000037:mdna:50]

[0000936395-19-000010:mdna:47]
For additional information on our business, industry, market opportunity, competitive landscape, and strategy, see our annual report on Form 10-K for the fiscal year ended October 31, 2018.

[0000936395-19-000010:mdna:48]
[same as prior period, unchanged from 0000936395-18-000037:mdna:53]

[0000936395-19-000010:mdna:49]
[same as prior period, unchanged from 0000936395-18-000037:mdna:54]

[0000936395-19-000010:mdna:50]
We have the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Software and Software-Related Services; and (iii) Global Services. See Note 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-19-000010:mdna:51]
Quarter ended January 31, 2019 compared to the quarter ended January 31, 2018

[0000936395-19-000010:mdna:52]
As of the first quarter of fiscal 2019, we adopted ASC 606 using the modified retrospective method. See Notes 2 and 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report for the impact of this adoption on our financial results.

[0000936395-19-000010:mdna:53]
[same as prior period, unchanged from 0000936395-18-000037:mdna:57]

[0000936395-19-000010:mdna:54]
During the first quarter of fiscal 2019, approximately 17.7% of our revenue was non-U.S. Dollar denominated, including sales in Euros, Japanese Yen, Canadian Dollars, Brazilian Reais, British Pounds and Indian Rupee. During the first quarter of fiscal 2019, as compared to the first quarter of fiscal 2018, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars slightly decreased by approximately $9.2 million, or 1.2%, as compared to the first quarter of fiscal 2018, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000010:mdna:55]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 548,997 |  |  | 70.5 |  | $ | 427,401 |  |  | 66.1 |  | $ | 121,596 |  |  | 28.5 |  |
| Packet Networking | 71,569 |  |  | 9.2 |  | 68,632 |  |  | 10.6 |  | 2,937 |  |  | 4.3 |  |
| Total Networking Platforms | 620,566 |  |  | 79.7 |  | 496,033 |  |  | 76.7 |  | 124,533 |  |  | 25.1 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Platform Software and Services | 41,598 |  |  | 5.3 |  | 44,136 |  |  | 6.8 |  | (2,538 | ) |  | (5.8 | ) |
| Blue Planet Automation Software and Services | 14,974 |  |  | 1.9 |  | 9,351 |  |  | 1.5 |  | 5,623 |  |  | 60.1 |  |
| Total Software and Software-Related Services | 56,572 |  |  | 7.2 |  | 53,487 |  |  | 8.3 |  | 3,085 |  |  | 5.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 61,277 |  |  | 8.0 |  | 55,958 |  |  | 8.7 |  | 5,319 |  |  | 9.5 |  |
| Installation and Deployment | 30,622 |  |  | 3.9 |  | 30,016 |  |  | 4.7 |  | 606 |  |  | 2.0 |  |
| Consulting and Network Design | 9,490 |  |  | 1.2 |  | 10,641 |  |  | 1.6 |  | (1,151 | ) |  | (10.8 | ) |
| Total Global Services | 101,389 |  |  | 13.1 |  | 96,615 |  |  | 15.0 |  | 4,774 |  |  | 4.9 |  |
| Consolidated revenue | $ | 778,527 |  |  | 100.0 |  | $ | 646,135 |  |  | 100.0 |  | $ | 132,392 |  |  | 20.5 |  |

[0000936395-19-000010:mdna:56]
[same as prior period, unchanged from 0000936395-18-000037:mdna:60]

[0000936395-19-000010:mdna:57]
[same as prior period, unchanged from 0000936395-18-000037:mdna:61]

[0000936395-19-000010:mdna:58]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:59]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $121.6 million of our Converged Packet Optical products and $2.9 million of our Packet Networking products. |

[0000936395-19-000010:mdna:60]
| ◦ | Converged Packet Optical sales primarily reflect sales increases of $79.3 million of our Waveserver stackable interconnect system and $53.6 million of our 6500 Packet-Optical Platform. These increases were partially offset by a sales decrease of $12.6 million of our 5410/5430 Reconfigurable Switching Systems. Waveserver |

[0000936395-19-000010:mdna:61]
stackable interconnect system sales reflect increased sales to Web-scale providers, which represent a growing portion of our business as our business continues to diversify. The sales increase of our 6500 Packet-Optical Platform is primarily due to increased sales to AT&T and other communications service providers, partially offset by decreased sales to Web-scale providers.

[0000936395-19-000010:mdna:62]
| ◦ | Packet Networking sales increased, primarily reflecting $17.9 million in initial sales of our 6500 Packet Transport System, partially offset by a sales decrease of $15.1 million of our 3000 and 5000 families of service delivery and aggregation switches, primarily due to decreased sales to AT&T and other communications service providers. |

[0000936395-19-000010:mdna:63]
| ◦ | Software and Software-Related Services segment revenue increased, primarily reflecting a sales increase of $5.6 million of our Blue Planet Automation Software and Services, partially offset by a sales decrease of $2.5 million of our Platform Software and Services. The increase in our Blue Planet Automation Software and Services includes sales of $4.9 million and $3.0 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. |

[0000936395-19-000010:mdna:64]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $5.3 million of our maintenance support and training services. |

[0000936395-19-000010:mdna:65]
Our operating segments engage in business and operations across four geographic regions: North America; Europe, Middle

[0000936395-19-000010:mdna:66]
East and Africa (“EMEA”); Caribbean and Latin America (“CALA”); and Asia Pacific and India (“APAC”). Results for North

[0000936395-19-000010:mdna:67]
America include only activities in the U.S. and Canada. The following table reflects our geographic distribution of revenue

[0000936395-19-000010:mdna:68]
principally based on the relevant location for our delivery of products and performance of services. Our revenue, when

[0000936395-19-000010:mdna:69]
considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network

[0000936395-19-000010:mdna:70]
projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular

[0000936395-19-000010:mdna:71]
quarter.  The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000010:mdna:72]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| North America | $ | 485,506 |  |  | 62.3 |  | $ | 402,909 |  |  | 62.4 |  | $ | 82,597 |  |  | 20.5 |  |
| EMEA | 129,190 |  |  | 16.6 |  | 97,834 |  |  | 15.1 |  | 31,356 |  |  | 32.1 |  |
| CALA | 30,975 |  |  | 4.0 |  | 34,563 |  |  | 5.3 |  | (3,588 | ) |  | (10.4 | ) |
| APAC | 132,856 |  |  | 17.1 |  | 110,829 |  |  | 17.2 |  | 22,027 |  |  | 19.9 |  |
| Total | $ | 778,527 |  |  | 100.0 |  | $ | 646,135 |  |  | 100.0 |  | $ | 132,392 |  |  | 20.5 |  |

[0000936395-19-000010:mdna:73]
[same as prior period, unchanged from 0000936395-18-000037:mdna:71]

[0000936395-19-000010:mdna:74]
[same as prior period, unchanged from 0000936395-18-000037:mdna:72]

[0000936395-19-000010:mdna:75]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:76]
| • | North America revenue primarily reflects an increase of $84.4 million within our Networking Platforms segment. This increase primarily reflects product line sales increases of $73.9 million of Converged Packet Optical products and $10.5 million of Packet Networking products. Converged Packet Optical sales primarily reflects sales increases of $48.4 million of our Waveserver stackable interconnect system and $26.2 million of our 6500 Packet-Optical Platform. Waveserver stackable interconnect system sales reflect increased sales to Web-scale providers. 6500 Packet-Optical Platform sales reflect increased sales to AT&T and other communications service providers, partially offset by decreased sales to Web-scale providers. |

[0000936395-19-000010:mdna:77]
| • | EMEA revenue primarily reflects increases of $25.7 million within our Networking Platforms segment and $4.5 million within our Global Services segment. Networking Platforms revenue primarily reflects a sales increase of $25.4 million of our Waveserver stackable interconnect system to Web-scale providers. |

[0000936395-19-000010:mdna:78]
| • | CALA revenue primarily reflects decreases of $2.2 million within our Networking Platforms segment and $2.1 million within our Global Services segment. |

[0000936395-19-000010:mdna:79]
| • | APAC revenue primarily reflects increases of $16.6 million within our Networking Platforms segment, $3.4 million within our Software and Software-Related Services segment and $2.0 million within our Global Services segment. APAC revenue primarily represents increases in sales in Japan and India of $11.7 million and $7.4 million, respectively. Networking Platforms segment revenue primarily reflects a product line increase of $24.6 million in Converged Packet Optical sales primarily due to an increase of $32.4 million in sales of our 6500 Packet-Optical Platform to communications service providers and submarine network operators. This increase was partially offset by |

[0000936395-19-000010:mdna:80]
a decrease of $11.2 million in sales of our 5410/5430 Reconfigurable Switching Systems to communications service providers.

[0000936395-19-000010:mdna:81]
[same as prior period, unchanged from 0000936395-18-000037:mdna:86]

[0000936395-19-000010:mdna:82]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs,

[0000936395-19-000010:mdna:83]
employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty

[0000936395-19-000010:mdna:84]
and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory

[0000936395-19-000010:mdna:85]
and, when applicable, estimated losses on committed customer contracts.

[0000936395-19-000010:mdna:86]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services

[0000936395-19-000010:mdna:87]
including installation, deployment, maintenance support, consulting and training activities and, when applicable, estimated

[0000936395-19-000010:mdna:88]
losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party

[0000936395-19-000010:mdna:89]
contractor-related costs.

[0000936395-19-000010:mdna:90]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when

[0000936395-19-000010:mdna:91]
viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending upon our revenue

[0000936395-19-000010:mdna:92]
concentration within a particular segment, product line, geography, or customer, including our success in selling software in a

[0000936395-19-000010:mdna:93]
particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative

[0000936395-19-000010:mdna:94]
to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive

[0000936395-19-000010:mdna:95]
pricing and commercial terms and, to secure business with new and existing customers, we may agree to pricing or other

[0000936395-19-000010:mdna:96]
unfavorable commercial terms that adversely affect our gross margin. When we have success in taking share and winning new

[0000936395-19-000010:mdna:97]
business, it can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network

[0000936395-19-000010:mdna:98]
deployments. Early stages of new network builds also often include an increased concentration of lower margin “common”

[0000936395-19-000010:mdna:99]
equipment sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services

[0000936395-19-000010:mdna:100]
to customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price

[0000936395-19-000010:mdna:101]
compression and the introduction or substitution of new platforms with improved price for performance as compared to existing

[0000936395-19-000010:mdna:102]
solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete

[0000936395-19-000010:mdna:103]
inventory and warranty obligations.

[0000936395-19-000010:mdna:104]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and

[0000936395-19-000010:mdna:105]
maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this

[0000936395-19-000010:mdna:106]
business.

[0000936395-19-000010:mdna:107]
[same as prior period, unchanged from 0000936395-18-000037:mdna:91]

[0000936395-19-000010:mdna:108]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 778,527 |  |  | 100.0 |  | $ | 646,135 |  |  | 100.0 |  | $ | 132,392 |  |  | 20.5 |
| Total cost of goods sold | 455,186 |  |  | 58.5 |  | 374,370 |  |  | 57.9 |  | 80,816 |  |  | 21.6 |
| Gross profit | $ | 323,341 |  |  | 41.5 |  | $ | 271,765 |  |  | 42.1 |  | $ | 51,576 |  |  | 19.0 |

[0000936395-19-000010:mdna:109]
[same as prior period, unchanged from 0000936395-18-000037:mdna:93]

[0000936395-19-000010:mdna:110]
[same as prior period, unchanged from 0000936395-18-000037:mdna:94]

[0000936395-19-000010:mdna:111]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:112]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 642,532 |  |  | 100.0 |  | $ | 525,609 |  |  | 100.0 |  | $ | 116,923 |  |  | 22.2 |
| Product cost of goods sold | 380,442 |  |  | 59.2 |  | 313,120 |  |  | 59.6 |  | 67,322 |  |  | 21.5 |
| Product gross profit | $ | 262,090 |  |  | 40.8 |  | $ | 212,489 |  |  | 40.4 |  | $ | 49,601 |  |  | 23.3 |

[0000936395-19-000010:mdna:113]
[same as prior period, unchanged from 0000936395-18-000037:mdna:97]

[0000936395-19-000010:mdna:114]
[same as prior period, unchanged from 0000936395-18-000037:mdna:98]

[0000936395-19-000010:mdna:115]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:116]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 135,995 |  |  | 100.0 |  | $ | 120,526 |  |  | 100.0 |  | $ | 15,469 |  |  | 12.8 |
| Service cost of goods sold | 74,744 |  |  | 55.0 |  | 61,250 |  |  | 50.8 |  | 13,494 |  |  | 22.0 |
| Service gross profit | $ | 61,251 |  |  | 45.0 |  | $ | 59,276 |  |  | 49.2 |  | $ | 1,975 |  |  | 3.3 |

[0000936395-19-000010:mdna:117]
[same as prior period, unchanged from 0000936395-18-000037:mdna:101]

[0000936395-19-000010:mdna:118]
[same as prior period, unchanged from 0000936395-18-000037:mdna:102]

[0000936395-19-000010:mdna:119]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:120]
| • | Gross profit as a percentage of revenue reflects reduced service gross profits partially offset by improved product gross profits as described below. We encountered fluctuations or reductions in our gross margin during fiscal 2018 as a result of our strategy to leverage our technology leadership and to aggressively capture additional market share and displace competitors, particularly with communications service providers internationally. We were successful in executing our strategy during fiscal 2018, which allowed us to achieve meaningful revenue growth and additional market share, but which adversely impacted gross margins. Our continued success in implementing this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, and result in an increased mix of revenues from early stage deployments, any or all of which may result in low or negative gross margins on a particular order or group of orders. |

[0000936395-19-000010:mdna:121]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to product cost reductions, improved manufacturing efficiencies and reduced inventory obsolescence expense. This benefit was partially offset by market-based price erosion we encountered during the period. |

[0000936395-19-000010:mdna:122]
| • | Gross profit on services as a percentage of services revenue decreased, primarily as a result of reduced margins on our software services, which was primarily due to increased costs related to developing resources to promote our growth strategy and the impact of early stages of international network deployments. |

[0000936395-19-000010:mdna:123]
[same as prior period, unchanged from 0000936395-18-000037:mdna:107]

[0000936395-19-000010:mdna:124]
[same as prior period, unchanged from 0000936395-18-000037:mdna:108]

[0000936395-19-000010:mdna:125]
[same as prior period, unchanged from 0000936395-18-000037:mdna:109]

[0000936395-19-000010:mdna:126]
[same as prior period, unchanged from 0000936395-18-000037:mdna:110]

[0000936395-19-000010:mdna:127]
[same as prior period, unchanged from 0000936395-18-000037:mdna:111]

[0000936395-19-000010:mdna:128]
[same as prior period, unchanged from 0000936395-18-000037:mdna:112]

[0000936395-19-000010:mdna:129]
[same as prior period, unchanged from 0000936395-18-000037:mdna:113]

[0000936395-19-000010:mdna:130]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors and severance and other employee-related costs associated with our acquisitions of Packet Design and DonRiver, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition. |

[0000936395-19-000010:mdna:131]
During the first quarter of fiscal 2019, approximately 52.0% of our operating expense was non-U.S. Dollar denominated, including expenses in Canadian Dollars, British Pounds, Indian Rupees, Euros, Brazilian Reais and Australian Dollars. During the first quarter of fiscal 2019 as compared to the first quarter of fiscal 2018, the U.S. Dollar fluctuated against these currencies.

[0000936395-19-000010:mdna:132]
33

[0000936395-19-000010:mdna:133]
Consequently, our operating expense reported in U.S. Dollars slightly decreased by approximately $6.2 million, or 2.3%, as compared to the first quarter of fiscal 2018, due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000010:mdna:134]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 128,633 |  |  | 16.5 |  | $ | 118,524 |  |  | 18.3 |  | $ | 10,109 |  |  | 8.5 |  |
| Selling and marketing | 98,113 |  |  | 12.6 |  | 88,515 |  |  | 13.7 |  | 9,598 |  |  | 10.8 |  |
| General and administrative | 39,243 |  |  | 5.0 |  | 38,406 |  |  | 6.0 |  | 837 |  |  | 2.2 |  |
| Significant asset impairments and restructuring costs | 2,273 |  |  | 0.3 |  | 5,961 |  |  | 0.9 |  | (3,688 | ) |  | (61.9 | ) |
| Amortization of intangible assets | 5,528 |  |  | 0.7 |  | 3,623 |  |  | 0.6 |  | 1,905 |  |  | 52.6 |  |
| Acquisition and integration costs | 1,608 |  |  | 0.2 |  | — |  |  | — |  | 1,608 |  |  | 100.0 |  |
| Total operating expenses | $ | 275,398 |  |  | 35.3 |  | $ | 255,029 |  |  | 39.5 |  | $ | 20,369 |  |  | 8.0 |  |

[0000936395-19-000010:mdna:135]
[same as prior period, unchanged from 0000936395-18-000037:mdna:117]

[0000936395-19-000010:mdna:136]
[same as prior period, unchanged from 0000936395-18-000037:mdna:118]

[0000936395-19-000010:mdna:137]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:138]
| • | Research and development expense benefited by $3.6 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, research and development expenses increased by $10.1 million. This increase primarily reflects increases of $5.2 million in professional services, $5.0 million in employee and compensation costs and $1.1 million in prototype expense. These increases were partially offset by a benefit of $1.9 million for the ENCQOR grant reimbursement. For more information on the ENCQOR grant, see Note 19 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-19-000010:mdna:139]
| • | Selling and marketing expense benefited by $2.0 million as a result of foreign exchange rates primarily due to a stronger U.S. Dollar in relation to the Euro and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expenses increased by $9.6 million, primarily reflecting increases of $6.9 million in employee and compensation costs, $1.0 million in professional services and $1.0 million in travel and entertainment costs. |

[0000936395-19-000010:mdna:140]
| • | General and administrative expense increased by $0.8 million, primarily reflecting an increase in employee and compensation costs. |

[0000936395-19-000010:mdna:141]
[same as prior period, unchanged from 0000936395-18-000037:mdna:124]

[0000936395-19-000010:mdna:142]
| • | Amortization of intangible assets increased due to additional intangibles related to our acquisitions of Packet Design and DonRiver. |

[0000936395-19-000010:mdna:143]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisitions of Packet Design and DonRiver. |

[0000936395-19-000010:mdna:144]
[same as prior period, unchanged from 0000936395-18-000037:mdna:127]

[0000936395-19-000010:mdna:145]
[same as prior period, unchanged from 0000936395-18-000037:mdna:128]

[0000936395-19-000010:mdna:146]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | (decrease) |  | %** |
| Interest and other income, net | $ | 4,253 |  |  | 0.5 |  | $ | 1,575 |  |  | 0.2 |  | $ | 2,678 |  |  | 170.0 |  |
| Interest expense | $ | 9,441 |  |  | 1.2 |  | $ | 13,734 |  |  | 2.1 |  | $ | (4,293 | ) |  | (31.3 | ) |
| Provision for income taxes | $ | 9,139 |  |  | 1.2 |  | $ | 477,940 |  |  | 74.0 |  | $ | (468,801 | ) |  | (98.1 | ) |

[0000936395-19-000010:mdna:147]
[same as prior period, unchanged from 0000936395-18-000037:mdna:130]

[0000936395-19-000010:mdna:148]
[same as prior period, unchanged from 0000936395-18-000037:mdna:131]

[0000936395-19-000010:mdna:149]
**    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:150]
| • | Interest and other income, net primarily reflects a $1.5 million gain related to foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, and a $1.4 million gain in interest income due to higher interest rates on our investments in the first quarter of fiscal 2019. |

[0000936395-19-000010:mdna:151]
| • | Interest expense decreased, primarily due to a reduction in our aggregate outstanding debt during the fourth quarter of fiscal 2018. |

[0000936395-19-000010:mdna:152]
| • | Provision for income taxes decreased, as the first fiscal quarter of fiscal 2018 reflects the impact of the Tax Act including $431.3 million in expense for the remeasurement of our net deferred tax assets and a $45.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. |

[0000936395-19-000010:mdna:153]
[same as prior period, unchanged from 0000936395-18-000037:mdna:207]

[0000936395-19-000010:mdna:154]
[same as prior period, unchanged from 0000936395-18-000037:mdna:208]

[0000936395-19-000010:mdna:155]
|  | Quarter Ended January 31, |  |  |  |
|  | 2019 |  | 2018 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Networking Platforms | $ | 136,590 |  |  | $ | 88,569 |  |  | $ | 48,021 |  |  | 54.2 |  |
| Software and Software-Related Services | $ | 18,417 |  |  | $ | 23,635 |  |  | $ | (5,218 | ) |  | (22.1 | ) |
| Global Services | $ | 39,701 |  |  | $ | 41,037 |  |  | $ | (1,336 | ) |  | (3.3 | ) |

[0000936395-19-000010:mdna:156]
[same as prior period, unchanged from 0000936395-18-000037:mdna:151]

[0000936395-19-000010:mdna:157]
*    Denotes % change from 2018 to 2019

[0000936395-19-000010:mdna:158]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume and higher gross margin as described above, partially offset by higher research and development costs. |

[0000936395-19-000010:mdna:159]
| • | Software and Software-Related Services segment profit decreased, primarily due to reduced gross margin on software-related services as described above. |

[0000936395-19-000010:mdna:160]
| • | Global Services segment profit decreased primarily due to reduced gross margin, partially offset by higher sales volume. |

[0000936395-19-000010:mdna:161]
[same as prior period, unchanged from 0000936395-18-000037:mdna:221]

[0000936395-19-000010:mdna:162]
For the three months ended January 31, 2019, we used $14.1 million of cash, as our working capital requirements of $108.9 million exceeded our net income (adjusted for non-cash charges) of $94.8 million. The increase in working capital was primarily driven by inventory increases of $67.6 million. For additional details on our cash from operations, see the discussion below entitled “Cash Used In Operations.”

[0000936395-19-000010:mdna:163]
Cash, cash equivalents and investments decreased by $165.4 million during the first three months of fiscal 2019. In addition to the cash used in operations mentioned above, the decrease in cash also reflects (i) cash used for the payment of the debt conversion liability associated with our New Notes of $111.3 million on November 15, 2018, (ii) cash used to fund our investing activities for capital expenditures totaling $15.3 million, (iii) cash used for stock repurchase under our stock repurchase program of $19.7 million and (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $10.0 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $10.9 million in cash during the three months ended January 31, 2019.

[0000936395-19-000010:mdna:164]
|  | January 31, 2019 |  | October 31, 2018 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 668,810 |  |  | $ | 745,423 |  |  | $ | (76,613 | ) |
| Short-term investments in marketable debt securities | 119,143 |  |  | 148,981 |  |  | (29,838 | ) |
| Long-term investments in marketable debt securities | — |  |  | 58,970 |  |  | (58,970 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 787,953 |  |  | $ | 953,374 |  |  | $ | (165,421 | ) |

[0000936395-19-000010:mdna:165]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash, cash equivalents and investments, which as of January 31, 2019 totaled $788.0 million, as well as the senior secured asset-backed revolving credit facility to which we and certain of our subsidiaries are parties (the “ABL Credit Facility”). The ABL Credit Facility provides for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 31, 2019, letters of credit totaling $68.7 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2019.

[0000936395-19-000010:mdna:166]
Foreign Liquidity. The amount of cash, cash equivalents, and short-term investments held by our foreign subsidiaries was $67.1 million as of January 31, 2019.We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these

[0000936395-19-000010:mdna:167]
accumulated historical foreign earnings, the estimated amount of unrecognized deferred income tax liability related to foreign

[0000936395-19-000010:mdna:168]
withholding taxes would be approximately $25.0 million.

[0000936395-19-000010:mdna:169]
Stock Repurchase Authorization. On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of its common stock, which replaced in its entirety the previous stock repurchase program authorized in fiscal 2018. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-19-000010:mdna:170]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents, investments, and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-19-000010:mdna:171]
Cash Used In Operations

[0000936395-19-000010:mdna:172]
The following sections set forth the components of our $14.1 million of cash used in operating activities during the first three months of fiscal 2019:

[0000936395-19-000010:mdna:173]
Net income (adjusted for non-cash charges)

[0000936395-19-000010:mdna:174]
The following table sets forth our net income (adjusted for non-cash charges) during the period (in thousands):

[0000936395-19-000010:mdna:175]
|  | Three months ended |
|  | January 31, 2019 |
| Net income | $ | 33,616 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 21,513 |  |
| Share-based compensation costs | 13,755 |  |
| Amortization of intangible assets | 8,947 |  |
| Deferred taxes | 5,037 |  |
| Provision for inventory excess and obsolescence | 4,673 |  |
| Provision for warranty | 3,891 |  |
| Other | 3,356 |  |
| Net income (adjusted for non-cash charges) | $ | 94,788 |  |

[0000936395-19-000010:mdna:176]
[same as prior period, unchanged from 0000936395-18-000037:mdna:237]

[0000936395-19-000010:mdna:177]
We used $108.9 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-19-000010:mdna:178]
|  | Three months ended |
|  | January 31, 2019 |
| Cash provided by accounts receivable | $ | 38,544 |  |
| Cash used in inventories | (67,555 | ) |
| Cash provided by prepaid expenses and other | 1,133 |  |
| Cash used in accounts payable, accruals and other obligations | (76,351 | ) |
| Cash used in deferred revenue | (4,664 | ) |
| Total cash used for working capital | $ | (108,893 | ) |

[0000936395-19-000010:mdna:179]
As compared to the end of fiscal 2018:

[0000936395-19-000010:mdna:180]
| • | The $38.5 million of cash provided by accounts receivable during the first three months of fiscal 2019 reflects increased cash collections; |

[0000936395-19-000010:mdna:181]
| • | The $67.6 million of cash used in inventory during the first three months of fiscal 2019 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-19-000010:mdna:182]
| • | The $1.1 million of cash provided by prepaid expense and other during the first three months of fiscal 2019 primarily reflects lower prepaid value added taxes and lower non-customer receivables, partially offset by increases in contract assets for unbilled accounts receivable due to changes in recognizing revenue for installation services and certain product sales. |

[0000936395-19-000010:mdna:183]
| • | The $76.4 million of cash used in accounts payable, accruals and other obligations during the first three months of fiscal 2019 primarily reflects the timing of bonus payments to employees under our annual cash incentive compensation plan; and |

[0000936395-19-000010:mdna:184]
| • | The $4.7 million of cash used in deferred revenue during the first three months of fiscal 2019 represents a decrease in advanced payments received from customers prior to revenue recognition. |

[0000936395-19-000010:mdna:185]
Our days sales outstanding (DSOs) for the first three months of fiscal 2019 were 93 days, and our inventory turns for the first three months of fiscal 2019 were 4.7. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-19-000010:mdna:186]
[same as prior period, unchanged from 0000936395-18-000037:mdna:247]

[0000936395-19-000010:mdna:187]
[same as prior period, unchanged from 0000936395-18-000037:mdna:248]

[0000936395-19-000010:mdna:188]
|  | Three months ended |
|  | January 31, 2019 |
| Term Loan due September 28, 2025 (1) | 7,790 |  |
| Interest rate swaps(2) | 538 |  |
| ABL Credit Facility(3) | 370 |  |
| Capital leases | 1,309 |  |
| Cash paid during period | $ | 10,007 |  |

[0000936395-19-000010:mdna:189]
| (1) | Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. At the end of the first quarter of fiscal 2019, the interest rate on the 2025 Term Loan was 4.50%. |

[0000936395-19-000010:mdna:190]
| (2) | The interest rate swaps fix the LIBOR rate for $350 million of the 2025 Term Loan at 2.957% through September 2023. |

[0000936395-19-000010:mdna:191]
| (3) | During the first three months of fiscal 2019, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.4 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-19-000010:mdna:192]
[same as prior period, unchanged from 0000936395-18-000037:mdna:255]

[0000936395-19-000010:mdna:193]
There have been no material changes to our contractual obligations since October 31, 2018. For a summary of our contractual obligations, see Item 7 of Part II of our annual report on Form 10-K for the fiscal year ended October 31, 2018.

[0000936395-19-000010:mdna:194]
[same as prior period, unchanged from 0000936395-18-000037:mdna:147]

[0000936395-19-000010:mdna:195]
[same as prior period, unchanged from 0000936395-18-000037:mdna:257]

[0000936395-19-000010:mdna:196]
[same as prior period, unchanged from 0000936395-18-000037:mdna:258]

[0000936395-19-000010:mdna:197]
[same as prior period, unchanged from 0000936395-18-000037:mdna:259]

[0000936395-19-000010:mdna:198]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to revenue recognition, share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-19-000010:mdna:199]
Our critical accounting policies and estimates have not changed materially since October 31, 2018, except for items listed below. For a discussion of our critical accounting policies and estimates, see Item 7 of Part II of our annual report on Form 10-K for the fiscal year ended October 31, 2018 (Management’s Discussion and Analysis of Financial Condition and Results of Operations).

[0000936395-19-000010:mdna:200]
Revenue Recognition

[0000936395-19-000010:mdna:201]
For changes to our revenue recognition policies and estimates due to ASC 606, see Notes 2 and 3 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-19-000010:mdna:202]
[same as prior period, unchanged from 0000936395-18-000037:mdna:265]

[0000936395-19-000010:mdna:203]
[same as prior period, unchanged from 0000936395-18-000037:mdna:266]
