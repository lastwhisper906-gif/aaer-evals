# CIEN note change history — 0000936395-15-000038 → 0000936395-15-000053


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2015, Ciena has received payment for the full amount of the grant. Payments received were recorded as a reduction in research and development expenses.
  (was, 2015-06-10, similarity 0.7589):
[0000936395-15-000038:note_history:1]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of April 30, 2015, Ciena has recorded a CAD$25.0 million benefit to date, as a reduction in research and development expenses. As of April 30, 2015, the amount receivable from this grant was CAD$1.9 million.

- changed (2015-09-09):
[0000936395-15-000053:note_history:2]
As of October 31, 2014 and July 31, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of July 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.
  (was, 2015-06-10, similarity 0.9904):
[0000936395-15-000038:note_history:2]
As of October 31, 2014 and April 30, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of April 30, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

- changed (2015-09-09):
[0000936395-15-000053:note_history:3]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:
  (was, 2015-06-10, similarity 0.9588):
[0000936395-15-000038:note_history:3]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s pending acquisition of Cyan, Inc. ("Cyan") were filed in the Court of Chancery of the State of Delaware:

- added (2015-09-09):
[0000936395-15-000053:note_history:4]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, plaintiffs filed a verified amended class action complaint, naming Ciena, Merger Sub and the members of Cyan’s board of directors as defendants. The amended complaint alleges, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding, failing to properly value Cyan and obtain the best exchange ratio, ignoring or not protecting against certain conflicts of interest, and failing to disclose all material information necessary for Cyan stockholders to make an informed decision regarding the acquisition. The amended complaint also alleges that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The amended complaint seeks (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger, (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, and (iv) costs including attorneys’ fees and experts’ fees. On August 10, 2015, the defendants filed motions to dismiss the amended complaint. No briefing schedule or hearing date has been set on these motions. Ciena believes that the consolidated lawsuit is without merit, and intends to defend it vigorously.

- added (2015-09-09):
[0000936395-15-000053:note_history:5]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-539008. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case. Ciena believes that the consolidated lawsuit is without merit and intend to defend it vigorously.

- removed (2015-09-09):
[0000936395-15-000038:note_history:6]
Each of the complaints names as defendants Cyan (except for the Canzano complaint), members of the Cyan board of directors, Ciena and Neptune Acquisition Subsidiary, Inc. (“Merger Sub”). The complaints allege, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding for Cyan, failing to properly value Cyan and obtain the best exchange ratio from Ciena, and ignoring or not protecting against certain conflicts of interest. The complaints also allege that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The complaints seek the following: (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger; (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages; and (iii) monetary damages and costs, including attorneys fees and experts fees. These lawsuits are at a preliminary stage. However, Ciena believes that the lawsuits are without merit and intends to defend them vigorously.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:7]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.
  (was, 2015-06-10, similarity 0.9979):
[0000936395-15-000038:note_history:7]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by GAAP . However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:8]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.
  (was, 2015-06-10, similarity 0.9947):
[0000936395-15-000038:note_history:8]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of April 30, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2015-09-09):
[0000936395-15-000053:note_history:9]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.
  (was, 2015-06-10, similarity 0.9753):
[0000936395-15-000038:note_history:9]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the shorter of its useful life or the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

- added (2015-09-09):
[0000936395-15-000053:note_history:10]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 12 below.

- changed (2015-09-09):
[0000936395-15-000053:note_history:11]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.
  (was, 2015-06-10, similarity 0.9958):
[0000936395-15-000038:note_history:11]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers and forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.

- changed (2015-09-09):
[0000936395-15-000053:note_history:12]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2014 and July 31, 2015 was 4.3% and 1.9%, respectively.
  (was, 2015-06-10, similarity 0.9724):
[0000936395-15-000038:note_history:12]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2014 and April 30, 2015 was 2.9% and 1.7%, respectively.

- changed (2015-09-09):
[0000936395-15-000053:note_history:13]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.
  (was, 2015-06-10, similarity 0.9891):
[0000936395-15-000038:note_history:13]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period of more than 60 days, which are accrued over the service period. See Note 3 below.

- changed (2015-09-09):
[0000936395-15-000053:note_history:14]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.
  (was, 2015-06-10, similarity 0.998):
[0000936395-15-000038:note_history:14]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations, See Note 4 below.

- changed (2015-09-09):
[0000936395-15-000053:note_history:15]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.  In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2015-06-10, similarity 0.6617):
[0000936395-15-000038:note_history:15]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. Based on the current expected adoption date, the standard will be effective for Ciena beginning in the first quarter of fiscal 2018. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- added (2015-09-09):
[0000936395-15-000053:note_history:16]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the its consolidated financial statements and related disclosures.

- removed (2015-09-09):
[0000936395-15-000038:note_history:17]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct and and Ciena will lease two new office buildings at its new Ottawa, Canada campus.The landlord will construct the buildings and contribute up to a maximum of $290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of April 30, 2015, there were no costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease.

- removed (2015-09-09):
[0000936395-15-000038:note_history:18]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, beginning after December 15, 2015. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the Ciena’s consolidated financial statements and related disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:19]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):
  (was, 2015-06-10, similarity 0.9895):
[0000936395-15-000038:note_history:19]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):

- changed (2015-09-09):
[0000936395-15-000053:note_history:20]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,351 |  |  | $ | 248,428 |  |
  (was, 2015-06-10, similarity 0.9707):
[0000936395-15-000038:note_history:20]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,994 |  |  | $ | 249,366 |  |

- changed (2015-09-09):
[0000936395-15-000053:note_history:21]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2015-06-10, similarity 0.994):
[0000936395-15-000038:note_history:21]
| (2) | The Term Loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- changed (2015-09-09):
[0000936395-15-000053:note_history:22]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of July 31, 2015:
  (was, 2015-06-10, similarity 0.9479):
[0000936395-15-000038:note_history:22]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of April 30, 2015:

- added (2015-09-09):
[0000936395-15-000053:note_history:23]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 507,813 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 498,750 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 182,910 |  |  | 274,116 |  |
|  |  | $ | 1,032,910 |  |  | $ | 1,280,679 |  |

- changed (2015-09-09):
[0000936395-15-000053:note_history:24]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2015-06-10, similarity 0.9946):
[0000936395-15-000038:note_history:24]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2015-09-09):
[0000936395-15-000038:note_history:25]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 504,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 456,531 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 181,613 |  |  | 248,841 |  |
|  |  | $ | 1,031,613 |  |  | $ | 1,209,747 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:26]
|  | July 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,041 |  |  | $ | 44 |  |  | — |  |  | $ | 105,085 |  |
| Included in long-term investments | 70,149 |  |  | 12 |  |  | — |  |  | 70,161 |  |
|  | $ | 175,190 |  |  | $ | 56 |  |  | $ | — |  |  | $ | 175,246 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 54,982 |  |  | — |  |  | — |  |  | 54,982 |  |
|  | $ | 54,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 54,982 |  |
  (was, 2015-06-10, similarity 0.9893):
[0000936395-15-000038:note_history:26]
|  | April 30, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,056 |  |  | $ | 46 |  |  | — |  |  | $ | 105,102 |  |
| Included in long-term investments | 85,233 |  |  | — |  |  | — |  |  | 85,233 |  |
|  | $ | 190,289 |  |  | $ | 46 |  |  | $ | — |  |  | $ | 190,335 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 39,987 |  |  | — |  |  | — |  |  | 39,987 |  |
|  | $ | 39,987 |  |  | $ | — |  |  | $ | — |  |  | $ | 39,987 |  |

- changed (2015-09-09):
[0000936395-15-000053:note_history:27]
The following table summarizes the final legal maturities of debt investments at July 31, 2015 (in thousands):
  (was, 2015-06-10, similarity 0.9469):
[0000936395-15-000038:note_history:27]
The following table summarizes final legal maturities of debt investments at April 30, 2015 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:28]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):
  (was, 2015-06-10, similarity 0.9734):
[0000936395-15-000038:note_history:28]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of April 30, 2015 (in thousands):

- changed (2015-09-09):
[0000936395-15-000053:note_history:29]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,351 |  |  | $ | 248,428 |  |
  (was, 2015-06-10, similarity 0.9707):
[0000936395-15-000038:note_history:29]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,994 |  |  | $ | 249,366 |  |

- changed (2015-09-09):
[0000936395-15-000053:note_history:30]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2015-06-10, similarity 0.994):
[0000936395-15-000038:note_history:30]
| (2) | The Term Loan was categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- added (2015-09-09):
[0000936395-15-000053:note_history:31]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 507,813 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 498,750 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 182,910 |  |  | 274,116 |  |
|  |  | $ | 1,032,910 |  |  | $ | 1,280,679 |  |

- changed (2015-09-09):
[0000936395-15-000053:note_history:32]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2015-06-10, similarity 0.9946):
[0000936395-15-000038:note_history:32]
| (1) | The convertible notes were categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2015-09-09):
[0000936395-15-000038:note_history:33]
|  |  | April 30, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 504,375 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 456,531 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 181,613 |  |  | 248,841 |  |
|  |  | $ | 1,031,613 |  |  | $ | 1,209,747 |  |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:34]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of July 31, 2015:
  (was, 2015-06-10, similarity 0.9479):
[0000936395-15-000038:note_history:34]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of our 4.0% convertible senior notes due December 15, 2020 were as follows as of April 30, 2015:


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:35]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2014 and July 31, 2015 was 4.3% and 1.9%, respectively.
  (was, 2015-06-10, similarity 0.9724):
[0000936395-15-000038:note_history:35]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the six months ended April 30, 2014 and April 30, 2015 was 2.9% and 1.7%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2015-09-09):
[0000936395-15-000053:note_history:36]
Acquisition of Cyan, Inc.
  (was, 2015-06-10, similarity 0.8621):
[0000936395-15-000038:note_history:36]
Pending Acquisition of Cyan, Inc.

- added (2015-09-09):
[0000936395-15-000053:note_history:37]
On August 3, 2015, Ciena acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all the then-outstanding Cyan stock options and unvested restricted stock unit awards and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

- added (2015-09-09):
[0000936395-15-000053:note_history:38]
Upon the closing of the acquisition, Ciena assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of 2019 Notes surrendered for conversion. As of September 3, 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes had surrendered their 2019 notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, Ciena issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

- added (2015-09-09):
[0000936395-15-000053:note_history:39]
During the first nine months of fiscal 2015, Ciena incurred approximately $3.5 million of acquisition-related costs associated with this transaction. Ciena further expects to incur a number of non-recurring costs associated with the transaction during the remainder of fiscal 2015. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other potential employment-related costs, including payments to certain Cyan executives. Ciena currently expects to incur in total, approximately $25.0 million of such expenses, which includes approximately $7.9 million of non-cash share-based compensation expense. Ciena expects a substantial majority of these acquisition-related costs to be recognized during the fiscal fourth quarter of fiscal 2015.

- removed (2015-09-09):
[0000936395-15-000038:note_history:40]
On May 3, 2015, Ciena entered into a definitive merger agreement to acquire Cyan, Inc. (“Cyan”), a Delaware corporation and leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction.  Subject to the terms and conditions set forth in the merger agreement, at closing each outstanding Cyan share will be exchanged for consideration equal to the value of 0.224 shares of Ciena common stock, 89% of which will be delivered in Ciena common stock and 11% will be delivered in cash based on the value of Ciena common stock at closing. Ciena also will assume Cyan’s outstanding convertible notes, subject to certain conversion and repurchase rights of the holders triggered by the acquisition, as well as Cyan’s outstanding equity awards. At the time of signing of the merger agreement, the transaction was valued at approximately $400.0 million (or $335.0 million, net of estimated cash acquired) and inclusive of Cyan’s $50 million outstanding convertible notes on an as-converted basis. Certain Cyan officers and directors and affiliated stockholders, including investment funds affiliated with certain directors, who, at the time of signing of the merger agreement collectively controlled approximately 40% of the voting power of the then outstanding shares of Cyan common stock, have entered into voting agreements with Ciena that obligate them to vote in favor of the merger, subject to certain exceptions and limitations. The transaction, which is expected to close in Ciena’s fourth fiscal quarter of 2015, is subject to approval by Cyan shareholders and satisfaction of certain other customary closing conditions, including the receipt of certain regulatory approvals.

- removed (2015-09-09):
[0000936395-15-000038:note_history:41]
During the second quarter of fiscal 2015, Ciena incurred approximately $1.0 million of acquisition-related costs associated with this pending transaction.
