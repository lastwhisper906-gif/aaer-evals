# CIEN 8-K — 0000936395-15-000049 filed 2015-09-03

## item codes, every 8-K on or before 2015-09-09

- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2015-09-09

- none on or before 2015-09-09

## item 2.02 — earnings release, exhibit 99.1

[0000936395-15-000049:8k_2_02:1]
EX-99.1
2
exhibit991-2015q3earningsp.htm
EXHIBIT 99.1

[0000936395-15-000049:8k_2_02:2]
Exhibit

[0000936395-15-000049:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-15-000049:8k_2_02:4]
Ciena Reports Fiscal Third Quarter 2015 Financial Results

[0000936395-15-000049:8k_2_02:5]
Delivers 12% adjusted operating margin and generates $117 million in cash from operations

[0000936395-15-000049:8k_2_02:6]
HANOVER, Md. - September 3, 2015 - Ciena® Corporation (NYSE:  CIEN), the network specialist, today announced unaudited financial results for its fiscal third quarter ended July 31, 2015.

[0000936395-15-000049:8k_2_02:7]
For the fiscal third quarter 2015, Ciena reported revenue of $602.9 million as compared to $603.6 million for the fiscal third quarter 2014.

[0000936395-15-000049:8k_2_02:8]
On the basis of generally accepted accounting principles (GAAP), Ciena's net income for the fiscal third quarter 2015 was $23.6 million, or $0.19 per diluted common share, which compares to a GAAP net income of $16.2 million, or $0.15 per diluted common share, for the fiscal third quarter 2014.

[0000936395-15-000049:8k_2_02:9]
Ciena's adjusted (non-GAAP) net income for the fiscal third quarter 2015 was $50.7 million, or $0.37 per diluted common share, which compares to an adjusted (non-GAAP) net income of $40.9 million, or $0.32 per diluted common share, for the fiscal third quarter 2014.

[0000936395-15-000049:8k_2_02:10]
"We delivered strong financial performance in our fiscal third quarter, including increased profitability and cash generation, demonstrating our ability to deliver on our business model and drive continued operating leverage," said Gary B. Smith, president and CEO of Ciena. "Despite short-term revenue headwinds related to the timing of network implementations at certain large service provider customers, fundamental demand drivers for our business remain strong. In fact, we now expect to exceed 10% adjusted operating margin for the full fiscal year."

[0000936395-15-000049:8k_2_02:11]
Fiscal Third Quarter 2015 Performance Summary

[0000936395-15-000049:8k_2_02:12]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly results to prior periods, including sequential quarter and year-over-year changes. A reconciliation between the GAAP and adjusted (non-GAAP) measures contained in this release is included in Appendix A.

[0000936395-15-000049:8k_2_02:13]
|  |  | GAAP Results |
|  |  | Q3 |  | Q2 |  | Q3 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 602.9 |  |  | $ | 621.6 |  |  | $ | 603.6 |  |  | (3.0 | )% |  | (0.1 | )% |
| Gross margin |  | 44.8 | % |  | 43.8 | % |  | 43.7 | % |  | 1.0 | % |  | 1.1 | % |
| Operating expense |  | $ | 225.4 |  |  | $ | 230.0 |  |  | $ | 227.0 |  |  | (2.0 | )% |  | (0.7 | )% |
| Operating margin |  | 7.4 | % |  | 6.8 | % |  | 6.1 | % |  | 0.6 | % |  | 1.3 | % |

[0000936395-15-000049:8k_2_02:14]
|  |  | Non-GAAP Results |
|  |  | Q3 |  | Q2 |  | Q3 |  | Period Change |
|  |  | FY 2015 |  | FY 2015 |  | FY 2014 |  | Q-T-Q* |  | Y-T-Y* |
| Revenue |  | $ | 602.9 |  |  | $ | 621.6 |  |  | $ | 603.6 |  |  | (3.0 | )% |  | (0.1 | )% |
| Adj. gross margin |  | 45.3 | % |  | 44.4 | % |  | 44.3 | % |  | 0.9 | % |  | 1.0 | % |
| Adj. operating expense |  | $ | 202.1 |  |  | $ | 207.9 |  |  | $ | 206.3 |  |  | (2.8 | )% |  | (2.0 | )% |
| Adj. operating margin |  | 11.8 | % |  | 10.9 | % |  | 10.1 | % |  | 0.9 | % |  | 1.7 | % |

[0000936395-15-000049:8k_2_02:15]
*  Denotes %  change,  or  in  the  case  of  margin, absolute change

[0000936395-15-000049:8k_2_02:16]
|  |  | Revenue by Segment |
|  |  | Q3 FY 2015 |  | Q2 FY 2015 |  | Q3 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| Converged Packet Optical |  | $ | 408.0 |  |  | 67.7 |  | $ | 432.9 |  |  | 69.6 |  | $ | 382.0 |  |  | 63.3 |
| Packet Networking |  | 57.2 |  |  | 9.5 |  | 53.3 |  |  | 8.6 |  | 69.5 |  |  | 11.5 |
| Optical Transport |  | 17.5 |  |  | 2.9 |  | 16.5 |  |  | 2.7 |  | 31.0 |  |  | 5.1 |
| Software and Services |  | 120.2 |  |  | 19.9 |  | 118.9 |  |  | 19.1 |  | 121.1 |  |  | 20.1 |
| Total |  | $ | 602.9 |  |  | 100.0 |  | $ | 621.6 |  |  | 100.0 |  | $ | 603.6 |  |  | 100.0 |

[0000936395-15-000049:8k_2_02:17]
Additional Performance Metrics for Fiscal Third Quarter 2015

[0000936395-15-000049:8k_2_02:18]
|  |  | Revenue by Geographic Region |
|  |  | Q3 FY 2015 |  | Q2 FY 2015 |  | Q3 FY 2014 |
|  |  | Revenue |  | % |  | Revenue |  | % |  | Revenue |  | % |
| North America |  | $ | 389.6 |  |  | 64.6 |  | 397.2 |  |  | 63.9 |  | 403.3 |  |  | 66.8 |
| Europe, Middle East and Africa |  | 93.2 |  |  | 15.5 |  | 102.2 |  |  | 16.4 |  | 99.9 |  |  | 16.6 |
| Caribbean and Latin America |  | 65.1 |  |  | 10.8 |  | 47.9 |  |  | 7.7 |  | 67.2 |  |  | 11.1 |
| Asia Pacific |  | 55.0 |  |  | 9.1 |  | 74.3 |  |  | 12.0 |  | 33.2 |  |  | 5.5 |
| Total |  | $ | 602.9 |  |  | 100.0 |  | $ | 621.6 |  |  | 100.0 |  | $ | 603.6 |  |  | 100.0 |

[0000936395-15-000049:8k_2_02:19]
| • | U.S. customers contributed 59.8% of total revenue |

[0000936395-15-000049:8k_2_02:20]
| • | One customer accounted for greater than 10% of revenue and represented 20% of total revenue |

[0000936395-15-000049:8k_2_02:21]
| • | Cash and investments totaled $927.3 million |

[0000936395-15-000049:8k_2_02:22]
| • | Cash flow from operations totaled $117.5 million |

[0000936395-15-000049:8k_2_02:23]
| • | Average days' sales outstanding (DSOs) were 79 |

[0000936395-15-000049:8k_2_02:24]
| • | Accounts receivable balance was $530.3 million |

[0000936395-15-000049:8k_2_02:25]
| • | Inventories totaled $194.0 million, including: |

[0000936395-15-000049:8k_2_02:26]
| ◦ | Raw materials: $54.1 million |

[0000936395-15-000049:8k_2_02:27]
| ◦ | Work in process: $8.9 million |

[0000936395-15-000049:8k_2_02:28]
| ◦ | Finished goods: $119.7 million |

[0000936395-15-000049:8k_2_02:29]
| ◦ | Deferred cost of sales: $59.6 million |

[0000936395-15-000049:8k_2_02:30]
| ◦ | Reserve for excess and obsolescence: $(48.3) million |

[0000936395-15-000049:8k_2_02:31]
| • | Product inventory turns were 5.6 |

[0000936395-15-000049:8k_2_02:32]
| • | Headcount totaled 5,196 |

[0000936395-15-000049:8k_2_02:33]
Executive Leadership Appointment

[0000936395-15-000049:8k_2_02:34]
Ciena also announced today that François Locoh-Donou has been appointed senior vice president and chief operating officer, effective November 1, 2015, reporting directly to Gary B. Smith, president and CEO. In this new position, Locoh-Donou will assume responsibility for Ciena’s Global Field Organization, including the global sales and services functions, while retaining his existing responsibility for Ciena’s research and development, product line management, supply chain and quality functions. Locoh-Donou joined Ciena in 2002 and has served as senior vice president, Global Products Group since August 2011. Previously, he served as vice president and general manager, EMEA, with responsibility for expanding Ciena’s sales and other operations in that region.

[0000936395-15-000049:8k_2_02:35]
Business Outlook for Fiscal Fourth Quarter 2015

[0000936395-15-000049:8k_2_02:36]
Statements relating to business outlook are forward-looking in nature and actual results may differ materially. These statements should be read in the context of the Notes to Investors below.

[0000936395-15-000049:8k_2_02:37]
Ciena expects fiscal fourth quarter 2015 financial performance, inclusive of a full quarter of results from the acquired Cyan business, to include:

[0000936395-15-000049:8k_2_02:38]
| • | Revenue in the range of $665 to $700 million |

[0000936395-15-000049:8k_2_02:39]
| • | Adjusted (non-GAAP) gross margin of approximately 44 percent |

[0000936395-15-000049:8k_2_02:40]
| • | Adjusted (non-GAAP) operating expense of approximately $225 million |

[0000936395-15-000049:8k_2_02:41]
Live Web Broadcast of Unaudited Fiscal Third Quarter 2015 Results

[0000936395-15-000049:8k_2_02:42]
Ciena will host a discussion of its unaudited fiscal third quarter 2015 results with investors and financial analysts today, Thursday, September 3, 2015 at 8:30 a.m. (Eastern). The live broadcast will be available at www.ciena.com, and an archived replay will be available shortly following the conclusion of the live broadcast on the Investor Relations page of Ciena's website at www.ciena.com/investors. Ciena will also post to the Investor Relations page a presentation that includes certain highlighted information discussed on the call and certain historical results of operations.

[0000936395-15-000049:8k_2_02:43]
Notes to Investors

[0000936395-15-000049:8k_2_02:44]
Forward-looking statements. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or similar words. Forward-looking statements in this release include: "We delivered strong financial performance in our fiscal third quarter, including increased profitability and cash generation, demonstrating our ability to deliver on our business model and drive continued operating leverage"; "Despite short-term revenue headwinds related to the timing of network implementations at certain large service provider customers, fundamental demand drivers for our business remain strong"; "In fact, we now expect to exceed 10% adjusted operating margin for the full fiscal year"; "Ciena expects fiscal fourth quarter 2015 financial performance, inclusive of a full quarter of results from the acquired Cyan business, to include: Revenue in the range of $665 to $700 million; Adjusted (non-GAAP) gross margin of approximately 44 percent; Adjusted (non-GAAP) operating expense of approximately $225 million."

[0000936395-15-000049:8k_2_02:45]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by large communication service providers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; and the other risk factors disclosed in Ciena's Report on Form 10-Q, which Ciena filed with the Securities and Exchange Commission on June 10, 2015. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-15-000049:8k_2_02:46]
Non-GAAP Presentation of Quarterly Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income (loss) from operations, net income (loss) and net income (loss) per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not  expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release, Appendix A to this press release sets forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-15-000049:8k_2_02:47]
About Ciena.  Ciena (NYSE: CIEN) is the network specialist. We collaborate with customers worldwide to unlock the strategic potential of their networks and fundamentally change the way they perform and compete. Ciena leverages its deep expertise in packet and optical networking and distributed software automation to deliver solutions in alignment with its OPn architecture for next-generation networks. We enable a high-scale, programmable infrastructure that can be controlled and adapted by network-level applications, and provide open interfaces to coordinate computing, storage and network resources in a unified, virtualized environment. For updates on Ciena news, follow us on Twitter @Ciena or on LinkedIn at http://www.linkedin.com/company/ciena. Investors are encouraged to review the Investors section of our website at www.ciena.com/investors, where we routinely post press releases, SEC filings, recent news, financial results, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use.

[0000936395-15-000049:8k_2_02:48]
CIENA CORPORATION

[0000936395-15-000049:8k_2_02:49]
CONDENSED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-15-000049:8k_2_02:50]
(in thousands, except per share data)

[0000936395-15-000049:8k_2_02:51]
(unaudited)

[0000936395-15-000049:8k_2_02:52]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Products | $ | 495,889 |  |  | $ | 493,919 |  |  | $ | 1,389,651 |  |  | $ | 1,428,114 |  |
| Services | 107,673 |  |  | 109,013 |  |  | 307,675 |  |  | 325,582 |  |
| Total revenue | 603,562 |  |  | 602,932 |  |  | 1,697,326 |  |  | 1,753,696 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |
| Products | 275,003 |  |  | 273,837 |  |  | 777,851 |  |  | 797,283 |  |
| Services | 64,586 |  |  | 59,226 |  |  | 191,960 |  |  | 183,838 |  |
| Total cost of goods sold | 339,589 |  |  | 333,063 |  |  | 969,811 |  |  | 981,121 |  |
| Gross profit | 263,973 |  |  | 269,869 |  |  | 727,515 |  |  | 772,575 |  |
| Operating expenses: |  |  |  |  |  |  |  |
| Research and development | 97,685 |  |  | 100,379 |  |  | 302,674 |  |  | 306,342 |  |
| Selling and marketing | 81,919 |  |  | 81,650 |  |  | 243,929 |  |  | 240,833 |  |
| General and administrative | 36,285 |  |  | 29,743 |  |  | 98,264 |  |  | 89,598 |  |
| Acquisition and integration costs | — |  |  | 2,435 |  |  | — |  |  | 3,455 |  |
| Amortization of intangible assets | 11,019 |  |  | 11,019 |  |  | 34,951 |  |  | 33,057 |  |
| Restructuring costs | 63 |  |  | 192 |  |  | 178 |  |  | 8,260 |  |
| Total operating expenses | 226,971 |  |  | 225,418 |  |  | 679,996 |  |  | 681,545 |  |
| Income from operations | 37,002 |  |  | 44,451 |  |  | 47,519 |  |  | 91,030 |  |
| Interest and other income (loss), net | (6,328 | ) |  | (5,491 | ) |  | (14,231 | ) |  | (19,273 | ) |
| Interest expense | (11,508 | ) |  | (11,883 | ) |  | (33,556 | ) |  | (38,491 | ) |
| Income (loss) before income taxes | 19,166 |  |  | 27,077 |  |  | (268 | ) |  | 33,266 |  |
| Provision for income taxes | 3,006 |  |  | 3,452 |  |  | 9,666 |  |  | 7,767 |  |
| Net income (loss) | $ | 16,160 |  |  | $ | 23,625 |  |  | $ | (9,934 | ) |  | $ | 25,499 |  |
| Net Income (loss) per Common Share |  |  |  |  |  |  |  |
| Basic net income (loss) per common share | $ | 0.15 |  |  | $ | 0.20 |  |  | $ | (0.09 | ) |  | $ | 0.23 |  |
| Diluted net income (loss) per potential common share1 | $ | 0.15 |  |  | $ | 0.19 |  |  | $ | (0.09 | ) |  | $ | 0.22 |  |
| Weighted average basic common shares outstanding | 106,236 |  |  | 118,413 |  |  | 105,404 |  |  | 113,189 |  |
| Weighted average dilutive potential common shares outstanding2 | 120,809 |  |  | 133,233 |  |  | 105,404 |  |  | 114,549 |  |

[0000936395-15-000049:8k_2_02:53]
| 1. | The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2014 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation. |

[0000936395-15-000049:8k_2_02:54]
The calculation of GAAP diluted net income per common share for the third quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017 to the GAAP net income in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-15-000049:8k_2_02:55]
2.  Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2014 includes 1.5 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-15-000049:8k_2_02:56]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the third quarter of fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units and 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017.

[0000936395-15-000049:8k_2_02:57]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the first nine months of fiscal 2015 includes 1.4 million shares underlying certain stock options and restricted stock units.

[0000936395-15-000049:8k_2_02:58]
CIENA CORPORATION

[0000936395-15-000049:8k_2_02:59]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0000936395-15-000049:8k_2_02:60]
(in thousands, except share data)

[0000936395-15-000049:8k_2_02:61]
(unaudited)

[0000936395-15-000049:8k_2_02:62]
|  | October 31, 2014 |  | July 31, 2015 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 697,091 |  |
| Short-term investments | 140,205 |  |  | 160,067 |  |
| Accounts receivable, net | 518,981 |  |  | 530,261 |  |
| Inventories | 254,660 |  |  | 194,017 |  |
| Prepaid expenses and other | 192,624 |  |  | 185,140 |  |
| Total current assets | 1,693,190 |  |  | 1,766,576 |  |
| Long-term investments | 50,057 |  |  | 70,161 |  |
| Equipment, building, furniture and fixtures, net | 126,632 |  |  | 159,592 |  |
| Other intangible assets, net | 128,677 |  |  | 89,019 |  |
| Other long-term assets | 74,076 |  |  | 78,347 |  |
| Total assets | $ | 2,072,632 |  |  | $ | 2,163,695 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY (DEFICIT) |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 209,777 |  |  | $ | 201,774 |  |
| Accrued liabilities | 276,608 |  |  | 272,691 |  |
| Deferred revenue | 104,688 |  |  | 114,902 |  |
| Current portion of long-term debt | 190,063 |  |  | 2,500 |  |
| Total current liabilities | 781,136 |  |  | 591,867 |  |
| Long-term deferred revenue | 40,930 |  |  | 53,731 |  |
| Other long-term obligations | 45,390 |  |  | 63,482 |  |
| Long-term debt, net | 1,274,791 |  |  | 1,276,761 |  |
| Total liabilities | $2,142,247 |  | $1,985,841 |
| Commitments and contingencies |  |  |  |
| Stockholders’ equity (deficit): |  |  |  |
| Preferred stock – par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock – par value $0.01; 290,000,000 shares authorized; 106,979,960 and 118,725,874 shares issued and outstanding | 1,070 |  |  | 1,187 |  |
| Additional paid-in capital | 5,954,440 |  |  | 6,187,759 |  |
| Accumulated other comprehensive loss | (14,668 | ) |  | (26,135 | ) |
| Accumulated deficit | (6,010,457 | ) |  | (5,984,957 | ) |
| Total stockholders’ equity (deficit) | (69,615 | ) |  | 177,854 |  |
| Total liabilities and stockholders’ equity (deficit) | $ | 2,072,632 |  |  | $ | 2,163,695 |  |

[0000936395-15-000049:8k_2_02:63]
CIENA CORPORATION

[0000936395-15-000049:8k_2_02:64]
CONDENSED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-15-000049:8k_2_02:65]
(in thousands)

[0000936395-15-000049:8k_2_02:66]
(unaudited)

[0000936395-15-000049:8k_2_02:67]
|  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |
| Cash flows provided by operating activities: |  |  |  |
| Net income (loss) | $ | (9,934 | ) |  | $ | 25,499 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 41,463 |  |  | 41,601 |  |
| Share-based compensation costs | 34,204 |  |  | 32,402 |  |
| Amortization of intangible assets | 43,931 |  |  | 39,659 |  |
| Provision for inventory excess and obsolescence | 22,026 |  |  | 18,010 |  |
| Provision for warranty | 18,720 |  |  | 12,549 |  |
| Other | 21,254 |  |  | (1,220 | ) |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | (55,688 | ) |  | (12,053 | ) |
| Inventories | (66,015 | ) |  | 42,633 |  |
| Prepaid expenses and other | (26,698 | ) |  | (5,345 | ) |
| Accounts payable, accruals and other obligations | (34,794 | ) |  | (39,266 | ) |
| Deferred revenue | 27,498 |  |  | 23,015 |  |
| Net cash provided by operating activities | 15,967 |  |  | 177,484 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (35,974 | ) |  | (39,729 | ) |
| Restricted cash | 2,059 |  |  | (42 | ) |
| Purchase of available for sale securities | (195,259 | ) |  | (180,203 | ) |
| Proceeds from maturities of available for sale securities | 150,000 |  |  | 140,000 |  |
| Settlement of foreign currency forward contracts, net | (10,796 | ) |  | 16,289 |  |
| Purchase of cost method investment | — |  |  | (2,000 | ) |
| Net cash used in investing activities | (89,970 | ) |  | (65,685 | ) |
| Cash flows provided by financing activities: |  |  |  |
| Proceeds from issuance of term loan, net | 248,750 |  |  | — |  |
| Payment of long term debt | — |  |  | (8,901 | ) |
| Payment for debt and equity issuance costs | (3,263 | ) |  | (420 | ) |
| Payment of capital lease obligations | (2,275 | ) |  | (6,441 | ) |
| Proceeds from issuance of common stock | 17,518 |  |  | 19,622 |  |
| Net cash provided by financing activities | 260,730 |  |  | 3,860 |  |
| Effect of exchange rate changes on cash and cash equivalents | (330 | ) |  | (5,288 | ) |
| Net increase in cash and cash equivalents | 186,397 |  |  | 110,371 |  |
| Cash and cash equivalents at beginning of period | 346,487 |  |  | 586,720 |  |
| Cash and cash equivalents at end of period | $ | 532,884 |  |  | $ | 697,091 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the period for interest | $ | 23,425 |  |  | $ | 31,566 |  |
| Cash paid during the period for income taxes, net | $ | 9,051 |  |  | $ | 8,526 |  |
| Non-cash investing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 4,334 |  |  | $ | 16,717 |  |
| Debt issuance costs in accrued liabilities | $ | 655 |  |  | $ | — |  |
| Equipment acquired under capital lease | $ | — |  |  | $ | 464 |  |
| Building subject to capital lease | $ | — |  |  | $ | 14,939 |  |
| Construction in progress subject to build-to-suit lease | $ | — |  |  | $ | 8,770 |  |
| Non-cash financing activities |  |  |  |
| Conversion of 4.0% convertible senior notes, due March 15, 2015 into 8,898,387 shares of common stock | — |  |  | 180,645 |  |

[0000936395-15-000049:8k_2_02:68]
| APPENDIX A - Reconciliation of Adjusted (Non- GAAP) Quarterly Measurements |
|  |  | Quarter Ended |
|  |  | July 31, |
|  |  | 2014 |  | 2015 |
| Gross Profit Reconciliation |  |  |  |  |
| GAAP gross profit |  | $ | 263,973 |  |  | $ | 269,869 |  |
| Share-based compensation-products |  | 737 |  |  | 671 |  |
| Share-based compensation-services |  | 572 |  |  | 490 |  |
| Amortization of intangible assets |  | 2,201 |  |  | 2,200 |  |
| Total adjustments related to gross profit |  | 3,510 |  |  | 3,361 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 267,483 |  |  | $ | 273,230 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 44.3 | % |  | 45.3 | % |
| Operating Expense Reconciliation |  |  |  |  |
| GAAP operating expense |  | $ | 226,971 |  |  | $ | 225,418 |  |
| Share-based compensation-research and development |  | 2,368 |  |  | 2,114 |  |
| Share-based compensation-sales and marketing |  | 3,890 |  |  | 3,571 |  |
| Share-based compensation-general and administrative |  | 3,376 |  |  | 3,516 |  |
| Acquisition and integration costs |  | — |  |  | 2,435 |  |
| Amortization of intangible assets |  | 11,019 |  |  | 11,019 |  |
| Restructuring costs |  | 63 |  |  | 192 |  |
| Settlement of patent litigation |  | — |  |  | 500 |  |
| Total adjustments related to operating expense |  | 20,716 |  |  | 23,347 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 206,255 |  |  | $ | 202,071 |  |
| Income from Operations Reconciliation |  |  |  |  |
| GAAP income from operations |  | $ | 37,002 |  |  | $ | 44,451 |  |
| Total adjustments related to gross profit |  | 3,510 |  |  | 3,361 |  |
| Total adjustments related to operating expense |  | 20,716 |  |  | 23,347 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 61,228 |  |  | 71,159 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 10.1 | % |  | 11.8 | % |
| Net Income Reconciliation |  |  |  |  |
| GAAP net income |  | $ | 16,160 |  |  | $ | 23,625 |  |
| Total adjustments related to gross profit |  | 3,510 |  |  | 3,361 |  |
| Total adjustments related to operating expense |  | 20,716 |  |  | 23,347 |  |
| Non-cash interest expense |  | 327 |  |  | 397 |  |
| Change in fair value of embedded redemption feature |  | 190 |  |  | — |  |
| Adjusted (non-GAAP) net income |  | $ | 40,903 |  |  | $ | 50,730 |  |
| Weighted average basic common shares outstanding |  | 106,236 |  |  | 118,413 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 156,561 |  |  | 159,787 |  |
| Net Income per Common Share |  |  |  |  |
| GAAP diluted net income per common share |  | $ | 0.15 |  |  | $ | 0.19 |  |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.32 |  |  | $ | 0.37 |  |

[0000936395-15-000049:8k_2_02:69]
| 1. | Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2014 includes 1.5 million shares underlying certain stock options and restricted stock units, 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due March 15, 2015, 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020. |

[0000936395-15-000049:8k_2_02:70]
Weighted average dilutive potential common shares outstanding used in calculating Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2015 includes 1.7 million shares underlying certain stock options and restricted stock units, 13.1 million shares underlying Ciena's 0.875% convertible senior notes, due June 15, 2017, 17.4 million shares underlying Ciena's 3.75% convertible senior notes, due October 15, 2018 and 9.2 million shares underlying Ciena's 4.0% convertible senior notes, due December 15, 2020.

[0000936395-15-000049:8k_2_02:71]
| 2. | The calculation of Adjusted (non-GAAP) diluted net income per common share for the fiscal third quarter of 2014 requires adding back interest expense of approximately approximately $2.1 million associated with Ciena's 4.0% convertible senior notes, due March 15, 2015, approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation. |

[0000936395-15-000049:8k_2_02:72]
The calculation of Adjusted (non-GAAP) diluted net income per common share for the third quarter of fiscal 2015 requires adding back interest expense of approximately $1.4 million associated with Ciena's 0.875% convertible senior notes, due June 15, 2017, approximately $3.6 million associated with Ciena's 3.75% convertible senior notes, due October 15, 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, due December 15, 2020 to the Adjusted (non-GAAP) net income in order to derive the numerator for the Adjusted earnings per common share calculation.

[0000936395-15-000049:8k_2_02:73]
* * *

[0000936395-15-000049:8k_2_02:74]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-15-000049:8k_2_02:75]
| • | Share-based compensation expense - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-15-000049:8k_2_02:76]
| • | Acquisition and integration costs - consist of expenses for financial, legal and accounting advisors, facilities and systems consolidation costs associated with our acquisition of Cyan. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-15-000049:8k_2_02:77]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-15-000049:8k_2_02:78]
| • | Restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-15-000049:8k_2_02:79]
| • | Settlement of patent litigation - included in general and administrative expense during the third quarter of fiscal 2015 is a $0.5 million patent litigation settlement. |

[0000936395-15-000049:8k_2_02:80]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes due December 15, 2020 relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-15-000049:8k_2_02:81]
| • | Change in fair value of embedded redemption feature - a non-cash unrealized gain or loss reflective of a mark to market fair value adjustment of an embedded derivative related to the redemption feature of Ciena's outstanding 4.0% senior convertible notes due March 15, 2015. |

## item 5.02 — body, verbatim

[0000936395-15-000049:8k_body:1]
ITEM 5.02 - DEPARTURE OF DIRECTORS OR CERTAIN OFFICERS; ELECTION OF DIRECTORS; APPOINTMENT OF CERTAIN OFFICERS; COMPENSATORY ARRANGEMENTS OF CERTAIN OFFICERS

[0000936395-15-000049:8k_body:2]
(b)(c)    On September 3, 2015, Ciena announced that its Board of Directors has approved the appointment of François Locoh-Donou to serve as Ciena’s Senior Vice President and Chief Operating Officer effective as of November 1, 2015. Mr. Locoh-Donou has served in his current role as Ciena’s Senior Vice President, Global Products Group since August 2011. In this new role, Mr. Locoh-Donou, 43, will assume responsibility for Ciena’s Global Field Organization, including the global sales and services functions, while retaining his existing responsibility for the research and development, product line management, supply chain and network integration functions. Mr. Locoh-Donou joined Ciena in August 2002 and previously served as Ciena’s Vice President and General Manager, EMEA, from June 2005 to July 2011. Additional information regarding Mr. Locoh-Donou’s appointment is included in the press release filed as Exhibit 99.2 to this Form 8-K.  The current compensation arrangements for Mr. Locoh-Donou were not changed at the time of his appointment and are materially consistent with those described in Ciena’s proxy statement for its 2015 Annual Meeting of Stockholders under the headings “Compensation Discussion and Analysis” and “Executive Compensation Tables.” Upon the effectiveness of Mr. Locoh-Donou's appointment as Ciena’s Senior Vice President and Chief Operating Officer he shall cease to serve as Ciena’s Senior Vice President, Global Products Group.
