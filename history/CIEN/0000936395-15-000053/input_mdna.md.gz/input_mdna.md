# CIEN MD&A — 0000936395-15-000053


## mdna

[0000936395-15-000053:mdna:1]
[same as prior period, unchanged from 0000936395-15-000038:mdna:1]

[0000936395-15-000053:mdna:2]
Some of the statements contained in this quarterly report discuss future events or expectations, contain projections of results of operations or financial condition, indicate changes in the markets for our products and services, or state other “forward-looking” information. Ciena’s “forward-looking” information is based on various factors and was derived using numerous assumptions. In some cases, you can identify these “forward-looking statements” by words like “may,” “will,” “should,” “expects,” “plans,” “anticipates,” “believes,” “estimates,” “predicts,” “intends,” “potential” or “continue” or the negative of those words and other comparable words. You should be aware that these statements only reflect our current predictions and beliefs. These statements are subject to known and unknown risks, uncertainties and other factors, and actual events or results may differ materially. Important factors that could cause our actual results to be materially different from the forward-looking statements are disclosed throughout this report, particularly in Item 1A “Risk Factors” of Part II of this report below. For a more complete understanding of the risks associated with an investment in Ciena’s securities, you should review these risk factors and the rest of this quarterly report in combination with the more detailed description of our business and management’s discussion and analysis of financial condition in our annual report on Form 10-K, which we filed with the Securities and Exchange Commission ("SEC") on December 19, 2014. Ciena undertakes no obligation to revise or update any forward-looking statements.

[0000936395-15-000053:mdna:3]
[same as prior period, unchanged from 0000936395-15-000038:mdna:3]

[0000936395-15-000053:mdna:4]
[same as prior period, unchanged from 0000936395-15-000038:mdna:4]

[0000936395-15-000053:mdna:5]
Our Converged Packet Optical, Packet Networking, Optical Transport and Software products are used, individually or as part of an integrated solution, in networks operated by communications service providers, cable operators, Web-scale providers, governments, enterprises, research and education institutions and other network operators across the globe. Our products allow network operators to scale capacity, increase transmission speeds, allocate network traffic and adapt to changing end-user demands through rapid service creation and delivery. Our solutions also include network management and control software and

[0000936395-15-000053:mdna:6]
network-level software applications that facilitate automation and efficient service delivery. To complement our hardware and software solutions, we offer a broad range of network transformation solutions and related support services that help our customers design, optimize, deploy, manage and maintain their networks.

[0000936395-15-000053:mdna:7]
The rapid proliferation of communications services and devices, together with increased mobility and growth in cloud-based services, have fundamentally affected the demands placed upon communications networks and how they are designed. Network operators also face a rapidly changing business environment that includes a shifting competitive landscape and challenges to existing business models. Our OPn Architecture, and the increased network scalability, flexibility and programmability that it enables, is designed to meet these challenges. Our OPn network approach allows for network-level software applications to control and configure the network dynamically, while flexible interfaces integrate computing, storage and network resources. This approach enables highly configurable infrastructures that can meet the "on-demand" requirements of end-users and the changing services they rely upon. By enhancing software programmability and control, enabling network functions virtually, and reducing required network elements, our OPn approach optimizes network infrastructures to connect content data centers, and users to such content. At the same time, our approach creates business and operational value for our customers by increasing scale at reduced cost and facilitating rapid introduction of new, revenue-generating service offerings. Our OPn Architecture, which underpins our solutions offering and guides our research and development strategy, is described more fully in the "Strategy" section below.

[0000936395-15-000053:mdna:8]
[same as prior period, unchanged from 0000936395-15-000038:mdna:8]

[0000936395-15-000053:mdna:9]
Acquisition of Cyan, Inc.

[0000936395-15-000053:mdna:10]
On August 3, 2015, we acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all then-outstanding Cyan stock options and unvested restricted stock unit awards and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

[0000936395-15-000053:mdna:11]
Our acquisition of Cyan is intended to advance a strategy that started with the introduction of our OPn architecture and was extended with the launch of our Agility software division in fiscal 2014. We believe that Cyan's best-in-class Blue Planet software solutions portfolio will significantly strengthen our software offering. Complementing Ciena's network control and application software technologies, Cyan adds multi-vendor network and service orchestration and next-generation network management software. The Blue Planet portfolio offers a carrier-grade, multi-vendor SDN and NFV platform designed to automate, orchestrate, and manage the lifecycle of virtualized services across data centers and the WAN. It also includes a family of applications designed to control and manage both physical network elements and virtual SDN/NFV resources. Further strengthening our leadership in packet-optical, Cyan brings a growing metro packet-optical business with a complementary base of key customers for its family of Z-Series high-capacity, multi-layer switching and transport platforms. We believe that this strategic acquisition will accelerate our availability to offer a complete, on-demand solution for virtualized networks and services in an open ecosystem, and will enable us to play a leading role in the transformation of the network from the delivery of pure capacity to the creation of capability on-demand. Revenue from Cyan's packet-optical solutions will be included in our Converged Packet Optical operating segment and revenue from its Blue Planet software solutions will be included in our Software and Services operating segment.

[0000936395-15-000053:mdna:12]
Upon the closing of the acquisition, we unified the software activities of both companies under a single brand and comprehensive set of resources known as the "Blue Planet" division. The division, which includes Ciena's former Agility business, will focus on helping customers automate services, from creation to orchestration to delivery, across both physical and virtual domains. The Blue Planet product portfolio includes Cyan's software applications, including Planet Orchestrate and Planet Operate, as well as Ciena's SDN Multilayer WAN Controller and its applications, V-WAN, Agility Matrix and network management solutions. The division, which is focused on providing next-generation multi-vendor network management and services orchestration solutions, is comprised of teams responsible for software development, product line management, product marketing, service and support, sales and business development.

[0000936395-15-000053:mdna:13]
During the first nine months of fiscal 2015, we incurred approximately $3.5 million of acquisition-related costs associated with this transaction. We further expect to incur a number of non-recurring costs during the remainder of fiscal 2015. These costs

[0000936395-15-000053:mdna:14]
and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other potential employment-related costs, including payments to certain former Cyan executives. We currently expect to incur in total, approximately $25.0 million of such expenses, which includes approximately $7.9 million of non-cash share-based compensation expense. We expect a substantial majority of these acquisition-related costs to be recognized during our fourth quarter of fiscal 2015. We also expect our financial results to be impacted, in a number of ways, as a result of the purchase accounting for the Cyan transaction. As a result of our expected increase in the value of the acquired inventory to its fair value as of the acquisition date, we expect our costs of goods sold and gross margin for sale of this inventory to be adversely impacted. Similarly, we expect to record finite-lived intangible assets such as developed technology, customer relationships, trademarks, trade names and customer backlog, the amortization of which will increase our expense during the useful life of these assets. As a result of its shorter term expected life, we expect the amortization expense associated with customer backlog to be principally incurred in our fourth quarter of fiscal 2015. We expect the acquisition-related costs and the the effect of purchase accounting for the transaction to adversely impact our net income for the fourth quarter of fiscal 2015.

[0000936395-15-000053:mdna:15]
Cyan had fiscal 2014 revenues of approximately $101.0 million. Because of the timing of the closing of this acquisition early in Ciena's fourth quarter of fiscal 2015, except where specifically indicated, Ciena's results of operations for the third quarter of fiscal 2015 and the corresponding discussion in this “Management’s Discussion and Analysis of Financial Condition and Results of Operations” do not give effect to the acquisition of Cyan, its operations or its effect on our results of operations. In addition to the acquisition and integration related costs noted above, we expect the inclusion of the Cyan operations to increase our revenue and operating expense in the fourth quarter of fiscal 2015.

[0000936395-15-000053:mdna:16]
Assumption and Conversion of Cyan Convertible Notes

[0000936395-15-000053:mdna:17]
Upon the closing of the acquisition, we assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of the 2019 Notes. As of September 3, 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes had surrendered their 2019 notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, we issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

[0000936395-15-000053:mdna:18]
[same as prior period, unchanged from 0000936395-15-000038:mdna:9]

[0000936395-15-000053:mdna:19]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, technology convergence, increased mobility, and evolving cloud-based service offerings and on-demand end-user service expectations. These conditions have created market opportunities and challenges that have impacted how networks are designed and services are consumed. These conditions have also resulted in a diverse set of network operator customer segments, and shifting competitive landscapes for network operators and the vendors that support them. Existing and emerging network operators are competing to distinguish their service offerings and introduce differentiated, revenue-generating services. At the same time, network operators continue to seek to manage the costs of their network and to ensure a profitable business model. These dynamics are driving technology convergence of network features, functions and layers, virtualization of certain network functions, and the adoption of software-based network control and programmability. We believe that these dynamics, and the need to adapt to changing business conditions, are creating an environment that will cause network operators to adopt infrastructures that are more open, programmable and automated. We also believe that these conditions will require vendors and network operators to leverage an open ecosystem of virtualized resources provided by a variety of third parties and will drive increased openness and interoperability of network infrastructures.

[0000936395-15-000053:mdna:20]
In recent periods, we have seen certain of our large service provider customers, including several of our larger customers in North America, take steps to constrain their capital expenditure budgets. This measured spending environment has adversely impacted segments of our market and the spending levels we have experienced from certain of these customers as compared to prior periods. During fiscal 2014 and the first nine months of fiscal 2015, we were able to continue to grow total revenue, in part, as a result of our strategy of focusing on certain higher growth segments of the network infrastructure market and the shift in spending toward next-generation solutions that enable network operators to monetize their network infrastructures. We also benefited from our efforts to diversify our customer base to include additional customer segments, such as Web-scale providers and multi-service operators, and to secure additional service provider customers in geographies including Brazil and India. We believe that our results underscore the importance of having established customer relationships with a diverse set of traditional communications service providers and Web-scale providers as their purchasing decisions and focus on open, on-demand network environments become increasingly interdependent.

[0000936395-15-000053:mdna:21]
[same as prior period, unchanged from 0000936395-15-000038:mdna:12]

[0000936395-15-000053:mdna:22]
[same as prior period, unchanged from 0000936395-15-000038:mdna:13]

[0000936395-15-000053:mdna:23]
We continue to encounter a highly competitive and and fragmented marketplace. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, high-capacity, high-speed network solutions and seek adoption of these solutions and our network architectural approach, particularly in metro applications. Our sales of Packet Networking solutions, including our 8700 Packetwave Platform, also face a highly competitive marketplace for data center interconnection and connecting users-to-content, with additional competitors, including traditional IP router vendors. We expect the current competitive landscape to remain challenging and dynamic. As networking technologies become more software-driven, and network features and layers continue to converge, our competitive landscape continues to broaden beyond our traditional competitors. As a result, we are competing with, and expect to compete increasingly with, additional vendors focused on IP routing, information technology and software.

[0000936395-15-000053:mdna:24]
Within these competitive dynamics, efforts to maintain incumbency and secure new opportunities with with key customers can often require aggressive pricing, significant commercial concessions or other unfavorable commercial terms. These terms have previously, and may in the future, adversely affect our quarterly results of operations and contribute to fluctuations in our results. These terms can also elongate our revenue recognition or cash collection cycles, add start-up costs to initial sales or deployment of our solutions, require financial commitments or performance bonds, and include onerous contractual commitments that place a disproportionate allocation of risk upon us.

[0000936395-15-000053:mdna:25]
[same as prior period, unchanged from 0000936395-15-000038:mdna:17]

[0000936395-15-000053:mdna:26]
[same as prior period, unchanged from 0000936395-15-000038:mdna:18]

[0000936395-15-000053:mdna:27]
Promotion of Our OPn Architecture. Our OPn Architecture enables a programmable infrastructure that brings together the reliability and capacity of optical networking with the flexibility and economics of packet networking technologies. Our OPn Architecture leverages this convergence to enable network operators to scale their networks efficiently and cost effectively, while applying advanced software-based network control and network-level software applications for enhanced programmability. The software-driven aspects of this architecture become increasingly important as network operators increasingly seek to leverage an open ecosystem of virtualized resources to enable the real-time analytics and network agility required for on-demand, next-generation network architectures. We see opportunities in offering a portfolio of OPn Architecture solutions that facilitate the transition to these next-generation networks and that are optimized to create new services rapidly and to meet end-user demands.

[0000936395-15-000053:mdna:28]
Research and Development Investment to Expand the Role and Application of Our Solutions. Our product development initiatives are focused on opportunities that enable Ciena to expand its role in customer networks and to address a more diverse set of network applications. We are investing in our OPn Architecture with current development efforts focused on expanding high-capacity service delivery capabilities in our Packet Networking and Converged Packet Optical products for metro networks, data center interconnectivity and wide area network applications. Our research and development efforts also seek to extend our existing technologies, including our WaveLogic coherent optical processor for 200G and 400G optical transport, and to introduce Terabit per second and greater transmission speeds. In the packet area, we are increasing the scale, density and capability of our packet offerings, and reducing power and space requirements, for applications in metro networks, user aggregation and data center connectivity. In the software area, we are also focused on increasing programmability and software control of networks. These efforts include our next-generation SDN and NFV solutions designed to automate, orchestrate, and manage physical and virtualized services across data centers and the WAN.

[0000936395-15-000053:mdna:29]
Go-to-Market Model to Expand Our Role and Reach. Our go-to-market model is focused on driving sales growth from the diversification of our business and further penetrating additional customer verticals and international markets. We are also focused on further penetrating Internet content providers, data center operators and other emerging network operators that form the "Web-scale" marketplace. To expand the geographic reach of our direct sales resources, we have pursued strategic channel opportunities that enable sales through third parties, including service providers, systems integrators and value-added resellers. Through the packet-optical resale element of our strategic relationship with Ericsson, we are seeking to expand our geographic reach, as well as the application of our products in customer networks. We also remain focused on expanding the application of our products by existing customers, including communications service provider customers and cable and multiservice operators. These sales efforts seek opportunities for our solutions in applications including metro aggregation, data center interconnectivity, managed services offerings, cloud-based services, business Ethernet services and mobile backhaul.

[0000936395-15-000053:mdna:30]
Business Optimization to Yield Operating Leverage. We are actively pursuing initiatives to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and

[0000936395-15-000053:mdna:31]
procurement initiatives to consolidate vendors and to ensure that our product cost model remains ahead of market-based price erosion. We are also focused on transforming our supply chain, including efforts to reduce our material and overhead costs, reduce customer lead times and improve inventory management and logistics. Our initiatives also include significant investments in the re-engineering of company-wide enterprise resource planning platforms, improved automation of key business processes and systems, and the off-shoring of certain business functions. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-15-000053:mdna:32]
[same as prior period, unchanged from 0000936395-15-000038:mdna:31]

[0000936395-15-000053:mdna:33]
We have introduced a number of new product platforms and chipsets during fiscal 2015 and in May 2015 launched our new Waveserver™ product. Waveserver is a stackable data center interconnect (DCI) platform that allows network operators, including Web-scale providers and data center operators, to scale bandwidth quickly and to support high-speed data transfer, virtual machine migration and disaster recovery/backup between data centers. Waveserver is a specialized platform, purpose-built for connecting data centers within a single metro area. It is optimized for the capacity, speed, space and power requirements of data center environments. Waveserver is designed to leverage the data server user experience, with open APIs and server-like deployment, provisioning and programmability via smart devices. We believe this product expands our role and market opportunity beyond our current solutions offering and enables us to further diversify our business through sales to additional customer verticals. Revenue from sales of Waveserver will be included in our Converged Packet Optical segment.

[0000936395-15-000053:mdna:34]
Sequential Financial Results

[0000936395-15-000053:mdna:35]
Revenue for the third quarter of fiscal 2015 was $602.9 million, representing a sequential decrease of 3.0% from $621.6 million in the second quarter of fiscal 2015. Our revenue for the third quarter of fiscal 2015 primarily reflects reduced spending levels by certain large service provider customers, particularly in North America, partially offset by revenue growth from our sales to government customers and AT&T. This reduction in spending impacted order volume during the third quarter of fiscal 2015, as compared to record order volume during the second quarter of fiscal 2015. This spending reduction was largely due to customer-specific factors, including, among other things, network implementation timing, short-term budget constraints and the effect on capital expenditure levels resulting from customer consolidation activities. As a result of initiatives to improve the velocity of our business, the percentage of quarterly revenue that we generate from customer orders placed during such quarter has increased as compared to prior periods. As a result, reductions in expected order volume in a given quarter can expose us to increased fluctuations in revenue for that quarter. Revenue-related details reflecting sequential changes from the second quarter of fiscal 2015 include:

[0000936395-15-000053:mdna:36]
| • | Product revenue for the third quarter of fiscal 2015 decreased by $18.0 million, reflecting a decrease of $24.9 million in Converged Packet Optical, partially offset by increases of $3.9 million in Packet Networking, $2.0 million in software and $1.0 million in Optical Transport. |

[0000936395-15-000053:mdna:37]
| • | Service revenue for the third quarter of fiscal 2015 decreased by $0.7 million. |

[0000936395-15-000053:mdna:38]
| • | North America revenue for the third quarter of fiscal 2015 was $389.6 million, a decrease from $397.2 million in the second quarter of fiscal 2015. This primarily reflects decreases of $7.1 million in Converged Packet Optical and $5.4 million in Packet Networking, partially offset by increases of $3.3 million in Software and Services and $1.6 million in Optical Transport. |

[0000936395-15-000053:mdna:39]
| • | Europe, Middle East and Africa ("EMEA") revenue for the third quarter of fiscal 2015 was $93.2 million, a decrease from $102.2 million in the second quarter of fiscal 2015. This primarily reflects decreases of $15.8 million in Converged Packet Optical, partially offset by increases of $4.9 million in Software and Services and $1.4 million in Packet Networking. |

[0000936395-15-000053:mdna:40]
| • | Caribbean and Latin America ("CALA") revenue for the third quarter of fiscal 2015 was $65.1 million, an increase from $47.9 million in the second quarter of fiscal 2015. This primarily reflects increases of $17.2 million in Converged Packet Optical and $1.2 million in Software and Services, partially offset by a $1.1 million decrease in Optical Transport. |

[0000936395-15-000053:mdna:41]
| • | Asia Pacific ("APAC") revenue for the third quarter of fiscal 2015 was $55.0 million, a decrease from $74.3 million in the second quarter of fiscal 2015. This primarily reflects decreases of $19.2 million in Converged Packet Optical and $8.1 million in Software and Services, partially offset by a $7.9 million increase in Packet Networking. |

[0000936395-15-000053:mdna:42]
| • | For the third quarter of fiscal 2015, AT&T accounted for 20.2% of total revenue. This compares to 18.9% of total revenue in the second quarter of fiscal 2015. |

[0000936395-15-000053:mdna:43]
Gross margin for the third quarter of fiscal 2015 was 44.8%, an increase from 43.8% in the second quarter of fiscal 2015. The improved gross margin for the third quarter of fiscal 2015 was primarily due to improved services margin, primarily from

[0000936395-15-000053:mdna:44]
35

[0000936395-15-000053:mdna:45]
increased software subscription service revenue, and a favorable product mix that included a larger portion of higher margin channel cards and increased sales of Packet Networking products.

[0000936395-15-000053:mdna:46]
Operating expense was $225.4 million for the third quarter of fiscal 2015, a decrease from $230.0 million in the second quarter of fiscal 2015. Third quarter fiscal 2015 operating expense primarily reflects decreases of $4.8 million in research and development expense and $0.8 million in selling and marketing expense. Operating expense for the third quarter of fiscal 2015 also reflects an increase of $1.4 million in acquisition and integration costs principally related to legal and accounting service fees associated with our acquisition of Cyan described above.

[0000936395-15-000053:mdna:47]
Income from operations for the third quarter of fiscal 2015 was $44.5 million, compared to income from operations of $42.4 million during the second quarter of fiscal 2015. Our net income for the third quarter of fiscal 2015 was $23.6 million, or $0.19 per diluted common share. This compares to a net income of $20.7 million or $0.17 per diluted common share, for the second quarter of fiscal 2015.

[0000936395-15-000053:mdna:48]
We generated cash from operations of $117.5 million during the third quarter of fiscal 2015, consisting of $72.3 million in cash provided by net income adjusted for non-cash charges and $45.2 million provided by cash related to improvements in working capital. This compares with $37.8 million of cash generated from operations during the second quarter of fiscal 2015, consisting of $79.8 million in cash provided by net income adjusted for non-cash charges and $42.0 million used in cash related to changes in working capital.

[0000936395-15-000053:mdna:49]
As of July 31, 2015, we had $697.1 million in cash and cash equivalents, $160.1 million of short-term investments in U.S. treasury securities and commercial paper and $70.2 million of long-term investments in U.S. treasury securities. This compares to $586.3 million in cash and cash equivalents, $145.1 million of short-term investments in U.S. treasury securities and commercial paper and $85.2 million of long-term investments in U.S. treasury securities, at April 30, 2015,

[0000936395-15-000053:mdna:50]
As of July 31, 2015, we had 5,196 employees which was an increase from 5,108 at April 30, 2015 and an increase from 5,136 at July 31, 2014.

[0000936395-15-000053:mdna:51]
[same as prior period, unchanged from 0000936395-15-000038:mdna:49]

[0000936395-15-000053:mdna:52]
[same as prior period, unchanged from 0000936395-15-000038:mdna:50]

[0000936395-15-000053:mdna:53]
[same as prior period, unchanged from 0000936395-15-000038:mdna:51]

[0000936395-15-000053:mdna:54]
| • | Converged Packet Optical —includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. In May 2015, we launched our new Waveserver™ product. Revenue from sales of Waveserver are included in our Converged Packet Optical segment. |

[0000936395-15-000053:mdna:55]
[same as prior period, unchanged from 0000936395-15-000038:mdna:53]

[0000936395-15-000053:mdna:56]
[same as prior period, unchanged from 0000936395-15-000038:mdna:54]

[0000936395-15-000053:mdna:57]
| • | Software and Services — includes Ciena's Agility software portfolio, which includes a SDN multilayer WAN controller, NFV platform, and network level software applications for enabling on-demand, high-bandwidth WAN |

[0000936395-15-000053:mdna:58]
services delivered in an open network ecosystem. This segment also includes the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager and Optical Suite Release. This segment includes a broad range of services for consulting and network design, installation and deployment, maintenance support and training activities. Except for revenue from the software portion of this segment, which is included in product revenue, revenue from this segment is included in services revenue on the Condensed Consolidated Statement of Operations.

[0000936395-15-000053:mdna:59]
Quarter ended July 31, 2014 compared to the quarter ended July 31, 2015

[0000936395-15-000053:mdna:60]
[same as prior period, unchanged from 0000936395-15-000038:mdna:57]

[0000936395-15-000053:mdna:61]
During fiscal 2015, the U.S. dollar has strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars during the third quarter of fiscal 2015 was adversely impacted by approximately $13.8 million or 2.2% as compared to the third quarter of fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000053:mdna:62]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 382,031 |  |  | 63.3 |  | $ | 407,970 |  |  | 67.7 |  | $ | 25,939 |  |  | 6.8 |  |
| Packet Networking | 69,464 |  |  | 11.5 |  | 57,209 |  |  | 9.5 |  | (12,255 | ) |  | (17.6 | ) |
| Optical Transport | 31,016 |  |  | 5.1 |  | 17,482 |  |  | 2.9 |  | (13,534 | ) |  | (43.6 | ) |
| Software and Services | 121,051 |  |  | 20.1 |  | 120,271 |  |  | 19.9 |  | (780 | ) |  | (0.6 | ) |
| Consolidated revenue | $ | 603,562 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | (630 | ) |  | (0.1 | ) |

[0000936395-15-000053:mdna:63]
[same as prior period, unchanged from 0000936395-15-000038:mdna:60]

[0000936395-15-000053:mdna:64]
[same as prior period, unchanged from 0000936395-15-000038:mdna:61]

[0000936395-15-000053:mdna:65]
[same as prior period, unchanged from 0000936395-15-000038:mdna:62]

[0000936395-15-000053:mdna:66]
| • | Converged Packet Optical revenue increased, primarily reflecting a $28.7 million increase in sales of our 6500 Packet-Optical Platform, largely driven by network operator demand for high-capacity, optical transport for coherent 40G and 100G network infrastructure. Segment revenue also reflects an increase of $8.6 million in sales of the OTN configuration for the 5410 Reconfigurable Switching System. These increases were partially offset by a $11.9 million decrease in sales of our 5430 Reconfigurable Switching System. The strong performance of this segment, particularly as compared to the steady declines we have experienced, and expect to continue to experience, in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality. |

[0000936395-15-000053:mdna:67]
| • | Packet Networking revenue decreased, reflecting a $14.6 million decrease in sales of our 3000 and 5000 families of service delivery and aggregation switches. This decrease was partially offset by increases of $1.5 million in sales of our 5410 Service Aggregation Switch and $1.0 million in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014. |

[0000936395-15-000053:mdna:68]
| • | Optical Transport revenue decreased, reflecting decreases of $5.0 million in sales of our 4200 Advanced Services Platform, $5.3 million in sales of our other stand-alone transport products and $3.2 million in sales of our 5100/5200 Advanced Services Platform. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years. We expect this trend to continue, reflecting network operators' transition toward next-generation converged network architectures as described above. |

[0000936395-15-000053:mdna:69]
| • | Software and Services revenue decreased, reflecting decreases of $2.2 million in network transformation consulting, $2.1 million in software revenue and $1.8 million in installation and deployment services. These decreases were offset by an increase of $5.3 million in maintenance and support services. |

[0000936395-15-000053:mdna:70]
[same as prior period, unchanged from 0000936395-15-000038:mdna:67]

[0000936395-15-000053:mdna:71]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 403,250 |  |  | 66.8 |  | 389,593 |  |  | 64.6 |  | $ | (13,657 | ) |  | (3.4 | ) |
| EMEA | 99,909 |  |  | 16.6 |  | 93,168 |  |  | 15.5 |  | (6,741 | ) |  | (6.7 | ) |
| CALA | 67,248 |  |  | 11.1 |  | 65,152 |  |  | 10.8 |  | (2,096 | ) |  | (3.1 | ) |
| APAC | 33,155 |  |  | 5.5 |  | 55,019 |  |  | 9.1 |  | 21,864 |  |  | 65.9 |  |
| Total | $ | 603,562 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | (630 | ) |  | (0.1 | ) |

[0000936395-15-000053:mdna:72]
[same as prior period, unchanged from 0000936395-15-000038:mdna:69]

[0000936395-15-000053:mdna:73]
[same as prior period, unchanged from 0000936395-15-000038:mdna:70]

[0000936395-15-000053:mdna:74]
[same as prior period, unchanged from 0000936395-15-000038:mdna:72]

[0000936395-15-000053:mdna:75]
| • | North America revenue reflects a decrease of $23.3 million in Packet Networking sales of our 3000 and 5000 families of service delivery and aggregation switches. In addition sales of Optical Transport products decreased by $10.4 million and sales of Software and Services decreased by $4.5 million. These decreases were partially offset by an increase of $24.5 million in Converged Packet Optical sales. Converged Packet Optical sales reflect increases of $15.8 million in sales of our 6500 Packet-Optical Platform, $5.7 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System, $1.6 million in sales of our CoreDirector® Multiservice Optical Switches and $1.3 million in sales of our 5430 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to AT&T and government customers, partially offset by reduced sales to certain large communication service provider customers. |

[0000936395-15-000053:mdna:76]
| • | EMEA revenue reflects decreases of $6.6 million in Converged Packet Optical sales and $3.6 million in Optical Transport sales, partially offset by an increase of $2.9 million in Packet Networking sales. Converged Packet Optical sales reflect decreases of $3.2 million in sales of our 6500 Packet-Optical Platform and $2.8 million in sales of our OTN configuration for the 5410 Reconfigurable Switching System. |

[0000936395-15-000053:mdna:77]
| • | CALA revenue primarily reflects a decrease of $1.6 million in Converged Packet Optical sales. |

[0000936395-15-000053:mdna:78]
| • | APAC revenue reflects increases of $9.6 million in Converged Packet Optical sales, $8.3 million in Packet Networking sales and $3.5 million in Software and Services sales. Converged Packet Optical sales reflect increases of $8.6 million in sales of our 6500 Packet-Optical Platform and $1.6 million in sales of our 5410 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers and sales through our strategic partnership with Ericsson. Packet Networking sales reflect an increase in sales of our 3000 and 5000 families of service delivery and aggregation switches to certain communication service providers. |

[0000936395-15-000053:mdna:79]
[same as prior period, unchanged from 0000936395-15-000038:mdna:77]

[0000936395-15-000053:mdna:80]
[same as prior period, unchanged from 0000936395-15-000038:mdna:78]

[0000936395-15-000053:mdna:81]
[same as prior period, unchanged from 0000936395-15-000038:mdna:79]

[0000936395-15-000053:mdna:82]
Our gross profit as a percentage of revenue, or “gross margin,” is susceptible to fluctuations due to a number of factors. In any given period, gross margin can vary significantly depending upon the mix and concentration of revenue by segment, product line within a particular segment, geography and customers. Gross margin can also be affected by our concentration of

[0000936395-15-000053:mdna:83]
lower margin "common" equipment sales and higher margin channel cards, the mix of lower margin installation services within our service revenue, our introduction of new products, and changes in expense for excess and obsolete inventory and warranty obligations. We expect that gross margins will be subject to fluctuation based on our level of success in driving product cost reductions relative to the market-based price erosion we typically encounter. Accordingly gross margin can be adversely affected by the level of pricing pressure and competition that we encounter in the market. In an effort to retain or secure customers, enter new markets or capture market share, we may agree to pricing or other unfavorable commercial terms that result in lower or negative gross margins on a particular order or group of orders. Gross margin can also be affected as a result of our degree of success in implementing certain optimization initiatives focused on rationalizing our supply chain and consolidating third party contract manufacturers and distribution sites. These factors and market dynamics may result in fluctuation in our results of operations and can adversely affect our gross margin and results of operations in certain periods.

[0000936395-15-000053:mdna:84]
[same as prior period, unchanged from 0000936395-15-000038:mdna:81]

[0000936395-15-000053:mdna:85]
[same as prior period, unchanged from 0000936395-15-000038:mdna:82]

[0000936395-15-000053:mdna:86]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 603,562 |  |  | 100.0 |  | $ | 602,932 |  |  | 100.0 |  | $ | (630 | ) |  | (0.1 | ) |
| Total cost of goods sold | 339,589 |  |  | 56.3 |  | 333,063 |  |  | 55.2 |  | (6,526 | ) |  | (1.9 | ) |
| Gross profit | $ | 263,973 |  |  | 43.7 |  | $ | 269,869 |  |  | 44.8 |  | $ | 5,896 |  |  | 2.2 |  |

[0000936395-15-000053:mdna:87]
[same as prior period, unchanged from 0000936395-15-000038:mdna:84]

[0000936395-15-000053:mdna:88]
[same as prior period, unchanged from 0000936395-15-000038:mdna:85]

[0000936395-15-000053:mdna:89]
[same as prior period, unchanged from 0000936395-15-000038:mdna:86]

[0000936395-15-000053:mdna:90]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 495,889 |  |  | 100.0 |  | $ | 493,919 |  |  | 100.0 |  | $ | (1,970 | ) |  | (0.4 | ) |
| Product cost of goods sold | 275,003 |  |  | 55.5 |  | 273,837 |  |  | 55.4 |  | (1,166 | ) |  | (0.4 | ) |
| Product gross profit | $ | 220,886 |  |  | 44.5 |  | $ | 220,082 |  |  | 44.6 |  | $ | (804 | ) |  | (0.4 | ) |

[0000936395-15-000053:mdna:91]
[same as prior period, unchanged from 0000936395-15-000038:mdna:88]

[0000936395-15-000053:mdna:92]
[same as prior period, unchanged from 0000936395-15-000038:mdna:89]

[0000936395-15-000053:mdna:93]
[same as prior period, unchanged from 0000936395-15-000038:mdna:90]

[0000936395-15-000053:mdna:94]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 107,673 |  |  | 100.0 |  | $ | 109,013 |  |  | 100.0 |  | $ | 1,340 |  |  | 1.2 |  |
| Service cost of goods sold | 64,586 |  |  | 60.0 |  | 59,226 |  |  | 54.3 |  | (5,360 | ) |  | (8.3 | ) |
| Service gross profit | $ | 43,087 |  |  | 40.0 |  | $ | 49,787 |  |  | 45.7 |  | $ | 6,700 |  |  | 15.5 |  |

[0000936395-15-000053:mdna:95]
[same as prior period, unchanged from 0000936395-15-000038:mdna:92]

[0000936395-15-000053:mdna:96]
[same as prior period, unchanged from 0000936395-15-000038:mdna:93]

[0000936395-15-000053:mdna:97]
[same as prior period, unchanged from 0000936395-15-000038:mdna:94]

[0000936395-15-000053:mdna:98]
[same as prior period, unchanged from 0000936395-15-000038:mdna:95]

[0000936395-15-000053:mdna:99]
[same as prior period, unchanged from 0000936395-15-000038:mdna:96]

[0000936395-15-000053:mdna:100]
[same as prior period, unchanged from 0000936395-15-000038:mdna:97]

[0000936395-15-000053:mdna:101]
[same as prior period, unchanged from 0000936395-15-000038:mdna:98]

[0000936395-15-000053:mdna:102]
Operating expense consists of the component elements described below.

[0000936395-15-000053:mdna:103]
[same as prior period, unchanged from 0000936395-15-000038:mdna:100]

[0000936395-15-000053:mdna:104]
[same as prior period, unchanged from 0000936395-15-000038:mdna:101]

[0000936395-15-000053:mdna:105]
[same as prior period, unchanged from 0000936395-15-000038:mdna:102]

[0000936395-15-000053:mdna:106]
Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, facilities and systems consolidation costs associated with our acquisition of Cyan.

[0000936395-15-000053:mdna:107]
[same as prior period, unchanged from 0000936395-15-000038:mdna:104]

[0000936395-15-000053:mdna:108]
[same as prior period, unchanged from 0000936395-15-000038:mdna:105]

[0000936395-15-000053:mdna:109]
[same as prior period, unchanged from 0000936395-15-000038:mdna:106]

[0000936395-15-000053:mdna:110]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 97,685 |  |  | 16.2 |  | $ | 100,379 |  |  | 16.6 |  | $ | 2,694 |  |  | 2.8 |  |
| Selling and marketing | 81,919 |  |  | 13.6 |  | 81,650 |  |  | 13.5 |  | (269 | ) |  | (0.3 | ) |
| General and administrative | 36,285 |  |  | 6.0 |  | 29,743 |  |  | 4.9 |  | (6,542 | ) |  | (18.0 | ) |
| Acquisition and integration costs | — |  |  | — |  | 2,435 |  |  | 0.4 |  | 2,435 |  |  | 100.0 |  |
| Amortization of intangible assets | 11,019 |  |  | 1.8 |  | 11,019 |  |  | 1.8 |  | — |  |  | — |  |
| Restructuring costs | 63 |  |  | — |  | 192 |  |  | — |  | 129 |  |  | 204.8 |  |
| Total operating expenses | $ | 226,971 |  |  | 37.6 |  | $ | 225,418 |  |  | 37.4 |  | $ | (1,553 | ) |  | (0.7 | ) |

[0000936395-15-000053:mdna:111]
[same as prior period, unchanged from 0000936395-15-000038:mdna:108]

[0000936395-15-000053:mdna:112]
[same as prior period, unchanged from 0000936395-15-000038:mdna:109]

[0000936395-15-000053:mdna:113]
[same as prior period, unchanged from 0000936395-15-000038:mdna:110]

[0000936395-15-000053:mdna:114]
| • | Research and development expense benefited from $8.1 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $2.7 million. This increase reflects increases of $2.7 million in facilities and information technology costs, $1.8 million in prototype costs and a $1.3 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario due to the maximum funding limit being met in the second quarter of fiscal 2015, partially offset by decreases of $1.8 million in employee and compensation costs and $1.0 million in professional services. |

[0000936395-15-000053:mdna:115]
| • | Selling and marketing expense benefited from $5.0 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expense decreased by $0.3 million, primarily reflecting a decrease of $1.5 million in trade show and related costs, offset by an increase of $1.0 million in customer demonstration equipment. |

[0000936395-15-000053:mdna:116]
| • | General and administrative expense benefited from $1.3 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense decreased by $6.5 million, primarily due to a decrease in legal fees. |

[0000936395-15-000053:mdna:117]
| • | Acquisition and integration costs primarily reflect legal and accounting costs associated with the acquisition of Cyan. |

[0000936395-15-000053:mdna:118]
| • | Amortization of intangible assets remained unchanged. |

[0000936395-15-000053:mdna:119]
| • | Restructuring costs remained relatively unchanged. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-15-000053:mdna:120]
[same as prior period, unchanged from 0000936395-15-000038:mdna:117]

[0000936395-15-000053:mdna:121]
[same as prior period, unchanged from 0000936395-15-000038:mdna:118]

[0000936395-15-000053:mdna:122]
|  | Quarter Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (6,328 | ) |  | (1.0 | ) |  | $ | (5,491 | ) |  | (0.9 | ) |  | $ | 837 |  |  | (13.2 | ) |
| Interest expense | $ | 11,508 |  |  | 1.9 |  |  | $ | 11,883 |  |  | 2.0 |  |  | $ | 375 |  |  | 3.3 |  |
| Provision for income taxes | $ | 3,006 |  |  | 0.5 |  |  | $ | 3,452 |  |  | 0.6 |  |  | $ | 446 |  |  | 14.8 |  |

[0000936395-15-000053:mdna:123]
[same as prior period, unchanged from 0000936395-15-000038:mdna:120]

[0000936395-15-000053:mdna:124]
[same as prior period, unchanged from 0000936395-15-000038:mdna:121]

[0000936395-15-000053:mdna:125]
[same as prior period, unchanged from 0000936395-15-000038:mdna:122]

[0000936395-15-000053:mdna:126]
| • | Interest and other income (loss), net primarily reflects a gain due to the remeasurement of assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity |

[0000936395-15-000053:mdna:127]
| • | Interest expense increased, primarily due to the Term Loan entered into in the third quarter of fiscal 2014 and related interest payments. For additional information about our Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-15-000053:mdna:128]
| • | Provision for income taxes increased, primarily due to foreign tax expense, which is largely a result of higher income from our Indian operations. |

[0000936395-15-000053:mdna:129]
Nine months ended July 31, 2014 compared to the nine months ended July 31, 2015

[0000936395-15-000053:mdna:130]
[same as prior period, unchanged from 0000936395-15-000038:mdna:127]

[0000936395-15-000053:mdna:131]
During the first nine months of fiscal 2015, as compared to the first nine months of fiscal 2014, the U.S. dollar strengthened against a number of foreign currencies, including the Canadian Dollar and Euro, in which we have our most significant foreign currency revenue exposure. Consequently, our total revenue reported in U.S. dollars was adversely impacted by approximately $37.9 million or 2.1% as compared to the first nine months of fiscal 2014. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-15-000053:mdna:132]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 1,072,272 |  |  | 63.2 |  | $ | 1,177,441 |  |  | 67.2 |  | $ | 105,169 |  |  | 9.8 |  |
| Packet Networking | 187,699 |  |  | 11.1 |  | 165,480 |  |  | 9.4 |  | (22,219 | ) |  | (11.8 | ) |
| Optical Transport | 100,729 |  |  | 5.9 |  | 56,275 |  |  | 3.2 |  | (44,454 | ) |  | (44.1 | ) |
| Software and Services | 336,626 |  |  | 19.8 |  | 354,500 |  |  | 20.2 |  | 17,874 |  |  | 5.3 |  |
| Consolidated revenue | $ | 1,697,326 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 56,370 |  |  | 3.3 |  |

[0000936395-15-000053:mdna:133]
[same as prior period, unchanged from 0000936395-15-000038:mdna:130]

[0000936395-15-000053:mdna:134]
[same as prior period, unchanged from 0000936395-15-000038:mdna:131]

[0000936395-15-000053:mdna:135]
[same as prior period, unchanged from 0000936395-15-000038:mdna:132]

[0000936395-15-000053:mdna:136]
| • | Converged Packet Optical revenue increased, reflecting an increase of $117.0 million in sales of our 6500 Packet-Optical Platform, largely driven by service provider demand for high-capacity, optical transport for coherent 40G and 100G network infrastructures. In addition, sales of the OTN configuration for the 5410 Reconfigurable Switching System increased by $14.5 million. These increases were partially offset by decreases of $16.2 million in sales of our |

[0000936395-15-000053:mdna:137]
CoreDirector® Multiservice Optical Switches and $10.1 million in sales of our 5430 reconfigurable switching system. The strong performance of this segment, particularly as compared to the expected revenue declines in Optical Transport segment revenue, reflects the preference of network operators to adopt next-generation architectures that enable the convergence of high-capacity, coherent optical transport with integrated OTN switching and control plane functionality.

[0000936395-15-000053:mdna:138]
| • | Packet Networking revenue decreased, reflecting decreases of $24.6 million in sales of our 3000 and 5000 families of service delivery and aggregation switches and $2.0 million in sales of our legacy broadband products. These decreases were offset by a $3.9 million increase in sales of our 8700 Packetwave Platform, which became available for sale in the fourth quarter of fiscal 2014. |

[0000936395-15-000053:mdna:139]
| • | Optical Transport revenue decreased, reflecting decreases of $17.0 million in sales of our 4200 Advanced Services Platform, $15.3 million in sales of our 5100/5200 Advanced Services Platform and $12.1 million in sales of our other stand-alone transport products. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000053:mdna:140]
| • | Software and Services revenue increased, reflecting increases of $17.0 million in maintenance and support services and $3.6 million in installation and deployment services, partially offset by a decrease of $2.7 million in network transformation consulting services. |

[0000936395-15-000053:mdna:141]
The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-15-000053:mdna:142]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| North America | $ | 1,136,867 |  |  | 67.0 |  | $ | 1,118,309 |  |  | 63.7 |  | $ | (18,558 | ) |  | (1.6 | ) |
| EMEA | 283,743 |  |  | 16.7 |  | 306,368 |  |  | 17.5 |  | 22,625 |  |  | 8.0 |  |
| CALA | 160,162 |  |  | 9.4 |  | 155,785 |  |  | 8.9 |  | (4,377 | ) |  | (2.7 | ) |
| APAC | 116,554 |  |  | 6.9 |  | 173,234 |  |  | 9.9 |  | 56,680 |  |  | 48.6 |  |
| Total | $ | 1,697,326 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 56,370 |  |  | 3.3 |  |

[0000936395-15-000053:mdna:143]
[same as prior period, unchanged from 0000936395-15-000038:mdna:140]

[0000936395-15-000053:mdna:144]
[same as prior period, unchanged from 0000936395-15-000038:mdna:141]

[0000936395-15-000053:mdna:145]
[same as prior period, unchanged from 0000936395-15-000038:mdna:142]

[0000936395-15-000053:mdna:146]
| • | North America revenue includes sales to AT&T for first nine months of fiscal 2014 and fiscal 2015 of $351.3 million and $355.6 million, respectively. Revenues reflect decreases of $32.4 million in Packet Networking sales and $33.1 million in Optical Transport sales. Packet Networking sales reflect decreased sales of our 3000 and 5000 families of service delivery and aggregation switches. Optical Transport sales reflect decreases of $12.4 million of sales of our 4200 Advanced Services Platform, $11.0 million of sales of our 5100/5200 Advanced Services Platform and $9.8 million of sales of our other stand-alone transport products. These decreases were partially offset by increases of $43.5 million in Converged Packet Optical sales and $3.4 million in Software and Services sales. Converged Packet Optical sales reflect increases of $47.4 million of sales of our 6500 Packet-Optical Platform and $7.3 million of sales of our 5410 Reconfigurable Switching System, partially offset by a decrease of $11.3 million of sales of our CoreDirector® Multiservice Optical Switches. Sales of our 6500 Packet-Optical Platform reflect increased sales to AT&T, multiservice operator customers, Web-scale providers and government customers, partially offset by decreased sales to certain large communication service provider customers. |

[0000936395-15-000053:mdna:147]
| • | EMEA revenue reflects increases of $34.8 million in sales of Converged Packet Optical and $2.4 million in sales of Packet Networking. These increases were partially offset by decreases of $9.8 million in Optical Transport sales and $4.8 million in Software and Services sales. Converged Packet Optical sales reflect increases of $33.2 million of sales of our 6500 Packet-Optical Platform, $3.8 million of sales of our 5430 Reconfigurable Switching System and $1.2 million of sales of our 5410 Reconfigurable Switching System, partially offset by a decrease of $3.4 million of sales of our CoreDirector® Multiservice Optical Switches. Sales of our 6500 Packet-Optical Platform reflect increased sales to submarine network operators,Web-scale providers, multiservice operator customers, enterprise customers and certain large communication service providers. |

[0000936395-15-000053:mdna:148]
[same as prior period, unchanged from 0000936395-15-000038:mdna:147]

[0000936395-15-000053:mdna:149]
| • | CALA revenue reflects an $11.2 million decrease in Converged Packet Optical sales. This decrease was partially offset by increases of $6.2 million in Software and Services sales and $1.1 million in Optical Transport sales. Converged Packet Optical sales reflect a $29.1 million decrease in sales of our 5430 Reconfigurable Switching System. This decrease was partially offset by increases of $15.3 million in sales of our 6500 Packet-Optical Platform and $2.8 million of sales of our 5410 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers. |

[0000936395-15-000053:mdna:150]
| • | APAC revenue reflects increases of $38.0 million in Converged Packet Optical sales, $13.1 million in Software and Services sales and $8.3 million in Packet Networking sales. These increases were partially offset by a $2.6 million decrease in sales of Optical Transport. Converged Packet Optical sales reflect increases of $21.0 million of sales of our 6500 Packet-Optical Platform and $19.1 million of sales of our 5430 Reconfigurable Switching System. These increases were partially offset by decreases of $1.2 million of sales of our CoreDirector® Multiservice Optical Switches and $1.0 million of sales of our 5410 Reconfigurable Switching System. Sales of our 6500 Packet-Optical Platform reflect increased sales to communication service providers and sales through our strategic relationship with Ericsson. Sales of our 5430 Reconfigurable Switching System reflect increased sales to communication service providers and submarine network operators. Software and Services sales reflect increases of $6.1 million in installation and deployment services, $3.4 million in maintenance and support services, $2.6 million in software sales and $1.0 million in network transformation consulting. |

[0000936395-15-000053:mdna:151]
[same as prior period, unchanged from 0000936395-15-000038:mdna:148]

[0000936395-15-000053:mdna:152]
[same as prior period, unchanged from 0000936395-15-000038:mdna:149]

[0000936395-15-000053:mdna:153]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 1,697,326 |  |  | 100.0 |  | $ | 1,753,696 |  |  | 100.0 |  | $ | 56,370 |  |  | 3.3 |
| Total cost of goods sold | 969,811 |  |  | 57.1 |  | 981,121 |  |  | 55.9 |  | 11,310 |  |  | 1.2 |
| Gross profit | $ | 727,515 |  |  | 42.9 |  | $ | 772,575 |  |  | 44.1 |  | $ | 45,060 |  |  | 6.2 |

[0000936395-15-000053:mdna:154]
[same as prior period, unchanged from 0000936395-15-000038:mdna:151]

[0000936395-15-000053:mdna:155]
[same as prior period, unchanged from 0000936395-15-000038:mdna:152]

[0000936395-15-000053:mdna:156]
[same as prior period, unchanged from 0000936395-15-000038:mdna:153]

[0000936395-15-000053:mdna:157]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 1,389,651 |  |  | 100.0 |  | $ | 1,428,114 |  |  | 100.0 |  | $ | 38,463 |  |  | 2.8 |
| Product cost of goods sold | 777,851 |  |  | 56.0 |  | 797,283 |  |  | 55.8 |  | 19,432 |  |  | 2.5 |
| Product gross profit | $ | 611,800 |  |  | 44.0 |  | $ | 630,831 |  |  | 44.2 |  | $ | 19,031 |  |  | 3.1 |

[0000936395-15-000053:mdna:158]
[same as prior period, unchanged from 0000936395-15-000038:mdna:155]

[0000936395-15-000053:mdna:159]
[same as prior period, unchanged from 0000936395-15-000038:mdna:156]

[0000936395-15-000053:mdna:160]
[same as prior period, unchanged from 0000936395-15-000038:mdna:157]

[0000936395-15-000053:mdna:161]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 307,675 |  |  | 100.0 |  | $ | 325,582 |  |  | 100.0 |  | $ | 17,907 |  |  | 5.8 |  |
| Service cost of goods sold | 191,960 |  |  | 62.4 |  | 183,838 |  |  | 56.5 |  | (8,122 | ) |  | (4.2 | ) |
| Service gross profit | $ | 115,715 |  |  | 37.6 |  | $ | 141,744 |  |  | 43.5 |  | $ | 26,029 |  |  | 22.5 |  |

[0000936395-15-000053:mdna:162]
[same as prior period, unchanged from 0000936395-15-000038:mdna:159]

[0000936395-15-000053:mdna:163]
[same as prior period, unchanged from 0000936395-15-000038:mdna:160]

[0000936395-15-000053:mdna:164]
[same as prior period, unchanged from 0000936395-15-000038:mdna:161]

[0000936395-15-000053:mdna:165]
[same as prior period, unchanged from 0000936395-15-000038:mdna:162]

[0000936395-15-000053:mdna:166]
[same as prior period, unchanged from 0000936395-15-000038:mdna:163]

[0000936395-15-000053:mdna:167]
[same as prior period, unchanged from 0000936395-15-000038:mdna:164]

[0000936395-15-000053:mdna:168]
[same as prior period, unchanged from 0000936395-15-000038:mdna:165]

[0000936395-15-000053:mdna:169]
[same as prior period, unchanged from 0000936395-15-000038:mdna:166]

[0000936395-15-000053:mdna:170]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 302,674 |  |  | 17.8 |  | $ | 306,342 |  |  | 17.5 |  | $ | 3,668 |  |  | 1.2 |  |
| Selling and marketing | 243,929 |  |  | 14.4 |  | 240,833 |  |  | 13.7 |  | (3,096 | ) |  | (1.3 | ) |
| General and administrative | 98,264 |  |  | 5.8 |  | 89,598 |  |  | 5.1 |  | (8,666 | ) |  | (8.8 | ) |
| Acquisition and integration costs | — |  |  | — |  | 3,455 |  |  | 0.2 |  | 3,455 |  |  | — |  |
| Amortization of intangible assets | 34,951 |  |  | 2.1 |  | 33,057 |  |  | 1.9 |  | (1,894 | ) |  | (5.4 | ) |
| Restructuring costs | 178 |  |  | — |  | 8,260 |  |  | 0.5 |  | 8,082 |  |  | — |  |
| Total operating expenses | $ | 679,996 |  |  | 40.1 |  | $ | 681,545 |  |  | 38.9 |  | $ | 1,549 |  |  | 0.2 |  |

[0000936395-15-000053:mdna:171]
[same as prior period, unchanged from 0000936395-15-000038:mdna:168]

[0000936395-15-000053:mdna:172]
[same as prior period, unchanged from 0000936395-15-000038:mdna:169]

[0000936395-15-000053:mdna:173]
[same as prior period, unchanged from 0000936395-15-000038:mdna:170]

[0000936395-15-000053:mdna:174]
| • | Research and development expense benefited $19.0 million, as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. dollar in relation to the Canadian dollar. Including the effect of foreign exchange rates, research and development expenses increased by $3.7 million primarily reflecting increases of $6.2 million in facilities and information systems expense and a $3.0 million reduction in reimbursements from our strategic jobs investment fund grant from the province of Ontario due to the maximum funding limit being met in the second quarter of fiscal 2015. These increases were partially offset by a decrease of $6.0 million in professional services. |

[0000936395-15-000053:mdna:175]
| • | Selling and marketing expense benefited $12.7 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, selling and marketing expenses decreased by $3.1 million, primarily reflecting decreases of $1.6 million in trade show and related costs, $1.5 million in travel and related costs, and $1.1 million in professional services. These decreases were partially offset by an increase of $1.4 million in customer demonstration equipment. |

[0000936395-15-000053:mdna:176]
| • | General and administrative expense benefited $3.2 million as a result of foreign exchange rates, primarily due to a stronger U.S. dollar in relation to the Euro and the Canadian Dollar. Including the effect of foreign exchange rates, general and administrative expense decreased by $8.7 million, primarily reflecting a decrease in legal fees due to certain patent litigation costs incurred during fiscal 2014. |

[0000936395-15-000053:mdna:177]
| • | Acquisition and integration costs primarily reflects legal and accounting costs associated with the acquisition of Cyan. |

[0000936395-15-000053:mdna:178]
[same as prior period, unchanged from 0000936395-15-000038:mdna:115]

[0000936395-15-000053:mdna:179]
| • | Restructuring costs primarily reflect certain severance and related expense associated with headcount reductions and initiatives to improve efficiency. During fiscal 2015, we have incurred approximately $8.3 million in restructuring costs, primarily reflecting a global workforce reduction of approximately 125 employees in the first quarter of fiscal 2015 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. As we look to manage operating expense and drive further efficiency and leverage from our operations, we will continue to assess allocation of headcount, facilities and other resources to ensure that they are optimized toward key growth opportunities. |

[0000936395-15-000053:mdna:180]
[same as prior period, unchanged from 0000936395-15-000038:mdna:177]

[0000936395-15-000053:mdna:181]
[same as prior period, unchanged from 0000936395-15-000038:mdna:178]

[0000936395-15-000053:mdna:182]
|  | Nine Months Ended July 31, |  | Increase |  |  |
|  | 2014 |  | %* |  | 2015 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | (14,231 | ) |  | (0.8 | ) |  | $ | (19,273 | ) |  | (1.1 | ) |  | $ | (5,042 | ) |  | 35.4 |  |
| Interest expense | $ | 33,556 |  |  | 2.0 |  |  | $ | 38,491 |  |  | 2.2 |  |  | $ | 4,935 |  |  | 14.7 |  |
| Provision for income taxes | $ | 9,666 |  |  | 0.6 |  |  | $ | 7,767 |  |  | 0.4 |  |  | $ | (1,899 | ) |  | (19.6 | ) |

[0000936395-15-000053:mdna:183]
[same as prior period, unchanged from 0000936395-15-000038:mdna:180]

[0000936395-15-000053:mdna:184]
[same as prior period, unchanged from 0000936395-15-000038:mdna:181]

[0000936395-15-000053:mdna:185]
[same as prior period, unchanged from 0000936395-15-000038:mdna:182]

[0000936395-15-000053:mdna:186]
| • | Interest and other income (loss), net reflects a $7.3 million loss due to the remeasurement of assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity, partially offset by a $2.7 million non-cash gain related to the change in fair value of the embedded redemption feature associated with our 2015 Notes that matured in the second quarter of fiscal 2015. |

[0000936395-15-000053:mdna:187]
| • | Interest expense increased primarily due to the Term Loan entered into during the third quarter of fiscal 2014 and related interest payments. For additional information about our Term Loan, see Note 15 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-15-000053:mdna:188]
[same as prior period, unchanged from 0000936395-15-000038:mdna:185]

[0000936395-15-000053:mdna:189]
[same as prior period, unchanged from 0000936395-15-000038:mdna:186]

[0000936395-15-000053:mdna:190]
[same as prior period, unchanged from 0000936395-15-000038:mdna:187]

[0000936395-15-000053:mdna:191]
|  | Quarter Ended July 31, |  |  |  |
|  | 2014 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 104,020 |  |  | $ | 118,223 |  |  | $ | 14,203 |  |  | 13.7 |  |
| Packet Networking | $ | 14,566 |  |  | $ | 7,628 |  |  | $ | (6,938 | ) |  | (47.6 | ) |
| Optical Transport | $ | 8,900 |  |  | $ | 2,813 |  |  | $ | (6,087 | ) |  | (68.4 | ) |
| Software and Services | $ | 38,802 |  |  | $ | 40,826 |  |  | $ | 2,024 |  |  | 5.2 |  |

[0000936395-15-000053:mdna:192]
[same as prior period, unchanged from 0000936395-15-000038:mdna:189]

[0000936395-15-000053:mdna:193]
[same as prior period, unchanged from 0000936395-15-000038:mdna:190]

[0000936395-15-000053:mdna:194]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-15-000053:mdna:195]
| • | Packet Networking segment profit decreased primarily due to decreased sales volume in North America as described above. |

[0000936395-15-000053:mdna:196]
| • | Optical Transport segment profit decreased primarily due to reduced sales volume and lower gross margin, slightly offset by lower research and development costs. Revenue for our Optical Transport segment, which currently consists principally of stand-alone WDM and SONET/SDH-based transport platforms, has experienced meaningful declines in annual revenue in recent years, reflecting network operators' transition toward next-generation network architectures as described above. |

[0000936395-15-000053:mdna:197]
| • | Software and Services segment profit increased primarily due to improved gross margin as described above, partially offset increases in software research and development costs. |

[0000936395-15-000053:mdna:198]
[same as prior period, unchanged from 0000936395-15-000038:mdna:195]

[0000936395-15-000053:mdna:199]
|  | Nine Months Ended July 31, |  |  |  |  |
|  | 2014 |  | 2015 |  | Increase (decrease) |  | %* |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 279,299 |  |  | $ | 322,652 |  |  | $ | 43,353 |  |  | 15.5 |  |
| Packet Networking | $ | 23,147 |  |  | $ | 18,910 |  |  | $ | (4,237 | ) |  | (18.3 | ) |
| Optical Transport | $ | 29,259 |  |  | $ | 13,428 |  |  | $ | (15,831 | ) |  | (54.1 | ) |
| Software and Services | $ | 93,136 |  |  | $ | 111,243 |  |  | $ | 18,107 |  |  | 19.4 |  |

[0000936395-15-000053:mdna:200]
[same as prior period, unchanged from 0000936395-15-000038:mdna:198]

[0000936395-15-000053:mdna:201]
[same as prior period, unchanged from 0000936395-15-000038:mdna:199]

[0000936395-15-000053:mdna:202]
| • | Converged Packet Optical segment profit increased, primarily due to increased sales volume and improved gross margin, partially offset by increased research and development expense. Increased sales volume is largely driven by service provider demand for convergence of high-capacity, coherent 40G and 100G network infrastructures with integrated OTN switching and control plane functionality. |

[0000936395-15-000053:mdna:203]
| • | Packet Networking segment profit decreased, due to lower sales volume and reduced gross margin, partially offset by lower research and development costs. |

[0000936395-15-000053:mdna:204]
[same as prior period, unchanged from 0000936395-15-000038:mdna:202]

[0000936395-15-000053:mdna:205]
| • | Software and Services segment profit increased, primarily due to increases in sales of installation services, software subscription services, support and consulting services, and increased margin due to lower repair costs to support maintenance service contracts. These increases were partially offset by increased software research and development costs. |

[0000936395-15-000053:mdna:206]
[same as prior period, unchanged from 0000936395-15-000038:mdna:204]

[0000936395-15-000053:mdna:207]
At July 31, 2015, our principal sources of liquidity were cash and cash equivalents, investments in marketable debt securities, representing U.S. treasuries and commercial paper, and our ABL Credit Facility. The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-15-000053:mdna:208]
|  | October 31, 2014 |  | July 31, 2015 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 586,720 |  |  | $ | 697,091 |  |  | $ | 110,371 |  |
| Short-term investments in marketable debt securities | 140,205 |  |  | 160,067 |  |  | 19,862 |  |
| Long-term investments in marketable debt securities | 50,057 |  |  | 70,161 |  |  | 20,104 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 776,982 |  |  | $ | 927,319 |  |  | $ | 150,337 |  |

[0000936395-15-000053:mdna:209]
The change in total cash and cash equivalents and investments in marketable debt securities during the first nine months of fiscal 2015 was primarily related to the following:

[0000936395-15-000053:mdna:210]
| • | $177.5 million cash generated from operations, consisting of $168.5 million provided by net income (adjusted for non-cash charges) and $9.0 million provided by working capital; |

[0000936395-15-000053:mdna:211]
| • | $39.7 million used for purchases of equipment, furniture, and fixtures and intellectual property; |

[0000936395-15-000053:mdna:212]
| • | $16.3 million provided by settlement of foreign currency forward contracts, net; |

[0000936395-15-000053:mdna:213]
| • | $6.4 million used to pay capital lease obligations; |

[0000936395-15-000053:mdna:214]
[same as prior period, unchanged from 0000936395-15-000038:mdna:212]

[0000936395-15-000053:mdna:215]
| • | $8.9 million used for repayment of long-term debt; |

[0000936395-15-000053:mdna:216]
| • | $19.6 million provided by stock issuances under our employee stock purchase plan and exercise of stock options; and |

[0000936395-15-000053:mdna:217]
| • | $5.3 million decrease due to the effect of exchange rate changes on cash and cash equivalents. |

[0000936395-15-000053:mdna:218]
46

[0000936395-15-000053:mdna:219]
Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200.0 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of July 31, 2015, letters of credit totaling $54.3 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2015.

[0000936395-15-000053:mdna:220]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating plans and may consider capital raising and other market opportunities that may be available to us. Based on past performance and current expectations, we believe that our cash, cash equivalents, investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-15-000053:mdna:221]
The following sections set forth the components of our $177.5 million of cash generated from operating activities during the first nine months of fiscal 2015:

[0000936395-15-000053:mdna:222]
[same as prior period, unchanged from 0000936395-15-000038:mdna:219]

[0000936395-15-000053:mdna:223]
[same as prior period, unchanged from 0000936395-15-000038:mdna:220]

[0000936395-15-000053:mdna:224]
|  | Nine months ended |
|  | July 31, 2015 |
| Net income | $ | 25,499 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 41,601 |  |
| Share-based compensation costs | 32,402 |  |
| Amortization of intangible assets | 39,659 |  |
| Provision for inventory excess and obsolescence | 18,010 |  |
| Provision for warranty | 12,549 |  |
| Other | (1,220 | ) |
| Net income (adjusted for non-cash charges) | $ | 168,500 |  |

[0000936395-15-000053:mdna:225]
[same as prior period, unchanged from 0000936395-15-000038:mdna:222]

[0000936395-15-000053:mdna:226]
[same as prior period, unchanged from 0000936395-15-000038:mdna:223]

[0000936395-15-000053:mdna:227]
Cash used by accounts receivable during the first nine months of fiscal 2015, net of a $0.8 million provision for doubtful accounts, was $12.1 million. Our days sales outstanding (DSOs) decreased from 86 days for the first nine months of fiscal 2014 to 82 days for the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:228]
The following table sets forth (in thousands) changes to our accounts receivable, net of allowance for doubtful accounts, from the end of fiscal 2014 through the end of the third quarter of fiscal 2015:

[0000936395-15-000053:mdna:229]
|  | October 31, 2014 |  | July 31, 2015 |  | Increase(decrease) |
| Accounts receivable, net | $ | 518,981 |  |  | $ | 530,261 |  |  | $ | 11,280 |  |

[0000936395-15-000053:mdna:230]
[same as prior period, unchanged from 0000936395-15-000038:mdna:227]

[0000936395-15-000053:mdna:231]
Cash generated from decreases in inventory during the first nine months of fiscal 2015 was $42.6 million. Our inventory turns increased from 3.5 turns during the first nine months of fiscal 2014 to 5.5 turns during the first nine months of fiscal 2015. Our inventory balance, as reported on our Condensed Consolidated Balance Sheet, decreased by $60.6 million during the first nine months of fiscal 2015 reflecting, in part, certain supply chain initiatives to improve manufacturing efficiencies and inventory management and the reduction of deferred costs of sales. The reduction of the deferred costs of sales relates to the completion of certain submarine network projects. This change reflects $42.6 million of cash provided by inventory and a $18.0 million non-cash provision for excess and obsolescence. The following table sets forth (in thousands) changes to the components of our inventory from the end of fiscal 2014 through the end of the third quarter of fiscal 2015:

[0000936395-15-000053:mdna:232]
|  | October 31, 2014 |  | July 31, 2015 |  | Increase(decrease) |
| Raw materials | $ | 64,853 |  |  | $ | 54,112 |  |  | $ | (10,741 | ) |
| Work-in-process | 8,371 |  |  | 8,924 |  |  | 553 |  |
| Finished goods | 165,799 |  |  | 119,635 |  |  | (46,164 | ) |
| Deferred cost of goods sold | 75,763 |  |  | 59,606 |  |  | (16,157 | ) |
| Gross inventory | 314,786 |  |  | 242,277 |  |  | (72,509 | ) |
| Provision for inventory excess and obsolescence | (60,126 | ) |  | (48,260 | ) |  | 11,866 |  |
| Inventory | $ | 254,660 |  |  | $ | 194,017 |  |  | $ | (60,643 | ) |

[0000936395-15-000053:mdna:233]
[same as prior period, unchanged from 0000936395-15-000038:mdna:231]

[0000936395-15-000053:mdna:234]
Cash used in prepaid expense and other during the first nine months of fiscal 2015 was $5.3 million, primarily due to higher maintenance spares.

[0000936395-15-000053:mdna:235]
[same as prior period, unchanged from 0000936395-15-000038:mdna:233]

[0000936395-15-000053:mdna:236]
Utilization of cash resources for accounts payable, accruals and other obligations during the first nine months of fiscal 2015 was $39.3 million. The $6.2 million change in accounts payable, accruals and other obligations on our Condensed Consolidated Balance Sheet reflects this utilization offset by the recording of $46.8 million in the following accruals and other obligations: $1.7 million related to our foreign currency forward contracts, $2.9 million related to our forward starting interest rate swap and $12.5 million relating to warranties, $9.1 million for financing activities relating to unpaid capital leases, $11.8 million for investing activities related to equipment purchases and $8.8 million for investing activities related to property acquired under a build-to-suit lease. These accruals and other obligations were offset by $1.3 million foreign currency translation impact related to unpaid capital leases.

[0000936395-15-000053:mdna:237]
The following table sets forth (in thousands) changes in our accounts payable, accruals and other obligations from the end of fiscal 2014 through the end of the third quarter of fiscal 2015:

[0000936395-15-000053:mdna:238]
|  | October 31, 2014 |  | July 31, 2015 |  | Increase(decrease) |
| Accounts payable | $ | 209,777 |  |  | $ | 201,774 |  |  | $ | (8,003 | ) |
| Accrued liabilities | 276,608 |  |  | 272,691 |  |  | (3,917 | ) |
| Other long-term obligations | 45,390 |  |  | 63,482 |  |  | 18,092 |  |
| Accounts payable, accruals and other obligations | $ | 531,775 |  |  | $ | 537,947 |  |  | $ | 6,172 |  |

[0000936395-15-000053:mdna:239]
Interest Paid on Convertible Notes, ABL Credit Facility and Term Loan

[0000936395-15-000053:mdna:240]
The final interest payment owing on our 4.0% convertible senior notes, due March 15, 2015, was paid during the second fiscal quarter of 2015. We paid $3.8 million of interest on these convertible notes during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:241]
Interest on our outstanding 0.875% convertible senior notes, due June 15, 2017, is payable on June 15 and December 15 of each year. We paid $4.4 million in interest on these convertible notes during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:242]
Interest on our outstanding 3.75% convertible senior notes, due October 15, 2018, is payable on April 15 and October 15 of each year. We paid $6.6 million in interest on these convertible notes during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:243]
Interest on our outstanding 4.0% convertible senior notes, due December 15, 2020, is payable on June 15 and December 15 of each year. We paid $7.5 million in interest on these convertible notes during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:244]
Interest on our outstanding Term Loan, due July 15, 2019, is payable periodically based on the underlying market index rate selected for borrowing. We paid $7.1 million in interest on this term loan during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:245]
During the first nine months of fiscal 2015, we utilized the ABL Credit Facility to collateralize certain standby letters of credit. We paid $1.3 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility during the first nine months of fiscal 2015.

[0000936395-15-000053:mdna:246]
[same as prior period, unchanged from 0000936395-15-000038:mdna:244]

[0000936395-15-000053:mdna:247]
[same as prior period, unchanged from 0000936395-15-000038:mdna:245]

[0000936395-15-000053:mdna:248]
Deferred revenue increased by $23.0 million during the first nine months of fiscal 2015. Product deferred revenue represents either payments received in advance of shipment or payments received after shipment but before revenue recognition. Services deferred revenue is related to payment for service contracts for which revenue will be recognized over the contract term. The following table reflects (in thousands) the balance of deferred revenue and the change in this balance from the end of fiscal 2014 through the first nine months of fiscal 2015:

[0000936395-15-000053:mdna:249]
|  | October 31, 2014 |  | July 31, 2015 |  | Increase(decrease) |
| Products | $ | 50,457 |  |  | $ | 56,355 |  |  | $ | 5,898 |  |
| Services | 95,161 |  |  | 112,278 |  |  | 17,117 |  |
| Total deferred revenue | $ | 145,618 |  |  | $ | 168,633 |  |  | $ | 23,015 |  |

[0000936395-15-000053:mdna:250]
[same as prior period, unchanged from 0000936395-15-000038:mdna:248]

[0000936395-15-000053:mdna:251]
[same as prior period, unchanged from 0000936395-15-000038:mdna:249]

[0000936395-15-000053:mdna:252]
The following is a summary of our future minimum payments under contractual obligations as of July 31, 2015 (in thousands):

[0000936395-15-000053:mdna:253]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 1,067,127 |  |  | $ | — |  |  | $ | 500,000 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |
| Principal due on Term Loan | 247,500 |  |  | 2,500 |  |  | 5,000 |  |  | 240,000 |  |  | — |  |
| Interest due on convertible notes | 95,938 |  |  | 25,000 |  |  | 45,625 |  |  | 21,563 |  |  | 3,750 |  |
| Interest due on Term Loan (2) | 37,018 |  |  | 9,404 |  |  | 18,472 |  |  | 9,142 |  |  | — |  |
| Payments due under Interest Rate Swap (2) | 9,319 |  |  | 3,144 |  |  | 6,175 |  |  | — |  |  | — |  |
| Operating leases (3) | 149,235 |  |  | 32,150 |  |  | 48,645 |  |  | 21,991 |  |  | 46,449 |  |
| Purchase obligations (4) | 199,033 |  |  | 199,033 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 6,713 |  |  | 6,241 |  |  | 472 |  |  | — |  |  | — |  |
| Capital leases— buildings (5) | 127,982 |  |  | 1,720 |  |  | 9,079 |  |  | 14,841 |  |  | 102,342 |  |
| Other obligations | 3,688 |  |  | 3,227 |  |  | 461 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,943,553 |  |  | $ | 282,419 |  |  | $ | 633,929 |  |  | $ | 657,537 |  |  | $ | 369,668 |  |

[0000936395-15-000053:mdna:254]
[same as prior period, unchanged from 0000936395-15-000038:mdna:252]

[0000936395-15-000053:mdna:255]
[same as prior period, unchanged from 0000936395-15-000038:mdna:253]

[0000936395-15-000053:mdna:256]
| (2) | Interest on the Term Loan and payments due under the Interest Rate Swap are variable and were calculated using the rate in effect on the balance sheet date. |

[0000936395-15-000053:mdna:257]
[same as prior period, unchanged from 0000936395-15-000038:mdna:255]

[0000936395-15-000053:mdna:258]
[same as prior period, unchanged from 0000936395-15-000038:mdna:256]

[0000936395-15-000053:mdna:259]
[same as prior period, unchanged from 0000936395-15-000038:mdna:257]

[0000936395-15-000053:mdna:260]
| (6) | As of July 31, 2015, we also had approximately $11.8 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-15-000053:mdna:261]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of July 31, 2015 (in thousands):

[0000936395-15-000053:mdna:262]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years | Thereafter |
| Standby letters of credit | $ | 54,304 |  |  | $ | 26,162 |  |  | $ | 14,285 |  |  | $ | 6,000 |  | $ | 7,857 |  |

[0000936395-15-000053:mdna:263]
[same as prior period, unchanged from 0000936395-15-000038:mdna:261]

[0000936395-15-000053:mdna:264]
[same as prior period, unchanged from 0000936395-15-000038:mdna:262]

[0000936395-15-000053:mdna:265]
[same as prior period, unchanged from 0000936395-15-000038:mdna:263]

[0000936395-15-000053:mdna:266]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-15-000053:mdna:267]
[same as prior period, unchanged from 0000936395-15-000038:mdna:265]

[0000936395-15-000053:mdna:268]
[same as prior period, unchanged from 0000936395-15-000038:mdna:266]

[0000936395-15-000053:mdna:269]
[same as prior period, unchanged from 0000936395-15-000038:mdna:267]

[0000936395-15-000053:mdna:270]
We apply the percentage-of-completion method to long-term arrangements where we are required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, we recognize revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage- of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the first nine months ended July 31, 2014 and July 31, 2015 were 4.3% and 1.9%, respectively.

[0000936395-15-000053:mdna:271]
[same as prior period, unchanged from 0000936395-15-000038:mdna:270]

[0000936395-15-000053:mdna:272]
[same as prior period, unchanged from 0000936395-15-000038:mdna:271]

[0000936395-15-000053:mdna:273]
[same as prior period, unchanged from 0000936395-15-000038:mdna:272]

[0000936395-15-000053:mdna:274]
[same as prior period, unchanged from 0000936395-15-000038:mdna:273]

[0000936395-15-000053:mdna:275]
Our total deferred revenue for products was $50.5 million and $56.4 million as of October 31, 2014 and July 31, 2015, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $95.2 million and $112.3 million as of October 31, 2014 and July 31, 2015, respectively.

[0000936395-15-000053:mdna:276]
[same as prior period, unchanged from 0000936395-15-000038:mdna:275]

[0000936395-15-000053:mdna:277]
[same as prior period, unchanged from 0000936395-15-000038:mdna:276]

[0000936395-15-000053:mdna:278]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 18 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of

[0000936395-15-000053:mdna:279]
July 31, 2015, total unrecognized compensation expense was $72.8 million, which relates to unvested restricted stock units and this expense is expected to be recognized over a weighted-average period of 1.5 years.

[0000936395-15-000053:mdna:280]
[same as prior period, unchanged from 0000936395-15-000038:mdna:278]

[0000936395-15-000053:mdna:281]
[same as prior period, unchanged from 0000936395-15-000038:mdna:279]

[0000936395-15-000053:mdna:282]
[same as prior period, unchanged from 0000936395-15-000038:mdna:280]

[0000936395-15-000053:mdna:283]
For fiscal 2015, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2015. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for incentive compensation in any interim period in fiscal 2015 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $37.1 million of expense in the first nine months of fiscal 2015 associated with our cash incentive bonus plan for fiscal 2015.

[0000936395-15-000053:mdna:284]
[same as prior period, unchanged from 0000936395-15-000038:mdna:282]

[0000936395-15-000053:mdna:285]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $22.0 million and $18.0 million in the first nine months of fiscal 2014 and 2015, respectively. The charges in fiscal 2015 primarily related to the discontinuance of certain parts and components used in the manufacture of Converged Packet Optical products and decreases in forecasted demand for our legacy, stand-alone WDM and SONET/SDH-based transport platforms and our 5410 Service Aggregation Switch. Our inventory net of allowance for excess and obsolescence was $254.7 million and $194.0 million as of October 31, 2014 and July 31, 2015, respectively.

[0000936395-15-000053:mdna:286]
[same as prior period, unchanged from 0000936395-15-000038:mdna:284]

[0000936395-15-000053:mdna:287]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be

[0000936395-15-000053:mdna:288]
required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $519.0 million and $530.3 million as of October 31, 2014 and July 31, 2015, respectively. Our allowance for doubtful accounts was $2.1 million and $2.3 million as of October 31, 2014 and July 31, 2015, respectively.

[0000936395-15-000053:mdna:289]
[same as prior period, unchanged from 0000936395-15-000038:mdna:287]

[0000936395-15-000053:mdna:290]
Our long-lived assets include: equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2014 and July 31, 2015, these assets totaled $309.4 million and $307.6 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows.We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-15-000053:mdna:291]
[same as prior period, unchanged from 0000936395-15-000038:mdna:289]

[0000936395-15-000053:mdna:292]
As of July 31, 2015, we have recorded a valuation allowance offsetting substantially all our net deferred tax assets of $1.5 billion. When measuring the need for a valuation allowance, we assess both positive and negative evidence regarding the realizability of these deferred tax assets. We record a valuation allowance to reduce our deferred tax assets to the amount that is more likely than not to be realized. In determining net deferred tax assets and valuation allowances, management is required to make judgments and estimates related to projections of profitability, the timing and extent of the utilization of net operating loss carryforwards, applicable tax rates, transfer pricing methodologies and tax planning strategies. The valuation allowance is reviewed quarterly and is maintained until sufficient positive evidence exists to support a reversal. Because evidence such as our operating results during the most recent three-year period is afforded more weight than forecasted results for future periods, our cumulative loss during this three-year period represents sufficient negative evidence regarding the need for nearly a full valuation allowance. We will release this valuation allowance when management determines that it is more likely than not that our deferred tax assets will be realized. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements.

[0000936395-15-000053:mdna:293]
[same as prior period, unchanged from 0000936395-15-000038:mdna:291]

[0000936395-15-000053:mdna:294]
Our liability for product warranties, included in other accrued liabilities, was $56.0 million and $53.8 million as of October 31, 2014 and July 31, 2015, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $18.7 million and $12.5 million for the first nine months of fiscal 2014 and 2015, respectively. See Note 12 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
