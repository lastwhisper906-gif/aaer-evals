# CIEN notes — 0000936395-15-000053


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-15-000053:notes:1]
ABL CREDIT FACILITY

[0000936395-15-000053:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $200 million with a maturity date of December 31, 2016. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments. As of July 31, 2015, letters of credit totaling $54.3 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of July 31, 2015.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-15-000053:notes:3]
[same as prior period, unchanged from 0000936395-15-000038:notes:3]

[0000936395-15-000053:notes:4]
[same as prior period, unchanged from 0000936395-15-000038:notes:4]

[0000936395-15-000053:notes:5]
Additionally, Ciena's access to certain materials or components is dependent upon sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena's supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena's business and results of operations may suffer.


## cien:GovernmentGrantsPolicyTextBlock

[0000936395-15-000053:notes:6]
[same as prior period, unchanged from 0000936395-15-000038:notes:6]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-15-000053:notes:7]
[same as prior period, unchanged from 0000936395-15-000038:notes:7]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-15-000053:notes:8]
[same as prior period, unchanged from 0000936395-15-000038:notes:8]

[0000936395-15-000053:notes:9]
[same as prior period, unchanged from 0000936395-15-000038:notes:9]

[0000936395-15-000053:notes:10]
|  | October 31, 2014 |  | July 31, 2015 |
| Prepaid VAT and other taxes | $ | 86,464 |  |  | $ | 86,113 |  |
| Product demonstration equipment, net | 42,385 |  |  | 42,469 |  |
| Deferred deployment expense | 27,991 |  |  | 24,238 |  |
| Prepaid expenses | 23,539 |  |  | 23,095 |  |
| Other non-trade receivables | 10,683 |  |  | 3,388 |  |
| Derivative assets | 1,562 |  |  | 5,837 |  |
|  | $ | 192,624 |  |  | $ | 185,140 |  |

[0000936395-15-000053:notes:11]
Depreciation of product demonstration equipment was $6.7 million and $7.3 million for the first nine months of fiscal 2014 and 2015, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-15-000053:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-15-000053:notes:13]
Term Loan

[0000936395-15-000053:notes:14]
On July 15, 2014, Ciena entered into a Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “Term Loan”) with a maturity date of July 15, 2019. The Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):

[0000936395-15-000053:notes:15]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 247,500 |  |  | $ | 1,149 |  |  | $ | 246,351 |  |

[0000936395-15-000053:notes:16]
The following table sets forth, in thousands, the carrying value and the estimated fair value of the Term Loan:

[0000936395-15-000053:notes:17]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 246,351 |  |  | $ | 248,428 |  |

[0000936395-15-000053:notes:18]
| (1) | Includes unamortized bond discount. |

[0000936395-15-000053:notes:19]
| (2) | The Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000053:notes:20]
Maturity of 2015 Convertible Notes

[0000936395-15-000053:notes:21]
On March 15, 2015, Ciena's outstanding 4.0% Convertible Senior Notes due 2015 (the “2015 Notes”) matured. As a result of conversion elections made by holders of a substantial majority of the outstanding 2015 Notes under the terms of the indenture, together with certain private exchange transactions conducted by Ciena prior to maturity, approximately $180.6 million in aggregate principal amount of 2015 Notes, representing 96.3% of the outstanding aggregate principal amount of 2015 Notes, was settled through the issuance of Ciena common stock at or prior to maturity. In total, Ciena issued approximately 8.9 million shares of Ciena common stock as a result of the conversion elections and private exchange transactions in respect of the 2015 Notes. Ciena repaid in cash approximately $6.9 million in aggregate principal amount of 2015 Notes at maturity.

[0000936395-15-000053:notes:22]
Outstanding Convertible Notes Payable

[0000936395-15-000053:notes:23]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% convertible senior notes due December 15, 2020 are as follows as of July 31, 2015:

[0000936395-15-000053:notes:24]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 196,679 |  |  | $ | 13,769 |  |  | $ | 182,910 |  |  | $ | 43,131 |  |

[0000936395-15-000053:notes:25]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding convertible notes:

[0000936395-15-000053:notes:26]
|  |  | July 31, 2015 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | 500,000 |  |  | 507,813 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 498,750 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 182,910 |  |  | 274,116 |  |
|  |  | $ | 1,032,910 |  |  | $ | 1,280,679 |  |

[0000936395-15-000053:notes:27]
| (1) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-15-000053:notes:28]
| (2) | Includes unamortized discount and accretion of principal. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-15-000053:notes:29]
[same as prior period, unchanged from 0000936395-15-000038:notes:29]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-15-000053:notes:30]
[same as prior period, unchanged from 0000936395-15-000038:notes:30]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-15-000053:notes:31]
COMMITMENTS AND CONTINGENCIES

[0000936395-15-000053:notes:32]
Ontario Grant

[0000936395-15-000053:notes:33]
Ciena was awarded a conditional grant from the Province of Ontario in June 2011. Under this strategic jobs investment fund grant, Ciena can receive up to an aggregate of CAD$25.0 million in funding for eligible costs relating to certain next-generation, coherent optical transport development initiatives over the period from November 1, 2010 to October 31, 2015. Amounts received under the grant are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of July 31, 2015, Ciena has received payment for the full amount of the grant. Payments received were recorded as a reduction in research and development expenses.

[0000936395-15-000053:notes:34]
Foreign Tax Contingencies

[0000936395-15-000053:notes:35]
As of October 31, 2014 and July 31, 2015, Ciena had accrued liabilities of $0.5 million and $1.1 million, respectively, related to preliminary assessment notices from the India tax authorities asserting deficiencies in payments for the tax years 2009 and 2010 related to income taxes. This contingency has been reported as a component of other long-term liabilities. Although Ciena estimates that it could be exposed to possible losses of up to $2.7 million, it has not accrued a liability of such amount as of July 31, 2015. Ciena has not accrued the additional income tax liability because it does not believe that such a loss is more likely than not. Ciena continues to evaluate the likelihood of a probable and reasonably possible loss, if any, related to these assessments. As a result, future increases or decreases to accrued liabilities may be necessary and will be recorded in the period when such amounts are estimable and more likely than not to occur.

[0000936395-15-000053:notes:36]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-15-000053:notes:37]
Litigation

[0000936395-15-000053:notes:38]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware:

[0000936395-15-000053:notes:39]
| • | Luvishis v. Cyan, Inc., et al., C.A. No. 11027-CB, filed May 15, 2015 |

[0000936395-15-000053:notes:40]
| • | Poll v. Cyan, Inc., et al., C.A. No. 11028-CB, filed May 15, 2015 |

[0000936395-15-000053:notes:41]
| • | Canzano v. Floyd, et al., C.A. No. 11052-CB, filed May 20, 2015 |

[0000936395-15-000053:notes:42]
| • | Kassis v. Cyan, Inc., et al., C.A. No. 11069-CB, filed May 27, 2015 |

[0000936395-15-000053:notes:43]
| • | Fenske v. Cyan, Inc., et al., C.A. No. 11090-CB, filed June 3, 2015 |

[0000936395-15-000053:notes:44]
Each of the complaints named Cyan (except for the Canzano complaint), Ciena, Neptune Acquisition Subsidiary, Inc., a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors as defendants. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, plaintiffs filed a verified amended class action complaint, naming Ciena, Merger Sub and the members of Cyan’s board of directors as defendants. The amended complaint alleges, among other things, that the Cyan board members breached their fiduciary duties by failing to take steps to maximize the value of Cyan to its public stockholders, taking steps to avoid competitive bidding, failing to properly value Cyan and obtain the best exchange ratio, ignoring or not protecting against certain conflicts of interest, and failing to disclose all material information necessary for Cyan stockholders to make an informed decision regarding the acquisition. The amended complaint also alleges that Ciena and Merger Sub aided and abetted the alleged breaches of fiduciary duties by the Cyan board members. The amended complaint seeks (i) preliminary and permanent injunctive relief enjoining Cyan and Ciena from consummating the merger, (ii) in the event the merger is consummated prior to the entry of the court’s final judgment, rescission of the merger or rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, and (iv) costs including attorneys’ fees and experts’ fees. On August 10, 2015, the defendants filed motions to dismiss the amended complaint. No briefing schedule or hearing date has been set on these motions. Ciena believes that the consolidated lawsuit is without merit, and intends to defend it vigorously.

[0000936395-15-000053:notes:45]
As a result of our acquisition of Cyan in August 2015, we became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-539008. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. In July 2014, the defendants filed a demurrer to the consolidated complaint, which the court overruled in October 2014 and allowed the case to proceed. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case. Ciena believes that the consolidated lawsuit is without merit and intend to defend it vigorously.

[0000936395-15-000053:notes:46]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-15-000053:notes:47]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-15-000053:notes:48]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-15-000053:notes:49]
[same as prior period, unchanged from 0000936395-15-000038:notes:48]

[0000936395-15-000053:notes:50]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the nine months ending July 31, 2015:

[0000936395-15-000053:notes:51]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2014 | $ | 71 |  |  | $ | (173 | ) |  | $ | (2,083 | ) |  | $ | (12,483 | ) |  | $ | (14,668 | ) |
| Other comprehensive income (loss) before reclassifications | (37 | ) |  | (5,451 | ) |  | (2,885 | ) |  | (6,919 | ) |  | (15,292 | ) |
| Amounts reclassified from AOCI | — |  |  | 3,825 |  |  | — |  |  | — |  |  | 3,825 |  |
| Balance at July 31, 2015 | $ | 34 |  |  | $ | (1,799 | ) |  | $ | (4,968 | ) |  | $ | (19,402 | ) |  | $ | (26,135 | ) |

[0000936395-15-000053:notes:52]
The following table summarizes the changes in accumulated balances of other comprehensive income (loss) for the nine months ending July 31, 2014:

[0000936395-15-000053:notes:53]
|  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Derivative Instruments |  | Translation Adjustment |  | Total |
| Balance at October 31, 2013 | $ | 30 |  |  | $ | (261 | ) |  | $ | (7,543 | ) |  | $ | (7,774 | ) |
| Other comprehensive income (loss) before reclassifications | (12 | ) |  | (862 | ) |  | (4,287 | ) |  | (5,161 | ) |
| Amounts reclassified from AOCI | — |  |  | 896 |  |  | — |  |  | 896 |  |
| Balance at July 31, 2014 | $ | 18 |  |  | $ | (227 | ) |  | $ | (11,830 | ) |  | $ | (12,039 | ) |

[0000936395-15-000053:notes:54]
[same as prior period, unchanged from 0000936395-15-000038:notes:53]


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-15-000053:notes:55]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-15-000053:notes:56]
[same as prior period, unchanged from 0000936395-15-000038:notes:55]

[0000936395-15-000053:notes:57]
|  | October 31, 2014 |  | July 31, 2015 |
| Products | $ | 50,457 |  |  | $ | 56,355 |  |
| Services | 95,161 |  |  | 112,278 |  |
|  | 145,618 |  |  | 168,633 |  |
| Less current portion | (104,688 | ) |  | (114,902 | ) |
| Long-term deferred revenue | $ | 40,930 |  |  | $ | 53,731 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-15-000053:notes:58]
[same as prior period, unchanged from 0000936395-15-000038:notes:57]

[0000936395-15-000053:notes:59]
[same as prior period, unchanged from 0000936395-15-000038:notes:58]

[0000936395-15-000053:notes:60]
As of July 31, 2015 and October 31, 2014, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $31.8 million and $51.5 million as of July 31, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 15 months or less and have been designated as cash flow hedges.

[0000936395-15-000053:notes:61]
During the first nine months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell Brazilian Real and buy an equivalent U.S. Dollar amount. During the first nine months of fiscal 2015 and fiscal 2014, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to sell U.S. Dollars and buy an equivalent amount of Canadian Dollars. The notional amount of these contracts was approximately $182.6 million and $194.5 million as of July 31, 2015 and October 31, 2014, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-15-000053:notes:62]
[same as prior period, unchanged from 0000936395-15-000038:notes:61]

[0000936395-15-000053:notes:63]
During fiscal 2014, Ciena entered into interest rate cap arrangements to limit interest paid under the Term Loan to a maximum of 0.75% plus a spread of 300 basis points through July 2015. The total notional amount of interest rate caps outstanding as of October 31, 2014 was $249.4 million. The interest rate caps expired in July 2015. Also in fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swap") that fix the interest rate under the Term Loan at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of July 31, 2015 and October 31, 2014 was $247.5 million.

[0000936395-15-000053:notes:64]
Ciena expects the variable rate payments to be received under the terms of the interest rate swap to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the Term Loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-15-000053:notes:65]
[same as prior period, unchanged from 0000936395-15-000038:notes:64]


## us-gaap:DerivativesPolicyTextBlock

[0000936395-15-000053:notes:66]
Ciena's 4.0% convertible senior notes due March 15, 2015 (the "2015 Notes") matured during the second quarter of fiscal 2015. The 2015 Notes included a redemption feature accounted for as a separate embedded derivative which expired when the 2015 notes matured. Until maturity of the 2015 Notes, the embedded redemption feature was recorded at fair value on a recurring basis, and these changes were included in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

[0000936395-15-000053:notes:67]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. dollar denominated cash flows. Generally, these derivatives have maturities of 15 months or less. During fiscal 2014, Ciena also entered into interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its Term Loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-15-000053:notes:68]
[same as prior period, unchanged from 0000936395-15-000038:notes:67]

[0000936395-15-000053:notes:69]
[same as prior period, unchanged from 0000936395-15-000038:notes:68]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-15-000053:notes:70]
[same as prior period, unchanged from 0000936395-15-000038:notes:69]

[0000936395-15-000053:notes:71]
[same as prior period, unchanged from 0000936395-15-000038:notes:70]

[0000936395-15-000053:notes:72]
[same as prior period, unchanged from 0000936395-15-000038:notes:71]

[0000936395-15-000053:notes:73]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of July 31, 2015, approximately 6.1 million shares remained available for issuance under the 2008 Plan.

[0000936395-15-000053:notes:74]
[same as prior period, unchanged from 0000936395-15-000038:notes:73]

[0000936395-15-000053:notes:75]
Outstanding stock option awards to employees are generally subject to service-based vesting conditions and vest incrementally over a four-year period. As of July 31, 2015, all outstanding options have completed their service-based vesting conditions and are fully vested. The following table is a summary of Ciena’s stock option activity for the period indicated (shares in thousands):

[0000936395-15-000053:notes:76]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2014 | 1,288 |  |  | $ | 25.43 |  |
| Exercised | (255 | ) |  | 15.27 |  |
| Canceled | (104 | ) |  | 25.66 |  |
| Balance at July 31, 2015 | 929 |  |  | $ | 28.19 |  |

[0000936395-15-000053:notes:77]
The total intrinsic value of options exercised during the first nine months of fiscal 2014 and fiscal 2015 was $1.0 million and $1.8 million, respectively. Ciena did not grant any stock options during the first nine months of fiscal 2014 or fiscal 2015.

[0000936395-15-000053:notes:78]
The following table summarizes information with respect to stock options outstanding at July 31, 2015, based on Ciena’s closing stock price on the last trading day of Ciena’s third fiscal quarter of 2015 (shares and intrinsic value in thousands):

[0000936395-15-000053:notes:79]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | July 31, 2015 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.94 |  |  | — |  |  | $ | 16.31 |  |  | 93 |  |  | 2.99 |  | $ | 6.96 |  |  | $ | 1,713 |  |
| $ | 16.52 |  |  | — |  |  | $ | 17.29 |  |  | 47 |  |  | 0.62 |  | 16.61 |  |  | 419 |  |
| $ | 17.43 |  |  | — |  |  | $ | 24.50 |  |  | 81 |  |  | 1.15 |  | 19.07 |  |  | 520 |  |
| $ | 24.69 |  |  | — |  |  | $ | 28.28 |  |  | 267 |  |  | 1.63 |  | 27.38 |  |  | 15 |  |
| $ | 28.61 |  |  | — |  |  | $ | 32.55 |  |  | 97 |  |  | 2.07 |  | 29.99 |  |  | — |  |
| $ | 33.00 |  |  | — |  |  | $ | 37.10 |  |  | 244 |  |  | 2.31 |  | 35.25 |  |  | — |  |
| $ | 37.31 |  |  | — |  |  | $ | 47.32 |  |  | 100 |  |  | 1.96 |  | 44.07 |  |  | — |  |
| $ | 0.94 |  |  | — |  |  | $ | 47.32 |  |  | 929 |  |  | 1.93 |  | $ | 28.19 |  |  | $ | 2,667 |  |

[0000936395-15-000053:notes:80]
[same as prior period, unchanged from 0000936395-15-000038:notes:79]

[0000936395-15-000053:notes:81]
[same as prior period, unchanged from 0000936395-15-000038:notes:80]

[0000936395-15-000053:notes:82]
[same as prior period, unchanged from 0000936395-15-000038:notes:81]

[0000936395-15-000053:notes:83]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena's outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. Awards with performance-based vesting conditions require the achievement of certain operational, financial or other performance criteria or targets as a condition of vesting, or the acceleration of vesting, of such awards. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-15-000053:notes:84]
[same as prior period, unchanged from 0000936395-15-000038:notes:83]

[0000936395-15-000053:notes:85]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2014 | 4,012 |  |  | $ | 18.02 |  |  | $ | 67,241 |  |
| Granted | 2,509 |  |  |  |  |  |
| Vested | (1,572 | ) |  |  |  |  |
| Canceled or forfeited | (219 | ) |  |  |  |  |
| Balance at July 31, 2015 | 4,730 |  |  | $ | 18.88 |  |  | $ | 120,374 |  |

[0000936395-15-000053:notes:86]
The total fair value of restricted stock units that vested and were converted into common stock during the first nine months of fiscal 2014 and fiscal 2015 was $40.4 million and $33.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first nine months of fiscal 2014 and fiscal 2015 was $21.96 and $19.15 respectively.

[0000936395-15-000053:notes:87]
[same as prior period, unchanged from 0000936395-15-000038:notes:86]

[0000936395-15-000053:notes:88]
[same as prior period, unchanged from 0000936395-15-000038:notes:87]

[0000936395-15-000053:notes:89]
[same as prior period, unchanged from 0000936395-15-000038:notes:88]

[0000936395-15-000053:notes:90]
[same as prior period, unchanged from 0000936395-15-000038:notes:89]

[0000936395-15-000053:notes:91]
[same as prior period, unchanged from 0000936395-15-000038:notes:90]

[0000936395-15-000053:notes:92]
[same as prior period, unchanged from 0000936395-15-000038:notes:91]

[0000936395-15-000053:notes:93]
During the first nine months of fiscal 2015, Ciena issued 1.0 million shares under the ESPP. At July 31, 2015, 6.4 million shares remained available for issuance under the ESPP.

[0000936395-15-000053:notes:94]
[same as prior period, unchanged from 0000936395-15-000038:notes:93]

[0000936395-15-000053:notes:95]
[same as prior period, unchanged from 0000936395-15-000038:notes:94]

[0000936395-15-000053:notes:96]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Product costs | $ | 737 |  |  | $ | 671 |  |  | $ | 1,984 |  |  | $ | 1,811 |  |
| Service costs | 572 |  |  | 490 |  |  | 1,720 |  |  | 1,583 |  |
| Share-based compensation expense included in cost of sales | 1,309 |  |  | 1,161 |  |  | 3,704 |  |  | 3,394 |  |
| Research and development | 2,368 |  |  | 2,114 |  |  | 7,722 |  |  | 6,815 |  |
| Sales and marketing | 3,890 |  |  | 3,571 |  |  | 12,199 |  |  | 11,071 |  |
| General and administrative | 3,376 |  |  | 3,516 |  |  | 10,543 |  |  | 11,158 |  |
| Share-based compensation expense included in operating expense | 9,634 |  |  | 9,201 |  |  | 30,464 |  |  | 29,044 |  |
| Share-based compensation expense capitalized in inventory, net | (182 | ) |  | (96 | ) |  | 36 |  |  | (36 | ) |
| Total share-based compensation | $ | 10,761 |  |  | $ | 10,266 |  |  | $ | 34,204 |  |  | $ | 32,402 |  |

[0000936395-15-000053:notes:97]
As of July 31, 2015, total unrecognized share-based compensation expense related to unvested restricted stock units was approximately $72.8 million, and this expense is expected to be recognized over a weighted-average period of 1.5 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-15-000053:notes:98]
[same as prior period, unchanged from 0000936395-15-000038:notes:97]


## us-gaap:EarningsPerShareTextBlock

[0000936395-15-000053:notes:99]
[same as prior period, unchanged from 0000936395-15-000038:notes:98]

[0000936395-15-000053:notes:100]
[same as prior period, unchanged from 0000936395-15-000038:notes:99]

[0000936395-15-000053:notes:101]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Numerator | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Net income (loss) | $ | 16,160 |  |  | $ | 23,625 |  |  | $ | (9,934 | ) |  | $ | 25,499 |  |
| Add: Interest expense associated with 0.875% convertible senior notes due 2017 | 1,384 |  |  | 1,384 |  |  | $ | — |  |  | — |  |
| Net income (loss) used to calculate Diluted EPS | $ | 17,544 |  |  | $ | 25,009 |  |  | $ | (9,934 | ) |  | $ | 25,499 |  |

[0000936395-15-000053:notes:102]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| Denominator | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Basic weighted average shares outstanding | 106,236 |  |  | 118,413 |  |  | 105,404 |  |  | 113,189 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | 1,465 |  |  | 1,712 |  |  | — |  |  | 1,360 |  |
| Add: Shares underlying 0.875% convertible senior notes due 2017 | 13,108 |  |  | 13,108 |  |  | — |  |  | — |  |
| Dilutive weighted average shares outstanding | 120,809 |  |  | 133,233 |  |  | 105,404 |  |  | 114,549 |  |

[0000936395-15-000053:notes:103]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
| EPS | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Basic EPS | $ | 0.15 |  |  | $ | 0.20 |  |  | $ | (0.09 | ) |  | $ | 0.23 |  |
| Diluted EPS | $ | 0.15 |  |  | $ | 0.19 |  |  | $ | (0.09 | ) |  | $ | 0.22 |  |

[0000936395-15-000053:notes:104]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the periods indicated (in thousands):

[0000936395-15-000053:notes:105]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Shares underlying stock options and restricted stock units | 1,123 |  |  | 755 |  |  | 3,205 |  |  | 1,534 |  |
| 4.0% Convertible Senior Notes due March 15, 2015 | 9,198 |  |  | — |  |  | 9,198 |  |  | 4,515 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | — |  |  | — |  |  | 13,108 |  |  | 13,108 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,356 |  |  | 17,356 |  |  | 17,356 |  |  | 17,356 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |  | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 36,875 |  |  | 27,309 |  |  | 52,065 |  |  | 45,711 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-15-000053:notes:106]
[same as prior period, unchanged from 0000936395-15-000038:notes:105]

[0000936395-15-000053:notes:107]
|  | July 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 538,895 |  |  | $ | — |  |  | $ | — |  |  | $ | 538,895 |  |
| U.S. government obligations | — |  |  | 175,246 |  |  | — |  |  | 175,246 |  |
| Commercial paper | — |  |  | 99,980 |  |  | — |  |  | 99,980 |  |
| Foreign currency forward contracts | — |  |  | 5,837 |  |  | — |  |  | 5,837 |  |
| Total assets measured at fair value | $ | 538,895 |  |  | $ | 281,063 |  |  | $ | — |  |  | $ | 819,958 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,941 |  |  | $ | — |  |  | $ | 1,941 |  |
| Forward starting interest rate swap | — |  |  | 4,968 |  |  | — |  |  | 4,968 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,909 |  |  | $ | — |  |  | $ | 6,909 |  |

[0000936395-15-000053:notes:108]
[same as prior period, unchanged from 0000936395-15-000038:notes:107]


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-15-000053:notes:109]
As of the date indicated, the assets and liabilities above are presented on Ciena’s Condensed Consolidated Balance Sheet as follows (in thousands):

[0000936395-15-000053:notes:110]
|  | July 31, 2015 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 538,895 |  |  | $ | 44,998 |  |  | $ | — |  |  | $ | 583,893 |  |
| Short-term investments | — |  |  | 160,067 |  |  | — |  |  | 160,067 |  |
| Prepaid expenses and other | — |  |  | 5,837 |  |  | — |  |  | 5,837 |  |
| Long-term investments | — |  |  | 70,161 |  |  | — |  |  | 70,161 |  |
| Total assets measured at fair value | $ | 538,895 |  |  | $ | 281,063 |  |  | $ | — |  |  | $ | 819,958 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,941 |  |  | $ | — |  |  | $ | 1,941 |  |
| Other long-term obligations | — |  |  | 4,968 |  |  | — |  |  | 4,968 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 6,909 |  |  | $ | — |  |  | $ | 6,909 |  |

[0000936395-15-000053:notes:111]
[same as prior period, unchanged from 0000936395-15-000038:notes:110]


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-15-000053:notes:112]
[same as prior period, unchanged from 0000936395-15-000038:notes:111]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-15-000053:notes:113]
[same as prior period, unchanged from 0000936395-15-000038:notes:112]


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-15-000053:notes:114]
[same as prior period, unchanged from 0000936395-15-000038:notes:113]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-15-000053:notes:115]
[same as prior period, unchanged from 0000936395-15-000038:notes:114]

[0000936395-15-000053:notes:116]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2008 through 2013 and in Canada for 2010 through 2012. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2012), United Kingdom (2012), Canada (2010) and India (2008). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-15-000053:notes:117]
[same as prior period, unchanged from 0000936395-15-000038:notes:116]

[0000936395-15-000053:notes:118]
[same as prior period, unchanged from 0000936395-15-000038:notes:117]


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-15-000053:notes:119]
[same as prior period, unchanged from 0000936395-15-000038:notes:118]

[0000936395-15-000053:notes:120]
[same as prior period, unchanged from 0000936395-15-000038:notes:119]

[0000936395-15-000053:notes:121]
|  | October 31, 2014 |  | July 31, 2015 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 417,833 |  |  | $ | (351,929 | ) |  | $ | 65,904 |  |  | $ | 417,833 |  |  | $ | (372,178 | ) |  | $ | 45,655 |  |
| Patents and licenses | 46,538 |  |  | (45,908 | ) |  | 630 |  |  | 46,538 |  |  | (46,031 | ) |  | 507 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 323,573 |  |  | (261,430 | ) |  | 62,143 |  |  | 323,573 |  |  | (280,716 | ) |  | 42,857 |  |
| Total other intangible assets | $ | 787,944 |  |  | $ | (659,267 | ) |  | $ | 128,677 |  |  | $ | 787,944 |  |  | $ | (698,925 | ) |  | $ | 89,019 |  |

[0000936395-15-000053:notes:122]
The amortization of finite-lived other intangible assets was $43.9 million and $39.7 million for the first nine months of fiscal 2014 and 2015, respectively. Expected future amortization of finite-lived other intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-15-000053:notes:123]
| Period ended October 31, |  |
| 2015 (remaining three months) | $ | 13,220 |  |
| 2016 | 52,879 |  |
| 2017 | 22,783 |  |
| 2018 | 137 |  |
|  | $ | 89,019 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-15-000053:notes:124]
[same as prior period, unchanged from 0000936395-15-000038:notes:123]

[0000936395-15-000053:notes:125]
[same as prior period, unchanged from 0000936395-15-000038:notes:124]

[0000936395-15-000053:notes:126]
|  | October 31, 2014 |  | July 31, 2015 |
| Raw materials | $ | 64,853 |  |  | $ | 54,112 |  |
| Work-in-process | 8,371 |  |  | 8,924 |  |
| Finished goods | 165,799 |  |  | 119,635 |  |
| Deferred cost of goods sold | 75,763 |  |  | 59,606 |  |
|  | 314,786 |  |  | 242,277 |  |
| Provision for excess and obsolescence | (60,126 | ) |  | (48,260 | ) |
|  | $ | 254,660 |  |  | $ | 194,017 |  |

[0000936395-15-000053:notes:127]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first nine months of fiscal 2015, Ciena recorded a provision for excess and obsolescence of $18.0 million, primarily related to the discontinuance of certain parts and components used in the manufacture of its Converged Packet Optical products and a decrease in the forecasted demand for both its legacy, stand-alone WDM and SONET/SDH-based transport platforms and its 5410 Service Aggregation Switch. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-15-000053:notes:128]
[same as prior period, unchanged from 0000936395-15-000038:notes:127]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-15-000053:notes:129]
[same as prior period, unchanged from 0000936395-15-000038:notes:128]

[0000936395-15-000053:notes:130]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2015, the carrying value of this investment was $2.0 million. With respect to this investment, Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-15-000053:notes:131]
The following table summarizes the final legal maturities of debt investments at July 31, 2015 (in thousands):

[0000936395-15-000053:notes:132]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 160,023 |  |  | $ | 160,067 |  |
| Due in 1-2 years | 70,149 |  |  | 70,161 |  |
|  | $ | 230,172 |  |  | $ | 230,228 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-15-000053:notes:133]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-15-000053:notes:134]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-15-000053:notes:135]
|  | July 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 105,041 |  |  | $ | 44 |  |  | — |  |  | $ | 105,085 |  |
| Included in long-term investments | 70,149 |  |  | 12 |  |  | — |  |  | 70,161 |  |
|  | $ | 175,190 |  |  | $ | 56 |  |  | $ | — |  |  | $ | 175,246 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 54,982 |  |  | — |  |  | — |  |  | 54,982 |  |
|  | $ | 54,982 |  |  | $ | — |  |  | $ | — |  |  | $ | 54,982 |  |

[0000936395-15-000053:notes:136]
|  | October 31, 2014 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,182 |  |  | $ | 29 |  |  | $ | — |  |  | $ | 110,211 |  |
| Included in long-term investments | 50,016 |  |  | 41 |  |  | — |  |  | 50,057 |  |
|  | $ | 160,198 |  |  | $ | 70 |  |  | $ | — |  |  | $ | 160,268 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | 29,994 |  |  | — |  |  | — |  |  | 29,994 |  |
|  | $ | 29,994 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,994 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-15-000053:notes:137]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-15-000053:notes:138]
[same as prior period, unchanged from 0000936395-15-000038:notes:137]

[0000936395-15-000053:notes:139]
As of October 31, 2014 and July 31, 2015, there were no individual customers that accounted for greater than 10% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. Allowance for doubtful accounts was $2.1 million and $2.3 million as of October 31, 2014 and July 31, 2015, respectively.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-15-000053:notes:140]
In May 2014, the FASB issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts.  In August 2015, the FASB issued an amendment to defer the effective date by one year and allow entities to early adopt no earlier than the original effective date. Based on this amendment, the standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-15-000053:notes:141]
In August 2014, the FASB issued ASU No. 2014-15, Disclosure of Uncertainties about an Entity's Ability to Continue as a Going Concern. ASU 2014-15 requires management to evaluate and provide related disclosures, at each annual or interim reporting period, whether there are conditions or events that exist that raise substantial doubt about an entity's ability to continue as a going concern within one year after the date the financial statements are issued. The standard will be effective for Ciena beginning in the first quarter of fiscal 2018. The adoption of this accounting standard update is not expected to have a material effect on Ciena's Consolidated Financial Statements and disclosures.

[0000936395-15-000053:notes:142]
In April 2015, the FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Early adoption is permitted for financial statements that have not been previously issued. Ciena does not expect the impact of adopting this guidance will be material to the its consolidated financial statements and related disclosures.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-15-000053:notes:143]
[same as prior period, unchanged from 0000936395-15-000038:notes:142]

[0000936395-15-000053:notes:144]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2014 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2014.

[0000936395-15-000053:notes:145]
[same as prior period, unchanged from 0000936395-15-000038:notes:144]


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-15-000053:notes:146]
[same as prior period, unchanged from 0000936395-15-000038:notes:145]

[0000936395-15-000053:notes:147]
|  | October 31, 2014 |  | July 31, 2015 |
| Income tax liability | $ | 14,342 |  |  | $ | 13,810 |  |
| Deferred tenant allowance | 10,839 |  |  | 10,057 |  |
| Straight-line rent | 5,174 |  |  | 5,801 |  |
| Capital lease obligations | 4,589 |  |  | 13,977 |  |
| Construction liability | — |  |  | 8,770 |  |
| Forward starting interest rate swap | 2,083 |  |  | 4,968 |  |
| Other | 8,363 |  |  | 6,099 |  |
|  | $ | 45,390 |  |  | $ | 63,482 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-15-000053:notes:148]
[same as prior period, unchanged from 0000936395-15-000038:notes:147]

[0000936395-15-000053:notes:149]
The components of interest and other income (loss), net, are as follows (in thousands):

[0000936395-15-000053:notes:150]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Interest income | $ | 88 |  |  | $ | 323 |  |  | $ | 235 |  |  | $ | 788 |  |
| Change in fair value of embedded derivative | (190 | ) |  | — |  |  | (2,740 | ) |  | — |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts | (1,484 | ) |  | 4,924 |  |  | (11,677 | ) |  | 14,925 |  |
| Foreign currency exchange gain (loss) | (4,341 | ) |  | (10,424 | ) |  | 993 |  |  | (32,910 | ) |
| Other | (401 | ) |  | (314 | ) |  | (1,042 | ) |  | (2,076 | ) |
| Interest and other income (loss), net | $ | (6,328 | ) |  | $ | (5,491 | ) |  | $ | (14,231 | ) |  | $ | (19,273 | ) |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-15-000053:notes:151]
[same as prior period, unchanged from 0000936395-15-000038:notes:150]

[0000936395-15-000053:notes:152]
[same as prior period, unchanged from 0000936395-15-000038:notes:151]

[0000936395-15-000053:notes:153]
|  | October 31, 2014 |  | July 31, 2015 |
| Equipment, furniture and fixtures | $ | 383,059 |  |  | $ | 382,850 |  |
| Building subject to capital lease | — |  |  | 13,939 |  |
| Construction in progress subject to build-to-suit lease | — |  |  | 8,770 |  |
| Leasehold improvements | 46,354 |  |  | 47,020 |  |
|  | 429,413 |  |  | 452,579 |  |
| Accumulated depreciation and amortization | (302,781 | ) |  | (292,987 | ) |
|  | $ | 126,632 |  |  | $ | 159,592 |  |

[0000936395-15-000053:notes:154]
[same as prior period, unchanged from 0000936395-15-000038:notes:153]

[0000936395-15-000053:notes:155]
Ciena capitalizes construction in progress and record a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of July 31, 2015, there were $8.8 million in costs incurred under this build-to-suit lease arrangement. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful life or the lease term.

[0000936395-15-000053:notes:156]
The total of depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $34.8 million and $34.3 million for the first nine months of fiscal 2014 and 2015, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-15-000053:notes:157]
Equipment, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During the second quarter of fiscal 2015, Ciena gained partial access to an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The lease building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 10 below.

[0000936395-15-000053:notes:158]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease.


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-15-000053:notes:159]
[same as prior period, unchanged from 0000936395-15-000038:notes:157]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-15-000053:notes:160]
[same as prior period, unchanged from 0000936395-15-000038:notes:158]

[0000936395-15-000053:notes:161]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Segment profit: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 104,020 |  |  | $ | 118,223 |  |  | $ | 279,299 |  |  | $ | 322,652 |  |
| Packet Networking | 14,566 |  |  | 7,628 |  |  | 23,147 |  |  | 18,910 |  |
| Optical Transport | 8,900 |  |  | 2,813 |  |  | 29,259 |  |  | 13,428 |  |
| Software and Services | 38,802 |  |  | 40,826 |  |  | 93,136 |  |  | 111,243 |  |
| Total segment profit | 166,288 |  |  | 169,490 |  |  | 424,841 |  |  | 466,233 |  |
| Less: Non-performance operating expenses |  |  |  |  |  |  |  |
| Selling and marketing | 81,919 |  |  | 81,650 |  |  | 243,929 |  |  | 240,833 |  |
| General and administrative | 36,285 |  |  | 29,743 |  |  | 98,264 |  |  | 89,598 |  |
| Acquisition and integration costs | — |  |  | 2,435 |  |  | — |  |  | 3,455 |  |
| Amortization of intangible assets | 11,019 |  |  | 11,019 |  |  | 34,951 |  |  | 33,057 |  |
| Restructuring costs | 63 |  |  | 192 |  |  | 178 |  |  | 8,260 |  |
| Add: Other non-performance financial items |  |  |  |  |  |  |  |
| Interest expense and other income (loss), net | (17,836 | ) |  | (17,374 | ) |  | (47,787 | ) |  | (57,764 | ) |
| Less: Provision for income taxes | 3,006 |  |  | 3,452 |  |  | 9,666 |  |  | 7,767 |  |
| Consolidated net income (loss) | $ | 16,160 |  |  | $ | 23,625 |  |  | $ | (9,934 | ) |  | $ | 25,499 |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-15-000053:notes:162]
[same as prior period, unchanged from 0000936395-15-000038:notes:160]

[0000936395-15-000053:notes:163]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 382,031 |  |  | $ | 407,970 |  |  | $ | 1,072,272 |  |  | $ | 1,177,441 |  |
| Packet Networking | 69,464 |  |  | 57,209 |  |  | 187,699 |  |  | 165,480 |  |
| Optical Transport | 31,016 |  |  | 17,482 |  |  | 100,729 |  |  | 56,275 |  |
| Software and Services | 121,051 |  |  | 120,271 |  |  | 336,626 |  |  | 354,500 |  |
| Consolidated revenue | $ | 603,562 |  |  | $ | 602,932 |  |  | $ | 1,697,326 |  |  | $ | 1,753,696 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-15-000053:notes:164]
[same as prior period, unchanged from 0000936395-15-000038:notes:162]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-15-000053:notes:165]
[same as prior period, unchanged from 0000936395-15-000038:notes:163]

[0000936395-15-000053:notes:166]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2015 (in thousands):

[0000936395-15-000053:notes:167]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2014 | $ | 181 |  |  | $ | 1,134 |  |  | $ | 1,315 |  |
| Additional liability recorded | 8,260 |  | (a) | — |  |  | 8,260 |  |
| Cash payments | (7,748 | ) |  | (370 | ) |  | (8,118 | ) |
| Balance at July 31, 2015 | $ | 693 |  |  | $ | 764 |  |  | $ | 1,457 |  |
| Current restructuring liabilities | $ | 693 |  |  | $ | 396 |  |  | $ | 1,089 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 368 |  |  | $ | 368 |  |

[0000936395-15-000053:notes:168]
[same as prior period, unchanged from 0000936395-15-000038:notes:166]

[0000936395-15-000053:notes:169]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the nine months ended July 31, 2014 (in thousands):

[0000936395-15-000053:notes:170]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2013 | $ | 80 |  |  | $ | 1,936 |  |  | $ | 2,016 |  |
| Additional liability recorded | 169 |  |  | 9 |  |  | 178 |  |
| Cash payments | (208 | ) |  | (269 | ) |  | (477 | ) |
| Balance at July 31, 2014 | $ | 41 |  |  | $ | 1,676 |  |  | $ | 1,717 |  |
| Current restructuring liabilities | $ | 41 |  |  | $ | 612 |  |  | $ | 653 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 1,064 |  |  | $ | 1,064 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-15-000053:notes:171]
[same as prior period, unchanged from 0000936395-15-000038:notes:169]

[0000936395-15-000053:notes:172]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2014 and July 31, 2015 was 4.3% and 1.9%, respectively.

[0000936395-15-000053:notes:173]
[same as prior period, unchanged from 0000936395-15-000038:notes:171]

[0000936395-15-000053:notes:174]
[same as prior period, unchanged from 0000936395-15-000038:notes:172]

[0000936395-15-000053:notes:175]
[same as prior period, unchanged from 0000936395-15-000038:notes:173]

[0000936395-15-000053:notes:176]
[same as prior period, unchanged from 0000936395-15-000038:notes:174]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-15-000053:notes:177]
[same as prior period, unchanged from 0000936395-15-000038:notes:175]

[0000936395-15-000053:notes:178]
|  | October 31, 2014 |  | July 31, 2015 |
| Compensation, payroll related tax and benefits | 82,207 |  |  | 79,794 |  |
| Warranty | 55,997 |  |  | 53,834 |  |
| Vacation | 35,126 |  |  | 31,990 |  |
| Capital lease obligations | 7,788 |  |  | 6,319 |  |
| Interest payable | 6,409 |  |  | 5,817 |  |
| Other | 89,081 |  |  | 94,937 |  |
|  | $ | 276,608 |  |  | $ | 272,691 |  |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock

[0000936395-15-000053:notes:179]
The principal balance, unamortized discount and net carrying amount of the Term Loan were as follows as of July 31, 2015 (in thousands):


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-15-000053:notes:180]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of July 31, 2015 (in thousands):

[0000936395-15-000053:notes:181]
| Period ended October 31, |  |
| 2015 (remaining three months) | $ | 1,934 |  |
| 2016 | 6,055 |  |
| 2017 | 1,628 |  |
| 2018 | 1,290 |  |
| 2019 | 1,290 |  |
| Thereafter | 19,808 |  |
| Net minimum capital lease payments | 32,005 |  |
| Less: Amount representing interest | (11,709 | ) |
| Present value of minimum lease payments | 20,296 |  |
| Less: Current portion of present value of minimum lease payments | (6,319 | ) |
| Long-term portion of present value of minimum lease payments | $ | 13,977 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-15-000053:notes:182]
[same as prior period, unchanged from 0000936395-15-000038:notes:180]

[0000936395-15-000053:notes:183]
|  | October 31, 2014 |  | July 31, 2015 |
| Maintenance spares, net | $ | 54,101 |  |  | $ | 58,959 |  |
| Deferred debt issuance costs, net | 15,160 |  |  | 11,889 |  |
| Other | 4,815 |  |  | 7,499 |  |
|  | $ | 74,076 |  |  | $ | 78,347 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-15-000053:notes:184]
[same as prior period, unchanged from 0000936395-15-000038:notes:182]

[0000936395-15-000053:notes:185]
| Nine months ended | Beginning |  |  |  |  |  | Ending |
| July 31, | Balance |  | Provisions |  | Settlements |  | Balance |
| 2014 | $ | 56,303 |  |  | 18,720 |  |  | (17,581 | ) |  | $ | 57,442 |  |
| 2015 | $ | 55,997 |  |  | 12,549 |  |  | (14,712 | ) |  | $ | 53,834 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-15-000053:notes:186]
[same as prior period, unchanged from 0000936395-15-000038:notes:185]

[0000936395-15-000053:notes:187]
|  | Quarter Ended July 31, |  | Nine Months Ended July 31, |
|  | 2014 |  | 2015 |  | 2014 |  | 2015 |
| North America | $ | 403,250 |  |  | $ | 389,593 |  |  | $ | 1,136,867 |  |  | $ | 1,118,309 |  |
| EMEA | 99,909 |  |  | 93,168 |  |  | 283,743 |  |  | 306,368 |  |
| CALA | 67,248 |  |  | 65,152 |  |  | 160,162 |  |  | 155,785 |  |
| APAC | 33,155 |  |  | 55,019 |  |  | 116,554 |  |  | 173,234 |  |
| Total | $ | 603,562 |  |  | $ | 602,932 |  |  | $ | 1,697,326 |  |  | $ | 1,753,696 |  |

[0000936395-15-000053:notes:188]
For the periods below, Ciena's geographic distribution of equipment, building, furniture and fixtures was as follows (in thousands):

[0000936395-15-000053:notes:189]
|  | October 31, 2014 |  | July 31, 2015 |
| United States | $ | 73,420 |  |  | $ | 79,560 |  |
| Canada | 42,015 |  |  | 69,045 |  |
| Other International | 11,197 |  |  | 10,987 |  |
| Total | $ | 126,632 |  |  | $ | 159,592 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-15-000053:notes:190]
[same as prior period, unchanged from 0000936395-15-000038:notes:187]

[0000936395-15-000053:notes:191]
[same as prior period, unchanged from 0000936395-15-000038:notes:188]

[0000936395-15-000053:notes:192]
[same as prior period, unchanged from 0000936395-15-000038:notes:189]

[0000936395-15-000053:notes:193]
| • | Converged Packet Optical — includes the 6500 Packet-Optical Platform and the 5430 Reconfigurable Switching System, which feature Ciena's WaveLogic coherent optical processors. Products also include Ciena's family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This segment also includes sales of operating system software and enhanced software features embedded in each of these products. Revenue from this segment is included in product revenue on the Condensed Consolidated Statement of Operations. In May 2015, Ciena launched its new Waveserver™ product. Revenue from sales of Waveserver are included in our Converged Packet Optical segment. |

[0000936395-15-000053:notes:194]
[same as prior period, unchanged from 0000936395-15-000038:notes:191]

[0000936395-15-000053:notes:195]
[same as prior period, unchanged from 0000936395-15-000038:notes:192]

[0000936395-15-000053:notes:196]
[same as prior period, unchanged from 0000936395-15-000038:notes:193]

[0000936395-15-000053:notes:197]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of July 31, 2015, equipment, building, furniture and fixtures totaling $159.6 million primarily support asset groups within Ciena's Converged Packet Optical, Packet Networking, and Software and Services segments and support Ciena's unallocated selling and general and administrative activities. As of July 31, 2015, all of Ciena's finite-lived intangible assets, totaling $89.0 million, were assigned to asset groups within Ciena's Converged Packet Optical segment. As of July 31, 2015, all of the maintenance spares, totaling $59.0 million, were assigned to asset groups within Ciena's Software and Services segment.

[0000936395-15-000053:notes:198]
[same as prior period, unchanged from 0000936395-15-000038:notes:195]

[0000936395-15-000053:notes:199]
[same as prior period, unchanged from 0000936395-15-000038:notes:196]

[0000936395-15-000053:notes:200]
[same as prior period, unchanged from 0000936395-15-000038:notes:197]

[0000936395-15-000053:notes:201]
[same as prior period, unchanged from 0000936395-15-000038:notes:198]

[0000936395-15-000053:notes:202]
[same as prior period, unchanged from 0000936395-15-000038:notes:199]

[0000936395-15-000053:notes:203]
North America includes $368.1 million and $360.7 million of United States revenue for fiscal quarters ended July 31, 2014 and 2015, respectively. For the nine months ended July 31, 2014 and 2015, United States revenue was $1,009.4 million and $1,026.0 million, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-15-000053:notes:204]
[same as prior period, unchanged from 0000936395-15-000038:notes:201]

[0000936395-15-000053:notes:205]
AT&T accounted for greater than 10% of Ciena's revenue in Ciena's fiscal quarters ended July 31, 2014 and 2015 with  total revenue of $130.3 million and $121.6 million, respectively. AT&T also accounted for greater than 10% of Ciena's revenue for the nine months ended July 31, 2014 and 2015 with total revenue of $351.3 million and $355.6 million, respectively. AT&T purchases products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-15-000053:notes:206]
[same as prior period, unchanged from 0000936395-15-000038:notes:203]


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-15-000053:notes:207]
[same as prior period, unchanged from 0000936395-15-000038:notes:204]

[0000936395-15-000053:notes:208]
[same as prior period, unchanged from 0000936395-15-000038:notes:205]

[0000936395-15-000053:notes:209]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-15-000053:notes:210]
[same as prior period, unchanged from 0000936395-15-000038:notes:207]

[0000936395-15-000053:notes:211]
[same as prior period, unchanged from 0000936395-15-000038:notes:208]

[0000936395-15-000053:notes:212]
[same as prior period, unchanged from 0000936395-15-000038:notes:209]

[0000936395-15-000053:notes:213]
[same as prior period, unchanged from 0000936395-15-000038:notes:210]

[0000936395-15-000053:notes:214]
[same as prior period, unchanged from 0000936395-15-000038:notes:211]

[0000936395-15-000053:notes:215]
[same as prior period, unchanged from 0000936395-15-000038:notes:212]

[0000936395-15-000053:notes:216]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 12 below.

[0000936395-15-000053:notes:217]
[same as prior period, unchanged from 0000936395-15-000038:notes:213]

[0000936395-15-000053:notes:218]
[same as prior period, unchanged from 0000936395-15-000038:notes:214]

[0000936395-15-000053:notes:219]
[same as prior period, unchanged from 0000936395-15-000038:notes:215]

[0000936395-15-000053:notes:220]
[same as prior period, unchanged from 0000936395-15-000038:notes:216]

[0000936395-15-000053:notes:221]
[same as prior period, unchanged from 0000936395-15-000038:notes:217]

[0000936395-15-000053:notes:222]
[same as prior period, unchanged from 0000936395-15-000038:notes:218]

[0000936395-15-000053:notes:223]
[same as prior period, unchanged from 0000936395-15-000038:notes:219]

[0000936395-15-000053:notes:224]
[same as prior period, unchanged from 0000936395-15-000038:notes:220]

[0000936395-15-000053:notes:225]
[same as prior period, unchanged from 0000936395-15-000038:notes:221]

[0000936395-15-000053:notes:226]
[same as prior period, unchanged from 0000936395-15-000038:notes:222]

[0000936395-15-000053:notes:227]
[same as prior period, unchanged from 0000936395-15-000038:notes:223]

[0000936395-15-000053:notes:228]
[same as prior period, unchanged from 0000936395-15-000038:notes:224]

[0000936395-15-000053:notes:229]
[same as prior period, unchanged from 0000936395-15-000038:notes:225]

[0000936395-15-000053:notes:230]
[same as prior period, unchanged from 0000936395-15-000038:notes:226]

[0000936395-15-000053:notes:231]
[same as prior period, unchanged from 0000936395-15-000038:notes:227]

[0000936395-15-000053:notes:232]
[same as prior period, unchanged from 0000936395-15-000038:notes:228]

[0000936395-15-000053:notes:233]
[same as prior period, unchanged from 0000936395-15-000038:notes:229]

[0000936395-15-000053:notes:234]
Loss Contingencies

[0000936395-15-000053:notes:235]
[same as prior period, unchanged from 0000936395-15-000038:notes:231]

[0000936395-15-000053:notes:236]
[same as prior period, unchanged from 0000936395-15-000038:notes:232]

[0000936395-15-000053:notes:237]
[same as prior period, unchanged from 0000936395-15-000038:notes:233]

[0000936395-15-000053:notes:238]
[same as prior period, unchanged from 0000936395-15-000038:notes:234]

[0000936395-15-000053:notes:239]
[same as prior period, unchanged from 0000936395-15-000038:notes:235]

[0000936395-15-000053:notes:240]
[same as prior period, unchanged from 0000936395-15-000038:notes:236]

[0000936395-15-000053:notes:241]
[same as prior period, unchanged from 0000936395-15-000038:notes:237]

[0000936395-15-000053:notes:242]
[same as prior period, unchanged from 0000936395-15-000038:notes:238]

[0000936395-15-000053:notes:243]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-15-000053:notes:244]
[same as prior period, unchanged from 0000936395-15-000038:notes:240]

[0000936395-15-000053:notes:245]
[same as prior period, unchanged from 0000936395-15-000038:notes:241]

[0000936395-15-000053:notes:246]
[same as prior period, unchanged from 0000936395-15-000038:notes:242]

[0000936395-15-000053:notes:247]
[same as prior period, unchanged from 0000936395-15-000038:notes:243]

[0000936395-15-000053:notes:248]
[same as prior period, unchanged from 0000936395-15-000038:notes:244]

[0000936395-15-000053:notes:249]
[same as prior period, unchanged from 0000936395-15-000038:notes:245]

[0000936395-15-000053:notes:250]
[same as prior period, unchanged from 0000936395-15-000038:notes:246]

[0000936395-15-000053:notes:251]
[same as prior period, unchanged from 0000936395-15-000038:notes:247]

[0000936395-15-000053:notes:252]
[same as prior period, unchanged from 0000936395-15-000038:notes:248]


## us-gaap:SubsequentEventsTextBlock

[0000936395-15-000053:notes:253]
SUBSEQUENT EVENTS

[0000936395-15-000053:notes:254]
Acquisition of Cyan, Inc.

[0000936395-15-000053:notes:255]
On August 3, 2015, Ciena acquired Cyan, Inc. (“Cyan”), a leading provider of SDN, NFV and metro packet-optical solutions, in a cash and stock transaction. Subject to the terms and conditions of the merger agreement, at closing each outstanding Cyan share was exchanged for 0.19936 shares of Ciena common stock and $0.63 in cash, resulting in an exchange of all of the outstanding shares of Cyan common stock for approximately $33.6 million in cash and 10.6 million shares of Ciena common stock. Ciena assumed all the then-outstanding Cyan stock options and unvested restricted stock unit awards and substituted for them approximately 1.0 million Ciena restricted stock unit awards and stock options exercisable for approximately 2.4 million shares of Ciena common stock.

[0000936395-15-000053:notes:256]
Upon the closing of the acquisition, Ciena assumed Cyan’s $50.0 million in outstanding principal amount of 8.0% Convertible Senior Secured Notes due 2019 (the "2019 Notes"). Under the terms of the indenture governing the 2019 notes, following the closing of the acquisition, the note holders were given the right to convert the 2019 Notes at an increased conversion rate of approximately 91.79 shares of Ciena common stock and $290.08 in cash for each $1,000 principal amount of 2019 Notes surrendered for conversion. As of September 3, 2015, holders representing all of the outstanding aggregate principal amount of the 2019 Notes had surrendered their 2019 notes for conversion and, accordingly, there are no remaining 2019 Notes outstanding. In satisfaction of such conversions, Ciena issued approximately 4.6 million shares of Ciena common stock and paid $14.5 million in cash.

[0000936395-15-000053:notes:257]
During the first nine months of fiscal 2015, Ciena incurred approximately $3.5 million of acquisition-related costs associated with this transaction. Ciena further expects to incur a number of non-recurring costs associated with the transaction during the remainder of fiscal 2015. These costs and expenses include fees associated with financial, legal and accounting advisors, facilities and systems consolidation costs, and severance and other potential employment-related costs, including payments to certain Cyan executives. Ciena currently expects to incur in total, approximately $25.0 million of such expenses, which includes approximately $7.9 million of non-cash share-based compensation expense. Ciena expects a substantial majority of these acquisition-related costs to be recognized during the fiscal fourth quarter of fiscal 2015.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-15-000053:notes:258]
[same as prior period, unchanged from 0000936395-15-000038:notes:253]

[0000936395-15-000053:notes:259]
Deferred debt issuance costs relate to Ciena's convertible notes payable (described in Note 15 below), Term Loan (described in Note 15 below) and our ABL Credit Facility (described in Note 16 below). Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the related debt. The amortization of deferred debt issuance costs is included in interest expense, and was $3.6 million and $3.6 million during the first nine months of fiscal 2014 and fiscal 2015, respectively.

[0000936395-15-000053:notes:260]
The decrease in the first nine months of fiscal 2015 warranty provision compared to the first nine months of fiscal 2014 was due to lower failure rates and reduced component and labor repair costs.

[0000936395-15-000053:notes:261]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner during the construction period for accounting purposes.
