# CIEN MD&A — 0000936395-17-000020


## mdna

[0000936395-17-000020:mdna:1]
[same as prior period, unchanged from 0000936395-16-000115:mdna:1]

[0000936395-17-000020:mdna:2]
[same as prior period, unchanged from 0000936395-16-000115:mdna:2]

[0000936395-17-000020:mdna:3]
[same as prior period, unchanged from 0000936395-16-000115:mdna:3]

[0000936395-17-000020:mdna:4]
[same as prior period, unchanged from 0000936395-16-000115:mdna:4]

[0000936395-17-000020:mdna:5]
[same as prior period, unchanged from 0000936395-16-000115:mdna:5]

[0000936395-17-000020:mdna:6]
| • | the competitive environment in which we operate; |

[0000936395-17-000020:mdna:7]
[same as prior period, unchanged from 0000936395-16-000115:mdna:7]

[0000936395-17-000020:mdna:8]
[same as prior period, unchanged from 0000936395-16-000115:mdna:8]

[0000936395-17-000020:mdna:9]
[same as prior period, unchanged from 0000936395-16-000115:mdna:9]

[0000936395-17-000020:mdna:10]
| • | our ability to diversify our customer base beyond our traditional customers and broaden the application for our solutions in communications networks; |

[0000936395-17-000020:mdna:11]
[same as prior period, unchanged from 0000936395-16-000115:mdna:11]

[0000936395-17-000020:mdna:12]
[same as prior period, unchanged from 0000936395-16-000115:mdna:12]

[0000936395-17-000020:mdna:13]
[same as prior period, unchanged from 0000936395-16-000115:mdna:13]

[0000936395-17-000020:mdna:14]
| • | the impact of pricing pressure and price erosion that we regularly encounter in our markets; |

[0000936395-17-000020:mdna:15]
[same as prior period, unchanged from 0000936395-16-000115:mdna:14]

[0000936395-17-000020:mdna:16]
[same as prior period, unchanged from 0000936395-16-000115:mdna:15]

[0000936395-17-000020:mdna:17]
[same as prior period, unchanged from 0000936395-16-000115:mdna:16]

[0000936395-17-000020:mdna:18]
[same as prior period, unchanged from 0000936395-16-000115:mdna:17]

[0000936395-17-000020:mdna:19]
[same as prior period, unchanged from 0000936395-16-000115:mdna:18]

[0000936395-17-000020:mdna:20]
| • | our ability to manage effectively our relationships with third party service partners and distributors; |

[0000936395-17-000020:mdna:21]
[same as prior period, unchanged from 0000936395-16-000115:mdna:20]

[0000936395-17-000020:mdna:22]
[same as prior period, unchanged from 0000936395-16-000115:mdna:21]

[0000936395-17-000020:mdna:23]
[same as prior period, unchanged from 0000936395-16-000115:mdna:22]

[0000936395-17-000020:mdna:24]
[same as prior period, unchanged from 0000936395-16-000115:mdna:23]

[0000936395-17-000020:mdna:25]
[same as prior period, unchanged from 0000936395-16-000115:mdna:24]

[0000936395-17-000020:mdna:26]
[same as prior period, unchanged from 0000936395-16-000115:mdna:25]

[0000936395-17-000020:mdna:27]
[same as prior period, unchanged from 0000936395-16-000115:mdna:26]

[0000936395-17-000020:mdna:28]
[same as prior period, unchanged from 0000936395-16-000115:mdna:27]

[0000936395-17-000020:mdna:29]
[same as prior period, unchanged from 0000936395-16-000115:mdna:28]

[0000936395-17-000020:mdna:30]
[same as prior period, unchanged from 0000936395-16-000115:mdna:29]

[0000936395-17-000020:mdna:31]
| • | future legislation or executive action in the U.S. relating to tax policy or trade regulation; |

[0000936395-17-000020:mdna:32]
[same as prior period, unchanged from 0000936395-16-000115:mdna:30]

[0000936395-17-000020:mdna:33]
[same as prior period, unchanged from 0000936395-16-000115:mdna:31]

[0000936395-17-000020:mdna:34]
| • | adverse results in litigation matters. |

[0000936395-17-000020:mdna:35]
34

[0000936395-17-000020:mdna:36]
[same as prior period, unchanged from 0000936395-16-000115:mdna:33]

[0000936395-17-000020:mdna:37]
We are a network strategy and technology company, providing solutions that enable a wide range of network operators to adopt next-generation communication architectures and to deliver a broad array of services relied upon by enterprise and consumer end users. We provide equipment, software and services that support the transport, switching, aggregation, service delivery and management of voice, video and data traffic on communications networks. Our high-capacity hardware and network management and control software solutions enable open, multi-vendor, programmable networks that improve automation, reduce network complexity and flexibly support changing service requirements. Our solutions yield business and operational value for our customers by enabling them to support new applications, introduce new revenue-generating services and reduce network complexity and expense.

[0000936395-17-000020:mdna:38]
Our Converged Packet Optical, Packet Networking and Optical Transport products are used by a diverse set of customers and market segments, including communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education (R&E) institutions, and other emerging network operators. These products, which provide functionality from the network core to network access points, allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. In addition to our portfolio of high-capacity hardware platforms, we offer network management and control software platforms designed to simplify the creation, automation and delivery of services across multi-vendor and multi-domain network environments. Our software solutions are oriented around our modular Blue Planet software platform for multi-domain service orchestration, network function virtualization, and network management and control. To complement our hardware and software solutions, we offer a broad range of transformation and automation services that help our customers design, optimize, integrate, deploy, manage and maintain their networks.

[0000936395-17-000020:mdna:39]
[same as prior period, unchanged from 0000936395-16-000115:mdna:39]

[0000936395-17-000020:mdna:40]
[same as prior period, unchanged from 0000936395-16-000115:mdna:40]

[0000936395-17-000020:mdna:41]
The markets in which we sell our communications networking solutions have been subject to significant changes in recent years, including rapid growth in network traffic, evolving cloud-based service offerings, changes in the type of customers building communications networks, and heightened end-user service demands. These conditions have placed significant demands on networks, challenged the business models of network operators, and altered the overall competitive landscape of network operators. Existing and emerging network operators are competing to distinguish their service offerings and rapidly introduce differentiated, revenue-generating services, while managing the costs of their networks and seeking to ensure a profitable business model. These dynamics are driving convergence of network features, functions and layers, virtualization of certain network functions, and solutions that leverage increased software-based network control and programmability. We believe that these dynamics, and the need to adapt to rapidly changing business and network demands, will cause network operators to adopt or evolve their networks to be more open, programmable and automated.

[0000936395-17-000020:mdna:42]
[same as prior period, unchanged from 0000936395-16-000115:mdna:44]

[0000936395-17-000020:mdna:43]
The markets in which we compete are characterized by rapidly advancing technologies, frequent introduction of new networking solutions and aggressive selling and pricing efforts to displace incumbent vendors and to capture market share. The markets for our solutions are both highly competitive and fragmented. Our sales of Converged Packet Optical solutions face an intense competitive environment as we and our competitors introduce new, higher-capacity, higher-speed network solutions with improved reach, spectral efficiency, automation, power consumption and cost per bit. We expect the competitive landscape in which we operate to continue to broaden and to remain challenging and dynamic. As we have expanded our solutions offerings to include our 8700 Packetwave Platform and Waveserver DCI platform, our solutions have become increasingly competitive with IP router vendors, data center switch providers, and other IT suppliers or integrators. Separately, as we seek increased customer adoption of our Blue Planet software platform, we expect to compete more directly with additional software vendors and information technology vendors or integrators of these solutions.

[0000936395-17-000020:mdna:44]
In addition to the above dynamics, many network operators are continuing to consider a variety of “consumption models,” or approaches to the design and procurement of their network infrastructure. While broader adoption of the consumption

[0000936395-17-000020:mdna:45]
models involving disaggregation in the procurement of hardware and software remains uncertain, we expect that the potential for different models will require us and other system vendors to assess and possibly broaden their existing commercial models over time. We may also face competition from  component vendors, including those in our supply chain, who develop networking products based on off-the-shelf or commoditized hardware technology, referred to as “white box” hardware. Further, some of our competitors are not vertically integrated in their packet optical supply chain and therefore sell a set of networking solutions that rely upon coherent modem technology developed by and procured from third party “merchant” providers. In connection with consumption models involving greater disaggregation, the continued use of such third party modem technology by these competitors and/or the availability of such technology in the market may increase overall pricing pressure in this space and may negatively impact our ability to derive higher gross margins for Converged Packet Optical solutions.

[0000936395-17-000020:mdna:46]
Given this dynamic competitive landscape and the market-based price erosion for our products that we regularly encounter, we expect that, in order to achieve sustained revenue growth, we will be required to continue to increase our volume of product shipments, continue to diversify our business and customer base, introduce new solutions that address evolving service and network demands, and accommodate multiple consumption models. In addition, in order to maintain incumbency with key customers and to secure new opportunities, we are often required to agree to aggressive pricing, incur significant costs early in network deployment, or make significant commercial concessions. These terms have previously, and may in the future, adversely affect our results of operations and contribute to fluctuations in our financial results.

[0000936395-17-000020:mdna:47]
[same as prior period, unchanged from 0000936395-16-000115:mdna:48]

[0000936395-17-000020:mdna:48]
Our corporate strategy to capitalize on the evolving market dynamics described above to drive the profitable growth of our business includes the following initiatives:

[0000936395-17-000020:mdna:49]
Promote Choice and Openness through our OPn Philosophy. We previously introduced our OPn Architecture as a focused approach to next-generation networks through scalability, programmability and network level applications. Today, OPn has evolved and expanded from an architecture into our governing philosophy and broader belief system, which is rooted in enabling choice in the market through openness. Choice is an increasingly important element of our customers’ efforts to keep pace with bandwidth demands and emerging service offerings, the shift to more automated and programmable networks, and the need to manage network costs. We believe that the best way to enable choice for our customers is by developing and providing network technologies and strategies that facilitate openness through innovation, virtualization, automation and collaboration. We also believe that we are well-positioned in this regard to offer an expansive range of choice to the market. Our OPn belief system shapes the operation of our business in a number of ways. It guides our research and development strategy and solutions offerings, including our focus on coherent modem leadership, packet-optical convergence, and on multi-vendor network orchestration, management and control through our Blue Planet software platform. By embracing design principles that leverage open application programming interfaces (APIs), including those found in our Waveserver platform, we believe we facilitate openness and choice. By offering collaborative tools and environments, including our Emulation Cloud and DevOps Toolkit, we enable the development, testing and customization of services and applications. Our OPn belief system also influences our go-to-market approach, as we expect to partner increasingly with an ecosystem of solutions vendors and virtual network function providers, and to integrate services and applications across multi-vendor and multi-domain networks. We intend to offer solutions and pursue opportunities across a range of customer consumption models in order to drive the evolution of next-generation network infrastructures and accelerate the realization of our OPn philosophy.

[0000936395-17-000020:mdna:50]
Extend Technology Leadership and Expand Application of our Solutions. Our product development strategy is focused on maintaining our leading technology offerings and expanding our role and the application of our solutions in customer networks. Our research and development efforts seek to advance and extend our coherent modem technology leadership, including our WaveLogic coherent optical processor and high-speed indium phosphide and silicon photonics technologies (HSPC) acquired from TeraXion during fiscal 2016, to address network operator requirements for performance, power and cost. We are also focused on introducing terabit per second and greater transmission speeds, and expanding the high-capacity and operationally-efficient service delivery capabilities in our Packet Networking and Converged Packet Optical products for access and metro networks, data center interconnect, submarine networks, and other WAN applications. In addition, we are seeking to increase software programmability of networks and to enable network operators to automate and accelerate the creation and delivery of new, cloud-based services. These efforts include investments in our Blue Planet software platform — which is designed to automate, orchestrate, and manage physical network resources and virtualized services across data centers and the WAN — and its integration across our portfolio and with additional third party network resources.

[0000936395-17-000020:mdna:51]
Increase Diversification of our Business. The continued diversification of our business is a key element of our strategy to address the dynamic environment of our industry. We believe this diversification positions us to continue to grow our business and to better withstand potential slowdowns adversely affecting particular geographies, markets, customer segments and

[0000936395-17-000020:mdna:52]
applications. We intend to pursue initiatives that broaden sales to existing customers across our solutions portfolio and also to secure additional relationships with a diverse set of network operators in high-growth customer segments and geographies.

[0000936395-17-000020:mdna:53]
[same as prior period, unchanged from 0000936395-16-000115:mdna:53]

[0000936395-17-000020:mdna:54]
We also intend to target important growth markets, including key customer market segments and geographies. Our go-to-market strategy is focused on further diversifying our customer base by penetrating additional internet content providers, data center operators and other emerging network operators that form the “Web-scale” marketplace. We are also focused on securing additional customers within our traditional base of communications service providers, particularly in higher growth markets, in the Asia-Pacific region, including India. We intend to use our direct and indirect sales channels to target, and to expand our sales with, several other market verticals, including cable and multiservice operators, submarine network operators, enterprise customers and in the government and R&E markets. For example, we intend to gain greater reach providing network solutions to submarine network operators, particularly in the new cable build market, in part through our recently announced supply partnership with TE SubCom. To leverage the geographic reach of our direct sales resources and expand sales into key geographies, we have pursued channel and distribution opportunities, including our strategic relationship with Ericsson, that enable sales through third parties, including service providers, systems integrators and value-added resellers.

[0000936395-17-000020:mdna:55]
Optimize Business to Yield Operating Leverage. We regularly pursue initiatives to improve our operating margin, constrain operating expense and promote efficiency of our business processes and systems. These initiatives include portfolio optimization and engineering efforts to drive improved efficiencies in the design and development of our solutions and supply chain initiatives to ensure that our product cost model remains ahead of the price erosion that we regularly encounter in our markets. We are also focused on ensuring an efficient supply chain, including efforts to vertically integrate where prudent, reduce our material and overhead costs and improve inventory management and logistics. Our initiatives also include the recent upgrade of our company-wide enterprise resource planning platform, as well as contemporaneous efforts to improve automation of key business processes and systems. We seek to leverage these initiatives to promote the profitable growth of our business and to drive additional operating leverage.

[0000936395-17-000020:mdna:56]
[same as prior period, unchanged from 0000936395-16-000115:mdna:56]

[0000936395-17-000020:mdna:57]
During the first quarter of 2017, we repurchased $46.3 million of the outstanding aggregate principal amount of our 0.875% Convertible Senior Notes due June 15, 2017 (the “2017 Notes”) in a private transaction, for an aggregate purchase price of $46.3 million. As of January 31, 2017, $185.3 million in aggregate principal amount of our 2017 Notes remained outstanding. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes. See Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this quarterly report for more information relating to our outstanding convertible notes.

[0000936395-17-000020:mdna:58]
Term Loan Refinancing

[0000936395-17-000020:mdna:59]
Following the end of our first quarter of fiscal 2017, on January 30, 2017, we entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement, and Pledge Agreement (the “Refinancing Agreement”) that amends our existing Term Loan Credit Agreement, dated July 15, 2014, as amended (the “Term Loan Credit Agreement”) and provides for the refinancing of the two existing tranches of term loans under the Term Loan Credit Agreement. Under the Refinancing Agreement the two existing tranches of term loans —  the first with an aggregate principal amount of $244.4 million maturing on July 15, 2019, and the second with an aggregate principal amount of $248.8 million maturing on April 25, 2021 (together, the “Existing Term Loans”) — were combined into a single term loan with a reduced aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). As a result, we repaid $93.1 million of outstanding principal under the Existing Term Loans, and the remaining balances under the Existing Term Loans were refinanced and replaced by the 2022 Term Loan. See Note 22 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this quarterly report for more information relating to our term loan refinancing.

[0000936395-17-000020:mdna:60]
Company-Wide Enterprise Resource Planning Platform Upgrade

[0000936395-17-000020:mdna:61]
During the first quarter of fiscal 2017, we upgraded our company-wide enterprise resource planning ("ERP") platform to support our finance, supply chain, services, tax, and information technology processes. The system changes were undertaken due to changes in support and software life-cycle decisions by the ERP platform vendor, not in response to any actual or perceived deficiencies in our internal control over financial reporting, and did not materially change our existing internal controls in design or operation. The ERP platform upgrade resulted in an intentional and temporary shut down of certain systems during the beginning of the first quarter of fiscal 2017.

[0000936395-17-000020:mdna:62]
Financial Results for First Quarter of Fiscal 2017 and Sequential Comparison

[0000936395-17-000020:mdna:63]
Revenue for the first quarter of fiscal 2017 was $621.5 million, representing a sequential decrease of 13.2% from $716.2 million in the fourth quarter of fiscal 2016. We typically experience reductions in order volume toward the end of the calendar year, as the procurement cycles of some of our customers slow and network deployment activity at service providers is curtailed. This seasonality in our order flows across our operating segments and geographic regions can result in weaker, seasonally affected revenue results in the first quarter of our fiscal year. Revenue-related details reflecting sequential changes from the fourth quarter of fiscal 2016 include:

[0000936395-17-000020:mdna:64]
| • | Product revenue for the first quarter of fiscal 2017 decreased by $75.5 million, primarily reflecting revenue decreases in Converged Packet Optical within our Networking Platforms segment. |

[0000936395-17-000020:mdna:65]
| • | Service revenue for the first quarter of fiscal 2017 decreased by $19.2 million. |

[0000936395-17-000020:mdna:66]
| • | North America revenue for the first quarter of fiscal 2017 was $405.9 million, a decrease from $463.1 million in the fourth quarter of fiscal 2016. This primarily reflects revenue decreases of $50.3 million within our Networking Platforms segment and $8.7 million within our Global Services segment. These decreases were partially offset by an increase of $1.8 million within our Software and Software-Related Services segment. |

[0000936395-17-000020:mdna:67]
| • | Europe, Middle East and Africa ("EMEA") revenue for the first quarter of fiscal 2017 was $91.5 million, a decrease from $112.5 million in the fourth quarter of fiscal 2016. This primarily reflects revenue decreases of $12.1 million within our Networking Platforms segment and $10.0 million within our Global Services segment.These decreases were partially offset by an increase of $1.1 million within our Software and Software-Related Services segment. |

[0000936395-17-000020:mdna:68]
| • | Caribbean and Latin America ("CALA") revenue for the first quarter of fiscal 2017 was $35.2 million, a decrease from $46.8 million in the fourth quarter of fiscal 2016. This primarily reflects revenue decreases of $9.3 million within our Networking Platforms segment and $1.7 million within our Global Services segment. |

[0000936395-17-000020:mdna:69]
| • | Asia Pacific ("APAC") revenue for the first quarter of fiscal 2017 was $88.9 million, a decrease from $93.8 million in the fourth quarter of fiscal 2016. This primarily reflects a decrease of $4.5 million within our Networking Platforms segment. |

[0000936395-17-000020:mdna:70]
| • | For the first quarter of fiscal 2017, two customers accounted for greater than 10% of total revenue. AT&T accounted for 15.5% of total revenue and Verizon accounted for 11.8%. AT&T accounted for 18.3% of total revenue in the fourth quarter of fiscal 2016. |

[0000936395-17-000020:mdna:71]
Gross margin for the first quarter of fiscal 2017 was 44.1%, a decrease from 44.5% in the fourth quarter of fiscal 2016. Reduced gross margin for the first quarter of fiscal 2017 primarily reflects market-based price erosion partially offset by increased software revenue, product cost reductions and lower warranty expense.

[0000936395-17-000020:mdna:72]
Operating expense was $254.7 million for the first quarter of fiscal 2017, a decrease from $258.9 million in the fourth quarter of fiscal 2016. First quarter fiscal 2017 operating expense primarily reflects a decrease of $11.9 million in selling and marketing expense, partially offset by increases of $4.4 million in research and development expense and $3.7 in general and administrative expense.

[0000936395-17-000020:mdna:73]
Income from operations for the first quarter of fiscal 2017 was $19.1 million, compared to income from operations of $59.7 million during the fourth quarter of fiscal 2016. Our net income for the first quarter of fiscal 2017 was $3.9 million, or $0.03 per diluted common share, compared to a net income of $36.6 million or $0.25 per diluted common share, for the fourth quarter of fiscal 2016.

[0000936395-17-000020:mdna:74]
We used cash in operations of $26.3 million during the first quarter of fiscal 2017, compared to $136.7 million of cash generated from operations during the fourth quarter of fiscal 2016. As of January 31, 2017, we had $693.9 million in cash and cash equivalents, $250.1 million of short-term investments in U.S. treasury securities and commercial paper and $109.9 million of long-term investments in U.S. treasury securities. This compares to $777.6 million in cash and cash equivalents, $275.2 million of short-term investments in U.S. treasury securities and commercial paper and $90.2 million of long-term investments in U.S. treasury securities, at October 31, 2016.

[0000936395-17-000020:mdna:75]
As of January 31, 2017, we had 5,613 employees, which reflects an increase from 5,555 at October 31, 2016 and an increase from 5,363 at January 31, 2016.

[0000936395-17-000020:mdna:76]
[same as prior period, unchanged from 0000936395-16-000115:mdna:65]

[0000936395-17-000020:mdna:77]
[same as prior period, unchanged from 0000936395-16-000115:mdna:73]

[0000936395-17-000020:mdna:78]
[same as prior period, unchanged from 0000936395-16-000115:mdna:74]

[0000936395-17-000020:mdna:79]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-17-000020:mdna:80]
Quarter ended January 31, 2017 compared to the quarter ended January 31, 2016

[0000936395-17-000020:mdna:81]
[same as prior period, unchanged from 0000936395-16-000115:mdna:77]

[0000936395-17-000020:mdna:82]
During the first three months of fiscal 2017, approximately 18.5% of our revenue was non-U.S. Dollar denominated, including sales in Canadian Dollar, Euro, British Pound, Brazilian Real and Japanese Yen. During the first three months of fiscal 2017 as compared to the first three months of fiscal 2016, the U.S. Dollar fluctuated against these currencies. Consequently, our revenue reported in U.S. Dollars on a constant currency basis was slightly reduced by approximately $1.1 million or 0.2%. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-17-000020:mdna:83]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 412,652 |  |  | 66.4 |  | $ | 389,168 |  |  | 67.9 |  | $ | 23,484 |  |  | 6.0 |  |
| Packet Networking | 72,194 |  |  | 11.6 |  | 48,197 |  |  | 8.4 |  | 23,997 |  |  | 49.8 |  |
| Optical Transport | 5,098 |  |  | 0.8 |  | 12,145 |  |  | 2.1 |  | (7,047 | ) |  | (58.0 | ) |
| Total Networking Platforms | 489,944 |  |  | 78.8 |  | 449,510 |  |  | 78.4 |  | 40,434 |  |  | 9.0 |  |
| Software and Software-Related Services |  |  |  |  |  |  |  |  |  |  |  |
| Software Platforms | 17,049 |  |  | 2.7 |  | 8,079 |  |  | 1.4 |  | 8,970 |  |  | 111.0 |  |
| Software-Related Services | 22,331 |  |  | 3.6 |  | 17,347 |  |  | 3.0 |  | 4,984 |  |  | 28.7 |  |
| Total Software and Software-Related Services | 39,380 |  |  | 6.3 |  | 25,426 |  |  | 4.4 |  | 13,954 |  |  | 54.9 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 54,990 |  |  | 8.9 |  | 56,058 |  |  | 9.8 |  | (1,068 | ) |  | (1.9 | ) |
| Installation and Deployment | 27,919 |  |  | 4.5 |  | 30,840 |  |  | 5.4 |  | (2,921 | ) |  | (9.5 | ) |
| Consulting and Network Design | 9,264 |  |  | 1.5 |  | 11,281 |  |  | 2.0 |  | (2,017 | ) |  | (17.9 | ) |
| Total Global Services | 92,173 |  |  | 14.9 |  | 98,179 |  |  | 17.2 |  | (6,006 | ) |  | (6.1 | ) |
| Consolidated revenue | $ | 621,497 |  |  | 100.0 |  | $ | 573,115 |  |  | 100.0 |  | $ | 48,382 |  |  | 8.4 |  |

[0000936395-17-000020:mdna:84]
[same as prior period, unchanged from 0000936395-16-000115:mdna:81]

[0000936395-17-000020:mdna:85]
[same as prior period, unchanged from 0000936395-16-000115:mdna:82]

[0000936395-17-000020:mdna:86]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:87]
| • | Networking Platforms segment revenue increased, primarily reflecting product line sales increases of $24.0 million of our Packet Networking products and $23.5 million of our Converged Packet Optical products, partially offset by a decrease of $7.0 million in sales of our Optical Transport products. |

[0000936395-17-000020:mdna:88]
| ◦ | Converged Packet Optical sales reflect increases of $32.4 million of our 6500 Packet-Optical Platform and $12.4 million of our Waveserver stackable interconnect system. These increases were partially offset by sales decreases of $12.1 million of our Z-Series Packet-Optical Platform, $4.9 million of our 5430 Reconfigurable Switching System and $4.3 million of our CoreDirector® Multiservice Optical Switches. |

[0000936395-17-000020:mdna:89]
| ◦ | Packet Networking sales primarily reflect increases of $18.7 million of our 3000 and 5000 family of service delivery and aggregation switches and $4.9 million of our 8700 Packetwave Platform. |

[0000936395-17-000020:mdna:90]
| ◦ | Optical Transport sales have continued to experience significant declines, as expected. Our Optical Transport products have either been previously discontinued, or are expected to be discontinued, reflecting network operators’ transition toward next-generation converged network architectures addressed by solutions within our Converged Packet Optical product line. |

[0000936395-17-000020:mdna:91]
| • | Software and Software-Related Services segment revenue increased, primarily reflecting sales increases of $9.0 million of our software platforms and $5.0 million in software-related services. The increase in software platform sales reflects increases of $7.0 million in sales of our Blue Planet software platform and advanced software applications and $1.0 million in sales of our OneControl Unified Management System. The increase in software-related services is primarily due to sales increases of $3.1 million of software subscription services, $1.0 million of services supporting our Blue Planet software platform and advance software applications, and $1.0 million of software-enabled services. |

[0000936395-17-000020:mdna:92]
| • | Global Services segment revenue decreased, primarily reflecting sales decreases of $2.9 million of our installation and deployment services, $2.0 million of our consulting and network design services, and $1.1 million of our maintenance support and training. |

[0000936395-17-000020:mdna:93]
Our operating segments each engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the United States and Canada. Part of our business and growth strategy is to continue to diversify our customer base and secure additional communications service provider customers outside of North America, including in high-growth geographies such as India. We believe that this is an important part of our strategy and required for continued revenue growth. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, particularly when considered by geographic distribution, can fluctuate significantly and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular quarter. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-17-000020:mdna:94]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| North America | $ | 405,928 |  |  | 65.3 |  | $ | 392,704 |  |  | 68.5 |  | $ | 13,224 |  |  | 3.4 |  |
| EMEA | 91,543 |  |  | 14.7 |  | 80,722 |  |  | 14.1 |  | 10,821 |  |  | 13.4 |  |
| CALA | 35,146 |  |  | 5.7 |  | 43,810 |  |  | 7.6 |  | (8,664 | ) |  | (19.8 | ) |
| APAC | 88,880 |  |  | 14.3 |  | 55,879 |  |  | 9.8 |  | 33,001 |  |  | 59.1 |  |
| Total | $ | 621,497 |  |  | 100.0 |  | $ | 573,115 |  |  | 100.0 |  | $ | 48,382 |  |  | 8.4 |  |

[0000936395-17-000020:mdna:95]
[same as prior period, unchanged from 0000936395-16-000115:mdna:94]

[0000936395-17-000020:mdna:96]
[same as prior period, unchanged from 0000936395-16-000115:mdna:95]

[0000936395-17-000020:mdna:97]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:98]
| • | North America revenue primarily reflects increases of $12.6 million within our Software and Software-Related Services segment and $6.1 million within our Networking Platforms segment, partially offset by a revenue decrease of $5.5 million within our Global Services segment. The increase within our Software and Software-Related Services segment primarily reflects sales increases of $5.9 million of our Blue Planet software platform and advanced software applications, $3.2 million of our software subscription services, $1.0 million of our OneControl Unified Management System and $1.0 million in services supporting our Blue Planet software platform and advanced software applications. The revenue increase within our Networking Platforms segment primarily reflects a product line increase of $13.3 million of Packet Networking sales, partially offset by product line decreases of $5.4 million of Converged Packet Optical sales and $1.8 million in Optical Transport sales. The revenue increase within Packet Networking primarily reflects an increase of $10.5 million in sales of our 3000 and 5000 family of service delivery and aggregation switches to AT&T. |

[0000936395-17-000020:mdna:99]
| • | EMEA revenue primarily reflects increases of $12.0 million within our Networking Platform segment and $1.0 million within our Software and Software-Related Services segment, partially offset by a revenue decrease of $2.0 million within our Global Services segment. Networking Platform segment revenue reflects a product line increase of $13.2 million in Converged Packet Optical sales, primarily due to increased sales of the 6500 Packet-Optical Platform to certain communication service providers. |

[0000936395-17-000020:mdna:100]
41

[0000936395-17-000020:mdna:101]
| • | CALA revenue primarily reflects a decrease of $10.8 million within our Networking Platform segment, partially offset by a revenue increase of $2.0 million within our Global Services segment. CALA revenue primarily reflects decreased sales in Mexico. |

[0000936395-17-000020:mdna:102]
| • | APAC revenue primarily reflects an increase of $33.1 million within our Networking Platform segment. The revenue increase within our Networking Platforms segment primarily reflects an increase of our 6500 Packet-Optical Platform sales to communication service providers, particularly in India, submarine network operators, enterprise customers and sales through our strategic relationship with Ericsson. The timing of revenue recognition for large network projects in this region can result in significant variations in revenue results in any particular quarter. |

[0000936395-17-000020:mdna:103]
[same as prior period, unchanged from 0000936395-16-000115:mdna:101]

[0000936395-17-000020:mdna:104]
[same as prior period, unchanged from 0000936395-16-000115:mdna:102]

[0000936395-17-000020:mdna:105]
[same as prior period, unchanged from 0000936395-16-000115:mdna:103]

[0000936395-17-000020:mdna:106]
Our gross profit as a percentage of revenue, or “gross margin,” has improved in recent fiscal years, from 41.4% in fiscal 2014 to 44.7% in fiscal 2016. However, gross margin, particularly when viewed on a quarterly basis, can fluctuate due to a number of factors. Our gross margin remains highly dependent upon on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, to retain or secure key customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Our success in taking share and winning new business can result in additional costs associated with the early stages of network deployments, including an increased concentration of lower margin “common” equipment sales and installation services, as compared to higher margin products including channel cards, software services and maintenance services. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations and our revenue concentration within a particular segment, product line, geography, or customer.

[0000936395-17-000020:mdna:107]
[same as prior period, unchanged from 0000936395-16-000115:mdna:105]

[0000936395-17-000020:mdna:108]
[same as prior period, unchanged from 0000936395-16-000115:mdna:106]

[0000936395-17-000020:mdna:109]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Total revenue | $ | 621,497 |  |  | 100.0 |  | $ | 573,115 |  |  | 100.0 |  | $ | 48,382 |  |  | 8.4 |
| Total cost of goods sold | 347,712 |  |  | 55.9 |  | 321,665 |  |  | 56.1 |  | 26,047 |  |  | 8.1 |
| Gross profit | $ | 273,785 |  |  | 44.1 |  | $ | 251,450 |  |  | 43.9 |  | $ | 22,335 |  |  | 8.9 |

[0000936395-17-000020:mdna:110]
[same as prior period, unchanged from 0000936395-16-000115:mdna:108]

[0000936395-17-000020:mdna:111]
[same as prior period, unchanged from 0000936395-16-000115:mdna:109]

[0000936395-17-000020:mdna:112]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:113]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Product revenue | $ | 506,993 |  |  | 100.0 |  | $ | 457,589 |  |  | 100.0 |  | $ | 49,404 |  |  | 10.8 |
| Product cost of goods sold | 286,811 |  |  | 56.6 |  | 260,482 |  |  | 56.9 |  | 26,329 |  |  | 10.1 |
| Product gross profit | $ | 220,182 |  |  | 43.4 |  | $ | 197,107 |  |  | 43.1 |  | $ | 23,075 |  |  | 11.7 |

[0000936395-17-000020:mdna:114]
[same as prior period, unchanged from 0000936395-16-000115:mdna:112]

[0000936395-17-000020:mdna:115]
[same as prior period, unchanged from 0000936395-16-000115:mdna:113]

[0000936395-17-000020:mdna:116]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:117]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Service revenue | $ | 114,504 |  |  | 100.0 |  | $ | 115,526 |  |  | 100.0 |  | $ | (1,022 | ) |  | (0.9 | ) |
| Service cost of goods sold | 60,901 |  |  | 53.2 |  | 61,183 |  |  | 53.0 |  | (282 | ) |  | (0.5 | ) |
| Service gross profit | $ | 53,603 |  |  | 46.8 |  | $ | 54,343 |  |  | 47.0 |  | $ | (740 | ) |  | (1.4 | ) |

[0000936395-17-000020:mdna:118]
[same as prior period, unchanged from 0000936395-16-000115:mdna:116]

[0000936395-17-000020:mdna:119]
[same as prior period, unchanged from 0000936395-16-000115:mdna:117]

[0000936395-17-000020:mdna:120]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:121]
| • | Gross profit as a percentage of revenue reflects improved product gross profit partially offset by reduced services gross profit. |

[0000936395-17-000020:mdna:122]
| • | Gross profit on products as a percentage of product revenue benefited from increased software revenue, product cost reductions and lower warranty expense partially offset by market-based price erosion. |

[0000936395-17-000020:mdna:123]
| • | Gross profit on services as a percentage of services revenue decreased primarily due to increased installation and deployment costs due to certain early stage deployment activities. |

[0000936395-17-000020:mdna:124]
[same as prior period, unchanged from 0000936395-16-000115:mdna:122]

[0000936395-17-000020:mdna:125]
We expect operating expense to increase in fiscal 2017 from the level reported for fiscal 2016 in order to fund our research and development initiatives, to provide for investments in the re-engineering of company-wide enterprise resource planning platforms, and to fund the transition of key facilities. In particular, the development of our new facilities and the transition of our operations in Ottawa, Canada and Gurgaon, India will require significant effort, time and cost.

[0000936395-17-000020:mdna:126]
[same as prior period, unchanged from 0000936395-16-000115:mdna:124]

[0000936395-17-000020:mdna:127]
[same as prior period, unchanged from 0000936395-16-000115:mdna:125]

[0000936395-17-000020:mdna:128]
[same as prior period, unchanged from 0000936395-16-000115:mdna:126]

[0000936395-17-000020:mdna:129]
[same as prior period, unchanged from 0000936395-16-000115:mdna:127]

[0000936395-17-000020:mdna:130]
[same as prior period, unchanged from 0000936395-16-000115:mdna:128]

[0000936395-17-000020:mdna:131]
[same as prior period, unchanged from 0000936395-16-000115:mdna:129]

[0000936395-17-000020:mdna:132]
[same as prior period, unchanged from 0000936395-16-000115:mdna:130]

[0000936395-17-000020:mdna:133]
[same as prior period, unchanged from 0000936395-16-000115:mdna:131]

[0000936395-17-000020:mdna:134]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Research and development | $ | 116,869 |  |  | 18.8 |  | $ | 108,046 |  |  | 18.9 |  | $ | 8,823 |  |  | 8.2 |  |
| Selling and marketing | 85,002 |  |  | 13.7 |  | 82,478 |  |  | 14.4 |  | 2,524 |  |  | 3.1 |  |
| General and administrative | 35,864 |  |  | 5.8 |  | 31,142 |  |  | 5.4 |  | 4,722 |  |  | 15.2 |  |
| Acquisition and integration costs | — |  |  | — |  | 1,299 |  |  | 0.2 |  | (1,299 | ) |  | (100.0 | ) |
| Amortization of intangible assets | 14,551 |  |  | 2.3 |  | 16,862 |  |  | 2.9 |  | (2,311 | ) |  | (13.7 | ) |
| Restructuring costs | 2,395 |  |  | 0.4 |  | 384 |  |  | 0.1 |  | 2,011 |  |  | 523.7 |  |
| Total operating expenses | $ | 254,681 |  |  | 41.0 |  | $ | 240,211 |  |  | 41.9 |  | $ | 14,470 |  |  | 6.0 |  |

[0000936395-17-000020:mdna:135]
[same as prior period, unchanged from 0000936395-16-000115:mdna:133]

[0000936395-17-000020:mdna:136]
[same as prior period, unchanged from 0000936395-16-000115:mdna:134]

[0000936395-17-000020:mdna:137]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:138]
| • | Research and development expense was adversely affected by $1.8 million as a result of foreign exchange rates, net of hedging, primarily due to a weaker U.S. Dollar in relation to the Canadian Dollar. Including the effect of foreign exchange rates, research and development expenses increased by $8.8 million. This change reflects increases of $4.4 million in employee and compensation costs and $5.1 million in facilities and information technology costs. These increases were partially offset by a decrease of $1.2 million in professional services. |

[0000936395-17-000020:mdna:139]
| • | Selling and marketing expense increased by $2.5 million, primarily reflecting increases of $1.0 million in employee and compensation costs, $0.6 million in facilities and information technology costs and $0.6 million in technology related costs. |

[0000936395-17-000020:mdna:140]
| • | General and administrative expense increased by $4.7 million, primarily reflecting increases of $1.5 million in employee and compensation costs and $2.5 million for professional services and legal fees. |

[0000936395-17-000020:mdna:141]
| • | Acquisition and integration costs incurred during fiscal 2016 reflects expense for financial, legal and accounting advisors and severance and other employee compensation costs, related to our acquisition of Cyan on August 3, 2015 and our acquisition of certain HSPC assets of TeraXion and its wholly-owned subsidiary on February 1, 2016. |

[0000936395-17-000020:mdna:142]
| • | Amortization of intangible assets decreased due to certain intangible assets having reached the end of their economic lives. |

[0000936395-17-000020:mdna:143]
| • | Restructuring costs increased reflecting a global workforce reduction of approximately 50 employees in the first quarter of fiscal 2017 as part of our business optimization strategy to improve our gross margin, constrain operating expense and redesign certain business processes, systems, and resources. |

[0000936395-17-000020:mdna:144]
[same as prior period, unchanged from 0000936395-16-000115:mdna:142]

[0000936395-17-000020:mdna:145]
[same as prior period, unchanged from 0000936395-16-000115:mdna:143]

[0000936395-17-000020:mdna:146]
|  | Quarter Ended January 31, |  | Increase |  |  |
|  | 2017 |  | %* |  | 2016 |  | %* |  | (decrease) |  | %** |
| Interest and other income (loss), net | $ | 370 |  |  | 0.1 |  | $ | (8,776 | ) |  | (1.5 | ) |  | $ | 9,146 |  |  | 104.2 |  |
| Interest expense | $ | 15,203 |  |  | 2.4 |  | $ | 12,710 |  |  | 2.2 |  |  | $ | 2,493 |  |  | 19.6 |  |
| Provision for income taxes | $ | 410 |  |  | 0.1 |  | $ | 1,299 |  |  | 0.2 |  |  | $ | (889 | ) |  | (68.4 | ) |

[0000936395-17-000020:mdna:147]
[same as prior period, unchanged from 0000936395-16-000115:mdna:145]

[0000936395-17-000020:mdna:148]
[same as prior period, unchanged from 0000936395-16-000115:mdna:146]

[0000936395-17-000020:mdna:149]
**    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:150]
| • | Interest and other income (loss), net primarily reflects a $7.6 million gain in foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. |

[0000936395-17-000020:mdna:151]
| • | Interest expense increased primarily due to the 2021 Term Loan that was entered into in the second quarter of fiscal 2016. For additional information about our term loans, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000020:mdna:152]
| • | Provision for income taxes decreased primarily due to lower foreign tax expense. |

[0000936395-17-000020:mdna:153]
[same as prior period, unchanged from 0000936395-16-000115:mdna:213]

[0000936395-17-000020:mdna:154]
[same as prior period, unchanged from 0000936395-16-000115:mdna:221]

[0000936395-17-000020:mdna:155]
|  | Quarter Ended January 31, |  |  |  |
|  | 2017 |  | 2016 |  | Increase (decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 113,747 |  |  | $ | 106,982 |  |  | $ | 6,765 |  |  | 6.3 |  |
| Software and Software-Related Services | $ | 7,700 |  |  | $ | (3,574 | ) |  | $ | 11,274 |  |  | 315.4 |  |
| Global Services | $ | 35,469 |  |  | $ | 39,996 |  |  | $ | (4,527 | ) |  | (11.3 | ) |

[0000936395-17-000020:mdna:156]
[same as prior period, unchanged from 0000936395-16-000115:mdna:167]

[0000936395-17-000020:mdna:157]
*    Denotes % change from 2016 to 2017

[0000936395-17-000020:mdna:158]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume, as described above, partially offset by reduced gross margin and higher research and development costs. The reduced gross margin primarily reflects market-based price erosion partially offset by product cost reductions and lower warranty expense. |

[0000936395-17-000020:mdna:159]
| • | Software and Software-Related Services segment profit reflects higher sales volume, as described above, and improved gross margin, partially offset by increased research and development costs. Research and development costs primarily reflect increased expenses relating to the continued development of our Blue Planet software platform. |

[0000936395-17-000020:mdna:160]
| • | Global Services segment profit decreased, primarily due to lower sales volume, as described above, and reduced gross margin. The reduced gross margin is primarily due to increased installation and deployment costs due to certain early stage deployment activities. |

[0000936395-17-000020:mdna:161]
[same as prior period, unchanged from 0000936395-16-000115:mdna:228]

[0000936395-17-000020:mdna:162]
For the three months ended January 31, 2017, we used in $26.3 million in cash to fund our operating needs, as our working capital requirements of $88.9 million exceeded our net income (adjusted for non-cash charges) of $62.6 million. The increase in working capital was primarily driven by inventory increases of $78.7 million. We further invested $25.7 million in capital expenditures for the purchase of equipment, furniture and fixtures. For additional details, see the discussion below entitled, “Cash from Operations.”

[0000936395-17-000020:mdna:163]
Our total cash, cash equivalents and investments decreased by $89.2 million during the first three months of fiscal 2017, as a result of the cash used in to fund operations and capital expenditures described above totaling $52.0 million, as well as the repurchase of an additional $46.3 million in outstanding 0.875% Convertible Senior Notes due June 15, 2017. Proceeds from the issuance of equity under our employee stock purchase plans provided approximately $9.7 million in cash during the period. We expect to repay the balance of the outstanding 2017 Notes with additional cash and investments on hand.

[0000936395-17-000020:mdna:164]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-17-000020:mdna:165]
|  | January 31, 2017 |  | October 31, 2016 |  | Increase(decrease) |
| Cash and cash equivalents | $ | 693,853 |  |  | $ | 777,615 |  |  | $ | (83,762 | ) |
| Short-term investments in marketable debt securities | 250,056 |  |  | 275,248 |  |  | (25,192 | ) |
| Long-term investments in marketable debt securities | 109,934 |  |  | 90,172 |  |  | 19,762 |  |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,053,843 |  |  | $ | 1,143,035 |  |  | $ | (89,192 | ) |

[0000936395-17-000020:mdna:166]
As more fully described in Note 22, following the end of our first quarter of fiscal 2017, we refinanced our existing Term Loans into a single term loan with an aggregate principal amount of $400 million, maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena repaid $93.1 million of outstanding principal under the Existing Term Loans utilizing cash, cash equivalents and investments on hand.

[0000936395-17-000020:mdna:167]
Our principal sources of liquidity on hand include our cash and investments, which as of January 31, 2017 totaled $1.1 billion, as well as our ABL Credit Facility. Ciena and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”) providing for a total commitment of $250 million with a maturity date of December 31, 2020. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of January 31, 2017, letters of credit totaling $71.3 million were collateralized by our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2017. Based on past performance and current expectations, we believe that cash from operations, cash and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy the working capital needs, capital expenditures, the repayment of our outstanding 0.875% convertible senior notes due June 15, 2017 and other liquidity requirements associated with our operations through at least the next 12 months.

[0000936395-17-000020:mdna:168]
The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $52.4 million as of January 31, 2017. Given this amount, we do not believe that there are significant amounts held by foreign subsidiaries in which we consider earnings to be permanently reinvested, that may not be available for U.S. operations. In the event such funds held by our foreign subsidiaries were repatriated, we believe that any resulting tax implications would not be material.

[0000936395-17-000020:mdna:169]
We regularly evaluate our liquidity position, debt obligations, and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. During fiscal 2017, we have repurchased $46.3 million in aggregate principal amount of our outstanding 2017 Notes. For additional information about our convertible notes, see Note 16 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically repurchase our outstanding convertible notes.

[0000936395-17-000020:mdna:170]
Cash from Operations

[0000936395-17-000020:mdna:171]
The following sections set forth the components of our $26.3 million of cash used in operating activities during the first three months of fiscal 2017:

[0000936395-17-000020:mdna:172]
[same as prior period, unchanged from 0000936395-16-000115:mdna:247]

[0000936395-17-000020:mdna:173]
[same as prior period, unchanged from 0000936395-16-000115:mdna:248]

[0000936395-17-000020:mdna:174]
|  | Three months ended |
|  | January 31, 2017 |
| Net income | $ | 3,861 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 16,699 |  |
| Share-based compensation costs | 12,825 |  |
| Amortization of intangible assets | 18,864 |  |
| Provision for inventory excess and obsolescence | 5,431 |  |
| Provision for warranty | 553 |  |
| Other | 4,452 |  |
| Net income (adjusted for non-cash charges) | $ | 62,685 |  |

[0000936395-17-000020:mdna:175]
[same as prior period, unchanged from 0000936395-16-000115:mdna:250]

[0000936395-17-000020:mdna:176]
We used $88.9 million of cash for working capital during the period. The following tables set forth the major components of the cash used in working capital (in thousands):

[0000936395-17-000020:mdna:177]
|  | Three months ended |
|  | January 31, 2017 |
| Cash used in accounts receivable | $ | (21,956 | ) |
| Cash used in inventories | (78,749 | ) |
| Cash used in prepaid expenses and other | (1,004 | ) |
| Cash provided by accounts payable, accruals and other obligations | 4,037 |  |
| Cash provided by deferred revenue | 8,737 |  |
| Total cash used for working capital | $ | (88,935 | ) |

[0000936395-17-000020:mdna:178]
As compared to the end of fiscal 2016:

[0000936395-17-000020:mdna:179]
| • | The $22.0 million of cash used by accounts receivable during the first three months of fiscal 2017 reflects increased sales volume at the end of the first quarter of fiscal 2017; |

[0000936395-17-000020:mdna:180]
| • | The $78.7 million of cash used in inventory during the first three months of fiscal 2017 primarily reflects increases in finished goods to meet customer delivery schedules for the beginning of the second quarter of fiscal 2017; |

[0000936395-17-000020:mdna:181]
| • | Cash used in prepaid expense and other during the first three months of fiscal 2017 was $1.0 million, primarily reflecting lower product demonstration equipment, partially offset by an increase in a financing receivable; |

[0000936395-17-000020:mdna:182]
| • | The $4.0 million of cash provided by accounts payable, accruals and other obligations during the first three months of fiscal 2017 reflects increased inventory purchases at the end of the first quarter of fiscal 2017, partially offset by the timing of bonus payments to employees under our annual cash incentive compensation plan; and |

[0000936395-17-000020:mdna:183]
| • | The $8.7 million of cash provided by deferred revenue during the first three months of fiscal 2017 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-17-000020:mdna:184]
Our days sales outstanding (DSOs) for the first three months of fiscal 2017 were 86 days and our inventory turns for the first three months of fiscal 2017 were 4.0.

[0000936395-17-000020:mdna:185]
[same as prior period, unchanged from 0000936395-16-000115:mdna:260]

[0000936395-17-000020:mdna:186]
[same as prior period, unchanged from 0000936395-16-000115:mdna:261]

[0000936395-17-000020:mdna:187]
|  | Three months ended |
|  | January 31, 2017 |
| 0.875% Convertible Senior Notes due June 15, 2017(1) | $ | 1,013 |  |
| 3.75% Convertible Senior Notes, due October 15, 2018(2) | — |  |
| 4.0% Convertible Senior Notes, due December 15, 2020(3) | 3,750 |  |
| Term Loan due July 15, 2019(4) | 2,342 |  |
| Term Loan due April 25, 2021(5) | 2,702 |  |
| Interest rate swaps(6) | 1,174 |  |
| ABL Credit Facility(7) | 348 |  |
| Capital leases | 502 |  |
| Cash paid during period | $ | 11,831 |  |

[0000936395-17-000020:mdna:188]
[same as prior period, unchanged from 0000936395-16-000115:mdna:263]

[0000936395-17-000020:mdna:189]
| (2) | Interest on our outstanding 3.75% Convertible Senior Notes, due October 15, 2018, is payable on April 15 and October 15 of each year. |

[0000936395-17-000020:mdna:190]
[same as prior period, unchanged from 0000936395-16-000115:mdna:265]

[0000936395-17-000020:mdna:191]
| (4) | Interest on the 2019 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2019 Term Loan bore interest at LIBOR plus a spread of 3.00% subject to a minimum LIBOR rate of |

[0000936395-17-000020:mdna:192]
[same as prior period, unchanged from 0000936395-16-000115:mdna:160]

[0000936395-17-000020:mdna:193]
0.75%. At the end of the first quarter of fiscal 2017, prior to the term loan refinancing, the interest rate on the 2019 Term Loan was 3.78%.

[0000936395-17-000020:mdna:194]
| (5) | Interest on the 2021 Term Loan was payable periodically based on the underlying market index rate selected for borrowing. The 2021 Term Loan bore interest at LIBOR plus a spread of 3.25% to 3.50% subject to a minimum LIBOR rate of 0.75%. At the end of the first quarter of fiscal 2017, prior to the term loan refinancing, the interest rate on the 2021 Term Loan was 4.28%. |

[0000936395-17-000020:mdna:195]
| (6) | Prior to the term loan refinancing, payments on our interest rate swaps were variable and effectively fixed the total interest rate under the 2019 Term Loan at 5.004% from July 20, 2015 through July 19, 2018 and the 2021 Term Loan at 4.62% to 4.87%, depending on applicable margin, from June 20, 2016 through June 22, 2020. |

[0000936395-17-000020:mdna:196]
| (7) | During the first three months of fiscal 2017, we utilized the ABL Credit Facility to collateralize certain standby letters of credit and paid $0.3 million in commitment fees, interest expense and other administrative charges relating to our ABL Credit Facility. |

[0000936395-17-000020:mdna:197]
For additional information about our convertible notes and term loans, ABL Credit Facility and interest rate swaps, see Notes 14, 16 and 17 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. For additional information relating to the refinancing of our 2019 Term Loan and our 2021 Term Loan following the end of the first quarter of fiscal 2017, see Note 22 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report.

[0000936395-17-000020:mdna:198]
[same as prior period, unchanged from 0000936395-16-000115:mdna:271]

[0000936395-17-000020:mdna:199]
The following is a summary of our future minimum payments under contractual obligations as of January 31, 2017 (in thousands):

[0000936395-17-000020:mdna:200]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Principal due at maturity on convertible notes (1) | $ | 752,385 |  |  | $ | 185,258 |  |  | $ | 350,000 |  |  | $ | 217,127 |  |  | $ | — |  |
| Principal due on term loans (2) | 493,125 |  |  | 5,000 |  |  | 246,875 |  |  | 241,250 |  |  | — |  |
| Interest due on convertible notes | 57,061 |  |  | 21,436 |  |  | 28,125 |  |  | 7,500 |  |  | — |  |
| Interest due on term loans (2) | 67,910 |  |  | 20,140 |  |  | 34,737 |  |  | 13,033 |  |  | — |  |
| Payments due under interest rate swaps (2) | 7,290 |  |  | 3,864 |  |  | 3,090 |  |  | 336 |  |  | — |  |
| Operating leases (3) | 134,010 |  |  | 26,913 |  |  | 41,029 |  |  | 28,263 |  |  | 37,805 |  |
| Purchase obligations (4) | 265,097 |  |  | 265,097 |  |  | — |  |  | — |  |  | — |  |
| Capital leases— equipment | 4,598 |  |  | 1,763 |  |  | 2,835 |  |  | — |  |  | — |  |
| Capital leases— buildings (5) | 124,587 |  |  | 4,302 |  |  | 14,672 |  |  | 15,045 |  |  | 90,568 |  |
| Other obligations | 2,628 |  |  | 1,036 |  |  | 1,592 |  |  | — |  |  | — |  |
| Total (6) | $ | 1,908,691 |  |  | $ | 534,809 |  |  | $ | 722,955 |  |  | $ | 522,554 |  |  | $ | 128,373 |  |

[0000936395-17-000020:mdna:201]
[same as prior period, unchanged from 0000936395-16-000115:mdna:178]

[0000936395-17-000020:mdna:202]
[same as prior period, unchanged from 0000936395-16-000115:mdna:276]

[0000936395-17-000020:mdna:203]
| (2) | Does not include the effect of our Refinancing Agreement which aggregated our Existing Term Loans into a single with a reduced aggregate principal amount. Interest on the term loans and payments due under the interest rate swaps are variable and were calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 14, 16 and 22 to our Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. |

[0000936395-17-000020:mdna:204]
[same as prior period, unchanged from 0000936395-16-000115:mdna:278]

[0000936395-17-000020:mdna:205]
[same as prior period, unchanged from 0000936395-16-000115:mdna:279]

[0000936395-17-000020:mdna:206]
| (5) | This represents the total minimum lease payments due for all buildings that are subject to capital lease accounting, as well as buildings that are expected to be recorded as capital leases upon the commencement of the lease term. Payment timing is based on the expected commencement of the lease term. Does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-17-000020:mdna:207]
| (6) | As of January 31, 2017, we also had approximately $13.8 million of other long-term obligations in our Condensed Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing of any cash settlement with the respective tax authority, if any, cannot be reasonably estimated. |

[0000936395-17-000020:mdna:208]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending upon the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of January 31, 2017 (in thousands):

[0000936395-17-000020:mdna:209]
|  | Total |  | Less than one year |  | One to three years |  | Three to five years |  | Thereafter |
| Standby letters of credit | $ | 76,526 |  |  | $ | 38,584 |  |  | $ | 14,748 |  |  | $ | 10,767 |  |  | $ | 12,427 |  |

[0000936395-17-000020:mdna:210]
[same as prior period, unchanged from 0000936395-16-000115:mdna:284]

[0000936395-17-000020:mdna:211]
[same as prior period, unchanged from 0000936395-16-000115:mdna:285]

[0000936395-17-000020:mdna:212]
[same as prior period, unchanged from 0000936395-16-000115:mdna:286]

[0000936395-17-000020:mdna:213]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-17-000020:mdna:214]
[same as prior period, unchanged from 0000936395-16-000115:mdna:288]

[0000936395-17-000020:mdna:215]
[same as prior period, unchanged from 0000936395-16-000115:mdna:289]

[0000936395-17-000020:mdna:216]
[same as prior period, unchanged from 0000936395-16-000115:mdna:290]

[0000936395-17-000020:mdna:217]
[same as prior period, unchanged from 0000936395-16-000115:mdna:292]

[0000936395-17-000020:mdna:218]
[same as prior period, unchanged from 0000936395-16-000115:mdna:293]

[0000936395-17-000020:mdna:219]
[same as prior period, unchanged from 0000936395-16-000115:mdna:294]

[0000936395-17-000020:mdna:220]
[same as prior period, unchanged from 0000936395-16-000115:mdna:295]

[0000936395-17-000020:mdna:221]
Our total deferred revenue for products was $48.8 million and $45.2 million as of January 31, 2017 and October 31, 2016, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $143.2 million and $137.7 million as of January 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000020:mdna:222]
[same as prior period, unchanged from 0000936395-16-000115:mdna:297]

[0000936395-17-000020:mdna:223]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards, net of estimated forfeitures, as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-17-000020:mdna:224]
Because share-based compensation expense is based on awards that are ultimately expected to vest, the amount of expense takes into account estimated forfeitures. We estimate forfeitures at the time of grant and revise these estimates, if necessary, in subsequent periods if actual forfeitures differ from those estimates. Changes in these estimates and assumptions can materially affect the measurement of estimated fair value of our share-based compensation. See Note 19 to our Condensed Consolidated Financial Statements in Item 1 of Part I of this report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of January 31, 2017, total unrecognized compensation expense was $95.9 million: (i) $0.4 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.3 years; and (ii) $95.5 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.6 years.

[0000936395-17-000020:mdna:225]
We recognize windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by us upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that we had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, we follow the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including our net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be

[0000936395-17-000020:mdna:226]
considered realized in instances where our net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.

[0000936395-17-000020:mdna:227]
[same as prior period, unchanged from 0000936395-16-000115:mdna:301]

[0000936395-17-000020:mdna:228]
[same as prior period, unchanged from 0000936395-16-000115:mdna:302]

[0000936395-17-000020:mdna:229]
For fiscal 2017, the Compensation Committee has approved an annual cash incentive arrangement generally applicable to full-time employees excluding commissioned salespersons, with the aggregate amount of any awards payable dependent upon the achievement of certain financial and operational goals for fiscal 2017. Given that the awards are generally contingent upon achieving annual objectives, the payment of cash incentive awards is not expected to be made until after fiscal year-end results are finalized. As a result, the expense that we accrue for cash incentive compensation in any interim period in fiscal 2017 is based upon estimates of expected financial results for the year and expected performance against relevant operating objectives. Because assessing actual performance against many of these objectives cannot generally occur until at or near fiscal year-end, determining the amount of expense that we incur in our interim financial statements for incentive compensation involves the judgment of management. Amounts accrued are subject to change in future interim periods if actual future financial results or operational performance are better or worse than expected. We incurred an aggregate of $15.0 million of expense in the first three months of fiscal 2017 associated with our cash incentive bonus plan for fiscal 2017.

[0000936395-17-000020:mdna:230]
[same as prior period, unchanged from 0000936395-16-000115:mdna:305]

[0000936395-17-000020:mdna:231]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand and market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted. Historically, we have experienced write downs due to changes in our strategic direction, discontinuance of a product and declines in market conditions. We recorded charges for excess and obsolete inventory of $5.4 million and $7.0 million in the first three months of fiscal 2017 and 2016, respectively. The charges in fiscal 2017 primarily were related to a decrease in the forecasted demand for certain Networking Platform products. Our inventory net of allowance for excess and obsolescence was $284.6 million and $211.3 million as of January 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000020:mdna:232]
[same as prior period, unchanged from 0000936395-16-000115:mdna:307]

[0000936395-17-000020:mdna:233]
Our allowance for doubtful accounts receivable is based on management's assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer's financial condition changes, or if actual defaults are higher than our historical experience, we may be required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations. Our accounts receivable, net of allowance for doubtful accounts, was $595.7 million and $576.2 million as of January 31, 2017 and October 31, 2016, respectively. Our allowance for doubtful accounts was $4.0 million as of January 31, 2017 and October 31, 2016, respectively.

[0000936395-17-000020:mdna:234]
[same as prior period, unchanged from 0000936395-16-000115:mdna:309]

[0000936395-17-000020:mdna:235]
Our goodwill was generated from the acquisition of Cyan during fiscal 2015 and the acquisition of the HSPC assets from TeraXion during fiscal 2016, and is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-17-000020:mdna:236]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, which we adopted in the first quarter in fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of January 31, 2017 and October 31, 2016, the goodwill balance was $267.2 million and $267.0 million, respectively.

[0000936395-17-000020:mdna:237]
[same as prior period, unchanged from 0000936395-16-000115:mdna:312]

[0000936395-17-000020:mdna:238]
Our long-lived assets include: equipment, building, furniture and fixtures; finite-lived intangible assets; in-process research and development; and maintenance spares. As of January 31, 2017 and October 31, 2016, these assets totaled $466.5 million and $484.7 million, net, respectively. We test long-lived assets for impairment whenever events or changes in circumstances indicate that the assets' carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-17-000020:mdna:239]
[same as prior period, unchanged from 0000936395-16-000115:mdna:314]

[0000936395-17-000020:mdna:240]
We provide a valuation allowance for our deferred tax assets in excess of deferred tax liabilities because we have concluded that it is more likely than not that such deferred tax assets will ultimately not be realized. The ultimate realization of deferred tax assets is dependent upon the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. We assess available positive and negative evidence regarding our ability to realize our deferred tax assets and record a valuation allowance when it is more likely than not that deferred tax assets will not be realized. To form a conclusion, management considers our recent financial results and trends and makes judgments and estimates related to projections of profitability, the timing and extent of the use of net operating loss carryforwards, and tax planning strategies. At January 31, 2017, we were not in a three-year cumulative loss position. However, management determined that a valuation allowance is still necessary, due to, among other things, the relatively low level of cumulative pre-tax income during this period — cumulative 12-quarter profit was only recently achieved in the second half of fiscal 2016  — and our lengthy history of operating losses. We will continue to evaluate future financial performance to determine whether such profitability is both sustainable and significant enough to provide sufficient evidence to support reversal of all or a portion of the valuation allowance. Any future release of valuation allowance may be recorded as a tax benefit increasing net income or as an adjustment to paid-in capital, based on tax ordering requirements. The valuation allowance balance at January 31, 2017 was $1.5 billion.

[0000936395-17-000020:mdna:241]
[same as prior period, unchanged from 0000936395-16-000115:mdna:316]

[0000936395-17-000020:mdna:242]
Our liability for product warranties, included in other accrued liabilities, was $48.7 million and $52.3 million as of January 31, 2017 and October 31, 2016, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties was $0.6 million and $5.0 million for the first three months of fiscal 2017 and 2016, respectively. See Note 13 to the Condensed Consolidated Financial Statements included in Item 1 of Part I of this report. The provision for warranty claims may fluctuate on a quarterly basis depending upon the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.
