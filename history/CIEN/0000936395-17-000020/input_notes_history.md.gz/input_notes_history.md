# CIEN note change history — 0000936395-16-000115 → 0000936395-17-000020


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:1]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. On November 18, 2016, the parties each filed motions for summary judgment. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.
  (was, 2016-09-07, similarity 0.9014):
[0000936395-16-000115:note_history:1]
As a result of Ciena's acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

- changed (2017-03-08):
[0000936395-17-000020:note_history:2]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the ‘673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.
  (was, 2016-09-07, similarity 0.9938):
[0000936395-16-000115:note_history:2]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties' products infringe U.S. Patent 6,542,673 (the “'673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants' inter partes application for reexamination with respect to certain claims of the '673 Patent, and the district court granted the defendants' motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the '673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the '673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the '673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the '673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:3]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2017 and 2016 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.
  (was, 2016-09-07, similarity 0.8041):
[0000936395-16-000115:note_history:3]
Ciena has a 52 or 53-week fiscal year, which ends on the Saturday nearest to the last day of October of each year. Fiscal 2015 and 2016 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.

- removed (2017-03-08):
[0000936395-16-000115:note_history:4]
Ciena previously identified prior period errors in the classification of foreign currency differences on changes in operating assets and liabilities for each quarterly period during the nine months ended July 31, 2015. The matters identified had no impact on any of the cash flow statement subtotals in any of the quarters, and were limited to equal and offsetting errors within the subtotal of cash provided by operations. Ciena concluded that the errors were not material to any of its previously issued financial statements. Ciena has revised the affected periods as they are presented in fiscal 2016 on a comparable basis to reflect the correction. The revisions resulted in net reclassifications within the cash flows from operating activities section of the cash flow from "Other" to “Changes in assets and liabilities” of $19.0 million for the nine-month period ending July 31, 2015.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:5]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to  allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.
  (was, 2016-09-07, similarity 0.9747):
[0000936395-16-000115:note_history:5]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, includes assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

- changed (2017-03-08):
[0000936395-17-000020:note_history:6]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.
  (was, 2016-09-07, similarity 0.85):
[0000936395-16-000115:note_history:6]
Ciena has a minority equity investment in a privately held technology company that is classified in other long-term assets. This investment is carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors this investment for impairment and makes appropriate reductions to the carrying value when necessary. As of July 31, 2016, the carrying value of this investment was $2.0 million. Ciena has not estimated the fair value of this cost method investment because determining the fair value is not practicable. Ciena has not evaluated this investment for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of this investment.

- changed (2017-03-08):
[0000936395-17-000020:note_history:7]
Ciena's chief operating decision maker, its chief executive officer, evaluates the Company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 below.
  (was, 2016-09-07, similarity 0.9765):
[0000936395-16-000115:note_history:7]
Ciena's chief operating decision maker, its chief executive officer, evaluates the company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. As of the first quarter of fiscal 2016, Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 21 below.

- added (2017-03-08):
[0000936395-17-000020:note_history:8]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

- changed (2017-03-08):
[0000936395-17-000020:note_history:9]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.
  (was, 2016-09-07, similarity 0.6027):
[0000936395-16-000115:note_history:9]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements. During fiscal 2015 and fiscal 2016, Ciena gained access to portions of an office building in Ottawa, Canada pursuant to a lease arrangement accounted for as a capital lease, which is depreciated over the lease term. The leased building is part of Ciena's new campus facility that will replace the "Lab 10" research and development center on the former Nortel Carling campus. See Note 11 below.

- changed (2017-03-08):
[0000936395-17-000020:note_history:10]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, and the asset developed has no alternative use, the full value of the asset will be charged to expense.
  (was, 2016-09-07, similarity 0.9258):
[0000936395-16-000115:note_history:10]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, the full value of the asset will be charged to expense.

- changed (2017-03-08):
[0000936395-17-000020:note_history:11]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 19 below.
  (was, 2016-09-07, similarity 0.9997):
[0000936395-16-000115:note_history:11]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 20 below.

- changed (2017-03-08):
[0000936395-17-000020:note_history:12]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2010) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.
  (was, 2016-09-07, similarity 0.9826):
[0000936395-16-000115:note_history:12]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena's income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2010 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena's consolidated financial position, results of operations or cash flows. Ciena's major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2013), Canada (2010) and India (2010). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

- changed (2017-03-08):
[0000936395-17-000020:note_history:13]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements. See Note 21 below.
  (was, 2016-09-07, similarity 0.982):
[0000936395-16-000115:note_history:13]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements.

- changed (2017-03-08):
[0000936395-17-000020:note_history:14]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena’s net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena’s net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.
  (was, 2016-09-07, similarity 0.996):
[0000936395-16-000115:note_history:14]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders' equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee's disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena's net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena's net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year's taxable income before considering the effects of current-year windfalls.

- changed (2017-03-08):
[0000936395-17-000020:note_history:15]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development cost qualifying for capitalization has been insignificant. Accordingly, Ciena has not capitalized any software development costs.
  (was, 2016-09-07, similarity 0.9973):
[0000936395-16-000115:note_history:15]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

- added (2017-03-08):
[0000936395-17-000020:note_history:16]
Newly Issued Accounting Standards - Effective

- added (2017-03-08):
[0000936395-17-000020:note_history:17]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $7.9 million at January 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.

- added (2017-03-08):
[0000936395-17-000020:note_history:18]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena has elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

- changed (2017-03-08):
[0000936395-17-000020:note_history:19]
In May 2014, FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require Ciena to determine the stand alone selling price for each of the elements at the contract inception and consequently Ciena expects certain software deliverables will be recognized at a point in time rather than over a period of time. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures, as well as the transition method.
  (was, 2016-09-07, similarity 0.6017):
[0000936395-16-000115:note_history:19]
In May 2014, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update (“ASU”) No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- changed (2017-03-08):
[0000936395-17-000020:note_history:20]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.
  (was, 2016-09-07, similarity 0.6947):
[0000936395-16-000115:note_history:20]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is currently evaluating the impact of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

- changed (2017-03-08):
[0000936395-17-000020:note_history:21]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard.
  (was, 2016-09-07, similarity 0.681):
[0000936395-16-000115:note_history:21]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.

- removed (2017-03-08):
[0000936395-16-000115:note_history:22]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two is required to compare the implied fair value of the reporting unit’s goodwill with the carrying amount of the reporting unit’s goodwill. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

- removed (2017-03-08):
[0000936395-16-000115:note_history:23]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2016 and July 31, 2015 was 0.3% and 1.9%, respectively.

- removed (2017-03-08):
[0000936395-16-000115:note_history:24]
Government Grants

- removed (2017-03-08):
[0000936395-16-000115:note_history:25]
Ciena accounts for proceeds from government grants as a reduction of operating expense when there is reasonable assurance that Ciena has complied with the conditions attached to the grant and that the grant proceeds will be received. Grant benefits are recorded to the line item in the Condensed Consolidated Statement of Operations to which the grant activity relates.

- removed (2017-03-08):
[0000936395-16-000115:note_history:26]
In April 2015, FASB issued ASU No. 2015-03, Simplifying the Presentation of Debt Issuance Costs. ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. The guidance is effective retrospectively for fiscal years, and interim periods within those years, and will be effective for Ciena beginning in the first quarter of fiscal 2017. Ciena does not expect that the impact of the adoption of this ASU will be material to its Consolidated Financial Statements or disclosures.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:27]
Term Loans
  (was, 2016-09-07, similarity 0.72):
[0000936395-16-000115:note_history:27]
Term Loan due 2021

- changed (2017-03-08):
[0000936395-17-000020:note_history:28]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.
  (was, 2016-09-07, similarity 0.7098):
[0000936395-16-000115:note_history:28]
On July 15, 2014, Ciena entered into the Term Loan Credit Agreement providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan requires Ciena to make installment payments of approximately $0.6 million on a quarterly basis. The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):

- added (2017-03-08):
[0000936395-17-000020:note_history:29]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis. At the beginning of the second quarter of fiscal 2017, Ciena refinanced the 2019 Term Loan and the 2021 Term Loan. See Note 22 below.

- added (2017-03-08):
[0000936395-17-000020:note_history:30]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:31]
|  |  | January 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | 241,635 |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | 245,158 |  |  | 244,944 |  |
|  |  | $ | 486,793 |  |  | $ | 486,303 |  |
  (was, 2016-09-07, similarity 0.6259):
[0000936395-16-000115:note_history:31]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,192 |  |  | $ | 251,557 |  |

- added (2017-03-08):
[0000936395-17-000020:note_history:32]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $4.6 million at January 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.3 million and $0.2 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.

- changed (2017-03-08):
[0000936395-17-000020:note_history:33]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loans (in thousands):
  (was, 2016-09-07, similarity 0.9478):
[0000936395-16-000115:note_history:33]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:34]
|  |  | January 31, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019 (1) |  | $ | 241,635 |  |  | $ | 244,375 |  |
| Term Loan Payable due April 25, 2021(1) |  | 245,158 |  |  | 248,750 |  |
|  |  | $ | 486,793 |  |  | $ | 493,125 |  |
  (was, 2016-09-07, similarity 0.7262):
[0000936395-16-000115:note_history:34]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,144 |  |  | $ | 247,144 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:35]
| (1) | Includes unamortized bond discount and debt issuance costs. |
  (was, 2016-09-07, similarity 0.7895):
[0000936395-16-000115:note_history:35]
| (1) | Includes unamortized bond discount. |

- changed (2017-03-08):
[0000936395-17-000020:note_history:36]
| (2) | Ciena's term loans are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loans using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2016-09-07, similarity 0.8802):
[0000936395-16-000115:note_history:36]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- changed (2017-03-08):
[0000936395-17-000020:note_history:37]
During the first three months of fiscal 2017, Ciena entered into a private transaction to repurchase $46.3 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for an aggregate purchase price of $46.3 million.
  (was, 2016-09-07, similarity 0.6598):
[0000936395-16-000115:note_history:37]
During the first nine months of fiscal 2016, Ciena entered into certain private transactions to repurchase $43.5 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for cash purchase prices slightly below par. See Note 23 below for information regarding a repurchase transaction in the fourth quarter of fiscal 2016.

- added (2017-03-08):
[0000936395-17-000020:note_history:38]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:39]
|  |  | January 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 188,509 |  |
|  |  | $ | 723,084 |  |  | $ | 767,379 |  |
  (was, 2016-09-07, similarity 0.7299):
[0000936395-16-000115:note_history:39]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 450,465 |  |  | $ | 449,339 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,938 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 188,348 |  |  | 239,072 |  |
|  |  | $ | 988,813 |  |  | $ | 1,105,349 |  |

- added (2017-03-08):
[0000936395-17-000020:note_history:40]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $3.4 million at January 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.5 million and $0.7 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.

- changed (2017-03-08):
[0000936395-17-000020:note_history:41]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our 2020 notes were as follows as of January 31, 2017 (in thousands):
  (was, 2016-09-07, similarity 0.7328):
[0000936395-16-000115:note_history:41]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of July 31, 2016:

- changed (2017-03-08):
[0000936395-17-000020:note_history:42]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 202,160 |  |  | $ | (10,954 | ) |  | $ | (1,183 | ) |  | $190,023 |  | $ | 43,131 |  |
  (was, 2016-09-07, similarity 0.6):
[0000936395-16-000115:note_history:42]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 249,375 |  |  | $ | 1,183 |  |  | $ | 248,192 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:43]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2017:
  (was, 2016-09-07, similarity 0.9845):
[0000936395-16-000115:note_history:43]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2016:

- added (2017-03-08):
[0000936395-17-000020:note_history:44]
|  |  | January 31, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 184,563 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 471,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 264,759 |  |
|  |  | $ | 723,084 |  |  | $ | 920,510 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:45]
| (1) | Includes unamortized discount, accretion of principal and debt issuance costs. |
  (was, 2016-09-07, similarity 0.8129):
[0000936395-16-000115:note_history:45]
| (2) | Includes unamortized discount and accretion of principal. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:46]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amends the Credit Agreement (the "Term Loan Credit Agreement"), dated July 15, 2014. The Incremental Term Loan Credit Agreement provides for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The proceeds of approximately $246.1 million, net of fees and expenses, will initially supplement cash on the balance sheet and are expected to provide additional liquidity to contribute, in part, to the repayment of the outstanding principal amount owing under Ciena’s 0.875% senior convertible notes due June 15, 2017.

- removed (2017-03-08):
[0000936395-16-000115:note_history:47]
The 2021 Term Loan will, among other things:

- removed (2017-03-08):
[0000936395-16-000115:note_history:48]
| • | mature on April 25, 2021; |

- removed (2017-03-08):
[0000936395-16-000115:note_history:49]
| • | amortize in equal quarterly installments in aggregate amounts of $0.6 million (equal to 0.25% of the original principal amount), with the balance payable at maturity; |

- removed (2017-03-08):
[0000936395-16-000115:note_history:50]
| • | be subject to mandatory prepayment on the same basis as Ciena’s existing 2019 Term Loan under the Term Loan Credit Agreement; |

- removed (2017-03-08):
[0000936395-16-000115:note_history:51]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus a margin ranging from 3.25% to 3.50%, or (b) a base rate (subject to a floor of 1.75%) plus a margin ranging from 2.25% to 2.50%, in each case, with the actual margin determined according to Ciena’s total net leverage ratio; |

- removed (2017-03-08):
[0000936395-16-000115:note_history:52]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2021 Term Loan with proceeds of certain indebtedness prior to October 25, 2016 shall require a prepayment premium of 1% of the aggregate principal amount of such prepayment; and |

- removed (2017-03-08):
[0000936395-16-000115:note_history:53]
| • | except as described above or otherwise set forth in the Incremental Term Loan Credit Agreement, have identical terms as the existing 2019 Term Loan under the Term Loan Credit Agreement. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:54]
Except as amended by the Incremental Term Loan Credit Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

- removed (2017-03-08):
[0000936395-16-000115:note_history:55]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of July 31, 2016 (in thousands):

- removed (2017-03-08):
[0000936395-16-000115:note_history:56]
Term Loan due 2019

- removed (2017-03-08):
[0000936395-16-000115:note_history:57]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 245,000 |  |  | $ | 856 |  |  | $ | 244,144 |  |

- removed (2017-03-08):
[0000936395-16-000115:note_history:58]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

- removed (2017-03-08):
[0000936395-16-000115:note_history:59]
| (1) | Includes unamortized bond discount. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:60]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:61]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 200,315 |  |  | $ | 11,967 |  |  | $ | 188,348 |  |  | $ | 43,131 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:62]
|  | January 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 230,090 |  |  | $ | 60 |  |  | (46 | ) |  | $ | 230,104 |  |
| Included in long-term investments | 110,035 |  |  | 5 |  |  | (106 | ) |  | 109,934 |  |
|  | $ | 340,125 |  |  | $ | 65 |  |  | $ | (152 | ) |  | $ | 340,038 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,952 |  |  | — |  |  | — |  |  | $ | 19,952 |  |
|  | $ | 19,952 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,952 |  |
  (was, 2016-09-07, similarity 0.9934):
[0000936395-16-000115:note_history:62]
|  | July 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 265,168 |  |  | $ | 187 |  |  | (3 | ) |  | $ | 265,352 |  |
| Included in long-term investments | 115,182 |  |  | 186 |  |  | (2 | ) |  | 115,366 |  |
|  | $ | 380,350 |  |  | $ | 373 |  |  | $ | (5 | ) |  | $ | 380,718 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 29,970 |  |  | — |  |  | — |  |  | $ | 29,970 |  |
|  | $ | 29,970 |  |  | $ | — |  |  | $ | — |  |  | $ | 29,970 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:63]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | — |  |  | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |
  (was, 2016-09-07, similarity 0.9897):
[0000936395-16-000115:note_history:63]
|  | October 31, 2015 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 110,108 |  |  | $ | 10 |  |  | $ | — |  |  | $ | 110,118 |  |
| Included in long-term investments | 95,171 |  |  | — |  |  | (66 | ) |  | 95,105 |  |
|  | $ | 205,279 |  |  | $ | 10 |  |  | $ | (66 | ) |  | $ | 205,223 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 24,989 |  |  | — |  |  | — |  |  | $ | 24,989 |  |
|  | $ | 24,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 24,989 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:64]
The following table summarizes the final legal maturities of debt investments at January 31, 2017 (in thousands):
  (was, 2016-09-07, similarity 0.9765):
[0000936395-16-000115:note_history:64]
The following table summarizes the final legal maturities of debt investments at July 31, 2016 (in thousands):


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-03-08):
[0000936395-17-000020:note_history:65]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:66]
|  |  | January 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 188,509 |  |
|  |  | $ | 723,084 |  |  | $ | 767,379 |  |
  (was, 2016-09-07, similarity 0.7299):
[0000936395-16-000115:note_history:66]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(1) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 450,465 |  |  | $ | 449,339 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 350,000 |  |  | 416,938 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 (2) |  | 188,348 |  |  | 239,072 |  |
|  |  | $ | 988,813 |  |  | $ | 1,105,349 |  |

- added (2017-03-08):
[0000936395-17-000020:note_history:67]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:68]
|  |  | January 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | 241,635 |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | 245,158 |  |  | 244,944 |  |
|  |  | $ | 486,793 |  |  | $ | 486,303 |  |
  (was, 2016-09-07, similarity 0.6259):
[0000936395-16-000115:note_history:68]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due April 25, 2021(1) |  | $ | 248,192 |  |  | $ | 251,557 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:69]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2017:
  (was, 2016-09-07, similarity 0.9845):
[0000936395-16-000115:note_history:69]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of July 31, 2016:

- added (2017-03-08):
[0000936395-17-000020:note_history:70]
|  |  | January 31, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 184,563 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 471,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 264,759 |  |
|  |  | $ | 723,084 |  |  | $ | 920,510 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:71]
| (1) | Includes unamortized discount, accretion of principal and debt issuance costs. |
  (was, 2016-09-07, similarity 0.8129):
[0000936395-16-000115:note_history:71]
| (2) | Includes unamortized discount and accretion of principal. |

- changed (2017-03-08):
[0000936395-17-000020:note_history:72]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loans (in thousands):
  (was, 2016-09-07, similarity 0.9478):
[0000936395-16-000115:note_history:72]
The following table sets forth the carrying value and the estimated fair value of the 2021 Term Loan (in thousands):

- changed (2017-03-08):
[0000936395-17-000020:note_history:73]
|  |  | January 31, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019 (1) |  | $ | 241,635 |  |  | $ | 244,375 |  |
| Term Loan Payable due April 25, 2021(1) |  | 245,158 |  |  | 248,750 |  |
|  |  | $ | 486,793 |  |  | $ | 493,125 |  |
  (was, 2016-09-07, similarity 0.7262):
[0000936395-16-000115:note_history:73]
|  |  | July 31, 2016 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019(1) |  | $ | 244,144 |  |  | $ | 247,144 |  |

- changed (2017-03-08):
[0000936395-17-000020:note_history:74]
| (1) | Includes unamortized bond discount and debt issuance costs. |
  (was, 2016-09-07, similarity 0.7895):
[0000936395-16-000115:note_history:74]
| (1) | Includes unamortized bond discount. |

- changed (2017-03-08):
[0000936395-17-000020:note_history:75]
| (2) | Ciena's term loans are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loans using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |
  (was, 2016-09-07, similarity 0.8802):
[0000936395-16-000115:note_history:75]
| (2) | The 2021 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2021 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:76]
The principal balance, unamortized discount and net carrying amount of the 2021 Term Loan were as follows as of July 31, 2016 (in thousands):

- removed (2017-03-08):
[0000936395-16-000115:note_history:77]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due April 25, 2021 |  | $ | 249,375 |  |  | $ | 1,183 |  |  | $ | 248,192 |  |

- removed (2017-03-08):
[0000936395-16-000115:note_history:78]
The principal balance, unamortized discount and net carrying amount of the 2019 Term Loan were as follows as of July 31, 2016 (in thousands):

- removed (2017-03-08):
[0000936395-16-000115:note_history:79]
|  |  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |
| Term Loan Payable due July 15, 2019 |  | $ | 245,000 |  |  | $ | 856 |  |  | $ | 244,144 |  |

- removed (2017-03-08):
[0000936395-16-000115:note_history:80]
The following table sets forth the carrying value and the estimated fair value of the 2019 Term Loan (in thousands):

- removed (2017-03-08):
[0000936395-16-000115:note_history:81]
| (1) | Includes unamortized bond discount. |

- removed (2017-03-08):
[0000936395-16-000115:note_history:82]
| (2) | The 2019 Term Loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its 2019 Term Loan using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:ScheduleOfDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-03-08):
[0000936395-17-000020:note_history:83]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our 2020 notes were as follows as of January 31, 2017 (in thousands):
  (was, 2016-09-07, similarity 0.7328):
[0000936395-16-000115:note_history:83]
The principal balance, unamortized discount and net carrying amount of the liability and equity components of Ciena's 4.0% Convertible Senior Notes due December 15, 2020 are as follows as of July 31, 2016:

- added (2017-03-08):
[0000936395-17-000020:note_history:84]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 202,160 |  |  | $ | (10,954 | ) |  | $ | (1,183 | ) |  | $190,023 |  | $ | 43,131 |  |

- removed (2017-03-08):
[0000936395-16-000115:note_history:85]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 200,315 |  |  | $ | 11,967 |  |  | $ | 188,348 |  |  | $ | 43,131 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- removed (2017-03-08):
[0000936395-16-000115:note_history:86]
Ciena applies the percentage-of-completion method to long-term arrangements where Ciena is required to undertake significant production, customization or modification engineering, and reasonable and reliable estimates of revenue and cost are available. Utilizing the percentage-of-completion method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to total estimated costs expected to be incurred. In instances that do not meet the percentage-of-completion method criteria, recognition of revenue is deferred until there are no uncertainties regarding customer acceptance. Unbilled percentage-of-completion revenues recognized are included in accounts receivable, net. Billings in excess of revenues recognized on these contracts are recorded within deferred revenue. The percentage of total revenue recognized using the percentage-of-completion method for the nine months ended July 31, 2016 and July 31, 2015 was 0.3% and 1.9%, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2017-03-08):
[0000936395-17-000020:note_history:87]
Under the Term Loan Credit Agreement, Ciena had two existing term loan tranches, the 2019 Term Loan, with an outstanding aggregate principal amount of $244.4 million, and the 2021 Term Loan, with an outstanding aggregate principal amount of $248.8 million (together, the “Existing Term Loans”).

- added (2017-03-08):
[0000936395-17-000020:note_history:88]
Following the end of our first quarter of fiscal 2017, on January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced the Existing Term Loans into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena repaid $93.1 million of outstanding principal under the Existing Term Loans, and the remaining balances under the Existing Term Loans were refinanced and replaced by the 2022 Term Loan. The Refinancing Agreement amends the Term Loan Credit Agreement and provides that the 2022 Term Loan will, among other things:

- added (2017-03-08):
[0000936395-17-000020:note_history:89]
| • | mature on January 30, 2022; |

- added (2017-03-08):
[0000936395-17-000020:note_history:90]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2022 Term Loan as of January 30, 2017, with the balance payable at maturity; |

- added (2017-03-08):
[0000936395-17-000020:note_history:91]
| • | be subject to mandatory prepayment on the same basis as the Existing Term Loans under the Term Loan Credit Agreement; |

- added (2017-03-08):
[0000936395-17-000020:note_history:92]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

- added (2017-03-08):
[0000936395-17-000020:note_history:93]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

- added (2017-03-08):
[0000936395-17-000020:note_history:94]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.

- removed (2017-03-08):
[0000936395-16-000115:note_history:95]
On August 5, 2016, Ciena repurchased approximately $205 million in aggregate principal amount of its outstanding 0.875% Convertible Senior Notes due 2017 (the “2017 Notes”) in a private transaction, for an aggregate purchase price of approximately $205 million, inclusive of accrued interest. Following the transaction, $245.3 million in aggregate principal amount of the 2017 Notes remain outstanding.
