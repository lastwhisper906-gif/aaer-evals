# CIEN notes — 0000936395-17-000020


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-17-000020:notes:1]
ABL CREDIT FACILITY

[0000936395-17-000020:notes:2]
Ciena Corporation and certain of its subsidiaries are parties to a senior secured asset-based revolving credit facility (the “ABL Credit Facility”). Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-17-000020:notes:3]
As of January 31, 2017, letters of credit totaling $71.3 million were collateralized by the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of January 31, 2017.


## cien:ConcentrationRiskDisclosurePolicyTextBlock

[0000936395-17-000020:notes:4]
[same as prior period, unchanged from 0000936395-16-000115:notes:9]

[0000936395-17-000020:notes:5]
Historically, a significant percentage of Ciena's revenue has been concentrated among sales to a small number of large communications service providers. Consolidation among Ciena's customers has increased this concentration. Consequently, Ciena's accounts receivable are concentrated among these customers. See Note 20 below.

[0000936395-17-000020:notes:6]
[same as prior period, unchanged from 0000936395-16-000115:notes:11]


## cien:MaintenanceSparesPolicyTextBlock

[0000936395-17-000020:notes:7]
[same as prior period, unchanged from 0000936395-16-000115:notes:13]


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-17-000020:notes:8]
[same as prior period, unchanged from 0000936395-16-000115:notes:14]

[0000936395-17-000020:notes:9]
[same as prior period, unchanged from 0000936395-16-000115:notes:15]

[0000936395-17-000020:notes:10]
|  | January 31, 2017 |  | October 31, 2016 |
| Prepaid VAT and other taxes | $ | 74,598 |  |  | $ | 77,474 |  |
| Product demonstration equipment, net | 38,766 |  |  | 42,259 |  |
| Deferred deployment expense | 18,607 |  |  | 19,138 |  |
| Prepaid expenses | 24,343 |  |  | 25,659 |  |
| Other non-trade receivables | 9,388 |  |  | 4,398 |  |
| Financing receivable | 7,779 |  |  | 3,740 |  |
| Derivative assets | 361 |  |  | 175 |  |
|  | $ | 173,842 |  |  | $ | 172,843 |  |

[0000936395-17-000020:notes:11]
Depreciation of product demonstration equipment was $2.4 million and $2.5 million for the first three months of fiscal 2017 and 2016, respectively.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-17-000020:notes:12]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-17-000020:notes:13]
Term Loans

[0000936395-17-000020:notes:14]
On July 15, 2014, Ciena entered into a Term Loan Credit Agreement (the "Term Loan Credit Agreement") providing for senior secured term loans in an aggregate principal amount of $250 million (the “2019 Term Loan”) with a maturity date of July 15, 2019. The 2019 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis.

[0000936395-17-000020:notes:15]
On April 25, 2016, Ciena entered into an Incremental Joinder and Amendment Agreement (the “Incremental Term Loan Credit Agreement”) that amended the Term Loan Credit Agreement. The Incremental Term Loan Credit Agreement provided for a new tranche of senior secured term loans under the Term Loan Credit Agreement in an aggregate principal amount of $250 million (the “2021 Term Loan”). The 2021 Term Loan required Ciena to make installment payments of approximately $0.6 million on a quarterly basis. At the beginning of the second quarter of fiscal 2017, Ciena refinanced the 2019 Term Loan and the 2021 Term Loan. See Note 22 below.

[0000936395-17-000020:notes:16]
The net carrying amount of Ciena's term loans were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000020:notes:17]
|  |  | January 31, 2017 |  | October 31, 2016 |
| Term Loan Payable due July 15, 2019 |  | $ | 241,635 |  |  | $ | 241,359 |  |
| Term Loan Payable due April 25, 2021 |  | 245,158 |  |  | 244,944 |  |
|  |  | $ | 486,793 |  |  | $ | 486,303 |  |

[0000936395-17-000020:notes:18]
The term loan balances in the table above reflect Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the term loans totaled $4.6 million at January 31, 2017 and $4.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loans. The amortization of deferred debt issuance costs for these term loans are included in interest expense, and was $0.3 million and $0.2 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the term loans listed above are also net of any unamortized discounts.

[0000936395-17-000020:notes:19]
The following table sets forth the carrying value and the estimated fair values of Ciena's term loans (in thousands):

[0000936395-17-000020:notes:20]
|  |  | January 31, 2017 |
|  |  | Carrying Value |  | Fair Value(2) |
| Term Loan Payable due July 15, 2019 (1) |  | $ | 241,635 |  |  | $ | 244,375 |  |
| Term Loan Payable due April 25, 2021(1) |  | 245,158 |  |  | 248,750 |  |
|  |  | $ | 486,793 |  |  | $ | 493,125 |  |

[0000936395-17-000020:notes:21]
| (1) | Includes unamortized bond discount and debt issuance costs. |

[0000936395-17-000020:notes:22]
| (2) | Ciena's term loans are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loans using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |

[0000936395-17-000020:notes:23]
Outstanding Convertible Notes Payable

[0000936395-17-000020:notes:24]
During the first three months of fiscal 2017, Ciena entered into a private transaction to repurchase $46.3 million of the outstanding principal amount of its 0.875% Convertible Senior Notes due June 15, 2017, for an aggregate purchase price of $46.3 million.

[0000936395-17-000020:notes:25]
The net carrying amount of Ciena's outstanding convertible notes payable was comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-17-000020:notes:26]
|  |  | January 31, 2017 |  | October 31, 2016 |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 231,240 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 347,630 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 188,509 |  |
|  |  | $ | 723,084 |  |  | $ | 767,379 |  |

[0000936395-17-000020:notes:27]
The convertible notes payable balances in the table above reflects Ciena's adoption of ASU 2015-03, as described in Note 2 above. Deferred debt issuance costs that were deducted from the carrying amounts of the convertible notes payable totaled $3.4 million at January 31, 2017 and $3.9 million at October 31, 2016. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the convertible notes payable. The amortization of deferred debt issuance costs is included in interest expense, and was $0.5 million and $0.7 million during the first three months of fiscal 2017 and 2016, respectively. The carrying amounts of the convertible notes payable listed above are also net of any unamortized discounts.

[0000936395-17-000020:notes:28]
The principal balance, unamortized discount, deferred debt issuance costs and net carrying value of the liability and equity components of our 2020 notes were as follows as of January 31, 2017 (in thousands):

[0000936395-17-000020:notes:29]
|  | Liability Component |  | Equity Component |
|  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Amount |  | Net Carrying Amount |
| 4.0% Convertible Senior Notes due December 15, 2020 | $ | 202,160 |  |  | $ | (10,954 | ) |  | $ | (1,183 | ) |  | $190,023 |  | $ | 43,131 |  |

[0000936395-17-000020:notes:30]
The following table sets forth, in thousands, the carrying value and the estimated fair value of Ciena’s outstanding issues of convertible notes as of January 31, 2017:

[0000936395-17-000020:notes:31]
|  |  | January 31, 2017 |
|  |  | Carrying Value (1) |  | Fair Value(2) |
| 0.875% Convertible Senior Notes due June 15, 2017 |  | $ | 185,122 |  |  | $ | 184,563 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 |  | 347,939 |  |  | 471,188 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 |  | 190,023 |  |  | 264,759 |  |
|  |  | $ | 723,084 |  |  | $ | 920,510 |  |

[0000936395-17-000020:notes:32]
| (1) | Includes unamortized discount, accretion of principal and debt issuance costs. |

[0000936395-17-000020:notes:33]
| (2) | The convertible notes are categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its outstanding convertible notes using a market approach based upon observable inputs, such as current market transactions involving comparable securities. |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000936395-17-000020:notes:34]
[same as prior period, unchanged from 0000936395-16-000115:notes:49]


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000936395-17-000020:notes:35]
[same as prior period, unchanged from 0000936395-16-000115:notes:58]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-17-000020:notes:36]
COMMITMENTS AND CONTINGENCIES

[0000936395-17-000020:notes:37]
Foreign Tax Contingencies

[0000936395-17-000020:notes:38]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-17-000020:notes:39]
Litigation

[0000936395-17-000020:notes:40]
From May 15 through June 3, 2015, five separate putative class action lawsuits in connection with Ciena’s then-pending acquisition of Cyan, Inc. (“Cyan”) were filed in the Court of Chancery of the State of Delaware. On June 23, 2015, each of these lawsuits was consolidated into a single case captioned In Re Cyan, Inc. Shareholder Litigation, Consol. C.A. No. 11027-CB. On July 9, 2015, the plaintiffs filed a verified amended class action complaint, which named as defendants Ciena, a Ciena subsidiary created solely for the purpose of effecting the acquisition (“Merger Sub”), and the members of Cyan’s board of directors. On August 5, 2015, the defendants filed motions to dismiss the amended complaint. On October 1, 2015, the plaintiffs filed a second amended complaint which named as defendants the members of Cyan’s board of directors. Cyan, Ciena, and Merger Sub were not named as defendants. On July 15, 2016, the plaintiffs filed a third amended complaint, which generally alleges that the Cyan board members breached their fiduciary duties by engaging in a conflicted and unfair sales process, failing to maximize stockholder value in the acquisition, taking steps to preclude competitive bidding, and failing to disclose material information necessary for stockholders to make an informed decision regarding the acquisition. The third amended complaint seeks (i) a declaration that the plaintiffs are entitled to a quasi-appraisal remedy, (ii) rescissory damages, (iii) recovery through an accounting of all damages caused as a result of the alleged breaches of fiduciary duties, (iv) compensatory damages, and (v) costs including attorneys’ fees and experts’ fees. On August 5, 2016, the defendants filed a motion to dismiss the third amended complaint. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-17-000020:notes:41]
As a result of the acquisition of Cyan in August 2015, Ciena became a defendant in a securities class action lawsuit. On April 1, 2014, a purported stockholder class action lawsuit was filed in the Superior Court of California, County of San Francisco, against Cyan, the members of Cyan’s board of directors, Cyan’s former Chief Financial Officer, and the underwriters of Cyan’s initial public offering. On April 30, 2014, a substantially similar lawsuit was filed in the same court against the same defendants. The two cases have been consolidated as Beaver County Employees Retirement Fund, et al. v. Cyan, Inc. et al., Case No. CGC-14-538355. The consolidated complaint alleges violations of federal securities laws on behalf of a purported class consisting of purchasers of Cyan’s common stock pursuant or traceable to the registration statement and prospectus for Cyan’s initial public offering in April 2013, and seeks unspecified compensatory damages and other relief. On May 19, 2015, the proposed class was certified. On August 25, 2015, the defendants filed a motion for judgment on the pleadings based on an alleged lack of subject matter jurisdiction over the case, which motion was denied on October 23, 2015. On May 24, 2016, the defendants filed a petition for a writ of certiorari on the jurisdiction issue with the United States Supreme Court, to which the plaintiffs filed a brief in opposition. On November 18, 2016, the parties each filed motions for summary judgment. Ciena believes that the consolidated lawsuit is without merit and intends to defend it vigorously.

[0000936395-17-000020:notes:42]
On May 29, 2008, Graywire, LLC filed a complaint in the United States District Court for the Northern District of Georgia against Ciena and four other defendants, alleging, among other things, that certain of the parties’ products infringe U.S. Patent 6,542,673 (the “’673 Patent”), relating to an identifier system and components for optical assemblies. The complaint seeks injunctive relief and damages. In July 2009, upon request of Ciena and certain other defendants, the U.S. Patent and Trademark Office (“PTO”) granted the defendants’ inter partes application for reexamination with respect to certain claims of the ‘673 Patent, and the district court granted the defendants’ motion to stay the case pending reexamination of all of the patents-in-suit. In December 2010, the PTO confirmed the validity of some claims and rejected the validity of other claims of the ‘673 Patent, to which Ciena and other defendants filed an appeal. On March 16, 2012, the PTO on appeal rejected multiple claims of the ‘673 Patent, including the two claims on which Ciena is alleged to infringe. Subsequently, the plaintiff requested a reopening of the prosecution of the ‘673 Patent, which request was denied by the PTO on April 29, 2013. Thereafter, on May 28, 2013, the plaintiff filed an amendment with the PTO in which it canceled the claims of the ‘673 Patent on which Ciena is alleged to infringe. The case currently remains stayed, and there can be no assurance as to whether or when the stay will be lifted.

[0000936395-17-000020:notes:43]
In addition to the matters described above, Ciena is subject to various legal proceedings and claims arising in the ordinary course of business, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve these matters will have a material effect on its results of operations, financial position or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000936395-17-000020:notes:44]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena's ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-17-000020:notes:45]
[same as prior period, unchanged from 0000936395-16-000115:notes:68]

[0000936395-17-000020:notes:46]
The following table summarizes the changes in accumulated balances of other comprehensive income ("AOCI") for the three months ending January 31, 2017:

[0000936395-17-000020:notes:47]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2016 | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive income (loss) before reclassifications | (249 | ) |  | 1,031 |  |  | 4,044 |  |  | 490 |  |  | 5,316 |  |
| Amounts reclassified from AOCI | — |  |  | 394 |  |  | 448 |  |  | — |  |  | 842 |  |
| Balance at January 31, 2017 | $ | (110 | ) |  | $ | 334 |  |  | $ | (1,475 | ) |  | $ | (16,920 | ) |  | $ | (18,171 | ) |

[0000936395-17-000020:notes:48]
The following table summarizes the changes in AOCI for the three months ending January 31, 2016:

[0000936395-17-000020:notes:49]
|  | Unrealized |  | Unrealized |  | Unrealized |  | Cumulative |  |  |
|  | Gain/(Loss) on |  | Gain/(Loss) on |  | Gain/(Loss) on Forward |  | Foreign Currency |  |  |
|  | Marketable Securities |  | Foreign Currency Contracts |  | Starting Interest Rate Swap |  | Translation Adjustment |  | Total |
| Balance at October 31, 2015 | $ | (78 | ) |  | $ | (268 | ) |  | (5,522 | ) |  | $ | (16,258 | ) |  | $ | (22,126 | ) |
| Other comprehensive income (loss) before reclassifications | 22 |  |  | (3,191 | ) |  | (1,120 | ) |  | (2,823 | ) |  | (7,112 | ) |
| Amounts reclassified from AOCI | — |  |  | 671 |  |  | 791 |  |  | — |  |  | 1,462 |  |
| Balance at January 31, 2016 | $ | (56 | ) |  | $ | (2,788 | ) |  | $ | (5,851 | ) |  | $ | (19,081 | ) |  | $ | (27,776 | ) |

[0000936395-17-000020:notes:50]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted research and development expense on the Condensed Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Condensed Consolidated Statements of Operations.


## us-gaap:CostsAssociatedWithExitOrDisposalActivitiesOrRestructuringsPolicyTextBlock

[0000936395-17-000020:notes:51]
[same as prior period, unchanged from 0000936395-16-000115:notes:74]


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000936395-17-000020:notes:52]
[same as prior period, unchanged from 0000936395-16-000115:notes:75]

[0000936395-17-000020:notes:53]
|  | January 31, 2017 |  | October 31, 2016 |
| Products | $ | 48,766 |  |  | $ | 45,216 |  |
| Services | 143,170 |  |  | 137,647 |  |
|  | 191,936 |  |  | 182,863 |  |
| Less current portion | (113,371 | ) |  | (109,009 | ) |
| Long-term deferred revenue | $ | 78,565 |  |  | $ | 73,854 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-17-000020:notes:54]
[same as prior period, unchanged from 0000936395-16-000115:notes:77]

[0000936395-17-000020:notes:55]
[same as prior period, unchanged from 0000936395-16-000115:notes:78]

[0000936395-17-000020:notes:56]
As of January 31, 2017 and October 31, 2016, Ciena had forward contracts in place to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally related to its research and development activities. The notional amount of these contracts was approximately $83.1 million and $107.6 million as of January 31, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have been designated as cash flow hedges.

[0000936395-17-000020:notes:57]
During the first three months of fiscal 2017 and fiscal 2016, in order to hedge certain balance sheet exposures, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar and Mexican Peso. The notional amount of these contracts was approximately $57.8 million and $59.6 million as of January 31, 2017 and October 31, 2016, respectively. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-17-000020:notes:58]
[same as prior period, unchanged from 0000936395-16-000115:notes:81]

[0000936395-17-000020:notes:59]
During fiscal 2014, Ciena entered into floating interest rate to fixed interest rate swap arrangements ("interest rate swaps") that fixed the interest rate under the 2019 Term Loan (as defined in Note 16) at 5.004% for the period commencing on July 20, 2015 through July 19, 2018. The total notional amount of these derivatives as of January 31, 2017 and October 31, 2016 was $243.8 million and $244.4 million, respectively.

[0000936395-17-000020:notes:60]
In May 2016, Ciena entered into interest rate swaps that fixed the total interest rate under the 2021 Term Loan (as defined in Note 16) at 4.62% to 4.87%, depending on the applicable margin, for the period commencing on June 20, 2016 through June 22, 2020. The total notional amount of these derivatives as of January 31, 2017 and October 31, 2016 was $148.9 million and $248.8 million, respectively.

[0000936395-17-000020:notes:61]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to exactly offset the forecasted variable rate payments on the equivalent notional amounts of the term loans. These derivative contracts have been designated as cash flow hedges.

[0000936395-17-000020:notes:62]
Other information regarding Ciena's derivatives is immaterial for separate financial statement presentation. See Note 4 and Note 6 above.


## us-gaap:DerivativesPolicyTextBlock

[0000936395-17-000020:notes:63]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 12 months or less. Ciena also has interest rate hedge arrangements to reduce variability in certain forecasted interest expense associated with its term loans. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The effective portion of the derivative's net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Condensed Consolidated Statement of Operations to which the hedged transaction relates. Any net gain or loss associated with the ineffectiveness of the hedging instrument is reported in interest and other income (loss), net. To date, no ineffectiveness has occurred.

[0000936395-17-000020:notes:64]
[same as prior period, unchanged from 0000936395-16-000115:notes:87]

[0000936395-17-000020:notes:65]
[same as prior period, unchanged from 0000936395-16-000115:notes:88]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-17-000020:notes:66]
[same as prior period, unchanged from 0000936395-16-000115:notes:89]

[0000936395-17-000020:notes:67]
Ciena has outstanding equity awards issued under its 2008 Omnibus Incentive Plan, as well as certain legacy equity plans and equity plans assumed as a result of previous acquisitions. Ciena grants equity awards under its 2008 Omnibus Incentive Plan (the "2008 Plan") and makes shares of its common stock available for purchase under its Amended and Restated Employee Stock Purchase Plan (the “ESPP”). These plans were approved by stockholders and are described below.

[0000936395-17-000020:notes:68]
[same as prior period, unchanged from 0000936395-16-000115:notes:91]

[0000936395-17-000020:notes:69]
The 2008 Plan authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2008 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2008 Plan to vest, unless the awards are continued or substituted for in connection with the transaction. The total number of shares authorized for issuance under the 2008 Plan is 25.1 million shares. As of January 31, 2017, approximately 1.4 million shares remained available for issuance under the 2008 Plan.

[0000936395-17-000020:notes:70]
[same as prior period, unchanged from 0000936395-16-000115:notes:93]

[0000936395-17-000020:notes:71]
[same as prior period, unchanged from 0000936395-16-000115:notes:94]

[0000936395-17-000020:notes:72]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance at October 31, 2016 | 1,387 |  |  | $ | 26.90 |  |
| Exercised | (102 | ) |  | 9.58 |  |
| Canceled | (187 | ) |  | 27.52 |  |
| Balance at January 31, 2017 | 1,098 |  |  | $ | 28.41 |  |

[0000936395-17-000020:notes:73]
The total intrinsic value of options exercised during the first three months of fiscal 2017 and fiscal 2016 was $1.5 million and $1.7 million, respectively. Ciena did not grant any stock options during the first three months of fiscal 2017 or fiscal 2016.

[0000936395-17-000020:notes:74]
The following table summarizes information with respect to stock options outstanding at January 31, 2017, based on Ciena’s closing stock price on the last trading day of Ciena’s first fiscal quarter of 2017 (shares and intrinsic value in thousands):

[0000936395-17-000020:notes:75]
|  |  |  |  |  |  | Options Outstanding at |  | Vested Options at |
|  |  |  |  |  |  | January 31, 2017 |  | January 31, 2017 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 0.45 |  |  | — |  |  | $ | 11.16 |  |  | 112 |  |  | 2.73 |  | $ | 7.48 |  |  | $ | 1,913 |  |  | 110 |  |  | 2.68 |  | $ | 7.45 |  |  | $ | 1,896 |  |
| $ | 11.34 |  |  | — |  |  | $ | 17.24 |  |  | 242 |  |  | 5.35 |  | 13.31 |  |  | 2,736 |  |  | 231 |  |  | 5.24 |  | 13.23 |  |  | 2,631 |  |
| $ | 17.50 |  |  | — |  |  | $ | 30.46 |  |  | 178 |  |  | 1.93 |  | 26.02 |  |  | 257 |  |  | 165 |  |  | 1.48 |  | 26.61 |  |  | 179 |  |
| $ | 31.93 |  |  | — |  |  | $ | 37.10 |  |  | 323 |  |  | 2.10 |  | 35.19 |  |  | — |  |  | 322 |  |  | 2.09 |  | 35.18 |  |  | — |  |
| $ | 37.82 |  |  | — |  |  | $ | 55.63 |  |  | 243 |  |  | 4.48 |  | 45.84 |  |  | — |  |  | 227 |  |  | 4.34 |  | 45.87 |  |  | — |  |
| $ | 0.45 |  |  | — |  |  | $ | 55.63 |  |  | 1,098 |  |  | 3.38 |  | $ | 28.41 |  |  | $ | 4,906 |  |  | 1,055 |  |  | 3.23 |  | $ | 28.42 |  |  | $ | 4,706 |  |

[0000936395-17-000020:notes:76]
[same as prior period, unchanged from 0000936395-16-000115:notes:99]

[0000936395-17-000020:notes:77]
[same as prior period, unchanged from 0000936395-16-000115:notes:100]

[0000936395-17-000020:notes:78]
[same as prior period, unchanged from 0000936395-16-000115:notes:101]

[0000936395-17-000020:notes:79]
[same as prior period, unchanged from 0000936395-16-000115:notes:102]

[0000936395-17-000020:notes:80]
[same as prior period, unchanged from 0000936395-16-000115:notes:103]

[0000936395-17-000020:notes:81]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverage GrantDate Fair ValuePer Share |  | AggregateFair Value |
| Balance at October 31, 2016 | 4,280 |  |  | $ | 19.96 |  |  | $ | 83,511 |  |
| Granted | 1,849 |  |  |  |  |  |
| Vested | (865 | ) |  |  |  |  |
| Canceled or forfeited | (111 | ) |  |  |  |  |
| Balance at January 31, 2017 | 5,153 |  |  | $ | 21.10 |  |  | $ | 126,808 |  |

[0000936395-17-000020:notes:82]
The total fair value of restricted stock units that vested and were converted into common stock during the first three months of fiscal 2017 and fiscal 2016 was $21.4 million and $23.9 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during the first three months of fiscal 2017 and fiscal 2016 was $23.08 and $19.84 respectively.

[0000936395-17-000020:notes:83]
[same as prior period, unchanged from 0000936395-16-000115:notes:106]

[0000936395-17-000020:notes:84]
[same as prior period, unchanged from 0000936395-16-000115:notes:107]

[0000936395-17-000020:notes:85]
[same as prior period, unchanged from 0000936395-16-000115:notes:108]

[0000936395-17-000020:notes:86]
[same as prior period, unchanged from 0000936395-16-000115:notes:109]

[0000936395-17-000020:notes:87]
[same as prior period, unchanged from 0000936395-16-000115:notes:110]

[0000936395-17-000020:notes:88]
Under the ESPP, eligible employees may enroll in a 12-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP's “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to approximately 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million shares. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-17-000020:notes:89]
During the first three months of fiscal 2017, Ciena issued 0.5 million shares under the ESPP. At January 31, 2017, 5.4 million shares remained available for issuance under the ESPP.

[0000936395-17-000020:notes:90]
[same as prior period, unchanged from 0000936395-16-000115:notes:113]

[0000936395-17-000020:notes:91]
[same as prior period, unchanged from 0000936395-16-000115:notes:114]

[0000936395-17-000020:notes:92]
|  | Quarter Ended January 31, |  |
|  | 2017 |  | 2016 |  |
| Product costs | $ | 561 |  |  | $ | 571 |  |  |
| Service costs | 628 |  |  | 592 |  |  |
| Share-based compensation expense included in cost of sales | 1,189 |  |  | 1,163 |  |  |
| Research and development | 3,209 |  |  | 3,428 |  |  |
| Sales and marketing | 2,873 |  |  | 4,735 |  |  |
| General and administrative | 5,453 |  |  | 5,129 |  |  |
| Acquisition and integration costs | — |  |  | 17 |  |  |
| Share-based compensation expense included in operating expense | 11,535 |  |  | 13,309 |  |  |
| Share-based compensation expense capitalized in inventory, net | 101 |  |  | 5 |  |  |
| Total share-based compensation | $ | 12,825 |  |  | $ | 14,477 |  |  |

[0000936395-17-000020:notes:93]
As of January 31, 2017, total unrecognized share-based compensation expense was approximately $95.9 million: (i) $0.4 million, which relates to unvested stock options and is expected to be recognized over a weighted-average period of 1.3 years; and (ii) $95.5 million,which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.6 years.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000936395-17-000020:notes:94]
[same as prior period, unchanged from 0000936395-16-000115:notes:117]


## us-gaap:EarningsPerShareTextBlock

[0000936395-17-000020:notes:95]
[same as prior period, unchanged from 0000936395-16-000115:notes:118]

[0000936395-17-000020:notes:96]
The following table (in thousands except per share amounts) is a reconciliation of the numerator and denominator of the basic net income per common share (“Basic EPS”) and the diluted net income per potential common share (“Diluted EPS”). Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding; (ii) shares issuable upon vesting of restricted stock units; (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method; and (iv) shares underlying Ciena’s outstanding convertible notes.

[0000936395-17-000020:notes:97]
|  | Quarter Ended January 31, |
| Numerator | 2017 |  | 2016 |
| Net income (loss) | $ | 3,861 |  |  | $ | (11,546 | ) |
| Net income (loss) used to calculate Diluted EPS | $ | 3,861 |  |  | $ | (11,546 | ) |

[0000936395-17-000020:notes:98]
|  | Quarter Ended January 31, |
| Denominator | 2017 |  | 2016 |
| Basic weighted average shares outstanding | 140,682 |  |  | 136,675 |  |
| Add: Shares underlying outstanding stock options and restricted stock units and issuable under employee stock purchase plan | 1,502 |  |  | — |  |
| Dilutive weighted average shares outstanding | 142,184 |  |  | 136,675 |  |

[0000936395-17-000020:notes:99]
|  | Quarter Ended January 31, |
| EPS | 2017 |  | 2016 |
| Basic EPS | $ | 0.03 |  |  | $ | (0.08 | ) |
| Diluted EPS | $ | 0.03 |  |  | $ | (0.08 | ) |

[0000936395-17-000020:notes:100]
[same as prior period, unchanged from 0000936395-16-000115:notes:123]

[0000936395-17-000020:notes:101]
|  | Quarter Ended January 31, |
|  | 2017 |  | 2016 |
| Shares underlying stock options and restricted stock units | 1,556 |  |  | 3,565 |  |
| 0.875% Convertible Senior Notes due June 15, 2017 | 5,564 |  |  | 12,912 |  |
| 3.75% Convertible Senior Notes due October 15, 2018 | 17,355 |  |  | 17,355 |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | 9,198 |  |  | 9,198 |  |
| Total shares excluded due to anti-dilutive effect | 33,673 |  |  | 43,030 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0000936395-17-000020:notes:102]
[same as prior period, unchanged from 0000936395-16-000115:notes:125]

[0000936395-17-000020:notes:103]
|  | January 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 529,967 |  |  | $ | — |  |  | $ | — |  |  | $ | 529,967 |  |
| U.S. government obligations | — |  |  | 340,038 |  |  | — |  |  | 340,038 |  |
| Commercial paper | — |  |  | 39,925 |  |  | — |  |  | 39,925 |  |
| Foreign currency forward contracts | — |  |  | 361 |  |  | — |  |  | 361 |  |
| Total assets measured at fair value | $ | 529,967 |  |  | $ | 380,324 |  |  | $ | — |  |  | $ | 910,291 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 496 |  |  | $ | — |  |  | $ | 496 |  |
| Forward starting interest rate swap | — |  |  | 1,475 |  |  | — |  |  | 1,475 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,971 |  |  | $ | — |  |  | $ | 1,971 |  |

[0000936395-17-000020:notes:104]
|  | October 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 625,277 |  |  | $ | — |  |  | $ | — |  |  | $ | 625,277 |  |
| U.S. government obligations | — |  |  | 350,431 |  |  | — |  |  | 350,431 |  |
| Commercial paper | — |  |  | 69,959 |  |  | — |  |  | 69,959 |  |
| Foreign currency forward contracts | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Total assets measured at fair value | $ | 625,277 |  |  | $ | 420,565 |  |  | $ | — |  |  | $ | 1,045,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 1,396 |  |  | $ | — |  |  | $ | 1,396 |  |
| Forward starting interest rate swap | — |  |  | 5,967 |  |  | — |  |  | 5,967 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,363 |  |  | $ | — |  |  | $ | 7,363 |  |


## us-gaap:FairValueByBalanceSheetGroupingTextBlock

[0000936395-17-000020:notes:105]
[same as prior period, unchanged from 0000936395-16-000115:notes:128]

[0000936395-17-000020:notes:106]
|  | January 31, 2017 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 529,967 |  |  | $ | 19,973 |  |  | $ | — |  |  | $ | 549,940 |  |
| Short-term investments | — |  |  | 250,056 |  |  | — |  |  | 250,056 |  |
| Prepaid expenses and other | — |  |  | 361 |  |  | — |  |  | 361 |  |
| Long-term investments | — |  |  | 109,934 |  |  | — |  |  | 109,934 |  |
| Total assets measured at fair value | $ | 529,967 |  |  | $ | 380,324 |  |  | $ | — |  |  | $ | 910,291 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 496 |  |  | $ | — |  |  | $ | 496 |  |
| Other long-term obligations | — |  |  | 1,475 |  |  | — |  |  | 1,475 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 1,971 |  |  | $ | — |  |  | $ | 1,971 |  |

[0000936395-17-000020:notes:107]
|  | October 31, 2016 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 625,277 |  |  | $ | 54,970 |  |  | $ | — |  |  | $ | 680,247 |  |
| Short-term investments | — |  |  | 275,248 |  |  | — |  |  | 275,248 |  |
| Prepaid expenses and other | — |  |  | 175 |  |  | — |  |  | 175 |  |
| Long-term investments | — |  |  | 90,172 |  |  | — |  |  | 90,172 |  |
| Total assets measured at fair value | $ | 625,277 |  |  | $ | 420,565 |  |  | $ | — |  |  | $ | 1,045,842 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 1,396 |  |  | $ | — |  |  | $ | 1,396 |  |
| Other long-term obligations | — |  |  | 5,967 |  |  | — |  |  | 5,967 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 7,363 |  |  | $ | — |  |  | $ | 7,363 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-17-000020:notes:108]
[same as prior period, unchanged from 0000936395-16-000115:notes:131]

[0000936395-17-000020:notes:109]
[same as prior period, unchanged from 0000936395-16-000115:notes:132]


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000936395-17-000020:notes:110]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-17-000020:notes:111]
[same as prior period, unchanged from 0000936395-16-000115:notes:134]

[0000936395-17-000020:notes:112]
The following table presents the goodwill allocated to Ciena's applicable reportable segments as of the dates indicated (in thousands):

[0000936395-17-000020:notes:113]
|  |  | Balance at October 31, 2016 |  | Acquisitions |  | Impairments |  | Translation |  | Balance at January 31, 2017 |
| Software and Software-Related Services |  | $ | 201,428 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 201,428 |  |
| Networking Platforms |  | 65,546 |  |  | — |  |  | — |  |  | 195 |  |  | 65,741 |  |
| Total |  | $ | 266,974 |  |  | $ | — |  |  | $ | — |  |  | $ | 195 |  |  | $ | 267,169 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000936395-17-000020:notes:114]
[same as prior period, unchanged from 0000936395-16-000115:notes:138]


## us-gaap:IncomeTaxPolicyTextBlock

[0000936395-17-000020:notes:115]
[same as prior period, unchanged from 0000936395-16-000115:notes:139]

[0000936395-17-000020:notes:116]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2010 and 2012 through 2014 and in Canada for 2011 through 2013. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2013), United Kingdom (2014), Canada (2011) India (2010) and Brazil (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-17-000020:notes:117]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest cumulative unremitted foreign earnings outside the U.S., and it is not practicable to determine the unrecognized deferred income taxes. These cumulative unremitted foreign earnings relate to ongoing operations in foreign jurisdictions and are required to fund foreign operations, capital expenditures and future expansion requirements. See Note 21 below.

[0000936395-17-000020:notes:118]
Ciena recognizes windfall tax benefits associated with the exercise of stock options or release of restricted stock units directly to stockholders’ equity only when realized. A windfall tax benefit occurs when the actual tax benefit realized by Ciena upon an employee’s disposition of a share-based award exceeds the deferred tax asset, if any, associated with the award that Ciena had recorded. When assessing whether a tax benefit relating to share-based compensation has been realized, Ciena follows the “with-and-without” method. Under the with-and-without method, the windfall is considered realized and recognized for financial statement purposes only when an incremental benefit is provided after considering all other tax benefits including Ciena’s net operating losses. The with-and-without method results in the windfall from share-based compensation awards always being effectively the last tax benefit to be considered. Consequently, the windfall attributable to share-based compensation will not be considered realized in instances where Ciena’s net operating loss carryover (that is unrelated to windfalls) is sufficient to offset the current year’s taxable income before considering the effects of current-year windfalls.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-17-000020:notes:119]
[same as prior period, unchanged from 0000936395-16-000115:notes:143]

[0000936395-17-000020:notes:120]
[same as prior period, unchanged from 0000936395-16-000115:notes:144]

[0000936395-17-000020:notes:121]
|  | January 31, 2017 |  | October 31, 2016 |
|  | Gross Intangible |  | Accumulated Amortization |  | Net Intangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 347,727 |  |  | $ | (258,955 | ) |  | $ | 88,772 |  |  | $ | 347,727 |  |  | $ | (248,128 | ) |  | $ | 99,599 |  |
| In-process research and development | 4,200 |  |  | — |  |  | 4,200 |  |  | 4,200 |  |  | — |  |  | 4,200 |  |
| Patents and licenses | 7,165 |  |  | (6,348 | ) |  | 817 |  |  | 7,165 |  |  | (6,285 | ) |  | 880 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 358,647 |  |  | (324,589 | ) |  | 34,058 |  |  | 358,647 |  |  | (316,615 | ) |  | 42,032 |  |
| Total other intangible assets | $ | 717,739 |  |  | $ | (589,892 | ) |  | $ | 127,847 |  |  | $ | 717,739 |  |  | $ | (571,028 | ) |  | $ | 146,711 |  |

[0000936395-17-000020:notes:122]
The aggregate amortization expense of intangible assets was $18.9 million and $20.5 million for the first three months of fiscal 2017 and 2016, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-17-000020:notes:123]
| Period ended October 31, |  |  |
| 2017 (remaining nine months) | $ | 26,497 |  |  |
| 2018 | 22,680 |  |  |
| 2019 | 22,133 |  |  |
| 2020 | 21,106 |  |  |
| 2021 | 18,172 |  |  |
| Thereafter | 13,059 |  |  |
|  | $ | 123,647 |  | (1) |

[0000936395-17-000020:notes:124]
[same as prior period, unchanged from 0000936395-16-000115:notes:148]


## us-gaap:InventoryDisclosureTextBlock

[0000936395-17-000020:notes:125]
[same as prior period, unchanged from 0000936395-16-000115:notes:149]

[0000936395-17-000020:notes:126]
[same as prior period, unchanged from 0000936395-16-000115:notes:150]

[0000936395-17-000020:notes:127]
|  | January 31, 2017 |  | October 31, 2016 |
| Raw materials | $ | 43,503 |  |  | $ | 44,644 |  |
| Work-in-process | 13,959 |  |  | 12,852 |  |
| Finished goods | 197,651 |  |  | 156,402 |  |
| Deferred cost of goods sold | 83,853 |  |  | 59,856 |  |
|  | 338,966 |  |  | 273,754 |  |
| Provision for excess and obsolescence | (54,371 | ) |  | (62,503 | ) |
|  | $ | 284,595 |  |  | $ | 211,251 |  |

[0000936395-17-000020:notes:128]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand and market conditions. During the first three months of fiscal 2017, Ciena recorded a provision for excess and obsolescence of $5.4 million, primarily related to a decrease in the forecasted demand for certain Networking Platform products. Deductions from the provision for excess and obsolete inventory relate primarily to disposal activities.


## us-gaap:InventoryPolicyTextBlock

[0000936395-17-000020:notes:129]
[same as prior period, unchanged from 0000936395-16-000115:notes:153]


## us-gaap:InvestmentPolicyTextBlock

[0000936395-17-000020:notes:130]
[same as prior period, unchanged from 0000936395-16-000115:notes:154]

[0000936395-17-000020:notes:131]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the companies. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of January 31, 2017, the combined carrying value of these investments was $6.0 million. Ciena has not estimated the fair value of these cost method investments because determining the fair value is not practicable. Ciena has not evaluated these investments for impairment as there have not been any events or changes in circumstances that Ciena believes would have had a significant adverse effect on the fair value of these investments.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000936395-17-000020:notes:132]
The following table summarizes the final legal maturities of debt investments at January 31, 2017 (in thousands):

[0000936395-17-000020:notes:133]
|  | AmortizedCost |  | EstimatedFair Value |
| Less than one year | $ | 250,042 |  |  | $ | 250,056 |  |
| Due in 1-2 years | 110,035 |  |  | 109,934 |  |
|  | $ | 360,077 |  |  | $ | 359,990 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-17-000020:notes:134]
SHORT-TERM AND LONG-TERM INVESTMENTS

[0000936395-17-000020:notes:135]
As of the dates indicated, investments are comprised of the following (in thousands):

[0000936395-17-000020:notes:136]
|  | January 31, 2017 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | GrossUnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 230,090 |  |  | $ | 60 |  |  | (46 | ) |  | $ | 230,104 |  |
| Included in long-term investments | 110,035 |  |  | 5 |  |  | (106 | ) |  | 109,934 |  |
|  | $ | 340,125 |  |  | $ | 65 |  |  | $ | (152 | ) |  | $ | 340,038 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 19,952 |  |  | — |  |  | — |  |  | $ | 19,952 |  |
|  | $ | 19,952 |  |  | $ | — |  |  | $ | — |  |  | $ | 19,952 |  |

[0000936395-17-000020:notes:137]
|  | October 31, 2016 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 260,125 |  |  | $ | 140 |  |  | $ | (6 | ) |  | $ | 260,259 |  |
| Included in long-term investments | 90,145 |  |  | 57 |  |  | (30 | ) |  | 90,172 |  |
|  | $ | 350,270 |  |  | $ | 197 |  |  | $ | (36 | ) |  | $ | 350,431 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 14,989 |  |  | — |  |  | — |  |  | $ | 14,989 |  |
|  | $ | 14,989 |  |  | $ | — |  |  | $ | — |  |  | $ | 14,989 |  |


## us-gaap:LegalCostsPolicyTextBlock

[0000936395-17-000020:notes:138]
Ciena expenses legal costs associated with litigation defense as incurred.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-17-000020:notes:139]
[same as prior period, unchanged from 0000936395-16-000115:notes:163]

[0000936395-17-000020:notes:140]
As of January 31, 2017, one customer accounted for 10.5% of Ciena's net accounts receivable and as of October 31, 2016, a different customer accounted for 10.4% of Ciena's net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. The allowance for doubtful accounts was $4.0 million as of January 31, 2017 and October 31, 2016.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000936395-17-000020:notes:141]
In April 2015, Financial Accounting Standards Board ("FASB") issued Accounting Standards Update ("ASU") No. 2015-03, Simplifying the Presentation of Debt Issuance Costs ("ASU 2015-03"). ASU 2015-03 requires debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying value of that debt liability, consistent with debt discounts. ASU 2015-03 is to be applied on a retrospective basis and represents a change in accounting principle. In August 2015, the FASB issued Accounting Standards Update No. 2015-15, “Interest — Imputation of Interest (Subtopic 835-30): Presentation and Subsequent Measurement of Debt Issuance Costs Associated with Line-of-Credit Arrangements — Amendments to SEC Paragraphs Pursuant to Staff Announcement at June 18, 2015 EITF Meeting” (“ASU 2015-15”), which clarifies the treatment of debt issuance costs from line-of-credit arrangements after the adoption of ASU 2015-03. In particular, ASU 2015-15 clarifies that the SEC staff would not object to an entity deferring and presenting debt issuance costs related to a line-of-credit arrangement as an asset and subsequently amortizing the deferred debt issuance costs ratably over the term of such arrangement, regardless of whether there are any outstanding borrowings on the line-of-credit arrangement. Ciena adopted these ASU's during the first quarter of fiscal 2017. The adoption of ASU 2015-03 resulted in the reclassification of unamortized debt issuance costs related to Ciena's convertible notes and term loans from other long-term assets to current portion of long-term debt and long-term debt, net in Ciena's Consolidated Balance sheets in the amount of $7.9 million at January 31, 2017 and $8.9 million at October 31, 2016. As permitted by ASU 2015-15, Ciena elected not to reclassify unamortized debt issuance costs associated with its ABL Credit Facility (described in Note 17 below) and continue to present such capitalized costs in other assets.

[0000936395-17-000020:notes:142]
In January 2017, the FASB issued ASU No. 2017-04, Simplifying the Test for Goodwill Impairment ("ASU 2017-04"), which simplifies the accounting for goodwill impairments by eliminating step two from the goodwill impairment test. ASU 2017-04 requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount rather than on the basis of the implied amount of goodwill relative to the goodwill balance of the reporting unit. ASU 2017-04 is effective for annual and interim impairment tests for periods beginning after December 15, 2021. Early adoption is allowed for annual and interim impairment tests occurring after January 1, 2017. Ciena has elected to adopt ASU 2017-04 during the first quarter of fiscal 2017.

[0000936395-17-000020:notes:143]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-17-000020:notes:144]
In May 2014, FASB issued ASU No. 2014-09, Revenue from Contracts with Customers (Topic 606), which provides guidance for revenue recognition. This ASU affects any entity that either enters into contracts with customers to transfer goods or services or enters into contracts for the transfer of non-financial assets. This ASU will supersede the revenue recognition requirements in Topic 605, Revenue Recognition, and most industry-specific guidance. This ASU also supersedes some cost guidance included in Subtopic 605-35, Revenue Recognition-Construction-Type and Production-Type Contracts. The standard will be effective for Ciena beginning in the first quarter of fiscal 2019. For multiple element software arrangements where VSOE of undelivered maintenance does not exist, Ciena currently recognizes revenue for the entire arrangement over the maintenance term. Ciena expects that the adoption of this ASU will require Ciena to determine the stand alone selling price for each of the elements at the contract inception and consequently Ciena expects certain software deliverables will be recognized at a point in time rather than over a period of time. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures, as well as the transition method.

[0000936395-17-000020:notes:145]
In February 2016, FASB issued ASU No. 2016-02, Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases and Ciena expects that the adoption of this ASU will require these leases to be classified as financing leases and to be recognized as assets and liabilities on Ciena’s balance sheet. Ciena is continuing to evaluate other possible impacts of the adoption of this ASU on its Consolidated Financial Statements and disclosures.

[0000936395-17-000020:notes:146]
In March 2016, the FASB issued ASU No. 2016-09, Improvements to Employee Share-Based Payment Accounting, which provides guidance on several aspects of accounting for share-based payment transactions, including the accounting for income taxes, forfeitures, and statutory tax withholding requirements, as well as classification on the statement of cash flows. ASU 2016-09 is effective for Ciena beginning in the first quarter of fiscal 2018. Under the new guidance, Ciena would recognize all excess tax benefits previously unrecognized, along with any valuation allowance, on a modified retrospective basis as a cumulative-effect adjustment to retained earnings as of the date of adoption of this updated standard.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000936395-17-000020:notes:147]
[same as prior period, unchanged from 0000936395-16-000115:notes:169]

[0000936395-17-000020:notes:148]
The interim financial statements included herein for Ciena Corporation and its wholly owned subsidiaries (“Ciena”) have been prepared by Ciena, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). In the opinion of management, the financial statements included in this report reflect all normal recurring adjustments that Ciena considers necessary for the fair statement of the results of operations for the interim periods covered and of the financial position of Ciena at the date of the interim balance sheets. Certain information and footnote disclosures normally included in the annual financial statements prepared in accordance with accounting principles generally accepted in the United States of America ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The Condensed Consolidated Balance Sheet as of October 31, 2016 was derived from audited financial statements, but does not include all disclosures required by GAAP. However, Ciena believes that the disclosures are adequate to understand the information presented herein. The operating results for interim periods are not necessarily indicative of the operating results for the entire year. These financial statements should be read in conjunction with Ciena’s audited consolidated financial statements and the notes thereto included in Ciena’s annual report on Form 10-K for the fiscal year ended October 31, 2016.

[0000936395-17-000020:notes:149]
Ciena has a 52 or 53-week fiscal year, with quarters ending on the Saturday nearest to the last day of January, April, July and October, respectively, of each year. Fiscal 2017 and 2016 are 52-week fiscal years. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31, and the fiscal quarters are described as having ended on January 31, April 30 and July 31 of each fiscal year.


## us-gaap:OtherLiabilitiesTableTextBlock

[0000936395-17-000020:notes:150]
[same as prior period, unchanged from 0000936395-16-000115:notes:173]

[0000936395-17-000020:notes:151]
|  | January 31, 2017 |  | October 31, 2016 |
| Construction liability | $ | 58,671 |  |  | $ | 57,602 |  |
| Capital lease obligations | 24,186 |  |  | 24,298 |  |
| Income tax liability | 13,765 |  |  | 14,122 |  |
| Deferred tenant allowance | 8,913 |  |  | 9,164 |  |
| Straight-line rent | 7,342 |  |  | 6,406 |  |
| Forward starting interest rate swap | 1,475 |  |  | 5,967 |  |
| Other | 6,968 |  |  | 6,835 |  |
|  | $ | 121,320 |  |  | $ | 124,394 |  |


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-17-000020:notes:152]
[same as prior period, unchanged from 0000936395-16-000115:notes:175]

[0000936395-17-000020:notes:153]
[same as prior period, unchanged from 0000936395-16-000115:notes:176]

[0000936395-17-000020:notes:154]
|  | Quarter Ended January 31, |
|  | 2017 |  | 2016 |
| Interest income | $ | 1,282 |  |  | $ | 686 |  |
| Gains (losses) on non-hedge designated foreign currency forward contracts | 1,024 |  |  | (4,614 | ) |
| Foreign currency exchange losses | (2,417 | ) |  | (4,377 | ) |
| Other | 481 |  |  | (471 | ) |
| Interest and other income (loss), net | $ | 370 |  |  | $ | (8,776 | ) |

[0000936395-17-000020:notes:155]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During the first three months of fiscal 2017 and the first three months of fiscal 2016, Ciena recorded $2.4 million and $4.4 million in foreign currency exchange rate losses, respectively, as a result of monetary assets and liabilities that were transacted in a currency other than the entity's functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. During the first three months of fiscal 2017 and fiscal 2016, Ciena recorded gains of $1.0 million and losses of $4.6 million, respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-17-000020:notes:156]
[same as prior period, unchanged from 0000936395-16-000115:notes:179]

[0000936395-17-000020:notes:157]
[same as prior period, unchanged from 0000936395-16-000115:notes:180]

[0000936395-17-000020:notes:158]
|  | January 31, 2017 |  | October 31, 2016 |
| Equipment, furniture and fixtures | $ | 461,146 |  |  | $ | 451,029 |  |
| Building subject to capital lease | 22,947 |  |  | 22,529 |  |
| Construction in progress subject to build-to-suit lease | 58,671 |  |  | 57,602 |  |
| Leasehold improvements | 62,349 |  |  | 60,011 |  |
|  | 605,113 |  |  | 591,171 |  |
| Accumulated depreciation and amortization | (311,963 | ) |  | (302,765 | ) |
|  | $ | 293,150 |  |  | $ | 288,406 |  |

[0000936395-17-000020:notes:159]
Ciena capitalizes construction in progress and records a corresponding long-term liability for build-to-suit lease agreements where Ciena is considered the owner, for accounting purposes, during the construction period. On April 15, 2015, Ciena entered into a build-to-suit lease arrangement pursuant to which the landlord will construct, and Ciena will subsequently lease, two new office buildings at its new Ottawa, Canada campus. The landlord will construct the buildings and contribute up to a maximum of CAD$290.00 per rentable square foot in total construction costs plus certain allowances for tenant improvements, and Ciena will be responsible for any additional construction costs. As of January 31, 2017, total costs incurred under this build-to-suit arrangement were $58.7 million. Upon occupancy of the facilities, Ciena expects this arrangement to qualify as a capital lease. As a result, the facilities will be depreciated over the shorter of their useful lives or the lease term.

[0000936395-17-000020:notes:160]
The total depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements, was $14.3 million and $11.9 million for the first three months of fiscal 2017 and 2016, respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000936395-17-000020:notes:161]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-17-000020:notes:162]
[same as prior period, unchanged from 0000936395-16-000115:notes:186]


## us-gaap:ReceivablesPolicyTextBlock

[0000936395-17-000020:notes:163]
[same as prior period, unchanged from 0000936395-16-000115:notes:187]


## us-gaap:ReconciliationOfOperatingProfitLossFromSegmentsToConsolidatedTextBlock

[0000936395-17-000020:notes:164]
The table below (in thousands) sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-17-000020:notes:165]
|  | Quarter Ended January 31, |  |
|  | 2017 |  | 2016 |  |
| Segment profit (loss): |  |  |  |  |
| Networking Platforms | $ | 113,747 |  |  | $ | 106,982 |  |  |
| Software and Software-Related Services | 7,700 |  |  | (3,574 | ) |  |
| Global Services | 35,469 |  |  | 39,996 |  |  |
| Total segment profit | 156,916 |  |  | 143,404 |  |  |
| Less: Non-performance operating expenses |  |  |  |  |
| Selling and marketing | 85,002 |  |  | 82,478 |  |  |
| General and administrative | 35,864 |  |  | 31,142 |  |  |
| Acquisition and integration costs | — |  |  | 1,299 |  |  |
| Amortization of intangible assets | 14,551 |  |  | 16,862 |  |  |
| Restructuring costs | 2,395 |  |  | 384 |  |  |
| Add: Other non-performance financial items |  |  |  |  |
| Interest expense and other income (loss), net | (14,833 | ) |  | (21,486 | ) |  |
| Less: Provision for income taxes | 410 |  |  | 1,299 |  |  |
| Consolidated net income (loss) | $ | 3,861 |  |  | $ | (11,546 | ) |  |


## us-gaap:ReconciliationOfRevenueFromSegmentsToConsolidatedTextBlock

[0000936395-17-000020:notes:166]
[same as prior period, unchanged from 0000936395-16-000115:notes:190]

[0000936395-17-000020:notes:167]
|  | Quarter Ended January 31, |
|  | 2017 |  | 2016 |
| Revenue: |  |  |  |
| Networking Platforms |  |  |  |
| Converged Packet Optical | $ | 412,652 |  |  | $ | 389,168 |  |
| Packet Networking | 72,194 |  |  | 48,197 |  |
| Optical Transport | 5,098 |  |  | 12,145 |  |
| Total Networking Platforms | 489,944 |  |  | 449,510 |  |
| Software and Software-Related Services |  |  |  |
| Software Platforms | 17,049 |  |  | 8,079 |  |
| Software-Related Services | 22,331 |  |  | 17,347 |  |
| Total Software and Software-Related Services | 39,380 |  |  | 25,426 |  |
| Global Services |  |  |  |
| Maintenance Support and Training | 54,990 |  |  | 56,058 |  |
| Installation and Deployment | 27,919 |  |  | 30,840 |  |
| Consulting and Network Design | 9,264 |  |  | 11,281 |  |
| Total Global Services | 92,173 |  |  | 98,179 |  |
| Consolidated revenue | $ | 621,497 |  |  | $ | 573,115 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000936395-17-000020:notes:168]
[same as prior period, unchanged from 0000936395-16-000115:notes:192]


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-17-000020:notes:169]
[same as prior period, unchanged from 0000936395-16-000115:notes:193]

[0000936395-17-000020:notes:170]
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2017 (in thousands):

[0000936395-17-000020:notes:171]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 2,008 |  |  | 387 |  |  | 2,395 |  |
| Cash payments | (2,512 | ) |  | (652 | ) |  | (3,164 | ) |
| Balance at January 31, 2017 | $ | 364 |  |  | $ | 1,705 |  |  | $ | 2,069 |  |
| Current restructuring liabilities | $ | 364 |  |  | $ | 1,269 |  |  | $ | 1,633 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 436 |  |  | $ | 436 |  |

[0000936395-17-000020:notes:172]
The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the three months ended January 31, 2016 (in thousands):

[0000936395-17-000020:notes:173]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2015 | $ | 591 |  |  | $ | 688 |  |  | $ | 1,279 |  |
| Additional liability recorded | 393 |  |  | — |  |  | 393 |  |
| Adjustment to previous estimates | — |  |  | (9 | ) |  | (9 | ) |
| Cash payments | (613 | ) |  | (148 | ) |  | (761 | ) |
| Balance at January 31, 2016 | $ | 371 |  |  | $ | 531 |  |  | $ | 902 |  |
| Current restructuring liabilities | $ | 371 |  |  | $ | 336 |  |  | $ | 707 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 195 |  |  | $ | 195 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000936395-17-000020:notes:174]
[same as prior period, unchanged from 0000936395-16-000115:notes:199]

[0000936395-17-000020:notes:175]
[same as prior period, unchanged from 0000936395-16-000115:notes:201]

[0000936395-17-000020:notes:176]
[same as prior period, unchanged from 0000936395-16-000115:notes:202]

[0000936395-17-000020:notes:177]
[same as prior period, unchanged from 0000936395-16-000115:notes:203]

[0000936395-17-000020:notes:178]
[same as prior period, unchanged from 0000936395-16-000115:notes:204]


## us-gaap:ScheduleOfAccruedLiabilitiesTableTextBlock

[0000936395-17-000020:notes:179]
[same as prior period, unchanged from 0000936395-16-000115:notes:205]

[0000936395-17-000020:notes:180]
|  | January 31, 2017 |  | October 31, 2016 |
| Compensation, payroll related tax and benefits | $ | 63,251 |  |  | $ | 106,687 |  |
| Warranty | 48,652 |  |  | 52,324 |  |
| Vacation | 36,187 |  |  | 36,112 |  |
| Capital lease obligations | 2,233 |  |  | 2,321 |  |
| Interest payable | 5,486 |  |  | 4,649 |  |
| Other | 108,746 |  |  | 108,260 |  |
|  | $ | 264,555 |  |  | $ | 310,353 |  |


## us-gaap:ScheduleOfFutureMinimumLeasePaymentsForCapitalLeasesTableTextBlock

[0000936395-17-000020:notes:181]
The following is a schedule by fiscal year of future minimum lease payments under capital leases and the present value of minimum lease payments as of January 31, 2017 (in thousands):

[0000936395-17-000020:notes:182]
| Period ended October 31, |  |
| 2017 (remaining nine months) | $ | 3,084 |  |
| 2018 | 3,842 |  |
| 2019 | 3,420 |  |
| 2020 | 2,440 |  |
| 2021 | 2,335 |  |
| Thereafter | 28,210 |  |
| Net minimum capital lease payments | 43,331 |  |
| Less: Amount representing interest | (16,912 | ) |
| Present value of minimum lease payments | 26,419 |  |
| Less: Current portion of present value of minimum lease payments | (2,233 | ) |
| Long-term portion of present value of minimum lease payments | $ | 24,186 |  |


## us-gaap:ScheduleOfOtherAssetsNoncurrentTextBlock

[0000936395-17-000020:notes:183]
[same as prior period, unchanged from 0000936395-16-000115:notes:210]

[0000936395-17-000020:notes:184]
|  | January 31, 2017 |  | October 31, 2016 |
| Maintenance spares, net | $ | 45,529 |  |  | $ | 49,535 |  |
| Deferred debt issuance costs, net (1) | 1,283 |  |  | 1,363 |  |
| Financing receivable | 2,018 |  |  | 1,870 |  |
| Other | 15,112 |  |  | 15,352 |  |
|  | $ | 63,942 |  |  | $ | 68,120 |  |

[0000936395-17-000020:notes:185]
(1) As described in Note 2 above, in connection with Ciena's adoption of ASU 2015-03 effective January 31, 2017, deferred debt issuance costs associated with its convertible notes and term loans were retrospectively reclassified from other long-term assets to current portion of long-term debt and long-term debt, net on the Condensed Consolidated Balance Sheets. The deferred debt issuance costs reflected relate to Ciena's ABL Credit Facility (described in Note 17 below). The amortization of deferred debt issuance costs for Ciena's ABL Credit Facility is included in interest expense, and was $0.1 million and $0.2 million during the first three months of fiscal 2017 and 2016, respectively.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0000936395-17-000020:notes:186]
[same as prior period, unchanged from 0000936395-16-000115:notes:212]

[0000936395-17-000020:notes:187]
| Three months ended |  | Beginning |  |  |  |  |  | Ending |
| January 31, |  | Balance |  | Provisions |  | Settlements |  | Balance |
| 2016 |  | $ | 56,654 |  |  | 4,971 |  |  | (4,989 | ) |  | $ | 56,636 |  |
| 2017 |  | $ | 52,324 |  |  | 553 |  |  | (4,225 | ) |  | $ | 48,652 |  |


## us-gaap:ScheduleOfRevenueByMajorCustomersByReportingSegmentsTableTextBlock

[0000936395-17-000020:notes:188]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-17-000020:notes:189]
|  | Quarter Ended January 31, |
|  | 2017 |  | 2016 |
| AT&T | $ | 96,437 |  |  | $ | 126,600 |  |
| Verizon | 73,089 |  |  | n/a |  |
| Total | $ | 169,526 |  |  | $ | 126,600 |  |

[0000936395-17-000020:notes:190]
________________________________

[0000936395-17-000020:notes:191]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-17-000020:notes:192]
[same as prior period, unchanged from 0000936395-16-000115:notes:214]

[0000936395-17-000020:notes:193]
|  | January 31, 2017 |  | October 31, 2016 |
| United States | $ | 104,187 |  |  | $ | 103,018 |  |
| Canada | 178,391 |  |  | 173,885 |  |
| Other International | 10,572 |  |  | 11,503 |  |
| Total | $ | 293,150 |  |  | $ | 288,406 |  |

[0000936395-17-000020:notes:194]
[same as prior period, unchanged from 0000936395-16-000115:notes:216]

[0000936395-17-000020:notes:195]
|  | Quarter Ended January 31, |
|  | 2017 |  | 2016 |
| North America | $ | 405,928 |  |  | $ | 392,704 |  |
| EMEA | 91,543 |  |  | 80,722 |  |
| CALA | 35,146 |  |  | 43,810 |  |
| APAC | 88,880 |  |  | 55,879 |  |
| Total | $ | 621,497 |  |  | $ | 573,115 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-17-000020:notes:196]
[same as prior period, unchanged from 0000936395-16-000115:notes:218]

[0000936395-17-000020:notes:197]
[same as prior period, unchanged from 0000936395-16-000115:notes:219]

[0000936395-17-000020:notes:198]
Ciena’s internal organizational structure and the management of its business are grouped into the following operating segments:

[0000936395-17-000020:notes:199]
[same as prior period, unchanged from 0000936395-16-000115:notes:221]

[0000936395-17-000020:notes:200]
[same as prior period, unchanged from 0000936395-16-000115:notes:222]

[0000936395-17-000020:notes:201]
[same as prior period, unchanged from 0000936395-16-000115:notes:223]

[0000936395-17-000020:notes:202]
| ◦ | Optical Transport — includes the 4200 Advanced Services Platform, 5100/5200 Advanced Services Platform, Common Photonic Layer (CPL) and 6100 Multiservice Optical Platform. Ciena's Optical Transport products have either been previously discontinued, or are expected to be discontinued during fiscal 2017, reflecting network operators' transition toward next-generation converged network architectures. |

[0000936395-17-000020:notes:203]
[same as prior period, unchanged from 0000936395-16-000115:notes:225]

[0000936395-17-000020:notes:204]
[same as prior period, unchanged from 0000936395-16-000115:notes:226]

[0000936395-17-000020:notes:205]
| ◦ | This segment includes Ciena’s element and network management solutions and planning tools, including the OneControl Unified Management System, ON-Center® Network & Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. As Ciena seeks adoption of its Blue Planet software platform and transitions features, functionality and customers to this platform, Ciena expects revenue declines for its other element and network management solutions. |

[0000936395-17-000020:notes:206]
| ◦ | This segment includes Ciena’s Blue Planet network virtualization, service orchestration and network management software platform. Ciena's Blue Planet platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV) management and orchestration (NFV MANO), and Ciena's manage, control and plan (MCP) solution, SDN Multilayer Controller and V-WAN application. |

[0000936395-17-000020:notes:207]
[same as prior period, unchanged from 0000936395-16-000115:notes:229]

[0000936395-17-000020:notes:208]
[same as prior period, unchanged from 0000936395-16-000115:notes:230]

[0000936395-17-000020:notes:209]
Ciena's long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of January 31, 2017, equipment, building, furniture and fixtures, net totaling $293.2 million primarily supported asset groups within Ciena's Networking Platforms and Software and Software-Related Services segments and supported Ciena's unallocated selling and general and administrative activities. As of January 31, 2017, $54.2 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Networking Platforms segment and $73.6 million of Ciena's intangible assets, net were assigned to asset groups within Ciena's Software and Software-Related Services segment. As of January 31, 2017, all of the maintenance spares, net, totaling $45.5 million, were assigned to asset groups within Ciena's Global Services segment.

[0000936395-17-000020:notes:210]
[same as prior period, unchanged from 0000936395-16-000115:notes:232]

[0000936395-17-000020:notes:211]
[same as prior period, unchanged from 0000936395-16-000115:notes:233]

[0000936395-17-000020:notes:212]
[same as prior period, unchanged from 0000936395-16-000115:notes:234]

[0000936395-17-000020:notes:213]
[same as prior period, unchanged from 0000936395-16-000115:notes:235]

[0000936395-17-000020:notes:214]
[same as prior period, unchanged from 0000936395-16-000115:notes:236]

[0000936395-17-000020:notes:215]
North America includes $379.7 million and $365.2 million of United States revenue for fiscal quarters ended January 31, 2017 and 2016, respectively.

[0000936395-17-000020:notes:216]
[same as prior period, unchanged from 0000936395-16-000115:notes:238]

[0000936395-17-000020:notes:217]
Both customers purchased products and services from each of Ciena's operating segments.


## us-gaap:SegmentReportingPolicyPolicyTextBlock

[0000936395-17-000020:notes:218]
Ciena's chief operating decision maker, its chief executive officer, evaluates the Company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000936395-17-000020:notes:219]
[same as prior period, unchanged from 0000936395-16-000115:notes:241]

[0000936395-17-000020:notes:220]
[same as prior period, unchanged from 0000936395-16-000115:notes:242]

[0000936395-17-000020:notes:221]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to  allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant's use of the asset and the appropriate discount rates for a market participant. Ciena's estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-17-000020:notes:222]
[same as prior period, unchanged from 0000936395-16-000115:notes:244]

[0000936395-17-000020:notes:223]
The preparation of the financial statements and related disclosures in conformity with GAAP requires management to make estimates and judgments that affect the amounts reported in the condensed consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, convertible notes payable valuations, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, incentive compensation, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-17-000020:notes:224]
[same as prior period, unchanged from 0000936395-16-000115:notes:246]

[0000936395-17-000020:notes:225]
[same as prior period, unchanged from 0000936395-16-000115:notes:247]

[0000936395-17-000020:notes:226]
[same as prior period, unchanged from 0000936395-16-000115:notes:248]

[0000936395-17-000020:notes:227]
Ciena's chief operating decision maker, its chief executive officer, evaluates the Company's performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. Ciena considers the following to be its operating segments for reporting purposes: (i) Networking Platforms, (ii) Software and Software-Related Services, and (iii) Global Services. See Note 20 below.

[0000936395-17-000020:notes:228]
[same as prior period, unchanged from 0000936395-16-000115:notes:250]

[0000936395-17-000020:notes:229]
[same as prior period, unchanged from 0000936395-16-000115:notes:251]

[0000936395-17-000020:notes:230]
The first step in the process of assessing goodwill impairment is to compare the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then step two as amended by ASU No. 2017-04, Simplifying the Test for Goodwill Impairment, adopted by Ciena in the first quarter of fiscal 2017, requires goodwill impairments to be measured on the basis of the fair value of the reporting unit relative to the reporting unit's carrying amount. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-17-000020:notes:231]
[same as prior period, unchanged from 0000936395-16-000115:notes:253]

[0000936395-17-000020:notes:232]
[same as prior period, unchanged from 0000936395-16-000115:notes:254]

[0000936395-17-000020:notes:233]
Ciena establishes assets and liabilities for the estimated construction costs incurred under build-to-suit lease arrangements to the extent that Ciena is involved in the construction of structural improvements or takes construction risk prior to commencement of a lease. See Notes 10 and 13 below.

[0000936395-17-000020:notes:234]
[same as prior period, unchanged from 0000936395-16-000115:notes:256]

[0000936395-17-000020:notes:235]
[same as prior period, unchanged from 0000936395-16-000115:notes:257]

[0000936395-17-000020:notes:236]
Ciena has recorded in-process research and development projects acquired as the result of an acquisition as indefinite-lived intangible assets. Upon completion of the projects, the assets will be amortized on a straight-line basis over the expected economic life of the asset, which will be determined on that date. Should the project be determined to be abandoned, and the asset developed has no alternative use, the full value of the asset will be charged to expense.

[0000936395-17-000020:notes:237]
[same as prior period, unchanged from 0000936395-16-000115:notes:259]

[0000936395-17-000020:notes:238]
[same as prior period, unchanged from 0000936395-16-000115:notes:260]

[0000936395-17-000020:notes:239]
[same as prior period, unchanged from 0000936395-16-000115:notes:261]

[0000936395-17-000020:notes:240]
[same as prior period, unchanged from 0000936395-16-000115:notes:262]

[0000936395-17-000020:notes:241]
[same as prior period, unchanged from 0000936395-16-000115:notes:263]

[0000936395-17-000020:notes:242]
[same as prior period, unchanged from 0000936395-16-000115:notes:264]

[0000936395-17-000020:notes:243]
[same as prior period, unchanged from 0000936395-16-000115:notes:265]

[0000936395-17-000020:notes:244]
[same as prior period, unchanged from 0000936395-16-000115:notes:266]

[0000936395-17-000020:notes:245]
[same as prior period, unchanged from 0000936395-16-000115:notes:268]

[0000936395-17-000020:notes:246]
[same as prior period, unchanged from 0000936395-16-000115:notes:269]

[0000936395-17-000020:notes:247]
[same as prior period, unchanged from 0000936395-16-000115:notes:270]

[0000936395-17-000020:notes:248]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena's stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena estimates the fair value of each restricted stock unit award based on the fair value of the underlying common stock on the date of grant. In each case, Ciena only recognizes expense in its Condensed Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Ciena recognizes the estimated fair value of performance-based awards, net of estimated forfeitures, as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based upon Ciena's determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Ciena uses the straight-line method to record expense for share-based awards with only service-based vesting. See Note 19 below.

[0000936395-17-000020:notes:249]
[same as prior period, unchanged from 0000936395-16-000115:notes:272]

[0000936395-17-000020:notes:250]
Loss Contingencies

[0000936395-17-000020:notes:251]
[same as prior period, unchanged from 0000936395-16-000115:notes:274]

[0000936395-17-000020:notes:252]
The carrying value of Ciena's cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena's convertible notes and term loans, see Note 16 below.

[0000936395-17-000020:notes:253]
[same as prior period, unchanged from 0000936395-16-000115:notes:276]

[0000936395-17-000020:notes:254]
[same as prior period, unchanged from 0000936395-16-000115:notes:277]

[0000936395-17-000020:notes:255]
[same as prior period, unchanged from 0000936395-16-000115:notes:278]

[0000936395-17-000020:notes:256]
[same as prior period, unchanged from 0000936395-16-000115:notes:279]

[0000936395-17-000020:notes:257]
[same as prior period, unchanged from 0000936395-16-000115:notes:280]

[0000936395-17-000020:notes:258]
[same as prior period, unchanged from 0000936395-16-000115:notes:281]

[0000936395-17-000020:notes:259]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 3 below.

[0000936395-17-000020:notes:260]
[same as prior period, unchanged from 0000936395-16-000115:notes:283]

[0000936395-17-000020:notes:261]
Certain of Ciena's foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders' equity. Where the monetary assets and liabilities are transacted in a currency other than the entity's functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Condensed Consolidated Statement of Operations. See Note 4 below.

[0000936395-17-000020:notes:262]
[same as prior period, unchanged from 0000936395-16-000115:notes:285]

[0000936395-17-000020:notes:263]
See Notes 6 and 14 below.

[0000936395-17-000020:notes:264]
[same as prior period, unchanged from 0000936395-16-000115:notes:287]

[0000936395-17-000020:notes:265]
Ciena calculates basic earnings per share ("EPS") by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted EPS includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic and diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the basic and diluted EPS computations is set forth in Note 18 below.

[0000936395-17-000020:notes:266]
[same as prior period, unchanged from 0000936395-16-000115:notes:289]

[0000936395-17-000020:notes:267]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized straight-line over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development cost qualifying for capitalization has been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-17-000020:notes:268]
Newly Issued Accounting Standards - Effective


## us-gaap:SubsequentEventsTextBlock

[0000936395-17-000020:notes:269]
SUBSEQUENT EVENT

[0000936395-17-000020:notes:270]
Under the Term Loan Credit Agreement, Ciena had two existing term loan tranches, the 2019 Term Loan, with an outstanding aggregate principal amount of $244.4 million, and the 2021 Term Loan, with an outstanding aggregate principal amount of $248.8 million (together, the “Existing Term Loans”).

[0000936395-17-000020:notes:271]
Following the end of our first quarter of fiscal 2017, on January 30, 2017, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Omnibus Refinancing Amendment to the Credit Agreement, Security Agreement and Pledge Agreement with the lenders party thereto and the administrative agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced the Existing Term Loans into a single term loan with an aggregate principal amount of $400 million maturing on January 30, 2022 (the “2022 Term Loan”). In connection with the transaction, Ciena repaid $93.1 million of outstanding principal under the Existing Term Loans, and the remaining balances under the Existing Term Loans were refinanced and replaced by the 2022 Term Loan. The Refinancing Agreement amends the Term Loan Credit Agreement and provides that the 2022 Term Loan will, among other things:

[0000936395-17-000020:notes:272]
| • | mature on January 30, 2022; |

[0000936395-17-000020:notes:273]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2022 Term Loan as of January 30, 2017, with the balance payable at maturity; |

[0000936395-17-000020:notes:274]
| • | be subject to mandatory prepayment on the same basis as the Existing Term Loans under the Term Loan Credit Agreement; |

[0000936395-17-000020:notes:275]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.75%) plus an applicable margin of 2.50%, or (b) a base rate (subject to a floor of 1.75%) plus an applicable margin of 1.50%; and |

[0000936395-17-000020:notes:276]
| • | be repayable at any time at Ciena's election, provided that repayment of the 2022 Term Loan with proceeds of certain indebtedness prior to July 30, 2017 will require a prepayment premium of 1% of the aggregate principal amount of such prepayment. |

[0000936395-17-000020:notes:277]
Except as amended by the Refinancing Agreement, the remaining terms of the Term Loan Credit Agreement remain in full force and effect.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-17-000020:notes:278]
[same as prior period, unchanged from 0000936395-16-000115:notes:294]

[0000936395-17-000020:notes:279]
The decrease in warranty provisions during fiscal 2017 were primarily due to lower failure rates and reduced costs due to efficiencies.

[0000936395-17-000020:notes:280]
[same as prior period, unchanged from 0000936395-16-000115:notes:296]
