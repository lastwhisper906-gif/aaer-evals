# CIEN 8-K — 0000936395-19-000051 filed 2019-12-12

## item codes, every 8-K on or before 2019-12-20

- 2019-12-12 0000936395-19-000051 — 2.02, 9.01
- 2019-10-31 0001193125-19-280501 — 1.01, 1.02, 2.03, 9.01
- 2019-10-03 0000936395-19-000045 — 8.01, 9.01
- 2019-09-05 0000936395-19-000036 — 2.02, 9.01
- 2019-08-29 0000936395-19-000033 — 5.02, 9.01
- 2019-06-06 0000936395-19-000017 — 2.02, 9.01
- 2019-04-01 0000936395-19-000012 — 5.07
- 2019-03-05 0000936395-19-000005 — 2.02, 9.01
- 2018-12-13 0000936395-18-000043 — 2.02, 8.01, 9.01
- 2018-10-18 0000936395-18-000041 — 5.02, 9.01
- 2018-10-01 0001193125-18-289772 — 1.01, 2.03, 8.01, 9.01
- 2018-09-20 0000936395-18-000039 — 8.01, 9.01
- 2018-09-05 0000936395-18-000034 — 8.01, 9.01
- 2018-08-30 0000936395-18-000031 — 2.02, 9.01
- 2018-06-13 0000936395-18-000026 — 5.02
- 2018-05-31 0000936395-18-000021 — 2.02, 8.01, 9.01
- 2018-04-12 0000936395-18-000017 — 8.01, 9.01
- 2018-04-05 0000936395-18-000015 — 5.07
- 2018-03-06 0000936395-18-000009 — 2.02, 9.01
- 2018-01-16 0000936395-18-000002 — 5.07 — amendment, the index does not say of what
- 2017-12-07 0000936395-17-000057 — 2.02, 8.01, 9.01
- 2017-10-30 0000936395-17-000053 — 5.02 — amendment of 0000936395-17-000042
- 2017-08-31 0000936395-17-000045 — 2.02, 9.01
- 2017-08-24 0000936395-17-000042 — 5.02, 9.01
- 2017-08-02 0001193125-17-245224 — 1.01, 8.01, 9.01
- 2017-06-30 0001193125-17-220186 — 8.01, 9.01
- 2017-06-15 0000936395-17-000040 — 8.01
- 2017-06-01 0000936395-17-000033 — 2.02, 9.01
- 2017-03-29 0000936395-17-000026 — 5.02, 9.01
- 2017-03-27 0000936395-17-000024 — 5.07
- 2017-03-08 0000936395-17-000017 — 2.02, 9.01
- 2017-03-01 0000936395-17-000013 — 8.01
- 2017-02-01 0000936395-17-000007 — 1.01, 2.03
- 2017-01-27 0000936395-17-000005 — 5.03, 9.01
- 2017-01-24 0000936395-17-000003 — 5.02, 9.01
- 2016-12-08 0000936395-16-000124 — 2.02, 9.01
- 2016-11-04 0000936395-16-000118 — 5.02
- 2016-09-01 0000936395-16-000112 — 2.02, 9.01
- 2016-08-05 0000936395-16-000109 — 8.01
- 2016-06-22 0000936395-16-000107 — 8.01
- 2016-06-02 0000936395-16-000098 — 2.02, 9.01
- 2016-04-26 0000936395-16-000093 — 1.01, 2.03
- 2016-03-30 0000936395-16-000087 — 5.07
- 2016-03-03 0000936395-16-000076 — 2.02, 9.01
- 2016-01-20 0000936395-16-000066 — 8.01, 9.01
- 2016-01-13 0000936395-16-000064 — 1.01, 2.03
- 2015-12-10 0000936395-15-000058 — 2.02, 9.01
- 2015-11-02 0000936395-15-000055 — 5.02
- 2015-09-03 0000936395-15-000049 — 2.02, 5.02, 8.01, 9.01
- 2015-08-13 0000936395-15-000046 — 5.02, 9.01
- 2015-08-03 0001193125-15-274559 — 1.01, 2.01, 2.03, 8.01, 9.01
- 2015-06-16 0000936395-15-000041 — 8.01, 9.01
- 2015-06-04 0000936395-15-000035 — 2.02, 9.01
- 2015-06-03 0000936395-15-000032 — 9.01
- 2015-05-04 0001193125-15-169310 — 1.01, 2.02, 8.01, 9.01
- 2015-04-17 0000936395-15-000028 — 1.01
- 2015-03-30 0000936395-15-000026 — 5.07
- 2015-03-16 0001628280-15-001789 — 8.01
- 2015-03-05 0000936395-15-000017 — 2.02, 9.01
- 2014-12-11 0000936395-14-000058 — 2.02, 9.01
- 2014-10-24 0000936395-14-000054 — 1.01
- 2014-09-04 0000936395-14-000048 — 2.02, 9.01
- 2014-07-17 0000936395-14-000045 — 2.03, 9.01
- 2014-07-11 0000936395-14-000042 — 1.01, 9.01
- 2014-06-05 0000936395-14-000037 — 2.02, 9.01
- 2014-06-03 0000936395-14-000034 — 5.02, 5.07 — amendment of 0000936395-14-000025
- 2014-04-11 0000936395-14-000025 — 5.07
- 2014-03-06 0000936395-14-000016 — 2.02, 9.01
- 2014-02-05 0000936395-14-000002 — 5.02, 9.01
- 2013-12-12 0000936395-13-000048 — 2.02, 3.01, 9.01
- 2013-11-01 0000936395-13-000043 — 5.02, 9.01
- 2013-09-04 0000936395-13-000035 — 2.02, 9.01
- 2013-08-30 0000936395-13-000031 — 1.01, 9.01
- 2013-06-06 0000936395-13-000024 — 2.02, 9.01
- 2013-03-25 0000936395-13-000021 — 5.07
- 2013-03-07 0000936395-13-000015 — 2.02, 9.01
- 2013-01-29 0000936395-13-000005 — 7.01
- 2012-12-31 0000936395-12-000078 — 1.01, 2.03, 9.01
- 2012-12-19 0000936395-12-000069 — 3.02, 8.01, 9.01
- 2012-12-13 0000936395-12-000065 — 2.02, 9.01
- 2012-09-25 0000936395-12-000062 — 5.02
- 2012-08-30 0000936395-12-000056 — 2.02, 9.01
- 2012-08-15 0000936395-12-000051 — 1.01, 2.03
- 2012-06-01 0000936395-12-000044 — 5.02, 9.01
- 2012-05-31 0000936395-12-000042 — 2.02, 9.01
- 2012-03-23 0000936395-12-000034 — 5.02, 5.07, 9.01
- 2012-03-07 0000936395-12-000026 — 2.02, 9.01
- 2012-02-21 0000936395-12-000021 — 2.02, 9.01
- 2012-02-15 0000936395-12-000016 — 1.01, 9.01
- 2011-12-08 0000936395-11-000005 — 2.02, 5.02, 9.01
- 2011-11-04 0001193125-11-297711 — 1.01
- 2011-09-01 0001157523-11-005260 — 2.02, 9.01
- 2011-06-08 0001157523-11-003576 — 2.02, 9.01
- 2011-06-08 0000950123-11-057583 — 5.02
- 2011-03-28 0000950123-11-029727 — 5.07
- 2011-03-07 0001157523-11-001418 — 2.02, 9.01
- 2010-12-09 0001157523-10-007239 — 2.02, 9.01
- 2010-10-21 0000950123-10-094907 — 1.01, 9.01
- 2010-10-18 0000950123-10-093925 — 2.03, 3.02, 8.01, 9.01
- 2010-10-12 0000950123-10-092585 — 7.01, 9.01
- 2010-09-09 0000950123-10-084690 — 2.05 — amendment of 0000950123-10-048531
- 2010-09-08 0001157523-10-005413 — 2.02, 9.01
- 2010-07-08 0000950123-10-064375 — 5.02
- 2010-06-09 0001157523-10-003627 — 2.02, 9.01
- 2010-05-28 0000950123-10-054157 — 2.01, 9.01 — amendment of 0000950123-10-028185
- 2010-05-12 0000950123-10-048531 — 2.05
- 2010-04-15 0000950123-10-035220 — 5.02, 5.07, 9.01
- 2010-03-25 0000950123-10-028185 — 1.01, 2.01, 5.02, 9.01
- 2010-03-19 0000950123-10-026421 — 1.01, 2.03, 9.01
- 2010-03-12 0000950123-10-023923 — 3.02, 8.01, 9.01
- 2010-03-04 0001157523-10-001398 — 2.02, 9.01
- 2010-03-04 0000950123-10-020848 — 7.01, 9.01
- 2010-02-05 0000950123-10-009300 — 5.02
- 2009-12-10 0001157523-09-008519 — 2.02, 5.02, 9.01
- 2009-12-03 0000950123-09-068077 — 1.01, 2.03, 8.01, 9.01
- 2009-11-24 0000950123-09-065579 — 1.01, 2.03, 3.02, 8.01, 9.01
- 2009-10-21 0000950123-09-051783 — 1.01
- 2009-10-07 0000950123-09-048834 — 1.01, 3.02, 8.01, 9.01
- 2009-10-05 0000950123-09-048251 — 7.01, 9.01
- 2009-09-03 0001157523-09-006332 — 2.02, 9.01
- 2009-06-04 0001157523-09-004328 — 2.02, 9.01
- 2009-05-28 0000950133-09-001791 — 5.02, 9.01
- 2009-04-17 0000950133-09-001165 — 2.06, 9.01
- 2009-03-05 0001157523-09-001899 — 2.02, 2.05, 9.01
- 2008-12-11 0001157523-08-009809 — 2.02, 5.02, 9.01
- 2008-09-04 0001157523-08-007267 — 2.02, 9.01
- 2008-08-28 0000950133-08-002983 — 5.03, 9.01
- 2008-07-18 0000950133-08-002411 — 2.06, 9.01
- 2008-06-05 0001157523-08-004853 — 2.02, 9.01
- 2008-05-12 0000950133-08-001943 — 9.01 — amendment of 0000950133-08-000964
- 2008-03-27 0000950133-08-001294 — 5.02, 5.03, 9.01
- 2008-03-07 0001157523-08-002056 — 2.02, 9.01
- 2008-03-05 0000950133-08-000964 — 2.01, 9.01
- 2008-02-01 0000950133-08-000348 — 8.01
- 2008-01-24 0000950133-08-000239 — 1.01, 3.02, 9.01
- 2008-01-02 0000950133-08-000030 — 3.03, 5.03
- 2007-12-13 0001157523-07-012129 — 2.02, 5.02, 9.01
- 2007-08-30 0001157523-07-008871 — 2.02, 9.01
- 2007-06-12 0000950133-07-002650 — 1.01, 9.01
- 2007-06-06 0000950133-07-002609 — 1.01, 3.02, 9.01
- 2007-05-31 0001157523-07-005724 — 2.02, 9.01
- 2007-04-05 0000950133-07-001582 — 5.02, 9.01
- 2007-03-01 0001157523-07-002213 — 2.02, 9.01
- 2006-12-14 0001157523-06-012127 — 2.02, 9.01
- 2006-12-14 0000950133-06-005322 — 5.02
- 2006-09-25 0000950133-06-004172 — 3.03, 9.01
- 2006-08-31 0001157523-06-008856 — 2.02, 9.01
- 2006-08-08 0001157523-06-008117 — 8.01, 9.01
- 2006-06-01 0001157523-06-005717 — 2.02, 9.01
- 2006-04-10 0000950133-06-001772 — 1.01, 9.01
- 2006-04-05 0000950133-06-001707 — 1.01, 3.02, 9.01
- 2006-03-21 0000950133-06-001377 — 2.05
- 2006-03-02 0001157523-06-002182 — 2.02, 9.01
- 2005-12-08 0001157523-05-010679 — 2.02, 9.01
- 2005-11-04 0000950133-05-004933 — 1.01, 5.02, 9.01
- 2005-10-31 0000950133-05-004799 — 1.01
- 2005-10-28 0000950133-05-004767 — 1.01, 9.01
- 2005-09-02 0000950133-05-004023 — 1.01, 9.01
- 2005-09-01 0001157523-05-007835 — 2.02, 9.01
- 2005-06-03 0000950133-05-002521 — 1.01, 3.03, 9.01
- 2005-06-02 0001157523-05-005203 — 2.02, 9.01
- 2005-03-18 0000950133-05-001112 — 1.01, 9.01
- 2005-02-23 0001157523-05-001739 — 2.02, 9.01
- 2005-02-04 0001157523-05-001078 — 5.02, 9.01
- 2004-12-09 0001157523-04-011316 — 2.02, 9.01
- 2004-10-29 0000950133-04-003990 — 5.03, 9.01
- 2004-08-19 0001157523-04-007932 — 12
- 2004-08-19 0001157523-04-007931 — 5
- 2004-08-03 0001157523-04-007311 — 12, 7
- 2004-05-20 0001157523-04-005037 — 12
- 2004-05-12 0000950133-04-001945 — 2, 7
- 2004-05-03 0001157523-04-004249 — 5, 7
- 2004-04-20 0001157523-04-003432 — 5, 7
- 2004-02-19 0001157523-04-001607 — 5, 7
- 2004-02-19 0001157523-04-001606 — 5, 7
- 2004-02-19 0001157523-04-001605 — 12
- 2004-02-03 0001157523-04-000923 — 12, 7
- 2003-12-22 0001157523-03-007500 — 5, 7
- 2003-12-11 0001157523-03-007229 — 12
- 2003-11-18 0001157523-03-006776 — 5, 7
- 2003-09-03 0001157523-03-004603 — 5, 7
- 2003-08-21 0000950133-03-003003 — 5, 7
- 2003-08-21 0000950133-03-002996 — 12, 7
- 2003-06-17 0000950133-03-002179 — 9
- 2003-05-22 0000950133-03-001972 — 7, 9
- 2003-04-10 0000950133-03-001267 — 9
- 2003-02-20 0000950133-03-000513 — 7, 9
- 2003-01-23 0000950133-03-000166 — 5, 7
- 2003-01-14 0000950133-03-000094 — 5, 7
- 2002-12-20 0000950133-02-004145 — 5, 7
- 2002-12-12 0000950133-02-004069 — 5, 7
- 2002-08-22 0000950133-02-003078 — 9
- 2002-06-28 0000950133-02-002427 — 2, 7
- 2002-03-26 0000950133-02-001200 — 5, 7
- 2002-02-19 0000950133-02-000577 — 5, 7
- 2002-02-05 0000950133-02-000362 — 5, 7
- 2001-11-13 0000950133-01-503168 — 5, 7
- 2001-04-02 0000950133-01-500361 — 2, 7
- 2001-01-18 0000950133-01-000146 — 5
- 2000-09-05 0000950133-00-003643 — 5, 7
- 2000-08-16 0000950133-00-003496 — 5, 7
- 1999-07-21 0000950133-99-002451 — 5, 7
- 1999-04-05 0000950133-99-001201 — 5, 7
- 1999-04-05 0000950133-99-001200 — 5, 7 — amendment of 0000950133-99-001167
- 1999-04-01 0000950133-99-001167 — 5, 7
- 1998-10-19 0000950133-98-003539 — 5, 7
- 1998-09-15 0000950133-98-003305 — 5, 7
- 1998-09-14 0000950133-98-003282 — 5, 7
- 1998-08-28 0000950133-98-003198 — 5, 7
- 1998-08-24 0000950133-98-003166 — 5, 7
- 1998-08-14 0000950133-98-003048 — 5, 7
- 1998-06-23 0000950133-98-002366 — 5, 7
- 1998-06-03 0000950133-98-002209 — 5, 7
- 1997-12-29 0000950133-97-004330 — 5, 7
- 1997-09-22 0000950133-97-003334 — 5 — amendment, the index does not say of what
- 1997-08-06 0000950133-97-002710 — 5, 7 — amendment, the index does not say of what
- 1997-02-19 0000950133-97-000500 — 5, 7

## late-filing notifications on or before 2019-12-20

- none on or before 2019-12-20

## item 2.02 — earnings release, exhibit 99.1

[0000936395-19-000051:8k_2_02:1]
EX-99.1
2
ex991-2019q4pressrelea.htm
EXHIBIT 99.1

[0000936395-19-000051:8k_2_02:2]
Exhibit

[0000936395-19-000051:8k_2_02:3]
FOR IMMEDIATE RELEASE

[0000936395-19-000051:8k_2_02:4]
Ciena Reports Fiscal Fourth Quarter 2019 and Year-End Financial Results

[0000936395-19-000051:8k_2_02:5]
HANOVER, Md. - December 12, 2019 - Ciena® Corporation (NYSE: CIEN), a networking systems, services and software company, today announced unaudited financial results for its fiscal fourth quarter and year ended October 31, 2019.

[0000936395-19-000051:8k_2_02:6]
| • | Q4 Revenue: $968.0 million, increasing 7.6% year over year |

[0000936395-19-000051:8k_2_02:7]
| • | Q4 Net Income per Share: $0.51 GAAP; $0.58 adjusted (non-GAAP) |

[0000936395-19-000051:8k_2_02:8]
| • | Share Repurchases: Repurchased approximately 1.0 million shares of common stock for an aggregate price of $38.2 million during the quarter |

[0000936395-19-000051:8k_2_02:9]
"Our outstanding Q4 financial performance rounded out an extraordinary year of industry-leading growth and profitability," said Gary Smith, President and CEO, Ciena. "Our innovation, diversification and scale uniquely position us to continue taking share while delivering improved operating margin and driving sustained EPS growth in 2020."

[0000936395-19-000051:8k_2_02:10]
For the fiscal fourth quarter 2019, Ciena reported revenue of $968.0 million as compared to $899.4 million for the fiscal fourth quarter 2018. For fiscal year 2019, Ciena reported revenue of $3.57 billion, as compared to $3.09 billion for fiscal year 2018.

[0000936395-19-000051:8k_2_02:11]
Ciena's GAAP net income for the fiscal fourth quarter 2019 was $80.3 million or $0.51 per diluted common share, which compares to a GAAP net income of $64.0 million, or $0.34 per diluted common share, for the fiscal fourth quarter 2018. For fiscal year 2019, Ciena's GAAP net income was $253.4 million, or $1.61 per diluted common share, as compared to a GAAP net loss of $(344.7) million, or $(2.49) per diluted common share for fiscal year 2018.

[0000936395-19-000051:8k_2_02:12]
Ciena's adjusted (non-GAAP) net income for the fiscal fourth quarter 2019 was $90.4 million, or $0.58 per diluted common share, which compares to an adjusted (non-GAAP) net income of $81.0 million, or $0.53 per diluted common share, for the fiscal fourth quarter 2018. For fiscal year 2019, Ciena's adjusted (non-GAAP) net income was $331.8 million, or $2.11 per diluted common share, as compared to an adjusted (non-GAAP) net income of $210.6 million, or $1.39 per diluted common share for fiscal year 2018.

[0000936395-19-000051:8k_2_02:13]
Performance Summary for the Fiscal Fourth Quarter and the Year Ended October 31, 2019

[0000936395-19-000051:8k_2_02:14]
The tables below (in millions, except percentage data) provide comparisons of certain quarterly and annual results to the prior year. Appendices A and B set forth reconciliations between the GAAP and adjusted (non-GAAP) measures contained in this release.

[0000936395-19-000051:8k_2_02:15]
|  |  | GAAP Results (unaudited) |
|  |  | Quarter Ended October 31, |  | Period Change |  | Year Ended October 31, |  | Period Change |
|  |  | 2019 |  | 2018 |  | Y-T-Y* |  | 2019 |  | 2018 |  | Y-T-Y* |
| Revenue |  | $ | 968.0 |  |  | $ | 899.4 |  |  | 7.6 | % |  | $ | 3,572.1 |  |  | $ | 3,094.3 |  |  | 15.4 | % |
| Gross margin |  | 43.4 | % |  | 44.3 | % |  | (0.9 | )% |  | 43.2 | % |  | 42.5 | % |  | 0.7 | % |
| Operating expense |  | $ | 326.5 |  |  | $ | 302.2 |  |  | 8.0 | % |  | $ | 1,195.3 |  |  | $ | 1,084.7 |  |  | 10.2 | % |
| Operating margin |  | 9.6 | % |  | 10.7 | % |  | (1.1 | )% |  | 9.7 | % |  | 7.4 | % |  | 2.3 | % |

[0000936395-19-000051:8k_2_02:16]
|  |  | Non-GAAP Results (unaudited) |
|  |  | Quarter Ended October 31, |  | Period Change |  | Year Ended October 31, |  | Period Change |
|  |  | 2019 |  | 2018 |  | Y-T-Y* |  | 2019 |  | 2018 |  | Y-T-Y* |
| Revenue |  | $ | 968.0 |  |  | $ | 899.4 |  |  | 7.6 | % |  | $ | 3,572.1 |  |  | $ | 3,094.3 |  |  | 15.4 | % |
| Adj. gross margin |  | 43.8 | % |  | 44.7 | % |  | (0.9 | )% |  | 43.7 | % |  | 43.0 | % |  | 0.7 | % |
| Adj. operating expense |  | $ | 295.3 |  |  | $ | 277.7 |  |  | 6.3 | % |  | $ | 1,091.8 |  |  | $ | 993.6 |  |  | 9.9 | % |
| Adj. operating margin |  | 13.3 | % |  | 13.9 | % |  | (0.6 | )% |  | 13.1 | % |  | 10.9 | % |  | 2.2 | % |

[0000936395-19-000051:8k_2_02:17]
* Denotes % change, or in the case of margin, absolute change

[0000936395-19-000051:8k_2_02:18]
|  |  | Revenue by Segment (unaudited) |
|  |  | Quarter Ended October 31, |
|  |  | 2019 |  | 2018 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 665.8 |  |  | 68.8 |  | $ | 646.4 |  |  | 71.9 |
| Packet Networking |  | 131.9 |  |  | 13.6 |  | 66.5 |  |  | 7.4 |
| Total Networking Platforms |  | 797.7 |  |  | 82.4 |  | 712.9 |  |  | 79.3 |
| Platform Software and Services |  | 41.2 |  |  | 4.3 |  | 56.6 |  |  | 6.3 |
| Blue Planet Automation Software and Services |  | 16.6 |  |  | 1.7 |  | 10.7 |  |  | 1.2 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 65.3 |  |  | 6.7 |  | 67.4 |  |  | 7.5 |
| Installation and Deployment |  | 36.5 |  |  | 3.8 |  | 39.3 |  |  | 4.4 |
| Consulting and Network Design |  | 10.7 |  |  | 1.1 |  | 12.5 |  |  | 1.3 |
| Total Global Services |  | 112.5 |  |  | 11.6 |  | 119.2 |  |  | 13.2 |
| Total |  | $ | 968.0 |  |  | 100.0 |  | $ | 899.4 |  |  | 100.0 |

[0000936395-19-000051:8k_2_02:19]
|  |  | Revenue by Segment (unaudited) |
|  |  | Year Ended October 31, |
|  |  | 2019 |  | 2018 |
|  |  | Revenue |  | %** |  | Revenue |  | % ** |
| Networking Platforms |  |  |  |  |  |  |  |  |
| Converged Packet Optical |  | $ | 2,562.8 |  |  | 71.8 |  | $ | 2,194.6 |  |  | 70.9 |
| Packet Networking |  | 348.5 |  |  | 9.8 |  | 283.5 |  |  | 9.2 |
| Total Networking Platforms |  | 2,911.3 |  |  | 81.6 |  | 2,478.1 |  |  | 80.1 |
| Platform Software and Services |  | 155.3 |  |  | 4.3 |  | 174.0 |  |  | 5.6 |
| Blue Planet Automation Software and Services |  | 54.6 |  |  | 1.5 |  | 26.7 |  |  | 0.9 |
| Global Services |  |  |  |  |  |  |  |  |
| Maintenance Support and Training |  | 261.3 |  |  | 7.3 |  | 245.1 |  |  | 7.9 |
| Installation and Deployment |  | 148.2 |  |  | 4.1 |  | 128.8 |  |  | 4.2 |
| Consulting and Network Design |  | 41.4 |  |  | 1.2 |  | 41.6 |  |  | 1.3 |
| Total Global Services |  | 450.9 |  |  | 12.6 |  | 415.5 |  |  | 13.4 |
| Total |  | $ | 3,572.1 |  |  | 100.0 |  | $ | 3,094.3 |  |  | 100.0 |

[0000936395-19-000051:8k_2_02:20]
Additional Performance Metrics for Fiscal Fourth Quarter and Year Ended October 31, 2019

[0000936395-19-000051:8k_2_02:21]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Quarter Ended October 31, |
|  |  | 2019 |  | 2018 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 672.7 |  |  | 69.5 |  | $ | 555.3 |  |  | 61.7 |
| Europe, Middle East and Africa |  | 153.0 |  |  | 15.8 |  | 123.1 |  |  | 13.7 |
| Caribbean and Latin America |  | 43.0 |  |  | 4.4 |  | 53.0 |  |  | 5.9 |
| Asia Pacific |  | 99.3 |  |  | 10.3 |  | 168.0 |  |  | 18.7 |
| Total |  | $ | 968.0 |  |  | 100.0 |  | $ | 899.4 |  |  | 100.0 |

[0000936395-19-000051:8k_2_02:22]
|  |  | Revenue by Geographic Region (unaudited) |
|  |  | Year Ended October 31, |
|  |  | 2019 |  | 2018 |
|  |  | Revenue |  | % ** |  | Revenue |  | % ** |
| North America |  | $ | 2,351.3 |  |  | 65.8 |  | $ | 1,886.4 |  |  | 61.0 |
| Europe, Middle East and Africa |  | 566.7 |  |  | 15.9 |  | 464.9 |  |  | 15.0 |
| Caribbean and Latin America |  | 152.6 |  |  | 4.3 |  | 140.2 |  |  | 4.5 |
| Asia Pacific |  | 501.5 |  |  | 14.0 |  | 602.8 |  |  | 19.5 |
| Total |  | $ | 3,572.1 |  |  | 100.0 |  | $ | 3,094.3 |  |  | 100.0 |

[0000936395-19-000051:8k_2_02:23]
**  Denotes %  of total revenue

[0000936395-19-000051:8k_2_02:24]
•One 10%-plus customer represented a total of 15.1% of revenue for the fiscal quarter

[0000936395-19-000051:8k_2_02:25]
•Three 10%-plus customers represented a total of 34.1% of revenue for the fiscal year

[0000936395-19-000051:8k_2_02:26]
| • | Cash and investments totaled $1,024.0 million |

[0000936395-19-000051:8k_2_02:27]
| • | Cash flow from operations totaled $240.0 million and $413.1 million for the fiscal quarter and year, respectively |

[0000936395-19-000051:8k_2_02:28]
| • | Average days' sales outstanding (DSOs) were 75 and 82 for the fiscal quarter and year, respectively |

[0000936395-19-000051:8k_2_02:29]
| • | Accounts receivable balance was $724.9 million |

[0000936395-19-000051:8k_2_02:30]
| • | Unbilled contract asset balance was $84.0 million |

[0000936395-19-000051:8k_2_02:31]
| • | Inventories totaled $345.0 million, including: |

[0000936395-19-000051:8k_2_02:32]
| ◦ | Raw materials: $99.0 million |

[0000936395-19-000051:8k_2_02:33]
| ◦ | Work in process: $13.7 million |

[0000936395-19-000051:8k_2_02:34]
| ◦ | Finished goods: $226.6 million |

[0000936395-19-000051:8k_2_02:35]
| ◦ | Deferred cost of sales: $53.0 million |

[0000936395-19-000051:8k_2_02:36]
| ◦ | Reserve for excess and obsolescence: $(47.3) million |

[0000936395-19-000051:8k_2_02:37]
| • | Product inventory turns were 5.4 and 5.0 for the fiscal quarter and year, respectively |

[0000936395-19-000051:8k_2_02:38]
| • | Headcount totaled 6,383 |

[0000936395-19-000051:8k_2_02:39]
Share Repurchase Program

[0000936395-19-000051:8k_2_02:40]
During fiscal year 2019, Ciena repurchased approximately 3.8 million shares of its common stock at an average price of $39.10 per share for an aggregate purchase price of $150.1 million.

[0000936395-19-000051:8k_2_02:41]
Ciena may purchase shares at management's discretion in the open market, in privately negotiated transactions, in transactions structured through investment banking institutions, or a combination of the foregoing. Ciena may also, from time to time, enter into Rule 10b5-1 plans to facilitate repurchases of its shares under this authorization. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price, and general business and market conditions. The program may be modified, suspended or discontinued at any time.

[0000936395-19-000051:8k_2_02:42]
Supplemental Materials and Live Web Broadcast of Unaudited Fiscal Fourth Quarter 2019 Results

[0000936395-19-000051:8k_2_02:43]
Today, Thursday, December 12, 2019, in conjunction with this announcement, Ciena has posted to the Quarterly Results page of the Investor Relations section of its website certain related supporting materials for its unaudited fiscal fourth quarter and fiscal 2019 results.

[0000936395-19-000051:8k_2_02:44]
Ciena's management will also host a discussion today with investors and financial analysts that will include the Company's  outlook. The live audio web broadcast beginning at 8:30 a.m. Eastern will be accessible via www.ciena.com.  An archived replay of the live broadcast will be available shortly following its conclusion on the Investor Relations page of Ciena's website.

[0000936395-19-000051:8k_2_02:45]
Notes to Investors

[0000936395-19-000051:8k_2_02:46]
Forward-Looking Statements. You are encouraged to review the Investors section of our website, where we routinely post press releases, SEC filings, recent news, financial results, supplemental financial information, and other announcements. From time to time we exclusively post material information to this website along with other disclosure channels that we use. This press release contains certain forward-looking statements that involve risks and uncertainties. These statements are based on current expectations, forecasts, assumptions and other information available to the Company as of the date hereof. Forward-looking statements include statements regarding Ciena's expectations, beliefs, intentions or strategies regarding the future and can be identified by forward-looking words such as "anticipate," "believe," "could," "estimate," "expect," "intend," "may," "should," "will," and "would" or

[0000936395-19-000051:8k_2_02:47]
similar words. Forward-looking statements in this release include: "Our outstanding Q4 financial performance rounded out an extraordinary year of industry-leading growth and profitability."; "Our innovation, diversification and scale uniquely position us to continue taking share while delivering improved operating margin and driving sustained EPS growth in 2020."

[0000936395-19-000051:8k_2_02:48]
Ciena's actual results, performance or events may differ materially from these forward-looking statements made or implied due to a number of risks and uncertainties relating to Ciena's business, including: the effect of broader economic and market conditions on our customers and their business; changes in network spending or network strategy by customers; seasonality and the timing and size of customer orders, including our ability to recognize revenue relating to such sales; the level of competitive pressure we encounter; the product, customer and geographic mix of sales within the period; supply chain disruptions and the level of success relating to efforts to optimize Ciena's operations; changes in foreign currency exchange rates affecting revenue and operating expense; the impact of the Tax Cuts and Jobs Act, changes in estimates of prospective income tax rates and any adjustments to Ciena's provisional estimates whether related to further guidance, analysis or otherwise, and the other risk factors disclosed in Ciena's periodic reports filed with the Securities and Exchange Commission, including its Quarterly Report on Form 10-Q filed with the SEC on September 11, 2019 and its Annual Report on Form 10-K to be filed with the SEC. Ciena assumes no obligation to update any forward-looking information included in this press release.

[0000936395-19-000051:8k_2_02:49]
Non-GAAP Presentation of Quarterly and Annual Results. This release includes non-GAAP measures of Ciena's gross profit, operating expense, income from operations, earnings before interest, tax, depreciation and amortization (EBITDA), Adjusted EBITDA, and measures of net income and net income per share. In evaluating the operating performance of Ciena's business, management excludes certain charges and credits that are required by GAAP. These items share one or more of the following characteristics: they are unusual and Ciena does not expect them to recur in the ordinary course of its business; they do not involve the expenditure of cash; they are unrelated to the ongoing operation of the business in the ordinary course; or their magnitude and timing is largely outside of Ciena's control. Management believes that the non-GAAP measures below provide management and investors useful information and meaningful insight to the operating performance of the business. The presentation of these non-GAAP financial measures should be considered in addition to Ciena's GAAP results and these measures are not intended to be a substitute for the financial information prepared and presented in accordance with GAAP. Ciena's non-GAAP measures and the related adjustments may differ from non-GAAP measures used by other companies and should only be used to evaluate Ciena's results of operations in conjunction with our corresponding GAAP results. To the extent not previously disclosed in a prior Ciena financial results press release for the relevant period, Appendix A and B to this press release set forth a complete GAAP to non-GAAP reconciliation of the non-GAAP measures contained in this release.

[0000936395-19-000051:8k_2_02:50]
About Ciena.  Ciena (NYSE: CIEN) is a networking systems, services and software company. We provide solutions that help our clients create the Adaptive Network™ in response to the constantly changing demands of their users. By delivering best-in-class networking technology through high-touch consultative relationships, we build the world’s most agile networks with automation, openness and scale. For updates on Ciena, follow us on Twitter @Ciena, LinkedIn, the Ciena Insights blog, or visit www.ciena.com.

[0000936395-19-000051:8k_2_02:51]
CIENA CORPORATION

[0000936395-19-000051:8k_2_02:52]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF OPERATIONS

[0000936395-19-000051:8k_2_02:53]
(in thousands, except per share data)

[0000936395-19-000051:8k_2_02:54]
|  |  | Quarter Ended October 31, |  | Year Ended October 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |  |
| Products |  | $ | 820,007 |  |  | $ | 743,867 |  |  | $ | 2,983,815 |  |  | $ | 2,565,460 |  |
| Services |  | 147,980 |  |  | 155,489 |  |  | 588,316 |  |  | 528,826 |  |
| Total revenue |  | 967,987 |  |  | 899,356 |  |  | 3,572,131 |  |  | 3,094,286 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |
| Products |  | 469,945 |  |  | 421,583 |  |  | 1,716,358 |  |  | 1,507,157 |  |
| Services |  | 78,346 |  |  | 79,698 |  |  | 313,707 |  |  | 272,439 |  |
| Total cost of goods sold |  | 548,291 |  |  | 501,281 |  |  | 2,030,065 |  |  | 1,779,596 |  |
| Gross profit |  | 419,696 |  |  | 398,075 |  |  | 1,542,066 |  |  | 1,314,690 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Research and development |  | 141,657 |  |  | 134,983 |  |  | 548,139 |  |  | 491,564 |  |
| Selling and marketing |  | 117,201 |  |  | 112,791 |  |  | 423,046 |  |  | 394,060 |  |
| General and administrative |  | 50,307 |  |  | 44,539 |  |  | 174,399 |  |  | 160,133 |  |
| Amortization of intangible assets |  | 5,222 |  |  | 4,654 |  |  | 21,808 |  |  | 15,737 |  |
| Acquisition and integration costs |  | (735 | ) |  | 3,778 |  |  | 3,370 |  |  | 5,111 |  |
| Significant asset impairments and restructuring costs |  | 12,842 |  |  | 1,460 |  |  | 24,538 |  |  | 18,139 |  |
| Total operating expenses |  | 326,494 |  |  | 302,205 |  |  | 1,195,300 |  |  | 1,084,744 |  |
| Income from operations |  | 93,202 |  |  | 95,870 |  |  | 346,766 |  |  | 229,946 |  |
| Interest and other income (loss), net |  | (1,183 | ) |  | (13,357 | ) |  | 3,876 |  |  | (12,029 | ) |
| Interest expense |  | (9,136 | ) |  | (14,873 | ) |  | (37,452 | ) |  | (55,249 | ) |
| Loss on extinguishment and modification of debt |  | — |  |  | (13,887 | ) |  | — |  |  | (13,887 | ) |
| Income before income taxes |  | 82,883 |  |  | 53,753 |  |  | 313,190 |  |  | 148,781 |  |
| Provision (benefit) for income taxes |  | 2,552 |  |  | (10,224 | ) |  | 59,756 |  |  | 493,471 |  |
| Net income (loss) |  | $ | 80,331 |  |  | $ | 63,977 |  |  | $ | 253,434 |  |  | $ | (344,690 | ) |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |  |
| Basic net income (loss) per common share |  | $ | 0.52 |  |  | $ | 0.45 |  |  | $ | 1.63 |  |  | $ | (2.40 | ) |
| Diluted net income (loss) per potential common share1 |  | $ | 0.51 |  |  | $ | 0.34 |  |  | $ | 1.61 |  |  | $ | (2.49 | ) |
| Weighted average basic common shares outstanding |  | 154,852 |  |  | 143,659 |  |  | 155,720 |  |  | 143,738 |  |
| Weighted average diluted potential common shares outstanding 2 |  | 156,612 |  |  | 157,745 |  |  | 157,612 |  |  | 143,738 |  |

[0000936395-19-000051:8k_2_02:55]
1.  The calculation of GAAP diluted net income per common share for the fourth quarter of fiscal 2018 requires a) adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018 and approximately $2.8 million associated with Ciena's 4.0% convertible senior notes, which were converted at Ciena's election during the fourth quarter of fiscal 2018, and b) reducing net income by $12.9 million for a non-cash loss due to a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-19-000051:8k_2_02:56]
The calculation of GAAP diluted net loss per common share for fiscal 2018 requires an adjustment of $12.9 million for a non-cash loss due to a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes to the GAAP net loss in order to derive the numerator for the diluted earnings per common share calculation.

[0000936395-19-000051:8k_2_02:57]
2. Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2019 includes 1.8 million shares underlying certain stock option and stock unit awards.

[0000936395-19-000051:8k_2_02:58]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-19-000051:8k_2_02:59]
Weighted average dilutive potential common shares outstanding used in calculating GAAP diluted net income per common share for the fourth quarter of fiscal 2018 includes 2.0 million shares underlying certain stock option and stock unit awards, 0.7 million and 2.5 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 8.9 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-19-000051:8k_2_02:60]
CIENA CORPORATION

[0000936395-19-000051:8k_2_02:61]
CONDENSED UNAUDITED CONSOLIDATED BALANCE SHEETS

[0000936395-19-000051:8k_2_02:62]
(in thousands, except share data)

[0000936395-19-000051:8k_2_02:63]
|  | October 31, |
|  | 2019 |  | 2018 |
| ASSETS |  |  |  |
| Current assets: |  |  |  |
| Cash and cash equivalents | $ | 904,045 |  |  | $ | 745,423 |  |
| Short-term investments | 109,940 |  |  | 148,981 |  |
| Accounts receivable, net | 724,854 |  |  | 786,502 |  |
| Inventories | 345,049 |  |  | 262,751 |  |
| Prepaid expenses and other | 297,914 |  |  | 198,945 |  |
| Total current assets | 2,381,802 |  |  | 2,142,602 |  |
| Long-term investments | 10,014 |  |  | 58,970 |  |
| Equipment, building, furniture and fixtures, net | 286,884 |  |  | 292,067 |  |
| Goodwill | 297,937 |  |  | 297,968 |  |
| Other intangible assets, net | 112,781 |  |  | 148,225 |  |
| Deferred tax asset, net | 714,942 |  |  | 745,039 |  |
| Other long-term assets | 88,986 |  |  | 71,652 |  |
| Total assets | $ | 3,893,346 |  |  | $ | 3,756,523 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |
| Current liabilities: |  |  |  |
| Accounts payable | $ | 344,819 |  |  | $ | 340,582 |  |
| Accrued liabilities and other short-term obligations | 382,740 |  |  | 340,075 |  |
| Deferred revenue | 111,381 |  |  | 111,134 |  |
| Current portion of long-term debt | 7,000 |  |  | 7,000 |  |
| Debt conversion liability | — |  |  | 164,212 |  |
| Total current liabilities | 845,940 |  |  | 963,003 |  |
| Long-term deferred revenue | 45,492 |  |  | 58,323 |  |
| Other long-term obligations | 148,747 |  |  | 119,413 |  |
| Long-term debt, net | 680,406 |  |  | 686,450 |  |
| Total liabilities | $ | 1,720,585 |  |  | $ | 1,827,189 |  |
| Stockholders’ equity: |  |  |  |
| Preferred stock — par value $0.01; 20,000,000 shares authorized; zero shares issued and outstanding | — |  |  | — |  |
| Common stock — par value $0.01; 290,000,000 shares authorized; 154,403,850 and 154,318,531 shares issued and outstanding | 1,544 |  |  | 1,543 |  |
| Additional paid-in capital | 6,837,714 |  |  | 6,881,223 |  |
| Accumulated other comprehensive loss | (22,084 | ) |  | (5,780 | ) |
| Accumulated deficit | (4,644,413 | ) |  | (4,947,652 | ) |
| Total stockholders’ equity | 2,172,761 |  |  | 1,929,334 |  |
| Total liabilities and stockholders’ equity | $ | 3,893,346 |  |  | $ | 3,756,523 |  |

[0000936395-19-000051:8k_2_02:64]
CIENA CORPORATION

[0000936395-19-000051:8k_2_02:65]
CONDENSED UNAUDITED CONSOLIDATED STATEMENTS OF CASH FLOWS

[0000936395-19-000051:8k_2_02:66]
(in thousands)

[0000936395-19-000051:8k_2_02:67]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |
| Cash flows from operating activities: |  |  |  |
| Net income (loss) | $ | 253,434 |  |  | $ | (344,690 | ) |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |
| Loss on extinguishment of debt | — |  |  | 10,039 |  |
| Loss on fair value of debt conversion liability | — |  |  | 12,070 |  |
| Depreciation of equipment, furniture and fixtures, and amortization of leasehold improvements | 87,576 |  |  | 84,214 |  |
| Share-based compensation costs | 59,736 |  |  | 52,972 |  |
| Amortization of intangible assets | 35,136 |  |  | 25,806 |  |
| Deferred taxes | 19,865 |  |  | 463,631 |  |
| Provision for doubtful accounts | 6,740 |  |  | 2,700 |  |
| Provision for inventory excess and obsolescence | 28,085 |  |  | 30,615 |  |
| Provision for warranty | 23,105 |  |  | 20,992 |  |
| Other | (910 | ) |  | 21,685 |  |
| Changes in assets and liabilities: |  |  |  |
| Accounts receivable | 65,712 |  |  | (168,357 | ) |
| Inventories | (112,941 | ) |  | (27,445 | ) |
| Prepaid expenses and other | (96,618 | ) |  | (21,425 | ) |
| Accounts payable, accruals and other obligations | 27,740 |  |  | 85,798 |  |
| Deferred revenue | 16,480 |  |  | (19,344 | ) |
| Net cash provided by operating activities | 413,140 |  |  | 229,261 |  |
| Cash flows used in investing activities: |  |  |  |
| Payments for equipment, furniture, fixtures and intellectual property | (62,579 | ) |  | (67,616 | ) |
| Purchase of available for sale securities | (158,074 | ) |  | (286,824 | ) |
| Proceeds from maturities of available for sale securities | 248,748 |  |  | 410,109 |  |
| Settlement of foreign currency forward contracts, net | (1,351 | ) |  | 9,385 |  |
| Purchase of equity investment | (2,667 | ) |  | (1,767 | ) |
| Acquisition of businesses, net of cash acquired | — |  |  | (82,670 | ) |
| Net cash provided by (used in) investing activities | 24,077 |  |  | (19,383 | ) |
| Cash flows from financing activities: |  |  |  |
| Proceeds from issuance of long-term debt, net | — |  |  | 305,125 |  |
| Payment of long-term debt | (7,000 | ) |  | (292,730 | ) |
| Payment for debt conversion liability | (111,268 | ) |  | — |  |
| Payment for make-whole provision upon conversion of long-term debt | — |  |  | (13,453 | ) |
| Payment of debt issuance costs | (1,191 | ) |  | (1,936 | ) |
| Payment of capital lease obligations | (3,319 | ) |  | (3,624 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units | (29,059 | ) |  | (4,757 | ) |
| Repurchases of common stock - repurchase program | (150,076 | ) |  | (110,981 | ) |
| Proceeds from issuance of common stock | 22,947 |  |  | 23,127 |  |
| Net cash used in financing activities | (278,966 | ) |  | (99,229 | ) |
| Effect of exchange rate changes on cash, cash equivalents and restricted cash | 476 |  |  | (5,856 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash | 158,727 |  |  | 104,793 |  |
| Cash, cash equivalents and restricted cash at beginning of fiscal year | 745,434 |  |  | 640,641 |  |
| Cash, cash equivalents and restricted cash at end of fiscal year | $ | 904,161 |  |  | $ | 745,434 |  |
| Supplemental disclosure of cash flow information |  |  |  |
| Cash paid during the fiscal year for interest | $ | 39,579 |  |  | $ | 44,750 |  |
| Cash paid during the fiscal year for income taxes, net | $ | 33,570 |  |  | $ | 26,900 |  |
| Non-cash investing and financing activities |  |  |  |
| Purchase of equipment in accounts payable | $ | 16,549 |  |  | $ | 5,118 |  |
| Contingent consideration for acquisition of business | $ | — |  |  | $ | 10,900 |  |
| Conversion of 3.75% convertible senior notes, due October 15, 2018 (Original) into 3,038,208 shares of common stock | $ | — |  |  | $ | 61,270 |  |
| Conversion of 4.0% convertible senior notes, due December 15, 2020 into 9,197,943 shares of common stock, net | $ | — |  |  | $ | 214,286 |  |
| Conversion of debt conversion liability into 1,585,140 shares of common stock | $ | 52,944 |  |  | $ | — |  |

[0000936395-19-000051:8k_2_02:68]
| APPENDIX A- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Gross Profit Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP gross profit |  | $ | 419,696 |  |  | $ | 398,075 |  |  | $ | 1,542,066 |  |  | $ | 1,314,690 |  |
| Share-based compensation-products |  | 748 |  |  | 705 |  |  | 2,868 |  |  | 2,984 |  |
| Share-based compensation-services |  | 715 |  |  | 651 |  |  | 3,175 |  |  | 2,616 |  |
| Amortization of intangible assets |  | 3,303 |  |  | 2,957 |  |  | 13,327 |  |  | 10,069 |  |
| Total adjustments related to gross profit |  | 4,766 |  |  | 4,313 |  |  | 19,370 |  |  | 15,669 |  |
| Adjusted (non-GAAP) gross profit |  | $ | 424,462 |  |  | $ | 402,388 |  |  | $ | 1,561,436 |  |  | $ | 1,330,359 |  |
| Adjusted (non-GAAP) gross profit percentage |  | 43.8 | % |  | 44.7 | % |  | 43.7 | % |  | 43.0 | % |
| Operating Expense Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP operating expense |  | $ | 326,494 |  |  | $ | 302,205 |  |  | $ | 1,195,300 |  |  | $ | 1,084,744 |  |
| Share-based compensation-research and development |  | 3,287 |  |  | 3,385 |  |  | 14,321 |  |  | 13,518 |  |
| Share-based compensation-sales and marketing |  | 4,151 |  |  | 3,741 |  |  | 16,474 |  |  | 14,246 |  |
| Share-based compensation-general and administrative |  | 6,425 |  |  | 5,588 |  |  | 22,841 |  |  | 19,709 |  |
| Amortization of intangible assets |  | 5,222 |  |  | 4,654 |  |  | 21,808 |  |  | 15,737 |  |
| Acquisition and integration costs |  | (735 | ) |  | 3,778 |  |  | 3,370 |  |  | 5,111 |  |
| Significant asset impairments and restructuring costs |  | 12,842 |  |  | 1,460 |  |  | 24,538 |  |  | 18,139 |  |
| Legal settlements |  | — |  |  | 1,929 |  |  | 137 |  |  | 4,682 |  |
| Total adjustments related to operating expense |  | $ | 31,192 |  |  | $ | 24,535 |  |  | $ | 103,489 |  |  | $ | 91,142 |  |
| Adjusted (non-GAAP) operating expense |  | $ | 295,302 |  |  | $ | 277,670 |  |  | $ | 1,091,811 |  |  | $ | 993,602 |  |
| Income from Operations Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP income from operations |  | $ | 93,202 |  |  | $ | 95,870 |  |  | $ | 346,766 |  |  | $ | 229,946 |  |
| Total adjustments related to gross profit |  | 4,766 |  |  | 4,313 |  |  | 19,370 |  |  | 15,669 |  |
| Total adjustments related to operating expense |  | 31,192 |  |  | 24,535 |  |  | 103,489 |  |  | 91,142 |  |
| Total adjustments related to income from operations |  | 35,958 |  |  | 28,848 |  |  | 122,859 |  |  | 106,811 |  |
| Adjusted (non-GAAP) income from operations |  | $ | 129,160 |  |  | $ | 124,718 |  |  | $ | 469,625 |  |  | $ | 336,757 |  |
| Adjusted (non-GAAP) operating margin percentage |  | 13.3 | % |  | 13.9 | % |  | 13.1 | % |  | 10.9 | % |

[0000936395-19-000051:8k_2_02:69]
| APPENDIX A- Reconciliation of Adjusted (Non- GAAP) Measurements (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Net Income (Loss) Reconciliation (GAAP/non-GAAP) |  |  |  |  |  |  |  |  |
| GAAP net income (loss) |  | $ | 80,331 |  |  | $ | 63,977 |  |  | $ | 253,434 |  |  | $ | (344,690 | ) |
| Exclude GAAP provision (benefit) for income taxes |  | 2,552 |  |  | (10,224 | ) |  | 59,756 |  |  | 493,471 |  |
| Income before income taxes |  | 82,883 |  |  | 53,753 |  |  | 313,190 |  |  | 148,781 |  |
| Total adjustments related to income from operations |  | 35,958 |  |  | 28,848 |  |  | 122,859 |  |  | 106,811 |  |
| Loss on extinguishment and modification of debt |  | — |  |  | 13,887 |  |  | — |  |  | 13,887 |  |
| Non-cash interest expense |  | — |  |  | 727 |  |  | — |  |  | 2,579 |  |
| Change in fair value of debt conversion liability |  | — |  |  | 12,070 |  |  | — |  |  | 12,070 |  |
| Adjusted income before income taxes |  | 118,841 |  |  | 109,285 |  |  | 436,049 |  |  | 284,128 |  |
| Non-GAAP tax provision on adjusted income before income taxes |  | 28,403 |  |  | 28,272 |  |  | 104,216 |  |  | 73,504 |  |
| Adjusted (non-GAAP) net income |  | $ | 90,438 |  |  | $ | 81,013 |  |  | $ | 331,833 |  |  | $ | 210,624 |  |
| Weighted average basic common shares outstanding |  | 154,852 |  |  | 143,659 |  |  | 155,720 |  |  | 143,738 |  |
| Weighted average dilutive potential common shares outstanding 1 |  | 156,612 |  |  | 157,745 |  |  | 157,612 |  |  | 158,884 |  |
| Net Income (Loss) per Common Share |  |  |  |  |  |  |  |  |
| GAAP diluted net income (loss) per common share |  | $ | 0.51 |  |  | $ | 0.34 |  |  | $ | 1.61 |  |  | $ | (2.49 | ) |
| Adjusted (non-GAAP) diluted net income per common share 2 |  | $ | 0.58 |  |  | $ | 0.53 |  |  | $ | 2.11 |  |  | $ | 1.39 |  |

[0000936395-19-000051:8k_2_02:70]
1.  Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2019 includes 1.8 million shares underlying certain stock option and stock unit awards.

[0000936395-19-000051:8k_2_02:71]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for fiscal 2019 includes 1.9 million shares underlying certain stock option and stock unit awards.

[0000936395-19-000051:8k_2_02:72]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2018 includes 2.0 million shares underlying certain stock option and stock unit awards, 0.7 million and 2.5 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, which were converted by holders thereof immediately prior to maturity during the fourth quarter of fiscal 2018, and 8.9 million shares underlying Ciena's 4.0% convertible senior notes, which were converted at Ciena's election during the fourth quarter of fiscal 2018.

[0000936395-19-000051:8k_2_02:73]
Weighted average dilutive potential common shares outstanding used in calculating adjusted (non-GAAP) diluted net income per common share for fiscal 2018 includes 1.4 million shares underlying certain stock option and stock unit awards, 1.8 million and 2.9 million shares underlying Ciena's "New" and "Original" 3.75% convertible senior notes, respectively, and 9.1 million shares underlying Ciena's 4.0% convertible senior notes.

[0000936395-19-000051:8k_2_02:74]
2.  The calculation of adjusted (non-GAAP) diluted net income per common share for the fourth quarter of fiscal 2018 requires adding back interest expense of approximately $0.4 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $2.3 million associated with Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-19-000051:8k_2_02:75]
The calculation of adjusted (non-GAAP) diluted net income per common share for fiscal 2018 requires adding back interest expense of  approximately $1.8 million associated with Ciena's "Original" 3.75% convertible senior notes and approximately $8.7 million associated with Ciena's 4.0% convertible senior notes to the adjusted (non-GAAP) net income in order to derive the numerator for the adjusted (non-GAAP) earnings per common share calculation.

[0000936395-19-000051:8k_2_02:76]
| APPENDIX B- Calculation of EBITDA and Adjusted EBITDA (unaudited) |
|  |  | Quarter Ended |  | Year Ended |
|  |  | October 31, |  | October 31, |
|  |  | 2019 |  | 2018 |  | 2019 |  | 2018 |
| Earnings Before Interest, Tax, Depreciation and Amortization (EBITDA) |  |  |  |  |  |  |  |  |
| Net income (loss) (GAAP) |  | $ | 80,331 |  |  | $ | 63,977 |  |  | $ | 253,434 |  |  | $ | (344,690 | ) |
| Add: Interest expense |  | 9,136 |  |  | 14,873 |  |  | 37,452 |  |  | 55,249 |  |
| Less: Interest and other income (loss), net |  | (1,183 | ) |  | (13,357 | ) |  | 3,876 |  |  | (12,029 | ) |
| Add: Loss on extinguishment and modification of debt |  | — |  |  | (13,887 | ) |  | — |  |  | (13,887 | ) |
| Add: Provision (benefit) for income taxes |  | 2,552 |  |  | (10,224 | ) |  | 59,756 |  |  | 493,471 |  |
| Add: Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements |  | 22,505 |  |  | 21,110 |  |  | 87,576 |  |  | 84,214 |  |
| Add: Amortization of intangible assets |  | 8,525 |  |  | 7,611 |  |  | 35,136 |  |  | 25,806 |  |
| EBITDA |  | $ | 124,232 |  |  | $ | 124,591 |  |  | $ | 469,478 |  |  | $ | 339,966 |  |
| Add: Shared-based compensation cost |  | 15,290 |  |  | 14,076 |  |  | 59,736 |  |  | 52,972 |  |
| Add: Significant asset impairments and restructuring costs |  | 12,842 |  |  | 1,460 |  |  | 24,538 |  |  | 18,139 |  |
| Add: Acquisition and integration costs |  | (735 | ) |  | 3,778 |  |  | 3,370 |  |  | 5,111 |  |
| Add: Legal settlement |  | — |  |  | 1,929 |  |  | 137 |  |  | 4,682 |  |
| Adjusted EBITDA |  | $ | 151,629 |  |  | $ | 145,834 |  |  | $ | 557,259 |  |  | $ | 420,870 |  |

[0000936395-19-000051:8k_2_02:77]
* * *

[0000936395-19-000051:8k_2_02:78]
The adjusted (non-GAAP) measures above and their reconciliation to Ciena's GAAP results for the periods presented reflect adjustments relating to the following items:

[0000936395-19-000051:8k_2_02:79]
| • | Share-based compensation - a non-cash expense incurred in accordance with share-based compensation accounting guidance. |

[0000936395-19-000051:8k_2_02:80]
| • | Amortization of intangible assets - a non-cash expense arising from the acquisition of intangible assets, principally developed technologies and customer-related intangibles, that Ciena is required to amortize over its expected useful life. |

[0000936395-19-000051:8k_2_02:81]
| • | Acquisition and integration costs - consist of financial, legal and accounting advisors' costs and severance and other employment-related costs related to Ciena's acquisition of Packet Design and DonRiver. Ciena does not believe that these costs are reflective of its ongoing operating expense following its completion of these integration activities. |

[0000936395-19-000051:8k_2_02:82]
| • | Significant asset impairments and restructuring costs - costs incurred as a result of restructuring activities taken to align resources with perceived market opportunities. |

[0000936395-19-000051:8k_2_02:83]
| • | Legal settlements - costs incurred as a result of settlements, during the first quarter of fiscal 2019, the third quarter of fiscal 2018 and the fourth quarter of fiscal 2018. |

[0000936395-19-000051:8k_2_02:84]
| • | Loss on extinguishment and modification of debt - reflects extinguishment of debt costs related to our conversion of Ciena's 4.0% convertible senior notes and debt modification expenses related to refinancing our then existing term loan, both of which occurred during the fourth quarter of fiscal 2018. |

[0000936395-19-000051:8k_2_02:85]
| • | Non-cash interest expense - a non-cash debt discount expense amortized as interest expense during the term of Ciena's 4.0% senior convertible notes, which were converted during the fourth quarter of 2018, relating to the required separate accounting of the equity component of these convertible notes. |

[0000936395-19-000051:8k_2_02:86]
| • | Change in fair value of debt conversion liability - a non-cash loss reflective of a mark to market fair value adjustment related to the outstanding conversion feature of Ciena's "New" 3.75% senior convertible notes. |

[0000936395-19-000051:8k_2_02:87]
| • | Non-GAAP tax provision - consists of current and deferred income tax expense commensurate with the level of adjusted income before income taxes and utilizes a current, blended U.S. and foreign statutory annual tax rate of 23.9% for fiscal 2019, and 25.9% for fiscal 2018. This rate may be subject to change in the future, including as a result of changes in tax policy or tax strategy. |
