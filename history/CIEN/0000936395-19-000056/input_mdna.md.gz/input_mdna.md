# CIEN MD&A — 0000936395-19-000056


## mdna

[0000936395-19-000056:mdna:1]
Item 7.    Management’s Discussion and Analysis of Financial Condition and Results of Operations

[0000936395-19-000056:mdna:2]
The following discussion and analysis should be read in conjunction with our “Selected Consolidated Financial Data” and consolidated financial statements and notes thereto included elsewhere in this annual report.

[0000936395-19-000056:mdna:3]
Overview

[0000936395-19-000056:mdna:4]
We are a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. We provide hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Our solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and other emerging network operators.

[0000936395-19-000056:mdna:5]
Our solutions include our portfolio of Networking Platforms, including our Converged Packet Optical and Packet Networking products, that can be applied from the network core to end user access points, and that allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. We offer Platform Software that provides management and domain control of our hardware solutions and automates network lifecycle operations, including provisioning equipment and services. Through our Blue Planet® Automation Software, we enable network providers to use network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments, streamlining key business and network processes. To complement our hardware and software products, we offer a broad range of services that help our customers build, operate and improve their networks and associated operational environments.

[0000936395-19-000056:mdna:6]
We refer to our complete portfolio vision as the Adaptive Network™. The Adaptive Network emphasizes a programmable network infrastructure, software control and automation capabilities, and network analytics and intelligence. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-19-000056:mdna:7]
Market Opportunity

[0000936395-19-000056:mdna:8]
The markets in which we sell our communications networking solutions have seen significant changes in recent years, including rapid growth in bandwidth demand and network traffic, the proliferation of cloud-based services and new approaches, or “consumption models,” for designing and procuring networking solutions. Emerging services and applications, including 5G mobile communications, fiber deep and the Internet of Things, are further impacting or expected to impact wireline network infrastructures, particularly at the edge of networks, where increased computing power and automation are required to provide the quality of experience demanded by end users. The business models of many network operators are under pressure to constrain their capital expenditure budgets, as they cannot grow their network spending at the rate of bandwidth growth. To address these growing service demands and better manage network cost, many network operators are looking to adopt next-generation infrastructures that are more programmable and better capable of leveraging data for network insight, analytics and automation. Other network operators are pursuing a diverse range of consumption models in their design and procurement of network infrastructure solutions. Our Adaptive Network vision and our business strategy to capitalize on these changing market dynamics include the initiatives set forth in the “Strategy” section of the description of our business in Item 1 of Part 1 of this annual report.

[0000936395-19-000056:mdna:9]
Revenue and Earnings Growth

[0000936395-19-000056:mdna:10]
During fiscal 2019, our revenue and earnings growth accelerated, as we benefited meaningfully from strong network operator demand for capacity, favorable industry and competitive dynamics, and the continued execution of our strategy. Our strategy has focused on innovation leadership, the diversification of our business and customer base, and leveraging our global scale to capture additional market share. From fiscal 2018 to fiscal 2019, our revenue grew from $3.09 billion to $3.57 billion, or approximately 15.4%, and our income from operations grew from $229.9 million to $346.8 million, or approximately 50.8%. Our results can fluctuate and, given the degree of outstanding performance of our business during fiscal 2019, we do not expect that these revenue and profit growth rates will be sustained in future periods.

[0000936395-19-000056:mdna:11]
Business Diversification

[0000936395-19-000056:mdna:12]
We continue to diversify our business across geographies, customer segments and product solutions and applications. In fiscal 2019 and for the last several years, our diversification and global scale have been key contributors to our strong revenue growth despite any challenges in a particular geography, segment or account that may have served as a meaningful revenue contributor in an earlier period. During fiscal 2019, we grew revenue in our North America, EMEA and CALA geographic regions, and across three of our four operating segments. During fiscal 2019, we also grew revenue with our largest service provider customers, particularly in North America, after recent years of declining revenues. During fiscal 2019 we also benefited meaningfully from our strong market position with leading Web-scale providers for data center interconnection applications. Sales to Web-scale provider customers, representing approximately 22% of total revenue and growing over 40% year-over-year, were an important contributor to our annual revenue growth, with certain of these customers among our largest customers by revenue for fiscal 2019. Certain of such customers have announced an intention to reduce capital spending in future periods, and we expect our revenue from Web-scale customers to moderate from the level achieved in fiscal 2019. Our revenue gains from these areas offset a meaningful revenue reduction from our APAC region during fiscal 2019. After recent years of strong growth driven by aggressive network build outs by service providers in India, capital spending in this region decreased year-over-year. We believe our business and financial performance in recent years highlights the benefits of our diverse global business and our ability to target high growth segments within our markets.

[0000936395-19-000056:mdna:13]
Technology Innovation

[0000936395-19-000056:mdna:14]
We believe that our investment capacity and our efforts to push the pace of innovation in our markets, and to provide market-leading offerings ahead of our competitors, are important competitive differentiators that have contributed to the growth of our business during fiscal 2019. We are focused on growing our optical and packet infrastructure business by addressing fast-growing markets and applications, including data center interconnection, packet aggregation and switching, network densification applications including 5G and fiber deep, and access networks and submarine networks. We are also introducing Packet Networking solutions with enhanced IP/Ethernet capabilities that enable our Adaptive Network vision and expand our addressable market into additional applications and layers of the network. Importantly, we are also executing on parallel innovation paths for the next generation of our modem technology – WaveLogic 5 Extreme (WL5e) and WaveLogic 5 Nano (WL5n) – to address customer consumption models ranging from integrated systems to pluggable form factors. Keeping pace with the market’s demand for technology innovation requires considerable research and development investment capacity and expenditures. During fiscal 2019, we invested $548.1 million in research and development activities, an increase of approximately 11.5% compared to fiscal 2018. We believe that remaining competitive in our addressable geographies, markets, and customer segments depends on our continued degree of investment in innovation and our ability to offer leading solutions that enable adoption of next-generation network infrastructures and evolving consumption models for networking solutions.

[0000936395-19-000056:mdna:15]
Investment in Blue Planet Automation Software

[0000936395-19-000056:mdna:16]
We have continued to pursue both organic investments and acquisition opportunities to expand our Blue Planet Automation Software and Services portfolio and business. On November 4, 2019, after the end of fiscal 2019, we acquired privately held Centina Systems, Inc., a provider of service assurance analytics and network performance management solutions. The acquisition of Centina is intended to accelerate Blue Planet’s software strategy of providing closed loop, intelligent automation solutions that help communications service providers analyze network conditions, traffic demands, and resource availability, and determine the best placement of traffic for optimal service quality and resource utilization. See Note 26 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-19-000056:mdna:17]
Consolidated Results of Operations

[0000936395-19-000056:mdna:18]
A discussion regarding our financial condition and results of operations for fiscal 2019 compared to fiscal 2018 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2018 compared to fiscal 2017 can be found under Item 7 of Part II of our Annual Report on Form 10-K for the fiscal year ended October 31, 2018, filed with the SEC on December 21, 2018 (our “2018 Annual Report”), which is available free of charge on the SEC’s website at www.sec.gov and our Investor Relations website at investor.ciena.com.

[0000936395-19-000056:mdna:19]
Operating Segments

[0000936395-19-000056:mdna:20]
During fiscal 2019, we separated our previous Software and Software-Related Services segment into two stand-alone operating segments: (i) Blue Planet Automation Software and Services; and (ii) Platform Software and Services. We separated this operating segment in alignment with and recognition of our corporate strategy to further promote customer adoption of our

[0000936395-19-000056:mdna:21]
Blue Planet Automation Software and Services, and corresponding changes by management to our evaluation of resource allocation for and measurement of performance of this business. Accordingly, as of the end of fiscal 2019, for reporting purposes, our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. Because we previously disclosed our Blue Planet Automation Software and Services and Platform Software and Services as distinct product lines in our presentation of segment revenue for our previous Software and Software-Related Services segment, our presentation of segment revenues has not significantly changed as a result of this separation. See Note 23 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-19-000056:mdna:22]
Fiscal 2019 Compared to Fiscal 2018

[0000936395-19-000056:mdna:23]
Revenue

[0000936395-19-000056:mdna:24]
During fiscal 2019, approximately 16.4% of our revenue was non-U.S. Dollar denominated, primarily including sales in Euros, Japanese Yen, Canadian Dollars, Indian Rupee, British Pounds, and Brazilian Reais. During fiscal 2019 as compared to fiscal 2018, the U.S. Dollar fluctuated against these and other currencies. Consequently, our revenue reported in U.S. Dollars was slightly reduced by approximately $23.4 million, or 0.7%, as compared to fiscal 2018 due to fluctuations in foreign currency. The table below (in thousands, except percentage data) sets forth the changes in our operating segment revenue for the periods indicated:

[0000936395-19-000056:mdna:25]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,562,841 |  |  | 71.8 |  | $ | 2,194,519 |  |  | 70.9 |  | $ | 368,322 |  |  | 16.8 |  |
| Packet Networking | 348,477 |  |  | 9.8 |  | 283,499 |  |  | 9.2 |  | 64,978 |  |  | 22.9 |  |
| Total Networking Platforms | 2,911,318 |  |  | 81.6 |  | 2,478,018 |  |  | 80.1 |  | 433,300 |  |  | 17.5 |  |
| Platform Software and Services | 155,376 |  |  | 4.3 |  | 173,949 |  |  | 5.6 |  | (18,573 | ) |  | (10.7 | ) |
| Blue Planet Automation Software and Services | 54,555 |  |  | 1.5 |  | 26,764 |  |  | 0.9 |  | 27,791 |  |  | 103.8 |  |
| Global Services |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Maintenance Support and Training | 261,337 |  |  | 7.3 |  | 245,161 |  |  | 7.9 |  | 16,176 |  |  | 6.6 |  |
| Installation and Deployment | 148,233 |  |  | 4.1 |  | 128,829 |  |  | 4.2 |  | 19,404 |  |  | 15.1 |  |
| Consulting and Network Design | 41,312 |  |  | 1.2 |  | 41,565 |  |  | 1.3 |  | (253 | ) |  | (0.6 | ) |
| Total Global Services | 450,882 |  |  | 12.6 |  | 415,555 |  |  | 13.4 |  | 35,327 |  |  | 8.5 |  |
| Consolidated revenue | $ | 3,572,131 |  |  | 100.0 |  | $ | 3,094,286 |  |  | 100.0 |  | $ | 477,845 |  |  | 15.4 |  |

[0000936395-19-000056:mdna:26]
_________________________________

[0000936395-19-000056:mdna:27]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:28]
| • | Networking Platforms segment revenue increased, reflecting product line sales increases of $368.3 million of our Converged Packet Optical products and $65.0 million of our Packet Networking products. |

[0000936395-19-000056:mdna:29]
| ◦ | Converged Packet Optical sales increased, primarily reflecting sales increases of $249.7 million of our Waveserver stackable interconnect system and $193.4 million of our 6500 Packet-Optical Platform. These increases were partially offset by a sales decrease of $71.5 million of our 5410/5430 Reconfigurable Switching Systems. Waveserver sales increases reflect sales to Web-scale providers which have been an increasingly important contributor to our overall growth, and certain of these customers were among our largest customers by revenue. 6500 Packet-Optical Platform sales increases primarily reflect increased sales to communications service providers and cable and multiservice operators. |

[0000936395-19-000056:mdna:30]
43

[0000936395-19-000056:mdna:31]
| ◦ | Packet Networking sales increased, primarily reflecting a sales increase of $99.1 million of our 6500 Packet Transport System (PTS) to a North American service provider, partially offset by sales decreases of $14.9 million of our packet networking platform independent software and $11.8 million of our 3000 and 5000 families of service delivery and aggregation switches. Part of our strategy is to continue to grow sales and reduce our concentration of revenue within our Packet Networking product line. |

[0000936395-19-000056:mdna:32]
| • | Platform Software and Services segment revenue decreased, reflecting software sales decreases of $20.1 million due to decreases of $12.0 million and $8.1 million in sales of our legacy software and our Manage, Control and Plan (“MCP”) software, respectively, partially offset by an increase of $1.5 million related to services. We continue to pursue further customer adoption of our MCP software platform and its enhanced features and functionality. As we transition existing customers as well as features and functionality from our legacy software to this platform, we expect revenue declines for our other legacy software solutions within this segment. |

[0000936395-19-000056:mdna:33]
| • | Blue Planet Automation Software and Services segment revenue increased, reflecting software sales increases of $5.1 million and service sales increases of $22.7 million. The increase in our software and service sales include sales of $12.8 million and $16.1 million related to the Packet Design and DonRiver businesses acquired during fiscal 2018, respectively. Our entrance into the software automation market is in the early stages and, as such, revenue from our Blue Planet Automation Software platform has not been significant to date. |

[0000936395-19-000056:mdna:34]
| • | Global Services segment revenue increased, primarily reflecting sales increases of $19.4 million of our installation and deployment services and $16.2 million of our maintenance support. |

[0000936395-19-000056:mdna:35]
Our operating segments engage in business and operations across four geographic regions: North America; EMEA; CALA; and APAC. Results for North America include only activities in the U.S. and Canada. The following table reflects our geographic distribution of revenue principally based on the relevant location for our delivery of products and performance of services. Our revenue, when considered by geographic distribution, can fluctuate significantly, and the timing of revenue recognition for large network projects, particularly outside of North America, can result in large variations in geographic revenue results in any particular period. The table below (in thousands, except percentage data) sets forth the changes in geographic distribution of revenue for the periods indicated:

[0000936395-19-000056:mdna:36]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| North America | $ | 2,351,260 |  |  | 65.8 |  | $ | 1,886,450 |  |  | 61.0 |  | $ | 464,810 |  |  | 24.6 |  |
| EMEA | 566,718 |  |  | 15.9 |  | 464,876 |  |  | 15.0 |  | 101,842 |  |  | 21.9 |  |
| CALA | 152,653 |  |  | 4.3 |  | 140,177 |  |  | 4.5 |  | 12,476 |  |  | 8.9 |  |
| APAC | 501,500 |  |  | 14.0 |  | 602,783 |  |  | 19.5 |  | (101,283 | ) |  | (16.8 | ) |
| Total | $ | 3,572,131 |  |  | 100.0 |  | $ | 3,094,286 |  |  | 100.0 |  | $ | 477,845 |  |  | 15.4 |  |

[0000936395-19-000056:mdna:37]
_________________________________

[0000936395-19-000056:mdna:38]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:39]
| • | North America revenue increased, reflecting increases of $453.6 million within our Networking Platforms segment, $15.4 million within our Global Services segment, and $15.9 million within our Blue Planet Automation Software and Services segment. These increases were partially offset by a decrease of $20.1 million within our Platform Software and Services segment. The Networking Platforms segment revenue increase includes a product line sales increase of $349.5 million of Converged Packet Optical products, primarily related to sales increases of $201.5 million of our 6500 Packet-Optical Platform to communication service providers and $165.9 million of our Waveserver to Web-scale providers. |

[0000936395-19-000056:mdna:40]
| • | EMEA revenue increased, reflecting increases of $91.8 million within our Networking Platforms segment. The increase within our Networking Platforms segment primarily reflects a product line sales increase of $90.4 million of Converged Packet Optical products, primarily related to sales increases of $66.0 million of our Waveserver to Web-scale providers and $33.7 million of our 6500 Packet-Optical Platform primarily to communications submarine network operators. The increase in EMEA revenue was primarily driven by increased sales in the United Kingdom and the Netherlands. |

[0000936395-19-000056:mdna:41]
| • | CALA revenue increased, reflecting increases of $4.3 million within our Networking Platforms segment and $5.8 million within our Global Services segment. The increase in CALA revenue primarily reflects increased sales to cable and multiservice operators and communications services providers in Mexico. |

[0000936395-19-000056:mdna:42]
| • | APAC revenue decreased, reflecting a decrease of $116.4 million within our Networking Platforms segment partially offset by revenue increases of $6.4 million within our Blue Planet Automation Software and Services segment, $5.7 million within our Global Services segment and $3.0 million within our Platform Software and Services segment. The decrease in Networking Platforms segment revenue reflects product line decreases of $74.8 million in Converged Packet Optical sales and $41.6 million in Packet Networking sales, primarily in India and Australia. See “Risk Factors – Changes in government regulations . . .” for additional information regarding an October 2019 regulatory ruling in India that may adversely impact future spending in that geography. The decrease in Converged Packet Optical sales is primarily due to decreases of $46.4 million and $45.8 million in sales of our 6500 Packet-Optical Platform and our 5410/5430 Reconfigurable Switching Systems, respectively, partially offset by an increase of $18.3 million in sales of Waveserver. Although our APAC revenue declined, we experienced increased sales in Japan and continued to capture new market share with communications service providers in the region. |

[0000936395-19-000056:mdna:43]
In fiscal 2019 and fiscal 2018, our top ten customers contributed 59.3% and 56.5% of revenue, respectively. Consequently, our financial results are closely correlated with the spending of a relatively small number of customers and can be significantly affected by market, industry or competitive dynamics affecting their businesses. Our reliance on a relatively small number of customers increases our exposure to changes in their spending levels, network priorities and purchasing strategies. The loss of a significant customer could have a material adverse effect on our business and results of operations, and our results of operations can fluctuate quarterly depending on sales volumes and purchasing priorities with these large customers. Verizon accounted for $459.8 million, or 12.9% of total revenue, in fiscal 2019 and $318.0 million, or 10.3% of total revenue, in fiscal 2018. Sales to AT&T were $388.7 million, or 10.9% of total revenue, in fiscal 2019, and $374.6 million, or 12.1% of total revenue, in fiscal 2018. Sales to one of our Web-scale customers were $370.6 million, or 10.4% of total revenue, in fiscal 2019. No other customer accounted for greater than 10% of our revenue in fiscal 2019 or fiscal 2018. The identity of and percentage of revenue attributable to our largest customers has varied from period to period. For example, the Web-scale provider noted above contributed greater than 10% of our revenue for the first time in fiscal 2019.

[0000936395-19-000056:mdna:44]
While drivers of bandwidth growth and network evolution remain strong, many of our network operator customers are under pressure to constrain their capital expenditure budgets and their businesses cannot grow their network spending at the rate of bandwidth growth. As a result, as we innovate and introduce new and more robust solutions that increase capacity or features, there is a market expectation of solutions that are more cost-effective from a price for performance perspective than existing or competing solutions. The combination of this regular technology-driven price compression, price competition in our markets and ongoing customer efforts to manage network costs can impact our growth rates and requires that we increase our volume of product shipments to maintain and grow revenue.

[0000936395-19-000056:mdna:45]
Cost of Goods Sold and Gross Profit

[0000936395-19-000056:mdna:46]
Product cost of goods sold consists primarily of amounts paid to third-party contract manufacturers, component costs, employee-related costs and overhead, shipping and logistics costs associated with manufacturing-related operations, warranty and other contractual obligations, royalties, license fees, amortization of intangible assets, cost of excess and obsolete inventory and, when applicable, estimated losses on committed customer contracts.

[0000936395-19-000056:mdna:47]
Services cost of goods sold consists primarily of direct and third-party costs associated with our provision of services including installation, deployment, maintenance support, consulting and training activities, and, when applicable, estimated losses on committed customer contracts. The majority of these costs relate to personnel, including employee and third-party contractor-related costs.

[0000936395-19-000056:mdna:48]
Our gross profit as a percentage of revenue, or “gross margin,” can fluctuate due to a number of factors, particularly when viewed on a quarterly basis. Our gross margin can fluctuate and be adversely impacted depending on our revenue concentration within a particular segment, product line, geography, or customer, including our success in selling software in a particular period. Our gross margin remains highly dependent on our continued ability to drive product cost reductions relative to the price erosion that we regularly encounter in our markets. Moreover, we are often required to compete with aggressive pricing and commercial terms, and, to secure business with new and existing customers, we may agree to pricing or other unfavorable commercial terms that adversely affect our gross margin. Success in taking share and winning new business can result in additional pressure on gross margin from these pricing dynamics and the early stages of these network deployments. Early stages of new network builds also often include an increased concentration of lower margin “common” equipment, photonics sales and installation services, with the intent to improve margin as we sell channel cards and maintenance services to

[0000936395-19-000056:mdna:49]
customers adding capacity or services to their networks. Gross margin can be impacted by technology-based price compression and the introduction or substitution of new platforms with improved price for performance as compared to existing solutions that carry higher margins. Gross margin can also be impacted by changes in expense for excess and obsolete inventory and warranty obligations.

[0000936395-19-000056:mdna:50]
Service gross margin can be affected by the mix of customers and services, particularly the mix between deployment and maintenance services, geographic mix and the timing and extent of any investments in internal resources to support this business.

[0000936395-19-000056:mdna:51]
The tables below (in thousands, except percentage data) set forth the changes in revenue, cost of goods sold and gross profit for the periods indicated:

[0000936395-19-000056:mdna:52]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Total revenue | $ | 3,572,131 |  |  | 100.0 |  | $ | 3,094,286 |  |  | 100.0 |  | $ | 477,845 |  |  | 15.4 |
| Total cost of goods sold | 2,030,065 |  |  | 56.8 |  | 1,779,596 |  |  | 57.5 |  | 250,469 |  |  | 14.1 |
| Gross profit | $ | 1,542,066 |  |  | 43.2 |  | $ | 1,314,690 |  |  | 42.5 |  | $ | 227,376 |  |  | 17.3 |

[0000936395-19-000056:mdna:53]
_________________________________

[0000936395-19-000056:mdna:54]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:55]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Product revenue | $ | 2,983,815 |  |  | 100.0 |  | $ | 2,565,460 |  |  | 100.0 |  | $ | 418,355 |  |  | 16.3 |
| Product cost of goods sold | 1,716,358 |  |  | 57.5 |  | 1,507,157 |  |  | 58.7 |  | 209,201 |  |  | 13.9 |
| Product gross profit | $ | 1,267,457 |  |  | 42.5 |  | $ | 1,058,303 |  |  | 41.3 |  | $ | 209,154 |  |  | 19.8 |

[0000936395-19-000056:mdna:56]
_________________________________

[0000936395-19-000056:mdna:57]
| * | Denotes % of product revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:58]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Service revenue | $ | 588,316 |  |  | 100.0 |  | $ | 528,826 |  |  | 100.0 |  | $ | 59,490 |  |  | 11.2 |
| Service cost of goods sold | 313,707 |  |  | 53.3 |  | 272,439 |  |  | 51.5 |  | 41,268 |  |  | 15.1 |
| Service gross profit | $ | 274,609 |  |  | 46.7 |  | $ | 256,387 |  |  | 48.5 |  | $ | 18,222 |  |  | 7.1 |

[0000936395-19-000056:mdna:59]
_________________________________

[0000936395-19-000056:mdna:60]
| * | Denotes % of service revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:61]
| • | Gross profit as a percentage of revenue reflects improved product gross profit as described below. In recent periods, we have encountered fluctuations or reductions in our gross margin as a result of our strategy to leverage our technology leadership and to capture aggressively additional market share and displace competitors, with the intent to improve margin in the long term as we sell channel cards, maintenance services, and other higher margin products to customers adding capacity or services to their networks. During fiscal 2019, our gross margin benefited from the success of this ongoing strategy and the resulting favorable mix of customers, network deployments and capacity additions during the period. Continued implementation of this strategy may require that we agree to aggressive pricing, commercial concessions and other unfavorable terms, or result in an unfavorable mix of revenues from early stage deployments during a particular period, which can adversely impact gross margin. |

[0000936395-19-000056:mdna:62]
| • | Gross profit on products as a percentage of product revenue increased, primarily due to product cost reductions, a favorable mix of customers, network deployments and capacity additions, partially offset by market-based price compression we encountered during the period. |

[0000936395-19-000056:mdna:63]
| • | Gross profit on services as a percentage of services revenue decreased, primarily as a result of lower margins on our Blue Planet Automation software services, due to increased costs associated with additional resources to support our corporate strategy to grow our software automation business, and the impact of early stages of international network deployments. |

[0000936395-19-000056:mdna:64]
Operating Expense

[0000936395-19-000056:mdna:65]
Operating expense increased in fiscal 2019 from the level reported for fiscal 2018 primarily due to increased research and development initiatives and increased selling and marketing resources.

[0000936395-19-000056:mdna:66]
Operating expense consists of the component elements described below.

[0000936395-19-000056:mdna:67]
| • | Research and development expense primarily consists of salaries and related employee expense (including share-based compensation expense), prototype costs relating to design, development, product testing, depreciation expense, and third-party consulting costs. |

[0000936395-19-000056:mdna:68]
| • | Selling and marketing expense primarily consists of salaries, commissions and related employee expense (including share-based compensation expense) and sales and marketing support expense, including travel, demonstration units, trade show expense, and third-party consulting costs. |

[0000936395-19-000056:mdna:69]
| • | General and administrative expense primarily consists of salaries and related employee expense (including share-based compensation expense) and costs for third-party consulting and other services. |

[0000936395-19-000056:mdna:70]
| • | Amortization of intangible assets primarily reflects the amortization of both purchased technology and the value of customer relationships derived from our acquisitions. |

[0000936395-19-000056:mdna:71]
| • | Significant asset impairments and restructuring costs primarily reflect actions we have taken to improve the alignment of our workforce, facilities and operating costs with perceived market opportunities, business strategies, changes in market and business conditions and significant impairments of assets. |

[0000936395-19-000056:mdna:72]
| • | Acquisition and integration costs consist of expenses for financial, legal and accounting advisors, severance and other employee-related costs associated with our acquisitions of Packet Design and DonRiver, including costs associated with a three-year earn-out arrangement related to the DonRiver acquisition. |

[0000936395-19-000056:mdna:73]
During fiscal 2019, approximately 50.7% of our operating expense was non-U.S. Dollar denominated, including expenses in Canadian Dollars, Indian Rupees, British Pounds and Euros. During fiscal 2019 as compared to fiscal 2018, the U.S. Dollar fluctuated against these currencies. Our operating expense reported in U.S. Dollars decreased by approximately $17.5 million, or 1.5%, as compared to fiscal 2018 due to these fluctuations.

[0000936395-19-000056:mdna:74]
The table below (in thousands, except percentage data) sets forth the changes in operating expense for the periods indicated:

[0000936395-19-000056:mdna:75]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Research and development | $ | 548,139 |  |  | 15.3 |  | $ | 491,564 |  |  | 15.9 |  | $ | 56,575 |  |  | 11.5 |  |
| Selling and marketing | 423,046 |  |  | 11.8 |  | 394,060 |  |  | 12.7 |  | 28,986 |  |  | 7.4 |  |
| General and administrative | 174,399 |  |  | 4.9 |  | 160,133 |  |  | 5.2 |  | 14,266 |  |  | 8.9 |  |
| Amortization of intangible assets | 21,808 |  |  | 0.6 |  | 15,737 |  |  | 0.5 |  | 6,071 |  |  | 38.6 |  |
| Acquisition and integration costs | 3,370 |  |  | 0.1 |  | 5,111 |  |  | 0.2 |  | (1,741 | ) |  | (34.1 | ) |
| Significant asset impairments and restructuring costs | 24,538 |  |  | 0.7 |  | 18,139 |  |  | 0.6 |  | 6,399 |  |  | 35.3 |  |
| Total operating expenses | $ | 1,195,300 |  |  | 33.4 |  | $ | 1,084,744 |  |  | 35.1 |  | $ | 110,556 |  |  | 10.2 |  |

[0000936395-19-000056:mdna:76]
_________________________________

[0000936395-19-000056:mdna:77]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:78]
| • | Research and development expense benefited by $8.1 million as a result of foreign exchange rates, net of hedging, primarily due to a stronger U.S. Dollar in relation to the Canadian Dollar and Indian Rupee. Including the effect of foreign exchange rates, research and development expenses increased by $56.6 million. This increase primarily reflects $19.9 million in employee and compensation costs, $16.9 million in professional services, $9.7 million for facility and information technology costs, $3.3 million in prototype expense and $1.0 million in technology and related expense. This increase also reflects a reduced benefit of $4.4 million for the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation (“ENCQOR”) grant reimbursement. For more information on the ENCQOR grant, see Note 25 to our Consolidated Financial Statements included in Item 8 of Part II of this report. |

[0000936395-19-000056:mdna:79]
| • | Selling and marketing expense benefited by $7.5 million as a result of foreign exchange rates primarily due to a stronger U.S. Dollar in relation to the British Pound and Canadian Dollar. Including the effect of foreign exchange rates, sales and marketing expense increased, primarily reflecting increases of $22.9 million in employee and compensation costs and $5.7 million for facilities and information technology costs. |

[0000936395-19-000056:mdna:80]
| • | General and administrative expense increased, primarily reflecting increases of $8.7 million in employee and compensation costs and $4.0 million for bad debt expense. |

[0000936395-19-000056:mdna:81]
| • | Amortization of intangible assets increased due to additional intangibles acquired in connection with our acquisitions of Packet Design and DonRiver during fiscal 2018. |

[0000936395-19-000056:mdna:82]
| • | Acquisition and integration costs reflect financial, legal and accounting advisors and severance and other employment-related costs related to our acquisitions of Packet Design and DonRiver. |

[0000936395-19-000056:mdna:83]
| • | Significant asset impairments and restructuring costs reflect global workforce reductions as part of a business optimization strategy to improve gross margin, constrain operating expense, and redesign certain business processes and unfavorable lease commitments for certain facility locations in the United States and India where we have vacated unused space. |

[0000936395-19-000056:mdna:84]
Other Items

[0000936395-19-000056:mdna:85]
The table below (in thousands, except percentage data) sets forth the changes in other items for the periods indicated:

[0000936395-19-000056:mdna:86]
|  | Fiscal Year |  |  |  |  |
|  | 2019 |  | %* |  | 2018 |  | %* |  | Increase(decrease) |  | %** |
| Interest and other income (loss), net | $ | 3,876 |  |  | 0.1 |  | $ | (12,029 | ) |  | (0.4 | ) |  | $ | 15,905 |  |  | (132.2 | ) |
| Interest expense | $ | 37,452 |  |  | 1.0 |  | $ | 55,249 |  |  | 1.8 |  |  | $ | (17,797 | ) |  | (32.2 | ) |
| Loss on extinguishment/modification of debt | $ | — |  |  | — |  | $ | (13,887 | ) |  | (0.4 | ) |  | $ | (13,887 | ) |  | 100.0 |  |
| Provision for income taxes | $ | 59,756 |  |  | 1.7 |  | $ | 493,471 |  |  | 15.9 |  |  | $ | (433,715 | ) |  | (87.9 | ) |

[0000936395-19-000056:mdna:87]
_________________________________

[0000936395-19-000056:mdna:88]
| * | Denotes % of total revenue |
| ** | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:89]
| • | Interest and other income, net increased, reflecting a $2.8 million favorable impact of foreign exchange rates on assets and liabilities denominated in a currency other than the relevant functional currency, net of hedging activity. Interest and other income, net, in fiscal 2018 included a $12.1 million loss due to a mark to market fair value adjustment related to the conversion feature of our 3.75% Convertible Senior Notes due October 15, 2018 (the “New Notes”). |

[0000936395-19-000056:mdna:90]
| • | Interest expense decreased, primarily due to a reduction in our aggregate outstanding debt during the fourth quarter of fiscal 2018. |

[0000936395-19-000056:mdna:91]
| • | Loss on extinguishment and modification of debt in fiscal 2018 reflects approximately $10.0 million of extinguishment of debt costs related to our conversion of our 4.0% Convertible Senior Notes due December 15, 2020 and approximately $3.8 million in debt modification costs related to our term loan refinancing. |

[0000936395-19-000056:mdna:92]
48

[0000936395-19-000056:mdna:93]
| • | Provision for income taxes decreased, primarily due to the fiscal 2018 impact of the Tax Act, including $438.2 million in expenses for the remeasurement of our net deferred tax assets and a $34.6 million charge related to a transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. The effective tax rate for fiscal 2019 was lower compared to fiscal 2018, primarily due to the fiscal 2018 impact of the Tax Act, including the remeasurement of our net deferred tax assets and the transition tax on accumulated historical foreign earnings and their deemed repatriation to the U.S. |

[0000936395-19-000056:mdna:94]
Segment Profit (Loss)

[0000936395-19-000056:mdna:95]
The table below (in thousands, except percentage data) sets forth the changes in our segment profit (loss) for the respective periods:

[0000936395-19-000056:mdna:96]
|  | Fiscal Year |  |  |
|  | 2019 |  | 2018 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Networking Platforms | $ | 759,244 |  |  | $ | 581,113 |  |  | $ | 178,131 |  |  | 30.7 |  |
| Platform Software and Services | $ | 64,210 |  |  | $ | 78,048 |  |  | $ | (13,838 | ) |  | (17.7 | ) |
| Blue Planet Automation Software and Services | $ | (17,769 | ) |  | $ | (8,240 | ) |  | $ | (9,529 | ) |  | 115.6 |  |
| Global Services | $ | 188,242 |  |  | $ | 172,205 |  |  | $ | 16,037 |  |  | 9.3 |  |

[0000936395-19-000056:mdna:97]
_________________________________

[0000936395-19-000056:mdna:98]
| * | Denotes % change from 2018 to 2019 |

[0000936395-19-000056:mdna:99]
| • | Networking Platforms segment profit increased, primarily due to higher sales volume and improved gross margin, as described above, partially offset by higher research and development costs. |

[0000936395-19-000056:mdna:100]
| • | Platform Software and Services segment profit decreased, primarily due to lower sales volume, as described above. |

[0000936395-19-000056:mdna:101]
| • | Blue Planet Automation Software and Services segment loss increased, primarily reflecting higher research and development costs and reduced gross margin on software-related services, as described above, and the impact of early stages of international network deployment. |

[0000936395-19-000056:mdna:102]
| • | Global Services segment profit increased, primarily due to higher sales volume and improved gross margin. |

[0000936395-19-000056:mdna:103]
The table below (in thousands) sets forth segment profit (loss) for Ciena’s software operating segments for fiscal 2018 and 2017 to reflect the change in Ciena’s operating segments as described in “Operating Segments” above:

[0000936395-19-000056:mdna:104]
|  | Fiscal Year |  |  |
|  | 2018 |  | 2017 |  | Increase(decrease) |  | %* |
| Segment profit (loss): |  |  |  |  |  |  |  |
| Platform Software and Services | $ | 78,048 |  |  | $ | 47,353 |  |  | $ | 30,695 |  |  | 64.8 |  |
| Blue Planet Automation Software and Services | $ | (8,240 | ) |  | $ | (14,817 | ) |  | $ | 6,577 |  |  | (44.4 | ) |

[0000936395-19-000056:mdna:105]
| • | Platform Software and Services segment profit increased, primarily due to higher sales volume as described in Item 7 of Part II of our 2018 Annual Report. |

[0000936395-19-000056:mdna:106]
| • | Blue Planet Automation Software and Services segment loss decreased, primarily reflecting higher revenues as described in Item 7 of Part II of our 2018 Annual Report, and lower research and development costs, partially offset by reduced gross margin on software-related services. |

[0000936395-19-000056:mdna:107]
Liquidity and Capital Resources

[0000936395-19-000056:mdna:108]
Overview. For the fiscal year ended October 31, 2019, we generated $413.1 million of cash from operations, as our net income (adjusted for non-cash charges) of $512.7 million exceeded our working capital requirements of $99.6 million. For additional details on our cash provided by operating activities, see the discussion below under the caption “Cash Provided By Operating Activities.”

[0000936395-19-000056:mdna:109]
Our cash, cash equivalents and investments increased by $70.6 million during fiscal 2019. The cash from operations above was partially offset by the following: (i) cash used for the payment of the debt conversion liability associated with the New Notes of $111.3 million on November 15, 2018; (ii) cash used to fund our investing activities for capital expenditures totaling $62.6 million; (iii) cash used for stock repurchase under our stock repurchase program of $150.1 million; (iv) stock repurchased upon vesting of our stock unit awards to employees relating to tax withholding of $29.1 million; and (v) cash used for payments on our term loan due September 28, 2025 (the “2025 Term Loan”) of $7.0 million. Proceeds from the issuance of equity under our employee stock purchase plans provided $22.9 million in cash during fiscal 2019.

[0000936395-19-000056:mdna:110]
See Notes 15, 17 and 20 to our Consolidated Financial Statements included in Item 8 of Part II of this report for information relating to these transactions.

[0000936395-19-000056:mdna:111]
The following table sets forth changes in our cash and cash equivalents and investments in marketable debt securities (in thousands):

[0000936395-19-000056:mdna:112]
|  | October 31, |  | Increase |
|  | 2019 |  | 2018 |  | (decrease) |
| Cash and cash equivalents | $ | 904,045 |  |  | $ | 745,423 |  |  | $ | 158,622 |  |
| Short-term investments in marketable debt securities | 109,940 |  |  | 148,981 |  |  | (39,041 | ) |
| Long-term investments in marketable debt securities | 10,014 |  |  | 58,970 |  |  | (48,956 | ) |
| Total cash and cash equivalents and investments in marketable debt securities | $ | 1,023,999 |  |  | $ | 953,374 |  |  | $ | 70,625 |  |

[0000936395-19-000056:mdna:113]
Principal Sources of Liquidity. Our principal sources of liquidity on hand include our cash and investments, which as of October 31, 2019 totaled $1.02 billion, as well as our senior secured asset-based revolving credit facility (the “ABL Credit Facility”). The ABL Credit Facility, which we entered into with certain of our subsidiaries on October 28, 2019, replaced a predecessor senior secured asset-based revolving credit facility and provides for a total commitment of $300 million with a maturity date of October 28, 2024. We principally use the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of our business and thereby to reduce our use of cash required to collateralize these instruments. As of October 31, 2019, letters of credit totaling $72.9 million were outstanding under our ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2019.

[0000936395-19-000056:mdna:114]
Foreign Liquidity. The amount of cash, cash equivalents and short-term investments held by our foreign subsidiaries was $73.9 million as of October 31, 2019. We intend to reinvest indefinitely our foreign earnings. If we were to repatriate these accumulated historical foreign earnings, the provisional amount of unrecognized deferred income tax liability related to foreign withholding taxes would be approximately $31.0 million. See Note 21 to our Consolidated Financial Statements included in Item 8 of Part II of this report.

[0000936395-19-000056:mdna:115]
Stock Repurchase Authorization. On December 13, 2018, we announced that our Board of Directors authorized a program to repurchase up to $500 million of our common stock. We repurchased $150.1 million under this program during fiscal 2019, and had $349.9 million remaining under the current authorization as of October 31, 2019. The amount and timing of repurchases are subject to a variety of factors including liquidity, cash flow, stock price and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-19-000056:mdna:116]
Liquidity Position. We regularly evaluate our liquidity position, debt obligations and anticipated cash needs to fund our operating or investment plans and may consider capital raising and other market opportunities that may be available to us. We regularly evaluate alternatives to manage our capital structure and reduce our debt and may continue to opportunistically pay down or refinance our outstanding debt. Based on past performance and current expectations, we believe that cash from operations, cash, cash equivalents and investments and other sources of liquidity, including our ABL Credit Facility, will satisfy our working capital needs, capital expenditures and other liquidity requirements associated with our operations, through at least the next 12 months.

[0000936395-19-000056:mdna:117]
Cash Provided by Operating Activities

[0000936395-19-000056:mdna:118]
The following sections set forth the components of our $413.1 million of cash provided by operating activities for fiscal 2019:

[0000936395-19-000056:mdna:119]
Net income (adjusted for non-cash charges)

[0000936395-19-000056:mdna:120]
The following tables set forth (in thousands) our net income adjusted for non-cash charges during fiscal 2019:

[0000936395-19-000056:mdna:121]
|  | Year ended |
|  | October 31, 2019 |
| Net income | $ | 253,434 |  |
| Adjustments for non-cash charges: |  |
| Depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements | 87,576 |  |
| Share-based compensation costs | 59,736 |  |
| Amortization of intangible assets | 35,136 |  |
| Deferred taxes | 19,865 |  |
| Provision for doubtful accounts | 6,740 |  |
| Provision for inventory excess and obsolescence | 28,085 |  |
| Provision for warranty | 23,105 |  |
| Other | (910 | ) |
| Net income (adjusted for non-cash charges) | $ | 512,767 |  |

[0000936395-19-000056:mdna:122]
Working Capital

[0000936395-19-000056:mdna:123]
Our working capital used $99.6 million of cash during fiscal 2019. The following tables set forth (in thousands) the major components of the increase in working capital:

[0000936395-19-000056:mdna:124]
|  | Year ended |
|  | October 31, 2019 |
| Cash provided by accounts receivable | $ | 65,712 |  |
| Cash used in inventories | (112,941 | ) |
| Cash used in prepaid expenses and other | (96,618 | ) |
| Cash provided by accounts payable, accruals and other obligations | 27,740 |  |
| Cash provided by deferred revenue | 16,480 |  |
| Cash used in working capital | $ | (99,627 | ) |

[0000936395-19-000056:mdna:125]
As compared to the end of fiscal 2018:

[0000936395-19-000056:mdna:126]
| • | The $65.7 million of cash provided by accounts receivable during fiscal 2019 reflects increased cash collection; |

[0000936395-19-000056:mdna:127]
| • | The $112.9 million of cash used in inventory during fiscal 2019 primarily reflects increases in finished goods to meet customer delivery schedules; |

[0000936395-19-000056:mdna:128]
| • | The $96.6 million of cash used in prepaid expenses and other during fiscal 2019 primarily reflects increases in contract assets for unbilled accounts receivable due to changes in revenue recognition for installation services and certain product sales; |

[0000936395-19-000056:mdna:129]
| • | The $27.7 million of cash provided by accounts payable, accruals and other obligations during fiscal 2019 primarily reflects higher employee bonus accrual associated with our annual cash incentive compensation plan, partially offset by payout of accrued employee leave in North America in connection with a new paid time off policy; and |

[0000936395-19-000056:mdna:130]
| • | The $16.5 million of cash provided by deferred revenue during fiscal 2019 represents an increase in advanced payments received from customers prior to revenue recognition. |

[0000936395-19-000056:mdna:131]
Our days sales outstanding (“DSOs”) were 82 for fiscal 2019 as compared to 92 for fiscal 2018. Our inventory turns decreased from 5.7 turns during fiscal 2018 to 5.0 turns during fiscal 2019 due to the increase in inventory. The calculation of DSOs includes accounts receivables and contract assets for unbilled receivables included in prepaid expenses and other.

[0000936395-19-000056:mdna:132]
Cash paid for interest

[0000936395-19-000056:mdna:133]
The following tables set forth (in thousands) our interest paid during fiscal 2019:

[0000936395-19-000056:mdna:134]
|  | Year ended |
|  | October 31, 2019 |
| Term Loan due September 28, 2025(1) | 30,751 |  |
| Interest rate swaps(2) | 2,112 |  |
| ABL Credit Facilities(3) | 1,620 |  |
| Capital leases | 5,096 |  |
| Total cash paid during period | $ | 39,579 |  |

[0000936395-19-000056:mdna:135]
| (1) | Interest on the 2025 Term Loan is payable periodically based on the interest period selected for borrowing. The 2025 Term Loan bears interest at LIBOR plus a spread of 2.00% subject to a minimum LIBOR rate of 0.00%. As of the end of fiscal 2019, the interest rate on the 2025 Term Loan was 3.85%. |

[0000936395-19-000056:mdna:136]
| (2) | We entered into a floating-to-fixed interest rate swap that fixed the LIBOR rate of approximately $350.0 million of the principal amount of the 2025 Term Loan at 2.957% through September 2023. |

[0000936395-19-000056:mdna:137]
| (3) | During fiscal 2019, we utilized the ABL Credit Facility and its predecessor to collateralize certain standby letters of credit and paid $1.6 million in commitment fees, interest expense and other administrative charges relating to these facilities. |

[0000936395-19-000056:mdna:138]
For additional information about our term loans, ABL Credit Facility and interest rate swaps, see Notes 15, 17 and 18 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report.

[0000936395-19-000056:mdna:139]
Contractual Obligations

[0000936395-19-000056:mdna:140]
The following is a summary of our future minimum payments under contractual obligations as of October 31, 2019 (in thousands):

[0000936395-19-000056:mdna:141]
|  | Total |  | Less than oneyear |  | One to threeyears |  | Three to fiveyears |  | Thereafter |
| Principal due on Term Loan due September 28, 2025(1) | $ | 693,000 |  |  | $ | 7,000 |  |  | $ | 14,000 |  |  | $ | 14,000 |  |  | $ | 658,000 |  |
| Interest due on Term Loan due September 28, 2025(1) | 156,040 |  |  | 26,934 |  |  | 53,049 |  |  | 52,098 |  |  | 23,959 |  |
| Payments due under interest rate swaps(1) | 15,440 |  |  | 3,941 |  |  | 7,882 |  |  | 3,617 |  |  | — |  |
| Operating leases(2) | 119,862 |  |  | 28,776 |  |  | 40,951 |  |  | 24,025 |  |  | 26,110 |  |
| Purchase obligations(3) | 495,150 |  |  | 495,150 |  |  | — |  |  | — |  |  | — |  |
| Capital leases - buildings and equipment(4) | 106,319 |  |  | 7,652 |  |  | 15,407 |  |  | 16,134 |  |  | 67,126 |  |
| Other obligations | 34 |  |  | 34 |  |  | — |  |  | — |  |  | — |  |
| Total (5) | $ | 1,585,845 |  |  | $ | 569,487 |  |  | $ | 131,289 |  |  | $ | 109,874 |  |  | $ | 775,195 |  |

[0000936395-19-000056:mdna:142]
_________________________________

[0000936395-19-000056:mdna:143]
| (1) | Interest on the 2025 Term Loan and payments due under the interest rate swaps is variable and is calculated using the rate in effect on the balance sheet date. For additional information about our term loans and the interest rate swaps, see Notes 15 and 17 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report and Item 7A of Part II of this annual report. |

[0000936395-19-000056:mdna:144]
| (2) | Does not include variable insurance, taxes, maintenance and other costs that may be required by the applicable operating lease. These costs are not expected to have a material future impact. |

[0000936395-19-000056:mdna:145]
| (3) | Purchase obligations relate to purchase order commitments to our contract manufacturers and component suppliers for inventory. In certain instances, we are permitted to cancel, reschedule or adjust these orders. Consequently, only a portion of the amount reported above relates to firm, non-cancelable and unconditional obligations. |

[0000936395-19-000056:mdna:146]
| (4) | This represents the total minimum lease payments due for all buildings and equipment subject to capital lease accounting. It does not include variable insurance, taxes, maintenance and other costs required by the applicable capital lease. These costs are not expected to have a material future impact. |

[0000936395-19-000056:mdna:147]
| (5) | As of October 31, 2019, we also had $13.1 million of other long-term obligations on our Consolidated Balance Sheet for unrecognized tax positions that are not included in this table because the timing or amount of any cash settlement with the respective tax authority cannot be reasonably estimated. |

[0000936395-19-000056:mdna:148]
52

[0000936395-19-000056:mdna:149]
Some of our commercial commitments, including some of the future minimum payments in operating leases set forth above and certain commitments to customers, are secured by standby letters of credit collateralized under our ABL Credit Facility or restricted cash. Restricted cash balances are included in other current assets or other long-term assets depending on the duration of the underlying letter of credit obligation. The following is a summary of our commercial commitments secured by standby letters of credit by commitment expiration date as of October 31, 2019 (in thousands):

[0000936395-19-000056:mdna:150]
|  | Total |  | Less than oneyear |  | One tothree years |  | Three tofive years |  | Thereafter |
| Standby letters of credit | $ | 72,920 |  |  | $ | 29,077 |  |  | $ | 21,741 |  |  | $ | 12,847 |  |  | $ | 9,255 |  |

[0000936395-19-000056:mdna:151]
Off-Balance Sheet Arrangements

[0000936395-19-000056:mdna:152]
We do not engage in any off-balance sheet financing arrangements. In particular, we do not have any equity interests in so-called limited purpose entities, which include special purpose entities (SPEs) and structured finance entities.

[0000936395-19-000056:mdna:153]
Critical Accounting Policies and Estimates

[0000936395-19-000056:mdna:154]
The preparation of our consolidated financial statements requires that we make estimates and judgments that affect the reported amounts of assets, liabilities, revenue and expense, and related disclosure of contingent assets and liabilities. By their nature, these estimates and judgments are subject to an inherent degree of uncertainty. On an ongoing basis, we reevaluate our estimates, including those related to share-based compensation, bad debts, inventories, intangible and other long-lived assets, goodwill, income taxes, warranty obligations, restructuring, derivatives and hedging, and contingencies and litigation. We base our estimates on historical experience and on various other assumptions that we believe to be reasonable under the circumstances. Among other things, these estimates form the basis for judgments about the carrying values of assets and liabilities that are not readily apparent from other sources. Actual results may differ from these estimates under different assumptions or conditions. To the extent that there are material differences between our estimates and actual results, our consolidated financial statements will be affected.

[0000936395-19-000056:mdna:155]
We believe that the following critical accounting policies reflect those areas where significant judgments and estimates are used in the preparation of our consolidated financial statements.

[0000936395-19-000056:mdna:156]
Revenue Recognition

[0000936395-19-000056:mdna:157]
We recognize revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which we expect to be entitled in exchange for those products or services.

[0000936395-19-000056:mdna:158]
We determine revenue recognition by applying the following five-step approach:

[0000936395-19-000056:mdna:159]
•identification of the contract, or contracts, with a customer;

[0000936395-19-000056:mdna:160]
•identification of the performance obligations in the contract;

[0000936395-19-000056:mdna:161]
•determination of the transaction price;

[0000936395-19-000056:mdna:162]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-19-000056:mdna:163]
•recognition of revenue when, or as, we satisfy a performance obligation.

[0000936395-19-000056:mdna:164]
Generally, we make sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of our products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. We evaluate each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, we consider, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where we deliver the product or services, we are typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-19-000056:mdna:165]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Our other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, we have not provided any material financing arrangements to its customers. As a practical expedient, we do not adjust the amount of consideration we will receive for the effects of a significant financing component as we expect, at contract inception, that the period between our transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. We record revenue net of any associated sales taxes.

[0000936395-19-000056:mdna:166]
We recognize revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation and various professional services as the customer receives the benefit over the contract term.

[0000936395-19-000056:mdna:167]
Significant Judgments

[0000936395-19-000056:mdna:168]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which we would expect to sell that product or service on a stand-alone basis at contract inception and that we would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when we sell the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000936395-19-000056:mdna:169]
We apply judgment in determining the transaction price, as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that we offer to our distributors, partners and customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. We also consider any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-19-000056:mdna:170]
When transfer of control is judged to be over time for installation and professional service arrangements, we apply the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, we recognize revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-19-000056:mdna:171]
Our total deferred revenue for products was $27.4 million and $42.5 million as of October 31, 2019 and October 31, 2018, respectively. Our services revenue is deferred and recognized ratably over the period during which the services are to be performed. Our total deferred revenue for services was $129.5 million and $127.0 million as of October 31, 2019 and October 31, 2018, respectively.

[0000936395-19-000056:mdna:172]
For further discussion of revenue recognition, see Note 1 to our Consolidated Financial Statements in Item 8 of Part II of this annual report.

[0000936395-19-000056:mdna:173]
Business Combinations

[0000936395-19-000056:mdna:174]
We record acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed in order to allocate purchase price consideration properly between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Our estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Our significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital, and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and

[0000936395-19-000056:mdna:175]
unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates. During fiscal 2018, we completed the Packet Design acquisition for a purchase price of $41.1 million and the DonRiver acquisition for a purchase price of $54.2 million, including a contingent consideration component. See Note 3 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for more information regarding these transactions and the three-year earn-out arrangement in connection with the DonRiver acquisition.

[0000936395-19-000056:mdna:176]
Share-Based Compensation

[0000936395-19-000056:mdna:177]
We estimate the fair value of our restricted stock unit awards based on the fair value of our common stock on the date of grant. Our outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. We recognize the estimated fair value of service-based awards as share-based expense ratably over the vesting period on a straight-line basis. Awards with performance-based vesting conditions require the achievement of certain financial or other performance criteria or targets as a condition to the vesting, or acceleration of vesting. We recognize the estimated fair value of performance-based awards as share-based expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on our determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, we reassess the probability of achieving the performance targets and the performance period required to meet those targets, and the expense is adjusted accordingly. Determining whether the performance targets will be achieved involves judgment, and the estimate of expense may be revised periodically based on changes in the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation cost is reversed.

[0000936395-19-000056:mdna:178]
Share-based compensation expense is taken into account based on awards granted. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of our share-based compensation. See Note 22 to our Consolidated Financial Statements in Item 8 of Part II of this annual report for information regarding our assumptions related to share-based compensation and the amount of share-based compensation expense we incurred for the periods covered in this report. As of October 31, 2019, total unrecognized compensation expense was $88.2 million, which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.45 years.

[0000936395-19-000056:mdna:179]
We are required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-19-000056:mdna:180]
Reserve for Inventory Obsolescence

[0000936395-19-000056:mdna:181]
We make estimates about future customer demand for our products when establishing the appropriate reserve for excess and obsolete inventory. We write down inventory that has become obsolete or unmarketable by an amount equal to the difference between the cost of inventory and the estimated market value based on assumptions about future demand, which are affected by changes in our strategic direction, discontinuance of a product or introduction of newer versions of our products, declines in the sales of or forecasted demand for certain products, and general market conditions. Inventory write downs are a component of our product cost of goods sold. Upon recognition of the write down, a new lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In an effort to limit our exposure to delivery delays and to satisfy customer needs, we purchase inventory based on forecasted sales across our product lines. In addition, part of our research and development strategy is to promote the convergence of similar features and functionalities across our product lines. Each of these practices exposes us to the risk that our customers will not order products for which we have forecasted sales, or will purchase less than we have forecasted.

[0000936395-19-000056:mdna:182]
We recorded charges for excess and obsolete inventory of $28.1 million, $30.6 million and $35.5 million in fiscal 2019, 2018 and 2017, respectively. Our inventory, net of allowance for excess and obsolescence, was $345.0 million and $262.8 million as of October 31, 2019 and October 31, 2018, respectively.

[0000936395-19-000056:mdna:183]
Allowance for Doubtful Accounts Receivable

[0000936395-19-000056:mdna:184]
Our allowance for doubtful accounts receivable is based on management’s assessment, on a specific identification basis, of the collectibility of customer accounts. We perform ongoing credit evaluations of our customers and generally have not required collateral or other forms of security from customers. In determining the appropriate balance for our allowance for doubtful accounts receivable, management considers each individual customer account receivable in order to determine collectibility. In doing so, we consider creditworthiness, payment history, account activity and communication with such customer. If a customer’s financial condition changes, or if actual defaults are higher than our historical experience, we may be

[0000936395-19-000056:mdna:185]
required to take a charge for an allowance for doubtful accounts receivable which could have an adverse impact on our results of operations.

[0000936395-19-000056:mdna:186]
Our accounts receivable, net of allowance for doubtful accounts, was $724.9 million and $786.5 million as of October 31, 2019 and October 31, 2018, respectively. Our allowance for doubtful accounts was $20.1 million and $17.4 million as of October 31, 2019 and October 31, 2018, respectively.

[0000936395-19-000056:mdna:187]
Goodwill

[0000936395-19-000056:mdna:188]
Our goodwill was generated from the acquisitions of (i) Cyan during fiscal 2015, (ii) the high-speed photonics components assets of TeraXion during fiscal 2016, (iii) Packet Design on July 2, 2018, and (iv) DonRiver on October 1, 2018. The goodwill from these acquisitions is primarily related to expected synergies. Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. We test goodwill for impairment on an annual basis, which we have determined to be the last business day of fiscal September each year. We also test goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-19-000056:mdna:189]
We test goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. Goodwill is allocated to reporting units based on relative fair value using a discounted cash flow model. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If we are required to take a substantial impairment charge, our operating results would be materially adversely affected in such period. As of October 31, 2019 and October 31, 2018, the goodwill balance was $297.9 million and $298.0 million, respectively. There were no goodwill impairments resulting from our fiscal 2019 and 2018 impairment tests and no reporting unit was determined to be at risk of failing the goodwill impairment test. See Note 13 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-19-000056:mdna:190]
Long-lived Assets

[0000936395-19-000056:mdna:191]
Our long-lived assets include equipment, building, furniture and fixtures, finite-lived intangible assets and maintenance spares. As of October 31, 2019 and October 31, 2018 these assets totaled $455.1 million and $486.0 million, net, respectively. We test long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the assets’ carrying amount is not recoverable from its undiscounted cash flows. Our long-lived assets are assigned to asset groups which represent the lowest level for which we identify cash flows. We measure impairment loss as the amount by which the carrying amount of the asset or asset group exceeds its fair value.

[0000936395-19-000056:mdna:192]
Deferred Tax Assets

[0000936395-19-000056:mdna:193]
Pursuant to ASC Topic 740, Income Taxes, we maintain a valuation allowance for a deferred tax asset when it is deemed to be more likely than not that some or all of the deferred tax asset will not be realized. The ultimate realization of deferred tax assets is dependent on the generation of future taxable income (including the reversals of deferred tax liabilities) during the periods in which those deferred tax assets will become deductible. In evaluating whether a valuation allowance is required under such rules, we consider all available positive and negative evidence, including prior operating results, the nature and reason for any losses, our forecast of future taxable income, utilization of tax planning strategies, and the dates on which any deferred tax assets are expected to expire. These assumptions and estimates require a significant amount of judgment and are made based on current and projected circumstances and conditions.

[0000936395-19-000056:mdna:194]
Quarterly, we perform an analysis to determine the likelihood of realizing our deferred tax assets and whether sufficient evidence exists to support reversal of all or a portion of the valuation allowance. During the fourth quarter of fiscal 2017, this analysis consisted of the evaluation of all available positive and negative evidence, including our improved profitability in fiscal 2016 and fiscal 2017. We also considered third-party estimates of market growth and our internal projections of future profitability as indicated in our annual update to our operating plan for fiscal 2018 and our long-term strategic forecast which were completed during the fourth quarter of fiscal 2017. We also considered our strong performance against our annual operating plans in recent years and our ability to utilize tax planning strategies. Based on this analysis, we concluded that it was more likely than not that the majority of our U.S. deferred tax assets will be realized, and we therefore reversed most of the valuation allowance against those deferred assets. This reversal resulted in a one-time, non-cash income tax benefit of $1.2 billion and a $26.0 million adjustment to additional paid-in capital. The valuation allowance balances at October 31, 2019 and October 31, 2018 were $136.0 million and $142.7 million, respectively.  The corresponding net deferred tax assets were $714.9 million and $745.0 million, respectively. We will continue to evaluate future financial performance to determine whether such

[0000936395-19-000056:mdna:195]
performance is both sustained and significant enough to provide sufficient evidence to support reversal of all or a portion of the remaining valuation allowance. The value of our net deferred tax asset may be subject to change in the future, depending on our generation or projections of future taxable income, as well as changes in tax policy or our tax planning strategy. For further discussion, see Note 21 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report.

[0000936395-19-000056:mdna:196]
Warranty

[0000936395-19-000056:mdna:197]
Our liability for product warranties, included in other accrued liabilities, was $48.5 million and $44.7 million as of October 31, 2019 and October 31, 2018, respectively. Our products are generally covered by a warranty for periods ranging from one to five years. We accrue for warranty costs as part of our cost of goods sold based on associated material costs, technical support labor costs and associated overhead. Material cost is estimated based primarily on historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily on historical trends and the cost to support the customer cases within the warranty period. The provision for product warranties, net of adjustments for previous years’ provisions, was $23.1 million, $21.0 million and $8.0 million for fiscal 2019, 2018 and 2017 respectively. The provision for warranty claims may fluctuate on a quarterly basis depending on the mix of products and customers in that period. If actual product failure rates, material replacement costs, service or labor costs differ from our estimates, revisions to the estimated warranty provision would be required. See Note 14 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report. An increase in warranty claims or the related costs associated with satisfying our warranty obligations could increase our cost of sales and negatively affect our gross margin.

[0000936395-19-000056:mdna:198]
Effects of Recent Accounting Pronouncements

[0000936395-19-000056:mdna:199]
See Note 1 to our Consolidated Financial Statements included in Item 8 of Part II of this annual report for information relating to our discussion of the effects of recent accounting pronouncements.

[0000936395-19-000056:mdna:200]
Unaudited Quarterly Results of Operations

[0000936395-19-000056:mdna:201]
The tables below (in thousands, except per share data) set forth the operating results in our consolidated statements of operations for each of the eight quarters in the period ended October 31, 2019. Our revenue can fluctuate from quarter to quarter as a result of a number of factors, including changes in customer spending levels or networking strategies, order timing and volume, backlog levels, timing of revenue recognition and other competitive dynamics. As our business has evolved, including the sales of our solutions to meet the “on-demand” service requirements of both our customers and their end-users, the amount of quarterly revenue that we recognize in a quarter from customer orders received in that same quarter (which we refer to as “book to revenue”) has increased as compared to our historical periods. Increased reliance on book to revenue introduces a number of risks, including the inherent difficulty in forecasting the amount and timing of book to revenue in any given quarter, and may increase the likelihood of fluctuations in our results. This information is unaudited, but in our opinion reflects all adjustments (consisting only of normal recurring adjustments) that we consider necessary for a fair statement of such information in accordance with generally accepted accounting principles. The results for any quarter are not necessarily indicative of results for any future period.

[0000936395-19-000056:mdna:202]
|  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |  | Oct. 31, |  | Jul. 31, |  | Apr. 30, |  | Jan. 31, |
|  | 2019 |  | 2019 |  | 2019 |  | 2019 |  | 2018 |  | 2018 |  | 2018 |  | 2018 |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | $ | 820,007 |  |  | $ | 810,588 |  |  | $ | 710,688 |  |  | $ | 642,532 |  |  | $ | 743,867 |  |  | $ | 691,758 |  |  | $ | 604,226 |  |  | $ | 525,609 |  |
| Services | 147,980 |  |  | 150,018 |  |  | 154,323 |  |  | 135,995 |  |  | 155,489 |  |  | 127,059 |  |  | 125,752 |  |  | 120,526 |  |
| Total revenue | 967,987 |  |  | 960,606 |  |  | 865,011 |  |  | 778,527 |  |  | 899,356 |  |  | 818,817 |  |  | 729,978 |  |  | 646,135 |  |
| Cost of goods sold: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products | 469,945 |  |  | 454,921 |  |  | 411,050 |  |  | 380,442 |  |  | 421,583 |  |  | 399,886 |  |  | 372,568 |  |  | 313,120 |  |
| Services | 78,346 |  |  | 81,333 |  |  | 79,284 |  |  | 74,744 |  |  | 79,698 |  |  | 67,388 |  |  | 64,103 |  |  | 61,250 |  |
| Total costs of goods sold | 548,291 |  |  | 536,254 |  |  | 490,334 |  |  | 455,186 |  |  | 501,281 |  |  | 467,274 |  |  | 436,671 |  |  | 374,370 |  |
| Gross profit | 419,696 |  |  | 424,352 |  |  | 374,677 |  |  | 323,341 |  |  | 398,075 |  |  | 351,543 |  |  | 293,307 |  |  | 271,765 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development | 141,657 |  |  | 139,880 |  |  | 137,969 |  |  | 128,633 |  |  | 134,983 |  |  | 121,133 |  |  | 116,924 |  |  | 118,524 |  |
| Selling and marketing | 117,201 |  |  | 104,230 |  |  | 103,502 |  |  | 98,113 |  |  | 112,791 |  |  | 95,395 |  |  | 97,359 |  |  | 88,515 |  |
| General and administrative | 50,307 |  |  | 42,695 |  |  | 42,154 |  |  | 39,243 |  |  | 44,539 |  |  | 38,212 |  |  | 38,976 |  |  | 38,406 |  |
| Amortization of intangible assets | 5,222 |  |  | 5,529 |  |  | 5,529 |  |  | 5,528 |  |  | 4,654 |  |  | 3,837 |  |  | 3,623 |  |  | 3,623 |  |
| Acquisition and integration costs | (735 | ) |  | 1,362 |  |  | 1,135 |  |  | 1,608 |  |  | 3,778 |  |  | 1,333 |  |  | — |  |  | — |  |
| Significant asset impairments and restructuring costs | 12,842 |  |  | 5,355 |  |  | 4,068 |  |  | 2,273 |  |  | 1,460 |  |  | 6,359 |  |  | 4,359 |  |  | 5,961 |  |
| Total operating expenses | 326,494 |  |  | 299,051 |  |  | 294,357 |  |  | 275,398 |  |  | 302,205 |  |  | 266,269 |  |  | 261,241 |  |  | 255,029 |  |
| Income from operations | 93,202 |  |  | 125,301 |  |  | 80,320 |  |  | 47,943 |  |  | 95,870 |  |  | 85,274 |  |  | 32,066 |  |  | 16,736 |  |
| Interest and other income (loss), net | (1,183 | ) |  | 1,050 |  |  | (244 | ) |  | 4,253 |  |  | (13,357 | ) |  | (1,543 | ) |  | 1,296 |  |  | 1,575 |  |
| Interest expense | (9,136 | ) |  | (9,404 | ) |  | (9,471 | ) |  | (9,441 | ) |  | (14,873 | ) |  | (13,611 | ) |  | (13,031 | ) |  | (13,734 | ) |
| Loss on extinguishment and modification of debt | — |  |  | — |  |  | — |  |  | — |  |  | (13,887 | ) |  | — |  |  | — |  |  | — |  |
| Income before income taxes | 82,883 |  |  | 116,947 |  |  | 70,605 |  |  | 42,755 |  |  | 53,753 |  |  | 70,120 |  |  | 20,331 |  |  | 4,577 |  |
| Provision (benefit) for income tax | 2,552 |  |  | 30,198 |  |  | 17,867 |  |  | 9,139 |  |  | (10,224 | ) |  | 19,280 |  |  | 6,475 |  |  | 477,940 |  |
| Net income (loss) | $ | 80,331 |  |  | $ | 86,749 |  |  | $ | 52,738 |  |  | $ | 33,616 |  |  | $ | 63,977 |  |  | $ | 50,840 |  |  | $ | 13,856 |  |  | $ | (473,363 | ) |
| Basic net income (loss) per common share | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.34 |  |  | $ | 0.22 |  |  | $ | 0.45 |  |  | $ | 0.35 |  |  | $ | 0.10 |  |  | $ | (3.29 | ) |
| Diluted net income (loss) per potential common share | $ | 0.51 |  |  | $ | 0.55 |  |  | $ | 0.33 |  |  | $ | 0.21 |  |  | $ | 0.34 |  |  | $ | 0.34 |  |  | $ | 0.09 |  |  | $ | (3.29 | ) |
| Weighted average basic common shares outstanding | 154,852 |  |  | 155,488 |  |  | 156,170 |  |  | 156,314 |  |  | 143,659 |  |  | 143,400 |  |  | 143,975 |  |  | 143,922 |  |
| Weighted average diluted potential common shares outstanding | 156,612 |  |  | 157,455 |  |  | 158,289 |  |  | 158,174 |  |  | 157,745 |  |  | 159,998 |  |  | 147,973 |  |  | 143,922 |  |

[0000936395-19-000056:mdna:203]
58
