# CIEN notes — 0000936395-19-000056


## us-gaap:OrganizationConsolidationBasisOfPresentationBusinessDescriptionAndAccountingPoliciesTextBlock

[0000936395-19-000056:notes:1]
CIENA CORPORATION AND SIGNIFICANT ACCOUNTING POLICIES AND ESTIMATES
Description of Business

[0000936395-19-000056:notes:2]
Ciena Corporation (“Ciena” or the “Company”) is a networking systems, services and software company, providing solutions that enable a wide range of network operators to deploy and manage next-generation networks that deliver services to businesses and consumers. Ciena provides hardware, software and services that support the transport, switching, aggregation, service delivery and management of video, data and voice traffic on communications networks. Ciena’s solutions are used by communications service providers, cable and multiservice operators, Web-scale providers, submarine network operators, governments, enterprises, research and education institutions and other emerging network operators.

[0000936395-19-000056:notes:3]
Ciena’s solutions include a portfolio of Networking Platforms, including Ciena’s Converged Packet Optical and Packet Networking products, that can be applied from the network core to end user access points, and that allow network operators to scale capacity, increase transmission speeds, allocate traffic and adapt dynamically to changing end-user service demands. Ciena offers Platform Software that provides management and domain control of Ciena’s hardware solutions and automates network lifecycle operations, including provisioning equipment and services. Through its Blue Planet Automation Software, Ciena enables network providers to use network data, analytics and policy-based assurance to achieve closed loop automation across multi-vendor and multi-domain network environments, streamlining key business and network processes. To complement its hardware and software products, Ciena offers a broad range of services that help its customers build, operate and improve their networks and associated operational environments.

[0000936395-19-000056:notes:4]
Ciena refers to its complete portfolio vision as the Adaptive Network. The Adaptive Network emphasizes a programmable network infrastructure, software control and automation capabilities, and network analytics and intelligence. By transforming network infrastructures into a dynamic, programmable environment driven by automation and analytics, network operators can realize greater business agility, dynamically adapt to changing end user service demands and rapidly introduce new revenue-generating services. They can also gain valuable real-time network insights, allowing them to optimize network operation and maximize the return on their network infrastructure investment.

[0000936395-19-000056:notes:5]
Basis of Presentation

[0000936395-19-000056:notes:6]
The accompanying consolidated financial statements include the accounts of Ciena and its wholly owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0000936395-19-000056:notes:7]
Ciena has a 52 or 53 week fiscal year, which ends on the Saturday nearest to the last day of October in each year (November 2, 2019, November 3, 2018 and October 28, 2017 for the periods reported). Fiscal 2019 and fiscal 2017 each consisted of a 52-week fiscal year and fiscal 2018 consisted of a 53-week fiscal year. For purposes of financial statement presentation, each fiscal year is described as having ended on October 31.

[0000936395-19-000056:notes:8]
Business Combinations

[0000936395-19-000056:notes:9]
Ciena records acquisitions using the purchase method of accounting. All of the assets acquired, liabilities assumed, contractual contingencies and contingent consideration are recognized at their fair value as of the acquisition date. The excess of the purchase price over the estimated fair values of the net tangible and net intangible assets acquired is recorded as goodwill. The application of the purchase method of accounting for business combinations requires management to make significant estimates and assumptions in the determination of the fair value of assets acquired and liabilities assumed, in order to properly allocate purchase price consideration between assets that are depreciated and amortized from goodwill. These assumptions and estimates include a market participant’s use of the asset and the appropriate discount rates for a market participant. Ciena’s estimates are based on historical experience, information obtained from the management of the acquired companies and, when appropriate, include assistance from independent third-party appraisal firms. Significant assumptions and estimates can include, but are not limited to, the cash flows that an asset is expected to generate in the future, the appropriate weighted-average cost of capital and the cost savings expected to be derived from acquiring an asset. These estimates are inherently uncertain and unpredictable. In addition, unanticipated events and circumstances may occur which may affect the accuracy or validity of such estimates.

[0000936395-19-000056:notes:10]
Use of Estimates

[0000936395-19-000056:notes:11]
The preparation of the financial statements and related disclosures in conformity with Generally Accepted Accounting Principles (“GAAP”) requires management to make estimates and judgments that affect the amounts reported in the consolidated financial statements and accompanying notes. Estimates are used for selling prices for multiple element arrangements, shared-based compensation, bad debts, valuation of inventories and investments, recoverability of intangible assets, other long-lived assets and goodwill, income taxes, warranty obligations, restructuring liabilities, derivatives, contingencies and litigation. Ciena bases its estimates on historical experience and assumptions that it believes are reasonable. Actual results may differ materially from management’s estimates.

[0000936395-19-000056:notes:12]
Cash and Cash Equivalents

[0000936395-19-000056:notes:13]
Ciena considers all highly liquid investments purchased with original maturities of three months or less to be cash equivalents. Any restricted cash collateralizing letters of credit is included in other current assets and other long-term assets depending on the duration of the restriction.

[0000936395-19-000056:notes:14]
Investments

[0000936395-19-000056:notes:15]
Ciena’s investments in debt securities are classified as available-for-sale and reported at fair value, with unrealized gains and losses recorded in accumulated other comprehensive income (loss). Ciena recognizes losses in the income statement when it determines that declines in the fair value of its investments below their cost basis are other-than-temporary. In determining whether a decline in fair value is other-than-temporary, Ciena considers various factors, including market price (when available), investment ratings, the financial condition and near-term prospects of the investee, the length of time and the extent to which the fair value has been less than Ciena’s cost basis, and Ciena’s intent and ability to hold the investment until maturity or for a period of time sufficient to allow for any anticipated recovery in market value. Ciena considers all marketable debt securities that it expects to convert to cash within one year or less to be short-term investments, with all others considered to be long-term investments.

[0000936395-19-000056:notes:16]
Ciena has minority equity investments in privately held technology companies that are classified in other long-term assets. These investments are carried at cost because Ciena owns less than 20% of the voting equity and does not have the ability to exercise significant influence over the company. Ciena monitors these investments for impairment and makes appropriate reductions to the carrying value when necessary. As of October 31, 2019, the combined carrying value of these investments was $10.7 million. Ciena elects to estimate the fair value at cost minus impairment, if any, plus or minus observable price changes in orderly transactions for identical or similar investments of the same issuer. Ciena has not evaluated these investments for impairment or observable price changes as there have not been any events or changes in circumstances that Ciena believes would have had a significant effect on the fair value of these investments.

[0000936395-19-000056:notes:17]
Inventories

[0000936395-19-000056:notes:18]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.

[0000936395-19-000056:notes:19]
Segment Reporting

[0000936395-19-000056:notes:20]
Ciena’s chief operating decision maker, its chief executive officer, evaluates the Company’s performance and allocates resources based on multiple factors, including measures of segment profit (loss). Operating segments are defined as components of an enterprise that engage in business activities that may earn revenue and incur expense, for which discrete financial information is available, and for which such information is evaluated regularly by the chief operating decision maker for purposes of allocating resources and assessing performance. During fiscal 2019, we separated our previous Software and Software-Related Services segment into two stand-alone operating segments. Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. See Note 23 below.

[0000936395-19-000056:notes:21]
Goodwill

[0000936395-19-000056:notes:22]
Goodwill is the excess of the purchase price over the fair values assigned to the net assets acquired in a business combination. Ciena tests goodwill for impairment on an annual basis, which it has determined to be the last business day of

[0000936395-19-000056:notes:23]
fiscal September each year. Ciena also tests goodwill for impairment between annual tests if an event occurs or circumstances change that would, more likely than not, reduce the fair value of the reporting unit below its carrying value.

[0000936395-19-000056:notes:24]
Ciena tests goodwill impairment by comparing the fair value of the reporting unit with the unit’s carrying amount, including goodwill. If this test indicates that the fair value is less than the carrying value, then an impairment loss is recognized limited to the total amount of goodwill allocated to that reporting unit. A non-cash goodwill impairment charge would have the effect of decreasing earnings or increasing losses in such period. If Ciena is required to take a substantial impairment charge, its operating results would be materially adversely affected in such period.

[0000936395-19-000056:notes:25]
Long-lived Assets

[0000936395-19-000056:notes:26]
Long-lived assets include: equipment, building, furniture and fixtures; finite-lived intangible assets; and maintenance spares. Ciena tests long-lived assets for impairment whenever triggering events or changes in circumstances indicate that the asset’s carrying amount is not recoverable from its undiscounted cash flows. An impairment loss is measured as the amount by which the carrying amount of the asset or asset group exceeds its fair value. Ciena’s long-lived assets are assigned to asset groups that represent the lowest level for which cash flows can be identified.

[0000936395-19-000056:notes:27]
Equipment, Building, Furniture and Fixtures and Internal Use Software

[0000936395-19-000056:notes:28]
Equipment, building, furniture and fixtures are recorded at cost. Depreciation and amortization are computed using the straight-line method over useful lives of two years to five years for equipment and furniture and fixtures and the shorter of useful life or lease term for leasehold improvements.

[0000936395-19-000056:notes:29]
Qualifying internal use software and website development costs incurred during the application development stage, which consist primarily of outside services and purchased software license costs, are capitalized and amortized straight-line over the estimated useful lives of two years to five years.

[0000936395-19-000056:notes:30]
Intangible Assets

[0000936395-19-000056:notes:31]
Ciena has recorded finite-lived intangible assets as a result of several acquisitions. Finite-lived intangible assets are carried at cost less accumulated amortization. Amortization is computed using the straight-line method over the expected economic lives of the respective assets, up to seven years, which approximates the use of intangible assets.

[0000936395-19-000056:notes:32]
Maintenance Spares

[0000936395-19-000056:notes:33]
Maintenance spares are recorded at cost. Spares usage cost is expensed ratably over four years.

[0000936395-19-000056:notes:34]
Concentrations

[0000936395-19-000056:notes:35]
Substantially all of Ciena’s cash and cash equivalents are maintained at a small number of major U.S. financial institutions. The majority of Ciena’s cash equivalents consist of money market funds. Deposits held with banks may exceed the amount of insurance provided on such deposits. Because these deposits generally may be redeemed upon demand, management believes that they bear minimal risk.

[0000936395-19-000056:notes:36]
Historically, a significant percentage of Ciena’s revenue has been concentrated among sales to a small number of large communications service providers and Web-scale providers. Consolidation among Ciena’s customers has increased this concentration. Consequently, Ciena’s accounts receivable are concentrated among these customers. See Note 23 below.

[0000936395-19-000056:notes:37]
Additionally, Ciena’s access to certain materials or components is dependent on sole or limited source suppliers. The inability of any of these suppliers to fulfill Ciena’s supply requirements, or significant changes in supply cost, could affect future results. Ciena relies on a small number of contract manufacturers to perform the majority of the manufacturing for its products. If Ciena cannot effectively manage these manufacturers or forecast future demand, or if these manufacturers fail to deliver products or components on time, Ciena’s business and results of operations may suffer.

[0000936395-19-000056:notes:38]
Revenue Recognition

[0000936395-19-000056:notes:39]
Ciena recognizes revenue when control of the promised products or services is transferred to its customer, in an amount that reflects the consideration to which Ciena expects to be entitled in exchange for those products or services.

[0000936395-19-000056:notes:40]
Ciena determines revenue recognition by applying the following five-step approach:

[0000936395-19-000056:notes:41]
•identification of the contract, or contracts, with a customer;

[0000936395-19-000056:notes:42]
•identification of the performance obligations in the contract;

[0000936395-19-000056:notes:43]
•determination of the transaction price;

[0000936395-19-000056:notes:44]
•allocation of the transaction price to the performance obligations in the contract; and

[0000936395-19-000056:notes:45]
•recognition of revenue when, or as, Ciena satisfies a performance obligation.

[0000936395-19-000056:notes:46]
Generally, Ciena makes sales pursuant to purchase orders placed by customers under framework agreements that govern the general commercial terms and conditions of the sale of Ciena’s products and services. These purchase orders under framework agreements are used to determine the identification of the contract or contracts with this customer. Purchase orders typically include the description, quantity, and price of each product or service purchased. Purchase orders may include one-line bundled pricing for both products and services. Accordingly, purchase orders can include various combinations of products and services that are generally distinct and accounted for as separate performance obligations. Ciena evaluates each promised product and service offering to determine whether it represents a distinct performance obligation. In doing so, Ciena considers, among other things, customary business practices, whether the customer can benefit from the product or service on its own or together with other resources that are readily available, and whether Ciena’s commitment to transfer the product or service to the customer is separately identifiable from other obligations in the purchase order. For transactions where Ciena delivers the product or services, Ciena is typically the principal and records revenue and costs of goods sold on a gross basis.

[0000936395-19-000056:notes:47]
Purchase orders are invoiced based on the terms set forth either in the purchase order or the framework agreement, as applicable. Generally, sales of products and software licenses are invoiced upon shipment or delivery. Maintenance and software subscription services are invoiced quarterly or annually in advance of the service term. Ciena’s other service offerings are generally invoiced upon completion of the service. Payment terms and cash received typically range from 30 to 90 days from the invoicing date. Historically, Ciena has not provided any material financing arrangements to its customers. As a practical expedient, Ciena does not adjust the amount of consideration it will receive for the effects of a significant financing component as it expects, at contract inception, that the period between Ciena transfer of the products or services to the customer, and customer payment for the products or services will be one year or less. Shipping and handling fees invoiced to customers are included in revenue, with the associated expense included in product cost of goods sold. Ciena records revenue net of any associated sales taxes.

[0000936395-19-000056:notes:48]
Ciena recognizes revenue upon the transfer of control of promised products or services to a customer. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment or delivery to the customer. Transfer of control can also occur over time for services such as software subscription, maintenance, installation, and various professional services as the customer receives the benefit over the contract term.

[0000936395-19-000056:notes:49]
Significant Judgments

[0000936395-19-000056:notes:50]
Revenue is allocated among performance obligations based on standalone selling price (“SSP”). SSP reflects the price at which Ciena would expect to sell that product or service on a stand-alone basis at contract inception and that Ciena would expect to be entitled to receive for the promised products or services. SSP is estimated for each distinct performance obligation, and judgment may be required in its determination. The best evidence of SSP is the observable price of a product or service when Ciena sells the products separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, Ciena determines SSP using information that may include market conditions and other observable inputs.

[0000936395-19-000056:notes:51]
Ciena applies judgment in determining the transaction price, as Ciena may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration can include various rebate, cooperative marketing, and other incentive programs that Ciena offers to its distributors, partners and customers. When determining the amount of revenue to recognize, Ciena estimates the expected usage of these programs, applying the expected value or most likely estimate and updates the estimate at each reporting period as actual utilization data becomes available. Ciena also considers any customer right of return and any actual or potential payment of liquidated damages, contractual or similar penalties, or other claims for performance failures or delays in determining the transaction price, where applicable.

[0000936395-19-000056:notes:52]
When transfer of control is judged to be over time for installation and professional service arrangements, Ciena applies the input method to determine the amount of revenue to be recognized in a given period. Utilizing the input method, Ciena recognizes revenue based on the ratio of actual costs incurred to date to the total estimated costs expected to be incurred. Revenue for software subscription and maintenance is recognized ratably over the period during which the services are performed.

[0000936395-19-000056:notes:53]
Capitalized Contract Acquisition Costs

[0000936395-19-000056:notes:54]
Ciena has considered the impact of the guidance in Accounting Standards Codification (“ASC”) 340-40, Other Assets and Deferred Costs; Contracts with Customers, and the interpretations of the Financial Accounting Standards Board (“FASB”) Transition Resource Group for Revenue Recognition with respect to capitalization and amortization of incremental costs of obtaining a contract. In conjunction with this interpretation, Ciena considers each customer purchase in combination with the corresponding framework agreement, if applicable, as a contract. Ciena has elected to implement the practical expedient, which allows for incremental costs to be recognized as an expense when incurred if the period of the asset recognition is one year or less. If the period of the asset recognition is greater than one year, Ciena amortizes these costs over the period of performance. Ciena considers sales commissions incurred upon receipt of purchase orders placed by customers as incremental costs to obtain such purchase orders. The practical expedient method is applied to the purchase order as a whole and thus the capitalized costs of obtaining a purchase order is applied even if the purchase order contains more than one performance obligation. In cases where a purchase order includes various distinct products or services with both short-term (one year or less) and long-term (more than a year) performance periods, the cost of commissions incurred for the total value of the purchase order is capitalized and subsequently amortized as each performance obligation is recognized.

[0000936395-19-000056:notes:55]
For the additional disclosures required as part of ASC 606 see Note 2 below.

[0000936395-19-000056:notes:56]
Warranty Accruals

[0000936395-19-000056:notes:57]
Ciena provides for the estimated costs to fulfill customer warranty obligations upon recognition of the related revenue. Estimated warranty costs include estimates for material costs, technical support labor costs and associated overhead. Warranty is included in cost of goods sold and is determined based on actual warranty cost experience, estimates of component failure rates and management’s industry experience. Ciena’s sales contracts do not permit the right of return of the product by the customer after the product has been accepted.

[0000936395-19-000056:notes:58]
Accounts Receivable, Net

[0000936395-19-000056:notes:59]
Ciena’s allowance for doubtful accounts is based on its assessment, on a specific identification basis, of the collectibility of customer accounts. Ciena performs ongoing credit evaluations of its customers and generally has not required collateral or other forms of security from them. In determining the appropriate balance for Ciena’s allowance for doubtful accounts, management considers each individual customer account receivable in order to determine collectibility. In doing so, management considers creditworthiness, payment history, account activity and communication with the customer. If a customer’s financial condition changes, Ciena may be required to record an allowance for doubtful accounts for that customer, which could negatively affect its results of operations.

[0000936395-19-000056:notes:60]
Research and Development

[0000936395-19-000056:notes:61]
Ciena charges all research and development costs to expense as incurred. Types of expense incurred in research and development include employee compensation, prototype equipment, consulting and third-party services, depreciation, facility costs and information technology.

[0000936395-19-000056:notes:62]
Government Grants

[0000936395-19-000056:notes:63]
Ciena accounts for proceeds from government grants as a reduction of expense when there is reasonable assurance that Ciena has met the required conditions associated with the grant and that grant proceeds will be received. Grant benefits are recorded to the particular line item of the Consolidated Statement of Operations to which the grant activity relates. See Note 25 below.

[0000936395-19-000056:notes:64]
Advertising Costs

[0000936395-19-000056:notes:65]
Ciena expenses all advertising costs as incurred.

[0000936395-19-000056:notes:66]
Legal Costs

[0000936395-19-000056:notes:67]
Ciena expenses legal costs associated with litigation as incurred.

[0000936395-19-000056:notes:68]
Share-Based Compensation Expense

[0000936395-19-000056:notes:69]
Ciena measures and recognizes compensation expense for share-based awards based on estimated fair values on the date of grant. Ciena estimates the fair value of each option-based award on the date of grant using the Black-Scholes option-pricing model. This model is affected by Ciena’s stock price as well as estimates regarding a number of variables, including expected stock price volatility over the expected term of the award and projected employee stock option exercise behaviors. Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. In each case, Ciena only recognizes expense in its Consolidated Statement of Operations for those stock options or restricted stock units that are expected ultimately to vest. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total shareholder return as compared to an index of peer companies, in whole or in part. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total shareholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of performance based awards subject to total shareholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model on the date of grant. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. See Note 22 below.

[0000936395-19-000056:notes:70]
Stock Repurchase Plan

[0000936395-19-000056:notes:71]
Shares repurchased pursuant to Ciena’s share repurchase program are immediately retired upon purchase. Repurchased common stock is reflected as a reduction of stockholders’ equity. Ciena’s accounting policy related to its share repurchases is to reduce its common stock based on the par value of the shares and to reduce its capital surplus for the excess of the repurchase price over the par value. Since the inception of its share repurchase program in December 2018, Ciena has had an accumulated deficit balance; therefore, the excess over the par value has been applied to additional paid-in capital. Once Ciena has retained earnings, the excess will be charged entirely to retained earnings.

[0000936395-19-000056:notes:72]
Income Taxes

[0000936395-19-000056:notes:73]
Ciena accounts for income taxes using an asset and liability approach. This approach recognizes deferred tax assets and liabilities (“DTA”) for the expected future tax consequences attributable to differences between the carrying amounts of assets and liabilities for financial reporting purposes and their respective tax bases, and for operating loss and tax credit carryforwards. In estimating future tax consequences, Ciena considers all expected future events other than the enactment of changes in tax laws or rates. Valuation allowances are provided if, based on the weight of the available evidence, it is more likely than not that some or all of the deferred tax assets will not be realized.

[0000936395-19-000056:notes:74]
In the ordinary course of business, transactions occur for which the ultimate outcome may be uncertain. In addition, tax authorities periodically audit Ciena’s income tax returns. These audits examine significant tax filing positions, including the timing and amounts of deductions and the allocation of income tax expenses among tax jurisdictions. Ciena is currently under audit in India for 2012 and 2014 through 2018, and in Canada for 2011 through 2015. Management does not expect the outcome of these audits to have a material adverse effect on Ciena’s consolidated financial position, results of operations or cash flows. Ciena’s major tax jurisdictions and the earliest open tax years are as follows: United States (2016), United Kingdom (2016), Canada (2011), and India (2012). Limited adjustments can be made to Federal U.S. tax returns in earlier years in order to reduce net operating loss carryforwards. Ciena classifies interest and penalties related to uncertain tax positions as a component of income tax expense.

[0000936395-19-000056:notes:75]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2019, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized totaled approximately $372.0 million. If these earnings were distributed to the U.S. in the form of dividends, or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, Ciena would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes.

[0000936395-19-000056:notes:76]
Ciena is required to record excess tax benefits or tax deficiencies related to stock-based compensation as income tax benefit or expense when share-based awards vest or are settled.

[0000936395-19-000056:notes:77]
Ciena adopted ASU 2016-09, Improvements to Employee Share-Based Payment Accounting, in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets

[0000936395-19-000056:notes:78]
related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018.

[0000936395-19-000056:notes:79]
The Tax Cuts and Jobs Act (the “Tax Act”) includes provisions that affect Ciena in fiscal 2019, including a provision designed to tax global intangible low-taxed income (“GILTI”). An accounting policy choice is allowed to either treat taxes due on future U.S. inclusions related to GILTI in taxable income as a current-period expense when incurred (the “period cost method”) or factor such amounts into the measurement of deferred taxes (the “deferred method”). The calculation of the deferred balance with respect to the new GILTI tax provisions will depend, in part, on analyzing global income to determine whether future U.S. inclusions in taxable income are expected related to GILTI and, if so, what the impact is expected to be. Ciena is electing to use the period cost method for future GILTI inclusions. Additionally, Ciena is electing to use the incremental cash tax savings approach when determining whether a valuation allowance needs to be recorded against the U.S. net operating loss (“NOL”) due to the GILTI inclusions.

[0000936395-19-000056:notes:80]
The Tax Act also introduced an alternative tax known as the base erosion and anti-abuse tax (“BEAT”). An accounting policy choice has been made to consider BEAT as a period cost when incurred.

[0000936395-19-000056:notes:81]
Loss Contingencies

[0000936395-19-000056:notes:82]
Ciena is subject to the possibility of various losses arising in the ordinary course of business. These may relate to disputes, litigation and other legal actions. Ciena considers the likelihood of loss or the incurrence of a liability, as well as Ciena’s ability to estimate the amount of loss reasonably, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. Ciena regularly evaluates current information available to it in order to determine whether any accruals should be adjusted and whether new accruals are required.

[0000936395-19-000056:notes:83]
Fair Value of Financial Instruments

[0000936395-19-000056:notes:84]
The carrying value of Ciena’s cash and cash equivalents, accounts receivable, accounts payable and accrued liabilities approximates fair market value due to the relatively short period of time to maturity. For information related to the fair value of Ciena’s term loan, see Note 17 below.

[0000936395-19-000056:notes:85]
Fair value for the measurement of financial assets and liabilities is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. As such, fair value is a market-based measurement that should be determined based on assumptions that market participants would use in pricing an asset or liability. Ciena utilizes a valuation hierarchy for disclosure of the inputs for fair value measurement. This hierarchy prioritizes the inputs into three broad levels as follows:

[0000936395-19-000056:notes:86]
| • | Level 1 inputs are unadjusted quoted prices in active markets for identical assets or liabilities; |

[0000936395-19-000056:notes:87]
| • | Level 2 inputs are quoted prices for identical or similar assets or liabilities in less active markets or model-derived valuations in which significant inputs are observable for the asset or liability, either directly or indirectly through market corroboration, for substantially the full term of the financial instrument; and |

[0000936395-19-000056:notes:88]
| • | Level 3 inputs are unobservable inputs based on Ciena’s assumptions used to measure assets and liabilities at fair value. The fair values are determined based on model-based techniques using inputs Ciena could not corroborated with market data. |

[0000936395-19-000056:notes:89]
By distinguishing between inputs that are observable in the marketplace, and therefore more objective, and those that are unobservable, and therefore more subjective, the hierarchy is designed to indicate the relative reliability of the fair value measurements. A financial asset’s or liability’s classification within the hierarchy is determined based on the lowest level input that is significant to the fair value measurement.

[0000936395-19-000056:notes:90]
Restructuring

[0000936395-19-000056:notes:91]
From time to time, Ciena takes actions to better align its workforce, facilities and operating costs with perceived market opportunities, business strategies and changes in market and business conditions. Ciena recognizes a liability for the cost associated with an exit or disposal activity in the period in which the liability is incurred, except for one-time employee termination benefits related to a service period, typically of more than 60 days, which are accrued over the service period. See Note 4 below.

[0000936395-19-000056:notes:92]
Foreign Currency

[0000936395-19-000056:notes:93]
Certain of Ciena’s foreign branch offices and subsidiaries use the U.S. Dollar as their functional currency because Ciena Corporation, as the U.S. parent entity, exclusively funds the operations of these branch offices and subsidiaries. For those subsidiaries using the local currency as their functional currency, assets and liabilities are translated at exchange rates in effect at the balance sheet date, and the statement of operations is translated at a monthly average rate. Resulting translation adjustments are recorded directly to a separate component of stockholders’ equity. Where the monetary assets and liabilities are transacted in a currency other than the entity’s functional currency, re-measurement adjustments are recorded in interest and other income (loss), net on the Consolidated Statement of Operations. See Note 5 below.

[0000936395-19-000056:notes:94]
Derivatives

[0000936395-19-000056:notes:95]
Ciena’s 3.75% Convertible Senior Notes due October 15, 2018 (the “New Notes”) included a conversion feature that was accounted for as a separate embedded derivative. The embedded conversion feature was recorded at fair value using the underlying stock price, time to maturity and expected volatility of Ciena’s stock and conversion price. These changes are included in interest and other income (loss), net on the Consolidated Statement of Operations. On November 15, 2018, Ciena settled this embedded conversion feature.

[0000936395-19-000056:notes:96]
From time to time, Ciena uses foreign currency forward contracts to reduce variability in certain forecasted non-U.S. Dollar denominated cash flows. Generally, these derivatives have maturities of 24 months or less. Ciena also has interest rate swap arrangements to reduce variability in certain forecasted interest expense associated with its term loan. All of these derivatives are designated as cash flow hedges. At the inception of the cash flow hedge, and on an ongoing basis, Ciena assesses whether the derivative has been effective in offsetting changes in cash flows attributable to the hedged risk during the hedging period. The derivative’s net gain or loss is initially reported as a component of accumulated other comprehensive income (loss), and, upon occurrence of the forecasted transaction, is subsequently reclassified to the line item in the Consolidated Statement of Operations to which the hedged transaction relates.

[0000936395-19-000056:notes:97]
Ciena records derivative instruments in the Consolidated Statements of Cash Flows within operating, investing, or financing activities consistent with the cash flows of the hedged items.

[0000936395-19-000056:notes:98]
From time to time, Ciena uses foreign currency forward contracts to hedge certain balance sheet foreign exchange exposures. These forward contracts are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is reported in interest and other income (loss), net on the Consolidated Statement of Operations.

[0000936395-19-000056:notes:99]
See Notes 7 and 15 below.

[0000936395-19-000056:notes:100]
Computation of Net Income (Loss) per Share

[0000936395-19-000056:notes:101]
Ciena calculates basic earnings per share by dividing earnings attributable to common stock by the weighted average number of common shares outstanding for the period. Diluted net income (loss) per potential common share (“Diluted EPS”) includes other potential dilutive shares that would be outstanding if securities or other contracts to issue common stock were exercised or converted into common stock. Ciena uses a dual presentation of basic net income (loss) per common share (“Basic EPS”) and Diluted EPS on the face of its income statement. A reconciliation of the numerator and denominator used for the Basic EPS and Diluted EPS computations is set forth in Note 19 below.

[0000936395-19-000056:notes:102]
Software Development Costs

[0000936395-19-000056:notes:103]
Ciena develops software for sale to its customers. GAAP requires the capitalization of certain software development costs that are incurred subsequent to the date technological feasibility is established and prior to the date the product is generally available for sale. The capitalized cost is then amortized using the straight-line method over the estimated life of the product. Ciena defines technological feasibility as being attained at the time a working model is completed. To date, the period between Ciena achieving technological feasibility and the general availability of such software has been short, and software development costs qualifying for capitalization have been insignificant. Accordingly, Ciena has not capitalized any software development costs.

[0000936395-19-000056:notes:104]
Newly Issued Accounting Standards - Effective

[0000936395-19-000056:notes:105]
In May 2014, FASB issued Accounting Standards Codification ASC 606, Revenue from Contracts with Customers, a new accounting standard related to revenue recognition. ASC 606 supersedes nearly all U.S. GAAP standards on revenue recognition and eliminates industry-specific guidance. The underlying principle of ASC 606 is to recognize revenue when a customer obtains control of the promised products or services at an amount that reflects the consideration that is expected to be received in exchange for those products or services. ASC 606 also requires additional disclosures regarding the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000936395-19-000056:notes:106]
ASC 606 allows two methods of adoption: (i) retrospectively to each prior period presented (“full retrospective method”), or (ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption (“modified retrospective method”). Effective upon the start of its first quarter of fiscal 2019, Ciena adopted ASC 606 using the modified retrospective method and accordingly recognized the cumulative effect in accumulated deficit for those contracts that were not completed as of October 31, 2018. Accordingly, results for the reporting periods after October 31, 2018 are presented under ASC 606, while prior periods have not been adjusted and continue to be reported in accordance with Ciena’s historical revenue recognition practices. Refer to Opening Balance Adjustments below for the impact of ASC 606 adoption on Ciena’s Consolidated Financial Statements. In connection with its adoption of ASC 606, Ciena has implemented new accounting policies and processes, and incorporated such into its existing internal control environment as necessary to support the requirements of ASC 606.

[0000936395-19-000056:notes:107]
Revenue Recognition Timing Differences

[0000936395-19-000056:notes:108]
The adoption of ASC 606 requires Ciena to recognize revenue when the customer obtains control of promised products or services in an amount that reflects the consideration that Ciena would expect to receive in exchange for those products or services. Under the prior revenue standard, the timing of revenue recognition for delivered products or services was limited to such amount not contingent on future delivery of products or service or future performance obligations, or subject to customer-specified return or privileges. In the case of multiple element software arrangements for which vendor-specific objective evidence of undelivered maintenance did not exist, under the prior revenue standard, Ciena recognized revenue for the entire arrangement over the maintenance term. The adoption of ASC 606 requires Ciena to determine the stand-alone selling price for each of the software and software-related deliverables of such multiple element arrangements at contract inception. Consequently, under ASC 606, certain software deliverables will be recognized at a point in time rather than over a period of time. In addition, under ASC 606, certain installation and deployment, and consulting and network design services, will be recognized over a period of time rather than at a point in time.

[0000936395-19-000056:notes:109]
Impact of ASC 606 Adoption

[0000936395-19-000056:notes:110]
The following table summarizes the impact of adopting ASC 606 on Ciena’s Consolidated Statement of Operations (in millions):

[0000936395-19-000056:notes:111]
|  |  | Year Ended October 31, 2019 |
|  |  | As Reported |  | Adjustments |  | Balances without adoption of ASC 606 |
| Total revenue |  | $ | 3,572,131 |  |  | $ | (28,838 | ) |  | $ | 3,543,293 |  |
| Total cost of goods sold |  | $ | 2,030,065 |  |  | $ | (21,330 | ) |  | $ | 2,008,735 |  |
| Net income |  | $ | 253,434 |  |  | $ | (7,776 | ) |  | $ | 245,658 |  |
| Diluted net income per potential common share |  | $ | 1.61 |  |  | $ | (0.05 | ) |  | $ | 1.56 |  |

[0000936395-19-000056:notes:112]
During fiscal 2019, the increase in revenue from adoption of ASC 606 was primarily the result of installation and deployment services revenue that was recognized over a period of time rather than at a point in time under the prior revenue recognition standard. The adoption of ASC 606 did not have a material impact to Ciena’s Consolidated Balance Sheets or any impact on net cash provided by operating activities as of October 31, 2019. See “Revenue Recognition Timing Differences” above. For additional information regarding ASC 606, see Note 2 below.

[0000936395-19-000056:notes:113]
Opening Balance Adjustments

[0000936395-19-000056:notes:114]
The following table summarizes the cumulative effect of the changes made to Ciena’s Consolidated Balance Sheets in connection with the adoption of ASC 606 (in millions):

[0000936395-19-000056:notes:115]
|  |  | Balance at October 31, 2018 |  | New Revenue Recognition Standard |  |  | Adjusted Balance at November 1, 2018 |
| ASSETS: |  |  |  |  |  |  |  |
| Accounts receivable, net |  | $ | 786,502 |  |  | $ | 12,509 |  | (1) |  | $ | 799,011 |  |
| Inventories |  | $ | 262,751 |  |  | (2,486 | ) | (2) |  | $ | 260,265 |  |
| Prepaid expenses and other |  | $ | 198,945 |  |  | 21,470 |  | (3) |  | $ | 220,415 |  |
| Deferred tax asset, net |  | $ | 745,039 |  |  | (14,439 | ) | (4) |  | $ | 730,600 |  |
| Other long-term assets |  | $ | 71,652 |  |  | 3,998 |  | (5) |  | $ | 75,650 |  |
| Total assets |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY: |  |  |  |  |  |  |  |
| Deferred revenue |  | $ | 111,134 |  |  | $ | (14,403 | ) | (6) |  | $ | 96,731 |  |
| Long-term deferred revenue |  | $ | 58,323 |  |  | (14,350 | ) | (7) |  | $ | 43,973 |  |
| Accumulated deficit |  | $ | (4,947,652 | ) |  | 49,805 |  | (8) |  | $ | (4,897,847 | ) |
| Total liabilities and stockholders’ equity |  | $ | 3,756,523 |  |  | $ | 21,052 |  |  |  | $ | 3,777,575 |  |

[0000936395-19-000056:notes:116]
| (1) | Unpaid accounts receivable and related deferred revenue related to rights and obligations in a contract are interdependent and therefore recorded net within Ciena’s balance sheet. This represents an increase of $12.5 million from the reversal of certain net unpaid accounts receivable and related deferred revenue. |

[0000936395-19-000056:notes:117]
| (2) | Represents a decrease of $2.5 million in deferred costs of goods sold due to change in revenue recognition for certain product sales. |

[0000936395-19-000056:notes:118]
| (3) | Represents increases of $27.5 million in unbilled accounts receivable for change in recognizing revenue for installation services, $3.9 million in unbilled accounts receivable from change in recognizing revenue for certain product sales and $9.6 million related to short-term capitalized acquisition costs (e.g., commissions) and a decrease of $19.5 million related to prepaid cost of installation services. |

[0000936395-19-000056:notes:119]
| (4) | Represents a decrease of $14.4 million in deferred tax asset, net, related to the unrecognized income tax effects of the net adjustments from the new revenue recognition standard. |

[0000936395-19-000056:notes:120]
| (5) | Represents an increase of $4.0 million related to long-term capitalized acquisition costs (e.g., commissions). |

[0000936395-19-000056:notes:121]
| (6) | Represents decreases of $23.6 million in deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and $1.7 million in deferred revenue, primarily due to a change in revenue recognition for certain product sales, and increases of $2.7 million for a change in revenue recognition from certain maintenance services and $8.2 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and deferred revenue. |

[0000936395-19-000056:notes:122]
| (7) | Represents a decrease of $18.6 million in long-term deferred revenue, primarily due to a change in revenue recognition for certain multiple-element software arrangements and an increase of $4.3 million from the reversal of balance sheet netting for certain unpaid invoices included in accounts receivable, net and long-term deferred revenue. |

[0000936395-19-000056:notes:123]
| (8) | Accumulated deficit impact from the adjustments noted above. |

[0000936395-19-000056:notes:124]
Intangibles

[0000936395-19-000056:notes:125]
In August 2018, the FASB issued ASU No. 2018-15 (“ASU 2018-15”), Intangibles - Goodwill and Other-Internal-Use Software, which aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementation costs incurred to develop or obtain internal-use software. Ciena adopted ASU 2018-15 during the first quarter of fiscal 2019. The application of this accounting standard did not have a material impact on Ciena’s Consolidated Financial Statements.

[0000936395-19-000056:notes:126]
Restricted Cash in Statement of Cash Flows

[0000936395-19-000056:notes:127]
In November 2016, the FASB issued ASU 2016-18 (“ASU 2016-18”), Statement of Cash Flows (Topic 230): Restricted Cash, which broadens the classification and presentation of changes in restricted cash in the statement of cash flows. Ciena adopted ASU 2016-18 during the first quarter of fiscal 2019. The application of this accounting standard update did not have a material impact on Ciena’s Consolidated Statements of Cash Flows. Prior period information has been retrospectively adjusted due to the adoption of ASU 2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0000936395-19-000056:notes:128]
Newly Issued Accounting Standards - Not Yet Effective

[0000936395-19-000056:notes:129]
In February 2016, the FASB issued ASU No. 2016-02 (“ASU 2016-02”), Leases, which requires an entity to recognize assets and liabilities on the balance sheet for the rights and obligations created by leased assets and to provide additional disclosures. Under current GAAP, the majority of Ciena’s leases for its properties are considered operating leases, and Ciena expects that the adoption of this ASU will require these leases to be recognized as assets and liabilities on Ciena’s balance sheet. ASU 2016-02 is effective for Ciena beginning in the first quarter of fiscal 2020. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-19-000056:notes:130]
Ciena will adopt this guidance on a modified retrospective basis on its effective date, November 1, 2019. This adoption will include the election of the related practical expedients. Ciena is continuing to evaluate other possible impacts of the adoption of ASU 2016-02 on its Consolidated Financial Statements and disclosures.

[0000936395-19-000056:notes:131]
In June 2016, the FASB issued ASU No. 2016-13 (“ASU 2016-13”), Financial Instruments - Credit Losses, which requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. ASU 2016-13 is effective for Ciena beginning in the first quarter of fiscal 2021 and early adoption is permitted. Ciena is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements and disclosures.

[0000936395-19-000056:notes:132]
In August 2018, the FASB issued ASU No. 2018-13 (“ASU 2018-13”), Fair Value Measurement (Topic 820): Disclosure Framework which modifies the disclosure requirements on fair value measurements. ASU 2018-13 is effective for Ciena beginning in the first quarter of fiscal year 2020, early adoption is permitted. Adoption of ASU 2018-13 will not have a material effect on Ciena’s financial position or results of operations.


## us-gaap:InventoryPolicyTextBlock

[0000936395-19-000056:notes:133]
Inventories are stated at the lower of cost or market, with cost computed using standard cost, which approximates actual cost, on a first-in, first-out basis. Ciena records a provision for excess and obsolete inventory when an impairment has been identified.
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions.


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000936395-19-000056:notes:134]
(8)

[0000936395-19-000056:notes:135]
Accumulated deficit impact from the adjustments noted above.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000936395-19-000056:notes:136]
REVENUE
Disaggregation of Revenue

[0000936395-19-000056:notes:137]
Ciena’s disaggregated revenue represents similar groups that depict the nature, amount, and timing of revenue and cash flows for Ciena’s various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies may differ for each of its product categories, resulting in different economic risk profiles for each category.

[0000936395-19-000056:notes:138]
The tables below (in thousands) set forth Ciena’s disaggregated revenue for the respective period:

[0000936395-19-000056:notes:139]
|  | Year Ended October 31, 2019 |
|  | Networking Platforms |  | Platform Software and Services |  | Blue Planet Automation Software and Services |  | Global Services |  | Total |
| Product lines: |  |  |  |  |  |  |  |  |  |
| Converged Packet Optical | $ | 2,562,841 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 2,562,841 |  |
| Packet Networking | 348,477 |  |  | — |  |  | — |  |  | — |  |  | 348,477 |  |
| Platform Software and Services | — |  |  | 155,376 |  |  | — |  |  | — |  |  | 155,376 |  |
| Blue Planet Automation Software and Services | — |  |  | — |  |  | 54,555 |  |  | — |  |  | 54,555 |  |
| Maintenance Support and Training | — |  |  | — |  |  | — |  |  | 261,337 |  |  | 261,337 |  |
| Installation and Deployment | — |  |  | — |  |  | — |  |  | 148,233 |  |  | 148,233 |  |
| Consulting and Network Design | — |  |  | — |  |  | — |  |  | 41,312 |  |  | 41,312 |  |
| Total revenue by product line | $ | 2,911,318 |  |  | $ | 155,376 |  |  | $ | 54,555 |  |  | $ | 450,882 |  |  | $ | 3,572,131 |  |
| Timing of revenue recognition: |  |  |  |  |  |  |  |  |  |
| Products and services at a point in time | $ | 2,911,318 |  |  | $ | 55,530 |  |  | $ | 17,697 |  |  | $ | 18,802 |  |  | $ | 3,003,347 |  |
| Products and services transferred over time | — |  |  | 99,846 |  |  | 36,858 |  |  | 432,080 |  |  | 568,784 |  |
| Total revenue by timing of revenue recognition | $ | 2,911,318 |  |  | $ | 155,376 |  |  | $ | 54,555 |  |  | $ | 450,882 |  |  | $ | 3,572,131 |  |

[0000936395-19-000056:notes:140]
|  | Year Ended October 31, 2019 |
| Geographic Distribution: |  |
| North America | $ | 2,351,260 |  |
| EMEA | 566,718 |  |
| CALA | 152,653 |  |
| APAC | 501,500 |  |
| Total revenue by geographic distribution | $ | 3,572,131 |  |

[0000936395-19-000056:notes:141]
| • | Networking Platforms reflects sales of Ciena’s Converged Packet Optical and Packet Networking product lines. |

[0000936395-19-000056:notes:142]
| • | Converged Packet Optical - includes the 6500 Packet-Optical Platform, 5430 Reconfigurable Switching System, Waveserver® stackable interconnect system, the family of CoreDirector® Multiservice Optical Switches and the OTN configuration for the 5410 Reconfigurable Switching System. This product line also includes sales of the Z-Series Packet-Optical Platform. |

[0000936395-19-000056:notes:143]
| • | Packet Networking - includes the 3000 family of service delivery switches and service aggregation switches and the 5000 family of service aggregation switches. This product line also includes the 8700 Packetwave Platform, the Ethernet packet configuration for the 5410 Service Aggregation Switch, and the 6500 Packet Transport System (PTS), which combines packet switching, control plane operation, and integrated optics. |

[0000936395-19-000056:notes:144]
The Networking Platforms segment also includes sales of operating system software and enhanced software features embedded in each of the product lines above. Revenue from this segment is included in product revenue on the Consolidated Statements of Operations. Ciena’s hardware with the embedded operating system software and enhanced software features are considered distinct performance obligations for which the revenue is generally recognized upfront at a point in time upon transfer of control.

[0000936395-19-000056:notes:145]
| • | Platform Software and Services provides analytics, data, and planning tools to assist customers in managing Ciena’s Networking Platforms products in their networks. Ciena’s platform software includes its Manage, Control and Plan (MCP) domain controller solution, OneControl Unified Management System, ON-Center® Network and Service Management Suite, Ethernet Services Manager, Optical Suite Release and Planet Operate. Platform software-related services revenue includes sales of subscription, installation, support, and consulting services related to Ciena’s software platforms, operating system software and enhanced software features embedded in each of the Networking Platforms product lines above. Revenue from the software portion of this segment is included in product revenue on |

[0000936395-19-000056:notes:146]
the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations.

[0000936395-19-000056:notes:147]
| • | Blue Planet Automation Software and Services which is a comprehensive, open software suite that allows customers to use enhanced knowledge about their networks to drive adaptive optimization of their services and operations. Ciena’s Blue Planet Automation Platform includes multi-domain service orchestration (MDSO), network function virtualization (NFV), management and orchestration (NFV MANO), analytics, network health predictor (NHP), route optimization and assurance (ROA), inventory management and Ciena’s SDN Multilayer Controller and virtual wide area network (V-WAN) application. Ciena acquired the NHP and ROA software solutions as a part of its acquisition of Packet Design, LLC (“Packet Design”). Ciena acquired the inventory management software solution as a part of its acquisition of DonRiver Holdings, LLC (“DonRiver”). Services revenue includes sales of subscription, installation, support, consulting and design services related to Ciena’s Blue Planet Automation Platform. Revenue from the software portion of this segment is included in product revenue on the Consolidated Statements of Operations. Revenue from services portions of this segment is included in services revenue on the Consolidated Statements of Operations. |

[0000936395-19-000056:notes:148]
Ciena’s software platform revenue typically reflects either perpetual or term-based software licenses, and these sales are considered a distinct performance obligation where revenue is generally recognized upfront at a point in time upon transfer of control. Revenue from software subscription and support are recognized ratably over the period during which the services are performed. Revenue from professional services for solution customization, software and solution support services, consulting and design, and build-operate-transfer services relating to Ciena’s software offerings are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period.

[0000936395-19-000056:notes:149]
| • | Global Services reflects sales of a broad range of Ciena’s services for maintenance support and training, installation and deployment, and consulting and network design activities. Revenue from this segment is included in services revenue on the Consolidated Statements of Operations. |

[0000936395-19-000056:notes:150]
Ciena’s Global Services are considered a distinct performance obligation where revenue is generally recognized over time. Revenue from maintenance support is recognized ratably over the period during which the services are performed. Revenue from installation and deployment services and consulting and network design services are recognized over time with Ciena applying the input method to determine the amount of revenue to be recognized in a given period. Revenue from training services is generally recognized at a point in time upon completion of the service.

[0000936395-19-000056:notes:151]
Contract Balances

[0000936395-19-000056:notes:152]
The following table provides information about receivables, contract assets and contract liabilities (deferred revenue) from contracts with customers (in thousands):

[0000936395-19-000056:notes:153]
|  |  | Balance at October 31, 2019 |  | Adjusted Balance at November 1, 2018 |
| Accounts receivable, net |  | $ | 724,854 |  |  | $ | 799,011 |  |
| Contract assets |  | $ | 84,046 |  |  | $ | 31,380 |  |
| Deferred revenue |  | $ | 156,873 |  |  | $ | 140,704 |  |

[0000936395-19-000056:notes:154]
Our contract assets represent unbilled accounts receivable where transfer of a product or service has occurred but invoicing is conditional on completion of future performance obligations. These amounts are primarily related to installation and deployment and professional services arrangements where transfer of control has occurred but Ciena has not yet invoiced the customer. Contract assets are included in prepaid expenses and other current assets in the Consolidated Balance Sheets, see Note 10 below.

[0000936395-19-000056:notes:155]
Contract liabilities consist of deferred revenue and represent advanced payments against non-cancelable customer orders received prior to revenue recognition. Ciena recognized approximately $95.1 million of revenue during fiscal 2019 that was included in the deferred revenue balance at November 1, 2018. Revenue recognized due to changes in transaction price from performance obligations satisfied or partially satisfied in previous periods was immaterial during fiscal 2019.

[0000936395-19-000056:notes:156]
Capitalized contract acquisition costs consist of deferred sales commissions and were $15.7 million and $13.6 million as of October 31, 2019 and November 1, 2018, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $18.6 million during fiscal 2019 and was included in sales and marketing expense.

[0000936395-19-000056:notes:157]
Remaining Performance Obligations

[0000936395-19-000056:notes:158]
Remaining Performance Obligations (“RPO”) are comprised of non-cancelable customer purchase orders for products and services that are awaiting transfer of control for revenue recognition under the applicable contract terms. As of October 31, 2019, the aggregate amount of RPO was $950.0 million. As of October 31, 2019, Ciena expects approximately 83% of the RPO to be recognized as revenue within the next twelve months.


## us-gaap:ContractWithCustomerAssetAndLiabilityTableTextBlock

[0000936395-19-000056:notes:159]
As of the dates indicated, deferred revenue is comprised of the following (in thousands):

[0000936395-19-000056:notes:160]
|  | October 31, |
|  | 2019 |  | 2018 |
| Products | $ | 27,366 |  |  | $ | 42,474 |  |
| Services | 129,507 |  |  | 126,983 |  |
|  | 156,873 |  |  | 169,457 |  |
| Less current portion | (111,381 | ) |  | (111,134 | ) |
| Long-term deferred revenue | $ | 45,492 |  |  | $ | 58,323 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000936395-19-000056:notes:161]
BUSINESS COMBINATIONS

[0000936395-19-000056:notes:162]
DonRiver Acquisition

[0000936395-19-000056:notes:163]
On October 1, 2018, Ciena acquired DonRiver, a global software and services company specializing in federated network and service inventory management solutions within the service provider Operational Support Systems (OSS) environment. This transaction has been accounted for as the acquisition of a business.

[0000936395-19-000056:notes:164]
During fiscal 2019 and fiscal 2018, Ciena incurred approximately $2.4 million and $3.5 million of acquisition-related costs associated with this transaction, respectively. These costs and expenses include fees associated with financial, legal and accounting advisors and other employment-related costs, including the contingent compensation portion of the three year earn-out agreement as described below. These costs were recorded in acquisition and integration costs in the Consolidated Statement of Operations.

[0000936395-19-000056:notes:165]
The following table summarizes the purchase price for the acquisition (in thousands):

[0000936395-19-000056:notes:166]
|  | Amount |
| Cash | $ | 43,283 |  |
| Contingent consideration | 10,900 |  |
| Total purchase price | $ | 54,183 |  |

[0000936395-19-000056:notes:167]
The following table summarizes the final purchase price allocation related to the acquisition based on the estimated fair value of the acquired assets and assumed liabilities (in thousands):

[0000936395-19-000056:notes:168]
|  | Amount |
| Cash and cash equivalents | $ | 1,025 |  |
| Accounts receivable | 4,790 |  |
| Prepaid expenses and other long term assets | 372 |  |
| Goodwill | 10,453 |  |
| Customer relationships and contracts | 37,700 |  |
| Developed technology | 9,700 |  |
| Deferred revenue | (193 | ) |
| Other current and long term liabilities | (9,664 | ) |
| Total purchase price | $ | 54,183 |  |

[0000936395-19-000056:notes:169]
The acquisition of DonRiver includes a $28.5 million three-year earn-out arrangement that consists of both a contingent consideration element and a contingent compensation element. The contingent consideration element requires additional cash consideration to be paid based on the future revenues generally derived from the DonRiver business over a 25-month period from the acquisition date through October 31, 2020. The undiscounted amounts potentially payable by Ciena under the contingent consideration element range from $0.0 million to $15.0 million in the aggregate over the period. Any remaining

[0000936395-19-000056:notes:170]
amounts earned under the contingent consideration element are payable in the first quarters of fiscal 2020 and 2021. The $10.9 million fair value of the contingent consideration element as of the acquisition date was estimated by applying the income approach based on a discounted cash flow technique using Monte Carlo simulations. See Note 7 below. The contingent compensation element of the earn-out arrangement includes an employment condition for the selling shareholders who became employees of Ciena upon the completion of the acquisition. The range of amounts that Ciena could pay under the contingent compensation element is between $0.0 million and $13.5 million in the aggregate over the period. Any amounts earned under the contingent compensation element are payable in the first quarters of fiscal 2021 and fiscal 2022. These amounts are accrued over the period earned and recorded as expense in the acquisition and integration costs line item in the Consolidated Statement of Operations. During fiscal 2019 and fiscal 2018, Ciena recorded $5.1 million and $0.4 million, of contingent compensation associated with the earn-out arrangement, respectively.

[0000936395-19-000056:notes:171]
The contingent consideration liability established at closing had an acquisition date fair value of $10.9 million. As of October 31, 2019, the fair value of the contingent consideration liability was $8.1 million. A decrease of $2.8 million was recorded as a reduction to expense in the acquisitions and integrations costs line item in the Consolidated Statement of Operations. During fiscal 2019, $4.4 million of the total contingent consideration liability was earned. This payment is due during the first quarter of fiscal 2020 and is included in accrued liabilities and other short-term obligations. The remainder of the contingent consideration liability is included in Other long-term obligations on the Consolidated Balance Sheet as of October 31, 2019.

[0000936395-19-000056:notes:172]
Customer relationships and contracts represent agreements with existing DonRiver customers. Customer relationships and contracts are amortized on a straight line basis over their estimated useful life of seven years. Fair value was determined using the multi-period excess earnings method based on the present value of the incremental after-tax cash flows (or “excess earnings”) attributable to customer relationships for a discrete projection period.

[0000936395-19-000056:notes:173]
Developed technology represents purchased technology that had reached technological feasibility and for which DonRiver had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of seven years.

[0000936395-19-000056:notes:174]
The goodwill generated from the acquisition of DonRiver is primarily related to expected synergies. The total goodwill amount was recorded in the previous Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.

[0000936395-19-000056:notes:175]
Pro forma disclosures have not been included due to immateriality.

[0000936395-19-000056:notes:176]
Packet Design Acquisition

[0000936395-19-000056:notes:177]
On July 2, 2018, Ciena acquired Packet Design, a provider of network performance management software focused on Layer 3 network optimization, topology and route analytics, in a cash transaction for approximately $41.1 million in cash. This transaction has been accounted for as the acquisition of a business.

[0000936395-19-000056:notes:178]
During fiscal 2018, Ciena incurred approximately $1.6 million of acquisition-related costs associated with this transaction. There were minimal acquisition-related costs associated with this transaction during fiscal 2019. These costs and expenses include fees associated with financial, legal and accounting advisors and severance and other employment-related costs, including payments to certain former Packet Design employees.

[0000936395-19-000056:notes:179]
|  | Amount |
| Cash and cash equivalents | $ | 642 |  |
| Accounts receivable | 1,525 |  |
| Prepaid expenses and other | 450 |  |
| Equipment, furniture and fixtures | 31 |  |
| Goodwill | 20,304 |  |
| Customer relationships and contracts | 2,200 |  |
| Developed technology | 21,900 |  |
| Accounts payable | (165 | ) |
| Accrued liabilities | (657 | ) |
| Deferred revenue | (5,176 | ) |
| Total purchase price | $ | 41,054 |  |

[0000936395-19-000056:notes:180]
Customer relationships and contracts represent agreements with existing Packet Design customers. Customer relationships and contracts are amortized on a straight line basis over their estimated useful life of three years.

[0000936395-19-000056:notes:181]
Developed technology represents purchased technology that had reached technological feasibility and for which Packet Design had substantially completed development as of the date of acquisition. Fair value was determined using future discounted cash flows related to the projected income stream of the developed technology for a discrete projection period. Cash flows were discounted to their present value as of the closing date. Developed technology is amortized on a straight line basis over its estimated useful life of five years.

[0000936395-19-000056:notes:182]
The goodwill generated from the acquisition of Packet Design is primarily related to expected synergies. The total goodwill amount was recorded in the previous Software and Software-Related Services segment. The goodwill related to this acquisition is not deductible for tax purposes.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000936395-19-000056:notes:183]
RESTRUCTURING COSTS
Ciena has undertaken a number of restructuring activities intended to reduce expense and better align its workforce and costs with market opportunities, product development and business strategies. The following table sets forth the restructuring activity and balance of the restructuring liability accounts for the fiscal years indicated (in thousands):

[0000936395-19-000056:notes:184]
|  | Workforcereduction |  | Consolidationof excessfacilities |  | Total |
| Balance at October 31, 2016 | $ | 868 |  |  | $ | 1,970 |  |  | $ | 2,838 |  |
| Additional liability recorded | 5,883 |  | (1) | 5,432 |  | (4) | 11,315 |  |
| Adjustment to previous estimates | — |  |  | (1,048 | ) |  | (1,048 | ) |
| Cash payments | (5,460 | ) |  | (4,706 | ) |  | (10,166 | ) |
| Balance at October 31, 2017 | 1,291 |  |  | 1,648 |  |  | 2,939 |  |
| Additional liability recorded | 14,853 |  | (2) | 3,890 |  | (5) | 18,743 |  |
| Cash payments | (14,036 | ) |  | (3,799 | ) |  | (17,835 | ) |
| Balance at October 31, 2018 | 2,108 |  |  | 1,739 |  |  | 3,847 |  |
| Additional liability recorded | 13,779 |  | (3) | 10,759 |  | (6) | 24,538 |  |
| Cash payments | (11,904 | ) |  | (1,338 | ) |  | (13,242 | ) |
| Balance at October 31, 2019 | $ | 3,983 |  |  | $ | 11,160 |  |  | $ | 15,143 |  |
| Current restructuring liabilities | $ | 3,983 |  |  | $ | 1,484 |  |  | $ | 5,467 |  |
| Non-current restructuring liabilities | $ | — |  |  | $ | 9,676 |  |  | $ | 9,676 |  |

[0000936395-19-000056:notes:185]
_________________________________

[0000936395-19-000056:notes:186]
| (1) | During fiscal 2017, Ciena recorded a charge of $5.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 100 employees. |

[0000936395-19-000056:notes:187]
| (2) | During fiscal 2018, Ciena recorded a charge of $14.9 million of severance and other employee-related costs associated with a workforce reduction of approximately 240 employees. |

[0000936395-19-000056:notes:188]
| (3) | During fiscal 2019, Ciena recorded a charge of $13.8 million of severance and other employee-related costs associated with a workforce reduction of approximately 283 employees. |

[0000936395-19-000056:notes:189]
| (4) | Reflects unfavorable lease commitments and relocation costs incurred in connection with Ciena’s research and development center facility transitions in Ottawa, Canada. |

[0000936395-19-000056:notes:190]
| (5) | Reflects unfavorable lease commitments in connection with a portion of facilities located in Petaluma, California and in Gurgaon, India. |

[0000936395-19-000056:notes:191]
(6)

[0000936395-19-000056:notes:192]
Reflects unfavorable lease commitments in connection with a portion of facilities located in Alpharetta, Georgia, Spokane, Washington, Durham, North Carolina and Hanover, Maryland.


## us-gaap:OtherNonoperatingIncomeAndExpenseTextBlock

[0000936395-19-000056:notes:193]
INTEREST AND OTHER INCOME (LOSS), NET
The components of interest and other income (loss), net, were as follows (in thousands):

[0000936395-19-000056:notes:194]
|  |  | Year Ended October 31, |
|  |  | 2019 |  | 2018 |  | 2017 |
| Interest income |  | $ | 14,410 |  |  | $ | 13,703 |  |  | $ | 6,579 |  |
| Gain (loss) on non-hedge designated foreign currency forward contracts |  | 3 |  |  | 6,791 |  |  | (1,198 | ) |
| Foreign currency exchange losses |  | (9,800 | ) |  | (19,434 | ) |  | (4,376 | ) |
| Loss on fair value of debt conversion liability |  | — |  |  | (12,070 | ) |  | — |  |
| Other |  | (737 | ) |  | (1,019 | ) |  | (92 | ) |
| Interest and other income (loss), net |  | $ | 3,876 |  |  | $ | (12,029 | ) |  | $ | 913 |  |

[0000936395-19-000056:notes:195]
Ciena Corporation, as the U.S. parent entity, uses the U.S. Dollar as its functional currency; however, some of its foreign branch offices and subsidiaries use the local currency as their functional currency. During fiscal 2019, 2018 and 2017, Ciena recorded $9.8 million, $19.4 million and $4.4 million, respectively, in exchange rate losses, as a result of monetary assets and liabilities that were transacted in a currency other than the entity’s functional currency, and the re-measurement adjustments were recorded in interest and other income (loss), net. For fiscal 2019, the majority of the foreign currency exchange rate losses relate to fluctuations in the Brazilian and Argentine exchange rates. From time to time, Ciena uses foreign currency forwards to hedge these balance sheet exposures. These forwards are not designated as hedges for accounting purposes, and any net gain or loss associated with these derivatives is also reported in interest and other income (loss), net. During fiscal 2019, Ciena recorded minimal gains from non-hedge designated foreign currency forward contracts. For fiscal 2018 and fiscal 2017, Ciena recorded a gain of $6.8 million, and a loss of $1.2 million respectively, from non-hedge designated foreign currency forward contracts.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000936395-19-000056:notes:196]
SHORT-TERM AND LONG-TERM INVESTMENTS
 As of October 31, 2019, investments are comprised of the following (in thousands):

[0000936395-19-000056:notes:197]
|  | October 31, 2019 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 109,715 |  |  | $ | 225 |  |  | $ | — |  |  | $ | 109,940 |  |
| Included in long-term investments | 10,017 |  |  | — |  |  | (3 | ) |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 225 |  |  | $ | (3 | ) |  | $ | 119,954 |  |

[0000936395-19-000056:notes:198]
As of October 31, 2018, investments are comprised of the following (in thousands):

[0000936395-19-000056:notes:199]
|  | October 31, 2018 |
|  | Amortized Cost |  | Gross UnrealizedGains |  | Gross UnrealizedLosses |  | Estimated FairValue |
| U.S. government obligations: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 139,365 |  |  | $ | — |  |  | $ | (347 | ) |  | $ | 139,018 |  |
| Included in long-term investments | 59,029 |  |  | — |  |  | (59 | ) |  | 58,970 |  |
|  | $ | 198,394 |  |  | $ | — |  |  | $ | (406 | ) |  | $ | 197,988 |  |
| Commercial paper: |  |  |  |  |  |  |  |
| Included in short-term investments | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |
|  | $ | 9,963 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,963 |  |

[0000936395-19-000056:notes:200]
The following table summarizes the legal maturities of debt investments at October 31, 2019:

[0000936395-19-000056:notes:201]
|  | October 31, 2019 |
|  | Amortized Cost |  | Estimated FairValue |
| Less than one year | $ | 109,715 |  |  | $ | 109,940 |  |
| Due in 1-2 years | 10,017 |  |  | 10,014 |  |
|  | $ | 119,732 |  |  | $ | 119,954 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000936395-19-000056:notes:202]
FAIR VALUE MEASUREMENTS

[0000936395-19-000056:notes:203]
As of the dates indicated, the following tables summarize the fair value of assets and liabilities that were recorded at fair value on a recurring basis (in thousands):

[0000936395-19-000056:notes:204]
|  | October 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| U.S. government obligations | — |  |  | 119,954 |  |  | — |  |  | 119,954 |  |
| Foreign currency forward contracts | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Total assets measured at fair value | $ | 759,114 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 880,638 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Forward starting interest rate swaps | — |  |  | 21,093 |  |  | — |  |  | 21,093 |  |
| Contingent consideration | — |  |  | — |  |  | 3,705 |  |  | 3,705 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-19-000056:notes:205]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Money market funds | $ | 590,684 |  |  | $ | — |  |  | $ | — |  |  | $ | 590,684 |  |
| U.S. government obligations | — |  |  | 197,988 |  |  | — |  |  | 197,988 |  |
| Commercial paper | — |  |  | 69,888 |  |  | — |  |  | 69,888 |  |
| Foreign currency forward contracts | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Forward starting interest rate swaps | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Foreign currency forward contracts | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Contingent consideration | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-19-000056:notes:206]
As of the dates indicated, the assets and liabilities above were presented on Ciena’s Consolidated Balance Sheet as follows (in thousands):

[0000936395-19-000056:notes:207]
|  | October 31, 2019 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 759,114 |  |  | $ | — |  |  | $ | — |  |  | $ | 759,114 |  |
| Short-term investments | — |  |  | 109,940 |  |  | — |  |  | 109,940 |  |
| Prepaid expenses and other | — |  |  | 1,570 |  |  | — |  |  | 1,570 |  |
| Long-term investments | — |  |  | 10,014 |  |  | — |  |  | 10,014 |  |
| Total assets measured at fair value | $ | 759,114 |  |  | $ | 121,524 |  |  | $ | — |  |  | $ | 880,638 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 35 |  |  | $ | — |  |  | $ | 35 |  |
| Other long-term obligations | — |  |  | 21,093 |  |  | 3,705 |  |  | 24,798 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 21,128 |  |  | $ | 3,705 |  |  | $ | 24,833 |  |

[0000936395-19-000056:notes:208]
|  | October 31, 2018 |
|  | Level 1 |  | Level 2 |  | Level 3 |  | Total |
| Assets: |  |  |  |  |  |  |  |
| Cash equivalents | $ | 590,684 |  |  | $ | 59,925 |  |  | $ | — |  |  | $ | 650,609 |  |
| Short-term investments | — |  |  | 148,981 |  |  | — |  |  | 148,981 |  |
| Prepaid expenses and other | — |  |  | 133 |  |  | — |  |  | 133 |  |
| Long-term investments | — |  |  | 58,970 |  |  | — |  |  | 58,970 |  |
| Other long-term assets | — |  |  | 779 |  |  | — |  |  | 779 |  |
| Total assets measured at fair value | $ | 590,684 |  |  | $ | 268,788 |  |  | $ | — |  |  | $ | 859,472 |  |
| Liabilities: |  |  |  |  |  |  |  |
| Accrued liabilities | $ | — |  |  | $ | 3,231 |  |  | $ | — |  |  | $ | 3,231 |  |
| Debt conversion liability | — |  |  | 164,212 |  |  | — |  |  | 164,212 |  |
| Other long-term obligations | — |  |  | — |  |  | 10,900 |  |  | 10,900 |  |
| Total liabilities measured at fair value | $ | — |  |  | $ | 167,443 |  |  | $ | 10,900 |  |  | $ | 178,343 |  |

[0000936395-19-000056:notes:209]
Ciena did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000936395-19-000056:notes:210]
Ciena’s Level 3 liability includes $3.7 million in other long-term obligations as of October 31, 2019. This reflects a contingent consideration element of a three-year payout arrangement associated with Ciena’s purchase of DonRiver in the fourth quarter of fiscal 2018. See Note 3 above.


## us-gaap:LoansNotesTradeAndOtherReceivablesDisclosureTextBlock

[0000936395-19-000056:notes:211]
ACCOUNTS RECEIVABLE

[0000936395-19-000056:notes:212]
As of October 31, 2019, one customer accounted for 12.0% of net accounts receivable. As of October 31, 2018, one customer accounted for 10.0% of net accounts receivable. Ciena has not historically experienced a significant amount of bad debt expense. During fiscal 2017, Ciena’s allowance for doubtful accounts includes a provision for a significant asset impairment of $13.7 million for a trade receivable related to a single customer in the APAC region. The following table summarizes the activity in Ciena’s allowance for doubtful accounts for the fiscal years indicated (in thousands):

[0000936395-19-000056:notes:213]
| Year ended |  | Beginning |  |  |  | Net |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Deductions |  | Balance |
| 2017 |  | $ | 3,963 |  |  | $ | 18,221 |  |  | $ | 4,604 |  |  | $ | 17,580 |  |
| 2018 |  | $ | 17,580 |  |  | $ | 2,700 |  |  | $ | 2,902 |  |  | $ | 17,378 |  |
| 2019 |  | $ | 17,378 |  |  | $ | 6,740 |  |  | $ | 4,017 |  |  | $ | 20,101 |  |


## us-gaap:InventoryDisclosureTextBlock

[0000936395-19-000056:notes:214]
INVENTORIES
As of the dates indicated, inventories are comprised of the following (in thousands):

[0000936395-19-000056:notes:215]
|  | October 31, |
|  | 2019 |  | 2018 |
| Raw materials | $ | 99,041 |  |  | $ | 67,468 |  |
| Work-in-process | 13,657 |  |  | 9,589 |  |
| Finished goods | 226,622 |  |  | 188,575 |  |
| Deferred cost of goods sold | 53,051 |  |  | 48,057 |  |
|  | 392,371 |  |  | 313,689 |  |
| Reserve for excess and obsolescence | (47,322 | ) |  | (50,938 | ) |
|  | $ | 345,049 |  |  | $ | 262,751 |  |

[0000936395-19-000056:notes:216]
Ciena writes down its inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated net realizable value based on assumptions about future demand, which are affected by changes in Ciena’s strategic direction, discontinuance of a product or introduction of newer versions of products, declines in the sales of or forecasted demand for certain products, and general market conditions. During fiscal 2019, fiscal 2018 and fiscal 2017, Ciena recorded a provision for excess and obsolescence of $28.1 million, $30.6 million, and $35.5 million, respectively, primarily related to the decrease in the forecasted demand for certain Converged Packet Optical products. Deductions from the provision for excess and obsolete inventory relate to disposal activities.

[0000936395-19-000056:notes:217]
The following table summarizes the activity in Ciena’s reserve for excess and obsolete inventory for the fiscal years indicated (in thousands):

[0000936395-19-000056:notes:218]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions |  | Disposals |  | Balance |
| 2017 |  | $ | 62,503 |  |  | $ | 35,459 |  |  | $ | 46,756 |  |  | $ | 51,206 |  |
| 2018 |  | $ | 51,206 |  |  | $ | 30,615 |  |  | $ | 30,883 |  |  | $ | 50,938 |  |
| 2019 |  | $ | 50,938 |  |  | $ | 28,085 |  |  | $ | 31,701 |  |  | $ | 47,322 |  |


## cien:PrepaidExpensesAndOtherTextBlock

[0000936395-19-000056:notes:219]
PREPAID EXPENSES AND OTHER
As of the dates indicated, prepaid expenses and other are comprised of the following (in thousands):

[0000936395-19-000056:notes:220]
|  | October 31, |
|  | 2019 |  | 2018 |
| Prepaid VAT and other taxes | $ | 84,706 |  |  | $ | 82,518 |  |
| Contract assets | 84,046 |  |  | — |  |
| Prepaid expenses | 48,680 |  |  | 32,987 |  |
| Product demonstration equipment, net | 38,900 |  |  | 37,623 |  |
| Other non-trade receivables | 28,136 |  |  | 25,716 |  |
| Capitalized contract acquisition costs | 11,677 |  |  | — |  |
| Derivative assets | 1,570 |  |  | 133 |  |
| Deferred deployment expense | 125 |  |  | 19,342 |  |
| Restricted cash | 74 |  |  | — |  |
| Financing receivable | — |  |  | 626 |  |
|  | $ | 297,914 |  |  | $ | 198,945 |  |

[0000936395-19-000056:notes:221]
Depreciation of product demonstration equipment was $8.8 million, $9.0 million and $10.0 million for fiscal 2019, 2018 and 2017, respectively.

[0000936395-19-000056:notes:222]
For further discussion on contract assets and capitalized contract acquisition costs, see Note 2 above.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000936395-19-000056:notes:223]
EQUIPMENT, BUILDING, FURNITURE AND FIXTURES
As of the dates indicated, equipment, building, furniture and fixtures are comprised of the following (in thousands):

[0000936395-19-000056:notes:224]
|  | October 31, |
|  | 2019 |  | 2018 |
| Equipment, furniture and fixtures | $ | 544,012 |  |  | $ | 504,714 |  |
| Building subject to capital lease | 71,760 |  |  | 71,968 |  |
| Leasehold improvements | 94,626 |  |  | 94,195 |  |
|  | 710,398 |  |  | 670,877 |  |
| Accumulated depreciation and amortization | (423,514 | ) |  | (378,810 | ) |
|  | $ | 286,884 |  |  | $ | 292,067 |  |

[0000936395-19-000056:notes:225]
During fiscal 2019, fiscal 2018 and fiscal 2017, Ciena recorded depreciation of equipment, building, furniture and fixtures, and amortization of leasehold improvements of $78.8 million, $75.3 million and $67.2 million, respectively.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000936395-19-000056:notes:226]
INTANGIBLE ASSETS
As of the dates indicated, intangible assets are comprised of the following (in thousands):

[0000936395-19-000056:notes:227]
|  | October 31, |
|  | 2019 |  | 2018 |
|  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |  | GrossIntangible |  | AccumulatedAmortization |  | NetIntangible |
| Developed technology | $ | 373,526 |  |  | $ | (308,261 | ) |  | $ | 65,265 |  |  | $ | 373,581 |  |  | $ | (285,233 | ) |  | $ | 88,348 |  |
| Patents and licenses | 3,565 |  |  | (2,244 | ) |  | 1,321 |  |  | 3,565 |  |  | (1,958 | ) |  | 1,607 |  |
| Customer relationships, covenants not to compete, outstanding purchase orders and contracts | 374,381 |  |  | (328,186 | ) |  | 46,195 |  |  | 374,620 |  |  | (316,350 | ) |  | 58,270 |  |
| Total intangible assets | $ | 751,472 |  |  | $ | (638,691 | ) |  | $ | 112,781 |  |  | $ | 751,766 |  |  | $ | (603,541 | ) |  | $ | 148,225 |  |

[0000936395-19-000056:notes:228]
The aggregate amortization expense of intangible assets was $35.1 million, $25.8 million and $45.7 million for fiscal 2019, fiscal 2018 and fiscal 2017, respectively. Expected future amortization of intangible assets for the fiscal years indicated is as follows (in thousands):

[0000936395-19-000056:notes:229]
| Year Ended October 31, |  |
| 2020 | $ | 34,008 |  |
| 2021 | 30,830 |  |
| 2022 | 24,809 |  |
| 2023 | 10,000 |  |
| 2024 | 6,948 |  |
| Thereafter | 6,186 |  |
|  | $ | 112,781 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000936395-19-000056:notes:230]
GOODWILL

[0000936395-19-000056:notes:231]
During fiscal 2019, Ciena separated its previous Software and Software-Related Services segment into two stand-alone operating segments: Blue Planet Automation Software and Services and Platform Software and Services. Ciena was required to separate this operating segment as a result of an internal realignment to support its corporate strategy to further promote customer adoption of its Blue Planet Automation Software and Services, and corresponding changes by management to the evaluation of resource allocation for and measurement of performance of this business. Accordingly, as of the end of fiscal 2019, for reporting purposes, our results of operations are presented based on the following operating segments: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services.

[0000936395-19-000056:notes:232]
As a result of the separation of Platform Software and Services and Blue Planet Automation Software and Services into separate operating segments, Ciena allocated the $232.2 million of goodwill previously allocated to the combined Software and Software Related-Services segment to the two separate operating segments based on each operating segments relative fair value using a discounted cash flow model. The following table presents the goodwill allocated to Ciena’s operating segments as of October 31, 2019 and October 31, 2018, as well as the changes to goodwill during fiscal 2019 (in thousands):

[0000936395-19-000056:notes:233]
|  | Balance at October 31, 2018 |  | Reallocation |  | Acquisitions |  | Impairments |  | Translation |  | Balance at October 31, 2019 |
| Software and Software Related Services | $ | 232,185 |  |  | $ | (232,185 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Platform Software and Services | — |  |  | 156,191 |  |  | — |  |  | — |  |  | — |  |  | 156,191 |  |
| Blue Planet Automation Software and Services | — |  |  | 75,994 |  |  | — |  |  | — |  |  | — |  |  | 75,994 |  |
| Networking Platforms | 65,783 |  |  | — |  |  | — |  |  | — |  |  | (31 | ) |  | 65,752 |  |
| Total | $ | 297,968 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (31 | ) |  | $ | 297,937 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000936395-19-000056:notes:234]
OTHER BALANCE SHEET DETAILS
As of the dates indicated, other long-term assets are comprised of the following (in thousands):

[0000936395-19-000056:notes:235]
|  | October 31, |
|  | 2019 |  | 2018 |
| Maintenance spares inventory, net | $ | 55,482 |  |  | $ | 45,679 |  |
| Cost method investments | 10,727 |  |  | 8,056 |  |
| Capitalized contract acquisition costs | 3,994 |  |  | — |  |
| Deferred debt issuance costs, net (1) | 1,609 |  |  | 720 |  |
| Restricted cash | 42 |  |  | 11 |  |
| Forward starting interest rate swaps | — |  |  | 779 |  |
| Other | 17,132 |  |  | 16,407 |  |
|  | $ | 88,986 |  |  | $ | 71,652 |  |

[0000936395-19-000056:notes:236]
(1) Deferred debt issuance costs relate to Ciena’s senior secured asset-based revolving credit facility (the “ABL Credit Facility”) entered into during fiscal 2019 and its predecessor credit facility (described in Note 18 below). The amortization of deferred debt issuance costs for the ABL Credit Facility and its predecessor is included in interest expense, and was $0.3 million, $0.3 million and $0.3 million for fiscal 2019, fiscal 2018 and fiscal 2017, respectively.

[0000936395-19-000056:notes:237]
As of the dates indicated, accrued liabilities and other short-term obligations are comprised of the following (in thousands):

[0000936395-19-000056:notes:238]
|  | October 31, |
|  | 2019 |  | 2018 |
| Compensation, payroll related tax and benefits | $ | 182,363 |  |  | $ | 140,277 |  |
| Warranty | 48,498 |  |  | 44,740 |  |
| Vacation (1) | 22,290 |  |  | 42,507 |  |
| Contingent Consideration | 4,372 |  |  | — |  |
| Capital lease obligations | 2,764 |  |  | 3,547 |  |
| Interest payable | 1,007 |  |  | 1,072 |  |
| Other | 121,446 |  |  | 107,932 |  |
|  | $ | 382,740 |  |  | $ | 340,075 |  |

[0000936395-19-000056:notes:239]
(1) Reduction is primarily due to the payout of North America vacation accruals in conjunction with Ciena’s adoption of a new vacation policy during fiscal 2019.

[0000936395-19-000056:notes:240]
The following table summarizes the activity in Ciena’s accrued warranty for the fiscal years indicated (in thousands):

[0000936395-19-000056:notes:241]
| Year ended |  | Beginning |  | Current Year |  |  |  | Ending |
| October 31, |  | Balance |  | Provisions (1) |  | Settlements |  | Balance |
| 2017 |  | $ | 52,324 |  |  | $ | 7,965 |  |  | $ | 17,833 |  |  | $ | 42,456 |  |
| 2018 |  | $ | 42,456 |  |  | $ | 20,992 |  |  | $ | 18,708 |  |  | $ | 44,740 |  |
| 2019 |  | $ | 44,740 |  |  | $ | 23,105 |  |  | $ | 19,347 |  |  | $ | 48,498 |  |

[0000936395-19-000056:notes:242]
(1) As a result of actual failure rates lower than expected, Ciena adjusted its fiscal 2017 provisions for warranty. These adjustments for previous fiscal year provisions had the effect of reducing warranty provisions by $9.7 million for fiscal 2017. During fiscal 2018 and fiscal 2019, Ciena determined that failure rates for prior estimates remained unchanged, and accordingly did not make any adjustments for previous fiscal year provisions not yet settled. As a result, Ciena’s warranty provision for fiscal 2018 and fiscal 2019 increased as compared to fiscal 2017.

[0000936395-19-000056:notes:243]
As of the dates indicated, other long-term obligations are comprised of the following (in thousands):

[0000936395-19-000056:notes:244]
|  | October 31, |
|  | 2019 |  | 2018 |
| Capital lease obligations | $ | 65,284 |  |  | $ | 68,245 |  |
| Income tax liability | 20,546 |  |  | 15,894 |  |
| Interest rate swap liability | 21,093 |  |  | — |  |
| Deferred tenant allowance | 6,248 |  |  | 7,244 |  |
| Straight-line rent | 5,434 |  |  | 6,750 |  |
| Contingent consideration | 3,705 |  |  | 10,900 |  |
| Other | 26,437 |  |  | 10,380 |  |
|  | $ | 148,747 |  |  | $ | 119,413 |  |

[0000936395-19-000056:notes:245]
The following is a schedule by fiscal years of future minimum lease payments under capital leases and the present value of minimum lease payments as of October 31, 2019 (in thousands):

[0000936395-19-000056:notes:246]
| Year Ending October 31, | Amount |
| 2020 | $ | 7,652 |  |
| 2021 | 7,547 |  |
| 2022 | 7,860 |  |
| 2023 | 8,067 |  |
| 2024 | 8,067 |  |
| Thereafter | 67,126 |  |
| Net minimum capital lease payments | 106,319 |  |
| Less: Amount representing interest | (38,271 | ) |
| Present value of minimum lease payments | 68,048 |  |
| Less: Current portion of present value of minimum lease payments | (2,764 | ) |
| Long-term portion of present value of minimum lease payments | $ | 65,284 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000936395-19-000056:notes:247]
DERIVATIVE INSTRUMENTS

[0000936395-19-000056:notes:248]
Foreign Currency Derivatives

[0000936395-19-000056:notes:249]
During fiscal 2019 and fiscal 2018, Ciena entered into forward contracts to hedge its foreign exchange exposure from its forecasted cash flows in order to reduce the variability in its Canadian Dollar and Indian Rupee denominated expense, which principally relates to research and development activities. The notional amount of these contracts was approximately $197.4 million and $163.2 million as of October 31, 2019 and October 31, 2018, respectively. These foreign exchange contracts have maturities of 24 months or less and have been designated as cash flow hedges.

[0000936395-19-000056:notes:250]
During fiscal 2019 and fiscal 2018, in order to hedge its foreign exchange exposure from certain balance sheet items, Ciena entered into forward contracts to mitigate risk due to volatility in the Brazilian Real, Canadian Dollar, Euro, Australian Dollar,

[0000936395-19-000056:notes:251]
British Pound Sterling, Mexican Peso, and Japanese Yen. The notional amount of these contracts was approximately $206.0 million and $162.6 million as of October 31, 2019 and October 31, 2018. These foreign exchange contracts have maturities of 12 months or less and have not been designated as hedges for accounting purposes.

[0000936395-19-000056:notes:252]
Interest Rate Derivatives

[0000936395-19-000056:notes:253]
Ciena is exposed to floating rates of LIBOR interest on its term loan borrowings (see Note 17 below) and has hedged such risk by entering into floating to fixed interest rate swap arrangements (“interest rate swaps”). During the fourth quarter of fiscal 2018, Ciena refinanced its previous term loan in the aggregate principal amount of $394.0 million, maturing on January 30, 2022 (the “2022 Term Loan”), into a new term loan due September 28, 2025 (the “2025 Term Loan”), increasing the aggregate outstanding principal to $700.0 million and extending the maturity to September 2025 (see Note 17 below). In conjunction with the refinancing, Ciena unwound its then-existing interest rate swaps for a cash gain of $6.8 million, which was recorded in Other Comprehensive Income, and entered into new floating-to-fixed interest rate swaps. The interest rate swaps fix the LIBOR rate of approximately $350.0 million of the principal amount of the 2025 Term Loan at 2.957% through September 2023. The total notional amount of these interest rate swaps in effect as of October 31, 2019 was $350.0 million.

[0000936395-19-000056:notes:254]
Ciena expects the variable rate payments to be received under the terms of the interest rate swaps to offset exactly the forecasted variable rate payments on the equivalent notional amounts of the term loan. These derivative contracts have been designated as cash flow hedges.

[0000936395-19-000056:notes:255]
Other information regarding Ciena’s derivatives is immaterial for separate financial statement presentation. See Notes 5 and 7 above.

[0000936395-19-000056:notes:256]
Debt Conversion Liability Associated With the New Notes

[0000936395-19-000056:notes:257]
The New Notes provided Ciena the option, at its election, to settle conversions of such notes for cash, shares of its common stock, or a combination of cash and shares equal to the aggregate amount due upon conversion. On August 30, 2018, Ciena notified the noteholders that it had elected to settle conversion of the New Notes in a combination of cash and shares, provided that the cash portion would not exceed an aggregate amount of $400.0 million. Ciena became obligated to settle a portion of the conversion feature in cash and reclassified the cash conversion feature from equity to a derivative liability at its current fair value of $152.1 million. As of October 31, 2018, Ciena recorded a loss of approximately $12.1 million related to the change in fair value of the embedded conversion feature. On November 15, 2018, Ciena paid approximately $111.3 million in cash and issued 1.6 million shares in settlement of this embedded conversion feature.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000936395-19-000056:notes:258]
ACCUMULATED OTHER COMPREHENSIVE INCOME
The following table summarizes the changes in accumulated balances of other comprehensive income (“AOCI”):

[0000936395-19-000056:notes:259]
|  |  | Unrealized Gain/(Loss) on Available-for-Sale Securities |  | Unrealized Gain/(Loss) on Foreign Currency Forward Contracts |  | Unrealized Gain/(Loss) on Forward Starting Interest Rate Swaps |  | Cumulative Foreign Currency Translation Adjustment |  | Total |
| Balance at October 31, 2016 |  | $ | 139 |  |  | $ | (1,091 | ) |  | $ | (5,967 | ) |  | $ | (17,410 | ) |  | $ | (24,329 | ) |
| Other comprehensive gain (loss) before reclassifications |  | (590 | ) |  | 1,290 |  |  | 3,669 |  |  | 8,012 |  |  | 12,381 |  |
| Amounts reclassified from AOCI |  | — |  |  | (1,585 | ) |  | 2,516 |  |  | — |  |  | 931 |  |
| Balance at October 31, 2017 |  | (451 | ) |  | (1,386 | ) |  | 218 |  |  | (9,398 | ) |  | (11,017 | ) |
| Other comprehensive gain (loss) before reclassifications |  | 26 |  |  | (3,242 | ) |  | 6,011 |  |  | 686 |  |  | 3,481 |  |
| Amounts reclassified from AOCI |  | — |  |  | 1,568 |  |  | 188 |  |  | — |  |  | 1,756 |  |
| Balance at October 31, 2018 |  | (425 | ) |  | (3,060 | ) |  | 6,417 |  |  | (8,712 | ) |  | (5,780 | ) |
| Other comprehensive gain (loss) before reclassifications |  | 577 |  |  | 14 |  |  | (18,948 | ) |  | (763 | ) |  | (19,120 | ) |
| Amounts reclassified from AOCI |  | — |  |  | 3,971 |  |  | (1,155 | ) |  | — |  |  | 2,816 |  |
| Balance at October 31, 2019 |  | $ | 152 |  |  | $ | 925 |  |  | $ | (13,686 | ) |  | $ | (9,475 | ) |  | $ | (22,084 | ) |

[0000936395-19-000056:notes:260]
All amounts reclassified from AOCI related to settlement (gains) losses on foreign currency forward contracts designated as cash flow hedges impacted revenue, research and development expense or sales and marketing expense on the Consolidated Statements of Operations. All amounts reclassified from AOCI related to settlement (gains) losses on forward starting interest rate swaps designated as cash flow hedges impacted interest and other income (loss), net on the Consolidated Statements of Operations.


## cien:TermLoanandConvertibleNotesPayableDisclosureTextBlock

[0000936395-19-000056:notes:261]
SHORT-TERM AND LONG-TERM DEBT

[0000936395-19-000056:notes:262]
2025 Term Loan

[0000936395-19-000056:notes:263]
The net carrying values of Ciena’s term loan were comprised of the following for the fiscal periods indicated (in thousands):

[0000936395-19-000056:notes:264]
|  |  | October 31, 2019 |  | October 31, 2018 |
|  |  | Principal Balance |  | Unamortized Discount |  | Deferred Debt Issuance Costs |  | Net Carrying Value |  | Net Carrying Value |
| Term Loan Payable due September 28, 2025 |  | $ | 693,000 |  |  | $ | (1,958 | ) |  | $ | (3,636 | ) |  | $ | 687,406 |  |  | $ | 693,450 |  |

[0000936395-19-000056:notes:265]
Deferred debt issuance costs deducted from the carrying amount of the term loan totaled $3.6 million at October 31, 2019 and $4.3 million at October 31, 2018. Deferred debt issuance costs are amortized using the straight-line method, which approximates the effect of the effective interest rate method, through the maturity of the term loan. The amortization of deferred debt issuance costs for this term loan is included in interest expense, and was $0.6 million and $0.7 million during fiscal 2019 and fiscal 2018, respectively.

[0000936395-19-000056:notes:266]
As of October 31, 2019, the estimated fair value of the term loan was $694.7 million. Ciena’s term loan is categorized as Level 2 in the fair value hierarchy. Ciena estimated the fair value of its term loan using a market approach based on observable inputs, such as current market transactions involving comparable securities.

[0000936395-19-000056:notes:267]
On September 28, 2018, Ciena, as borrower, and Ciena Communications, Inc. and Ciena Government Solutions, Inc., as guarantors, entered into an Increase Joinder and Refinancing Amendment to Credit Agreement with the lenders party thereto and the Administrative Agent (the “Refinancing Agreement”), pursuant to which Ciena refinanced its the 2022 Term Loan into the 2025 Term Loan. In connection with the transaction, Ciena received a loan in the amount of $699.1 million, net of original discount, from the 2025 Term Loan and simultaneously repaid $394.0 million of outstanding principal under the 2022 Term Loan, resulting in proceeds of $305.1 million. The 2025 Term Loan requires Ciena to make installment payments of $1.75 million on a quarterly basis. Based on the continuation of existing lenders and the addition of new lenders, this arrangement was primarily accounted for as a modification of debt and, as such, $3.8 million of debt issuance costs associated with the 2025 Term Loan were expensed. The aggregate balance of $2.4 million of debt issuance costs and approximately $1.4 million of original discount from the 2022 Term Loan, $1.9 million of debt issuance costs associated with new lenders for the 2025 Term Loan, and approximately $0.9 million of original discount from the 2025 Term Loan, were included in the carrying value of the 2025 Term Loan.

[0000936395-19-000056:notes:268]
The Refinancing Agreement amends Ciena’s credit agreement, dated July 15, 2014, as amended (the “Credit Agreement”) and provides that the 2025 Term Loan will, among other things:

[0000936395-19-000056:notes:269]
| • | amortize in equal quarterly installments in aggregate amounts equal to 0.25% of the principal amount of the 2025 Term Loan as of September 28, 2018, with the balance payable at maturity; |

[0000936395-19-000056:notes:270]
| • | be subject to mandatory prepayment provisions upon the occurrence of certain specified events substantially similar to the 2022 Term Loan, including certain asset sales, debt issuances and receipt of annual Excess Cash Flow (as defined in the Credit Agreement); |

[0000936395-19-000056:notes:271]
| • | bear interest, at Ciena’s election, at a per annum rate equal to (a) LIBOR (subject to a floor of 0.00%) plus an applicable margin of 2.00%, or (b) a base rate (subject to a floor of 1.00%) plus an applicable margin of 1.00%; and |

[0000936395-19-000056:notes:272]
•

[0000936395-19-000056:notes:273]
be repayable at any time at Ciena’s election, provided that repayment of the 2025 Term Loan with proceeds of certain indebtedness prior to March 28, 2019 will require a prepayment premium of 1.00% of the aggregate principal amount of such prepayment.


## cien:AssetBasedLendingCreditAgreementTextBlock

[0000936395-19-000056:notes:274]
ABL CREDIT FACILITY

[0000936395-19-000056:notes:275]
Ciena Corporation and certain of its subsidiaries are parties to the ABL Credit Facility, which provides for a total commitment of $300 million with a maturity date of October 28, 2024. The ABL Credit Facility was entered into on October 28, 2019 and replaced a predecessor senior secured asset-based revolving credit facility. Ciena principally uses the ABL Credit Facility to support the issuance of letters of credit that arise in the ordinary course of its business and thereby to reduce its use of cash required to collateralize these instruments.

[0000936395-19-000056:notes:276]
As of October 31, 2019, letters of credit totaling $72.9 million were outstanding under the ABL Credit Facility. There were no borrowings outstanding under the ABL Credit Facility as of October 31, 2019.


## us-gaap:EarningsPerShareTextBlock

[0000936395-19-000056:notes:277]
EARNINGS (LOSS) PER SHARE CALCULATION
The following tables (in thousands except per share amounts) show a reconciliation of the numerator and denominator of the Basic EPS and the Diluted EPS. Basic EPS is computed using the weighted average number of common shares outstanding. Diluted EPS is computed using the weighted average number of the following, in each case, to the extent the effect is not anti-dilutive: (i) common shares outstanding, (ii) shares issuable upon vesting of restricted stock units and (iii) shares issuable under Ciena’s employee stock purchase plan and upon exercise of outstanding stock options, using the treasury stock method.

[0000936395-19-000056:notes:278]
Numerator

[0000936395-19-000056:notes:279]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Net income (loss) | $ | 253,434 |  |  | $ | (344,690 | ) |  | $ | 1,261,953 |  |
| Less: Loss on fair value of debt conversion liability |  |  |  | (12,894 | ) |  | — |  |
| Add: Interest expense associated with 0.875% Convertible Senior Notes due 2017 | — |  |  | — |  |  | 853 |  |
| Add: Interest expense associated with 3.75% Convertible Senior Notes due 2018 (Original Notes) | — |  |  | — |  |  | 7,224 |  |
| Add: Interest expense associated with 4.0% Convertible Senior Notes due 2020 | — |  |  | — |  |  | 8,691 |  |
| Net income (loss) used to calculate Diluted EPS | $ | 253,434 |  |  | $ | (357,584 | ) |  | $ | 1,278,721 |  |

[0000936395-19-000056:notes:280]
Denominator

[0000936395-19-000056:notes:281]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Basic weighted average shares outstanding | 155,720 |  |  | 143,738 |  |  | 141,997 |  |
| Add: Shares underlying outstanding stock options, employee stock purchase plan and restricted stock units | 1,892 |  |  | — |  |  | 1,354 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) | — |  |  | — |  |  | 404 |  |
| Add: Shares underlying 0.875% Convertible Senior Notes due 2017 | — |  |  | — |  |  | 3,032 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (Original Notes) | — |  |  | — |  |  | 13,934 |  |
| Add: Shares underlying 4.0% Convertible Senior Notes due 2020 | — |  |  | — |  |  | 9,198 |  |
| Diluted weighted average shares outstanding | 157,612 |  |  | 143,738 |  |  | 169,919 |  |

[0000936395-19-000056:notes:282]
EPS

[0000936395-19-000056:notes:283]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Basic EPS | $ | 1.63 |  |  | $ | (2.40 | ) |  | $ | 8.89 |  |
| Diluted EPS | $ | 1.61 |  |  | $ | (2.49 | ) |  | $ | 7.53 |  |

[0000936395-19-000056:notes:284]
The following table summarizes the weighted average shares excluded from the calculation of the denominator for Diluted EPS due to their anti-dilutive effect for the fiscal years indicated (in thousands):

[0000936395-19-000056:notes:285]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Shares underlying stock options and restricted stock units | 234 |  |  | 2,235 |  |  | 958 |  |
| Add: Shares underlying 3.75% Convertible Senior Notes due 2018 (New Notes) | — |  |  | 1,780 |  | — |  | — |  |
| 3.75% Convertible Senior Notes due October 15, 2018 (Original Notes) | — |  |  | 2,883 |  |  | — |  |
| 4.0% Convertible Senior Notes due December 15, 2020 | — |  |  | 9,123 |  |  | — |  |
| Total shares excluded due to anti-dilutive effect | 234 |  |  | 16,021 |  |  | 958 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000936395-19-000056:notes:286]
STOCKHOLDERS’ EQUITY

[0000936395-19-000056:notes:287]
Stock Repurchase Program

[0000936395-19-000056:notes:288]
On December 13, 2018, Ciena announced that its Board of Directors authorized a program to repurchase up to $500 million of Ciena’s common stock. The amount and timing of repurchases are subject to a variety of factors including liquidity,

[0000936395-19-000056:notes:289]
cash flow, stock price, and general business and market conditions. The program may be modified, suspended, or discontinued at any time.

[0000936395-19-000056:notes:290]
The following table summarizes activity of the stock repurchase program, reported based on trade date:

[0000936395-19-000056:notes:291]
|  | Shares Repurchased |  | Weighted-Average Price per Share |  | Amount Repurchased (in thousands) |
| Cumulative balance at October 31, 2018 | — |  |  | $ | — |  |  | $ | — |  |
| Repurchase of common stock under the stock repurchase program | 3,838,466 |  |  | $ | 39.10 |  |  | 150,076 |  |
| Cumulative balance at October 31, 2019 | 3,838,466 |  |  | $ | 39.10 |  |  | $ | 150,076 |  |

[0000936395-19-000056:notes:292]
The purchase price for the shares of Ciena’s stock repurchased is reflected as a reduction of common stock and additional paid-in capital.

[0000936395-19-000056:notes:293]
Stock Repurchases Related to Restricted Stock Unit Tax Withholdings

[0000936395-19-000056:notes:294]
Ciena repurchases shares of common stock to satisfy employee tax withholding obligations due upon vesting of stock unit awards. The purchase price of $29.1 million for the shares of Ciena’s stock repurchased is reflected as a reduction to stockholders’ equity. Ciena is required to allocate the purchase price of the repurchased shares as a reduction of common stock and additional paid-in capital.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000936395-19-000056:notes:295]
INCOME TAXES
For the fiscal periods indicated, the provision (benefit) for income taxes consists of the following (in thousands):

[0000936395-19-000056:notes:296]
|  | Year Ended October 31, |  |
|  | 2019 |  | 2018 |  | 2017 |  |
| Provision (benefit) for income taxes: |  |  |  |  |  |  |
| Current: |  |  |  |  |  |  |
| Federal | $ | 13,143 |  |  | $ | 8,327 |  |  | $ | — |  |  |
| State | 16,945 |  |  | 8,219 |  |  | 6,342 |  |  |
| Foreign | 9,816 |  |  | 13,294 |  |  | 14,563 |  |  |
| Total current | 39,904 |  |  | 29,840 |  |  | 20,905 |  |  |
| Deferred: |  |  |  |  |  |  |
| Federal | 31,872 |  |  | 475,951 |  | (1 | ) | (1,047,699 | ) | (1 | ) |
| State | (9,159 | ) |  | (8,202 | ) |  | (77,429 | ) | (1 | ) |
| Foreign | (2,861 | ) |  | (4,118 | ) |  | (1,604 | ) |  |
| Total deferred | 19,852 |  |  | 463,631 |  |  | (1,126,732 | ) |  |
| Provision (benefit) for income taxes | $ | 59,756 |  |  | $ | 493,471 |  |  | $ | (1,105,827 | ) |  |

[0000936395-19-000056:notes:297]
(1)  The income tax expense for 2018 includes the impact of the remeasurement of the net deferred tax assets and the federal transition tax. See further discussion below. The income tax benefit for fiscal 2017 includes the reversal of a significant portion of the valuation allowance on Ciena’s deferred tax assets in the U.S.

[0000936395-19-000056:notes:298]
For the fiscal periods indicated, income before provision for income taxes consists of the following (in thousands):

[0000936395-19-000056:notes:299]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| United States | $ | 256,461 |  |  | $ | 106,972 |  |  | $ | 114,242 |  |
| Foreign | 56,729 |  |  | 41,809 |  |  | 41,884 |  |
| Total | $ | 313,190 |  |  | $ | 148,781 |  |  | $ | 156,126 |  |

[0000936395-19-000056:notes:300]
Ciena’s foreign income tax as a percentage of foreign income may appear disproportionate compared to the expected tax based on the U.S. federal statutory rate and is dependent on the mix of earnings and tax rates in foreign jurisdictions.

[0000936395-19-000056:notes:301]
For the periods indicated, the tax provision (benefit) reconciles to the amount computed by multiplying income before income taxes by the U.S. federal statutory rate of 21% for fiscal 2019, 23.41% for fiscal 2018 (see note below), and 35% for fiscal 2017 as follows:

[0000936395-19-000056:notes:302]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Provision at statutory rate | 21.00 | % |  | 23.41 | % |  | 35.00 | % |
| Deferred tax assets remeasurement | — | % |  | 294.56 | % |  | — | % |
| Base Erosion and Anti-Abuse Tax | 3.60 | % |  | — | % |  | — | % |
| State taxes | 2.18 | % |  | (0.16 | )% |  | 2.29 | % |
| Foreign taxes | (0.37 | )% |  | 1.22 | % |  | (0.35 | )% |
| Research and development credit | (7.53 | )% |  | (8.80 | )% |  | (15.38 | )% |
| Non-deductible compensation | 1.01 | % |  | 3.39 | % |  | 3.45 | % |
| Fair value of debt conversion liability | — | % |  | 1.90 | % |  | — | % |
| Transition tax | 0.29 | % |  | 23.23 | % |  | — | % |
| Valuation allowance | (2.13 | )% |  | (11.95 | )% |  | (739.97 | )% |
| Other | 1.03 | % |  | 4.88 | % |  | 6.67 | % |
| Effective income tax rate | 19.08 | % |  | 331.68 | % |  | (708.29 | )% |

[0000936395-19-000056:notes:303]
On December 22, 2017, the Tax Act was enacted. The Tax Act significantly revises the U.S. corporate income tax by, among other things, lowering the statutory corporate income tax rate (“federal tax rate”) from 35% to 21% effective January 1, 2018, implementing a modified territorial tax system, and imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries.

[0000936395-19-000056:notes:304]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, Ciena computed its income tax expense for the October 31, 2018 fiscal year using a blended federal tax rate of 23.41%. Ciena remeasured its DTA using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000936395-19-000056:notes:305]
In December 2017, the SEC issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional amounts when it does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes due to the Tax Act. The measurement period ends when a company has obtained, prepared and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above amounts to the extent they are provisional due to changes in interpretations of the Tax Act, legislative action to address questions that arise because of the Tax Act, changes in accounting standards for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. The enactment of the Tax Act resulted in Ciena recording a provisional tax expense of $472.8 million in fiscal 2018. In the first quarter of fiscal 2019, the measurement period under the Tax Act concluded, which resulted in immaterial adjustments to our provisional estimates.

[0000936395-19-000056:notes:306]
Ciena is also required to make accounting policy elections as a result of the Tax Act. These include whether a valuation allowance is recorded for the estimated effect of the application of GILTI and BEAT or if these will be treated as period costs when incurred. Ciena had made the incremental cash tax cost policy election with respect to analyzing the impact of GILTI on the assessment of the realizability of net operating losses. Ciena’s analysis of the new BEAT rules, as well as the very recent regulatory guidance and how they may impact the company, continue to progress.  The realizability of U.S. tax carryforwards is not impacted by the BEAT, and the BEAT is a period cost when incurred. Ciena is also required to elect to either treat taxes due on future GILTI inclusions in U.S. taxable income as a current period expense when incurred or reflect such portion of the future GILTI inclusions in U.S. taxable income that relate to existing basis differences in Ciena’s current measurement of deferred taxes. Ciena’s accounting policy election is to treat the taxes due on future U.S. inclusions in taxable income under GILTI as a period cost when incurred.

[0000936395-19-000056:notes:307]
The significant components of DTA are as follows (in thousands):

[0000936395-19-000056:notes:308]
|  | October 31, |
|  | 2019 |  | 2018 |
| Deferred tax assets: |  |  |  |
| Reserves and accrued liabilities | $ | 54,183 |  |  | $ | 40,959 |  |
| Depreciation and amortization | 455,007 |  |  | 353,838 |  |
| NOL and credit carry forward | 302,325 |  |  | 483,495 |  |
| Other | 39,405 |  |  | 9,397 |  |
| Gross deferred tax assets | 850,920 |  |  | 887,689 |  |
| Valuation allowance | (135,978 | ) |  | (142,650 | ) |
| Deferred tax asset, net of valuation allowance | $ | 714,942 |  |  | $ | 745,039 |  |

[0000936395-19-000056:notes:309]
A reconciliation of the beginning and ending amount of unrecognized tax benefits, excluding interest and penalties, is as follows (in thousands):

[0000936395-19-000056:notes:310]
|  | Amount |
| Unrecognized tax benefits at October 31, 2016 | $ | 30,668 |  |
| Increase related to positions taken in prior period | 122 |  |
| Increase related to positions taken in current period | 111,412 |  |
| Reductions related to expiration of statute of limitations | (620 | ) |
| Unrecognized tax benefits at October 31, 2017 | 141,582 |  |
| Decrease related to positions taken in prior period | (46,400 | ) |
| Increase related to positions taken in current period | 2,482 |  |
| Reductions related to expiration of statute of limitations | (1,301 | ) |
| Unrecognized tax benefits at October 31, 2018 | 96,363 |  |
| Increase related to positions taken in prior period | 1,959 |  |
| Reductions related to settlements with taxing authorities | (1,224 | ) |
| Reductions related to expiration of statute of limitations | (2,494 | ) |
| Unrecognized tax benefits at October 31, 2019 | $ | 94,604 |  |

[0000936395-19-000056:notes:311]
As of October 31, 2019 and 2018, Ciena had accrued $3.0 million and $3.5 million of interest and penalties, respectively, related to unrecognized tax benefits within other long-term liabilities in the Consolidated Balance Sheets. Interest and penalties of $1.0 million and $0.6 million were recorded as a net benefit to the provision for income taxes during fiscal 2019 and fiscal 2017, respectively. During fiscal 2019, Ciena recorded a net benefit primarily as a result of a settlement with a taxing authority. During fiscal 2017, Ciena recorded a net benefit primarily as a result of recognizing a portion of previously unrecognized tax benefits. During fiscal 2018, Ciena recorded a provision for interest and penalties in its provision for income taxes of $1.1 million. If recognized, the entire balance of unrecognized tax benefits would impact the effective tax rate. Over the next 12 months, Ciena does not estimate any material changes in unrecognized income tax benefits.

[0000936395-19-000056:notes:312]
Ciena has not provided for U.S. deferred income taxes on the cumulative unremitted earnings of its non-U.S. affiliates, as it plans to indefinitely reinvest these foreign earnings outside the U.S. As of October 31, 2019, the cumulative amount of such temporary differences for which a deferred tax liability has not been recognized is an estimated $372.0 million. If these earnings were distributed to the U.S., Ciena would be subject to additional foreign withholding taxes of approximately $31.0 million. Additionally, there are no other significant temporary differences for which a deferred tax liability has not been recognized.

[0000936395-19-000056:notes:313]
As of October 31, 2019, Ciena continues to maintain a valuation allowance against net deferred tax assets of $136.0 million primarily related to state and foreign net operating losses and credits that Ciena estimates it will not be able to use.

[0000936395-19-000056:notes:314]
The following table summarizes the activity in Ciena’s valuation allowance against its gross deferred tax assets (in thousands):

[0000936395-19-000056:notes:315]
| Year ended |  | Beginning |  |  |  |  |  | Ending |
| October 31, |  | Balance |  | Additions |  | Deductions |  | Balance |
| 2017 |  | $ | 1,489,780 |  |  | $ | — |  |  | $ | 1,303,882 |  |  | $ | 185,898 |  |
| 2018 |  | $ | 185,898 |  |  | $ | 23,720 |  |  | $ | 66,968 |  |  | $ | 142,650 |  |
| 2019 |  | $ | 142,650 |  |  | $ | 27,459 |  |  | $ | 34,131 |  |  | $ | 135,978 |  |

[0000936395-19-000056:notes:316]
As of October 31, 2019, Ciena had a $391.0 million net operating loss carry forward and a $62.0 million income tax credit carry forward which begin to expire in fiscal 2029 and fiscal 2021, respectively. Ciena’s ability to use net operating losses and credit carry forwards is subject to limitations pursuant to the ownership change rules of the Internal Revenue Code Section 382.

[0000936395-19-000056:notes:317]
Ciena adopted ASU 2016-09, Improvements to Employee Share-Based Payment Accounting, in the first quarter of fiscal 2018. In connection with the adoption of this guidance, Ciena recognized approximately $62.1 million of deferred tax assets related to previously unrecognized tax benefits. This was recorded as a cumulative-effect adjustment to retained earnings as of the beginning of the first quarter of fiscal 2018.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000936395-19-000056:notes:318]
SHARE-BASED COMPENSATION EXPENSE
Ciena has outstanding equity awards issued under its 2017 Omnibus Incentive Plan (the “2017 Plan”), its 2008 Omnibus Incentive Plan, and certain legacy equity plans and equity plans assumed as a result of previous acquisitions. All equity awards granted on or after March 23, 2017 are made exclusively from the 2017 Plan. Ciena also makes shares of its common stock available for purchase under its Amended and Restated 2003 Employee Stock Purchase Plan (the “ESPP”). Each of the 2017 Plan and the ESPP are described below.

[0000936395-19-000056:notes:319]
2017 Plan

[0000936395-19-000056:notes:320]
The 2017 Plan has a ten-year term and authorizes the issuance of awards including stock options, restricted stock units (RSUs), restricted stock, unrestricted stock, stock appreciation rights (SARs) and other equity and/or cash performance incentive awards to employees, directors and consultants of Ciena. Subject to certain restrictions, the Compensation Committee of the Board of Directors has broad discretion to establish the terms and conditions for awards under the 2017 Plan, including the number of shares, vesting conditions, and the required service or performance criteria. Options and SARs have a maximum term of ten years, and their exercise price may not be less than 100% of fair market value on the date of grant. Repricing of stock options and SARs is prohibited without stockholder approval. Certain change in control transactions may cause awards granted under the 2017 Plan to vest, unless the awards are continued or substituted for in connection with the transaction.

[0000936395-19-000056:notes:321]
The 2017 Plan authorizes and reserves 8.9 million shares for issuance. In addition, any shares that remained available for issuance under the 2008 Plan as of March 23, 2017 were added to the 2017 Plan and are available for issuance thereunder. The number of shares available under the 2017 Plan will also be increased from time to time by: (i) the number of shares subject to outstanding awards granted under Ciena’s prior equity compensation plans that are forfeited, expire or are canceled without delivery of common stock following the effective date of the 2017 Plan, and (ii) the number of shares subject to awards assumed or substituted in connection with the acquisition of another company. As of October 31, 2019, the total number of shares authorized for issuance under the 2017 Plan is 8.9 million and approximately 5.0 million shares remained available for issuance thereunder.

[0000936395-19-000056:notes:322]
Stock Options

[0000936395-19-000056:notes:323]
There were no stock options granted by Ciena during fiscal 2019, fiscal 2018 or fiscal 2017. Outstanding stock option awards granted to employees in prior periods are generally subject to service-based vesting conditions and vest over a four-year period. The following table is a summary of Ciena’s stock option activity for the periods indicated (shares in thousands):

[0000936395-19-000056:notes:324]
|  | Shares UnderlyingOptionsOutstanding |  | WeightedAverageExercise Price |
| Balance as of October 31, 2018 | 276 |  |  | $ | 33.52 |  |
| Granted | — |  |  | — |  |
| Exercised | (50 | ) |  | $ | 24.13 |  |
| Canceled | (6 | ) |  | $ | 37.03 |  |
| Balance as of October 31, 2019 | 220 |  |  | $ | 35.54 |  |

[0000936395-19-000056:notes:325]
The total intrinsic value of options exercised during fiscal 2019, fiscal 2018 and fiscal 2017 was $0.8 million, $2.2 million and $3.1 million, respectively.

[0000936395-19-000056:notes:326]
The following table summarizes information with respect to stock options outstanding at October 31, 2019, based on Ciena’s closing stock price on the last trading day of Ciena’s fiscal 2019 (shares and intrinsic value in thousands):

[0000936395-19-000056:notes:327]
|  |  |  |  |  |  | Options Outstanding and Vested at |
|  |  |  |  |  |  | October 31, 2019 |
|  |  |  |  |  |  | Number |  | WeightedAverageRemaining |  | Weighted |  |  |
| Range of |  | of |  | Contractual |  | Average |  | Aggregate |
| Exercise |  | Underlying |  | Life |  | Exercise |  | Intrinsic |
| Price |  | Shares |  | (Years) |  | Price |  | Value |
| $ | 6.43 |  |  | — |  |  | $ | 10.50 |  |  | 4 |  |  | 0.81 |  | $ | 8.42 |  |  | $ | 117 |  |
| $ | 11.34 |  |  | — |  |  | $ | 15.67 |  |  | 49 |  |  | 2.79 |  | $ | 13.51 |  |  | 1,123 |  |
| $ | 17.50 |  |  | — |  |  | $ | 19.25 |  |  | 11 |  |  | 4.6 |  | $ | 18.17 |  |  | 202 |  |
| $ | 32.06 |  |  | — |  |  | $ | 37.10 |  |  | 31 |  |  | 3.27 |  | $ | 36.04 |  |  | 28 |  |
| $ | 41.52 |  |  | — |  |  | $ | 55.63 |  |  | 125 |  |  | 3.48 |  | $ | 46.47 |  |  | — |  |
| $ | 6.43 |  |  | — |  |  | $ | 55.63 |  |  | 220 |  |  | 3.30 |  | $ | 35.54 |  |  | $ | 1,470 |  |

[0000936395-19-000056:notes:328]
Assumptions for Option-Based Awards

[0000936395-19-000056:notes:329]
Ciena recognizes the fair value of stock options as share-based compensation expense on a straight-line basis over the requisite service period. Ciena did not grant any option-based awards during fiscal 2019, fiscal 2018, or fiscal 2017.

[0000936395-19-000056:notes:330]
Restricted Stock Units

[0000936395-19-000056:notes:331]
A restricted stock unit is a stock award that entitles the holder to receive shares of Ciena common stock as the unit vests. Ciena’s outstanding restricted stock unit awards are subject to service-based vesting conditions and/or performance-based vesting conditions. Awards subject to service-based conditions typically vest in increments over a three or four-year period. However, the 2017 Plan permits Ciena to grant service-based stock awards with a minimum one-year vesting period. Awards with performance-based vesting conditions (i) require the achievement of certain operational, financial or other performance criteria or targets or (ii) vest based on Ciena’s total shareholder return as compared to an index of peer companies, in whole or in part.

[0000936395-19-000056:notes:332]
Assumptions for Restricted Stock Unit Awards

[0000936395-19-000056:notes:333]
Ciena recognizes the estimated fair value of performance-based awards as share-based compensation expense over the performance period, using graded vesting, which considers each performance period or tranche separately, based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At the end of each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets.

[0000936395-19-000056:notes:334]
Ciena recognizes the estimated fair value of restricted stock units subject only to service-based vesting conditions by multiplying the number of shares underlying the award by the closing price per share of Ciena common stock on the grant date. Ciena recognizes the estimated fair value of restricted stock units subject to performance-based vesting conditions other than total shareholder return by assuming the satisfaction of any performance-based objectives at the “target” level and multiplying the corresponding number of shares earned based upon such achievement by the closing price per share of Ciena common stock on the grant date.

[0000936395-19-000056:notes:335]
Ciena recognizes the estimated fair value of performance based awards subject to total shareholder return as compared to an index of peer companies using a Monte Carlo simulation valuation model. Assumptions for awards granted during fiscal 2019 and fiscal 2018 included the following:

[0000936395-19-000056:notes:336]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |
| Expected volatility of Ciena common stock, which is a weighted average of implied volatility and historical volatility | 34.10% |  | 34.93% |
| Historical volatility of Ciena common stock | 36.80% |  | 38.24% |
| Historical volatility of S&P Networking Index | 17.39% |  | 17.14% |
| Correlation coefficient | 0.6251 |  | 0.6597 |
| Expected life in years | 2.87 |  | 2.89 |
| Risk-free interest rate | 2.62% |  | 1.94% |
| Expected dividend yield | 0.0% |  | 0.0% |

[0000936395-19-000056:notes:337]
The following table is a summary of Ciena’s restricted stock unit activity for the period indicated, with the aggregate fair value of the balance outstanding at the end of each period, based on Ciena’s closing stock price on the last trading day of the relevant period (shares and aggregate fair value in thousands):

[0000936395-19-000056:notes:338]
|  | RestrictedStock UnitsOutstanding |  | WeightedAverageGrant DateFair ValuePer Share |  | Aggregate FairValue |
| Balance as of October 31, 2018 | 4,402 |  |  | $ | 22.26 |  |  | $ | 140,943 |  |
| Granted | 2,057 |  |  |  |  |  |
| Vested | (2,101 | ) |  |  |  |  |
| Canceled or forfeited | (348 | ) |  |  |  |  |
| Balance as of October 31, 2019 | 4,010 |  |  | $ | 27.94 |  |  | $ | 146,091 |  |

[0000936395-19-000056:notes:339]
As of October 31, 2019 and 2018, 0.3 million and 0.2 million of the total restricted stock units outstanding are performance based awards subject to total shareholder return, respectively. The total fair value of restricted stock units that vested and were converted into common stock during fiscal 2019, fiscal 2018 and fiscal 2017 was $79.2 million, $54.3 million and $49.5 million, respectively. The weighted average fair value of each restricted stock unit granted by Ciena during fiscal 2019, fiscal 2018 and fiscal 2017 was $34.53, $22.46 and $23.29, respectively.

[0000936395-19-000056:notes:340]
The fair value of each restricted stock unit award is based on the closing price on the date of grant. Share-based expense for service-based restricted stock unit awards is recognized ratably over the vesting period on a straight-line basis.

[0000936395-19-000056:notes:341]
Share-based expense for performance-based restricted stock unit awards is recognized ratably over the performance period based on Ciena’s determination of whether it is probable that the performance targets will be achieved. At each reporting period, Ciena reassesses the probability of achieving the performance targets and the performance period required to meet those targets. The estimation of whether the performance targets will be achieved involves judgment, and the estimate of expense is revised periodically based on the probability of achieving the performance targets. Revisions are reflected in the period in which the estimate is changed. If any performance goals are not met, no compensation cost is ultimately recognized against that goal and, to the extent previously recognized, compensation expense is reversed.

[0000936395-19-000056:notes:342]
Share-based compensation expense is recognized only for those awards that are ultimately expected to vest. In the event of a forfeiture of an award, the expense related to the unvested portion of that award is reversed. Reversal of share-based compensation expense based on forfeitures can materially affect the measurement of estimated fair value of Ciena’s share-based compensation.

[0000936395-19-000056:notes:343]
Amended and Restated ESPP

[0000936395-19-000056:notes:344]
Under the ESPP, eligible employees may enroll in a twelve-month offer period that begins in December and June of each year. Each offer period includes two six-month purchase periods. Employees may purchase a limited number of shares of Ciena common stock at 85% of the fair market value on either the day immediately preceding the offer date or the purchase date, whichever is lower. The ESPP is considered compensatory for purposes of share-based compensation expense. Pursuant to the ESPP’s “evergreen” provision, on December 31 of each year, the number of shares available under the ESPP increases by up to 0.6 million shares, provided that the total number of shares available at that time shall not exceed 8.2 million. Unless earlier terminated, the ESPP will terminate on January 24, 2023.

[0000936395-19-000056:notes:345]
During fiscal 2019, fiscal 2018 and fiscal 2017, Ciena issued 1.0 million, 1.1 million and 1.0 million shares under the ESPP, respectively. At October 31, 2019, 4.5 million shares remained available for issuance under the ESPP.

[0000936395-19-000056:notes:346]
The following table summarizes share-based compensation expense for the periods indicated (in thousands):

[0000936395-19-000056:notes:347]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Product cost of goods sold | $ | 2,868 |  |  | $ | 2,984 |  |  | $ | 2,672 |  |
| Service cost of goods sold | 3,175 |  |  | 2,616 |  |  | 2,487 |  |
| Share-based compensation expense included in cost of goods sold | 6,043 |  |  | 5,600 |  |  | 5,159 |  |
| Research and development | 14,321 |  |  | 13,518 |  |  | 12,957 |  |
| Sales and marketing | 16,474 |  |  | 14,246 |  |  | 12,846 |  |
| General and administrative | 22,841 |  |  | 19,709 |  |  | 17,321 |  |
| Share-based compensation expense included in operating expense | 53,636 |  |  | 47,473 |  |  | 43,124 |  |
| Share-based compensation expense capitalized in inventory, net | 57 |  |  | (101 | ) |  | 77 |  |
| Total share-based compensation | $ | 59,736 |  |  | $ | 52,972 |  |  | $ | 48,360 |  |

[0000936395-19-000056:notes:348]
As of October 31, 2019, total unrecognized share-based compensation expense was $88.2 million which relates to unvested restricted stock units and is expected to be recognized over a weighted-average period of 1.45 years.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000936395-19-000056:notes:349]
SEGMENT AND ENTITY WIDE DISCLOSURES
Segment Reporting

[0000936395-19-000056:notes:350]
Ciena has the following operating segments for reporting purposes: (i) Networking Platforms; (ii) Platform Software and Services; (iii) Blue Planet Automation Software and Services; and (iv) Global Services. During fiscal 2019, we separated our previous Software and Software-Related Services segment into two stand-alone operating segments. Because Ciena previously disclosed its Platform Software and Services and Blue Planet Automation Software and Services as distinct product lines in its presentation of segment revenue for Software and Software-Related Services, there is no significant change to our presentation of segment revenues as a result of this separation. Comparative periods have been retrospectively adjusted to disclose segment profit for Platform Software and Services and Blue Planet Automation Software and Services.

[0000936395-19-000056:notes:351]
Ciena’s long-lived assets, including equipment, building, furniture and fixtures, finite-lived intangible assets, and maintenance spares, are not reviewed by the chief operating decision maker for purposes of evaluating performance and allocating resources. As of October 31, 2019, equipment, building, furniture and fixtures totaling $286.9 million primarily supports asset groups within Ciena’s Networking Platforms, Platform Software and Services and Blue Planet Automation Software and Services segments and Ciena’s unallocated selling and general and administrative activities. As of October 31, 2019, $20.3 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Networking Platforms segment and $92.5 million of Ciena’s intangible assets were assigned to asset groups within Ciena’s Blue Planet Automation Software and Services segment. As of October 31, 2019, all of the maintenance spares totaling $55.5 million were assigned to asset groups within Ciena’s Global Services segment.

[0000936395-19-000056:notes:352]
Segment Revenue

[0000936395-19-000056:notes:353]
The table below (in thousands, except percentage data) sets forth Ciena’s segment revenue for the respective periods indicated:

[0000936395-19-000056:notes:354]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Revenue: |  |  |  |  |  |
| Networking Platforms |  |  |  |  |  |
| Converged Packet Optical | $ | 2,562,841 |  |  | $ | 2,194,519 |  |  | $ | 1,939,621 |  |
| Packet Networking | 348,477 |  |  | 283,499 |  |  | 313,089 |  |
| Total Networking Platforms | 2,911,318 |  |  | 2,478,018 |  |  | 2,252,710 |  |
| Platform Software and Services | 155,376 |  |  | 173,949 |  |  | 145,009 |  |
| Blue Planet Automation Software and Services | 54,555 |  |  | 26,764 |  |  | 16,110 |  |
| Global Services |  |  |  |  |  |
| Maintenance Support and Training | 261,337 |  |  | 245,161 |  |  | 227,400 |  |
| Installation and Deployment | 148,233 |  |  | 128,829 |  |  | 117,524 |  |
| Consulting and Network Design | 41,312 |  |  | 41,565 |  |  | 42,934 |  |
| Total Global Services | 450,882 |  |  | 415,555 |  |  | 387,858 |  |
| Total revenue | $ | 3,572,131 |  |  | $ | 3,094,286 |  |  | $ | 2,801,687 |  |

[0000936395-19-000056:notes:355]
Segment Profit (Loss)

[0000936395-19-000056:notes:356]
The presentation of segment profit (loss) for fiscal 2018 and 2017 reflects the change in Ciena’s software operating segments as described above. Segment profit (loss) is determined based on internal performance measures used by Ciena’s chief executive officer to assess the performance of each operating segment in a given period. In connection with that assessment, the chief executive officer excludes the following items: selling and marketing costs; general and administrative costs; amortization of intangible assets; acquisition and integration costs; significant asset impairments and restructuring costs, interest and other income (loss), net; interest expense; loss on extinguishment and modification of debt; and provision (benefit) for income taxes.

[0000936395-19-000056:notes:357]
The table below (in thousands) sets forth Ciena’s segment profit (loss) and the reconciliation to consolidated net income (loss) during the respective periods indicated:

[0000936395-19-000056:notes:358]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Segment profit (loss): |  |  |  |  |  |
| Networking Platforms | $ | 759,244 |  |  | $ | 581,113 |  |  | $ | 578,039 |  |
| Platform Software and Services | 64,210 |  |  | 78,048 |  |  | 47,353 |  |
| Blue Planet Automation Software and Services | (17,769 | ) |  | (8,240 | ) |  | (14,817 | ) |
| Global Services | 188,242 |  |  | 172,205 |  |  | 159,882 |  |
| Total segment profit | 993,927 |  |  | 823,126 |  |  | 770,457 |  |
| Less: non-performance operating expenses |  |  |  |  |  |
| Selling and marketing | 423,046 |  |  | 394,060 |  |  | 356,169 |  |
| General and administrative | 174,399 |  |  | 160,133 |  |  | 142,604 |  |
| Amortization of intangible assets | 21,808 |  |  | 15,737 |  |  | 33,029 |  |
| Acquisition and integration costs | 3,370 |  |  | 5,111 |  |  | — |  |
| Significant asset impairments and restructuring costs | 24,538 |  |  | 18,139 |  |  | 23,933 |  |
| Add: other non-performance financial items |  |  |  |  |  |
| Interest and other income (loss), net | 3,876 |  |  | (12,029 | ) |  | 913 |  |
| Interest expense | (37,452 | ) |  | (55,249 | ) |  | (55,852 | ) |
| Loss on extinguishment and modification of debt | — |  |  | (13,887 | ) |  | (3,657 | ) |
| Less: Provision (benefit) for income taxes | 59,756 |  |  | 493,471 |  |  | (1,105,827 | ) |
| Total net income (loss) | $ | 253,434 |  |  | $ | (344,690 | ) |  | $ | 1,261,953 |  |

[0000936395-19-000056:notes:359]
Entity Wide Reporting

[0000936395-19-000056:notes:360]
Ciena’s operating segments each engage in business across four geographic regions: North America; Europe, Middle East and Africa (“EMEA”); Asia-Pacific, Japan and India (“APAC”); and Caribbean and Latin America (“CALA”). North America includes only activities in the United States and Canada. The following table reflects Ciena’s geographic distribution of revenue principally based on the relevant location for Ciena’s delivery of products and performance of services. For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):

[0000936395-19-000056:notes:361]
|  | Year Ended October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| North America | $ | 2,351,260 |  |  | $ | 1,886,450 |  |  | $ | 1,736,047 |  |
| EMEA | 566,718 |  |  | 464,876 |  |  | 404,099 |  |
| CALA | 152,653 |  |  | 140,177 |  |  | 164,308 |  |
| APAC | 501,500 |  |  | 602,783 |  |  | 497,233 |  |
| Total | $ | 3,572,131 |  |  | $ | 3,094,286 |  |  | $ | 2,801,687 |  |

[0000936395-19-000056:notes:362]
North America includes $2.25 billion, $1.77 billion and $1.63 billion of United States revenue for fiscal years ended October 31, 2019, 2018 and 2017, respectively. No other country accounted for at least 10% of total revenue for the periods presented above.

[0000936395-19-000056:notes:363]
The following table reflects Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, with any country accounting for at least 10% of total equipment, building, furniture and fixtures, net, specifically identified. Equipment, building, furniture and fixtures, net, attributable to geographic regions outside of the United States and Canada are reflected as “Other International.” For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-19-000056:notes:364]
|  | October 31, |
|  | 2019 |  | 2018 |
| Canada | $ | 211,901 |  |  | $ | 198,028 |  |
| United States | 58,119 |  |  | 75,479 |  |
| Other International | 16,864 |  |  | 18,560 |  |
| Total | $ | 286,884 |  |  | $ | 292,067 |  |

[0000936395-19-000056:notes:365]
While Ciena has benefited from the diversification of its business and customer base, its ten largest customers contributed 59.3% of fiscal 2019 revenue, 56.5% of fiscal 2018 revenue and 55.6% of fiscal 2017 revenue.

[0000936395-19-000056:notes:366]
For the periods below, customers accounting for at least 10% of Ciena’s revenue were as follows (in thousands):

[0000936395-19-000056:notes:367]
|  | October 31, |
|  | 2019 |  | 2018 |  | 2017 |
| Verizon | $ | 459,787 |  |  | $ | 318,013 |  |  | $ | 288,048 |  |
| AT&T | 388,704 |  |  | 374,576 |  |  | 448,943 |  |
| Web-scale provider | 370,577 |  |  | n/a |  |  | n/a |  |
| Total | $ | 1,219,068 |  |  | $ | 692,589 |  |  | $ | 736,991 |  |

[0000936395-19-000056:notes:368]
________________________________

[0000936395-19-000056:notes:369]
| n/a | Denotes revenue representing less than 10% of total revenue for the period |

[0000936395-19-000056:notes:370]
The Web-scale provider noted above contributed greater than 10% of total revenue for the first time in fiscal 2019 and purchased products from each of Ciena’s operating segments excluding Blue Planet Automation Software and Services. The other customers identified above purchased products and services from each of Ciena’s operating segments.


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0000936395-19-000056:notes:371]
For the periods below, Ciena’s geographic distribution of equipment, building, furniture and fixtures, net, was as follows (in thousands):

[0000936395-19-000056:notes:372]
For the periods below, Ciena’s geographic distribution of revenue was as follows (in thousands):


## us-gaap:CompensationAndEmployeeBenefitPlansTextBlock

[0000936395-19-000056:notes:373]
OTHER EMPLOYEE BENEFIT PLANS
Ciena has a Defined Contribution Pension Plan that covers a majority of its Canada-based employees. The plan covers all Canada-based employees who are not part of an excluded group. Total contributions (employee and employer) cannot exceed the lesser of 18% of participant earnings and an annual dollar limit (CAD$27,230 (approximately $20,725) for 2019). This plan includes a required employer contribution of 1% for all participants and a 50% matching of participant contributions up to a total annual maximum of CAD$3,000 (approximately $2,283) per employee. During fiscal 2019, 2018 and 2017, Ciena made matching contributions of approximately CAD$5.2 million (approximately $4.0 million), CAD$5.1 million (approximately $3.9 million) and CAD$4.7 million (approximately $3.6 million), respectively.

[0000936395-19-000056:notes:374]
Ciena has a 401(k) defined contribution profit sharing plan. Participants may contribute up to 60% of pre-tax compensation, subject to certain limitations. The plan includes an employer matching contribution equal to 50% of the first 6% an employee contributes each pay period. Ciena may also make discretionary annual profit contributions up to the IRS regulated limit. Ciena has made no profit sharing contributions to date. During fiscal 2019, 2018 and 2017, Ciena made matching contributions of approximately $5.9 million, $5.8 million and $5.7 million, respectively.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000936395-19-000056:notes:375]
COMMITMENTS AND CONTINGENCIES

[0000936395-19-000056:notes:376]
Government Grant

[0000936395-19-000056:notes:377]
During fiscal 2018, Ciena entered into agreements related to the Evolution of Networking Services through a Corridor in Quebec and Ontario for Research and Innovation project with the Canadian federal government, the government of the province of Ontario and the government of the province of Quebec to develop a 5G technology corridor between Quebec and Ontario to promote research and development, small business enterprises and entrepreneurs in Canada. Under these agreements, Ciena can receive up to an aggregate CAD$57.6 million (approximately $43.8 million) in reimbursement from the three Canadian government entities for eligible costs over a period commencing on February 20, 2017 and ending on March 31, 2022. Ciena anticipates receiving recurring disbursements over this period. Amounts received under the agreements are subject to recoupment in the event that Ciena fails to achieve certain minimum investment, employment and project milestones. As of October 31, 2019, Ciena has recorded CAD$28.9 million (approximately $22.0 million) in cumulative benefits as a reduction in research and development expense of which CAD$12.3 million (approximately $9.2 million) was recorded in fiscal 2019. As of October 31, 2019, amounts receivable from this grant were CAD$10.4 million (approximately $7.9 million).

[0000936395-19-000056:notes:378]
Tax Contingencies

[0000936395-19-000056:notes:379]
Ciena is subject to various tax liabilities arising in the ordinary course of business. Ciena does not expect that the ultimate settlement of these tax liabilities will have a material effect on its results of operations, financial position or cash flows.

[0000936395-19-000056:notes:380]
Litigation

[0000936395-19-000056:notes:381]
Ciena is subject to various legal proceedings, claims and other matters arising in the ordinary course of business, including those that relate to employment, commercial, tax and other regulatory matters. Ciena is also subject to intellectual property related claims, including claims against third parties that may involve contractual indemnification obligations on the part of Ciena. Ciena does not expect that the ultimate costs to resolve such matters will have a material effect on its results of operations, financial position or cash flows.

[0000936395-19-000056:notes:382]
Lease Commitments

[0000936395-19-000056:notes:383]
Ciena has certain minimum obligations under non-cancelable leases expiring on various dates through 2032 for equipment and facilities. The following table summarizes Ciena’s future annual minimum lease commitments under non-cancelable leases that are not recorded on the balance sheet as of October 31, 2019 (in thousands):

[0000936395-19-000056:notes:384]
|  |  | 2020 |  | 2021 |  | 2022 |  | 2023 |  | 2024 |  | Thereafter |  | Total |
| Operating leases |  | $ | 28,776 |  |  | $ | 24,184 |  |  | $ | 16,767 |  |  | $ | 13,393 |  |  | $ | 10,632 |  |  | $ | 26,110 |  |  | $ | 119,862 |  |

[0000936395-19-000056:notes:385]
Rental expense for fiscal 2019, fiscal 2018 and fiscal 2017 was approximately $22.0 million, $24.1 million and $30.9 million, respectively. In addition, Ciena paid approximately $1.3 million, $1.9 million and $2.7 million during fiscal 2019, fiscal 2018 and fiscal 2017, respectively, related to rent costs for restructured facilities and unfavorable lease commitments, which were offset against Ciena’s restructuring liabilities and unfavorable lease obligations. The amount for operating lease commitments above does not include variable expenses relating to insurance, taxes, maintenance and other costs required by the applicable operating lease. These costs are not expected to have a material impact on Ciena’s financial condition, results of operations or cash flows.


## us-gaap:SubsequentEventsTextBlock

[0000936395-19-000056:notes:386]
SUBSEQUENT EVENTS

[0000936395-19-000056:notes:387]
From the end of the fourth quarter of fiscal 2019 through December 16, 2019, Ciena repurchased an additional 737,474 shares of its common stock, for an aggregate purchase price of $27.4 million at an average price of $37.21 per share, inclusive of repurchases pending settlement. As of December 16, 2019, Ciena has repurchased an aggregate of 4,575,940 shares and has an aggregate of $322.5 million of authorized funds remaining under its Stock Repurchase Program.

[0000936395-19-000056:notes:388]
Centina Acquisition

[0000936395-19-000056:notes:389]
On October 3, 2019, Ciena entered into a definitive agreement to acquire privately-held Centina Systems, Inc., a provider of service assurance analytics and network performance management solutions. The transaction closed during Ciena’s first quarter of fiscal 2020.

[0000936395-19-000056:notes:390]
Tax Regulations

[0000936395-19-000056:notes:391]
On December 2, 2019, the U.S. Department of the Treasury released final regulations and proposed regulations under Section 59A, BEAT. BEAT, which requires certain U.S. corporations to pay a minimum tax associated with deductible payments to non-U.S. related parties, was enacted by the Tax Act. In addition, on December 2, 2019, the U.S. Department of the Treasury also released final regulations that provide additional guidance with respect to the foreign tax credit regime under the Tax Act. For the year ended October 31, 2019, Ciena recorded $11.3 million of BEAT and a benefit of $0.9 million attributable to such foreign tax credits. Ciena is in the process of reviewing these regulations and does not anticipate the impact of the new regulations will be material. Any tax effect will be recorded in Ciena’s fiscal 2020 results.
